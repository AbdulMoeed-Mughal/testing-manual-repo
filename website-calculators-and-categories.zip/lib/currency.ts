export type Currency = "USD" | "EUR" | "GBP" | "INR" | "CAD" | "AUD" | "JPY" | "CNY" | "CHF" | "SGD"

export type CurrencyCode = Currency

export const currencySymbols: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  INR: "₹",
  CAD: "C$",
  AUD: "A$",
  JPY: "¥",
  CNY: "¥",
  CHF: "CHF",
  SGD: "S$",
}

export const currencyLocales: Record<Currency, string> = {
  USD: "en-US",
  EUR: "de-DE",
  GBP: "en-GB",
  INR: "en-IN",
  CAD: "en-CA",
  AUD: "en-AU",
  JPY: "ja-JP",
  CNY: "zh-CN",
  CHF: "de-CH",
  SGD: "en-SG",
}

export const currencyOptions: { value: Currency; label: string; symbol: string }[] = [
  { value: "USD", label: "US Dollar", symbol: "$" },
  { value: "EUR", label: "Euro", symbol: "€" },
  { value: "GBP", label: "British Pound", symbol: "£" },
  { value: "INR", label: "Indian Rupee", symbol: "₹" },
  { value: "CAD", label: "Canadian Dollar", symbol: "C$" },
  { value: "AUD", label: "Australian Dollar", symbol: "A$" },
  { value: "JPY", label: "Japanese Yen", symbol: "¥" },
  { value: "CNY", label: "Chinese Yuan", symbol: "¥" },
  { value: "CHF", label: "Swiss Franc", symbol: "CHF" },
  { value: "SGD", label: "Singapore Dollar", symbol: "S$" },
]

export const currencies: Record<Currency, { code: Currency; name: string; symbol: string; locale: string }> = {
  USD: { code: "USD", name: "US Dollar", symbol: "$", locale: "en-US" },
  EUR: { code: "EUR", name: "Euro", symbol: "€", locale: "de-DE" },
  GBP: { code: "GBP", name: "British Pound", symbol: "£", locale: "en-GB" },
  INR: { code: "INR", name: "Indian Rupee", symbol: "₹", locale: "en-IN" },
  CAD: { code: "CAD", name: "Canadian Dollar", symbol: "C$", locale: "en-CA" },
  AUD: { code: "AUD", name: "Australian Dollar", symbol: "A$", locale: "en-AU" },
  JPY: { code: "JPY", name: "Japanese Yen", symbol: "¥", locale: "ja-JP" },
  CNY: { code: "CNY", name: "Chinese Yuan", symbol: "¥", locale: "zh-CN" },
  CHF: { code: "CHF", name: "Swiss Franc", symbol: "CHF", locale: "de-CH" },
  SGD: { code: "SGD", name: "Singapore Dollar", symbol: "S$", locale: "en-SG" },
}

export function formatCurrency(value: number, currency: Currency = "USD"): string {
  const locale = currencyLocales[currency]

  const options: Intl.NumberFormatOptions = {
    style: "currency",
    currency: currency,
    minimumFractionDigits: currency === "JPY" ? 0 : 2,
    maximumFractionDigits: currency === "JPY" ? 0 : 2,
  }

  return new Intl.NumberFormat(locale, options).format(value)
}

export function formatCurrencyCompact(value: number, currency: Currency = "USD"): string {
  const symbol = currencySymbols[currency]

  if (value >= 1000000000) {
    return `${symbol}${(value / 1000000000).toFixed(1)}B`
  } else if (value >= 1000000) {
    return `${symbol}${(value / 1000000).toFixed(1)}M`
  } else if (value >= 1000) {
    return `${symbol}${(value / 1000).toFixed(1)}K`
  }

  return formatCurrency(value, currency)
}
