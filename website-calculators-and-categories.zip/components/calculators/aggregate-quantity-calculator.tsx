"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Box, Info, Calculator, HelpCircle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type InputMode = "area" | "volume"

interface AggregateResult {
  volume: number
  weight: number
  bags50kg: number
  bags25kg: number
}

export function AggregateQuantityCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("area")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [volume, setVolume] = useState("")
  const [thickness, setThickness] = useState("")
  const [lengthUnit, setLengthUnit] = useState("m")
  const [thicknessUnit, setThicknessUnit] = useState("mm")
  const [cementRatio, setCementRatio] = useState("1")
  const [sandRatio, setSandRatio] = useState("2")
  const [aggregateRatio, setAggregateRatio] = useState("4")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [density, setDensity] = useState("1500")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<AggregateResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateAggregate = () => {
    setError("")
    setResult(null)

    let wetVolumeM3: number

    if (inputMode === "area") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)
      const thicknessNum = Number.parseFloat(thickness)

      if (isNaN(lengthNum) || lengthNum <= 0) {
        setError("Please enter a valid length greater than 0")
        return
      }
      if (isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter a valid width greater than 0")
        return
      }
      if (isNaN(thicknessNum) || thicknessNum <= 0) {
        setError("Please enter a valid thickness greater than 0")
        return
      }

      // Convert to meters
      let lengthM = lengthNum
      if (lengthUnit === "ft") lengthM *= 0.3048

      let widthM = widthNum
      if (lengthUnit === "ft") widthM *= 0.3048

      let thicknessM = thicknessNum
      if (thicknessUnit === "mm") thicknessM /= 1000
      else if (thicknessUnit === "cm") thicknessM /= 100
      else if (thicknessUnit === "in") thicknessM *= 0.0254

      wetVolumeM3 = lengthM * widthM * thicknessM
    } else {
      const volumeNum = Number.parseFloat(volume)
      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }
      wetVolumeM3 = volumeNum
    }

    const dryFactorNum = Number.parseFloat(dryVolumeFactor)
    const densityNum = Number.parseFloat(density)
    const wastageNum = Number.parseFloat(wastage)
    const cement = Number.parseFloat(cementRatio)
    const sand = Number.parseFloat(sandRatio)
    const aggregate = Number.parseFloat(aggregateRatio)

    if (isNaN(dryFactorNum) || dryFactorNum <= 0) {
      setError("Please enter a valid dry volume factor")
      return
    }
    if (isNaN(densityNum) || densityNum <= 0) {
      setError("Please enter a valid density")
      return
    }
    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }
    if (isNaN(cement) || isNaN(sand) || isNaN(aggregate) || cement <= 0 || sand <= 0 || aggregate <= 0) {
      setError("Please enter valid mix ratio values")
      return
    }

    const dryVolume = wetVolumeM3 * dryFactorNum
    const totalRatio = cement + sand + aggregate
    const aggregateVolume = dryVolume * (aggregate / totalRatio)
    const aggregateVolumeWithWastage = aggregateVolume * (1 + wastageNum / 100)
    const aggregateWeight = aggregateVolumeWithWastage * densityNum

    setResult({
      volume: Math.round(aggregateVolumeWithWastage * 1000) / 1000,
      weight: Math.round(aggregateWeight * 10) / 10,
      bags50kg: Math.ceil(aggregateWeight / 50),
      bags25kg: Math.ceil(aggregateWeight / 25),
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setVolume("")
    setThickness("")
    setCementRatio("1")
    setSandRatio("2")
    setAggregateRatio("4")
    setDryVolumeFactor("1.54")
    setDensity("1500")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Aggregate Required: ${result.volume} m³ (${result.weight} kg)\nBags: ${result.bags50kg} × 50kg or ${result.bags25kg} × 25kg`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Aggregate Quantity Result",
          text: `I calculated aggregate quantity using CalcHub! Required: ${result.volume} m³ (${result.weight} kg)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleInputMode = () => {
    setInputMode((prev) => (prev === "area" ? "volume" : "area"))
    setLength("")
    setWidth("")
    setVolume("")
    setThickness("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Box className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Aggregate Quantity Calculator</CardTitle>
                    <CardDescription>Calculate coarse aggregate required for concrete</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={toggleInputMode}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "volume" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "area" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Area-Based
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "volume" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Volume-Based
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {inputMode === "area" ? (
                  <>
                    {/* Dimensions */}
                    <div className="space-y-2">
                      <Label htmlFor="length">Length ({lengthUnit})</Label>
                      <div className="flex gap-2">
                        <Input
                          id="length"
                          type="number"
                          placeholder="Enter length"
                          value={length}
                          onChange={(e) => setLength(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <Select value={lengthUnit} onValueChange={setLengthUnit}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="m">m</SelectItem>
                            <SelectItem value="ft">ft</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="width">Width ({lengthUnit})</Label>
                      <Input
                        id="width"
                        type="number"
                        placeholder="Enter width"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="thickness">Thickness ({thicknessUnit})</Label>
                      <div className="flex gap-2">
                        <Input
                          id="thickness"
                          type="number"
                          placeholder="Enter thickness"
                          value={thickness}
                          onChange={(e) => setThickness(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <Select value={thicknessUnit} onValueChange={setThicknessUnit}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="mm">mm</SelectItem>
                            <SelectItem value="cm">cm</SelectItem>
                            <SelectItem value="m">m</SelectItem>
                            <SelectItem value="in">in</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="volume">Concrete Volume (m³)</Label>
                    <Input
                      id="volume"
                      type="number"
                      placeholder="Enter volume in cubic meters"
                      value={volume}
                      onChange={(e) => setVolume(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                {/* Mix Ratio */}
                <div className="space-y-2">
                  <Label>Mix Ratio (Cement : Sand : Aggregate)</Label>
                  <div className="grid grid-cols-5 gap-2 items-center">
                    <Input
                      type="number"
                      placeholder="C"
                      value={cementRatio}
                      onChange={(e) => setCementRatio(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                    <span className="text-center text-muted-foreground">:</span>
                    <Input
                      type="number"
                      placeholder="S"
                      value={sandRatio}
                      onChange={(e) => setSandRatio(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                    <span className="text-center text-muted-foreground">:</span>
                    <Input
                      type="number"
                      placeholder="A"
                      value={aggregateRatio}
                      onChange={(e) => setAggregateRatio(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Advanced Parameters */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="dryFactor">Dry Volume Factor</Label>
                    <Input
                      id="dryFactor"
                      type="number"
                      value={dryVolumeFactor}
                      onChange={(e) => setDryVolumeFactor(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="density">Density (kg/m³)</Label>
                    <Input
                      id="density"
                      type="number"
                      value={density}
                      onChange={(e) => setDensity(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="wastage">Wastage (%)</Label>
                  <Input
                    id="wastage"
                    type="number"
                    placeholder="Enter wastage percentage"
                    value={wastage}
                    onChange={(e) => setWastage(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAggregate} className="w-full" size="lg">
                  Calculate Aggregate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Aggregate Required</p>
                        <p className="text-4xl font-bold text-amber-600">{result.volume} m³</p>
                        <p className="text-lg font-semibold text-amber-700 mt-1">{result.weight} kg ({(result.weight / 1000).toFixed(2)} tons)</p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="p-3 bg-white/50 rounded-lg text-center">
                          <p className="text-muted-foreground mb-1">50kg Bags</p>
                          <p className="text-2xl font-bold text-amber-600">{result.bags50kg}</p>
                        </div>
                        <div className="p-3 bg-white/50 rounded-lg text-center">
                          <p className="text-muted-foreground mb-1">25kg Bags</p>
                          <p className="text-2xl font-bold text-amber-600">{result.bags25kg}</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Mix Ratios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M10 Grade</span>
                      <span className="text-sm text-amber-600">1:3:6</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M15 Grade</span>
                      <span className="text-sm text-amber-600">1:2:4</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M20 Grade</span>
                      <span className="text-sm text-amber-600">1:1.5:3</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M25 Grade</span>
                      <span className="text-sm text-amber-600">1:1:2</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Aggregate Types</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div>
                    <p className="font-semibold text-foreground mb-1">Coarse Aggregate</p>
                    <p>Particles larger than 4.75mm, typically crushed stone or gravel used in concrete mixing.</p>
                  </div>
                  <div>
                    <p className="font-semibold text-foreground mb-1">Standard Density</p>
                    <p>Typical density: 1500 kg/m³, but may vary based on aggregate type and source.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Aggregate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Coarse Aggregate?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Coarse aggregate, also known as gravel or crushed stone, is a key component in concrete and construction
                  projects. It consists of particles larger than 4.75mm and typically ranges from 10mm to 40mm in size.
                  Coarse aggregate makes up approximately 60-75% of concrete volume, providing strength, dimensional
                  stability, and wear resistance to the finished structure.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The quality and quantity of coarse aggregate significantly affect the properties of concrete, including
                  its compressive strength, workability, and durability. Properly calculating the required aggregate
                  quantity ensures optimal concrete performance while minimizing material waste and project costs.
                </p>
              </CardContent>
            </Card>

            {/* How is Aggregate Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How is Aggregate Quantity Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The aggregate quantity calculation involves several steps. First, calculate the wet concrete volume by
                  multiplying length, width, and thickness (or use the direct volume if known). Then, convert to dry volume
                  by multiplying by the dry volume factor (typically 1.54), which accounts for voids and compaction during
                  mixing.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Next, determine the aggregate proportion from the mix ratio. For example, in a 1:2:4 mix, the total ratio
                  is 7 parts, and aggregate accounts for 4/7 of the dry volume. Multiply this by the aggregate density
                  (typically 1500 kg/m³) to get the weight. Finally, add the wastage percentage (typically 5%) to account
                  for spillage, breakage, and over-excavation during construction.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <HelpCircle className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions About Aggregate</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What is the difference between coarse and fine aggregate?</h4>
                    <p className="text-muted-foreground text-sm">
                      Fine aggregate (sand) has particles smaller than 4.75mm, while coarse aggregate (gravel) consists of
                      particles larger than 4.75mm. Both are essential for concrete, with fine aggregate filling voids
                      between coarse aggregate particles.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Why do we multiply by 1.54 for dry volume?</h4>
                    <p className="text-muted-foreground text-sm">
                      The dry volume factor of 1.54 accounts for air voids between particles. When cement, sand, and
                      aggregate are dry, there are gaps between particles. These voids fill during mixing and compaction,
                      requiring approximately 54% more dry materials than the final wet volume.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How much wastage should I include?</h4>
                    <p className="text-muted-foreground text-sm">
                      A typical wastage allowance is 5-10% for aggregate, depending on site conditions, handling practices,
                      and project complexity. This accounts for spillage during transportation, loading/unloading, and
                      material stuck to equipment.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What size aggregate should I use?</h4>
                    <p className="text-muted-foreground text-sm">
                      Aggregate size depends on the application. For general concrete work, 20mm aggregate is common. For
                      mass concrete (foundations, dams), 40mm aggregate works well. For thin sections or heavily reinforced
                      elements, use 10mm aggregate to ensure proper compaction around reinforcement.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50/50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  <strong className="text-foreground">Disclaimer:</strong> Aggregate density and dry volume factor may vary
                  depending on material type, source, moisture content, and compaction method. Results provided by this
                  calculator are approximate and intended for estimation purposes only. Always consult with structural
                  engineers and follow local building codes for accurate material requirements in construction projects.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
