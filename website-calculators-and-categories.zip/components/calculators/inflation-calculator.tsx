"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingDown,
  Info,
  AlertTriangle,
  DollarSign,
  ArrowUpDown,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationType = "future" | "past"

interface InflationResult {
  adjustedAmount: number
  inflationImpact: number
  percentageChange: number
  originalAmount: number
  years: number
  rate: number
  type: CalculationType
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
]

export function InflationCalculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>("future")
  const [amount, setAmount] = useState("")
  const [inflationRate, setInflationRate] = useState("")
  const [years, setYears] = useState("")
  const [currency, setCurrency] = useState("USD")
  const [result, setResult] = useState<InflationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const currencySymbol = currencies.find((c) => c.code === currency)?.symbol || "$"

  const formatCurrency = (value: number): string => {
    if (currency === "INR") {
      if (value >= 10000000) return `${currencySymbol}${(value / 10000000).toFixed(2)} Cr`
      if (value >= 100000) return `${currencySymbol}${(value / 100000).toFixed(2)} L`
      return `${currencySymbol}${value.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`
    }
    if (value >= 1000000000) return `${currencySymbol}${(value / 1000000000).toFixed(2)}B`
    if (value >= 1000000) return `${currencySymbol}${(value / 1000000).toFixed(2)}M`
    if (value >= 1000) return `${currencySymbol}${(value / 1000).toFixed(2)}K`
    return `${currencySymbol}${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`
  }

  const calculateInflation = () => {
    setError("")
    setResult(null)

    const amountNum = Number.parseFloat(amount)
    const rateNum = Number.parseFloat(inflationRate)
    const yearsNum = Number.parseFloat(years)

    if (isNaN(amountNum) || amountNum <= 0) {
      setError("Please enter a valid amount greater than 0")
      return
    }

    if (isNaN(rateNum) || rateNum < 0) {
      setError("Please enter a valid inflation rate (0 or greater)")
      return
    }

    if (isNaN(yearsNum) || yearsNum <= 0) {
      setError("Please enter a valid time period greater than 0")
      return
    }

    let adjustedAmount: number
    let inflationImpact: number
    let percentageChange: number

    if (calculationType === "future") {
      // Future Value: FV = P × (1 + i)^n
      adjustedAmount = amountNum * Math.pow(1 + rateNum / 100, yearsNum)
      inflationImpact = adjustedAmount - amountNum
      percentageChange = ((adjustedAmount - amountNum) / amountNum) * 100
    } else {
      // Past Value: PV = FV ÷ (1 + i)^n
      adjustedAmount = amountNum / Math.pow(1 + rateNum / 100, yearsNum)
      inflationImpact = amountNum - adjustedAmount
      percentageChange = ((amountNum - adjustedAmount) / amountNum) * 100
    }

    setResult({
      adjustedAmount,
      inflationImpact,
      percentageChange,
      originalAmount: amountNum,
      years: yearsNum,
      rate: rateNum,
      type: calculationType,
    })
  }

  const handleReset = () => {
    setAmount("")
    setInflationRate("")
    setYears("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        calculationType === "future"
          ? `${currencySymbol}${result.originalAmount.toLocaleString()} today will be worth ${formatCurrency(result.adjustedAmount)} in ${result.years} years at ${result.rate}% annual inflation.`
          : `${currencySymbol}${result.originalAmount.toLocaleString()} was worth ${formatCurrency(result.adjustedAmount)} ${result.years} years ago at ${result.rate}% annual inflation.`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text =
          calculationType === "future"
            ? `${currencySymbol}${result.originalAmount.toLocaleString()} today will be worth ${formatCurrency(result.adjustedAmount)} in ${result.years} years at ${result.rate}% annual inflation.`
            : `${currencySymbol}${result.originalAmount.toLocaleString()} was worth ${formatCurrency(result.adjustedAmount)} ${result.years} years ago at ${result.rate}% annual inflation.`
        await navigator.share({
          title: "Inflation Calculator Result",
          text: text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleCalculationType = () => {
    setCalculationType((prev) => (prev === "future" ? "past" : "future"))
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingDown className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Inflation Calculator</CardTitle>
                    <CardDescription>Calculate purchasing power over time</CardDescription>
                  </div>
                </div>

                {/* Calculation Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Type</span>
                  <button
                    onClick={toggleCalculationType}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        calculationType === "past" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        calculationType === "future" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Future
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        calculationType === "past" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Past
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Currency Selector */}
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <select
                    id="currency"
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                  >
                    {currencies.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.symbol}) - {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Amount Input */}
                <div className="space-y-2">
                  <Label htmlFor="amount">
                    {calculationType === "future" ? "Current Amount" : "Amount to Adjust"} ({currencySymbol})
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder={`Enter amount in ${currency}`}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Inflation Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="inflationRate">Annual Inflation Rate (%)</Label>
                  <Input
                    id="inflationRate"
                    type="number"
                    placeholder="Enter annual inflation rate (e.g., 3.5)"
                    value={inflationRate}
                    onChange={(e) => setInflationRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Time Period Input */}
                <div className="space-y-2">
                  <Label htmlFor="years">Time Period (Years)</Label>
                  <Input
                    id="years"
                    type="number"
                    placeholder="Enter number of years"
                    value={years}
                    onChange={(e) => setYears(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateInflation} className="w-full" size="lg">
                  Calculate {calculationType === "future" ? "Future" : "Past"} Value
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {calculationType === "future" ? "Future Value" : "Past Value"}
                      </p>
                      <p className="text-4xl sm:text-5xl font-bold text-green-600 mb-2">
                        {formatCurrency(result.adjustedAmount)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {calculationType === "future"
                          ? `What ${currencySymbol}${result.originalAmount.toLocaleString()} will be worth in ${result.years} years`
                          : `What ${currencySymbol}${result.originalAmount.toLocaleString()} was worth ${result.years} years ago`}
                      </p>
                    </div>

                    {/* Breakdown */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Inflation Impact</p>
                        <p className="text-lg font-bold text-orange-600">
                          {calculationType === "future" ? "+" : "-"}
                          {formatCurrency(Math.abs(result.inflationImpact))}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Purchasing Power Change</p>
                        <p className="text-lg font-bold text-red-600">
                          {calculationType === "future" ? "-" : "+"}
                          {result.percentageChange.toFixed(1)}%
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex items-center gap-2 mb-1">
                        <ArrowUpDown className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-blue-700">Future Value</span>
                      </div>
                      <p className="text-sm text-blue-600">
                        Shows how much money you'll need in the future to have the same purchasing power as today.
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex items-center gap-2 mb-1">
                        <ArrowUpDown className="h-4 w-4 text-purple-600" />
                        <span className="font-medium text-purple-700">Past Value</span>
                      </div>
                      <p className="text-sm text-purple-600">
                        Shows what today's money was worth in the past, accounting for cumulative inflation.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas Used</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Future Value:</p>
                    <p>FV = P × (1 + i)ⁿ</p>
                    <p className="font-semibold text-foreground mt-3">Past Value:</p>
                    <p>PV = FV ÷ (1 + i)ⁿ</p>
                  </div>
                  <p className="text-xs">Where: P = Principal, i = Inflation rate (decimal), n = Number of years</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Historical Inflation Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center p-2 bg-muted rounded">
                      <span>United States (avg)</span>
                      <span className="font-medium">~3.0%</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded">
                      <span>European Union (avg)</span>
                      <span className="font-medium">~2.0%</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded">
                      <span>India (avg)</span>
                      <span className="font-medium">~5.5%</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded">
                      <span>Japan (avg)</span>
                      <span className="font-medium">~1.0%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Inflation rates are estimates; actual purchasing power may vary based on economic conditions,
                        geographic location, and specific goods or services.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Inflation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Inflation is the rate at which the general level of prices for goods and services rises over time,
                  leading to a decrease in the purchasing power of money. When inflation occurs, each unit of currency
                  buys fewer goods and services than it did before. This economic phenomenon affects everyone, from
                  individual consumers to large corporations and governments. Understanding inflation is crucial for
                  making informed financial decisions, whether you're saving for retirement, planning major purchases,
                  or managing investments.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Central banks around the world, such as the Federal Reserve in the United States, the European Central
                  Bank, and the Reserve Bank of India, monitor and attempt to control inflation through monetary policy.
                  They typically target a moderate level of inflation, usually around 2% annually for developed
                  economies, as this is considered healthy for economic growth. However, inflation rates can vary
                  significantly based on economic conditions, supply chain disruptions, government policies, and global
                  events.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Purchasing Power</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Purchasing power refers to the quantity of goods and services that can be purchased with a unit of
                  currency. As inflation rises, purchasing power decreases because the same amount of money buys fewer
                  items. For example, if annual inflation is 3%, something that costs $100 today would cost
                  approximately $103 next year. Over longer periods, this effect compounds dramatically. An item costing
                  $100 in 2000 would cost over $170 in 2023, assuming an average annual inflation rate of 2.5%.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This erosion of purchasing power is why simply saving money without investing it often results in a
                  net loss of value over time. To maintain or grow your wealth, your savings and investments need to
                  generate returns that at least match the inflation rate. This concept is fundamental to retirement
                  planning, where you need to ensure your savings will provide adequate purchasing power decades into
                  the future.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Inflation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Economists categorize inflation into several types based on its severity and causes. Creeping
                  inflation, typically between 1-3% annually, is considered normal and even healthy for an economy.
                  Walking inflation, ranging from 3-10%, starts to impact economic planning and can erode savings.
                  Galloping inflation, exceeding 10% annually, severely disrupts economic activity and discourages
                  saving. Hyperinflation, where prices can double within days or weeks, leads to economic collapse and
                  requires drastic measures to control.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Inflation can also be categorized by its causes: demand-pull inflation occurs when demand exceeds
                  supply; cost-push inflation happens when production costs increase; and built-in inflation results
                  from the expectation of future price increases leading to higher wages and prices in a
                  self-perpetuating cycle. Understanding these types helps individuals and businesses anticipate
                  economic trends and make informed financial decisions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ArrowUpDown className="h-5 w-5 text-primary" />
                  <CardTitle>Protecting Against Inflation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  There are several strategies individuals can use to protect their wealth against inflation. Investing
                  in assets that historically outpace inflation, such as stocks, real estate, and commodities, can help
                  maintain purchasing power. Treasury Inflation-Protected Securities (TIPS) in the United States and
                  similar instruments in other countries provide returns that adjust with inflation. Diversifying
                  investments across different asset classes and geographic regions can also provide protection against
                  inflation in any single economy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For retirement planning, it's essential to factor in inflation when calculating how much you'll need
                  to save. A common mistake is to plan based on today's prices without accounting for the fact that
                  costs will be significantly higher in 20, 30, or 40 years. Using an inflation calculator like this one
                  helps you understand the true future cost of your goals and ensures you're saving enough to maintain
                  your desired lifestyle in retirement.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
