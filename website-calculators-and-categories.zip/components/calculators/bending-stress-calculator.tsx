"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Ruler, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type InputMode = "direct" | "dimensions"
type CrossSection = "rectangular" | "circular" | "hollow-circular" | "i-beam"
type MomentUnit = "Nm" | "kNm" | "lb-ft" | "lb-in"
type LengthUnit = "m" | "cm" | "mm" | "in" | "ft"
type StressUnit = "Pa" | "kPa" | "MPa" | "GPa" | "psi" | "ksi"

interface BendingStressResult {
  stress: number
  stressUnit: string
  sectionModulus: number
  category: string
  color: string
  bgColor: string
}

export function BendingStressCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("direct")
  const [crossSection, setCrossSection] = useState<CrossSection>("rectangular")
  const [moment, setMoment] = useState("")
  const [momentUnit, setMomentUnit] = useState<MomentUnit>("Nm")
  const [sectionModulus, setSectionModulus] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [diameter, setDiameter] = useState("")
  const [innerDiameter, setInnerDiameter] = useState("")
  const [flangeWidth, setFlangeWidth] = useState("")
  const [flangeThickness, setFlangeThickness] = useState("")
  const [webHeight, setWebHeight] = useState("")
  const [webThickness, setWebThickness] = useState("")
  const [lengthUnit, setLengthUnit] = useState<LengthUnit>("mm")
  const [stressUnit, setStressUnit] = useState<StressUnit>("MPa")
  const [result, setResult] = useState<BendingStressResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const convertMomentToNm = (value: number, unit: MomentUnit): number => {
    switch (unit) {
      case "Nm":
        return value
      case "kNm":
        return value * 1000
      case "lb-ft":
        return value * 1.35582
      case "lb-in":
        return value * 0.112985
      default:
        return value
    }
  }

  const convertLengthToM = (value: number, unit: LengthUnit): number => {
    switch (unit) {
      case "m":
        return value
      case "cm":
        return value / 100
      case "mm":
        return value / 1000
      case "in":
        return value * 0.0254
      case "ft":
        return value * 0.3048
      default:
        return value
    }
  }

  const convertStressFromPa = (value: number, unit: StressUnit): number => {
    switch (unit) {
      case "Pa":
        return value
      case "kPa":
        return value / 1000
      case "MPa":
        return value / 1e6
      case "GPa":
        return value / 1e9
      case "psi":
        return value / 6894.76
      case "ksi":
        return value / 6894760
      default:
        return value
    }
  }

  const calculateSectionModulus = (): number | null => {
    if (inputMode === "direct") {
      const S = Number.parseFloat(sectionModulus)
      if (isNaN(S) || S <= 0) return null
      // Convert to m³
      const lengthFactor = convertLengthToM(1, lengthUnit)
      return S * Math.pow(lengthFactor, 3)
    }

    switch (crossSection) {
      case "rectangular": {
        const b = Number.parseFloat(width)
        const h = Number.parseFloat(height)
        if (isNaN(b) || isNaN(h) || b <= 0 || h <= 0) return null
        const bM = convertLengthToM(b, lengthUnit)
        const hM = convertLengthToM(h, lengthUnit)
        return (bM * hM * hM) / 6
      }
      case "circular": {
        const d = Number.parseFloat(diameter)
        if (isNaN(d) || d <= 0) return null
        const dM = convertLengthToM(d, lengthUnit)
        return (Math.PI * Math.pow(dM, 3)) / 32
      }
      case "hollow-circular": {
        const dOuter = Number.parseFloat(diameter)
        const dInner = Number.parseFloat(innerDiameter)
        if (isNaN(dOuter) || isNaN(dInner) || dOuter <= 0 || dInner <= 0 || dInner >= dOuter) return null
        const dOuterM = convertLengthToM(dOuter, lengthUnit)
        const dInnerM = convertLengthToM(dInner, lengthUnit)
        return (Math.PI * (Math.pow(dOuterM, 4) - Math.pow(dInnerM, 4))) / (32 * dOuterM)
      }
      case "i-beam": {
        const bf = Number.parseFloat(flangeWidth)
        const tf = Number.parseFloat(flangeThickness)
        const hw = Number.parseFloat(webHeight)
        const tw = Number.parseFloat(webThickness)
        if (isNaN(bf) || isNaN(tf) || isNaN(hw) || isNaN(tw) || bf <= 0 || tf <= 0 || hw <= 0 || tw <= 0) return null
        const bfM = convertLengthToM(bf, lengthUnit)
        const tfM = convertLengthToM(tf, lengthUnit)
        const hwM = convertLengthToM(hw, lengthUnit)
        const twM = convertLengthToM(tw, lengthUnit)
        const H = hwM + 2 * tfM
        const I = (bfM * Math.pow(H, 3) - (bfM - twM) * Math.pow(hwM, 3)) / 12
        return I / (H / 2)
      }
      default:
        return null
    }
  }

  const calculateBendingStress = () => {
    setError("")
    setResult(null)

    const M = Number.parseFloat(moment)
    if (isNaN(M) || M <= 0) {
      setError("Please enter a valid bending moment greater than 0")
      return
    }

    const S = calculateSectionModulus()
    if (S === null || S <= 0) {
      setError("Please enter valid dimensions for section modulus calculation")
      return
    }

    const momentNm = convertMomentToNm(M, momentUnit)
    const stressPa = momentNm / S
    const stressConverted = convertStressFromPa(stressPa, stressUnit)

    let category: string
    let color: string
    let bgColor: string

    const stressMPa = stressPa / 1e6
    if (stressMPa < 50) {
      category = "Low Stress"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (stressMPa < 150) {
      category = "Moderate Stress"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (stressMPa < 300) {
      category = "High Stress"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Stress"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      stress: stressConverted,
      stressUnit,
      sectionModulus: S,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setMoment("")
    setSectionModulus("")
    setWidth("")
    setHeight("")
    setDiameter("")
    setInnerDiameter("")
    setFlangeWidth("")
    setFlangeThickness("")
    setWebHeight("")
    setWebThickness("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Bending Stress: ${result.stress.toExponential(4)} ${result.stressUnit} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Bending Stress Result",
          text: `Bending Stress: ${result.stress.toExponential(4)} ${result.stressUnit} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1e6 || Math.abs(num) < 1e-3) {
      return num.toExponential(4)
    }
    return num.toFixed(4)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Ruler className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Bending Stress Calculator</CardTitle>
                    <CardDescription>Calculate bending stress in beams</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={() => {
                      setInputMode(inputMode === "direct" ? "dimensions" : "direct")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "dimensions" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "direct" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Direct S
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "dimensions" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Dimensions
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Bending Moment Input */}
                <div className="space-y-2">
                  <Label htmlFor="moment">Bending Moment (M)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="moment"
                      type="number"
                      placeholder="Enter bending moment"
                      value={moment}
                      onChange={(e) => setMoment(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={momentUnit} onValueChange={(v) => setMomentUnit(v as MomentUnit)}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Nm">N·m</SelectItem>
                        <SelectItem value="kNm">kN·m</SelectItem>
                        <SelectItem value="lb-ft">lb·ft</SelectItem>
                        <SelectItem value="lb-in">lb·in</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {inputMode === "direct" ? (
                  /* Direct Section Modulus Input */
                  <div className="space-y-2">
                    <Label htmlFor="sectionModulus">Section Modulus (S)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="sectionModulus"
                        type="number"
                        placeholder="Enter section modulus"
                        value={sectionModulus}
                        onChange={(e) => setSectionModulus(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={lengthUnit} onValueChange={(v) => setLengthUnit(v as LengthUnit)}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="m">m³</SelectItem>
                          <SelectItem value="cm">cm³</SelectItem>
                          <SelectItem value="mm">mm³</SelectItem>
                          <SelectItem value="in">in³</SelectItem>
                          <SelectItem value="ft">ft³</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ) : (
                  /* Dimensions Input */
                  <>
                    <div className="space-y-2">
                      <Label>Cross-Section Type</Label>
                      <Select value={crossSection} onValueChange={(v) => setCrossSection(v as CrossSection)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="rectangular">Rectangular</SelectItem>
                          <SelectItem value="circular">Solid Circular</SelectItem>
                          <SelectItem value="hollow-circular">Hollow Circular</SelectItem>
                          <SelectItem value="i-beam">I-Beam</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Dimension Unit</Label>
                      <Select value={lengthUnit} onValueChange={(v) => setLengthUnit(v as LengthUnit)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="m">Meters (m)</SelectItem>
                          <SelectItem value="cm">Centimeters (cm)</SelectItem>
                          <SelectItem value="mm">Millimeters (mm)</SelectItem>
                          <SelectItem value="in">Inches (in)</SelectItem>
                          <SelectItem value="ft">Feet (ft)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {crossSection === "rectangular" && (
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor="width">Width (b)</Label>
                          <Input
                            id="width"
                            type="number"
                            placeholder="Width"
                            value={width}
                            onChange={(e) => setWidth(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="height">Height (h)</Label>
                          <Input
                            id="height"
                            type="number"
                            placeholder="Height"
                            value={height}
                            onChange={(e) => setHeight(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                      </div>
                    )}

                    {crossSection === "circular" && (
                      <div className="space-y-2">
                        <Label htmlFor="diameter">Diameter (d)</Label>
                        <Input
                          id="diameter"
                          type="number"
                          placeholder="Diameter"
                          value={diameter}
                          onChange={(e) => setDiameter(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                    )}

                    {crossSection === "hollow-circular" && (
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor="outerDiameter">Outer Diameter</Label>
                          <Input
                            id="outerDiameter"
                            type="number"
                            placeholder="Outer d"
                            value={diameter}
                            onChange={(e) => setDiameter(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="innerDiameter">Inner Diameter</Label>
                          <Input
                            id="innerDiameter"
                            type="number"
                            placeholder="Inner d"
                            value={innerDiameter}
                            onChange={(e) => setInnerDiameter(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                      </div>
                    )}

                    {crossSection === "i-beam" && (
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor="flangeWidth">Flange Width</Label>
                          <Input
                            id="flangeWidth"
                            type="number"
                            placeholder="bf"
                            value={flangeWidth}
                            onChange={(e) => setFlangeWidth(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="flangeThickness">Flange Thickness</Label>
                          <Input
                            id="flangeThickness"
                            type="number"
                            placeholder="tf"
                            value={flangeThickness}
                            onChange={(e) => setFlangeThickness(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="webHeight">Web Height</Label>
                          <Input
                            id="webHeight"
                            type="number"
                            placeholder="hw"
                            value={webHeight}
                            onChange={(e) => setWebHeight(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="webThickness">Web Thickness</Label>
                          <Input
                            id="webThickness"
                            type="number"
                            placeholder="tw"
                            value={webThickness}
                            onChange={(e) => setWebThickness(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* Output Stress Unit */}
                <div className="space-y-2">
                  <Label>Stress Output Unit</Label>
                  <Select value={stressUnit} onValueChange={(v) => setStressUnit(v as StressUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pa">Pascal (Pa)</SelectItem>
                      <SelectItem value="kPa">Kilopascal (kPa)</SelectItem>
                      <SelectItem value="MPa">Megapascal (MPa)</SelectItem>
                      <SelectItem value="GPa">Gigapascal (GPa)</SelectItem>
                      <SelectItem value="psi">PSI (psi)</SelectItem>
                      <SelectItem value="ksi">KSI (ksi)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBendingStress} className="w-full" size="lg">
                  Calculate Bending Stress
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Bending Stress (σ)</p>
                      <p className={`text-3xl font-bold ${result.color} mb-1`}>
                        {formatNumber(result.stress)} {result.stressUnit}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Show Steps Toggle */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-1">
                        <p>
                          <strong>Step 1:</strong> Bending Moment M = {moment} {momentUnit}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Section Modulus S = {formatNumber(result.sectionModulus)} m³
                        </p>
                        <p>
                          <strong>Step 3:</strong> σ = M / S = {formatNumber(result.stress)} {result.stressUnit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bending Stress Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-lg">σ = M / S</p>
                  </div>
                  <p>Where:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>
                      <strong>σ</strong> = Bending stress
                    </li>
                    <li>
                      <strong>M</strong> = Bending moment
                    </li>
                    <li>
                      <strong>S</strong> = Section modulus
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Section Modulus Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Rectangular</span>
                      <span className="text-blue-600 font-mono">S = bh²/6</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Solid Circular</span>
                      <span className="text-green-600 font-mono">S = πd³/32</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Hollow Circular</span>
                      <span className="text-yellow-600 font-mono text-xs">S = π(D⁴-d⁴)/(32D)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-600" />
                    <CardTitle className="text-lg">Disclaimer</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    Bending stress calculations are estimates based on ideal assumptions. Actual stress may vary due to
                    material defects, load distribution, and boundary conditions. Consult engineering references for
                    precise analysis.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Bending Stress?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bending stress is the internal stress induced in a material when an external bending moment is
                  applied. When a beam is subjected to a bending load, it experiences compressive stress on one side and
                  tensile stress on the other. The maximum stress occurs at the outer fibers of the beam, farthest from
                  the neutral axis.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding bending stress is crucial in structural engineering for designing beams, shafts, and
                  other structural members. Engineers must ensure that the maximum bending stress in a member does not
                  exceed the material's allowable stress to prevent failure.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Section Modulus Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The section modulus (S) is a geometric property of a cross-section that relates the bending moment to
                  the maximum bending stress. It is defined as the ratio of the second moment of area (moment of
                  inertia) to the distance from the neutral axis to the outermost fiber: S = I/c.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A larger section modulus indicates a more efficient cross-section for resisting bending. This is why
                  I-beams and other optimized shapes are commonly used in construction - they maximize the section
                  modulus while minimizing material usage.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
