"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Baby, Info, Calendar, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMode = "lmp" | "conception"

interface GestationalAgeResult {
  weeks: number
  days: number
  totalDays: number
  dueDate: string
}

export function GestationalAgeCalculator() {
  const [mode, setMode] = useState<CalculationMode>("lmp")
  const [lmpDate, setLmpDate] = useState("")
  const [conceptionDate, setConceptionDate] = useState("")
  const [currentDate, setCurrentDate] = useState(new Date().toISOString().split("T")[0])
  const [cycleLength, setCycleLength] = useState("28")
  const [result, setResult] = useState<GestationalAgeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateGestationalAge = () => {
    setError("")
    setResult(null)

    const current = new Date(currentDate)
    let referenceDate: Date

    if (mode === "lmp") {
      if (!lmpDate) {
        setError("Please enter the last menstrual period date")
        return
      }
      referenceDate = new Date(lmpDate)
      
      // Adjust for cycle length if not 28 days
      const cycleLengthNum = Number.parseInt(cycleLength) || 28
      if (cycleLengthNum !== 28) {
        const adjustment = cycleLengthNum - 28
        referenceDate.setDate(referenceDate.getDate() - adjustment)
      }
    } else {
      if (!conceptionDate) {
        setError("Please enter the conception date")
        return
      }
      referenceDate = new Date(conceptionDate)
      // Add 2 weeks to conception date to get equivalent LMP
      referenceDate.setDate(referenceDate.getDate() - 14)
    }

    if (referenceDate > current) {
      setError("Reference date cannot be in the future")
      return
    }

    // Calculate difference in days
    const diffTime = current.getTime() - referenceDate.getTime()
    const totalDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))

    if (totalDays > 300) {
      setError("Gestational age exceeds normal pregnancy duration")
      return
    }

    const weeks = Math.floor(totalDays / 7)
    const days = totalDays % 7

    // Calculate due date (280 days / 40 weeks from LMP)
    const dueDateTime = referenceDate.getTime() + 280 * 24 * 60 * 60 * 1000
    const dueDateObj = new Date(dueDateTime)
    const dueDate = dueDateObj.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    setResult({ weeks, days, totalDays, dueDate })
  }

  const handleReset = () => {
    setLmpDate("")
    setConceptionDate("")
    setCurrentDate(new Date().toISOString().split("T")[0])
    setCycleLength("28")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Gestational Age: ${result.weeks} weeks ${result.days} days\nEstimated Due Date: ${result.dueDate}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Gestational Age Calculation",
          text: `Gestational Age: ${result.weeks} weeks ${result.days} days. Estimated Due Date: ${result.dueDate}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Baby className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gestational Age Calculator</CardTitle>
                    <CardDescription>Calculate pregnancy gestational age</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Mode</span>
                  <button
                    onClick={() => setMode(mode === "lmp" ? "conception" : "lmp")}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "conception" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "lmp" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      LMP
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "conception" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Conception
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Reference Date Input */}
                {mode === "lmp" ? (
                  <div className="space-y-2">
                    <Label htmlFor="lmp">Last Menstrual Period (LMP)</Label>
                    <Input
                      id="lmp"
                      type="date"
                      value={lmpDate}
                      onChange={(e) => setLmpDate(e.target.value)}
                      max={new Date().toISOString().split("T")[0]}
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="conception">Conception Date</Label>
                    <Input
                      id="conception"
                      type="date"
                      value={conceptionDate}
                      onChange={(e) => setConceptionDate(e.target.value)}
                      max={new Date().toISOString().split("T")[0]}
                    />
                  </div>
                )}

                {/* Cycle Length (only for LMP mode) */}
                {mode === "lmp" && (
                  <div className="space-y-2">
                    <Label htmlFor="cycle">Average Cycle Length (days)</Label>
                    <Input
                      id="cycle"
                      type="number"
                      value={cycleLength}
                      onChange={(e) => setCycleLength(e.target.value)}
                      min="21"
                      max="35"
                      placeholder="28"
                    />
                  </div>
                )}

                {/* Current Date */}
                <div className="space-y-2">
                  <Label htmlFor="current">Current Date</Label>
                  <Input
                    id="current"
                    type="date"
                    value={currentDate}
                    onChange={(e) => setCurrentDate(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateGestationalAge} className="w-full" size="lg">
                  Calculate Gestational Age
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-2">Gestational Age</p>
                      <p className="text-4xl font-bold text-cyan-600 mb-1">
                        {result.weeks} weeks {result.days} days
                      </p>
                      <p className="text-sm text-cyan-700 mb-3">({result.totalDays} days total)</p>
                      <div className="p-3 bg-white rounded-lg border border-cyan-200 mb-3">
                        <p className="text-xs text-muted-foreground mb-1">Estimated Due Date</p>
                        <p className="text-sm font-semibold text-cyan-700">{result.dueDate}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Disclaimer */}
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-xs text-amber-800">
                    <strong>Disclaimer:</strong> Gestational age calculations are estimates based on entered dates.
                    Consult a healthcare provider for accurate pregnancy assessment.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pregnancy Trimesters</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-700">First Trimester</div>
                      <div className="text-sm text-cyan-600">Weeks 1-12</div>
                    </div>
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-700">Second Trimester</div>
                      <div className="text-sm text-cyan-600">Weeks 13-26</div>
                    </div>
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-700">Third Trimester</div>
                      <div className="text-sm text-cyan-600">Weeks 27-40</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Methods</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div>
                    <strong className="text-foreground">LMP Method:</strong>
                    <p className="mt-1">Calculates from the first day of your last menstrual period, the most common method.</p>
                  </div>
                  <div>
                    <strong className="text-foreground">Conception Date:</strong>
                    <p className="mt-1">Uses the estimated conception date, typically 2 weeks after LMP.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Gestational Age */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Gestational Age?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gestational age refers to the age of a pregnancy, typically measured from the first day of the last
                  menstrual period (LMP). This dating method is used universally in prenatal care because it provides a
                  standardized way to track pregnancy development and estimate the due date. Although conception usually
                  occurs about two weeks after the LMP, using the LMP date simplifies calculations and aligns with
                  standard medical practice.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Healthcare providers use gestational age to monitor fetal development, schedule prenatal tests and
                  ultrasounds, determine when certain interventions might be necessary, and predict the expected delivery
                  date. Accurate gestational age assessment is crucial for proper prenatal care and identifying any
                  potential complications early in pregnancy.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Gestational Age</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The most common method to calculate gestational age is using Naegele's Rule, which estimates the due
                  date by adding 280 days (40 weeks) to the first day of the last menstrual period. To find the current
                  gestational age, simply calculate the time elapsed from the LMP to the current date. The result is
                  typically expressed in weeks and days, such as "12 weeks 3 days."
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  If you know the conception date instead of the LMP, you can calculate gestational age by adding 14 days
                  to the conception date to get the equivalent LMP date, then proceed with the standard calculation. Some
                  women have irregular cycles, so adjustments may be made based on cycle length. Ultrasound measurements,
                  particularly in the first trimester, can also provide accurate gestational age estimates that may be
                  used to refine calculations.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Baby className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Why is gestational age measured from LMP?</h4>
                    <p className="text-muted-foreground text-sm">
                      Most women know when their last period started, but not the exact date of conception. Using the LMP
                      provides a consistent reference point that's easy to determine and standardizes pregnancy dating
                      across different healthcare settings.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      What if my cycle is not 28 days?
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      If your average cycle length differs from 28 days, the calculator can adjust accordingly. Longer
                      cycles may push back ovulation and conception, while shorter cycles may advance them. First-trimester
                      ultrasounds provide the most accurate dating regardless of cycle irregularity.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      How accurate is the due date?
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      Only about 5% of babies are born on their exact due date. Most babies arrive within two weeks before
                      or after the estimated due date. The due date serves as a guideline for monitoring pregnancy
                      progress rather than a precise prediction of delivery.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
