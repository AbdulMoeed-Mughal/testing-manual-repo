"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, BatteryCharging, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ChargingResult {
  hours: number
  minutes: number
  totalHours: number
  energyRequired: number
}

export function BatteryChargingTimeCalculator() {
  const [capacity, setCapacity] = useState("")
  const [capacityUnit, setCapacityUnit] = useState<"Ah" | "mAh">("mAh")
  const [chargingCurrent, setChargingCurrent] = useState("")
  const [currentUnit, setCurrentUnit] = useState<"A" | "mA">("mA")
  const [voltage, setVoltage] = useState("")
  const [efficiency, setEfficiency] = useState("85")
  const [currentCharge, setCurrentCharge] = useState("0")
  const [result, setResult] = useState<ChargingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const capacityNum = Number.parseFloat(capacity)
    const currentNum = Number.parseFloat(chargingCurrent)
    const efficiencyNum = Number.parseFloat(efficiency) / 100
    const currentChargeNum = Number.parseFloat(currentCharge) / 100
    const voltageNum = Number.parseFloat(voltage)

    if (isNaN(capacityNum) || capacityNum <= 0) {
      setError("Please enter a valid battery capacity greater than 0")
      return
    }

    if (isNaN(currentNum) || currentNum <= 0) {
      setError("Please enter a valid charging current greater than 0")
      return
    }

    if (isNaN(efficiencyNum) || efficiencyNum <= 0 || efficiencyNum > 1) {
      setError("Please enter a valid efficiency between 1 and 100%")
      return
    }

    if (isNaN(currentChargeNum) || currentChargeNum < 0 || currentChargeNum >= 1) {
      setError("Please enter a valid current charge between 0 and 99%")
      return
    }

    // Convert to Ah
    const capacityAh = capacityUnit === "mAh" ? capacityNum / 1000 : capacityNum
    const chargingCurrentA = currentUnit === "mA" ? currentNum / 1000 : currentNum

    // Calculate remaining capacity to charge
    const remainingCapacity = capacityAh * (1 - currentChargeNum)

    // Charging time formula: Time = (Capacity / Current) × (1 / Efficiency)
    const chargingTimeHours = (remainingCapacity / chargingCurrentA) * (1 / efficiencyNum)
    const hours = Math.floor(chargingTimeHours)
    const minutes = Math.round((chargingTimeHours - hours) * 60)

    // Energy required
    const energyRequired = !isNaN(voltageNum) && voltageNum > 0 ? (remainingCapacity * voltageNum) / efficiencyNum : 0

    setResult({
      hours,
      minutes,
      totalHours: chargingTimeHours,
      energyRequired,
    })
  }

  const handleReset = () => {
    setCapacity("")
    setChargingCurrent("")
    setVoltage("")
    setEfficiency("85")
    setCurrentCharge("0")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Charging Time: ${result.hours}h ${result.minutes}m (${result.totalHours.toFixed(2)} hours)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Battery Charging Time Result",
          text: `Estimated charging time: ${result.hours}h ${result.minutes}m`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <BatteryCharging className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Battery Charging Time Calculator</CardTitle>
                    <CardDescription>Estimate time to fully charge a battery</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Battery Capacity */}
                <div className="space-y-2">
                  <Label>Battery Capacity</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-2">
                      <Input
                        type="number"
                        placeholder="Enter capacity"
                        value={capacity}
                        onChange={(e) => setCapacity(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <Select value={capacityUnit} onValueChange={(v) => setCapacityUnit(v as "Ah" | "mAh")}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mAh">mAh</SelectItem>
                        <SelectItem value="Ah">Ah</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Charging Current */}
                <div className="space-y-2">
                  <Label>Charging Current</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-2">
                      <Input
                        type="number"
                        placeholder="Enter charging current"
                        value={chargingCurrent}
                        onChange={(e) => setChargingCurrent(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <Select value={currentUnit} onValueChange={(v) => setCurrentUnit(v as "A" | "mA")}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mA">mA</SelectItem>
                        <SelectItem value="A">A</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Battery Voltage (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="voltage">Battery Voltage (V) - Optional</Label>
                  <Input
                    id="voltage"
                    type="number"
                    placeholder="e.g., 3.7, 12"
                    value={voltage}
                    onChange={(e) => setVoltage(e.target.value)}
                    min="0"
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">For energy calculation</p>
                </div>

                {/* Current Charge Level */}
                <div className="space-y-2">
                  <Label htmlFor="currentCharge">Current Charge Level (%)</Label>
                  <Input
                    id="currentCharge"
                    type="number"
                    placeholder="e.g., 0, 20, 50"
                    value={currentCharge}
                    onChange={(e) => setCurrentCharge(e.target.value)}
                    min="0"
                    max="99"
                    step="1"
                  />
                </div>

                {/* Charging Efficiency */}
                <div className="space-y-2">
                  <Label htmlFor="efficiency">Charging Efficiency (%)</Label>
                  <Input
                    id="efficiency"
                    type="number"
                    placeholder="e.g., 85"
                    value={efficiency}
                    onChange={(e) => setEfficiency(e.target.value)}
                    min="1"
                    max="100"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">Typical: 80-95% for modern chargers</p>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Charging Time
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-yellow-50 border-yellow-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Charging Time</p>
                      <p className="text-4xl font-bold text-yellow-600 mb-1">
                        {result.hours}h {result.minutes}m
                      </p>
                      <p className="text-sm text-muted-foreground">({result.totalHours.toFixed(2)} hours)</p>
                    </div>

                    {result.energyRequired > 0 && (
                      <div className="mt-4 p-2 bg-white rounded-lg text-center">
                        <p className="text-sm text-muted-foreground">Energy Required</p>
                        <p className="font-semibold">{result.energyRequired.toFixed(2)} Wh</p>
                      </div>
                    )}

                    {/* Step-by-Step Solution */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-yellow-700 hover:text-yellow-800"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide Steps" : "Show Calculation Steps"}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Calculate remaining capacity to charge
                        </p>
                        <p>
                          <strong>Step 2:</strong> Time = (Remaining Capacity / Charging Current) × (1 / Efficiency)
                        </p>
                        <p>
                          <strong>Step 3:</strong> Convert to hours and minutes
                        </p>
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Charging Time Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Time (h) = (Capacity / Current) × (1 / Efficiency)</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    The efficiency factor accounts for energy lost as heat during charging.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Charging Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Slow Charging (0.1C)</span>
                      <span className="font-mono">10+ hours</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Standard (0.5C)</span>
                      <span className="font-mono">2-3 hours</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Fast Charging (1C)</span>
                      <span className="font-mono">1-1.5 hours</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Rapid Charging (2C+)</span>
                      <span className="font-mono">30-45 min</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    C-rate: 1C means charging current equals battery capacity (e.g., 3000mAh battery at 3A)
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tips for Safe Charging</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Use manufacturer-recommended chargers</li>
                    <li>• Avoid charging in extreme temperatures</li>
                    <li>• Don't leave batteries charging unattended</li>
                    <li>• Stop charging if battery becomes hot</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Battery Charging</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Battery charging time depends on the battery capacity, charging current, and charger efficiency.
                  Modern lithium-ion batteries often use CC-CV (constant current, constant voltage) charging, which
                  slows down as the battery reaches full capacity to protect battery health.
                </p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Battery charging time calculations are estimates. Actual charging time
                  may vary due to charger efficiency, battery condition, temperature, and charging method. Consult
                  manufacturer specifications for precise timing.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
