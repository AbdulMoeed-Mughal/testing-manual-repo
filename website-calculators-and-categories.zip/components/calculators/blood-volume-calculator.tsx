"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Droplets, Info, AlertTriangle, Activity, Heart } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"

interface BloodVolumeResult {
  volumeLiters: number
  volumeML: number
  percentOfWeight: number
  status: string
  color: string
  bgColor: string
}

export function BloodVolumeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [age, setAge] = useState("")
  const [result, setResult] = useState<BloodVolumeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [warning, setWarning] = useState("")

  const calculateBloodVolume = () => {
    setError("")
    setWarning("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    // Validate weight ranges
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum
    if (weightInKg < 20 || weightInKg > 300) {
      setWarning("Weight seems unusual. Results may not be accurate.")
    }

    let heightInMeters: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      if (heightCmNum < 100 || heightCmNum > 250) {
        setWarning("Height seems unusual. Results may not be accurate.")
      }
      heightInMeters = heightCmNum / 100
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInMeters = totalInches * 0.0254
    }

    // Validate age if provided
    const ageNum = age ? Number.parseFloat(age) : null
    if (age && (isNaN(ageNum!) || ageNum! < 0 || ageNum! > 120)) {
      setError("Please enter a valid age between 0 and 120")
      return
    }

    // Nadler formula for blood volume estimation
    // Male: BV = 0.3669 × height(m)³ + 0.03219 × weight(kg) + 0.6041
    // Female: BV = 0.3561 × height(m)³ + 0.03308 × weight(kg) + 0.1833
    const heightCubed = Math.pow(heightInMeters, 3)

    let bloodVolumeLiters: number
    if (gender === "male") {
      bloodVolumeLiters = 0.3669 * heightCubed + 0.03219 * weightInKg + 0.6041
    } else {
      bloodVolumeLiters = 0.3561 * heightCubed + 0.03308 * weightInKg + 0.1833
    }

    const bloodVolumeML = bloodVolumeLiters * 1000
    const percentOfWeight = (bloodVolumeLiters / weightInKg) * 100

    // Determine status based on percentage of body weight
    // Normal range is typically 7-8% of body weight
    let status: string
    let color: string
    let bgColor: string

    if (percentOfWeight >= 6.5 && percentOfWeight <= 8.5) {
      status = "Normal Range"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (percentOfWeight < 6.5) {
      status = "Below Average"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      status = "Above Average"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    }

    setResult({
      volumeLiters: Math.round(bloodVolumeLiters * 100) / 100,
      volumeML: Math.round(bloodVolumeML),
      percentOfWeight: Math.round(percentOfWeight * 10) / 10,
      status,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setAge("")
    setResult(null)
    setError("")
    setWarning("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My estimated blood volume is ${result.volumeLiters} L (${result.volumeML} mL), which is ${result.percentOfWeight}% of my body weight.`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Blood Volume Estimate",
          text: `I calculated my blood volume using CalcHub! My estimated blood volume is ${result.volumeLiters} L (${result.volumeML} mL).`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
    setWarning("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Blood Volume Calculator</CardTitle>
                    <CardDescription>Estimate your total blood volume</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Age Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (optional)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age in years"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="0"
                    max="120"
                  />
                </div>

                {/* Warning Message */}
                {warning && (
                  <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200 text-yellow-700 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {warning}
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBloodVolume} className="w-full" size="lg">
                  Calculate Blood Volume
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Blood Volume</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{result.volumeLiters} L</p>
                      <p className="text-lg text-muted-foreground mb-2">{result.volumeML} mL</p>
                      <p className={`text-base font-semibold ${result.color}`}>{result.status}</p>
                    </div>

                    {/* Additional Info */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">% of Body Weight</span>
                        <span className="font-semibold">{result.percentOfWeight}%</span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Blood Volume Ranges</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Average Adult Male</span>
                      <span className="text-sm text-blue-600">5-6 L</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-pink-50 border border-pink-200">
                      <span className="font-medium text-pink-700">Average Adult Female</span>
                      <span className="text-sm text-pink-600">4-5 L</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">% of Body Weight</span>
                      <span className="text-sm text-green-600">7-8%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Athletes</span>
                      <span className="text-sm text-purple-600">May be higher</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Nadler Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-xs">
                    <p className="font-semibold text-foreground mb-2">Male:</p>
                    <p>BV = 0.3669 × H³ + 0.03219 × W + 0.6041</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-xs">
                    <p className="font-semibold text-foreground mb-2">Female:</p>
                    <p>BV = 0.3561 × H³ + 0.03308 × W + 0.1833</p>
                  </div>
                  <p className="text-xs">Where H = height in meters, W = weight in kg, BV = blood volume in liters</p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-600" />
                    <CardTitle className="text-lg text-amber-800">Medical Disclaimer</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-amber-700">
                    This calculator provides estimates only. Actual blood volume may vary based on individual factors
                    including fitness level, hydration status, and health conditions. Consult a healthcare professional
                    for precise measurement.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Blood Volume */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Blood Volume?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Blood volume refers to the total amount of blood circulating within your body's cardiovascular system
                  at any given time. This vital fluid serves as the body's primary transport system, carrying oxygen
                  from your lungs to your tissues, nutrients from your digestive system to your cells, and waste
                  products to your kidneys and liver for elimination. Understanding your blood volume is important for
                  various medical and athletic applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The average adult human body contains approximately 4.5 to 5.5 liters of blood, though this varies
                  significantly based on body size, gender, and overall health. Blood volume typically represents about
                  7-8% of total body weight. This measurement plays a crucial role in surgical planning, blood
                  transfusion calculations, dialysis treatments, and understanding cardiovascular function. Athletes
                  often have higher blood volumes due to cardiovascular adaptations from training.
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting Blood Volume */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Blood Volume</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence an individual's blood volume beyond just height and weight. Gender plays a
                  significant role, with males typically having about 10-15% more blood volume than females of similar
                  size due to differences in body composition and hormonal influences. Age also affects blood volume,
                  with volumes generally increasing from birth through adulthood and potentially decreasing in elderly
                  individuals.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Physical Fitness</h4>
                    <p className="text-blue-700 text-sm">
                      Endurance athletes can have blood volumes 20-25% higher than sedentary individuals due to plasma
                      volume expansion from training adaptations.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Hydration Status</h4>
                    <p className="text-green-700 text-sm">
                      Dehydration can reduce blood volume significantly, while proper hydration helps maintain optimal
                      cardiovascular function and blood pressure.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Pregnancy</h4>
                    <p className="text-purple-700 text-sm">
                      During pregnancy, blood volume increases by 30-50% to support the growing fetus and prepare for
                      blood loss during delivery.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Altitude</h4>
                    <p className="text-orange-700 text-sm">
                      Living at high altitudes stimulates increased red blood cell production, gradually increasing
                      total blood volume over time.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Medical Importance */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Why Blood Volume Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Knowing your estimated blood volume has several practical applications in both medical and athletic
                  contexts. In medical settings, blood volume calculations are essential for determining appropriate
                  blood transfusion amounts, calculating drug dosages for certain medications, planning surgical
                  procedures, and managing patients with conditions affecting blood volume like hemorrhage, shock, or
                  fluid overload.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For athletes and fitness enthusiasts, understanding blood volume can provide insights into
                  cardiovascular fitness and training adaptations. Endurance training leads to increased plasma volume,
                  which improves the blood's ability to deliver oxygen to working muscles. This adaptation is one reason
                  why VO2 max (maximal oxygen uptake) improves with aerobic training. Monitoring blood volume changes
                  can also help identify overtraining or inadequate recovery.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Blood volume also plays a crucial role in maintaining blood pressure and cardiovascular health. When
                  blood volume drops too low (hypovolemia), blood pressure can fall dangerously low, leading to
                  dizziness, fainting, or in severe cases, shock. Conversely, excessive blood volume (hypervolemia) can
                  strain the heart and lead to high blood pressure, edema, and other cardiovascular complications. This
                  is why conditions affecting fluid balance, such as kidney disease or heart failure, require careful
                  monitoring and management.
                </p>
              </CardContent>
            </Card>

            {/* Blood Composition */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Blood Composition</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Blood is composed of two main components: plasma (the liquid portion) and formed elements (cells and
                  cell fragments). Plasma makes up about 55% of blood volume and consists primarily of water (92%),
                  along with proteins, nutrients, hormones, waste products, and electrolytes. The remaining 45% consists
                  of red blood cells (erythrocytes), white blood cells (leukocytes), and platelets (thrombocytes).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Red blood cells are the most numerous blood cells, with approximately 5 million per microliter in
                  adult males and 4.5 million in adult females. These cells contain hemoglobin, the iron-rich protein
                  that carries oxygen throughout the body. White blood cells, though far fewer in number (5,000-10,000
                  per microliter), are essential for immune function. Platelets (150,000-400,000 per microliter) play a
                  critical role in blood clotting and wound healing. The balance of these components is crucial for
                  maintaining health, and significant deviations can indicate various medical conditions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
