"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface AbsoluteValueResult {
  input: string
  result: string
  resultNumeric: number | null
  piecewiseForm: string | null
  steps: string[]
  isExpression: boolean
}

export function AbsoluteValueCalculator() {
  const [inputValue, setInputValue] = useState("")
  const [variableValue, setVariableValue] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<AbsoluteValueResult | null>(null)
  const [copied, setCopied] = useState<"text" | "latex" | null>(null)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(true)

  const parseExpression = (
    expr: string,
  ): {
    type: "numeric" | "expression"
    value: number | null
    simplified: string
    piecewise: string | null
    steps: string[]
  } => {
    const steps: string[] = []
    const cleanExpr = expr.replace(/\s+/g, "").replace(/\|/g, "")

    // Check if it's a simple number
    const numValue = Number.parseFloat(cleanExpr)
    if (!isNaN(numValue) && /^-?\d+\.?\d*$/.test(cleanExpr)) {
      steps.push(`Given value: ${cleanExpr}`)
      if (numValue >= 0) {
        steps.push(`Since ${cleanExpr} ≥ 0, |${cleanExpr}| = ${cleanExpr}`)
      } else {
        steps.push(`Since ${cleanExpr} < 0, |${cleanExpr}| = -1 × (${cleanExpr}) = ${Math.abs(numValue)}`)
      }
      steps.push(`Result: |${cleanExpr}| = ${Math.abs(numValue)}`)
      return {
        type: "numeric",
        value: Math.abs(numValue),
        simplified: Math.abs(numValue).toString(),
        piecewise: null,
        steps,
      }
    }

    // Handle algebraic expressions like |x - 5|, |-3x + 2|, |2x|
    const linearMatch = cleanExpr.match(/^(-?\d*\.?\d*)?\*?([a-zA-Z])([+-]\d+\.?\d*)?$/)
    if (linearMatch) {
      const coef = linearMatch[1] ? Number.parseFloat(linearMatch[1]) : linearMatch[1] === "-" ? -1 : 1
      const variable = linearMatch[2]
      const constant = linearMatch[3] ? Number.parseFloat(linearMatch[3]) : 0

      steps.push(`Given expression: |${formatLinear(coef, variable, constant)}|`)
      steps.push(`This is a linear expression in ${variable}`)

      // Determine critical point
      const criticalPoint = -constant / coef
      steps.push(`Critical point: ${variable} = ${criticalPoint.toFixed(2)} (where expression equals 0)`)

      let piecewise = ""
      if (coef > 0) {
        piecewise = `|${formatLinear(coef, variable, constant)}| = { ${formatLinear(coef, variable, constant)}, if ${variable} ≥ ${criticalPoint.toFixed(2)} ; ${formatLinear(-coef, variable, -constant)}, if ${variable} < ${criticalPoint.toFixed(2)} }`
        steps.push(`For ${variable} ≥ ${criticalPoint.toFixed(2)}: expression ≥ 0, so |expression| = expression`)
        steps.push(`For ${variable} < ${criticalPoint.toFixed(2)}: expression < 0, so |expression| = -expression`)
      } else {
        piecewise = `|${formatLinear(coef, variable, constant)}| = { ${formatLinear(-coef, variable, -constant)}, if ${variable} ≥ ${criticalPoint.toFixed(2)} ; ${formatLinear(coef, variable, constant)}, if ${variable} < ${criticalPoint.toFixed(2)} }`
        steps.push(`For ${variable} ≥ ${criticalPoint.toFixed(2)}: expression ≤ 0, so |expression| = -expression`)
        steps.push(`For ${variable} < ${criticalPoint.toFixed(2)}: expression > 0, so |expression| = expression`)
      }

      return {
        type: "expression",
        value: null,
        simplified: `|${formatLinear(coef, variable, constant)}|`,
        piecewise,
        steps,
      }
    }

    // Simple variable like |x|
    if (/^[a-zA-Z]$/.test(cleanExpr)) {
      steps.push(`Given expression: |${cleanExpr}|`)
      steps.push(`By definition of absolute value:`)
      steps.push(`|${cleanExpr}| = ${cleanExpr} if ${cleanExpr} ≥ 0`)
      steps.push(`|${cleanExpr}| = -${cleanExpr} if ${cleanExpr} < 0`)
      const piecewise = `|${cleanExpr}| = { ${cleanExpr}, if ${cleanExpr} ≥ 0 ; -${cleanExpr}, if ${cleanExpr} < 0 }`
      return { type: "expression", value: null, simplified: `|${cleanExpr}|`, piecewise, steps }
    }

    // Try to parse more complex expressions
    steps.push(`Given expression: |${cleanExpr}|`)
    steps.push(`Applying absolute value definition`)
    return { type: "expression", value: null, simplified: `|${cleanExpr}|`, piecewise: null, steps }
  }

  const formatLinear = (coef: number, variable: string, constant: number): string => {
    let result = ""
    if (coef === 1) result = variable
    else if (coef === -1) result = `-${variable}`
    else result = `${coef}${variable}`

    if (constant > 0) result += ` + ${constant}`
    else if (constant < 0) result += ` - ${Math.abs(constant)}`

    return result
  }

  const evaluateWithVariable = (expr: string, varValue: number): number | null => {
    const cleanExpr = expr.replace(/\s+/g, "").replace(/\|/g, "")

    // Try to evaluate linear expression ax + b
    const linearMatch = cleanExpr.match(/^(-?\d*\.?\d*)?\*?([a-zA-Z])([+-]\d+\.?\d*)?$/)
    if (linearMatch) {
      const coef = linearMatch[1] ? Number.parseFloat(linearMatch[1]) : linearMatch[1] === "-" ? -1 : 1
      const constant = linearMatch[3] ? Number.parseFloat(linearMatch[3]) : 0
      const value = coef * varValue + constant
      return Math.abs(value)
    }

    // Simple variable
    if (/^[a-zA-Z]$/.test(cleanExpr)) {
      return Math.abs(varValue)
    }

    return null
  }

  const calculateAbsoluteValue = () => {
    setError("")
    setResult(null)

    if (!inputValue.trim()) {
      setError("Please enter a value or expression")
      return
    }

    try {
      const parsed = parseExpression(inputValue)

      let resultNumeric = parsed.value
      const steps = [...parsed.steps]

      // If variable value is provided and it's an expression, evaluate it
      if (variableValue && parsed.type === "expression") {
        const varVal = Number.parseFloat(variableValue)
        if (!isNaN(varVal)) {
          resultNumeric = evaluateWithVariable(inputValue, varVal)
          if (resultNumeric !== null) {
            steps.push(``)
            steps.push(`Evaluating at variable = ${varVal}:`)
            steps.push(`Result: |expression| = ${resultNumeric}`)
          }
        }
      }

      setResult({
        input: inputValue,
        result: resultNumeric !== null ? resultNumeric.toString() : parsed.simplified,
        resultNumeric,
        piecewiseForm: parsed.piecewise,
        steps,
        isExpression: parsed.type === "expression",
      })
    } catch {
      setError("Invalid expression. Please check the format.")
    }
  }

  const handleReset = () => {
    setInputValue("")
    setVariableValue("")
    setResult(null)
    setError("")
    setCopied(null)
  }

  const handleCopy = async (type: "text" | "latex") => {
    if (result) {
      let text = ""
      if (type === "text") {
        text = `|${result.input}| = ${result.result}`
      } else {
        text = `\\left| ${result.input.replace(/\*/g, "\\cdot ")} \\right| = ${result.result}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(type)
      setTimeout(() => setCopied(null), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Absolute Value Calculation",
          text: `|${result.input}| = ${result.result}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Absolute Value Calculator</CardTitle>
                    <CardDescription>Calculate |x| for numbers and expressions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Input Value */}
                <div className="space-y-2">
                  <Label htmlFor="inputValue">Value or Expression</Label>
                  <Input
                    id="inputValue"
                    type="text"
                    placeholder="e.g., -5, x - 3, 2x + 1"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    className="font-mono"
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter a number or algebraic expression (e.g., -7, x, x - 5, -3x + 2)
                  </p>
                </div>

                {/* Variable Value (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="variableValue">Variable Value (Optional)</Label>
                  <Input
                    id="variableValue"
                    type="number"
                    placeholder="e.g., 3"
                    value={variableValue}
                    onChange={(e) => setVariableValue(e.target.value)}
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">Provide a value to evaluate the expression</p>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between py-2">
                  <Label htmlFor="showSteps" className="cursor-pointer">
                    Show step-by-step solution
                  </Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAbsoluteValue} className="w-full" size="lg">
                  Calculate Absolute Value
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <span className="text-lg text-muted-foreground">|{result.input}|</span>
                        <span className="text-lg text-muted-foreground">=</span>
                        <span className="text-4xl font-bold text-blue-600">{result.result}</span>
                      </div>
                      {result.resultNumeric !== null && result.isExpression && (
                        <p className="text-sm text-blue-600">Numeric value: {result.resultNumeric}</p>
                      )}
                    </div>

                    {/* Piecewise Form */}
                    {result.piecewiseForm && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-blue-100">
                        <p className="text-xs font-medium text-muted-foreground mb-2">Piecewise Form:</p>
                        <div className="font-mono text-sm text-blue-700 whitespace-pre-wrap">
                          {result.piecewiseForm.split(";").map((part, i) => (
                            <div key={i} className="ml-4">
                              {part.trim()}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            <span>Step-by-step solution</span>
                            {stepsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-2 p-3 bg-white rounded-lg border border-blue-100 space-y-2">
                            {result.steps.map((step, index) => (
                              <div key={index} className={`text-sm ${step === "" ? "h-2" : ""}`}>
                                {step && (
                                  <>
                                    <span className="font-medium text-blue-600 mr-2">
                                      {step.startsWith("Result") ? "→" : `${index + 1}.`}
                                    </span>
                                    <span className="text-muted-foreground font-mono">{step}</span>
                                  </>
                                )}
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleCopy("text")}>
                        {copied === "text" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied === "text" ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleCopy("latex")}>
                        {copied === "latex" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied === "latex" ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Absolute Value Definition</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">If a ≥ 0:</span>
                      <span className="text-sm text-green-600 ml-2">|a| = a</span>
                    </div>
                    <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">If a {"<"} 0:</span>
                      <span className="text-sm text-red-600 ml-2">|a| = −a</span>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Always:</span>
                      <span className="text-sm text-blue-600 ml-2">|a| ≥ 0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-muted rounded font-mono">|5| = 5</div>
                    <div className="p-2 bg-muted rounded font-mono">|-5| = 5</div>
                    <div className="p-2 bg-muted rounded font-mono">|0| = 0</div>
                    <div className="p-2 bg-muted rounded font-mono">|-3.5| = 3.5</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Numbers:</strong> -5, 3.14, 0
                  </p>
                  <p>
                    <strong>Variables:</strong> x, y
                  </p>
                  <p>
                    <strong>Linear expressions:</strong> x - 5, 2x + 3, -3x
                  </p>
                  <p className="text-xs mt-2">Note: The | symbols around expressions are optional</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Absolute Value?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The absolute value of a number represents its distance from zero on the number line, regardless of
                  direction. It is denoted by vertical bars around the number, such as |x|. Since distance is always
                  non-negative, the absolute value of any real number is always zero or positive. For example, both 5
                  and -5 are 5 units away from zero, so |5| = |-5| = 5.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Absolute value is fundamental in mathematics because it allows us to measure magnitude without
                  considering sign. This concept is essential in calculus for defining limits and continuity, in algebra
                  for solving equations and inequalities, and in real-world applications like calculating distances,
                  errors, and deviations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Properties of Absolute Value</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Non-negativity</h4>
                    <p className="text-sm text-muted-foreground">|a| ≥ 0 for all real numbers a</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Identity of Indiscernibles</h4>
                    <p className="text-sm text-muted-foreground">|a| = 0 if and only if a = 0</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Symmetry</h4>
                    <p className="text-sm text-muted-foreground">|−a| = |a| for all real numbers a</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Multiplicativity</h4>
                    <p className="text-sm text-muted-foreground">|ab| = |a| × |b| for all real numbers</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Triangle Inequality</h4>
                    <p className="text-sm text-muted-foreground">|a + b| ≤ |a| + |b| for all real numbers</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Preservation of Division</h4>
                    <p className="text-sm text-muted-foreground">|a/b| = |a|/|b| when b ≠ 0</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-amber-700">
                  This absolute value calculator applies standard mathematical definitions. Results depend on correct
                  input formatting and assumptions. For complex expressions, verify the interpretation matches your
                  intended input. This tool is for educational purposes and should be used alongside proper mathematical
                  understanding.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
