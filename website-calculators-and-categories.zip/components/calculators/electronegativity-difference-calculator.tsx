"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, Atom, FlaskConical } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

// Pauling electronegativity values for common elements
const ELECTRONEGATIVITY_VALUES: Record<string, number> = {
  H: 2.20, He: 0,
  Li: 0.98, Be: 1.57, B: 2.04, C: 2.55, N: 3.04, O: 3.44, F: 3.98, Ne: 0,
  Na: 0.93, Mg: 1.31, Al: 1.61, Si: 1.90, P: 2.19, S: 2.58, Cl: 3.16, Ar: 0,
  K: 0.82, Ca: 1.00, Sc: 1.36, Ti: 1.54, V: 1.63, Cr: 1.66, Mn: 1.55, Fe: 1.83,
  Co: 1.88, Ni: 1.91, Cu: 1.90, Zn: 1.65, Ga: 1.81, Ge: 2.01, As: 2.18, Se: 2.55,
  Br: 2.96, Kr: 3.00, Rb: 0.82, Sr: 0.95, Y: 1.22, Zr: 1.33, Nb: 1.6, Mo: 2.16,
  Tc: 1.9, Ru: 2.2, Rh: 2.28, Pd: 2.20, Ag: 1.93, Cd: 1.69, In: 1.78, Sn: 1.96,
  Sb: 2.05, Te: 2.1, I: 2.66, Xe: 2.60, Cs: 0.79, Ba: 0.89, La: 1.10, Hf: 1.3,
  Ta: 1.5, W: 2.36, Re: 1.9, Os: 2.2, Ir: 2.20, Pt: 2.28, Au: 2.54, Hg: 2.00,
  Tl: 1.62, Pb: 2.33, Bi: 2.02, Po: 2.0, At: 2.2, Rn: 2.2
}

const ELEMENT_SYMBOLS = Object.keys(ELECTRONEGATIVITY_VALUES).filter(el => ELECTRONEGATIVITY_VALUES[el] > 0)

interface ENResult {
  en1: number
  en2: number
  difference: number
  bondType: string
  color: string
  bgColor: string
  moreElectronegative: string
  lessElectronegative: string
}

export function ElectronegativityDifferenceCalculator() {
  const [element1, setElement1] = useState("")
  const [element2, setElement2] = useState("")
  const [customEN1, setCustomEN1] = useState("")
  const [customEN2, setCustomEN2] = useState("")
  const [useCustomValues, setUseCustomValues] = useState(false)
  const [result, setResult] = useState<ENResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateEN = () => {
    setError("")
    setResult(null)

    let en1: number
    let en2: number

    if (useCustomValues) {
      en1 = Number.parseFloat(customEN1)
      en2 = Number.parseFloat(customEN2)

      if (isNaN(en1) || isNaN(en2) || en1 <= 0 || en2 <= 0) {
        setError("Please enter valid positive electronegativity values")
        return
      }
    } else {
      if (!element1 || !element2) {
        setError("Please select both elements")
        return
      }

      en1 = ELECTRONEGATIVITY_VALUES[element1]
      en2 = ELECTRONEGATIVITY_VALUES[element2]

      if (en1 === 0 || en2 === 0) {
        setError("Selected element(s) do not have electronegativity values")
        return
      }
    }

    const difference = Math.abs(en1 - en2)
    const roundedDiff = Math.round(difference * 100) / 100

    let bondType: string
    let color: string
    let bgColor: string

    if (roundedDiff < 0.4) {
      bondType = "Nonpolar Covalent"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (roundedDiff < 1.7) {
      bondType = "Polar Covalent"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      bondType = "Ionic"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    const moreElectronegative = en1 > en2 ? (element1 || "Element A") : (element2 || "Element B")
    const lessElectronegative = en1 > en2 ? (element2 || "Element B") : (element1 || "Element A")

    setResult({
      en1,
      en2,
      difference: roundedDiff,
      bondType,
      color,
      bgColor,
      moreElectronegative,
      lessElectronegative
    })
  }

  const handleReset = () => {
    setElement1("")
    setElement2("")
    setCustomEN1("")
    setCustomEN2("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Electronegativity Difference: ΔEN = ${result.difference} (${result.bondType} bond)`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Electronegativity Difference Result",
          text: `I calculated electronegativity difference using CalcHub! ΔEN = ${result.difference} (${result.bondType} bond)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Electronegativity Difference</CardTitle>
                    <CardDescription>Calculate bond polarity and type</CardDescription>
                  </div>
                </div>

                {/* Custom Values Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Method</span>
                  <button
                    onClick={() => {
                      setUseCustomValues(!useCustomValues)
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        useCustomValues ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !useCustomValues ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Elements
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        useCustomValues ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Custom
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {!useCustomValues ? (
                  <>
                    {/* Element A Selection */}
                    <div className="space-y-2">
                      <Label htmlFor="element1">Element A</Label>
                      <Select value={element1} onValueChange={setElement1}>
                        <SelectTrigger id="element1">
                          <SelectValue placeholder="Select element" />
                        </SelectTrigger>
                        <SelectContent>
                          {ELEMENT_SYMBOLS.map((symbol) => (
                            <SelectItem key={symbol} value={symbol}>
                              {symbol} - {ELECTRONEGATIVITY_VALUES[symbol]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Element B Selection */}
                    <div className="space-y-2">
                      <Label htmlFor="element2">Element B</Label>
                      <Select value={element2} onValueChange={setElement2}>
                        <SelectTrigger id="element2">
                          <SelectValue placeholder="Select element" />
                        </SelectTrigger>
                        <SelectContent>
                          {ELEMENT_SYMBOLS.map((symbol) => (
                            <SelectItem key={symbol} value={symbol}>
                              {symbol} - {ELECTRONEGATIVITY_VALUES[symbol]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Custom EN Value 1 */}
                    <div className="space-y-2">
                      <Label htmlFor="customEN1">Electronegativity Value 1</Label>
                      <Input
                        id="customEN1"
                        type="number"
                        placeholder="Enter EN value"
                        value={customEN1}
                        onChange={(e) => setCustomEN1(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>

                    {/* Custom EN Value 2 */}
                    <div className="space-y-2">
                      <Label htmlFor="customEN2">Electronegativity Value 2</Label>
                      <Input
                        id="customEN2"
                        type="number"
                        placeholder="Enter EN value"
                        value={customEN2}
                        onChange={(e) => setCustomEN2(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateEN} className="w-full" size="lg">
                  Calculate ΔEN
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Electronegativity Difference</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.difference}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.bondType}</p>
                      
                      {/* Polarity Indication */}
                      <div className="mt-4 pt-4 border-t border-current/20">
                        <p className="text-xs text-muted-foreground mb-2">Bond Polarity</p>
                        <div className="flex items-center justify-center gap-2 text-sm">
                          <span className="font-mono font-medium">
                            {result.lessElectronegative}<sup className="text-xs">δ+</sup>
                          </span>
                          <span className="text-muted-foreground">—</span>
                          <span className="font-mono font-medium">
                            {result.moreElectronegative}<sup className="text-xs">δ−</sup>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bond Type Classification</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Nonpolar Covalent</span>
                      <span className="text-sm text-green-600">ΔEN {"< 0.4"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Polar Covalent</span>
                      <span className="text-sm text-yellow-600">0.4 ≤ ΔEN {"< 1.7"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Ionic</span>
                      <span className="text-sm text-red-600">ΔEN ≥ 1.7</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Electronegativity Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ΔEN = |EN₁ − EN₂|</p>
                  </div>
                  <p>
                    The electronegativity difference (ΔEN) is the absolute value of the difference between the electronegativity values of two bonded atoms.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Polarity Symbols</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <ul className="space-y-2">
                    <li><strong>δ⁺ (delta plus):</strong> Partial positive charge on less electronegative atom</li>
                    <li><strong>δ⁻ (delta minus):</strong> Partial negative charge on more electronegative atom</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Electronegativity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Electronegativity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electronegativity is a fundamental chemical property that measures the tendency of an atom to attract electrons toward itself when forming a chemical bond. Introduced by Linus Pauling in 1932, this concept has become essential for understanding molecular structure, bond polarity, and chemical reactivity. Electronegativity values are dimensionless numbers typically ranging from 0.7 (cesium and francium) to 3.98 (fluorine), with fluorine being the most electronegative element.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Pauling scale is the most widely used electronegativity scale in chemistry. It's based on bond dissociation energies and provides a quantitative measure that helps predict the nature of chemical bonds. Elements with high electronegativity values, like oxygen, nitrogen, and the halogens, strongly attract electrons, while elements with low electronegativity, such as alkali metals, tend to donate electrons readily.
                </p>
              </CardContent>
            </Card>

            {/* Understanding Bond Types */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Bond Types Based on ΔEN</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The electronegativity difference between two atoms determines the type and polarity of the chemical bond they form. This relationship provides a powerful predictive tool for understanding molecular behavior and properties.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Nonpolar Covalent Bonds (ΔEN {"< 0.4"})</h4>
                    <p className="text-green-700 text-sm">
                      When two atoms have very similar or identical electronegativity values, they share electrons equally, forming a nonpolar covalent bond. Examples include H₂, O₂, N₂, and C-H bonds. These bonds show no significant charge separation and typically form between atoms of the same element or between carbon and hydrogen.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Polar Covalent Bonds (0.4 ≤ ΔEN {"< 1.7"})</h4>
                    <p className="text-yellow-700 text-sm">
                      When atoms have moderately different electronegativity values, electrons are shared unequally, creating a polar covalent bond with partial charges (δ⁺ and δ⁻). Water (H₂O), ammonia (NH₃), and hydrogen chloride (HCl) contain polar covalent bonds. These bonds are responsible for many important molecular properties including dipole moments and hydrogen bonding.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Ionic Bonds (ΔEN ≥ 1.7)</h4>
                    <p className="text-red-700 text-sm">
                      Large electronegativity differences result in essentially complete electron transfer from one atom to another, forming ionic bonds. The more electronegative atom gains electron(s) to become a negatively charged anion, while the less electronegative atom loses electron(s) to become a positively charged cation. Sodium chloride (NaCl) and magnesium oxide (MgO) are classic examples of ionic compounds.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Electronegativity Difference</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding electronegativity differences has numerous practical applications in chemistry and related fields. It helps predict molecular polarity, which affects solubility, boiling points, and chemical reactivity. Polar molecules dissolve well in polar solvents (like water), while nonpolar molecules prefer nonpolar solvents (like hexane).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In organic chemistry, electronegativity differences help predict reaction mechanisms and the stability of intermediates. In materials science, they guide the design of semiconductors and catalysts. Biochemists use electronegativity to understand protein folding, enzyme active sites, and drug-receptor interactions. The concept is also fundamental in understanding acid-base behavior and oxidation-reduction reactions.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Note:</strong> Electronegativity differences estimate bond character. Actual bonds may show mixed or partial behavior. The 0.4 and 1.7 thresholds are guidelines, not absolute boundaries. Bond character exists on a continuum, and factors like molecular geometry and resonance can affect the actual distribution of electron density.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
