"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, FlaskConical, Clock } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type TimeUnit = "s" | "min" | "h"

interface ElectrolysisResult {
  charge: number
  moles: number
  mass: number
  gasVolume: number | null
  steps: string[]
}

const FARADAY_CONSTANT = 96485 // C/mol
const MOLAR_VOLUME_STP = 22.414 // L/mol at STP

// Common substances for electrolysis
const commonSubstances = [
  { name: "Copper (Cu)", molarMass: 63.546, electrons: 2, isGas: false },
  { name: "Silver (Ag)", molarMass: 107.868, electrons: 1, isGas: false },
  { name: "Gold (Au)", molarMass: 196.967, electrons: 3, isGas: false },
  { name: "Zinc (Zn)", molarMass: 65.38, electrons: 2, isGas: false },
  { name: "Hydrogen (H₂)", molarMass: 2.016, electrons: 2, isGas: true },
  { name: "Oxygen (O₂)", molarMass: 32.0, electrons: 4, isGas: true },
  { name: "Chlorine (Cl₂)", molarMass: 70.906, electrons: 2, isGas: true },
  { name: "Aluminum (Al)", molarMass: 26.982, electrons: 3, isGas: false },
  { name: "Nickel (Ni)", molarMass: 58.693, electrons: 2, isGas: false },
  { name: "Iron (Fe)", molarMass: 55.845, electrons: 2, isGas: false },
]

export function ElectrolysisCalculator() {
  const [current, setCurrent] = useState("")
  const [time, setTime] = useState("")
  const [timeUnit, setTimeUnit] = useState<TimeUnit>("s")
  const [electrons, setElectrons] = useState("")
  const [molarMass, setMolarMass] = useState("")
  const [selectedSubstance, setSelectedSubstance] = useState("")
  const [isGasProduct, setIsGasProduct] = useState(false)
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<ElectrolysisResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const convertTimeToSeconds = (value: number, unit: TimeUnit): number => {
    switch (unit) {
      case "min":
        return value * 60
      case "h":
        return value * 3600
      default:
        return value
    }
  }

  const handleSubstanceSelect = (value: string) => {
    setSelectedSubstance(value)
    if (value === "custom") {
      setElectrons("")
      setMolarMass("")
      setIsGasProduct(false)
    } else {
      const substance = commonSubstances.find((s) => s.name === value)
      if (substance) {
        setElectrons(substance.electrons.toString())
        setMolarMass(substance.molarMass.toString())
        setIsGasProduct(substance.isGas)
      }
    }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const I = Number.parseFloat(current)
    const t = Number.parseFloat(time)
    const n = Number.parseFloat(electrons)
    const M = Number.parseFloat(molarMass)

    if (isNaN(I) || I <= 0) {
      setError("Please enter a valid current greater than 0")
      return
    }

    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid time greater than 0")
      return
    }

    if (isNaN(n) || n <= 0 || !Number.isInteger(n)) {
      setError("Please enter a valid positive integer for electrons transferred")
      return
    }

    if (isNaN(M) || M <= 0) {
      setError("Please enter a valid molar mass greater than 0")
      return
    }

    const steps: string[] = []

    // Convert time to seconds
    const timeInSeconds = convertTimeToSeconds(t, timeUnit)
    steps.push(`Time in seconds: ${t} ${timeUnit} = ${timeInSeconds.toLocaleString()} s`)

    // Calculate charge (Q = I × t)
    const Q = I * timeInSeconds
    steps.push(`Charge passed: Q = I × t = ${I} A × ${timeInSeconds.toLocaleString()} s = ${Q.toLocaleString()} C`)

    // Calculate moles of substance (n_substance = Q / (n × F))
    const molesSubstance = Q / (n * FARADAY_CONSTANT)
    steps.push(
      `Moles of substance: n = Q ÷ (n_electrons × F) = ${Q.toLocaleString()} C ÷ (${n} × ${FARADAY_CONSTANT.toLocaleString()} C/mol)`,
    )
    steps.push(`n = ${molesSubstance.toExponential(4)} mol`)

    // Calculate mass (m = n × M)
    const mass = molesSubstance * M
    steps.push(`Mass produced: m = n × M = ${molesSubstance.toExponential(4)} mol × ${M} g/mol`)
    steps.push(`m = ${mass.toFixed(4)} g`)

    // Calculate gas volume if applicable
    let gasVolume: number | null = null
    if (isGasProduct) {
      gasVolume = molesSubstance * MOLAR_VOLUME_STP
      steps.push(`Gas volume at STP: V = n × V_m = ${molesSubstance.toExponential(4)} mol × ${MOLAR_VOLUME_STP} L/mol`)
      steps.push(`V = ${gasVolume.toFixed(4)} L`)
    }

    setResult({
      charge: Q,
      moles: molesSubstance,
      mass: mass,
      gasVolume: gasVolume,
      steps: steps,
    })
  }

  const handleReset = () => {
    setCurrent("")
    setTime("")
    setTimeUnit("s")
    setElectrons("")
    setMolarMass("")
    setSelectedSubstance("")
    setIsGasProduct(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Electrolysis Results:
Charge: ${result.charge.toLocaleString()} C
Moles: ${result.moles.toExponential(4)} mol
Mass: ${result.mass.toFixed(4)} g${result.gasVolume !== null ? `\nGas Volume: ${result.gasVolume.toFixed(4)} L` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Electrolysis Calculation Results",
          text: `I calculated electrolysis results using CalcHub! Mass produced: ${result.mass.toFixed(4)} g`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number, decimals = 4): string => {
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 1000000) {
      return num.toExponential(decimals)
    }
    return num.toFixed(decimals)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Electrolysis Calculator</CardTitle>
                    <CardDescription>Calculate mass produced using Faraday's laws</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Substance Selection */}
                <div className="space-y-2">
                  <Label>Substance (optional preset)</Label>
                  <Select value={selectedSubstance} onValueChange={handleSubstanceSelect}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a substance or enter custom" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="custom">Custom values</SelectItem>
                      {commonSubstances.map((s) => (
                        <SelectItem key={s.name} value={s.name}>
                          {s.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Current Input */}
                <div className="space-y-2">
                  <Label htmlFor="current">Current (I) in Amperes</Label>
                  <Input
                    id="current"
                    type="number"
                    placeholder="Enter current in A"
                    value={current}
                    onChange={(e) => setCurrent(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Time Input */}
                <div className="space-y-2">
                  <Label>Time (t)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder="Enter time"
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      min="0"
                      step="0.1"
                      className="flex-1"
                    />
                    <Select value={timeUnit} onValueChange={(v) => setTimeUnit(v as TimeUnit)}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="s">sec</SelectItem>
                        <SelectItem value="min">min</SelectItem>
                        <SelectItem value="h">hour</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Electrons Transferred */}
                <div className="space-y-2">
                  <Label htmlFor="electrons">Electrons transferred per ion (n)</Label>
                  <Input
                    id="electrons"
                    type="number"
                    placeholder="e.g., 2 for Cu²⁺ → Cu"
                    value={electrons}
                    onChange={(e) => setElectrons(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Molar Mass */}
                <div className="space-y-2">
                  <Label htmlFor="molarMass">Molar Mass (M) in g/mol</Label>
                  <Input
                    id="molarMass"
                    type="number"
                    placeholder="Enter molar mass"
                    value={molarMass}
                    onChange={(e) => setMolarMass(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                </div>

                {/* Gas Product Toggle */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                  <div>
                    <Label className="font-medium">Gas product?</Label>
                    <p className="text-xs text-muted-foreground">Calculate volume at STP</p>
                  </div>
                  <Switch checked={isGasProduct} onCheckedChange={setIsGasProduct} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Mass Produced</p>
                      <p className="text-4xl font-bold text-purple-600">{formatNumber(result.mass)} g</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 rounded-lg bg-white border border-purple-100">
                        <p className="text-xs text-muted-foreground">Charge Passed</p>
                        <p className="font-semibold text-purple-700">{result.charge.toLocaleString()} C</p>
                      </div>
                      <div className="p-3 rounded-lg bg-white border border-purple-100">
                        <p className="text-xs text-muted-foreground">Moles Produced</p>
                        <p className="font-semibold text-purple-700">{result.moles.toExponential(4)} mol</p>
                      </div>
                      {result.gasVolume !== null && (
                        <div className="col-span-2 p-3 rounded-lg bg-white border border-purple-100">
                          <p className="text-xs text-muted-foreground">Gas Volume at STP</p>
                          <p className="font-semibold text-purple-700">{formatNumber(result.gasVolume)} L</p>
                        </div>
                      )}
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 p-3 rounded-lg bg-white border border-purple-100">
                        <p className="text-sm font-medium text-purple-800 mb-2">Step-by-Step Solution:</p>
                        <div className="space-y-1">
                          {result.steps.map((step, index) => (
                            <p key={index} className="text-xs text-muted-foreground font-mono">
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Faraday's Laws of Electrolysis</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Q = I × t</p>
                    <p className="font-semibold text-foreground">n = Q ÷ (n_e × F)</p>
                    <p className="font-semibold text-foreground">m = n × M</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>Q</strong> = Charge (Coulombs)
                    </p>
                    <p>
                      <strong>I</strong> = Current (Amperes)
                    </p>
                    <p>
                      <strong>t</strong> = Time (seconds)
                    </p>
                    <p>
                      <strong>n_e</strong> = Electrons per ion
                    </p>
                    <p>
                      <strong>F</strong> = Faraday constant (96,485 C/mol)
                    </p>
                    <p>
                      <strong>M</strong> = Molar mass (g/mol)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Electrolysis Reactions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="p-2 rounded bg-muted">
                      <p className="font-mono">Cu²⁺ + 2e⁻ → Cu</p>
                      <p className="text-xs text-muted-foreground">Copper plating (n=2)</p>
                    </div>
                    <div className="p-2 rounded bg-muted">
                      <p className="font-mono">2H₂O → 2H₂ + O₂</p>
                      <p className="text-xs text-muted-foreground">Water electrolysis</p>
                    </div>
                    <div className="p-2 rounded bg-muted">
                      <p className="font-mono">Ag⁺ + e⁻ → Ag</p>
                      <p className="text-xs text-muted-foreground">Silver plating (n=1)</p>
                    </div>
                    <div className="p-2 rounded bg-muted">
                      <p className="font-mono">Al³⁺ + 3e⁻ → Al</p>
                      <p className="text-xs text-muted-foreground">Aluminum production (n=3)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results assume 100% current efficiency and ideal conditions. Actual yields may vary due to side
                        reactions and other factors.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Electrolysis?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrolysis is a chemical process that uses electrical energy to drive a non-spontaneous chemical
                  reaction. When an electric current passes through an electrolyte (a substance containing free ions),
                  it causes chemical changes at the electrodes. This process is fundamental to many industrial
                  applications including metal extraction, electroplating, and the production of various chemicals.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  During electrolysis, positive ions (cations) migrate to the negative electrode (cathode) where they
                  gain electrons (reduction), while negative ions (anions) move to the positive electrode (anode) where
                  they lose electrons (oxidation). The amount of substance produced or consumed is directly related to
                  the quantity of electric charge passed through the system, as described by Faraday's laws.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Faraday's Laws Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Michael Faraday discovered two fundamental laws governing electrolysis in 1833. The first law states
                  that the mass of substance deposited or liberated at an electrode is directly proportional to the
                  quantity of electricity (charge) passed through the electrolyte. This means doubling the current or
                  time will double the amount of product.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The second law states that when the same quantity of electricity passes through different
                  electrolytes, the masses of substances deposited are proportional to their equivalent weights (molar
                  mass divided by the number of electrons transferred). These laws form the quantitative basis for all
                  electrolytic calculations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Industrial Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrolysis has numerous industrial applications. Electroplating uses electrolysis to coat objects
                  with thin layers of metals like chromium, nickel, or gold for protection or decoration.
                  Electrorefining purifies metals like copper to very high purity levels (99.99%). The Hall-Héroult
                  process uses electrolysis to extract aluminum from bauxite ore.
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-100">
                    <p className="font-medium text-purple-800">Electroplating</p>
                    <p className="text-sm text-purple-600">Decorative and protective metal coatings</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-100">
                    <p className="font-medium text-purple-800">Metal Extraction</p>
                    <p className="text-sm text-purple-600">Aluminum, sodium, and reactive metals</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-100">
                    <p className="font-medium text-purple-800">Chlor-Alkali Process</p>
                    <p className="text-sm text-purple-600">Production of chlorine and sodium hydroxide</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-100">
                    <p className="font-medium text-purple-800">Hydrogen Production</p>
                    <p className="text-sm text-purple-600">Green hydrogen via water electrolysis</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Current Efficiency</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In practice, electrolysis rarely achieves 100% current efficiency. Some of the electrical energy is
                  lost to side reactions, heat generation, and other inefficiencies. For example, during water
                  electrolysis, some current may go toward oxidizing metal electrodes rather than producing oxygen.
                  Industrial processes typically operate at 70-95% efficiency.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The actual yield can be calculated by multiplying the theoretical yield by the current efficiency:
                  Actual mass = Theoretical mass × (Current efficiency / 100). When comparing calculated results to
                  experimental data, always consider that real-world yields will typically be lower than the theoretical
                  maximum.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
