"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Beaker,
  Atom,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

// Periodic table with atomic weights (standard atomic weights)
const PERIODIC_TABLE: Record<string, { name: string; weight: number; number: number }> = {
  H: { name: "Hydrogen", weight: 1.008, number: 1 },
  He: { name: "Helium", weight: 4.0026, number: 2 },
  Li: { name: "Lithium", weight: 6.94, number: 3 },
  Be: { name: "Beryllium", weight: 9.0122, number: 4 },
  B: { name: "Boron", weight: 10.81, number: 5 },
  C: { name: "Carbon", weight: 12.011, number: 6 },
  N: { name: "Nitrogen", weight: 14.007, number: 7 },
  O: { name: "Oxygen", weight: 15.999, number: 8 },
  F: { name: "Fluorine", weight: 18.998, number: 9 },
  Ne: { name: "Neon", weight: 20.18, number: 10 },
  Na: { name: "Sodium", weight: 22.99, number: 11 },
  Mg: { name: "Magnesium", weight: 24.305, number: 12 },
  Al: { name: "Aluminum", weight: 26.982, number: 13 },
  Si: { name: "Silicon", weight: 28.085, number: 14 },
  P: { name: "Phosphorus", weight: 30.974, number: 15 },
  S: { name: "Sulfur", weight: 32.06, number: 16 },
  Cl: { name: "Chlorine", weight: 35.45, number: 17 },
  Ar: { name: "Argon", weight: 39.948, number: 18 },
  K: { name: "Potassium", weight: 39.098, number: 19 },
  Ca: { name: "Calcium", weight: 40.078, number: 20 },
  Sc: { name: "Scandium", weight: 44.956, number: 21 },
  Ti: { name: "Titanium", weight: 47.867, number: 22 },
  V: { name: "Vanadium", weight: 50.942, number: 23 },
  Cr: { name: "Chromium", weight: 51.996, number: 24 },
  Mn: { name: "Manganese", weight: 54.938, number: 25 },
  Fe: { name: "Iron", weight: 55.845, number: 26 },
  Co: { name: "Cobalt", weight: 58.933, number: 27 },
  Ni: { name: "Nickel", weight: 58.693, number: 28 },
  Cu: { name: "Copper", weight: 63.546, number: 29 },
  Zn: { name: "Zinc", weight: 65.38, number: 30 },
  Ga: { name: "Gallium", weight: 69.723, number: 31 },
  Ge: { name: "Germanium", weight: 72.63, number: 32 },
  As: { name: "Arsenic", weight: 74.922, number: 33 },
  Se: { name: "Selenium", weight: 78.971, number: 34 },
  Br: { name: "Bromine", weight: 79.904, number: 35 },
  Kr: { name: "Krypton", weight: 83.798, number: 36 },
  Rb: { name: "Rubidium", weight: 85.468, number: 37 },
  Sr: { name: "Strontium", weight: 87.62, number: 38 },
  Y: { name: "Yttrium", weight: 88.906, number: 39 },
  Zr: { name: "Zirconium", weight: 91.224, number: 40 },
  Nb: { name: "Niobium", weight: 92.906, number: 41 },
  Mo: { name: "Molybdenum", weight: 95.95, number: 42 },
  Tc: { name: "Technetium", weight: 98, number: 43 },
  Ru: { name: "Ruthenium", weight: 101.07, number: 44 },
  Rh: { name: "Rhodium", weight: 102.91, number: 45 },
  Pd: { name: "Palladium", weight: 106.42, number: 46 },
  Ag: { name: "Silver", weight: 107.87, number: 47 },
  Cd: { name: "Cadmium", weight: 112.41, number: 48 },
  In: { name: "Indium", weight: 114.82, number: 49 },
  Sn: { name: "Tin", weight: 118.71, number: 50 },
  Sb: { name: "Antimony", weight: 121.76, number: 51 },
  Te: { name: "Tellurium", weight: 127.6, number: 52 },
  I: { name: "Iodine", weight: 126.9, number: 53 },
  Xe: { name: "Xenon", weight: 131.29, number: 54 },
  Cs: { name: "Cesium", weight: 132.91, number: 55 },
  Ba: { name: "Barium", weight: 137.33, number: 56 },
  La: { name: "Lanthanum", weight: 138.91, number: 57 },
  Ce: { name: "Cerium", weight: 140.12, number: 58 },
  Pr: { name: "Praseodymium", weight: 140.91, number: 59 },
  Nd: { name: "Neodymium", weight: 144.24, number: 60 },
  Pm: { name: "Promethium", weight: 145, number: 61 },
  Sm: { name: "Samarium", weight: 150.36, number: 62 },
  Eu: { name: "Europium", weight: 151.96, number: 63 },
  Gd: { name: "Gadolinium", weight: 157.25, number: 64 },
  Tb: { name: "Terbium", weight: 158.93, number: 65 },
  Dy: { name: "Dysprosium", weight: 162.5, number: 66 },
  Ho: { name: "Holmium", weight: 164.93, number: 67 },
  Er: { name: "Erbium", weight: 167.26, number: 68 },
  Tm: { name: "Thulium", weight: 168.93, number: 69 },
  Yb: { name: "Ytterbium", weight: 173.05, number: 70 },
  Lu: { name: "Lutetium", weight: 174.97, number: 71 },
  Hf: { name: "Hafnium", weight: 178.49, number: 72 },
  Ta: { name: "Tantalum", weight: 180.95, number: 73 },
  W: { name: "Tungsten", weight: 183.84, number: 74 },
  Re: { name: "Rhenium", weight: 186.21, number: 75 },
  Os: { name: "Osmium", weight: 190.23, number: 76 },
  Ir: { name: "Iridium", weight: 192.22, number: 77 },
  Pt: { name: "Platinum", weight: 195.08, number: 78 },
  Au: { name: "Gold", weight: 196.97, number: 79 },
  Hg: { name: "Mercury", weight: 200.59, number: 80 },
  Tl: { name: "Thallium", weight: 204.38, number: 81 },
  Pb: { name: "Lead", weight: 207.2, number: 82 },
  Bi: { name: "Bismuth", weight: 208.98, number: 83 },
  Po: { name: "Polonium", weight: 209, number: 84 },
  At: { name: "Astatine", weight: 210, number: 85 },
  Rn: { name: "Radon", weight: 222, number: 86 },
  Fr: { name: "Francium", weight: 223, number: 87 },
  Ra: { name: "Radium", weight: 226, number: 88 },
  Ac: { name: "Actinium", weight: 227, number: 89 },
  Th: { name: "Thorium", weight: 232.04, number: 90 },
  Pa: { name: "Protactinium", weight: 231.04, number: 91 },
  U: { name: "Uranium", weight: 238.03, number: 92 },
  Np: { name: "Neptunium", weight: 237, number: 93 },
  Pu: { name: "Plutonium", weight: 244, number: 94 },
  Am: { name: "Americium", weight: 243, number: 95 },
  Cm: { name: "Curium", weight: 247, number: 96 },
  Bk: { name: "Berkelium", weight: 247, number: 97 },
  Cf: { name: "Californium", weight: 251, number: 98 },
  Es: { name: "Einsteinium", weight: 252, number: 99 },
  Fm: { name: "Fermium", weight: 257, number: 100 },
  Md: { name: "Mendelevium", weight: 258, number: 101 },
  No: { name: "Nobelium", weight: 259, number: 102 },
  Lr: { name: "Lawrencium", weight: 262, number: 103 },
  Rf: { name: "Rutherfordium", weight: 267, number: 104 },
  Db: { name: "Dubnium", weight: 270, number: 105 },
  Sg: { name: "Seaborgium", weight: 271, number: 106 },
  Bh: { name: "Bohrium", weight: 270, number: 107 },
  Hs: { name: "Hassium", weight: 277, number: 108 },
  Mt: { name: "Meitnerium", weight: 276, number: 109 },
  Ds: { name: "Darmstadtium", weight: 281, number: 110 },
  Rg: { name: "Roentgenium", weight: 282, number: 111 },
  Cn: { name: "Copernicium", weight: 285, number: 112 },
  Nh: { name: "Nihonium", weight: 286, number: 113 },
  Fl: { name: "Flerovium", weight: 289, number: 114 },
  Mc: { name: "Moscovium", weight: 290, number: 115 },
  Lv: { name: "Livermorium", weight: 293, number: 116 },
  Ts: { name: "Tennessine", weight: 294, number: 117 },
  Og: { name: "Oganesson", weight: 294, number: 118 },
}

interface ElementCount {
  element: string
  name: string
  atomicWeight: number
  count: number
  contribution: number
}

interface ParseResult {
  success: boolean
  elements?: ElementCount[]
  totalWeight?: number
  totalAtoms?: number
  error?: string
}

// Parse chemical formula with support for parentheses and subscripts
function parseFormula(formula: string): ParseResult {
  if (!formula.trim()) {
    return { success: false, error: "Please enter a chemical formula" }
  }

  const elementCounts: Record<string, number> = {}

  try {
    // Recursive parser for handling nested parentheses
    function parseSegment(segment: string, multiplier = 1): void {
      let i = 0
      while (i < segment.length) {
        if (segment[i] === "(") {
          // Find matching closing parenthesis
          let depth = 1
          let j = i + 1
          while (j < segment.length && depth > 0) {
            if (segment[j] === "(") depth++
            if (segment[j] === ")") depth--
            j++
          }

          if (depth !== 0) {
            throw new Error("Unmatched parentheses")
          }

          const innerSegment = segment.slice(i + 1, j - 1)

          // Get the subscript after the closing parenthesis
          let subscript = ""
          while (j < segment.length && /\d/.test(segment[j])) {
            subscript += segment[j]
            j++
          }

          const count = subscript ? Number.parseInt(subscript) : 1
          parseSegment(innerSegment, multiplier * count)
          i = j
        } else if (/[A-Z]/.test(segment[i])) {
          // Parse element symbol
          let symbol = segment[i]
          let j = i + 1

          // Check for lowercase letters (two-letter symbols)
          while (j < segment.length && /[a-z]/.test(segment[j])) {
            symbol += segment[j]
            j++
          }

          // Validate element symbol
          if (!PERIODIC_TABLE[symbol]) {
            throw new Error(`Unknown element: ${symbol}`)
          }

          // Get the subscript
          let subscript = ""
          while (j < segment.length && /\d/.test(segment[j])) {
            subscript += segment[j]
            j++
          }

          const count = subscript ? Number.parseInt(subscript) : 1
          elementCounts[symbol] = (elementCounts[symbol] || 0) + count * multiplier
          i = j
        } else if (segment[i] === ")") {
          throw new Error("Unexpected closing parenthesis")
        } else if (/\s/.test(segment[i])) {
          // Skip whitespace
          i++
        } else if (segment[i] === "·" || segment[i] === ".") {
          // Handle hydration notation (e.g., ·5H2O)
          i++
          // Get the number
          let hydrationCount = ""
          while (i < segment.length && /\d/.test(segment[i])) {
            hydrationCount += segment[i]
            i++
          }
          const count = hydrationCount ? Number.parseInt(hydrationCount) : 1

          // Parse the hydration molecule
          let hydrationFormula = ""
          while (i < segment.length && segment[i] !== "·" && segment[i] !== ".") {
            hydrationFormula += segment[i]
            i++
          }
          if (hydrationFormula) {
            parseSegment(hydrationFormula, multiplier * count)
          }
        } else {
          throw new Error(`Invalid character: ${segment[i]}`)
        }
      }
    }

    parseSegment(formula)

    if (Object.keys(elementCounts).length === 0) {
      return { success: false, error: "No valid elements found in formula" }
    }

    // Build result
    const elements: ElementCount[] = []
    let totalWeight = 0
    let totalAtoms = 0

    for (const [symbol, count] of Object.entries(elementCounts)) {
      const element = PERIODIC_TABLE[symbol]
      const contribution = element.weight * count
      elements.push({
        element: symbol,
        name: element.name,
        atomicWeight: element.weight,
        count,
        contribution,
      })
      totalWeight += contribution
      totalAtoms += count
    }

    // Sort by atomic number
    elements.sort((a, b) => PERIODIC_TABLE[a.element].number - PERIODIC_TABLE[b.element].number)

    return {
      success: true,
      elements,
      totalWeight,
      totalAtoms,
    }
  } catch (e) {
    return { success: false, error: (e as Error).message }
  }
}

// Common compound examples
const COMMON_COMPOUNDS = [
  { formula: "H2O", name: "Water" },
  { formula: "NaCl", name: "Sodium Chloride" },
  { formula: "C6H12O6", name: "Glucose" },
  { formula: "H2SO4", name: "Sulfuric Acid" },
  { formula: "Ca(OH)2", name: "Calcium Hydroxide" },
  { formula: "Al2(SO4)3", name: "Aluminum Sulfate" },
  { formula: "C2H5OH", name: "Ethanol" },
  { formula: "NH3", name: "Ammonia" },
]

export function MolecularWeightCalculator() {
  const [formula, setFormula] = useState("")
  const [compoundName, setCompoundName] = useState("")
  const [showSteps, setShowSteps] = useState(true)
  const [copied, setCopied] = useState(false)

  const result = useMemo(() => parseFormula(formula), [formula])

  const handleReset = () => {
    setFormula("")
    setCompoundName("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result.success && result.totalWeight) {
      const text = `${compoundName ? compoundName + " " : ""}(${formula}): ${result.totalWeight.toFixed(4)} g/mol`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result.success && navigator.share) {
      try {
        await navigator.share({
          title: "Molecular Weight Result",
          text: `${compoundName ? compoundName + " " : ""}(${formula}): ${result.totalWeight?.toFixed(4)} g/mol - Calculated with CalcHub`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const selectExample = (compound: { formula: string; name: string }) => {
    setFormula(compound.formula)
    setCompoundName(compound.name)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Molecular Weight Calculator</CardTitle>
                    <CardDescription>Calculate molar mass from chemical formula</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Formula Input */}
                <div className="space-y-2">
                  <Label htmlFor="formula">Chemical Formula</Label>
                  <Input
                    id="formula"
                    type="text"
                    placeholder="e.g., H2O, C6H12O6, Ca(OH)2"
                    value={formula}
                    onChange={(e) => setFormula(e.target.value)}
                    className="font-mono text-lg"
                  />
                  <p className="text-xs text-muted-foreground">
                    Supports parentheses, subscripts, and hydration (e.g., CuSO4·5H2O)
                  </p>
                </div>

                {/* Compound Name (optional) */}
                <div className="space-y-2">
                  <Label htmlFor="name">Compound Name (optional)</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="e.g., Water, Glucose"
                    value={compoundName}
                    onChange={(e) => setCompoundName(e.target.value)}
                  />
                </div>

                {/* Quick Examples */}
                <div className="space-y-2">
                  <Label>Quick Examples</Label>
                  <div className="flex flex-wrap gap-2">
                    {COMMON_COMPOUNDS.slice(0, 4).map((compound) => (
                      <Button
                        key={compound.formula}
                        variant="outline"
                        size="sm"
                        onClick={() => selectExample(compound)}
                        className="font-mono text-xs"
                      >
                        {compound.formula}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show element breakdown</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {formula && !result.success && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">
                    {result.error}
                  </div>
                )}

                {/* Result */}
                {result.success && result.totalWeight && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      {compoundName && <p className="text-sm text-muted-foreground mb-1">{compoundName}</p>}
                      <p className="text-lg font-mono text-purple-700 mb-2">{formula}</p>
                      <p className="text-sm text-muted-foreground mb-1">Molecular Weight</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">{result.totalWeight.toFixed(4)}</p>
                      <p className="text-sm text-purple-600 font-medium">g/mol</p>
                      <p className="text-xs text-muted-foreground mt-2">Total atoms: {result.totalAtoms}</p>
                    </div>

                    {/* Element Breakdown */}
                    {showSteps && result.elements && (
                      <div className="mt-4 pt-4 border-t border-purple-200">
                        <p className="text-sm font-medium text-purple-700 mb-2">Element Breakdown</p>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="text-left text-muted-foreground">
                                <th className="pb-2">Element</th>
                                <th className="pb-2 text-right">Atomic Wt.</th>
                                <th className="pb-2 text-right">Count</th>
                                <th className="pb-2 text-right">Mass (g/mol)</th>
                              </tr>
                            </thead>
                            <tbody className="font-mono">
                              {result.elements.map((el) => (
                                <tr key={el.element} className="border-t border-purple-100">
                                  <td className="py-2">
                                    <span className="font-bold">{el.element}</span>
                                    <span className="text-xs text-muted-foreground ml-1">({el.name})</span>
                                  </td>
                                  <td className="py-2 text-right">{el.atomicWeight.toFixed(4)}</td>
                                  <td className="py-2 text-right">{el.count}</td>
                                  <td className="py-2 text-right font-medium">{el.contribution.toFixed(4)}</td>
                                </tr>
                              ))}
                              <tr className="border-t-2 border-purple-300 font-bold">
                                <td className="py-2" colSpan={2}>
                                  Total
                                </td>
                                <td className="py-2 text-right">{result.totalAtoms}</td>
                                <td className="py-2 text-right text-purple-600">{result.totalWeight.toFixed(4)}</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">M = Σ (Atomic Weight × Count)</p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-3">
                    The molecular weight is calculated by summing the atomic weights of all atoms in the formula.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Compounds</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {COMMON_COMPOUNDS.map((compound) => (
                      <button
                        key={compound.formula}
                        onClick={() => selectExample(compound)}
                        className="w-full flex items-center justify-between p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors text-left"
                      >
                        <span className="font-mono font-medium">{compound.formula}</span>
                        <span className="text-sm text-muted-foreground">{compound.name}</span>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Disclaimer</p>
                      <p className="text-sm text-amber-700 mt-1">
                        Atomic weights are based on standard average values from IUPAC and may vary slightly by isotope.
                        For precise measurements, consult official sources.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Molecular Weight?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Molecular weight (also called molar mass or molecular mass) is the sum of the atomic weights of all
                  atoms in a molecule. It is expressed in grams per mole (g/mol) and represents the mass of one mole
                  (6.022 × 10²³ particles) of that substance. Understanding molecular weight is fundamental to chemistry
                  as it allows scientists to convert between mass and moles, which is essential for stoichiometric
                  calculations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, water (H₂O) has a molecular weight of approximately 18.015 g/mol because it contains two
                  hydrogen atoms (2 × 1.008 = 2.016) and one oxygen atom (15.999), giving a total of 18.015 g/mol. This
                  means that 18.015 grams of water contains exactly one mole of water molecules.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use Chemical Formulas</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Chemical formulas use element symbols and subscript numbers to represent the composition of compounds.
                  Each element is represented by its one- or two-letter symbol (e.g., H for hydrogen, Ca for calcium),
                  and the subscript number indicates how many atoms of that element are present.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono font-medium">H₂O</p>
                    <p className="text-sm text-muted-foreground">2 hydrogen atoms + 1 oxygen atom</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono font-medium">Ca(OH)₂</p>
                    <p className="text-sm text-muted-foreground">
                      1 calcium + 2 oxygen + 2 hydrogen (parentheses multiply)
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono font-medium">CuSO₄·5H₂O</p>
                    <p className="text-sm text-muted-foreground">Copper sulfate with 5 water molecules (hydration)</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Molecular weight calculations are essential in many areas of science and industry:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Stoichiometry:</strong> Converting between mass and moles for chemical reactions
                  </li>
                  <li>
                    <strong>Solution Preparation:</strong> Calculating how much solute is needed for a specific molarity
                  </li>
                  <li>
                    <strong>Pharmacology:</strong> Determining drug dosages based on molecular composition
                  </li>
                  <li>
                    <strong>Polymer Chemistry:</strong> Characterizing and comparing polymer chains
                  </li>
                  <li>
                    <strong>Biochemistry:</strong> Analyzing proteins, DNA, and other biomolecules
                  </li>
                  <li>
                    <strong>Industrial Chemistry:</strong> Scaling reactions for manufacturing processes
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="space-y-2 text-muted-foreground">
                  <li>
                    <strong>Check element symbols:</strong> Use proper capitalization (e.g., Co for cobalt, CO for
                    carbon monoxide)
                  </li>
                  <li>
                    <strong>Parentheses matter:</strong> Ca(OH)₂ is different from CaOH₂
                  </li>
                  <li>
                    <strong>Include hydration:</strong> Some compounds include water of crystallization (e.g.,
                    CuSO₄·5H₂O)
                  </li>
                  <li>
                    <strong>Verify your formula:</strong> Double-check subscripts and element symbols before calculating
                  </li>
                  <li>
                    <strong>Consider significant figures:</strong> Atomic weights have inherent uncertainty, so report
                    results appropriately
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
