"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Volume2, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface SoundIntensityResult {
  intensity: number
  decibels: number
  category: string
  color: string
  bgColor: string
}

export function SoundIntensityCalculator() {
  const [power, setPower] = useState("")
  const [distance, setDistance] = useState("")
  const [referenceIntensity, setReferenceIntensity] = useState("1e-12")
  const [result, setResult] = useState<SoundIntensityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateSoundIntensity = () => {
    setError("")
    setResult(null)

    const powerNum = Number.parseFloat(power)
    const distanceNum = Number.parseFloat(distance)
    const referenceNum = Number.parseFloat(referenceIntensity)

    if (isNaN(powerNum) || powerNum <= 0) {
      setError("Please enter a valid sound power greater than 0")
      return
    }

    if (isNaN(distanceNum) || distanceNum <= 0) {
      setError("Please enter a valid distance greater than 0")
      return
    }

    if (isNaN(referenceNum) || referenceNum <= 0) {
      setError("Please enter a valid reference intensity greater than 0")
      return
    }

    // Calculate sound intensity: I = P / (4 × π × r²)
    const intensity = powerNum / (4 * Math.PI * distanceNum * distanceNum)

    // Calculate sound level in decibels: L = 10 × log₁₀(I / I₀)
    const decibels = 10 * Math.log10(intensity / referenceNum)

    // Categorize sound level
    let category: string
    let color: string
    let bgColor: string

    if (decibels < 30) {
      category = "Very Quiet"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (decibels < 60) {
      category = "Quiet"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (decibels < 85) {
      category = "Moderate"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (decibels < 110) {
      category = "Loud"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Very Loud"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      intensity: intensity,
      decibels: Math.round(decibels * 100) / 100,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setPower("")
    setDistance("")
    setReferenceIntensity("1e-12")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Sound Intensity: ${result.intensity.toExponential(2)} W/m², Sound Level: ${result.decibels} dB (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Sound Intensity Result",
          text: `Sound Intensity: ${result.intensity.toExponential(2)} W/m², Sound Level: ${result.decibels} dB`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                    <Volume2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Sound Intensity Calculator</CardTitle>
                    <CardDescription>Calculate acoustic intensity and sound level</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Sound Power Input */}
                <div className="space-y-2">
                  <Label htmlFor="power">Sound Power (W)</Label>
                  <Input
                    id="power"
                    type="number"
                    placeholder="Enter sound power in Watts"
                    value={power}
                    onChange={(e) => setPower(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                </div>

                {/* Distance Input */}
                <div className="space-y-2">
                  <Label htmlFor="distance">Distance from Source (m)</Label>
                  <Input
                    id="distance"
                    type="number"
                    placeholder="Enter distance in meters"
                    value={distance}
                    onChange={(e) => setDistance(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Reference Intensity Input */}
                <div className="space-y-2">
                  <Label htmlFor="reference">Reference Intensity I₀ (W/m²)</Label>
                  <Input
                    id="reference"
                    type="text"
                    placeholder="Default: 1×10⁻¹² W/m²"
                    value={referenceIntensity}
                    onChange={(e) => setReferenceIntensity(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Default is the threshold of human hearing</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSoundIntensity} className="w-full" size="lg">
                  Calculate Sound Intensity
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="space-y-3">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Sound Intensity</p>
                        <p className={`text-3xl font-bold ${result.color}`}>{result.intensity.toExponential(2)} W/m²</p>
                      </div>

                      <div className="text-center pt-2 border-t">
                        <p className="text-sm text-muted-foreground mb-1">Sound Level</p>
                        <p className={`text-4xl font-bold ${result.color}`}>{result.decibels} dB</p>
                        <p className={`text-lg font-semibold ${result.color} mt-1`}>{result.category}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>

                    {/* Step-by-Step Toggle */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-2">
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {/* Step-by-Step Breakdown */}
                    {showSteps && (
                      <div className="mt-3 p-3 bg-background/50 rounded-lg text-sm space-y-2">
                        <p className="font-semibold">Step-by-Step Calculation:</p>
                        <div className="space-y-1 text-muted-foreground">
                          <p>
                            <strong>Step 1:</strong> Calculate intensity using I = P / (4πr²)
                          </p>
                          <p className="pl-4">
                            I = {power} / (4 × π × {distance}²)
                          </p>
                          <p className="pl-4">I = {result.intensity.toExponential(2)} W/m²</p>
                          <p className="mt-2">
                            <strong>Step 2:</strong> Calculate sound level using L = 10 × log₁₀(I / I₀)
                          </p>
                          <p className="pl-4">
                            L = 10 × log₁₀({result.intensity.toExponential(2)} /{" "}
                            {Number.parseFloat(referenceIntensity).toExponential(2)})
                          </p>
                          <p className="pl-4">L = {result.decibels} dB</p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sound Level Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Very Quiet</span>
                      <span className="text-sm text-blue-600">{"< 30 dB"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Quiet</span>
                      <span className="text-sm text-green-600">30 – 60 dB</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate</span>
                      <span className="text-sm text-yellow-600">60 – 85 dB</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Loud</span>
                      <span className="text-sm text-orange-600">85 – 110 dB</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very Loud</span>
                      <span className="text-sm text-red-600">≥ 110 dB</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground mb-2">Sound Intensity:</p>
                    <p className="font-semibold text-foreground">I = P / (4πr²)</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground mb-2">Sound Level:</p>
                    <p className="font-semibold text-foreground">L = 10 × log₁₀(I / I₀)</p>
                  </div>
                  <p className="text-xs">
                    where P is power (W), r is distance (m), I is intensity (W/m²), I₀ is reference intensity (W/m²),
                    and L is sound level (dB)
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Sound Levels</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Whisper</span>
                      <span className="font-semibold">20 dB</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Normal Conversation</span>
                      <span className="font-semibold">60 dB</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Vacuum Cleaner</span>
                      <span className="font-semibold">70 dB</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Traffic Noise</span>
                      <span className="font-semibold">85 dB</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Chainsaw</span>
                      <span className="font-semibold">110 dB</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Rock Concert</span>
                      <span className="font-semibold">120 dB</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Sound Intensity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Sound Intensity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Sound intensity is a measure of the power per unit area carried by a sound wave. It quantifies how
                  much acoustic energy passes through a surface perpendicular to the direction of sound propagation.
                  Measured in watts per square meter (W/m²), sound intensity helps us understand how loud a sound is at
                  a specific location relative to its source.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In physics and acoustics, sound intensity follows the inverse square law, meaning it decreases with
                  the square of the distance from the source. This calculator helps you determine both the intensity and
                  the corresponding decibel level, which is a logarithmic scale more closely aligned with human
                  perception of loudness.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Volume2 className="h-5 w-5 text-primary" />
                  <CardTitle>Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Sound intensity calculations are essential in various fields including audio engineering,
                  environmental noise assessment, architectural acoustics, and occupational safety. Engineers use these
                  calculations to design speaker systems, evaluate noise pollution, and ensure compliance with workplace
                  safety regulations regarding noise exposure.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-900">Important Note</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-amber-800 leading-relaxed">
                  Sound intensity calculations assume an ideal point source in free space. Actual measurements may vary
                  due to reflections, absorption, and environmental conditions. Consult acoustics references for precise
                  analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
