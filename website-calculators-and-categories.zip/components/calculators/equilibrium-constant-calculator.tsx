"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Activity,
  Plus,
  Trash2,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type CalculationMode = "kc" | "kp" | "conversion"
type PressureUnit = "atm" | "Pa" | "kPa" | "bar"

interface Species {
  id: string
  name: string
  coefficient: string
  value: string
  isProduct: boolean
}

interface EquilibriumResult {
  equilibriumConstant: number
  constantType: string
  deltaN: number
  reactionDirection?: string
  productRatio?: number
}

export function EquilibriumConstantCalculator() {
  const [mode, setMode] = useState<CalculationMode>("kc")
  const [species, setSpecies] = useState<Species[]>([
    { id: "1", name: "A", coefficient: "1", value: "", isProduct: false },
    { id: "2", name: "B", coefficient: "1", value: "", isProduct: true },
  ])
  const [temperature, setTemperature] = useState("")
  const [knownK, setKnownK] = useState("")
  const [pressureUnit, setPressureUnit] = useState<PressureUnit>("atm")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<EquilibriumResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const R = 0.0821 // L·atm/(mol·K) for Kp calculations

  const modeLabels: Record<CalculationMode, string> = {
    kc: "Equilibrium Constant (Kc)",
    kp: "Equilibrium Constant (Kp)",
    conversion: "Kc ↔ Kp Conversion",
  }

  const addSpecies = (isProduct: boolean) => {
    const newId = Date.now().toString()
    const defaultName = isProduct ? `P${species.filter(s => s.isProduct).length + 1}` : `R${species.filter(s => !s.isProduct).length + 1}`
    setSpecies([...species, { id: newId, name: defaultName, coefficient: "1", value: "", isProduct }])
  }

  const removeSpecies = (id: string) => {
    if (species.length > 2) {
      setSpecies(species.filter(s => s.id !== id))
    }
  }

  const updateSpecies = (id: string, field: keyof Species, value: string | boolean) => {
    setSpecies(species.map(s => s.id === id ? { ...s, [field]: value } : s))
  }

  const convertPressure = (value: number, fromUnit: PressureUnit): number => {
    // Convert to atm first
    const toAtm: Record<PressureUnit, number> = {
      atm: 1,
      Pa: 1 / 101325,
      kPa: 1 / 101.325,
      bar: 1 / 1.01325,
    }
    return value * toAtm[fromUnit]
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const reactants = species.filter(s => !s.isProduct)
    const products = species.filter(s => s.isProduct)

    if (reactants.length === 0 || products.length === 0) {
      setError("You need at least one reactant and one product")
      return
    }

    // Validate all species have values and coefficients
    for (const s of species) {
      const coef = Number.parseFloat(s.coefficient)
      const val = Number.parseFloat(s.value)
      
      if (isNaN(coef) || coef <= 0) {
        setError(`Please enter a valid positive coefficient for ${s.name || "species"}`)
        return
      }
      if (mode !== "conversion") {
        if (isNaN(val) || val < 0) {
          setError(`Please enter a valid ${mode === "kc" ? "concentration" : "pressure"} for ${s.name || "species"}`)
          return
        }
        if (val === 0 && !s.isProduct) {
          setError(`Reactant ${s.name || "species"} cannot have zero concentration/pressure`)
          return
        }
      }
    }

    if (mode === "conversion") {
      // Kc ↔ Kp conversion
      const T = Number.parseFloat(temperature)
      const K = Number.parseFloat(knownK)

      if (isNaN(T) || T <= 0) {
        setError("Please enter a valid temperature in Kelvin (greater than 0)")
        return
      }
      if (isNaN(K) || K <= 0) {
        setError("Please enter a valid equilibrium constant (greater than 0)")
        return
      }

      // Calculate Δn (change in moles of gas)
      const nProducts = products.reduce((sum, s) => sum + Number.parseFloat(s.coefficient), 0)
      const nReactants = reactants.reduce((sum, s) => sum + Number.parseFloat(s.coefficient), 0)
      const deltaN = nProducts - nReactants

      // Kp = Kc × (RT)^Δn, so Kc = Kp / (RT)^Δn
      const conversionFactor = Math.pow(R * T, deltaN)
      const convertedK = K * conversionFactor

      setResult({
        equilibriumConstant: convertedK,
        constantType: "Kp (from Kc)",
        deltaN,
      })
    } else {
      // Calculate Kc or Kp
      let numerator = 1
      let denominator = 1

      for (const p of products) {
        const val = Number.parseFloat(p.value)
        const coef = Number.parseFloat(p.coefficient)
        const adjustedVal = mode === "kp" ? convertPressure(val, pressureUnit) : val
        numerator *= Math.pow(adjustedVal, coef)
      }

      for (const r of reactants) {
        const val = Number.parseFloat(r.value)
        const coef = Number.parseFloat(r.coefficient)
        const adjustedVal = mode === "kp" ? convertPressure(val, pressureUnit) : val
        denominator *= Math.pow(adjustedVal, coef)
      }

      if (denominator === 0) {
        setError("Reactant concentrations/pressures cannot all be zero")
        return
      }

      const K = numerator / denominator

      // Calculate Δn
      const nProducts = products.reduce((sum, s) => sum + Number.parseFloat(s.coefficient), 0)
      const nReactants = reactants.reduce((sum, s) => sum + Number.parseFloat(s.coefficient), 0)
      const deltaN = nProducts - nReactants

      // Determine reaction direction
      let reactionDirection = ""
      if (K > 1) {
        reactionDirection = "Products favored (K > 1)"
      } else if (K < 1) {
        reactionDirection = "Reactants favored (K < 1)"
      } else {
        reactionDirection = "Neither favored (K ≈ 1)"
      }

      setResult({
        equilibriumConstant: K,
        constantType: mode === "kc" ? "Kc" : "Kp",
        deltaN,
        reactionDirection,
        productRatio: numerator / (numerator + denominator) * 100,
      })
    }
  }

  const handleReset = () => {
    setSpecies([
      { id: "1", name: "A", coefficient: "1", value: "", isProduct: false },
      { id: "2", name: "B", coefficient: "1", value: "", isProduct: true },
    ])
    setTemperature("")
    setKnownK("")
    setShowSteps(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Equilibrium Constant Calculator Result:
Mode: ${modeLabels[mode]}
${result.constantType}: ${formatNumber(result.equilibriumConstant)}
Δn (change in moles): ${result.deltaN}
${result.reactionDirection ? `Reaction Direction: ${result.reactionDirection}` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Equilibrium Constant Calculator Result",
          text: `${result.constantType}: ${formatNumber(result.equilibriumConstant)} | Δn: ${result.deltaN}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number, decimals = 6): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.000001 || Math.abs(num) >= 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: decimals })
  }

  const getStepByStepCalculation = () => {
    if (!result) return []
    const steps: string[] = []

    const reactants = species.filter(s => !s.isProduct)
    const products = species.filter(s => s.isProduct)

    if (mode === "conversion") {
      steps.push("Kc ↔ Kp Conversion Formula:")
      steps.push("Kp = Kc × (R × T)^Δn")
      steps.push("")
      steps.push(`Given: K = ${knownK}`)
      steps.push(`Given: T = ${temperature} K`)
      steps.push(`R = 0.0821 L·atm/(mol·K)`)
      steps.push("")
      steps.push("Calculate Δn (change in moles of gas):")
      steps.push(`Δn = Σn(products) − Σn(reactants)`)
      const nProducts = products.reduce((sum, s) => sum + Number.parseFloat(s.coefficient), 0)
      const nReactants = reactants.reduce((sum, s) => sum + Number.parseFloat(s.coefficient), 0)
      steps.push(`Δn = ${nProducts} − ${nReactants} = ${result.deltaN}`)
      steps.push("")
      steps.push(`Conversion factor = (R × T)^Δn`)
      steps.push(`= (0.0821 × ${temperature})^${result.deltaN}`)
      steps.push(`= ${formatNumber(Math.pow(R * Number.parseFloat(temperature), result.deltaN))}`)
      steps.push("")
      steps.push(`Kp = Kc × ${formatNumber(Math.pow(R * Number.parseFloat(temperature), result.deltaN))}`)
      steps.push(`Kp = ${formatNumber(result.equilibriumConstant)}`)
    } else {
      const valueLabel = mode === "kc" ? "concentration" : "partial pressure"
      const unit = mode === "kc" ? "M" : pressureUnit

      steps.push(`Equilibrium Constant (${mode === "kc" ? "Kc" : "Kp"}) Formula:`)
      steps.push(`K = [Products]^coefficients / [Reactants]^coefficients`)
      steps.push("")
      
      // Build the formula representation
      const productTerms = products.map(p => `[${p.name}]^${p.coefficient}`).join(" × ")
      const reactantTerms = reactants.map(r => `[${r.name}]^${r.coefficient}`).join(" × ")
      steps.push(`K = (${productTerms}) / (${reactantTerms})`)
      steps.push("")

      steps.push("Given values:")
      for (const s of species) {
        steps.push(`  ${s.isProduct ? "Product" : "Reactant"} ${s.name}: ${s.value} ${unit} (coefficient: ${s.coefficient})`)
      }
      steps.push("")

      // Numerator calculation
      steps.push("Numerator (Products):")
      let numStr = ""
      for (const p of products) {
        numStr += `(${p.value})^${p.coefficient} × `
      }
      numStr = numStr.slice(0, -3)
      steps.push(`  = ${numStr}`)
      
      let numerator = 1
      for (const p of products) {
        const val = Number.parseFloat(p.value)
        const coef = Number.parseFloat(p.coefficient)
        numerator *= Math.pow(val, coef)
      }
      steps.push(`  = ${formatNumber(numerator)}`)
      steps.push("")

      // Denominator calculation
      steps.push("Denominator (Reactants):")
      let denStr = ""
      for (const r of reactants) {
        denStr += `(${r.value})^${r.coefficient} × `
      }
      denStr = denStr.slice(0, -3)
      steps.push(`  = ${denStr}`)
      
      let denominator = 1
      for (const r of reactants) {
        const val = Number.parseFloat(r.value)
        const coef = Number.parseFloat(r.coefficient)
        denominator *= Math.pow(val, coef)
      }
      steps.push(`  = ${formatNumber(denominator)}`)
      steps.push("")

      steps.push(`K = ${formatNumber(numerator)} / ${formatNumber(denominator)}`)
      steps.push(`K = ${formatNumber(result.equilibriumConstant)}`)
    }

    return steps
  }

  const reactants = species.filter(s => !s.isProduct)
  const products = species.filter(s => s.isProduct)

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Equilibrium Constant Calculator</CardTitle>
                    <CardDescription>Calculate Kc or Kp for chemical equilibrium</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Mode */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select value={mode} onValueChange={(v) => setMode(v as CalculationMode)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select calculation mode" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kc">Kc (Concentration-based)</SelectItem>
                      <SelectItem value="kp">Kp (Pressure-based)</SelectItem>
                      <SelectItem value="conversion">Kc ↔ Kp Conversion</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Pressure Unit (for Kp mode) */}
                {mode === "kp" && (
                  <div className="space-y-2">
                    <Label>Pressure Unit</Label>
                    <Select value={pressureUnit} onValueChange={(v) => setPressureUnit(v as PressureUnit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="atm">Atmospheres (atm)</SelectItem>
                        <SelectItem value="Pa">Pascals (Pa)</SelectItem>
                        <SelectItem value="kPa">Kilopascals (kPa)</SelectItem>
                        <SelectItem value="bar">Bar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Conversion Mode Inputs */}
                {mode === "conversion" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="knownK">Known Equilibrium Constant (Kc)</Label>
                      <Input
                        id="knownK"
                        type="number"
                        placeholder="Enter known Kc value"
                        value={knownK}
                        onChange={(e) => setKnownK(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="temperature">Temperature (K)</Label>
                      <Input
                        id="temperature"
                        type="number"
                        placeholder="Enter temperature in Kelvin"
                        value={temperature}
                        onChange={(e) => setTemperature(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Reactants Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Reactants</Label>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => addSpecies(false)}
                      className="h-8"
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Add
                    </Button>
                  </div>
                  {reactants.map((s) => (
                    <div key={s.id} className="grid grid-cols-12 gap-2 items-end p-3 bg-muted/50 rounded-lg">
                      <div className="col-span-3">
                        <Label className="text-xs">Name</Label>
                        <Input
                          value={s.name}
                          onChange={(e) => updateSpecies(s.id, "name", e.target.value)}
                          placeholder="A"
                          className="h-9"
                        />
                      </div>
                      <div className="col-span-3">
                        <Label className="text-xs">Coefficient</Label>
                        <Input
                          type="number"
                          value={s.coefficient}
                          onChange={(e) => updateSpecies(s.id, "coefficient", e.target.value)}
                          placeholder="1"
                          min="1"
                          className="h-9"
                        />
                      </div>
                      {mode !== "conversion" && (
                        <div className="col-span-4">
                          <Label className="text-xs">{mode === "kc" ? "Conc. (M)" : `Press. (${pressureUnit})`}</Label>
                          <Input
                            type="number"
                            value={s.value}
                            onChange={(e) => updateSpecies(s.id, "value", e.target.value)}
                            placeholder="0.1"
                            min="0"
                            step="any"
                            className="h-9"
                          />
                        </div>
                      )}
                      <div className={mode !== "conversion" ? "col-span-2" : "col-span-6"}>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeSpecies(s.id)}
                          disabled={species.length <= 2}
                          className="h-9 w-full text-red-500 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Products Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Products</Label>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => addSpecies(true)}
                      className="h-8"
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Add
                    </Button>
                  </div>
                  {products.map((s) => (
                    <div key={s.id} className="grid grid-cols-12 gap-2 items-end p-3 bg-muted/50 rounded-lg">
                      <div className="col-span-3">
                        <Label className="text-xs">Name</Label>
                        <Input
                          value={s.name}
                          onChange={(e) => updateSpecies(s.id, "name", e.target.value)}
                          placeholder="B"
                          className="h-9"
                        />
                      </div>
                      <div className="col-span-3">
                        <Label className="text-xs">Coefficient</Label>
                        <Input
                          type="number"
                          value={s.coefficient}
                          onChange={(e) => updateSpecies(s.id, "coefficient", e.target.value)}
                          placeholder="1"
                          min="1"
                          className="h-9"
                        />
                      </div>
                      {mode !== "conversion" && (
                        <div className="col-span-4">
                          <Label className="text-xs">{mode === "kc" ? "Conc. (M)" : `Press. (${pressureUnit})`}</Label>
                          <Input
                            type="number"
                            value={s.value}
                            onChange={(e) => updateSpecies(s.id, "value", e.target.value)}
                            placeholder="0.5"
                            min="0"
                            step="any"
                            className="h-9"
                          />
                        </div>
                      )}
                      <div className={mode !== "conversion" ? "col-span-2" : "col-span-6"}>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeSpecies(s.id)}
                          disabled={species.length <= 2}
                          className="h-9 w-full text-red-500 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show Step-by-Step Solution</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {modeLabels[mode]}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">{result.constantType}</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">
                        {formatNumber(result.equilibriumConstant)}
                      </p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Δn (moles)</p>
                        <p className="font-semibold text-purple-600">{result.deltaN}</p>
                      </div>
                      {result.reactionDirection && (
                        <div className="p-3 bg-white rounded-lg text-center">
                          <p className="text-xs text-muted-foreground">Direction</p>
                          <p className="font-semibold text-purple-600 text-xs">
                            {result.reactionDirection.split(" ")[0]}
                          </p>
                        </div>
                      )}
                    </div>

                    {result.reactionDirection && (
                      <div className="p-3 bg-white rounded-lg text-center mb-4">
                        <p className="text-sm text-purple-700">{result.reactionDirection}</p>
                      </div>
                    )}

                    {/* Step-by-Step Breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-purple-100">
                        <p className="font-medium text-sm mb-2 text-purple-700">Step-by-Step Solution:</p>
                        <div className="text-xs space-y-1 text-muted-foreground font-mono">
                          {getStepByStepCalculation().map((step, index) => (
                            <p
                              key={index}
                              className={
                                step.startsWith("K =") || step.startsWith("Kp =") || step.startsWith("Kc =")
                                  ? "text-purple-600 font-semibold"
                                  : step === ""
                                  ? "h-2"
                                  : ""
                              }
                            >
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Equilibrium Constant Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-mono font-semibold text-purple-700 text-center text-sm">
                      Kc = [C]^c[D]^d / [A]^a[B]^b
                    </p>
                    <p className="text-xs text-purple-600 text-center mt-1">Concentration-based (aA + bB ⇌ cC + dD)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-mono font-semibold text-purple-700 text-center text-sm">
                      Kp = Kc × (RT)^Δn
                    </p>
                    <p className="text-xs text-purple-600 text-center mt-1">Kc to Kp Conversion</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p><strong>Kc</strong> = Equilibrium constant (concentrations)</p>
                    <p><strong>Kp</strong> = Equilibrium constant (pressures)</p>
                    <p><strong>R</strong> = 0.0821 L·atm/(mol·K)</p>
                    <p><strong>Δn</strong> = n(products) − n(reactants)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Info className="h-5 w-5" />
                    Understanding Equilibrium Constants
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div>
                    <p className="font-medium text-foreground mb-1">What does K tell us?</p>
                    <p>
                      The equilibrium constant K indicates the relative amounts of products and reactants at equilibrium.
                      A large K (&gt;1) means products are favored; a small K (&lt;1) means reactants are favored.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Kc vs Kp</p>
                    <p>
                      Kc uses molar concentrations and applies to all reactions. Kp uses partial pressures and only
                      applies to gas-phase reactions. They are related through the equation Kp = Kc(RT)^Δn.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Temperature Dependence</p>
                    <p>
                      K only changes with temperature. For exothermic reactions, K decreases as T increases.
                      For endothermic reactions, K increases as T increases.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Interpreting K Values
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>K &gt;&gt; 1</span>
                    <span className="font-mono text-green-600">Products strongly favored</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>K &gt; 1</span>
                    <span className="font-mono text-green-600">Products favored</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>K ≈ 1</span>
                    <span className="font-mono text-yellow-600">Neither favored</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>K &lt; 1</span>
                    <span className="font-mono text-red-600">Reactants favored</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="space-y-2 text-sm text-amber-900">
                      <p className="font-medium">Important Note</p>
                      <p>
                        Calculations assume ideal solutions or gases and equilibrium conditions. Real systems may
                        deviate due to activity coefficients or non-ideal behavior. Only include gaseous or aqueous
                        species in calculations; pure solids and liquids are excluded.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Information Section */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Chemical Equilibrium?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Chemical equilibrium is a dynamic state where the rates of the forward and reverse reactions are
                  equal, resulting in no net change in the concentrations of reactants and products over time. At
                  equilibrium, both reactions continue to occur, but they proceed at the same rate, maintaining
                  constant concentrations. The equilibrium constant K quantifies the ratio of product concentrations
                  to reactant concentrations at this state.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equilibrium constant is a fundamental concept in chemistry that helps predict reaction behavior,
                  determine optimal conditions for industrial processes, and understand biological systems. It is
                  temperature-dependent and characteristic of each specific reaction under given conditions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Equilibrium Constants</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Equilibrium constants are essential in many fields. In industrial chemistry, they help optimize
                  conditions for reactions like the Haber process (ammonia synthesis) and contact process (sulfuric
                  acid production). Engineers use K values to design reactors and determine optimal temperature and
                  pressure conditions for maximum product yield.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In biochemistry, equilibrium constants describe enzyme-substrate binding, protein folding, and
                  metabolic pathways. Environmental scientists use them to model pollutant distribution between
                  different environmental phases. Understanding K values is crucial for predicting how systems
                  respond to changes in conditions according to Le Chatelier&apos;s principle.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
