"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Dumbbell,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Droplets,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Goal = "muscle-gain" | "strength" | "endurance" | "maintenance"

interface CreatineResult {
  loadingDailyDose: number
  loadingServings: number
  maintenanceDailyDose: number
  maintenanceServings: number
  loadingDuration: number
  totalCreatineLoading: number
  totalCreatineMaintenance: number
  totalCreatine: number
  weightKg: number
}

export function CreatineDosageCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [goal, setGoal] = useState<Goal>("muscle-gain")
  const [useLoadingPhase, setUseLoadingPhase] = useState(true)
  const [supplementationDuration, setSupplementationDuration] = useState("")
  const [result, setResult] = useState<CreatineResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateCreatine = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    const ageNum = Number.parseFloat(age)
    if (isNaN(ageNum) || ageNum < 16 || ageNum > 100) {
      setError("Please enter a valid age between 16 and 100")
      return
    }

    // Convert to kg if imperial
    const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Standard dosage recommendations
    // Loading phase: 0.3 g/kg/day for 5-7 days
    // Maintenance phase: 0.03 g/kg/day (typically 3-5g/day)
    const loadingDosePerKg = 0.3 // g/kg/day
    const maintenanceDosePerKg = 0.03 // g/kg/day

    // Calculate loading phase dose
    let loadingDailyDose = weightKg * loadingDosePerKg
    // Cap at reasonable maximum (25g/day)
    loadingDailyDose = Math.min(loadingDailyDose, 25)
    loadingDailyDose = Math.round(loadingDailyDose * 10) / 10

    // Calculate maintenance dose
    let maintenanceDailyDose = weightKg * maintenanceDosePerKg
    // Ensure minimum of 3g and maximum of 10g for maintenance
    maintenanceDailyDose = Math.max(maintenanceDailyDose, 3)
    maintenanceDailyDose = Math.min(maintenanceDailyDose, 10)

    // Adjust based on goal
    const goalMultipliers: Record<Goal, number> = {
      "muscle-gain": 1.0,
      strength: 1.1,
      endurance: 0.9,
      maintenance: 0.85,
    }
    maintenanceDailyDose = maintenanceDailyDose * goalMultipliers[goal]
    maintenanceDailyDose = Math.round(maintenanceDailyDose * 10) / 10

    // Calculate servings (typically 5g per serving)
    const loadingServings = Math.ceil(loadingDailyDose / 5)
    const maintenanceServings = Math.ceil(maintenanceDailyDose / 5)

    // Loading phase duration (5-7 days, use 7 for standard)
    const loadingDuration = 7

    // Calculate total creatine needed
    const durationWeeks = Number.parseFloat(supplementationDuration) || 8
    const totalLoadingDays = useLoadingPhase ? loadingDuration : 0
    const totalMaintenanceDays = durationWeeks * 7 - totalLoadingDays

    const totalCreatineLoading = useLoadingPhase ? loadingDailyDose * loadingDuration : 0
    const totalCreatineMaintenance = maintenanceDailyDose * totalMaintenanceDays
    const totalCreatine = totalCreatineLoading + totalCreatineMaintenance

    setResult({
      loadingDailyDose,
      loadingServings,
      maintenanceDailyDose,
      maintenanceServings,
      loadingDuration,
      totalCreatineLoading: Math.round(totalCreatineLoading),
      totalCreatineMaintenance: Math.round(totalCreatineMaintenance),
      totalCreatine: Math.round(totalCreatine),
      weightKg: Math.round(weightKg * 10) / 10,
    })
  }

  const handleReset = () => {
    setWeight("")
    setAge("")
    setGender("male")
    setGoal("muscle-gain")
    setUseLoadingPhase(true)
    setSupplementationDuration("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = useLoadingPhase
        ? `Creatine Dosage Plan:\nLoading Phase: ${result.loadingDailyDose}g/day for ${result.loadingDuration} days\nMaintenance Phase: ${result.maintenanceDailyDose}g/day\nTotal Creatine Needed: ${result.totalCreatine}g`
        : `Creatine Dosage Plan:\nDaily Dose: ${result.maintenanceDailyDose}g/day\nTotal Creatine Needed: ${result.totalCreatine}g`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Creatine Dosage Plan",
          text: `I calculated my creatine dosage using CalcHub! ${useLoadingPhase ? `Loading: ${result.loadingDailyDose}g/day, ` : ""}Maintenance: ${result.maintenanceDailyDose}g/day`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Dumbbell className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Creatine Dosage Calculator</CardTitle>
                    <CardDescription>Calculate your optimal creatine supplementation</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="16"
                    max="100"
                  />
                </div>

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setGender("male")}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        gender === "male"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted-foreground/20 hover:border-muted-foreground/40"
                      }`}
                    >
                      <span className="font-medium">Male</span>
                    </button>
                    <button
                      onClick={() => setGender("female")}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        gender === "female"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted-foreground/20 hover:border-muted-foreground/40"
                      }`}
                    >
                      <span className="font-medium">Female</span>
                    </button>
                  </div>
                </div>

                {/* Goal Selection */}
                <div className="space-y-2">
                  <Label>Fitness Goal</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "muscle-gain", label: "Muscle Gain" },
                      { value: "strength", label: "Strength" },
                      { value: "endurance", label: "Endurance" },
                      { value: "maintenance", label: "Maintenance" },
                    ].map((option) => (
                      <button
                        key={option.value}
                        onClick={() => setGoal(option.value as Goal)}
                        className={`p-3 rounded-lg border-2 transition-all text-sm ${
                          goal === option.value
                            ? "border-primary bg-primary/5 text-primary"
                            : "border-muted-foreground/20 hover:border-muted-foreground/40"
                        }`}
                      >
                        <span className="font-medium">{option.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Loading Phase Toggle */}
                <div className="space-y-2">
                  <Label>Loading Phase</Label>
                  <button
                    onClick={() => setUseLoadingPhase(!useLoadingPhase)}
                    className="w-full flex items-center justify-between p-3 rounded-lg border-2 border-muted-foreground/20 hover:border-muted-foreground/40 transition-all"
                  >
                    <span className="text-sm">Use loading phase (5-7 days)</span>
                    <div
                      className={`w-10 h-6 rounded-full p-1 transition-colors ${
                        useLoadingPhase ? "bg-primary" : "bg-muted-foreground/30"
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transition-transform ${
                          useLoadingPhase ? "translate-x-4" : "translate-x-0"
                        }`}
                      />
                    </div>
                  </button>
                </div>

                {/* Duration Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Supplementation Duration (weeks) - Optional</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Default: 8 weeks"
                    value={supplementationDuration}
                    onChange={(e) => setSupplementationDuration(e.target.value)}
                    min="1"
                    max="52"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCreatine} className="w-full" size="lg">
                  Calculate Dosage
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Daily Maintenance Dose</p>
                      <p className="text-5xl font-bold text-green-600 mb-2">{result.maintenanceDailyDose}g</p>
                      <p className="text-lg font-semibold text-green-600">
                        {result.maintenanceServings} serving{result.maintenanceServings > 1 ? "s" : ""} per day
                      </p>
                    </div>

                    {useLoadingPhase && (
                      <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm font-semibold text-blue-700 text-center">Loading Phase</p>
                        <p className="text-2xl font-bold text-blue-600 text-center">{result.loadingDailyDose}g/day</p>
                        <p className="text-sm text-blue-600 text-center">
                          for {result.loadingDuration} days ({result.loadingServings} servings/day)
                        </p>
                      </div>
                    )}

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 space-y-3 text-sm">
                        <div className="grid grid-cols-2 gap-2">
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Body Weight</p>
                            <p className="font-semibold">{result.weightKg} kg</p>
                          </div>
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Goal</p>
                            <p className="font-semibold capitalize">{goal.replace("-", " ")}</p>
                          </div>
                        </div>
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-muted-foreground mb-2">Total Creatine Needed</p>
                          <div className="space-y-1">
                            {useLoadingPhase && (
                              <div className="flex justify-between">
                                <span>Loading Phase:</span>
                                <span className="font-medium">{result.totalCreatineLoading}g</span>
                              </div>
                            )}
                            <div className="flex justify-between">
                              <span>Maintenance Phase:</span>
                              <span className="font-medium">{result.totalCreatineMaintenance}g</span>
                            </div>
                            <div className="flex justify-between border-t pt-1 mt-1">
                              <span className="font-semibold">Total:</span>
                              <span className="font-bold text-green-600">{result.totalCreatine}g</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dosage Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Loading Phase</span>
                      <span className="text-sm text-blue-600">0.3 g/kg/day × 5-7 days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Maintenance</span>
                      <span className="text-sm text-green-600">3-5 g/day (0.03 g/kg)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">No Loading</span>
                      <span className="text-sm text-purple-600">3-5 g/day (slower saturation)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Optimal Timing</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Post-Workout (Recommended)</p>
                    <p>
                      Taking creatine after exercise may enhance uptake due to increased blood flow and insulin
                      sensitivity.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">With Carbohydrates</p>
                    <p>Consuming creatine with carbs or protein can improve absorption through insulin response.</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Consistency Matters</p>
                    <p>Take creatine daily at the same time for best results, even on rest days.</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Droplets className="h-5 w-5 text-blue-500" />
                    Hydration Note
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    Creatine draws water into muscle cells. Increase your water intake by{" "}
                    <strong>16-24 oz (500-700ml)</strong> per day when supplementing to stay properly hydrated and
                    maximize benefits.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Creatine?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Creatine is a naturally occurring compound found in muscle cells that helps produce energy during
                  high-intensity exercise and heavy lifting. It is one of the most researched and effective supplements
                  for improving strength, power output, and muscle mass. Your body produces creatine from amino acids,
                  and it can also be obtained from dietary sources like red meat and fish.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When you supplement with creatine, you increase your muscles' phosphocreatine stores, which helps
                  regenerate ATP (adenosine triphosphate) - the primary energy currency of cells. This allows you to
                  perform more reps, lift heavier weights, and recover faster between sets, ultimately leading to
                  greater gains in strength and muscle mass over time.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Dumbbell className="h-5 w-5 text-primary" />
                  <CardTitle>Loading vs. No Loading Phase</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The loading phase involves taking a higher dose (typically 20-25g/day split into 4-5 servings) for 5-7
                  days to rapidly saturate your muscles with creatine. This approach allows you to experience the
                  benefits of creatine supplementation within about a week. After the loading phase, you transition to a
                  maintenance dose of 3-5g per day.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Alternatively, you can skip the loading phase and simply take 3-5g per day from the start. This
                  approach will still fully saturate your muscles with creatine, but it takes approximately 3-4 weeks to
                  reach the same saturation levels. Both methods are equally effective in the long run; the loading
                  phase simply gets you there faster.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-amber-800 text-sm leading-relaxed">
                    Creatine dosage recommendations provided by this calculator are general guidelines for healthy
                    adults. While creatine is one of the safest and most well-researched supplements, individual
                    responses may vary. Consult a healthcare professional before starting creatine supplementation,
                    especially if you have kidney disease, liver disease, diabetes, or are pregnant or breastfeeding.
                    Stop use if you experience any adverse effects. This calculator is for informational purposes only
                    and is not a substitute for professional medical advice.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
