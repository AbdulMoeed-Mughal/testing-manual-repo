"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  Home,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Percent,
  Calculator,
  Building,
  Activity,
  Shield,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface DownPaymentResult {
  downPaymentAmount: number
  downPaymentPercent: number
  loanAmount: number
  ltvRatio: number
  requiresPMI: boolean
  estimatedPMI: number
  minimumRecommended: number
  minimumRecommendedPercent: number
  closingCostsEstimate: number
  totalCashNeeded: number
}

interface ComparisonScenario {
  percent: number
  amount: number
  loanAmount: number
  requiresPMI: boolean
  monthlyPMI: number
}

const LOAN_TYPES = [
  { value: "conventional", label: "Conventional", minDown: 3 },
  { value: "fha", label: "FHA", minDown: 3.5 },
  { value: "va", label: "VA", minDown: 0 },
  { value: "usda", label: "USDA", minDown: 0 },
]

export function DownPaymentCalculator() {
  const [homePrice, setHomePrice] = useState("")
  const [downPayment, setDownPayment] = useState("")
  const [downPaymentType, setDownPaymentType] = useState<"amount" | "percent">("percent")
  const [loanType, setLoanType] = useState("conventional")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [closingCostRate, setClosingCostRate] = useState("3")
  const [result, setResult] = useState<DownPaymentResult | null>(null)
  const [comparison, setComparison] = useState<ComparisonScenario[]>([])
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)
  const [showComparison, setShowComparison] = useState(false)

  const calculateDownPayment = () => {
    setError("")
    setResult(null)
    setComparison([])

    const price = Number.parseFloat(homePrice)
    const dp = Number.parseFloat(downPayment)
    const closingRate = Number.parseFloat(closingCostRate) || 3

    // Validation
    if (!homePrice || price <= 0) {
      setError("Please enter a valid home price")
      return
    }

    if (!downPayment || dp < 0) {
      setError("Please enter a valid down payment")
      return
    }

    // Get minimum down payment for loan type
    const selectedLoan = LOAN_TYPES.find((l) => l.value === loanType)
    const minDownPercent = selectedLoan?.minDown || 3

    // Calculate down payment amount and percentage
    let downPaymentAmount: number
    let downPaymentPercent: number

    if (downPaymentType === "percent") {
      if (dp > 100) {
        setError("Down payment percentage cannot exceed 100%")
        return
      }
      downPaymentPercent = dp
      downPaymentAmount = price * (dp / 100)
    } else {
      if (dp > price) {
        setError("Down payment cannot exceed home price")
        return
      }
      downPaymentAmount = dp
      downPaymentPercent = (dp / price) * 100
    }

    // Validate minimum down payment
    if (downPaymentPercent < minDownPercent) {
      setError(`${selectedLoan?.label} loans require a minimum ${minDownPercent}% down payment`)
      return
    }

    // Calculate loan amount
    const loanAmount = price - downPaymentAmount

    // Calculate LTV ratio
    const ltvRatio = (loanAmount / price) * 100

    // Determine if PMI is required (typically for LTV > 80%)
    const requiresPMI = ltvRatio > 80 && loanType !== "va"

    // Estimate PMI (approximately 0.5-1% of loan amount annually)
    const annualPMI = requiresPMI ? loanAmount * 0.007 : 0
    const estimatedPMI = annualPMI / 12

    // Calculate minimum recommended (20% to avoid PMI for conventional)
    const minimumRecommendedPercent = loanType === "conventional" ? 20 : minDownPercent
    const minimumRecommended = price * (minimumRecommendedPercent / 100)

    // Estimate closing costs (typically 2-5% of home price)
    const closingCostsEstimate = price * (closingRate / 100)

    // Total cash needed at closing
    const totalCashNeeded = downPaymentAmount + closingCostsEstimate

    setResult({
      downPaymentAmount,
      downPaymentPercent,
      loanAmount,
      ltvRatio,
      requiresPMI,
      estimatedPMI,
      minimumRecommended,
      minimumRecommendedPercent,
      closingCostsEstimate,
      totalCashNeeded,
    })

    // Generate comparison scenarios
    const scenarios: ComparisonScenario[] = []
    const percentages = [5, 10, 15, 20, 25]
    for (const pct of percentages) {
      if (pct >= minDownPercent) {
        const amt = price * (pct / 100)
        const loan = price - amt
        const ltv = (loan / price) * 100
        const needsPMI = ltv > 80 && loanType !== "va"
        const pmi = needsPMI ? (loan * 0.007) / 12 : 0
        scenarios.push({
          percent: pct,
          amount: amt,
          loanAmount: loan,
          requiresPMI: needsPMI,
          monthlyPMI: pmi,
        })
      }
    }
    setComparison(scenarios)
  }

  const handleReset = () => {
    setHomePrice("")
    setDownPayment("")
    setDownPaymentType("percent")
    setLoanType("conventional")
    setShowAdvanced(false)
    setClosingCostRate("3")
    setResult(null)
    setComparison([])
    setError("")
    setCopied(false)
    setShowDetails(false)
    setShowComparison(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Down Payment Summary:\nHome Price: ${formatCurrency(Number.parseFloat(homePrice))}\nDown Payment: ${formatCurrency(result.downPaymentAmount)} (${result.downPaymentPercent.toFixed(1)}%)\nLoan Amount: ${formatCurrency(result.loanAmount)}\nLTV Ratio: ${result.ltvRatio.toFixed(1)}%\nPMI Required: ${result.requiresPMI ? "Yes" : "No"}\nTotal Cash Needed: ${formatCurrency(result.totalCashNeeded)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Down Payment Calculation",
          text: `For a ${formatCurrency(Number.parseFloat(homePrice))} home, I need ${formatCurrency(result.downPaymentAmount)} down payment (${result.downPaymentPercent.toFixed(1)}%)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  const getLTVColor = (ltv: number) => {
    if (ltv <= 80) return "bg-green-50 border-green-200 text-green-700"
    if (ltv <= 90) return "bg-yellow-50 border-yellow-200 text-yellow-700"
    return "bg-red-50 border-red-200 text-red-700"
  }

  const getLTVLabel = (ltv: number) => {
    if (ltv <= 80) return "Excellent - No PMI Required"
    if (ltv <= 90) return "Good - PMI Required"
    return "High LTV - Higher PMI"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Down Payment Calculator</CardTitle>
                    <CardDescription>Calculate your home down payment</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Home Price */}
                <div className="space-y-2">
                  <Label htmlFor="homePrice">Home Price ($)</Label>
                  <Input
                    id="homePrice"
                    type="number"
                    placeholder="e.g., 400000"
                    value={homePrice}
                    onChange={(e) => setHomePrice(e.target.value)}
                    min="0"
                    step="1000"
                  />
                </div>

                {/* Down Payment */}
                <div className="space-y-2">
                  <Label>Down Payment</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder={downPaymentType === "percent" ? "20" : "80000"}
                      value={downPayment}
                      onChange={(e) => setDownPayment(e.target.value)}
                      min="0"
                      className="flex-1"
                    />
                    <div className="flex border rounded-lg overflow-hidden">
                      <Button
                        type="button"
                        variant={downPaymentType === "percent" ? "default" : "ghost"}
                        size="sm"
                        className="rounded-none px-3"
                        onClick={() => setDownPaymentType("percent")}
                      >
                        <Percent className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant={downPaymentType === "amount" ? "default" : "ghost"}
                        size="sm"
                        className="rounded-none px-3"
                        onClick={() => setDownPaymentType("amount")}
                      >
                        <DollarSign className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Loan Type */}
                <div className="space-y-2">
                  <Label>Loan Type</Label>
                  <Select value={loanType} onValueChange={setLoanType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select loan type" />
                    </SelectTrigger>
                    <SelectContent>
                      {LOAN_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label} (Min {type.minDown}% down)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options */}
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="w-full justify-between"
                  >
                    <span>Advanced Options</span>
                    {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>

                  {showAdvanced && (
                    <div className="space-y-3 p-3 border rounded-lg bg-muted/30">
                      <div className="space-y-2">
                        <Label htmlFor="closingCostRate">Closing Cost Rate (%)</Label>
                        <Input
                          id="closingCostRate"
                          type="number"
                          placeholder="3"
                          value={closingCostRate}
                          onChange={(e) => setClosingCostRate(e.target.value)}
                          min="0"
                          max="10"
                          step="0.5"
                        />
                        <p className="text-xs text-muted-foreground">Typically 2-5% of home price</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDownPayment} className="w-full" size="lg">
                  Calculate Down Payment
                </Button>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleReset} className="flex-1 bg-transparent">
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                  <Button variant="outline" onClick={handleCopy} disabled={!result} className="flex-1 bg-transparent">
                    {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                    {copied ? "Copied!" : "Copy"}
                  </Button>
                  <Button variant="outline" onClick={handleShare} disabled={!result} className="flex-1 bg-transparent">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${getLTVColor(result.ltvRatio)}`}
                  >
                    <div className="text-center mb-4">
                      <div className="flex items-center justify-center gap-2 mb-1">
                        <Home className="h-5 w-5" />
                        <span className="text-sm font-medium">{getLTVLabel(result.ltvRatio)}</span>
                      </div>
                      <div className="text-3xl font-bold">{formatCurrency(result.downPaymentAmount)}</div>
                      <div className="text-sm opacity-80">
                        {result.downPaymentPercent.toFixed(1)}% of {formatCurrency(Number.parseFloat(homePrice))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-white/50 rounded-lg p-2 text-center">
                        <div className="font-semibold">{formatCurrency(result.loanAmount)}</div>
                        <div className="text-xs opacity-70">Loan Amount</div>
                      </div>
                      <div className="bg-white/50 rounded-lg p-2 text-center">
                        <div className="font-semibold">{result.ltvRatio.toFixed(1)}%</div>
                        <div className="text-xs opacity-70">LTV Ratio</div>
                      </div>
                      <div className="bg-white/50 rounded-lg p-2 text-center">
                        <div className="font-semibold">{result.requiresPMI ? "Yes" : "No"}</div>
                        <div className="text-xs opacity-70">PMI Required</div>
                      </div>
                      <div className="bg-white/50 rounded-lg p-2 text-center">
                        <div className="font-semibold">{formatCurrency(result.totalCashNeeded)}</div>
                        <div className="text-xs opacity-70">Total Cash Needed</div>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <div className="mt-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowDetails(!showDetails)}
                        className="w-full justify-between hover:bg-white/30"
                      >
                        <span className="text-sm">View Details</span>
                        {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>

                      {showDetails && (
                        <div className="mt-2 space-y-2 text-sm">
                          <div className="flex justify-between p-2 bg-white/30 rounded">
                            <span>Closing Costs (est.)</span>
                            <span className="font-medium">{formatCurrency(result.closingCostsEstimate)}</span>
                          </div>
                          {result.requiresPMI && (
                            <div className="flex justify-between p-2 bg-white/30 rounded">
                              <span>Est. Monthly PMI</span>
                              <span className="font-medium">{formatCurrency(result.estimatedPMI)}/mo</span>
                            </div>
                          )}
                          {result.downPaymentPercent < 20 && loanType === "conventional" && (
                            <div className="flex justify-between p-2 bg-white/30 rounded">
                              <span>To Avoid PMI (20%)</span>
                              <span className="font-medium">{formatCurrency(result.minimumRecommended)}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Comparison Scenarios */}
                {comparison.length > 0 && (
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowComparison(!showComparison)}
                      className="w-full justify-between"
                    >
                      <span>Compare Down Payment Scenarios</span>
                      {showComparison ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>

                    {showComparison && (
                      <div className="border rounded-lg overflow-hidden">
                        <table className="w-full text-sm">
                          <thead className="bg-muted/50">
                            <tr>
                              <th className="p-2 text-left">Down %</th>
                              <th className="p-2 text-right">Amount</th>
                              <th className="p-2 text-right">Loan</th>
                              <th className="p-2 text-center">PMI</th>
                            </tr>
                          </thead>
                          <tbody>
                            {comparison.map((scenario) => (
                              <tr
                                key={scenario.percent}
                                className={`border-t ${scenario.percent === Math.round(result?.downPaymentPercent || 0) ? "bg-primary/10" : ""}`}
                              >
                                <td className="p-2 font-medium">{scenario.percent}%</td>
                                <td className="p-2 text-right">{formatCurrency(scenario.amount)}</td>
                                <td className="p-2 text-right">{formatCurrency(scenario.loanAmount)}</td>
                                <td className="p-2 text-center">
                                  {scenario.requiresPMI ? (
                                    <span className="text-yellow-600">{formatCurrency(scenario.monthlyPMI)}/mo</span>
                                  ) : (
                                    <span className="text-green-600">None</span>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-4">
              {/* Loan Types Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Building className="h-5 w-5 text-green-600" />
                    Loan Types & Minimum Down Payments
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center justify-between p-2 bg-blue-50 rounded-lg">
                    <div>
                      <span className="font-medium text-blue-700">Conventional</span>
                      <p className="text-xs text-blue-600">Standard mortgage</p>
                    </div>
                    <span className="text-blue-700 font-bold">3%+</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-purple-50 rounded-lg">
                    <div>
                      <span className="font-medium text-purple-700">FHA</span>
                      <p className="text-xs text-purple-600">Gov. insured</p>
                    </div>
                    <span className="text-purple-700 font-bold">3.5%+</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-green-50 rounded-lg">
                    <div>
                      <span className="font-medium text-green-700">VA</span>
                      <p className="text-xs text-green-600">Veterans only</p>
                    </div>
                    <span className="text-green-700 font-bold">0%</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-amber-50 rounded-lg">
                    <div>
                      <span className="font-medium text-amber-700">USDA</span>
                      <p className="text-xs text-amber-600">Rural areas</p>
                    </div>
                    <span className="text-amber-700 font-bold">0%</span>
                  </div>
                </CardContent>
              </Card>

              {/* PMI Info Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Shield className="h-5 w-5 text-green-600" />
                    Private Mortgage Insurance (PMI)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <p>
                      PMI is required when your down payment is less than <strong>20%</strong> of the home price for
                      conventional loans.
                    </p>
                    <div className="space-y-1">
                      <div className="flex justify-between">
                        <span>Typical PMI Rate:</span>
                        <span className="font-medium">0.5% - 1% annually</span>
                      </div>
                      <div className="flex justify-between">
                        <span>PMI Removal:</span>
                        <span className="font-medium">At 80% LTV</span>
                      </div>
                    </div>
                    <p className="text-xs">
                      VA loans do not require PMI. FHA loans have MIP (Mortgage Insurance Premium) instead.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Formula Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Calculator className="h-5 w-5 text-green-600" />
                    Down Payment Formula
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="bg-muted/50 rounded-lg p-3 font-mono text-center">
                      <div>Down Payment = Home Price × (Percentage / 100)</div>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-3 font-mono text-center">
                      <div>Loan Amount = Home Price - Down Payment</div>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-3 font-mono text-center">
                      <div>LTV = (Loan Amount / Home Price) × 100</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="grid gap-4 md:grid-cols-2 mt-6">
            <Card className="shadow-md border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  What is a Down Payment?
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground space-y-2">
                <p>
                  A down payment is the initial upfront payment you make when purchasing a home. It represents your
                  equity in the property from day one.
                </p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Larger down payments mean smaller loans</li>
                  <li>20% down avoids PMI on conventional loans</li>
                  <li>Lower LTV ratios often get better interest rates</li>
                  <li>Down payment shows lenders you&apos;re financially stable</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Tips for Saving Your Down Payment
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground space-y-2">
                <ul className="list-disc list-inside space-y-1">
                  <li>Set up automatic transfers to a dedicated savings account</li>
                  <li>Consider down payment assistance programs</li>
                  <li>Look into first-time homebuyer programs</li>
                  <li>Reduce unnecessary expenses and redirect to savings</li>
                  <li>Consider a side income or freelance work</li>
                  <li>Check if family gift funds are allowed by your lender</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <Card className="mt-4 shadow-md border-0 bg-amber-50/50">
            <CardContent className="pt-4">
              <div className="flex gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-800">
                  <p className="font-medium mb-1">Important Disclaimer</p>
                  <p>
                    Down payment calculations are estimates and may vary based on lender requirements and local
                    regulations. Actual closing costs, PMI rates, and other fees may differ. Consult a mortgage
                    professional for personalized advice.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
