"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, GraduationCap, Info, Calendar, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface SemesterResult {
  totalDays: number
  weeks: number
  days: number
  instructionalDays: number
  weekdays: number
  weekends: number
}

export function AcademicSemesterLengthCalculator() {
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [excludeWeekends, setExcludeWeekends] = useState(false)
  const [result, setResult] = useState<SemesterResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateSemesterLength = () => {
    setError("")
    setResult(null)

    if (!startDate || !endDate) {
      setError("Please enter both start and end dates")
      return
    }

    const start = new Date(startDate)
    const end = new Date(endDate)

    if (end <= start) {
      setError("End date must be after start date")
      return
    }

    const diffTime = end.getTime() - start.getTime()
    const totalDays = Math.floor(diffTime / (1000 * 60 * 60 * 24)) + 1 // +1 to include both start and end dates

    if (totalDays > 365) {
      setError("Semester duration exceeds one year")
      return
    }

    const weeks = Math.floor(totalDays / 7)
    const days = totalDays % 7

    // Count weekdays and weekends
    let weekdays = 0
    let weekends = 0
    const currentDate = new Date(start)

    while (currentDate <= end) {
      const dayOfWeek = currentDate.getDay()
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        weekends++
      } else {
        weekdays++
      }
      currentDate.setDate(currentDate.getDate() + 1)
    }

    const instructionalDays = excludeWeekends ? weekdays : totalDays

    setResult({ totalDays, weeks, days, instructionalDays, weekdays, weekends })
  }

  const handleReset = () => {
    setStartDate("")
    setEndDate("")
    setExcludeWeekends(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = excludeWeekends
        ? `Semester Length: ${result.totalDays} total days (${result.weeks} weeks, ${result.days} days)\nInstructional Days: ${result.instructionalDays} weekdays`
        : `Semester Length: ${result.totalDays} days (${result.weeks} weeks, ${result.days} days)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = excludeWeekends
          ? `Semester Length: ${result.totalDays} total days (${result.instructionalDays} instructional days)`
          : `Semester Length: ${result.totalDays} days (${result.weeks} weeks, ${result.days} days)`
        await navigator.share({
          title: "Semester Length Calculation",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <GraduationCap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Academic Semester Length Calculator</CardTitle>
                    <CardDescription>Calculate semester duration and instructional days</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Start Date */}
                <div className="space-y-2">
                  <Label htmlFor="start">Semester Start Date</Label>
                  <Input
                    id="start"
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>

                {/* End Date */}
                <div className="space-y-2">
                  <Label htmlFor="end">Semester End Date</Label>
                  <Input
                    id="end"
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    min={startDate}
                  />
                </div>

                {/* Exclude Weekends */}
                <div className="flex items-center space-x-2 py-2">
                  <Checkbox
                    id="weekends"
                    checked={excludeWeekends}
                    onCheckedChange={(checked) => setExcludeWeekends(checked as boolean)}
                  />
                  <label
                    htmlFor="weekends"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Count only instructional days (exclude weekends)
                  </label>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSemesterLength} className="w-full" size="lg">
                  Calculate Semester Length
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total Semester Length</p>
                        <p className="text-4xl font-bold text-cyan-600 mb-1">{result.totalDays}</p>
                        <p className="text-sm text-cyan-700">
                          days ({result.weeks} weeks, {result.days} days)
                        </p>
                      </div>

                      {excludeWeekends && (
                        <div className="p-3 bg-white rounded-lg border border-cyan-200">
                          <div className="text-center">
                            <p className="text-xs text-muted-foreground mb-1">Instructional Days</p>
                            <p className="text-2xl font-bold text-cyan-700">{result.instructionalDays}</p>
                            <p className="text-xs text-cyan-600 mt-1">weekdays only</p>
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 bg-white rounded-lg border border-cyan-200 text-center">
                          <p className="text-xs text-muted-foreground">Weekdays</p>
                          <p className="text-lg font-semibold text-cyan-700">{result.weekdays}</p>
                        </div>
                        <div className="p-2 bg-white rounded-lg border border-cyan-200 text-center">
                          <p className="text-xs text-muted-foreground">Weekends</p>
                          <p className="text-lg font-semibold text-cyan-700">{result.weekends}</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Disclaimer */}
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-xs text-amber-800">
                    <strong>Note:</strong> Semester length calculations are based on entered dates. Results may vary
                    depending on holidays, breaks, and calendar differences.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Semester Lengths</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-700">Fall Semester</div>
                      <div className="text-sm text-cyan-600">15-16 weeks (August-December)</div>
                    </div>
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-700">Spring Semester</div>
                      <div className="text-sm text-cyan-600">15-16 weeks (January-May)</div>
                    </div>
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-700">Summer Session</div>
                      <div className="text-sm text-cyan-600">6-12 weeks (May-August)</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Details</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div>
                    <strong className="text-foreground">Total Days:</strong>
                    <p className="mt-1">Includes all calendar days from start to end date, including weekends.</p>
                  </div>
                  <div>
                    <strong className="text-foreground">Instructional Days:</strong>
                    <p className="mt-1">When weekends are excluded, shows only Monday-Friday for class scheduling.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* About Semester Planning */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Academic Semester Planning</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding the length of an academic semester is crucial for effective planning in higher education.
                  Most colleges and universities in the United States operate on a semester system, with fall and spring
                  semesters typically lasting 15-16 weeks each. These periods are carefully structured to provide
                  sufficient time for comprehensive instruction, assessment, and learning across various subjects.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Knowing the exact duration helps students plan their coursework, manage assignment deadlines, and
                  balance academic commitments with other responsibilities. For instructors, accurate semester length
                  information is essential for curriculum design, pacing lessons appropriately, and scheduling exams and
                  major assignments throughout the term.
                </p>
              </CardContent>
            </Card>

            {/* Using the Calculator */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Using the Semester Length Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate your semester length, simply enter the first day of classes as the start date and the last
                  day of classes or final exams as the end date. The calculator will determine the total number of days,
                  convert this into weeks and days, and provide a breakdown of weekdays versus weekend days. This
                  information can help you plan your study schedule and understand the pacing of your semester.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  If you enable the "Count only instructional days" option, the calculator will exclude Saturdays and
                  Sundays to show you specifically how many class days are available. This is particularly useful for
                  understanding how many actual teaching or study days you have, accounting for the typical Monday-Friday
                  class schedule. Remember that this doesn't account for holidays or breaks, which should be considered
                  separately in your planning.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <GraduationCap className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      How does semester length affect course planning?
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      Longer semesters allow for more in-depth coverage of material and more flexible pacing, while
                      shorter sessions like summer terms require more intensive study. Understanding semester length helps
                      you estimate workload and plan accordingly.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Should I include exam week in the calculation?</h4>
                    <p className="text-muted-foreground text-sm">
                      Yes, typically you should include the final exam period in your end date, as this is still part of
                      the academic semester. Many schools count exam week when determining the official semester length.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      What about holidays and breaks?
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      This calculator shows the total calendar length between start and end dates. For precise
                      instructional days, you'll need to manually subtract any holidays, spring break, or other scheduled
                      breaks that occur during the semester.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
