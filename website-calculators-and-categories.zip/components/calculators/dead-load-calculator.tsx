"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Weight, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "SI" | "imperial"
type ElementType = "slab" | "beam" | "column" | "wall"

interface DeadLoadResult {
  volumePerElement: number
  totalVolume: number
  loadPerElement: number
  totalLoad: number
  loadPerArea?: number
  unit: string
}

interface MaterialPreset {
  name: string
  density: number
}

const materialPresetsSI: MaterialPreset[] = [
  { name: "Concrete (RCC)", density: 25 },
  { name: "Plain Concrete", density: 24 },
  { name: "Brick Masonry", density: 19 },
  { name: "Steel", density: 78.5 },
  { name: "Timber", density: 6.5 },
  { name: "Stone Masonry", density: 22 },
]

const materialPresetsImperial: MaterialPreset[] = [
  { name: "Concrete (RCC)", density: 150 },
  { name: "Plain Concrete", density: 145 },
  { name: "Brick Masonry", density: 120 },
  { name: "Steel", density: 490 },
  { name: "Timber", density: 40 },
  { name: "Stone Masonry", density: 140 },
]

export function DeadLoadCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("SI")
  const [elementType, setElementType] = useState<ElementType>("slab")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [depth, setDepth] = useState("")
  const [density, setDensity] = useState("25")
  const [repetitions, setRepetitions] = useState("1")
  const [safetyFactor, setSafetyFactor] = useState("1.2")
  const [result, setResult] = useState<DeadLoadResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDeadLoad = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const depthNum = Number.parseFloat(depth)
    const densityNum = Number.parseFloat(density)
    const reps = Number.parseInt(repetitions) || 1
    const sf = Number.parseFloat(safetyFactor)

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }
    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }
    if (isNaN(depthNum) || depthNum <= 0) {
      setError("Please enter a valid depth/thickness greater than 0")
      return
    }
    if (isNaN(densityNum) || densityNum <= 0) {
      setError("Please enter a valid material density greater than 0")
      return
    }
    if (reps < 1) {
      setError("Number of repetitions must be at least 1")
      return
    }
    if (isNaN(sf) || sf < 1) {
      setError("Safety factor must be at least 1")
      return
    }

    // Calculate volume per element
    const volumePerElement = lengthNum * widthNum * depthNum
    const totalVolume = volumePerElement * reps

    // Calculate dead load
    const loadPerElement = volumePerElement * densityNum * sf
    const totalLoad = loadPerElement * reps

    // Calculate load per area (optional)
    const area = lengthNum * widthNum
    const loadPerArea = area > 0 ? loadPerElement / area : undefined

    const unit = unitSystem === "SI" ? "kN" : "lb"

    setResult({
      volumePerElement: Math.round(volumePerElement * 100) / 100,
      totalVolume: Math.round(totalVolume * 100) / 100,
      loadPerElement: Math.round(loadPerElement * 100) / 100,
      totalLoad: Math.round(totalLoad * 100) / 100,
      loadPerArea: loadPerArea ? Math.round(loadPerArea * 100) / 100 : undefined,
      unit,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setDepth("")
    setDensity(unitSystem === "SI" ? "25" : "150")
    setRepetitions("1")
    setSafetyFactor("1.2")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Dead Load: ${result.totalLoad} ${result.unit} (${repetitions} ${elementType}${Number.parseInt(repetitions) > 1 ? "s" : ""})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Dead Load Calculation",
          text: `I calculated dead load using CalcHub! Total: ${result.totalLoad} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "SI" ? "imperial" : "SI"))
    setLength("")
    setWidth("")
    setDepth("")
    setDensity(unitSystem === "SI" ? "150" : "25")
    setResult(null)
    setError("")
  }

  const handleMaterialPreset = (presetName: string) => {
    const presets = unitSystem === "SI" ? materialPresetsSI : materialPresetsImperial
    const preset = presets.find((p) => p.name === presetName)
    if (preset) {
      setDensity(preset.density.toString())
    }
  }

  const getElementDimensions = () => {
    switch (elementType) {
      case "slab":
        return { lengthLabel: "Length", widthLabel: "Width", depthLabel: "Thickness" }
      case "beam":
        return { lengthLabel: "Length", widthLabel: "Width", depthLabel: "Depth" }
      case "column":
        return { lengthLabel: "Width", widthLabel: "Breadth", depthLabel: "Height" }
      case "wall":
        return { lengthLabel: "Length", widthLabel: "Thickness", depthLabel: "Height" }
      default:
        return { lengthLabel: "Length", widthLabel: "Width", depthLabel: "Depth" }
    }
  }

  const dimensions = getElementDimensions()
  const unitLabel = unitSystem === "SI" ? "m" : "ft"
  const densityUnit = unitSystem === "SI" ? "kN/m³" : "lb/ft³"
  const volumeUnit = unitSystem === "SI" ? "m³" : "ft³"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Weight className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Dead Load Calculator</CardTitle>
                    <CardDescription>Calculate dead load of structural elements</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "SI" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      SI
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Element Type */}
                <div className="space-y-2">
                  <Label htmlFor="elementType">Element Type</Label>
                  <Select value={elementType} onValueChange={(value) => setElementType(value as ElementType)}>
                    <SelectTrigger id="elementType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="slab">Slab</SelectItem>
                      <SelectItem value="beam">Beam</SelectItem>
                      <SelectItem value="column">Column</SelectItem>
                      <SelectItem value="wall">Wall</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dimensions */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">
                      {dimensions.lengthLabel} ({unitLabel})
                    </Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder="0"
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="width">
                      {dimensions.widthLabel} ({unitLabel})
                    </Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder="0"
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="depth">
                      {dimensions.depthLabel} ({unitLabel})
                    </Label>
                    <Input
                      id="depth"
                      type="number"
                      placeholder="0"
                      value={depth}
                      onChange={(e) => setDepth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Material Density */}
                <div className="space-y-2">
                  <Label htmlFor="density">Material Density ({densityUnit})</Label>
                  <div className="flex gap-2">
                    <Input
                      id="density"
                      type="number"
                      placeholder="0"
                      value={density}
                      onChange={(e) => setDensity(e.target.value)}
                      min="0"
                      step="0.1"
                      className="flex-1"
                    />
                    <Select onValueChange={handleMaterialPreset}>
                      <SelectTrigger className="w-[140px]">
                        <SelectValue placeholder="Preset" />
                      </SelectTrigger>
                      <SelectContent>
                        {(unitSystem === "SI" ? materialPresetsSI : materialPresetsImperial).map((preset) => (
                          <SelectItem key={preset.name} value={preset.name}>
                            {preset.name.split(" ")[0]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Repetitions and Safety Factor */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="repetitions">Repetitions</Label>
                    <Input
                      id="repetitions"
                      type="number"
                      placeholder="1"
                      value={repetitions}
                      onChange={(e) => setRepetitions(e.target.value)}
                      min="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="safetyFactor">Safety Factor</Label>
                    <Input
                      id="safetyFactor"
                      type="number"
                      placeholder="1.2"
                      value={safetyFactor}
                      onChange={(e) => setSafetyFactor(e.target.value)}
                      min="1"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDeadLoad} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Dead Load
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total Dead Load</p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">{result.totalLoad}</p>
                        <p className="text-lg font-semibold text-amber-700">{result.unit}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-amber-200">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Per Element</p>
                          <p className="text-lg font-semibold text-amber-700">
                            {result.loadPerElement} {result.unit}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Total Volume</p>
                          <p className="text-lg font-semibold text-amber-700">
                            {result.totalVolume} {volumeUnit}
                          </p>
                        </div>
                      </div>

                      {result.loadPerArea && (
                        <div className="text-center pt-2 border-t border-amber-200">
                          <p className="text-xs text-muted-foreground">Load per Unit Area</p>
                          <p className="text-lg font-semibold text-amber-700">
                            {result.loadPerArea} {result.unit}/{unitSystem === "SI" ? "m²" : "ft²"}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Material Densities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {(unitSystem === "SI" ? materialPresetsSI : materialPresetsImperial).map((preset) => (
                      <div key={preset.name} className="flex items-center justify-between p-2 rounded bg-muted">
                        <span className="font-medium">{preset.name}</span>
                        <span className="text-muted-foreground">
                          {preset.density} {densityUnit}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Safety Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong className="text-foreground">Permanent Loads:</strong> 1.2 - 1.4
                  </p>
                  <p>
                    <strong className="text-foreground">Finishes & Partitions:</strong> 1.2
                  </p>
                  <p>
                    <strong className="text-foreground">Retaining Walls:</strong> 1.35 - 1.5
                  </p>
                  <p className="text-xs pt-2 border-t">
                    Safety factors vary by code and structure type. Always consult local building codes.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Dead Load */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Dead Load?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Dead load refers to the permanent, static weight of structural elements and fixed components in a
                  building or structure. This includes the self-weight of slabs, beams, columns, walls, roof systems,
                  and permanent fixtures like flooring, ceiling materials, HVAC equipment, and plumbing. Unlike live
                  loads which can vary over time, dead loads remain constant throughout the life of the structure.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Accurate calculation of dead loads is crucial in structural engineering because these loads act
                  continuously on the structure and significantly influence the design of foundations, columns, beams,
                  and load-bearing walls. Engineers must account for all permanent materials and components to ensure
                  the structure can safely support these loads while maintaining structural integrity and stability.
                </p>
              </CardContent>
            </Card>

            {/* How Dead Load is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How is Dead Load Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Dead load is calculated by determining the volume of each structural element and multiplying it by
                  the unit weight (density) of the material. For example, a concrete slab measuring 5m × 4m × 0.15m
                  with concrete density of 25 kN/m³ would have a dead load of: Volume (5 × 4 × 0.15 = 3 m³) × Density
                  (25 kN/m³) = 75 kN. A safety factor, typically 1.2 to 1.5, is then applied to account for variations
                  in material density and construction tolerances.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For complex structures, dead loads are calculated for each component separately and then summed to
                  find the total dead load. This includes structural elements (beams, columns, slabs), architectural
                  components (walls, partitions), and fixed services (permanent equipment, finishes). The calculated
                  dead loads are essential inputs for structural analysis and design, ensuring that foundations and
                  structural members are adequately sized to support the permanent weight of the building.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What's the difference between dead load and live load?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Dead load is the permanent, static weight of the structure and fixed components that don't change
                      over time. Live load refers to temporary, movable loads like people, furniture, equipment, and
                      environmental loads (wind, snow). Both must be considered in structural design.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Why is a safety factor applied to dead loads?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Safety factors account for uncertainties in material properties, construction variations, measurement
                      errors, and potential overloading. They provide a margin of safety to ensure the structure can handle
                      slightly higher loads than anticipated without failure.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How do material densities vary?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Material densities can vary based on composition, moisture content, and manufacturing processes.
                      Reinforced concrete typically weighs 25 kN/m³ (150 lb/ft³), while plain concrete is slightly lighter
                      at 24 kN/m³. Always verify actual material densities with suppliers and specifications.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-900">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p className="leading-relaxed">
                      Dead load calculations provided by this calculator are approximate and for preliminary estimation
                      purposes only. Final design loads must follow applicable structural design codes, building
                      regulations, and material specifications. Always consult with qualified structural engineers and
                      verify all calculations before construction or design implementation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
