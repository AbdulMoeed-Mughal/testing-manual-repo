"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Atom, Plus, Minus } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface AtomData {
  id: number
  symbol: string
  valenceElectrons: string
  lonePairElectrons: string
  bondingElectrons: string
}

interface FormalChargeResult {
  atoms: { symbol: string; formalCharge: number }[]
  totalCharge: number
}

export function FormalChargeCalculator() {
  const [atoms, setAtoms] = useState<AtomData[]>([
    { id: 1, symbol: "", valenceElectrons: "", lonePairElectrons: "", bondingElectrons: "" }
  ])
  const [result, setResult] = useState<FormalChargeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const addAtom = () => {
    const newId = atoms.length > 0 ? Math.max(...atoms.map(a => a.id)) + 1 : 1
    setAtoms([...atoms, { id: newId, symbol: "", valenceElectrons: "", lonePairElectrons: "", bondingElectrons: "" }])
  }

  const removeAtom = (id: number) => {
    if (atoms.length > 1) {
      setAtoms(atoms.filter(a => a.id !== id))
    }
  }

  const updateAtom = (id: number, field: keyof AtomData, value: string) => {
    setAtoms(atoms.map(a => a.id === id ? { ...a, [field]: value } : a))
  }

  const calculateFormalCharge = () => {
    setError("")
    setResult(null)

    const results: { symbol: string; formalCharge: number }[] = []
    let totalCharge = 0

    for (const atom of atoms) {
      if (!atom.symbol.trim()) {
        setError("Please enter an atom symbol for all atoms")
        return
      }

      const valence = Number.parseFloat(atom.valenceElectrons)
      const lonePair = Number.parseFloat(atom.lonePairElectrons)
      const bonding = Number.parseFloat(atom.bondingElectrons)

      if (isNaN(valence) || valence < 0) {
        setError(`Please enter valid valence electrons for ${atom.symbol}`)
        return
      }
      if (isNaN(lonePair) || lonePair < 0) {
        setError(`Please enter valid lone pair electrons for ${atom.symbol}`)
        return
      }
      if (isNaN(bonding) || bonding < 0) {
        setError(`Please enter valid bonding electrons for ${atom.symbol}`)
        return
      }
      if (bonding % 2 !== 0) {
        setError(`Bonding electrons must be even for ${atom.symbol}`)
        return
      }

      // Formal Charge = Valence Electrons - (Lone Pair Electrons + 1/2 × Bonding Electrons)
      const formalCharge = valence - (lonePair + bonding / 2)
      results.push({ symbol: atom.symbol, formalCharge })
      totalCharge += formalCharge
    }

    setResult({ atoms: results, totalCharge })
  }

  const handleReset = () => {
    setAtoms([{ id: 1, symbol: "", valenceElectrons: "", lonePairElectrons: "", bondingElectrons: "" }])
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.atoms.map(a => `${a.symbol}: ${a.formalCharge > 0 ? "+" : ""}${a.formalCharge}`).join(", ") + ` | Total: ${result.totalCharge > 0 ? "+" : ""}${result.totalCharge}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = result.atoms.map(a => `${a.symbol}: ${a.formalCharge > 0 ? "+" : ""}${a.formalCharge}`).join(", ")
        await navigator.share({
          title: "Formal Charge Calculation",
          text: `Formal Charges: ${text} | Total: ${result.totalCharge}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const getChargeColor = (charge: number) => {
    if (charge > 0) return "text-red-600 bg-red-50 border-red-200"
    if (charge < 0) return "text-blue-600 bg-blue-50 border-blue-200"
    return "text-green-600 bg-green-50 border-green-200"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Formal Charge Calculator</CardTitle>
                    <CardDescription>Calculate formal charges of atoms in a molecule</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Atoms List */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Atoms</Label>
                    <Button variant="outline" size="sm" onClick={addAtom}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Atom
                    </Button>
                  </div>

                  {atoms.map((atom, index) => (
                    <div key={atom.id} className="p-4 border rounded-lg space-y-3 bg-muted/30">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Atom {index + 1}</span>
                        {atoms.length > 1 && (
                          <Button variant="ghost" size="sm" onClick={() => removeAtom(atom.id)}>
                            <Minus className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs">Symbol</Label>
                          <Input
                            placeholder="e.g., C, O, N"
                            value={atom.symbol}
                            onChange={(e) => updateAtom(atom.id, "symbol", e.target.value)}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Valence e⁻</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 4"
                            value={atom.valenceElectrons}
                            onChange={(e) => updateAtom(atom.id, "valenceElectrons", e.target.value)}
                            min="0"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Lone Pair e⁻</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 2"
                            value={atom.lonePairElectrons}
                            onChange={(e) => updateAtom(atom.id, "lonePairElectrons", e.target.value)}
                            min="0"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Bonding e⁻</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 4"
                            value={atom.bondingElectrons}
                            onChange={(e) => updateAtom(atom.id, "bondingElectrons", e.target.value)}
                            min="0"
                            step="2"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFormalCharge} className="w-full" size="lg">
                  Calculate Formal Charges
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 border-purple-200 bg-purple-50 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-3">Formal Charges</p>
                      <div className="flex flex-wrap gap-2 justify-center mb-4">
                        {result.atoms.map((atom, index) => (
                          <div
                            key={index}
                            className={`px-4 py-2 rounded-lg border ${getChargeColor(atom.formalCharge)}`}
                          >
                            <span className="font-bold text-lg">{atom.symbol}</span>
                            <span className="ml-1 text-sm">
                              {atom.formalCharge > 0 ? "+" : ""}{atom.formalCharge}
                            </span>
                          </div>
                        ))}
                      </div>
                      <div className={`inline-block px-4 py-2 rounded-lg border ${getChargeColor(result.totalCharge)}`}>
                        <span className="text-sm">Total Charge: </span>
                        <span className="font-bold text-xl">
                          {result.totalCharge > 0 ? "+" : ""}{result.totalCharge}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formal Charge Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">FC = V - (L + B/2)</p>
                  </div>
                  <p>Where:</p>
                  <ul className="space-y-1 list-disc list-inside">
                    <li><strong>V</strong> = Valence electrons of the atom</li>
                    <li><strong>L</strong> = Lone pair electrons on the atom</li>
                    <li><strong>B</strong> = Bonding electrons (shared)</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Valence Electrons</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>H (Hydrogen)</span>
                      <span className="font-mono">1</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>C (Carbon)</span>
                      <span className="font-mono">4</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>N (Nitrogen)</span>
                      <span className="font-mono">5</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>O (Oxygen)</span>
                      <span className="font-mono">6</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>S (Sulfur)</span>
                      <span className="font-mono">6</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Cl (Chlorine)</span>
                      <span className="font-mono">7</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Formal Charge */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Formal Charge?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Formal charge is a theoretical concept used in chemistry to describe the electrical charge assigned to 
                  an atom in a molecule, assuming that all electrons in chemical bonds are shared equally between atoms. 
                  It helps chemists determine the most stable Lewis structure of a molecule and understand electron 
                  distribution within molecular structures.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Unlike actual partial charges that exist in molecules due to electronegativity differences, formal 
                  charges are bookkeeping tools that help predict molecular geometry, reactivity, and the location of 
                  charge in polyatomic ions. The sum of all formal charges in a neutral molecule must equal zero, while 
                  in an ion, it must equal the overall ionic charge.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Formal Charge</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate the formal charge of an atom, start by identifying the number of valence electrons the 
                  atom has in its ground state (this is typically the group number for main group elements). Then, 
                  count the number of lone pair (non-bonding) electrons on the atom in the Lewis structure.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Finally, count the total number of bonding electrons around the atom. Since electrons in bonds are 
                  shared, each atom is assigned half of the bonding electrons. The formal charge formula is: 
                  FC = Valence electrons - Lone pair electrons - (1/2 × Bonding electrons). For example, oxygen in 
                  water has 6 valence electrons, 4 lone pair electrons, and 4 bonding electrons, giving it a formal 
                  charge of 6 - 4 - 2 = 0.
                </p>
              </CardContent>
            </Card>

            {/* Choosing Lewis Structures */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Choosing the Best Lewis Structure</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When multiple Lewis structures are possible for a molecule, formal charges help identify the most 
                  stable one. The best Lewis structure typically has the smallest formal charges on all atoms. Ideally, 
                  all atoms should have a formal charge of zero. When non-zero formal charges are unavoidable, negative 
                  formal charges should be placed on more electronegative atoms.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Adjacent atoms should not have formal charges of the same sign, as this creates electrostatic 
                  repulsion and reduces stability. Following these guidelines helps predict which resonance structure 
                  contributes most to the actual electronic structure of a molecule and aids in understanding chemical 
                  reactivity patterns.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations of Formal Charge</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Formal charge is a theoretical construct and does not represent actual electron density or partial 
                  charges in molecules. It assumes equal sharing of bonding electrons, which is often not the case due 
                  to electronegativity differences between atoms. For polar bonds, actual charge distribution differs 
                  significantly from what formal charges suggest.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Additionally, formal charge analysis does not account for resonance effects where electron 
                  delocalization occurs. In molecules with multiple resonance structures, the actual electron 
                  distribution is a weighted average of all contributing structures. For more accurate charge 
                  predictions, computational methods like Natural Population Analysis (NPA) or Mulliken population 
                  analysis are preferred in advanced applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
