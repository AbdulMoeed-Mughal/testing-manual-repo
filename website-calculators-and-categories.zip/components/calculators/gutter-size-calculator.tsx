"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Home,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Droplets,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface GutterResult {
  roofArea: number
  flowRate: number
  recommendedSize: { width: number; depth: number; name: string }
  totalLength: number
  totalLengthWithWaste: number
  recommendedDownspouts: number
}

interface GutterSize {
  name: string
  width: number
  depth: number
  capacity: number // L/min for metric, gal/min for imperial
}

const gutterSizesMetric: GutterSize[] = [
  { name: "75mm Mini", width: 75, depth: 50, capacity: 3.5 },
  { name: "100mm Standard", width: 100, depth: 75, capacity: 7 },
  { name: "125mm Large", width: 125, depth: 90, capacity: 12 },
  { name: "150mm Commercial", width: 150, depth: 100, capacity: 18 },
  { name: "175mm Industrial", width: 175, depth: 125, capacity: 28 },
]

const gutterSizesImperial: GutterSize[] = [
  { name: '4" Mini', width: 4, depth: 2.5, capacity: 0.9 },
  { name: '5" Standard', width: 5, depth: 3, capacity: 1.8 },
  { name: '6" Large', width: 6, depth: 4, capacity: 3.2 },
  { name: '7" Commercial', width: 7, depth: 5, capacity: 4.8 },
  { name: '8" Industrial', width: 8, depth: 6, capacity: 7.4 },
]

export function GutterSizeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [roofLength, setRoofLength] = useState("")
  const [roofWidth, setRoofWidth] = useState("")
  const [roofPitch, setRoofPitch] = useState("")
  const [rainfallIntensity, setRainfallIntensity] = useState("")
  const [downspouts, setDownspouts] = useState("")
  const [wastePercentage, setWastePercentage] = useState("10")
  const [result, setResult] = useState<GutterResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateGutter = () => {
    setError("")
    setResult(null)

    const length = Number.parseFloat(roofLength)
    const width = Number.parseFloat(roofWidth)
    const rainfall = Number.parseFloat(rainfallIntensity)
    const waste = Number.parseFloat(wastePercentage) || 10
    const pitch = Number.parseFloat(roofPitch) || 0

    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid roof length greater than 0")
      return
    }
    if (isNaN(width) || width <= 0) {
      setError("Please enter a valid roof width greater than 0")
      return
    }
    if (isNaN(rainfall) || rainfall <= 0) {
      setError("Please enter a valid rainfall intensity greater than 0")
      return
    }

    // Calculate roof area (adjust for pitch if provided)
    let roofArea = length * width
    if (pitch > 0) {
      const pitchFactor = 1 / Math.cos((pitch * Math.PI) / 180)
      roofArea = roofArea * pitchFactor
    }

    // Calculate flow rate
    let flowRate: number
    if (unitSystem === "metric") {
      // Flow in L/min = Area (m²) × Rainfall (mm/h) / 60
      flowRate = (roofArea * rainfall) / 60
    } else {
      // Flow in gal/min = Area (ft²) × Rainfall (in/h) × 0.623 / 60
      flowRate = (roofArea * rainfall * 0.623) / 60
    }

    // Determine recommended gutter size
    const gutterSizes = unitSystem === "metric" ? gutterSizesMetric : gutterSizesImperial
    let recommendedSize = gutterSizes[gutterSizes.length - 1]
    for (const size of gutterSizes) {
      if (size.capacity >= flowRate) {
        recommendedSize = size
        break
      }
    }

    // Calculate total gutter length (perimeter for gutters typically on eaves)
    // Usually gutters are on the longer sides (eaves)
    const totalLength = length * 2

    // Add waste
    const totalLengthWithWaste = totalLength * (1 + waste / 100)

    // Calculate recommended downspouts
    // Rule of thumb: 1 downspout per 20 linear feet (6m) of gutter, minimum 2
    const downspoutSpacing = unitSystem === "metric" ? 6 : 20
    const calculatedDownspouts = Math.max(2, Math.ceil(totalLength / downspoutSpacing))
    const userDownspouts = Number.parseInt(downspouts) || calculatedDownspouts

    setResult({
      roofArea,
      flowRate,
      recommendedSize: {
        width: recommendedSize.width,
        depth: recommendedSize.depth,
        name: recommendedSize.name,
      },
      totalLength,
      totalLengthWithWaste,
      recommendedDownspouts: userDownspouts,
    })
  }

  const handleReset = () => {
    setRoofLength("")
    setRoofWidth("")
    setRoofPitch("")
    setRainfallIntensity("")
    setDownspouts("")
    setWastePercentage("10")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const lengthUnit = unitSystem === "metric" ? "m" : "ft"
      const text = `Gutter Size: ${result.recommendedSize.name}, Total Length: ${result.totalLengthWithWaste.toFixed(2)} ${lengthUnit}, Downspouts: ${result.recommendedDownspouts}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const lengthUnit = unitSystem === "metric" ? "m" : "ft"
      try {
        await navigator.share({
          title: "Gutter Size Calculation",
          text: `I calculated my gutter requirements using CalcHub! Recommended Size: ${result.recommendedSize.name}, Total Length: ${result.totalLengthWithWaste.toFixed(2)} ${lengthUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setRoofLength("")
    setRoofWidth("")
    setRoofPitch("")
    setRainfallIntensity("")
    setDownspouts("")
    setResult(null)
    setError("")
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"
  const areaUnit = unitSystem === "metric" ? "m²" : "ft²"
  const rainfallUnit = unitSystem === "metric" ? "mm/h" : "in/h"
  const flowUnit = unitSystem === "metric" ? "L/min" : "gal/min"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gutter Size Calculator</CardTitle>
                    <CardDescription>Calculate gutter size and length</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Roof Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="roofLength">Roof Length ({lengthUnit})</Label>
                    <Input
                      id="roofLength"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "12" : "40"}`}
                      value={roofLength}
                      onChange={(e) => setRoofLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="roofWidth">Roof Width ({lengthUnit})</Label>
                    <Input
                      id="roofWidth"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "8" : "25"}`}
                      value={roofWidth}
                      onChange={(e) => setRoofWidth(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Roof Pitch (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="roofPitch">Roof Pitch (degrees, optional)</Label>
                  <Input
                    id="roofPitch"
                    type="number"
                    placeholder="e.g., 30"
                    value={roofPitch}
                    onChange={(e) => setRoofPitch(e.target.value)}
                    min="0"
                    max="60"
                    step="1"
                  />
                </div>

                {/* Rainfall Intensity */}
                <div className="space-y-2">
                  <Label htmlFor="rainfallIntensity">Rainfall Intensity ({rainfallUnit})</Label>
                  <Input
                    id="rainfallIntensity"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "75" : "3"}`}
                    value={rainfallIntensity}
                    onChange={(e) => setRainfallIntensity(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">
                    Typical: {unitSystem === "metric" ? "50-150 mm/h" : "2-6 in/h"} for heavy rain
                  </p>
                </div>

                {/* Number of Downspouts (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="downspouts">Number of Downspouts (optional)</Label>
                  <Input
                    id="downspouts"
                    type="number"
                    placeholder="Auto-calculated if empty"
                    value={downspouts}
                    onChange={(e) => setDownspouts(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="wastePercentage">Waste Allowance (%)</Label>
                  <Select value={wastePercentage} onValueChange={setWastePercentage}>
                    <SelectTrigger id="wastePercentage">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5% (Minimal cuts)</SelectItem>
                      <SelectItem value="10">10% (Standard)</SelectItem>
                      <SelectItem value="15">15% (Complex roof)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateGutter} className="w-full" size="lg">
                  Calculate Gutter Requirements
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Recommended Gutter Size</p>
                      <p className="text-3xl font-bold text-amber-700">{result.recommendedSize.name}</p>
                      <p className="text-sm text-amber-600">
                        {unitSystem === "metric"
                          ? `${result.recommendedSize.width}mm × ${result.recommendedSize.depth}mm`
                          : `${result.recommendedSize.width}" × ${result.recommendedSize.depth}"`}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Length</p>
                        <p className="text-lg font-semibold text-foreground">
                          {result.totalLengthWithWaste.toFixed(1)} {lengthUnit}
                        </p>
                        <p className="text-xs text-muted-foreground">(with waste)</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Downspouts</p>
                        <p className="text-lg font-semibold text-foreground">{result.recommendedDownspouts}</p>
                        <p className="text-xs text-muted-foreground">recommended</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Roof Area</p>
                        <p className="text-lg font-semibold text-foreground">
                          {result.roofArea.toFixed(1)} {areaUnit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Flow Rate</p>
                        <p className="text-lg font-semibold text-foreground">
                          {result.flowRate.toFixed(1)} {flowUnit}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step breakdown */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full flex items-center justify-between p-2 text-sm text-amber-700 hover:bg-amber-100 rounded-lg transition-colors"
                    >
                      <span>View calculation steps</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p>
                          <strong>1. Roof Area:</strong> {roofLength} × {roofWidth}
                          {roofPitch ? ` × pitch factor` : ""} = {result.roofArea.toFixed(2)} {areaUnit}
                        </p>
                        <p>
                          <strong>2. Flow Rate:</strong> {result.roofArea.toFixed(2)} × {rainfallIntensity}{" "}
                          {rainfallUnit}
                          {unitSystem === "imperial" ? " × 0.623" : ""} ÷ 60 = {result.flowRate.toFixed(2)} {flowUnit}
                        </p>
                        <p>
                          <strong>3. Gutter Length:</strong> {roofLength} × 2 (eaves) = {result.totalLength.toFixed(2)}{" "}
                          {lengthUnit}
                        </p>
                        <p>
                          <strong>4. With Waste:</strong> {result.totalLength.toFixed(2)} × (1 +{" "}
                          {wastePercentage || "10"}%) = {result.totalLengthWithWaste.toFixed(2)} {lengthUnit}
                        </p>
                        <p>
                          <strong>5. Downspouts:</strong> 1 per {unitSystem === "metric" ? "6m" : "20ft"} ={" "}
                          {result.recommendedDownspouts} minimum
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Gutter Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {(unitSystem === "metric" ? gutterSizesMetric : gutterSizesImperial).map((size) => (
                      <div
                        key={size.name}
                        className="flex items-center justify-between p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                      >
                        <span className="font-medium">{size.name}</span>
                        <span className="text-muted-foreground">
                          {size.capacity} {flowUnit}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rainfall Intensity Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {unitSystem === "metric" ? (
                      <>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-blue-50 border border-blue-200">
                          <span className="font-medium text-blue-700">Light Rain</span>
                          <span className="text-blue-600">{"< 25 mm/h"}</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                          <span className="font-medium text-green-700">Moderate Rain</span>
                          <span className="text-green-600">25-50 mm/h</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-yellow-50 border border-yellow-200">
                          <span className="font-medium text-yellow-700">Heavy Rain</span>
                          <span className="text-yellow-600">50-100 mm/h</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                          <span className="font-medium text-red-700">Very Heavy</span>
                          <span className="text-red-600">{"> 100 mm/h"}</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-blue-50 border border-blue-200">
                          <span className="font-medium text-blue-700">Light Rain</span>
                          <span className="text-blue-600">{"< 1 in/h"}</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                          <span className="font-medium text-green-700">Moderate Rain</span>
                          <span className="text-green-600">1-2 in/h</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-yellow-50 border border-yellow-200">
                          <span className="font-medium text-yellow-700">Heavy Rain</span>
                          <span className="text-yellow-600">2-4 in/h</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                          <span className="font-medium text-red-700">Very Heavy</span>
                          <span className="text-red-600">{"> 4 in/h"}</span>
                        </div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Important Note</p>
                      <p>
                        Results are estimates. Actual gutter size and quantity may vary due to roof design, local
                        rainfall patterns, and building codes. Consult a professional for complex installations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Gutter Sizing</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Proper gutter sizing is crucial for effective rainwater management and protecting your building from
                  water damage. Gutters that are too small will overflow during heavy rain, potentially causing
                  foundation damage, basement flooding, and erosion around your home. Conversely, oversized gutters are
                  unnecessary and more expensive to install and maintain.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key factors in determining gutter size include roof area (the catchment surface), local rainfall
                  intensity (how much water falls in a given time), roof pitch (which affects water velocity), and the
                  number and placement of downspouts. A well-designed gutter system should handle the maximum expected
                  rainfall without overflowing.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>How Gutter Size is Calculated</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gutter sizing calculations start with determining your roof's effective drainage area. For a simple
                  flat roof, this is just length times width. For pitched roofs, the actual surface area is larger due
                  to the angle, so a pitch factor is applied. The pitch factor equals 1 divided by the cosine of the
                  roof angle.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="font-mono text-sm text-center">
                    <strong>Flow Rate = Roof Area × Rainfall Intensity</strong>
                  </p>
                </div>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Once you know the water flow rate your gutters need to handle, you select a gutter size with adequate
                  capacity. Standard residential gutters range from 4-6 inches wide, while commercial applications may
                  require 7-8 inch gutters. The gutter capacity depends on both width and depth, with K-style gutters
                  generally having more capacity than half-round styles of the same width.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Home className="h-5 w-5 text-primary" />
                  <CardTitle>Downspout Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Downspouts are equally important as gutter size for proper drainage. The general rule is one downspout
                  for every 20 linear feet (6 meters) of gutter, with a minimum of two downspouts per gutter run.
                  Downspouts should be sized to match gutter capacity—typically 2×3 inch downspouts for 5-inch gutters
                  and 3×4 inch downspouts for 6-inch gutters.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Placement matters too. Downspouts should be located at corners and low points where water naturally
                  collects. They should direct water away from the foundation, ideally extending at least 4-6 feet from
                  the building. In areas with high rainfall, consider increasing the number of downspouts beyond the
                  minimum recommendation to ensure adequate drainage capacity.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
