"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface PrimeFactor {
  prime: number
  exponent: number
}

interface FactorizationResult {
  originalNumber: number
  isNegative: boolean
  factors: PrimeFactor[]
  standardForm: string
  latexForm: string
  steps: string[]
}

export function PrimeFactorizationCalculator() {
  const [number, setNumber] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<FactorizationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const factorize = () => {
    setError("")
    setResult(null)

    const inputNum = number.trim()
    if (!inputNum || !/^-?\d+$/.test(inputNum)) {
      setError("Please enter a valid integer")
      return
    }

    let num = Number.parseInt(inputNum, 10)
    const isNegative = num < 0
    const originalNumber = num
    num = Math.abs(num)

    // Handle special cases
    if (num === 0) {
      setError("0 has no prime factorization (undefined)")
      return
    }

    if (num === 1) {
      setResult({
        originalNumber,
        isNegative: false,
        factors: [],
        standardForm: "1 (no prime factors)",
        latexForm: "1",
        steps: ["1 has no prime factors"],
      })
      return
    }

    const factors: PrimeFactor[] = []
    const steps: string[] = []
    let remaining = num

    if (isNegative) {
      steps.push(`Extract the negative sign: ${originalNumber} = -1 × ${num}`)
    }

    steps.push(`Starting with ${num}`)

    // Trial division up to sqrt(n)
    let divisor = 2
    while (divisor * divisor <= remaining) {
      let count = 0
      while (remaining % divisor === 0) {
        remaining = remaining / divisor
        count++
        steps.push(`${remaining * divisor} ÷ ${divisor} = ${remaining}`)
      }
      if (count > 0) {
        factors.push({ prime: divisor, exponent: count })
      }
      divisor++
    }

    // If remaining > 1, it's a prime factor
    if (remaining > 1) {
      factors.push({ prime: remaining, exponent: 1 })
      steps.push(`${remaining} is prime`)
    }

    // Generate standard form
    let standardForm = ""
    let latexForm = ""

    if (isNegative) {
      standardForm = "-1 × "
      latexForm = "-1 \\times "
    }

    if (factors.length === 0) {
      standardForm += "1"
      latexForm += "1"
    } else {
      const standardParts = factors.map((f) => (f.exponent === 1 ? `${f.prime}` : `${f.prime}^${f.exponent}`))
      const latexParts = factors.map((f) => (f.exponent === 1 ? `${f.prime}` : `${f.prime}^{${f.exponent}}`))

      standardForm += standardParts.join(" × ")
      latexForm += latexParts.join(" \\times ")
    }

    setResult({
      originalNumber,
      isNegative,
      factors,
      standardForm,
      latexForm,
      steps,
    })
  }

  const handleReset = () => {
    setNumber("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`${result.originalNumber} = ${result.standardForm}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      await navigator.clipboard.writeText(`${result.originalNumber} = ${result.latexForm}`)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Prime Factorization Result",
          text: `Prime factorization: ${result.originalNumber} = ${result.standardForm}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Prime Factorization</CardTitle>
                    <CardDescription>Decompose integers into prime factors</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Number Input */}
                <div className="space-y-2">
                  <Label htmlFor="number">Integer Number</Label>
                  <Input
                    id="number"
                    type="text"
                    placeholder="Enter an integer (e.g., 360, -120)"
                    value={number}
                    onChange={(e) => setNumber(e.target.value)}
                  />
                </div>

                {/* Step-by-step toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <Label htmlFor="show-steps" className="cursor-pointer">
                    Show step-by-step solution
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={factorize} className="w-full" size="lg">
                  Find Prime Factors
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Prime Factorization</p>
                      <p className="text-lg font-semibold text-blue-800 mb-2">
                        {result.originalNumber} = {result.standardForm}
                      </p>

                      {result.factors.length > 0 && (
                        <div className="mt-3 p-3 bg-white/70 rounded-lg">
                          <p className="text-sm text-muted-foreground mb-2">Prime Factors</p>
                          <div className="flex flex-wrap justify-center gap-2">
                            {result.isNegative && (
                              <span className="px-3 py-1 bg-gray-100 rounded-full text-sm font-medium">-1</span>
                            )}
                            {result.factors.map((f, i) => (
                              <span key={i} className="px-3 py-1 bg-blue-100 rounded-full text-sm font-medium">
                                {f.prime}
                                {f.exponent > 1 && <sup>{f.exponent}</sup>}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="flex items-center justify-between w-full p-3 bg-white/70 rounded-lg hover:bg-white/90 transition-colors"
                        >
                          <span className="font-medium text-sm">Step-by-Step Solution</span>
                          {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>

                        {showDetails && (
                          <div className="mt-2 p-3 bg-white/70 rounded-lg space-y-2">
                            {result.steps.map((step, i) => (
                              <div key={i} className="flex gap-2 text-sm">
                                <span className="text-blue-600 font-medium">{i + 1}.</span>
                                <span className="font-mono">{step}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Factorizations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">12</span>
                      <span className="text-sm text-muted-foreground">
                        2<sup>2</sup> × 3
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">60</span>
                      <span className="text-sm text-muted-foreground">
                        2<sup>2</sup> × 3 × 5
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">100</span>
                      <span className="text-sm text-muted-foreground">
                        2<sup>2</sup> × 5<sup>2</sup>
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">360</span>
                      <span className="text-sm text-muted-foreground">
                        2<sup>3</sup> × 3<sup>2</sup> × 5
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">1000</span>
                      <span className="text-sm text-muted-foreground">
                        2<sup>3</sup> × 5<sup>3</sup>
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Prime Factorization Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Trial Division Algorithm</p>
                    <ol className="list-decimal list-inside space-y-1 text-xs">
                      <li>Start with the smallest prime (2)</li>
                      <li>Divide n by the prime while divisible</li>
                      <li>Move to the next prime</li>
                      <li>Repeat until n = 1 or √n exceeded</li>
                      <li>{"If n > 1, it's a prime factor"}</li>
                    </ol>
                  </div>
                  <p>
                    <strong>Time Complexity:</strong> O(√n) for the optimized method
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Special Cases</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>0</span>
                      <span className="text-muted-foreground">Undefined</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1</span>
                      <span className="text-muted-foreground">No prime factors</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>-1</span>
                      <span className="text-muted-foreground">-1 (unit)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Prime</span>
                      <span className="text-muted-foreground">Itself</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Prime Factorization?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Prime factorization is the process of breaking down a composite number into a product of its prime
                  factors. According to the Fundamental Theorem of Arithmetic, every integer greater than 1 can be
                  expressed as a unique product of prime numbers (up to the order of factors). This unique
                  representation is extremely useful in mathematics.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, 360 = 2³ × 3² × 5, meaning 360 can be written as 2 × 2 × 2 × 3 × 3 × 5. This
                  decomposition is unique - no other combination of primes will multiply to give 360.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Prime Factorization</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Prime factorization has numerous applications in mathematics and computer science:
                </p>
                <ul className="text-muted-foreground mt-4 space-y-2">
                  <li>
                    <strong>Finding GCD and LCM:</strong> The greatest common divisor and least common multiple can be
                    easily calculated using prime factorizations.
                  </li>
                  <li>
                    <strong>Simplifying Fractions:</strong> Reduce fractions to lowest terms by canceling common prime
                    factors.
                  </li>
                  <li>
                    <strong>Cryptography:</strong> RSA encryption relies on the difficulty of factoring large numbers.
                  </li>
                  <li>
                    <strong>Number Theory:</strong> Understanding divisibility, perfect numbers, and other properties.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm">
                  This prime factorization calculator uses deterministic trial division. Very large numbers may require
                  more advanced algorithms (such as Pollard's rho or the quadratic sieve) for faster results. Results
                  are for educational purposes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
