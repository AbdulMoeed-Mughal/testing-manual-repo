"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, FlaskConical, Info, AlertTriangle, Atom, PieChart } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

// Periodic table with standard atomic weights
const periodicTable: Record<string, { name: string; weight: number }> = {
  H: { name: "Hydrogen", weight: 1.008 },
  He: { name: "Helium", weight: 4.0026 },
  Li: { name: "Lithium", weight: 6.94 },
  Be: { name: "Beryllium", weight: 9.0122 },
  B: { name: "Boron", weight: 10.81 },
  C: { name: "Carbon", weight: 12.011 },
  N: { name: "Nitrogen", weight: 14.007 },
  O: { name: "Oxygen", weight: 15.999 },
  F: { name: "Fluorine", weight: 18.998 },
  Ne: { name: "Neon", weight: 20.18 },
  Na: { name: "Sodium", weight: 22.99 },
  Mg: { name: "Magnesium", weight: 24.305 },
  Al: { name: "Aluminum", weight: 26.982 },
  Si: { name: "Silicon", weight: 28.085 },
  P: { name: "Phosphorus", weight: 30.974 },
  S: { name: "Sulfur", weight: 32.06 },
  Cl: { name: "Chlorine", weight: 35.45 },
  Ar: { name: "Argon", weight: 39.948 },
  K: { name: "Potassium", weight: 39.098 },
  Ca: { name: "Calcium", weight: 40.078 },
  Sc: { name: "Scandium", weight: 44.956 },
  Ti: { name: "Titanium", weight: 47.867 },
  V: { name: "Vanadium", weight: 50.942 },
  Cr: { name: "Chromium", weight: 51.996 },
  Mn: { name: "Manganese", weight: 54.938 },
  Fe: { name: "Iron", weight: 55.845 },
  Co: { name: "Cobalt", weight: 58.933 },
  Ni: { name: "Nickel", weight: 58.693 },
  Cu: { name: "Copper", weight: 63.546 },
  Zn: { name: "Zinc", weight: 65.38 },
  Ga: { name: "Gallium", weight: 69.723 },
  Ge: { name: "Germanium", weight: 72.63 },
  As: { name: "Arsenic", weight: 74.922 },
  Se: { name: "Selenium", weight: 78.971 },
  Br: { name: "Bromine", weight: 79.904 },
  Kr: { name: "Krypton", weight: 83.798 },
  Rb: { name: "Rubidium", weight: 85.468 },
  Sr: { name: "Strontium", weight: 87.62 },
  Y: { name: "Yttrium", weight: 88.906 },
  Zr: { name: "Zirconium", weight: 91.224 },
  Nb: { name: "Niobium", weight: 92.906 },
  Mo: { name: "Molybdenum", weight: 95.95 },
  Tc: { name: "Technetium", weight: 98 },
  Ru: { name: "Ruthenium", weight: 101.07 },
  Rh: { name: "Rhodium", weight: 102.91 },
  Pd: { name: "Palladium", weight: 106.42 },
  Ag: { name: "Silver", weight: 107.87 },
  Cd: { name: "Cadmium", weight: 112.41 },
  In: { name: "Indium", weight: 114.82 },
  Sn: { name: "Tin", weight: 118.71 },
  Sb: { name: "Antimony", weight: 121.76 },
  Te: { name: "Tellurium", weight: 127.6 },
  I: { name: "Iodine", weight: 126.9 },
  Xe: { name: "Xenon", weight: 131.29 },
  Cs: { name: "Cesium", weight: 132.91 },
  Ba: { name: "Barium", weight: 137.33 },
  La: { name: "Lanthanum", weight: 138.91 },
  Ce: { name: "Cerium", weight: 140.12 },
  Pr: { name: "Praseodymium", weight: 140.91 },
  Nd: { name: "Neodymium", weight: 144.24 },
  Pm: { name: "Promethium", weight: 145 },
  Sm: { name: "Samarium", weight: 150.36 },
  Eu: { name: "Europium", weight: 151.96 },
  Gd: { name: "Gadolinium", weight: 157.25 },
  Tb: { name: "Terbium", weight: 158.93 },
  Dy: { name: "Dysprosium", weight: 162.5 },
  Ho: { name: "Holmium", weight: 164.93 },
  Er: { name: "Erbium", weight: 167.26 },
  Tm: { name: "Thulium", weight: 168.93 },
  Yb: { name: "Ytterbium", weight: 173.05 },
  Lu: { name: "Lutetium", weight: 174.97 },
  Hf: { name: "Hafnium", weight: 178.49 },
  Ta: { name: "Tantalum", weight: 180.95 },
  W: { name: "Tungsten", weight: 183.84 },
  Re: { name: "Rhenium", weight: 186.21 },
  Os: { name: "Osmium", weight: 190.23 },
  Ir: { name: "Iridium", weight: 192.22 },
  Pt: { name: "Platinum", weight: 195.08 },
  Au: { name: "Gold", weight: 196.97 },
  Hg: { name: "Mercury", weight: 200.59 },
  Tl: { name: "Thallium", weight: 204.38 },
  Pb: { name: "Lead", weight: 207.2 },
  Bi: { name: "Bismuth", weight: 208.98 },
  Po: { name: "Polonium", weight: 209 },
  At: { name: "Astatine", weight: 210 },
  Rn: { name: "Radon", weight: 222 },
  Fr: { name: "Francium", weight: 223 },
  Ra: { name: "Radium", weight: 226 },
  Ac: { name: "Actinium", weight: 227 },
  Th: { name: "Thorium", weight: 232.04 },
  Pa: { name: "Protactinium", weight: 231.04 },
  U: { name: "Uranium", weight: 238.03 },
  Np: { name: "Neptunium", weight: 237 },
  Pu: { name: "Plutonium", weight: 244 },
  Am: { name: "Americium", weight: 243 },
  Cm: { name: "Curium", weight: 247 },
  Bk: { name: "Berkelium", weight: 247 },
  Cf: { name: "Californium", weight: 251 },
  Es: { name: "Einsteinium", weight: 252 },
  Fm: { name: "Fermium", weight: 257 },
  Md: { name: "Mendelevium", weight: 258 },
  No: { name: "Nobelium", weight: 259 },
  Lr: { name: "Lawrencium", weight: 266 },
  Rf: { name: "Rutherfordium", weight: 267 },
  Db: { name: "Dubnium", weight: 268 },
  Sg: { name: "Seaborgium", weight: 269 },
  Bh: { name: "Bohrium", weight: 270 },
  Hs: { name: "Hassium", weight: 277 },
  Mt: { name: "Meitnerium", weight: 278 },
  Ds: { name: "Darmstadtium", weight: 281 },
  Rg: { name: "Roentgenium", weight: 282 },
  Cn: { name: "Copernicium", weight: 285 },
  Nh: { name: "Nihonium", weight: 286 },
  Fl: { name: "Flerovium", weight: 289 },
  Mc: { name: "Moscovium", weight: 290 },
  Lv: { name: "Livermorium", weight: 293 },
  Ts: { name: "Tennessine", weight: 294 },
  Og: { name: "Oganesson", weight: 294 },
}

interface ElementComposition {
  symbol: string
  name: string
  atomCount: number
  atomicWeight: number
  massContribution: number
  percentComposition: number
}

interface CompositionResult {
  elements: ElementComposition[]
  totalMolarMass: number
  formula: string
}

// Element colors for pie chart
const elementColors: Record<string, string> = {
  H: "#ffffff",
  C: "#909090",
  N: "#3050f8",
  O: "#ff0d0d",
  S: "#ffff30",
  P: "#ff8000",
  Cl: "#1ff01f",
  Br: "#a62929",
  I: "#940094",
  F: "#90e050",
  Na: "#ab5cf2",
  K: "#8f40d4",
  Ca: "#3dff00",
  Mg: "#8aff00",
  Fe: "#e06633",
  Cu: "#c88033",
  Zn: "#7d80b0",
  default: "#6366f1",
}

export function PercentCompositionCalculator() {
  const [formula, setFormula] = useState("")
  const [compoundName, setCompoundName] = useState("")
  const [result, setResult] = useState<CompositionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showPieChart, setShowPieChart] = useState(false)

  // Parse chemical formula and return element counts
  const parseFormula = (formulaStr: string): Map<string, number> | null => {
    const elements = new Map<string, number>()

    // Handle hydration notation (e.g., CuSO4·5H2O)
    const parts = formulaStr.split(/[·•]/)

    for (let partIndex = 0; partIndex < parts.length; partIndex++) {
      const part = parts[partIndex].trim()
      let multiplier = 1

      // Check if this part starts with a number (like 5H2O)
      const partMatch = part.match(/^(\d+)(.+)$/)
      let partFormula = part
      if (partMatch) {
        multiplier = Number.parseInt(partMatch[1])
        partFormula = partMatch[2]
      }

      // Parse the formula part
      const partElements = parseFormulaPart(partFormula)
      if (!partElements) return null

      // Add to total with multiplier
      for (const [symbol, count] of partElements) {
        elements.set(symbol, (elements.get(symbol) || 0) + count * multiplier)
      }
    }

    return elements
  }

  const parseFormulaPart = (formulaStr: string): Map<string, number> | null => {
    const elements = new Map<string, number>()
    const stack: Map<string, number>[] = [new Map()]

    let i = 0
    while (i < formulaStr.length) {
      const char = formulaStr[i]

      if (char === "(") {
        stack.push(new Map())
        i++
      } else if (char === ")") {
        i++
        // Get the multiplier after the closing parenthesis
        let numStr = ""
        while (i < formulaStr.length && /\d/.test(formulaStr[i])) {
          numStr += formulaStr[i]
          i++
        }
        const multiplier = numStr ? Number.parseInt(numStr) : 1

        // Pop the group and multiply
        const group = stack.pop()
        if (!group || stack.length === 0) return null

        const current = stack[stack.length - 1]
        for (const [symbol, count] of group) {
          current.set(symbol, (current.get(symbol) || 0) + count * multiplier)
        }
      } else if (/[A-Z]/.test(char)) {
        // Element symbol
        let symbol = char
        i++
        while (i < formulaStr.length && /[a-z]/.test(formulaStr[i])) {
          symbol += formulaStr[i]
          i++
        }

        // Validate element
        if (!periodicTable[symbol]) {
          return null
        }

        // Get subscript
        let numStr = ""
        while (i < formulaStr.length && /\d/.test(formulaStr[i])) {
          numStr += formulaStr[i]
          i++
        }
        const count = numStr ? Number.parseInt(numStr) : 1

        const current = stack[stack.length - 1]
        current.set(symbol, (current.get(symbol) || 0) + count)
      } else {
        return null // Invalid character
      }
    }

    if (stack.length !== 1) return null // Unbalanced parentheses

    return stack[0]
  }

  const calculateComposition = () => {
    setError("")
    setResult(null)

    if (!formula.trim()) {
      setError("Please enter a chemical formula")
      return
    }

    const elementCounts = parseFormula(formula.trim())
    if (!elementCounts || elementCounts.size === 0) {
      setError("Invalid chemical formula. Please check the element symbols and syntax.")
      return
    }

    // Calculate molar mass and composition
    let totalMolarMass = 0
    const compositions: ElementComposition[] = []

    for (const [symbol, count] of elementCounts) {
      const element = periodicTable[symbol]
      const massContribution = element.weight * count
      totalMolarMass += massContribution

      compositions.push({
        symbol,
        name: element.name,
        atomCount: count,
        atomicWeight: element.weight,
        massContribution,
        percentComposition: 0, // Will calculate after total is known
      })
    }

    // Calculate percent composition
    for (const comp of compositions) {
      comp.percentComposition = (comp.massContribution / totalMolarMass) * 100
    }

    // Sort by percent composition (highest first)
    compositions.sort((a, b) => b.percentComposition - a.percentComposition)

    setResult({
      elements: compositions,
      totalMolarMass,
      formula: formula.trim(),
    })
  }

  const handleReset = () => {
    setFormula("")
    setCompoundName("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.elements.map((e) => `${e.name} (${e.symbol}): ${e.percentComposition.toFixed(2)}%`).join("\n")
      await navigator.clipboard.writeText(
        `Percent Composition of ${compoundName || result.formula}:\n${text}\nTotal Molar Mass: ${result.totalMolarMass.toFixed(4)} g/mol`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getElementColor = (symbol: string): string => {
    return elementColors[symbol] || elementColors.default
  }

  // Generate pie chart SVG
  const renderPieChart = () => {
    if (!result) return null

    const size = 200
    const center = size / 2
    const radius = 80
    let startAngle = 0

    const slices = result.elements.map((element, index) => {
      const angle = (element.percentComposition / 100) * 360
      const endAngle = startAngle + angle
      const largeArcFlag = angle > 180 ? 1 : 0

      const startRad = (startAngle - 90) * (Math.PI / 180)
      const endRad = (endAngle - 90) * (Math.PI / 180)

      const x1 = center + radius * Math.cos(startRad)
      const y1 = center + radius * Math.sin(startRad)
      const x2 = center + radius * Math.cos(endRad)
      const y2 = center + radius * Math.sin(endRad)

      const pathD = `M ${center} ${center} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} Z`

      const slice = (
        <path
          key={element.symbol}
          d={pathD}
          fill={getElementColor(element.symbol)}
          stroke="#1f2937"
          strokeWidth="1"
          className="transition-opacity hover:opacity-80"
        />
      )

      startAngle = endAngle
      return slice
    })

    return (
      <svg viewBox={`0 0 ${size} ${size}`} className="w-full max-w-[200px] mx-auto">
        {slices}
        <circle cx={center} cy={center} r={30} fill="#1f2937" />
        <text
          x={center}
          y={center}
          textAnchor="middle"
          dominantBaseline="middle"
          fill="white"
          fontSize="12"
          fontWeight="bold"
        >
          100%
        </text>
      </svg>
    )
  }

  const quickExamples = [
    { formula: "H2O", name: "Water" },
    { formula: "C6H12O6", name: "Glucose" },
    { formula: "NaCl", name: "Salt" },
    { formula: "CaCO3", name: "Calcium Carbonate" },
    { formula: "H2SO4", name: "Sulfuric Acid" },
    { formula: "C2H5OH", name: "Ethanol" },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Percent Composition Calculator</CardTitle>
                    <CardDescription>Calculate element percentages in a compound</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Formula Input */}
                <div className="space-y-2">
                  <Label htmlFor="formula">Chemical Formula</Label>
                  <Input
                    id="formula"
                    type="text"
                    placeholder="e.g., H2O, C6H12O6, Ca(OH)2"
                    value={formula}
                    onChange={(e) => setFormula(e.target.value)}
                    className="font-mono"
                  />
                  <p className="text-xs text-muted-foreground">
                    Supports parentheses and hydration notation (e.g., CuSO4·5H2O)
                  </p>
                </div>

                {/* Compound Name (optional) */}
                <div className="space-y-2">
                  <Label htmlFor="compoundName">Compound Name (optional)</Label>
                  <Input
                    id="compoundName"
                    type="text"
                    placeholder="e.g., Water, Glucose"
                    value={compoundName}
                    onChange={(e) => setCompoundName(e.target.value)}
                  />
                </div>

                {/* Quick Examples */}
                <div className="space-y-2">
                  <Label className="text-sm">Quick Examples</Label>
                  <div className="flex flex-wrap gap-2">
                    {quickExamples.map((example) => (
                      <Button
                        key={example.formula}
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setFormula(example.formula)
                          setCompoundName(example.name)
                        }}
                        className="text-xs"
                      >
                        {example.formula}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateComposition} className="w-full" size="lg">
                  Calculate Composition
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">
                        {compoundName || "Compound"}: <span className="font-mono font-semibold">{result.formula}</span>
                      </p>
                      <p className="text-3xl font-bold text-purple-600">{result.totalMolarMass.toFixed(4)} g/mol</p>
                      <p className="text-sm text-muted-foreground">Total Molar Mass</p>
                    </div>

                    {/* Toggle for Pie Chart */}
                    <div className="flex items-center justify-center gap-2 mb-4">
                      <Label htmlFor="pieChart" className="text-sm">
                        Table
                      </Label>
                      <Switch id="pieChart" checked={showPieChart} onCheckedChange={setShowPieChart} />
                      <Label htmlFor="pieChart" className="text-sm">
                        Pie Chart
                      </Label>
                    </div>

                    {showPieChart ? (
                      <div className="space-y-4">
                        {renderPieChart()}
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {result.elements.map((element) => (
                            <div key={element.symbol} className="flex items-center gap-2">
                              <div
                                className="w-3 h-3 rounded-full border border-gray-400"
                                style={{ backgroundColor: getElementColor(element.symbol) }}
                              />
                              <span className="font-mono">{element.symbol}</span>
                              <span className="text-muted-foreground">{element.percentComposition.toFixed(2)}%</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-purple-200">
                              <th className="text-left py-2 px-1">Element</th>
                              <th className="text-center py-2 px-1">Atoms</th>
                              <th className="text-right py-2 px-1">Mass (g/mol)</th>
                              <th className="text-right py-2 px-1">%</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.elements.map((element) => (
                              <tr key={element.symbol} className="border-b border-purple-100 last:border-0">
                                <td className="py-2 px-1">
                                  <span className="font-mono font-semibold">{element.symbol}</span>
                                  <span className="text-muted-foreground text-xs ml-1">({element.name})</span>
                                </td>
                                <td className="text-center py-2 px-1">{element.atomCount}</td>
                                <td className="text-right py-2 px-1 font-mono">
                                  {element.massContribution.toFixed(4)}
                                </td>
                                <td className="text-right py-2 px-1 font-semibold text-purple-600">
                                  {element.percentComposition.toFixed(2)}%
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Percent Composition Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">% Element = (Mass of element ÷ Molar mass) × 100</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Where mass of element = atomic weight × number of atoms
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Compounds</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">H₂O</span>
                      <span className="text-muted-foreground">Water (18.02 g/mol)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">CO₂</span>
                      <span className="text-muted-foreground">Carbon Dioxide (44.01 g/mol)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">NaCl</span>
                      <span className="text-muted-foreground">Sodium Chloride (58.44 g/mol)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">C₆H₁₂O₆</span>
                      <span className="text-muted-foreground">Glucose (180.16 g/mol)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Percent composition values are based on standard atomic weights and assume ideal purity. Actual
                        compositions may vary due to isotopic variations and sample impurities.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Percent Composition?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Percent composition is a fundamental concept in chemistry that describes the relative mass of each
                  element in a chemical compound. It tells you what percentage of the compound's total mass is made up
                  by each element. This information is crucial for understanding the makeup of substances, verifying
                  chemical formulas, and performing stoichiometric calculations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, in water (H₂O), the percent composition tells us that hydrogen makes up about 11.19% of
                  the mass while oxygen makes up about 88.81%. Despite having two hydrogen atoms for every oxygen atom,
                  oxygen dominates the mass because it's much heavier than hydrogen.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Percent Composition</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate percent composition, follow these steps:
                </p>
                <div className="mt-4 space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Step 1: Find the Molar Mass</h4>
                    <p className="text-purple-700 text-sm">
                      Calculate the total molar mass by adding up the atomic weights of all atoms in the formula.
                      Multiply each element's atomic weight by the number of atoms of that element.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">
                      Step 2: Calculate Each Element's Mass Contribution
                    </h4>
                    <p className="text-blue-700 text-sm">
                      For each element, multiply its atomic weight by the number of atoms in the formula to get its
                      total mass contribution.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Step 3: Calculate the Percentage</h4>
                    <p className="text-green-700 text-sm">
                      Divide each element's mass contribution by the total molar mass, then multiply by 100 to get the
                      percentage.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Percent Composition</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Percent composition has many practical applications in chemistry and related fields:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Determining Empirical Formulas:</strong> When analyzing unknown compounds, percent
                    composition data can be used to determine the simplest whole-number ratio of atoms in a compound.
                  </li>
                  <li>
                    <strong>Quality Control:</strong> In manufacturing, percent composition is used to verify that
                    products meet specifications and contain the correct amounts of each component.
                  </li>
                  <li>
                    <strong>Nutrition:</strong> Food labels show the percentage of nutrients like protein,
                    carbohydrates, and fats, which are based on percent composition calculations.
                  </li>
                  <li>
                    <strong>Environmental Analysis:</strong> Scientists use percent composition to analyze pollutants,
                    soil samples, and water quality.
                  </li>
                  <li>
                    <strong>Pharmaceutical Industry:</strong> Drug formulations require precise percent composition to
                    ensure correct dosages and effectiveness.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
