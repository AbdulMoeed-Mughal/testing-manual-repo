"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  DollarSign,
  Info,
  TrendingUp,
  AlertTriangle,
  PieChart,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Currency = "USD" | "EUR" | "GBP" | "INR" | "JPY" | "CAD" | "AUD"

const currencies: { value: Currency; label: string; symbol: string }[] = [
  { value: "USD", label: "USD ($)", symbol: "$" },
  { value: "EUR", label: "EUR (€)", symbol: "€" },
  { value: "GBP", label: "GBP (£)", symbol: "£" },
  { value: "INR", label: "INR (₹)", symbol: "₹" },
  { value: "JPY", label: "JPY (¥)", symbol: "¥" },
  { value: "CAD", label: "CAD ($)", symbol: "C$" },
  { value: "AUD", label: "AUD ($)", symbol: "A$" },
]

interface ProfitResult {
  grossProfit: number
  grossMargin: number
  netProfit: number
  netMargin: number
  totalExpenses: number
  isHealthy: boolean
}

export function ProfitMarginCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [revenue, setRevenue] = useState("")
  const [cogs, setCogs] = useState("")
  const [operatingExpenses, setOperatingExpenses] = useState("")
  const [otherExpenses, setOtherExpenses] = useState("")
  const [result, setResult] = useState<ProfitResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const currencySymbol = currencies.find((c) => c.value === currency)?.symbol || "$"

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value)
  }

  const calculateProfitMargin = () => {
    setError("")
    setResult(null)

    const revenueNum = Number.parseFloat(revenue)
    const cogsNum = Number.parseFloat(cogs) || 0
    const operatingNum = Number.parseFloat(operatingExpenses) || 0
    const otherNum = Number.parseFloat(otherExpenses) || 0

    if (isNaN(revenueNum) || revenueNum <= 0) {
      setError("Please enter a valid revenue amount greater than 0")
      return
    }

    if (cogsNum < 0 || operatingNum < 0 || otherNum < 0) {
      setError("Costs and expenses cannot be negative")
      return
    }

    if (cogsNum > revenueNum) {
      setError("Cost of Goods Sold cannot exceed Revenue")
      return
    }

    const grossProfit = revenueNum - cogsNum
    const grossMargin = (grossProfit / revenueNum) * 100

    const totalExpenses = cogsNum + operatingNum + otherNum
    const netProfit = revenueNum - totalExpenses
    const netMargin = (netProfit / revenueNum) * 100

    const isHealthy = netMargin >= 10

    setResult({
      grossProfit,
      grossMargin,
      netProfit,
      netMargin,
      totalExpenses,
      isHealthy,
    })
  }

  const handleReset = () => {
    setRevenue("")
    setCogs("")
    setOperatingExpenses("")
    setOtherExpenses("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Profit Margin Results:
Gross Profit: ${formatCurrency(result.grossProfit)} (${result.grossMargin.toFixed(1)}%)
Net Profit: ${formatCurrency(result.netProfit)} (${result.netMargin.toFixed(1)}%)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Profit Margin Results",
          text: `I calculated my profit margins using CalcHub! Gross Margin: ${result.grossMargin.toFixed(1)}%, Net Margin: ${result.netMargin.toFixed(1)}%`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getMarginColor = (margin: number) => {
    if (margin >= 20) return { color: "text-green-600", bg: "bg-green-50 border-green-200" }
    if (margin >= 10) return { color: "text-blue-600", bg: "bg-blue-50 border-blue-200" }
    if (margin >= 0) return { color: "text-yellow-600", bg: "bg-yellow-50 border-yellow-200" }
    return { color: "text-red-600", bg: "bg-red-50 border-red-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <PieChart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Profit Margin Calculator</CardTitle>
                    <CardDescription>Calculate gross and net profit margins</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {currencies.map((c) => (
                      <option key={c.value} value={c.value}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Revenue Input */}
                <div className="space-y-2">
                  <Label htmlFor="revenue">Revenue / Sales ({currencySymbol})</Label>
                  <Input
                    id="revenue"
                    type="number"
                    placeholder="Enter total revenue"
                    value={revenue}
                    onChange={(e) => setRevenue(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* COGS Input */}
                <div className="space-y-2">
                  <Label htmlFor="cogs">Cost of Goods Sold ({currencySymbol})</Label>
                  <Input
                    id="cogs"
                    type="number"
                    placeholder="Enter COGS"
                    value={cogs}
                    onChange={(e) => setCogs(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Operating Expenses Input */}
                <div className="space-y-2">
                  <Label htmlFor="operating">
                    Operating Expenses ({currencySymbol}){" "}
                    <span className="text-muted-foreground font-normal">- Optional</span>
                  </Label>
                  <Input
                    id="operating"
                    type="number"
                    placeholder="Enter operating expenses"
                    value={operatingExpenses}
                    onChange={(e) => setOperatingExpenses(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Other Expenses Input */}
                <div className="space-y-2">
                  <Label htmlFor="other">
                    Other Expenses ({currencySymbol}){" "}
                    <span className="text-muted-foreground font-normal">- Optional</span>
                  </Label>
                  <Input
                    id="other"
                    type="number"
                    placeholder="Enter other expenses"
                    value={otherExpenses}
                    onChange={(e) => setOtherExpenses(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateProfitMargin} className="w-full" size="lg">
                  Calculate Profit Margin
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getMarginColor(result.netMargin).bg} transition-all duration-300`}
                  >
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Net Profit Margin</p>
                      <p className={`text-5xl font-bold ${getMarginColor(result.netMargin).color} mb-1`}>
                        {result.netMargin.toFixed(1)}%
                      </p>
                      <p className={`text-lg font-semibold ${getMarginColor(result.netMargin).color}`}>
                        {formatCurrency(result.netProfit)}
                      </p>
                    </div>

                    {/* Breakdown */}
                    <div className="space-y-2 text-sm border-t border-current/10 pt-4 mt-4">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Gross Profit:</span>
                        <span className="font-medium">{formatCurrency(result.grossProfit)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Gross Margin:</span>
                        <span className="font-medium">{result.grossMargin.toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Total Expenses:</span>
                        <span className="font-medium">{formatCurrency(result.totalExpenses)}</span>
                      </div>
                    </div>

                    {/* Health Indicator */}
                    {!result.isHealthy && result.netMargin >= 0 && (
                      <div className="mt-4 p-2 rounded-lg bg-yellow-100 border border-yellow-300 text-yellow-700 text-xs flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                        <span>Net margin below 10% may indicate tight profitability</span>
                      </div>
                    )}

                    {result.netMargin < 0 && (
                      <div className="mt-4 p-2 rounded-lg bg-red-100 border border-red-300 text-red-700 text-xs flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                        <span>Negative margin indicates a loss - review costs</span>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Margin Benchmarks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-sm text-green-600">{"≥ 20%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-sm text-blue-600">10% – 19.9%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Low</span>
                      <span className="text-sm text-yellow-600">0% – 9.9%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Loss</span>
                      <span className="text-sm text-red-600">{"< 0%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas Used</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-xs mb-1">Gross Profit</p>
                    <p className="font-mono text-xs">Revenue − COGS</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-xs mb-1">Gross Margin %</p>
                    <p className="font-mono text-xs">(Gross Profit ÷ Revenue) × 100</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-xs mb-1">Net Profit</p>
                    <p className="font-mono text-xs">Revenue − All Expenses</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-xs mb-1">Net Margin %</p>
                    <p className="font-mono text-xs">(Net Profit ÷ Revenue) × 100</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Actual profits may vary based on business conditions,
                        tax obligations, and accounting methods.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Profit Margin?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Profit margin is one of the most important financial metrics for any business, representing the
                  percentage of revenue that remains as profit after accounting for costs and expenses. It serves as a
                  key indicator of a company's financial health, operational efficiency, and pricing strategy
                  effectiveness. Understanding profit margins helps business owners, investors, and managers make
                  informed decisions about pricing, cost control, and overall business strategy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  There are two primary types of profit margins: gross profit margin and net profit margin. Gross profit
                  margin measures the profitability of a company's core business operations by showing what percentage
                  of revenue remains after subtracting the direct costs of producing goods or services (Cost of Goods
                  Sold). Net profit margin, on the other hand, provides a more comprehensive picture by accounting for
                  all expenses, including operating costs, interest, and taxes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Gross vs Net Margin</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gross profit margin focuses exclusively on the relationship between revenue and the direct costs of
                  production. For a manufacturing company, COGS includes raw materials, direct labor, and manufacturing
                  overhead. For a retailer, it's the wholesale cost of inventory. A healthy gross margin indicates that
                  your pricing strategy is effective and your production costs are under control. Industry benchmarks
                  vary widely—software companies often enjoy gross margins of 80-90%, while grocery retailers may
                  operate on margins as low as 25-30%.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Net profit margin tells the complete story of profitability. It accounts for operating expenses like
                  rent, utilities, marketing, salaries, insurance, and depreciation, as well as interest payments and
                  taxes. A company might have an excellent gross margin but poor net margin due to high operating
                  expenses or excessive debt. Conversely, efficient operations can turn a modest gross margin into a
                  healthy net profit. Most successful businesses aim for a net profit margin of at least 10%, though
                  this varies significantly by industry.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Profit Margins</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence profit margins, and understanding them is crucial for business success.
                  Pricing strategy is perhaps the most direct lever—raising prices can improve margins, but only if
                  customers perceive sufficient value and competitors don't undercut you. Cost management is equally
                  important; negotiating better supplier terms, improving operational efficiency, and reducing waste can
                  all boost margins without touching prices.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Product mix also plays a significant role. Businesses often carry products with varying margins, and
                  shifting sales toward higher-margin offerings can improve overall profitability. Volume is another
                  consideration—while selling more units at lower margins can sometimes generate more total profit, it
                  also increases operational complexity and risk. Economic conditions, competitive pressure, and
                  seasonal fluctuations all impact margins, making regular monitoring and analysis essential for
                  long-term success.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-primary" />
                  <CardTitle>Strategies to Improve Profit Margins</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Improving profit margins requires a multi-faceted approach. Start by analyzing your cost structure to
                  identify areas of waste or inefficiency. Review supplier contracts and consider bulk purchasing or
                  alternative vendors. Evaluate your pricing strategy—many businesses undercharge, leaving money on the
                  table. Conduct market research to understand what customers are willing to pay and position your
                  offerings accordingly.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Operational efficiency improvements can significantly impact margins. Automate repetitive tasks,
                  streamline workflows, and invest in employee training to boost productivity. Focus on customer
                  retention, as acquiring new customers typically costs 5-25 times more than retaining existing ones.
                  Consider value-added services or premium offerings that command higher margins. Finally, regularly
                  review your product line and consider discontinuing low-margin items that don't contribute to
                  strategic goals like customer acquisition or brand awareness.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
