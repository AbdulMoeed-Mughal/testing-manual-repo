"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Hash, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

type Mode = "count" | "round"

interface SigFigResult {
  originalNumber: string
  sigFigs: number
  roundedNumber?: string
  scientificNotation: string
  steps: string[]
}

export function SignificantFiguresCalculator() {
  const [mode, setMode] = useState<Mode>("count")
  const [inputValue, setInputValue] = useState("")
  const [desiredSigFigs, setDesiredSigFigs] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<SigFigResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedSci, setCopiedSci] = useState(false)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(true)

  const countSignificantFigures = (numStr: string): { count: number; steps: string[] } => {
    const steps: string[] = []
    let cleanStr = numStr.trim()

    // Handle negative numbers
    if (cleanStr.startsWith("-")) {
      cleanStr = cleanStr.substring(1)
      steps.push("Removed negative sign (doesn't affect sig figs)")
    }

    // Handle scientific notation
    let mantissa = cleanStr
    let exponentPart = ""
    if (cleanStr.toLowerCase().includes("e")) {
      const parts = cleanStr.toLowerCase().split("e")
      mantissa = parts[0]
      exponentPart = parts[1]
      steps.push(`Identified scientific notation: mantissa = ${mantissa}, exponent = 10^${exponentPart}`)
    }

    // Remove decimal point for counting
    const hasDecimal = mantissa.includes(".")
    const digits = mantissa.replace(".", "")

    if (hasDecimal) {
      steps.push("Number contains a decimal point")
    }

    let sigFigCount = 0
    let foundNonZero = false
    let trailingZeros = 0

    for (let i = 0; i < digits.length; i++) {
      const digit = digits[i]

      if (digit !== "0") {
        foundNonZero = true
        sigFigCount += 1 + trailingZeros
        trailingZeros = 0
        steps.push(`Digit '${digit}' at position ${i + 1}: Non-zero digit, significant (count: ${sigFigCount})`)
      } else if (foundNonZero) {
        // Zero after non-zero - could be significant
        if (hasDecimal) {
          sigFigCount++
          steps.push(
            `Digit '0' at position ${i + 1}: Zero after decimal with non-zero, significant (count: ${sigFigCount})`,
          )
        } else {
          trailingZeros++
          steps.push(`Digit '0' at position ${i + 1}: Trailing zero without decimal, potentially not significant`)
        }
      } else {
        steps.push(`Digit '0' at position ${i + 1}: Leading zero, not significant`)
      }
    }

    // Handle trailing zeros after decimal point
    if (hasDecimal && !foundNonZero) {
      // Number like 0.000
      sigFigCount = 1
      steps.push("Number is zero - has 1 significant figure")
    }

    return { count: sigFigCount, steps }
  }

  const roundToSigFigs = (num: number, sigFigs: number): string => {
    if (num === 0) return "0"

    const magnitude = Math.floor(Math.log10(Math.abs(num)))
    const multiplier = Math.pow(10, sigFigs - magnitude - 1)
    const rounded = Math.round(num * multiplier) / multiplier

    // Format to show correct number of sig figs
    if (magnitude >= sigFigs - 1) {
      return rounded.toString()
    } else {
      const decimalPlaces = sigFigs - magnitude - 1
      return rounded.toFixed(decimalPlaces)
    }
  }

  const toScientificNotation = (numStr: string, sigFigs: number): string => {
    const num = Number.parseFloat(numStr)
    if (num === 0) return "0"
    if (isNaN(num)) return numStr

    const exponent = Math.floor(Math.log10(Math.abs(num)))
    const mantissa = num / Math.pow(10, exponent)
    const roundedMantissa = Number.parseFloat(mantissa.toFixed(sigFigs - 1))

    return `${roundedMantissa} × 10^${exponent}`
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (!inputValue.trim()) {
      setError("Please enter a number")
      return
    }

    // Validate input is a valid number
    const cleanInput = inputValue.trim()
    const numValue = Number.parseFloat(cleanInput)

    if (isNaN(numValue)) {
      setError("Please enter a valid number")
      return
    }

    if (mode === "round") {
      const desiredNum = Number.parseInt(desiredSigFigs)
      if (isNaN(desiredNum) || desiredNum < 1) {
        setError("Please enter a valid number of significant figures (positive integer)")
        return
      }
    }

    const { count, steps } = countSignificantFigures(cleanInput)

    let roundedNumber: string | undefined
    let roundingSteps: string[] = []

    if (mode === "round" && desiredSigFigs) {
      const targetSigFigs = Number.parseInt(desiredSigFigs)
      roundedNumber = roundToSigFigs(numValue, targetSigFigs)
      roundingSteps = [
        `Rounding ${cleanInput} to ${targetSigFigs} significant figure${targetSigFigs > 1 ? "s" : ""}`,
        `Result: ${roundedNumber}`,
      ]
    }

    const scientificNotation = toScientificNotation(
      mode === "round" && roundedNumber ? roundedNumber : cleanInput,
      mode === "round" && desiredSigFigs ? Number.parseInt(desiredSigFigs) : count,
    )

    setResult({
      originalNumber: cleanInput,
      sigFigs: count,
      roundedNumber,
      scientificNotation,
      steps: [...steps, ...roundingSteps],
    })
  }

  const handleReset = () => {
    setInputValue("")
    setDesiredSigFigs("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedSci(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        mode === "round" && result.roundedNumber
          ? result.roundedNumber
          : `${result.sigFigs} significant figure${result.sigFigs !== 1 ? "s" : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopySci = async () => {
    if (result) {
      await navigator.clipboard.writeText(result.scientificNotation)
      setCopiedSci(true)
      setTimeout(() => setCopiedSci(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text =
          mode === "round" && result.roundedNumber
            ? `${result.originalNumber} rounded to ${desiredSigFigs} sig figs = ${result.roundedNumber}`
            : `${result.originalNumber} has ${result.sigFigs} significant figure${result.sigFigs !== 1 ? "s" : ""}`
        await navigator.share({
          title: "Significant Figures Result",
          text: `I calculated significant figures using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  // Comparison table for different sig fig counts
  const getComparisonTable = () => {
    if (!result) return []
    const num = Number.parseFloat(result.originalNumber)
    if (isNaN(num)) return []

    const rows = []
    for (let sf = 1; sf <= Math.min(6, result.sigFigs + 2); sf++) {
      rows.push({
        sigFigs: sf,
        rounded: roundToSigFigs(num, sf),
        scientific: toScientificNotation(roundToSigFigs(num, sf), sf),
      })
    }
    return rows
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Hash className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Significant Figures Calculator</CardTitle>
                    <CardDescription>Count or round to significant figures</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Mode</span>
                  <button
                    onClick={() => {
                      setMode(mode === "count" ? "round" : "count")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "round" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "count" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Count
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "round" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Round
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Number Input */}
                <div className="space-y-2">
                  <Label htmlFor="inputValue">Number</Label>
                  <Input
                    id="inputValue"
                    type="text"
                    placeholder="e.g., 0.00456, 1.230, 5.67e-3"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Supports integers, decimals, and scientific notation (e.g., 1.23e4)
                  </p>
                </div>

                {/* Desired Sig Figs (only in round mode) */}
                {mode === "round" && (
                  <div className="space-y-2">
                    <Label htmlFor="desiredSigFigs">Round to Significant Figures</Label>
                    <Input
                      id="desiredSigFigs"
                      type="number"
                      placeholder="e.g., 3"
                      value={desiredSigFigs}
                      onChange={(e) => setDesiredSigFigs(e.target.value)}
                      min="1"
                      max="15"
                    />
                  </div>
                )}

                {/* Step-by-step toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps" className="cursor-pointer">
                    Show step-by-step explanation
                  </Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  {mode === "count" ? "Count Significant Figures" : "Round Number"}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      {mode === "count" ? (
                        <>
                          <p className="text-sm text-muted-foreground">Number of Significant Figures</p>
                          <p className="text-5xl font-bold text-blue-600">{result.sigFigs}</p>
                          <p className="text-sm text-muted-foreground">
                            in <span className="font-mono font-semibold">{result.originalNumber}</span>
                          </p>
                        </>
                      ) : (
                        <>
                          <p className="text-sm text-muted-foreground">
                            Rounded to {desiredSigFigs} Significant Figure
                            {Number.parseInt(desiredSigFigs) !== 1 ? "s" : ""}
                          </p>
                          <p className="text-4xl font-bold text-blue-600 font-mono">{result.roundedNumber}</p>
                          <p className="text-sm text-muted-foreground">
                            Original: <span className="font-mono">{result.originalNumber}</span> ({result.sigFigs} sig
                            figs)
                          </p>
                        </>
                      )}

                      <div className="pt-2 border-t border-blue-200">
                        <p className="text-xs text-muted-foreground mb-1">Scientific Notation</p>
                        <p className="font-mono text-sm text-blue-700">{result.scientificNotation}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopySci}>
                        {copiedSci ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedSci ? "Copied" : "Sci"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-step breakdown */}
                {result && showSteps && result.steps.length > 0 && (
                  <Collapsible open={stepsOpen} onOpenChange={setStepsOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="outline" className="w-full justify-between bg-transparent">
                        Step-by-Step Explanation
                        <ChevronDown className={`h-4 w-4 transition-transform ${stepsOpen ? "rotate-180" : ""}`} />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-3">
                      <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                        {result.steps.map((step, index) => (
                          <div key={index} className="flex gap-3 text-sm">
                            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-medium">
                              {index + 1}
                            </span>
                            <span className="text-muted-foreground">{step}</span>
                          </div>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}

                {/* Comparison Table */}
                {result && (
                  <Collapsible>
                    <CollapsibleTrigger asChild>
                      <Button variant="outline" className="w-full justify-between bg-transparent">
                        Comparison Table
                        <ChevronDown className="h-4 w-4" />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-3">
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left py-2 px-3 font-medium">Sig Figs</th>
                              <th className="text-left py-2 px-3 font-medium">Rounded</th>
                              <th className="text-left py-2 px-3 font-medium">Scientific</th>
                            </tr>
                          </thead>
                          <tbody>
                            {getComparisonTable().map((row) => (
                              <tr key={row.sigFigs} className="border-b last:border-0">
                                <td className="py-2 px-3">{row.sigFigs}</td>
                                <td className="py-2 px-3 font-mono">{row.rounded}</td>
                                <td className="py-2 px-3 font-mono text-xs">{row.scientific}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Significant Figures Rules</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-700">Non-zero digits</p>
                      <p className="text-green-600 text-xs mt-1">Always significant (1-9)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700">Zeros between non-zeros</p>
                      <p className="text-blue-600 text-xs mt-1">Always significant (e.g., 101 has 3 sig figs)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <p className="font-medium text-yellow-700">Leading zeros</p>
                      <p className="text-yellow-600 text-xs mt-1">Never significant (e.g., 0.005 has 1 sig fig)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-700">Trailing zeros after decimal</p>
                      <p className="text-purple-600 text-xs mt-1">Always significant (e.g., 2.50 has 3 sig figs)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <p className="font-medium text-orange-700">Trailing zeros without decimal</p>
                      <p className="text-orange-600 text-xs mt-1">Ambiguous (e.g., 100 could be 1, 2, or 3 sig figs)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">0.00340</span>
                      <span className="font-medium">3 sig figs</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">1.200</span>
                      <span className="font-medium">4 sig figs</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">5000</span>
                      <span className="font-medium">1-4 sig figs*</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">5.00 × 10³</span>
                      <span className="font-medium">3 sig figs</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">0.0070</span>
                      <span className="font-medium">2 sig figs</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    *Use scientific notation to clarify ambiguous cases
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Standard:</strong> 123.456, 0.00789
                  </p>
                  <p>
                    <strong>Scientific:</strong> 1.23e4, 5.67e-3
                  </p>
                  <p>
                    <strong>Negative:</strong> -45.6, -1.2e-5
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Significant Figures?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Significant figures (also called significant digits or sig figs) are the digits in a number that carry
                  meaningful information about its precision. They indicate the reliability of a measurement and are
                  essential in scientific and engineering calculations to properly represent the accuracy of data.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When performing calculations with measured values, the result should not have more significant figures
                  than the least precise measurement used. This ensures that reported values don't imply greater
                  precision than the original data supports.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Count Mode:</strong> Enter any number to determine how many significant figures it contains.
                  The calculator analyzes each digit according to standard rules and provides a step-by-step
                  explanation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Round Mode:</strong> Enter a number and specify the desired number of significant figures. The
                  calculator will round your number appropriately while maintaining the correct precision.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Significant figures calculations follow standard rules. Results depend on correct input formatting and
                  selected rounding conventions. For ambiguous cases (like trailing zeros without a decimal point),
                  consider using scientific notation to clearly indicate the intended precision.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
