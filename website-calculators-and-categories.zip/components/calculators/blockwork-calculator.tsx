"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Box, Info, Calculator, Package } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type BlockSize = "standard" | "large" | "custom"
type MortarRatio = "1:3" | "1:4" | "1:5" | "1:6"

interface BlockworkResult {
  wallVolume: number
  numberOfBlocks: number
  mortarVolume: number
  cement: { bags: number; kg: number }
  sand: { volume: number; kg: number }
}

export function BlockworkCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [wallLength, setWallLength] = useState("")
  const [wallHeight, setWallHeight] = useState("")
  const [wallThickness, setWallThickness] = useState("")
  const [blockSize, setBlockSize] = useState<BlockSize>("standard")
  const [blockLength, setBlockLength] = useState("0.4")
  const [blockHeight, setBlockHeight] = useState("0.2")
  const [blockWidth, setBlockWidth] = useState("0.2")
  const [mortarRatio, setMortarRatio] = useState<MortarRatio>("1:4")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<BlockworkResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBlockwork = () => {
    setError("")
    setResult(null)

    const wallLengthNum = Number.parseFloat(wallLength)
    const wallHeightNum = Number.parseFloat(wallHeight)
    const wallThicknessNum = Number.parseFloat(wallThickness)
    const blockLengthNum = Number.parseFloat(blockLength)
    const blockHeightNum = Number.parseFloat(blockHeight)
    const blockWidthNum = Number.parseFloat(blockWidth)
    const wastageNum = Number.parseFloat(wastage)

    if (isNaN(wallLengthNum) || wallLengthNum <= 0) {
      setError("Please enter a valid wall length greater than 0")
      return
    }

    if (isNaN(wallHeightNum) || wallHeightNum <= 0) {
      setError("Please enter a valid wall height greater than 0")
      return
    }

    if (isNaN(wallThicknessNum) || wallThicknessNum <= 0) {
      setError("Please enter a valid wall thickness greater than 0")
      return
    }

    if (isNaN(blockLengthNum) || blockLengthNum <= 0) {
      setError("Please enter a valid block length greater than 0")
      return
    }

    if (isNaN(blockHeightNum) || blockHeightNum <= 0) {
      setError("Please enter a valid block height greater than 0")
      return
    }

    if (isNaN(blockWidthNum) || blockWidthNum <= 0) {
      setError("Please enter a valid block width greater than 0")
      return
    }

    if (wallThicknessNum < blockWidthNum) {
      setError("Wall thickness must be at least equal to block width")
      return
    }

    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }

    // Convert to meters if imperial
    let wallLengthM = wallLengthNum
    let wallHeightM = wallHeightNum
    let wallThicknessM = wallThicknessNum
    let blockLengthM = blockLengthNum
    let blockHeightM = blockHeightNum
    let blockWidthM = blockWidthNum

    if (unitSystem === "imperial") {
      wallLengthM = wallLengthNum * 0.3048
      wallHeightM = wallHeightNum * 0.3048
      wallThicknessM = wallThicknessNum * 0.3048
      blockLengthM = blockLengthNum * 0.3048
      blockHeightM = blockHeightNum * 0.3048
      blockWidthM = blockWidthNum * 0.3048
    }

    const wastageMultiplier = 1 + wastageNum / 100

    // Calculate wall volume
    const wallVolume = wallLengthM * wallHeightM * wallThicknessM

    // Calculate single block volume
    const blockVolume = blockLengthM * blockHeightM * blockWidthM

    // Number of blocks (accounting for mortar joints)
    const mortarThickness = 0.01 // 10mm mortar joint
    const effectiveBlockLength = blockLengthM + mortarThickness
    const effectiveBlockHeight = blockHeightM + mortarThickness

    const blocksPerLength = wallLengthM / effectiveBlockLength
    const blocksPerHeight = wallHeightM / effectiveBlockHeight
    const numberOfBlocks = Math.ceil(blocksPerLength * blocksPerHeight * wastageMultiplier)

    // Calculate mortar volume (approximately 30% of wall volume)
    const mortarVolume = wallVolume * 0.3
    const dryMortarVolume = mortarVolume * 1.54 // Dry volume factor

    // Calculate cement and sand based on mortar ratio
    const ratio = mortarRatio.split(":").map((p) => Number.parseFloat(p))
    const totalParts = ratio.reduce((sum, p) => sum + p, 0)

    const cementVolume = (dryMortarVolume * ratio[0]) / totalParts
    const sandVolume = (dryMortarVolume * ratio[1]) / totalParts

    const cementKg = cementVolume * 1440 * wastageMultiplier // Cement density
    const cementBags = cementKg / 50

    setResult({
      wallVolume,
      numberOfBlocks,
      mortarVolume,
      cement: { bags: cementBags, kg: cementKg },
      sand: { volume: sandVolume * wastageMultiplier, kg: sandVolume * 1600 * wastageMultiplier },
    })
  }

  const handleReset = () => {
    setWallLength("")
    setWallHeight("")
    setWallThickness("")
    setBlockSize("standard")
    setBlockLength("0.4")
    setBlockHeight("0.2")
    setBlockWidth("0.2")
    setMortarRatio("1:4")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Blockwork Calculator Results:\nBlocks Required: ${result.numberOfBlocks}\nCement: ${result.cement.bags.toFixed(0)} bags\nSand: ${result.sand.volume.toFixed(2)} m³`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Blockwork Calculator Results",
          text: `Blocks Required: ${result.numberOfBlocks}, Cement: ${result.cement.bags.toFixed(0)} bags`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWallLength("")
    setWallHeight("")
    setWallThickness("")
    setResult(null)
    setError("")
  }

  const handleBlockSizeChange = (size: BlockSize) => {
    setBlockSize(size)
    if (size === "standard") {
      setBlockLength(unitSystem === "metric" ? "0.4" : "1.312")
      setBlockHeight(unitSystem === "metric" ? "0.2" : "0.656")
      setBlockWidth(unitSystem === "metric" ? "0.2" : "0.656")
    } else if (size === "large") {
      setBlockLength(unitSystem === "metric" ? "0.6" : "1.969")
      setBlockHeight(unitSystem === "metric" ? "0.2" : "0.656")
      setBlockWidth(unitSystem === "metric" ? "0.2" : "0.656")
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Box className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Blockwork Calculator</CardTitle>
                    <CardDescription>Calculate blocks and mortar for masonry walls</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Wall Dimensions */}
                <div className="space-y-2">
                  <Label htmlFor="wallLength">Wall Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="wallLength"
                    type="number"
                    placeholder="Enter wall length"
                    value={wallLength}
                    onChange={(e) => setWallLength(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="wallHeight">Wall Height ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="wallHeight"
                    type="number"
                    placeholder="Enter wall height"
                    value={wallHeight}
                    onChange={(e) => setWallHeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="wallThickness">Wall Thickness ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="wallThickness"
                    type="number"
                    placeholder="Enter wall thickness"
                    value={wallThickness}
                    onChange={(e) => setWallThickness(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Block Size Selection */}
                <div className="space-y-2">
                  <Label htmlFor="blockSize">Block Size</Label>
                  <Select value={blockSize} onValueChange={(value: BlockSize) => handleBlockSizeChange(value)}>
                    <SelectTrigger id="blockSize">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard (400×200×200mm)</SelectItem>
                      <SelectItem value="large">Large (600×200×200mm)</SelectItem>
                      <SelectItem value="custom">Custom Size</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Custom Block Dimensions */}
                {blockSize === "custom" && (
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-2">
                      <Label htmlFor="blockLength">Length</Label>
                      <Input
                        id="blockLength"
                        type="number"
                        placeholder="L"
                        value={blockLength}
                        onChange={(e) => setBlockLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="blockHeight">Height</Label>
                      <Input
                        id="blockHeight"
                        type="number"
                        placeholder="H"
                        value={blockHeight}
                        onChange={(e) => setBlockHeight(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="blockWidth">Width</Label>
                      <Input
                        id="blockWidth"
                        type="number"
                        placeholder="W"
                        value={blockWidth}
                        onChange={(e) => setBlockWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                )}

                {/* Mortar and Wastage */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="mortarRatio">Mortar Mix</Label>
                    <Select value={mortarRatio} onValueChange={(value: MortarRatio) => setMortarRatio(value)}>
                      <SelectTrigger id="mortarRatio">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1:3">1:3 (Rich)</SelectItem>
                        <SelectItem value="1:4">1:4 (Standard)</SelectItem>
                        <SelectItem value="1:5">1:5 (Medium)</SelectItem>
                        <SelectItem value="1:6">1:6 (Lean)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wastage">Wastage (%)</Label>
                    <Input
                      id="wastage"
                      type="number"
                      value={wastage}
                      onChange={(e) => setWastage(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBlockwork} className="w-full" size="lg">
                  Calculate Materials
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Blocks Required</p>
                        <p className="text-3xl font-bold text-amber-600">{result.numberOfBlocks.toLocaleString()}</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between p-2 bg-white rounded">
                          <span className="font-medium">Mortar Volume:</span>
                          <span className="text-amber-700">{result.mortarVolume.toFixed(2)} m³</span>
                        </div>
                        <div className="flex justify-between p-2 bg-white rounded">
                          <span className="font-medium">Cement:</span>
                          <span className="text-amber-700">
                            {result.cement.bags.toFixed(0)} bags ({result.cement.kg.toFixed(0)} kg)
                          </span>
                        </div>
                        <div className="flex justify-between p-2 bg-white rounded">
                          <span className="font-medium">Sand:</span>
                          <span className="text-amber-700">
                            {result.sand.volume.toFixed(2)} m³ ({result.sand.kg.toFixed(0)} kg)
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Block Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Standard Block</h4>
                      <p className="text-sm text-amber-700">400 × 200 × 200 mm (16″ × 8″ × 8″)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Large Block</h4>
                      <p className="text-sm text-amber-700">600 × 200 × 200 mm (24″ × 8″ × 8″)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">AAC Block</h4>
                      <p className="text-sm text-amber-700">600 × 200 × 100-300 mm (lightweight)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mortar Mix Ratios</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">1:3 (Rich Mix)</p>
                    <p>High strength for external walls</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">1:4 (Standard)</p>
                    <p>General purpose masonry work</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">1:6 (Lean Mix)</p>
                    <p>Internal non-load bearing walls</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Blockwork */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Blockwork?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Blockwork refers to the construction technique of building walls using concrete blocks, also known as
                  concrete masonry units (CMUs) or cement blocks. These blocks are larger than traditional bricks,
                  typically measuring 400×200×200mm (16″×8″×8″) for standard sizes, allowing for faster construction
                  compared to brickwork. Blocks are manufactured from cement, aggregate, and water, and may be solid or
                  hollow depending on their intended use. The hollow cores in many blocks provide advantages such as
                  reduced weight, improved thermal insulation, and space for reinforcement or utilities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Blockwork is widely used in both residential and commercial construction for load-bearing walls,
                  partition walls, boundary walls, and basement construction. Modern variations include autoclaved
                  aerated concrete (AAC) blocks, which are extremely lightweight and offer superior thermal insulation
                  properties. The efficiency of blockwork lies in its speed of construction, consistent dimensions for
                  easier alignment, and the structural integrity provided by larger units bonded with mortar joints.
                  Understanding material quantities ensures proper planning and cost estimation for blockwork projects.
                </p>
              </CardContent>
            </Card>

            {/* Calculation Method */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Blockwork Materials?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating blockwork materials involves determining both the number of blocks required and the
                  quantity of mortar for joints. First, calculate the wall area by multiplying length by height. To
                  find the number of blocks, consider the effective area covered by each block including mortar joints
                  (typically 10mm thick). For a standard 400×200mm block with joints, the effective coverage is
                  approximately 410×210mm per block face. Divide the total wall area by the effective block coverage
                  area to determine the number of blocks needed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Mortar volume calculation requires understanding that mortar fills approximately 30% of the total wall
                  volume in blockwork construction. Calculate the wall volume (length × height × thickness), then
                  multiply by 0.3 to get wet mortar volume. Apply the dry volume factor of 1.54 to convert to dry
                  material quantities. Based on the selected mortar mix ratio (cement:sand), determine proportions of
                  each material. Standard cement density is 1440 kg/m³, allowing conversion of volume to weight and
                  number of bags. Always add a wastage factor (typically 5-10%) to account for cutting, breakage, and
                  material handling losses.
                </p>
              </CardContent>
            </Card>

            {/* Best Practices */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  <CardTitle>Blockwork Best Practices</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Successful blockwork construction requires attention to several critical factors. Block quality is
                  paramount – ensure blocks are properly cured, have consistent dimensions, and meet relevant standards
                  for compressive strength. Blocks should be dry when laid to prevent excessive moisture absorption from
                  mortar, which can weaken bond strength. Store blocks on level ground protected from rain and ground
                  moisture. Mortar consistency is crucial; it should be workable but not too wet, maintaining proper
                  proportions of cement, sand, and water for adequate strength and workability.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  During construction, maintain level and plumb alignment using string lines and spirit levels
                  throughout the work. Proper bonding patterns (running bond, English bond, etc.) distribute loads
                  effectively and prevent continuous vertical joints that create weak points. Fill all joints completely
                  and tool them appropriately for weather resistance. For load-bearing walls, consider reinforcement
                  using steel bars placed in hollow cores filled with concrete grout. Curing is essential – keep newly
                  constructed walls moist for at least 7 days to allow proper cement hydration and strength development.
                  Quality workmanship, proper supervision, and adherence to structural drawings ensure durable, safe
                  blockwork construction.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Calculations provided by this blockwork calculator are approximate
                  estimates based on standard formulas and typical construction practices. Actual material requirements
                  depend on block size variations, mortar thickness, joint quality, workmanship, cutting waste, and site
                  conditions. Block dimensions may vary slightly between manufacturers. Always verify actual block sizes
                  before ordering and add appropriate wastage factors. This calculator is intended for planning and
                  estimation purposes only. For structural or load-bearing walls, consult qualified structural engineers
                  and follow local building codes and regulations. Proper supervision by experienced masons is essential
                  for quality blockwork construction.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
