"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Scale,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Circle,
  Square,
  RectangleHorizontal,
  CircleDot,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type SteelShape = "round" | "square" | "rectangular" | "hollow-pipe"

interface SteelResult {
  volumePerPiece: number
  weightPerPiece: number
  totalWeight: number
  volumeUnit: string
  weightUnit: string
}

export function SteelWeightCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [shape, setShape] = useState<SteelShape>("round")
  const [diameter, setDiameter] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [outerDiameter, setOuterDiameter] = useState("")
  const [innerDiameter, setInnerDiameter] = useState("")
  const [length, setLength] = useState("")
  const [density, setDensity] = useState(unitSystem === "metric" ? "7850" : "0.284")
  const [quantity, setQuantity] = useState("1")
  const [result, setResult] = useState<SteelResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const shapes = [
    { id: "round" as SteelShape, name: "Round Bar", icon: Circle },
    { id: "square" as SteelShape, name: "Square Bar", icon: Square },
    { id: "rectangular" as SteelShape, name: "Rectangular Bar", icon: RectangleHorizontal },
    { id: "hollow-pipe" as SteelShape, name: "Hollow Pipe", icon: CircleDot },
  ]

  const calculateWeight = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const densityNum = Number.parseFloat(density)
    const quantityNum = Number.parseInt(quantity) || 1

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }

    if (isNaN(densityNum) || densityNum <= 0) {
      setError("Please enter a valid density greater than 0")
      return
    }

    if (quantityNum < 1) {
      setError("Number of pieces must be at least 1")
      return
    }

    let volume: number // in m³ for metric, in³ for imperial
    let lengthInM: number
    let crossSectionArea: number // in m² for metric, in² for imperial

    if (unitSystem === "metric") {
      lengthInM = lengthNum // length in meters
    } else {
      lengthInM = lengthNum * 0.3048 // convert feet to meters for calculation
    }

    switch (shape) {
      case "round": {
        const d = Number.parseFloat(diameter)
        if (isNaN(d) || d <= 0) {
          setError("Please enter a valid diameter greater than 0")
          return
        }
        // Convert mm to m for metric, inches stay as inches
        const radiusInM = unitSystem === "metric" ? d / 1000 / 2 : (d * 0.0254) / 2
        crossSectionArea = Math.PI * radiusInM * radiusInM
        volume = crossSectionArea * lengthInM
        break
      }
      case "square": {
        const w = Number.parseFloat(width)
        if (isNaN(w) || w <= 0) {
          setError("Please enter a valid width greater than 0")
          return
        }
        const sideInM = unitSystem === "metric" ? w / 1000 : w * 0.0254
        crossSectionArea = sideInM * sideInM
        volume = crossSectionArea * lengthInM
        break
      }
      case "rectangular": {
        const w = Number.parseFloat(width)
        const h = Number.parseFloat(height)
        if (isNaN(w) || w <= 0 || isNaN(h) || h <= 0) {
          setError("Please enter valid width and height greater than 0")
          return
        }
        const widthInM = unitSystem === "metric" ? w / 1000 : w * 0.0254
        const heightInM = unitSystem === "metric" ? h / 1000 : h * 0.0254
        crossSectionArea = widthInM * heightInM
        volume = crossSectionArea * lengthInM
        break
      }
      case "hollow-pipe": {
        const od = Number.parseFloat(outerDiameter)
        const id = Number.parseFloat(innerDiameter)
        if (isNaN(od) || od <= 0 || isNaN(id) || id <= 0) {
          setError("Please enter valid outer and inner diameters greater than 0")
          return
        }
        if (id >= od) {
          setError("Inner diameter must be less than outer diameter")
          return
        }
        const outerRadiusInM = unitSystem === "metric" ? od / 1000 / 2 : (od * 0.0254) / 2
        const innerRadiusInM = unitSystem === "metric" ? id / 1000 / 2 : (id * 0.0254) / 2
        crossSectionArea = Math.PI * (outerRadiusInM * outerRadiusInM - innerRadiusInM * innerRadiusInM)
        volume = crossSectionArea * lengthInM
        break
      }
    }

    // Weight calculation: volume (m³) × density (kg/m³) = weight (kg)
    const densityInKgM3 = unitSystem === "metric" ? densityNum : densityNum * 27679.9 // convert lb/in³ to kg/m³
    const weightPerPieceKg = volume * densityInKgM3
    const totalWeightKg = weightPerPieceKg * quantityNum

    // Convert to display units
    let displayWeight: number
    let displayTotal: number
    let displayVolume: number

    if (unitSystem === "metric") {
      displayWeight = weightPerPieceKg
      displayTotal = totalWeightKg
      displayVolume = volume * 1000000 // m³ to cm³
    } else {
      displayWeight = weightPerPieceKg * 2.20462 // kg to lb
      displayTotal = totalWeightKg * 2.20462
      displayVolume = volume * 61023.7 // m³ to in³
    }

    setResult({
      volumePerPiece: displayVolume,
      weightPerPiece: displayWeight,
      totalWeight: displayTotal,
      volumeUnit: unitSystem === "metric" ? "cm³" : "in³",
      weightUnit: unitSystem === "metric" ? "kg" : "lb",
    })
  }

  const handleReset = () => {
    setDiameter("")
    setWidth("")
    setHeight("")
    setOuterDiameter("")
    setInnerDiameter("")
    setLength("")
    setDensity(unitSystem === "metric" ? "7850" : "0.284")
    setQuantity("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Steel Weight: ${result.weightPerPiece.toFixed(2)} ${result.weightUnit} per piece, Total: ${result.totalWeight.toFixed(2)} ${result.weightUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Steel Weight Result",
          text: `Steel Weight: ${result.weightPerPiece.toFixed(2)} ${result.weightUnit} per piece, Total: ${result.totalWeight.toFixed(2)} ${result.weightUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    const newSystem = unitSystem === "metric" ? "imperial" : "metric"
    setUnitSystem(newSystem)
    setDensity(newSystem === "metric" ? "7850" : "0.284")
    setResult(null)
    setError("")
  }

  const getFormulaDisplay = () => {
    switch (shape) {
      case "round":
        return "V = π × (D/2)² × L"
      case "square":
        return "V = W × W × L"
      case "rectangular":
        return "V = W × H × L"
      case "hollow-pipe":
        return "V = π × (R²outer − R²inner) × L"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Steel Weight Calculator</CardTitle>
                    <CardDescription>Calculate the weight of steel shapes</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Shape Selector */}
                <div className="space-y-2">
                  <Label>Steel Shape</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {shapes.map((s) => (
                      <button
                        key={s.id}
                        onClick={() => {
                          setShape(s.id)
                          setResult(null)
                          setError("")
                        }}
                        className={`flex items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                          shape === s.id
                            ? "border-amber-500 bg-amber-50 text-amber-700"
                            : "border-muted hover:border-muted-foreground/30"
                        }`}
                      >
                        <s.icon className="h-5 w-5" />
                        <span className="text-sm font-medium">{s.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Shape-specific inputs */}
                {shape === "round" && (
                  <div className="space-y-2">
                    <Label htmlFor="diameter">Diameter ({unitSystem === "metric" ? "mm" : "inches"})</Label>
                    <Input
                      id="diameter"
                      type="number"
                      placeholder={`Enter diameter in ${unitSystem === "metric" ? "mm" : "inches"}`}
                      value={diameter}
                      onChange={(e) => setDiameter(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                )}

                {shape === "square" && (
                  <div className="space-y-2">
                    <Label htmlFor="width">Side Width ({unitSystem === "metric" ? "mm" : "inches"})</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder={`Enter side width in ${unitSystem === "metric" ? "mm" : "inches"}`}
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                )}

                {shape === "rectangular" && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="width">Width ({unitSystem === "metric" ? "mm" : "in"})</Label>
                      <Input
                        id="width"
                        type="number"
                        placeholder="Width"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="height">Height ({unitSystem === "metric" ? "mm" : "in"})</Label>
                      <Input
                        id="height"
                        type="number"
                        placeholder="Height"
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                )}

                {shape === "hollow-pipe" && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="outerDiameter">Outer Dia ({unitSystem === "metric" ? "mm" : "in"})</Label>
                      <Input
                        id="outerDiameter"
                        type="number"
                        placeholder="Outer diameter"
                        value={outerDiameter}
                        onChange={(e) => setOuterDiameter(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="innerDiameter">Inner Dia ({unitSystem === "metric" ? "mm" : "in"})</Label>
                      <Input
                        id="innerDiameter"
                        type="number"
                        placeholder="Inner diameter"
                        value={innerDiameter}
                        onChange={(e) => setInnerDiameter(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                )}

                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Density Input */}
                <div className="space-y-2">
                  <Label htmlFor="density">Density ({unitSystem === "metric" ? "kg/m³" : "lb/in³"})</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder="Steel density"
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                  <p className="text-xs text-muted-foreground">
                    Standard steel: {unitSystem === "metric" ? "7850 kg/m³" : "0.284 lb/in³"}
                  </p>
                </div>

                {/* Quantity Input */}
                <div className="space-y-2">
                  <Label htmlFor="quantity">Number of Pieces</Label>
                  <Input
                    id="quantity"
                    type="number"
                    placeholder="Enter quantity"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWeight} className="w-full" size="lg">
                  Calculate Weight
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Weight per Piece</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">
                        {result.weightPerPiece.toFixed(2)} {result.weightUnit}
                      </p>
                      {Number.parseInt(quantity) > 1 && (
                        <p className="text-lg font-semibold text-amber-700">
                          Total ({quantity} pcs): {result.totalWeight.toFixed(2)} {result.weightUnit}
                        </p>
                      )}
                      <p className="text-sm text-muted-foreground mt-2">
                        Volume: {result.volumePerPiece.toFixed(2)} {result.volumeUnit}
                      </p>
                    </div>

                    {/* Step-by-step breakdown */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-center gap-1 w-full mt-3 text-sm text-amber-700 hover:text-amber-800"
                    >
                      {showSteps ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide calculation steps
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show calculation steps
                        </>
                      )}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p className="font-medium">Calculation Steps:</p>
                        <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                          <li>Calculate cross-sectional area using {shape} formula</li>
                          <li>
                            Volume = Area × Length = {result.volumePerPiece.toFixed(4)} {result.volumeUnit}
                          </li>
                          <li>
                            Weight = Volume × Density = {result.weightPerPiece.toFixed(2)} {result.weightUnit}
                          </li>
                          {Number.parseInt(quantity) > 1 && (
                            <li>
                              Total = {result.weightPerPiece.toFixed(2)} × {quantity} = {result.totalWeight.toFixed(2)}{" "}
                              {result.weightUnit}
                            </li>
                          )}
                        </ol>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Volume Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-muted">
                      <div className="flex items-center gap-2 mb-1">
                        <Circle className="h-4 w-4" />
                        <span className="font-medium text-sm">Round Bar</span>
                      </div>
                      <p className="text-sm font-mono">V = π × (D/2)² × L</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <div className="flex items-center gap-2 mb-1">
                        <Square className="h-4 w-4" />
                        <span className="font-medium text-sm">Square Bar</span>
                      </div>
                      <p className="text-sm font-mono">V = W × W × L</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <div className="flex items-center gap-2 mb-1">
                        <RectangleHorizontal className="h-4 w-4" />
                        <span className="font-medium text-sm">Rectangular Bar</span>
                      </div>
                      <p className="text-sm font-mono">V = W × H × L</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <div className="flex items-center gap-2 mb-1">
                        <CircleDot className="h-4 w-4" />
                        <span className="font-medium text-sm">Hollow Pipe</span>
                      </div>
                      <p className="text-sm font-mono">V = π × (R²out − R²in) × L</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Steel Densities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Carbon Steel</span>
                      <span className="font-medium">7850 kg/m³</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Stainless Steel</span>
                      <span className="font-medium">7480-8000 kg/m³</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Tool Steel</span>
                      <span className="font-medium">7720 kg/m³</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Cast Iron</span>
                      <span className="font-medium">7200 kg/m³</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual steel weight may vary due to manufacturing tolerances and material
                        composition.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Steel Weight Calculation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Steel weight calculation is essential for construction, engineering, and manufacturing projects.
                  Knowing the weight of steel components helps in structural design, transportation planning, material
                  procurement, and cost estimation. The weight is determined by calculating the volume of the steel
                  shape and multiplying it by the material density.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The basic formula for calculating steel weight is: <strong>Weight = Volume × Density</strong>. The
                  volume calculation varies depending on the shape of the steel section. For round bars, we use the
                  circular cross-section formula; for rectangular sections, we multiply width, height, and length; and
                  for hollow pipes, we calculate the difference between outer and inner cylindrical volumes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Steel Shapes and Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid sm:grid-cols-2 gap-4 mt-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Round Bars</h4>
                    <p className="text-sm text-muted-foreground">
                      Used in reinforcement, shafts, axles, and fasteners. Common in rebar for concrete reinforcement.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Square Bars</h4>
                    <p className="text-sm text-muted-foreground">
                      Used in machine parts, agricultural equipment, brackets, and decorative ironwork.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Rectangular Bars (Flat Bars)</h4>
                    <p className="text-sm text-muted-foreground">
                      Used in frames, bracing, supports, gates, and general fabrication work.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Hollow Pipes</h4>
                    <p className="text-sm text-muted-foreground">
                      Used in plumbing, structural columns, handrails, and mechanical tubing applications.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="space-y-2 text-muted-foreground">
                  <li>
                    <strong>Verify density:</strong> Different steel grades have slightly different densities. Standard
                    carbon steel is 7850 kg/m³, but stainless steel can range from 7480 to 8000 kg/m³.
                  </li>
                  <li>
                    <strong>Account for tolerances:</strong> Manufacturing tolerances can affect actual dimensions. Add
                    2-5% allowance for critical applications.
                  </li>
                  <li>
                    <strong>Measure accurately:</strong> Use calipers for diameter and thickness measurements rather
                    than relying on nominal sizes.
                  </li>
                  <li>
                    <strong>Consider cutting loss:</strong> When ordering material, account for cutting waste and
                    offcuts in your total weight estimate.
                  </li>
                  <li>
                    <strong>Check units:</strong> Ensure consistent units throughout your calculation. Mixing metric and
                    imperial units is a common source of errors.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
