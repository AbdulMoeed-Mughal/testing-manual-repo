"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  Receipt,
  PiggyBank,
  Plus,
  Trash2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  TrendingUp,
  TrendingDown,
  Calendar,
  CreditCard,
  Wallet,
  Target,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Expense {
  id: string
  name: string
  amount: string
  category: string
  date: string
  paymentMethod: string
}

interface CategoryBudget {
  category: string
  limit: string
}

interface TrackingResult {
  totalExpenses: number
  expensesByCategory: { category: string; amount: number; percentage: number; budget?: number; overBudget: boolean }[]
  expensesByPaymentMethod: { method: string; amount: number; percentage: number }[]
  remainingBudget: number
  status: "under" | "on-track" | "over"
  largestExpense: { name: string; amount: number; category: string }
  averageExpense: number
  expenseCount: number
}

const EXPENSE_CATEGORIES = [
  "Housing",
  "Transportation",
  "Food & Dining",
  "Utilities",
  "Healthcare",
  "Entertainment",
  "Shopping",
  "Personal Care",
  "Education",
  "Savings",
  "Debt Payments",
  "Insurance",
  "Other",
]

const PAYMENT_METHODS = ["Cash", "Debit Card", "Credit Card", "Bank Transfer", "Mobile Payment", "Other"]

export function MonthlyExpenseTracker() {
  const [expenses, setExpenses] = useState<Expense[]>([
    { id: "1", name: "", amount: "", category: "Food & Dining", date: "", paymentMethod: "Debit Card" },
  ])
  const [monthlyIncome, setMonthlyIncome] = useState("")
  const [categoryBudgets, setCategoryBudgets] = useState<CategoryBudget[]>([])
  const [showBudgets, setShowBudgets] = useState(false)
  const [result, setResult] = useState<TrackingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const addExpense = () => {
    setExpenses([
      ...expenses,
      {
        id: Date.now().toString(),
        name: "",
        amount: "",
        category: "Food & Dining",
        date: "",
        paymentMethod: "Debit Card",
      },
    ])
  }

  const removeExpense = (id: string) => {
    if (expenses.length > 1) {
      setExpenses(expenses.filter((e) => e.id !== id))
    }
  }

  const updateExpense = (id: string, field: keyof Expense, value: string) => {
    setExpenses(expenses.map((e) => (e.id === id ? { ...e, [field]: value } : e)))
  }

  const addCategoryBudget = () => {
    const usedCategories = categoryBudgets.map((b) => b.category)
    const availableCategory = EXPENSE_CATEGORIES.find((c) => !usedCategories.includes(c))
    if (availableCategory) {
      setCategoryBudgets([...categoryBudgets, { category: availableCategory, limit: "" }])
    }
  }

  const removeCategoryBudget = (index: number) => {
    setCategoryBudgets(categoryBudgets.filter((_, i) => i !== index))
  }

  const updateCategoryBudget = (index: number, field: keyof CategoryBudget, value: string) => {
    setCategoryBudgets(categoryBudgets.map((b, i) => (i === index ? { ...b, [field]: value } : b)))
  }

  const calculateExpenses = () => {
    setError("")
    setResult(null)

    // Validate expenses
    const validExpenses = expenses.filter((e) => e.name && e.amount)
    if (validExpenses.length === 0) {
      setError("Please enter at least one expense")
      return
    }

    for (const expense of validExpenses) {
      if (Number.parseFloat(expense.amount) < 0) {
        setError("Expense amounts must be non-negative")
        return
      }
    }

    // Calculate total expenses
    const totalExpenses = validExpenses.reduce((sum, e) => sum + Number.parseFloat(e.amount), 0)

    // Calculate expenses by category
    const categoryTotals: Record<string, number> = {}
    for (const expense of validExpenses) {
      categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + Number.parseFloat(expense.amount)
    }

    const budgetMap: Record<string, number> = {}
    for (const budget of categoryBudgets) {
      if (budget.limit) {
        budgetMap[budget.category] = Number.parseFloat(budget.limit)
      }
    }

    const expensesByCategory = Object.entries(categoryTotals)
      .map(([category, amount]) => ({
        category,
        amount,
        percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0,
        budget: budgetMap[category],
        overBudget: budgetMap[category] ? amount > budgetMap[category] : false,
      }))
      .sort((a, b) => b.amount - a.amount)

    // Calculate expenses by payment method
    const methodTotals: Record<string, number> = {}
    for (const expense of validExpenses) {
      methodTotals[expense.paymentMethod] =
        (methodTotals[expense.paymentMethod] || 0) + Number.parseFloat(expense.amount)
    }

    const expensesByPaymentMethod = Object.entries(methodTotals)
      .map(([method, amount]) => ({
        method,
        amount,
        percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0,
      }))
      .sort((a, b) => b.amount - a.amount)

    // Calculate remaining budget
    const income = monthlyIncome ? Number.parseFloat(monthlyIncome) : 0
    const remainingBudget = income - totalExpenses

    // Determine status
    let status: "under" | "on-track" | "over" = "on-track"
    if (income > 0) {
      const spendingRatio = totalExpenses / income
      if (spendingRatio < 0.8) status = "under"
      else if (spendingRatio > 1) status = "over"
    }

    // Find largest expense
    const largestExpenseItem = validExpenses.reduce(
      (max, e) => (Number.parseFloat(e.amount) > Number.parseFloat(max.amount) ? e : max),
      validExpenses[0],
    )

    const largestExpense = {
      name: largestExpenseItem.name,
      amount: Number.parseFloat(largestExpenseItem.amount),
      category: largestExpenseItem.category,
    }

    // Calculate average expense
    const averageExpense = totalExpenses / validExpenses.length

    setResult({
      totalExpenses,
      expensesByCategory,
      expensesByPaymentMethod,
      remainingBudget,
      status,
      largestExpense,
      averageExpense,
      expenseCount: validExpenses.length,
    })
  }

  const handleReset = () => {
    setExpenses([{ id: "1", name: "", amount: "", category: "Food & Dining", date: "", paymentMethod: "Debit Card" }])
    setMonthlyIncome("")
    setCategoryBudgets([])
    setShowBudgets(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Monthly Expense Summary:\nTotal Expenses: $${result.totalExpenses.toLocaleString()}\nExpense Count: ${result.expenseCount}\nAverage Expense: $${result.averageExpense.toFixed(2)}\nLargest Expense: ${result.largestExpense.name} ($${result.largestExpense.amount.toFixed(2)})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Monthly Expenses",
          text: `I tracked ${result.expenseCount} expenses totaling $${result.totalExpenses.toLocaleString()} this month!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "under":
        return "bg-green-50 border-green-200 text-green-700"
      case "over":
        return "bg-red-50 border-red-200 text-red-700"
      default:
        return "bg-yellow-50 border-yellow-200 text-yellow-700"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "under":
        return <TrendingDown className="h-5 w-5" />
      case "over":
        return <TrendingUp className="h-5 w-5" />
      default:
        return <Target className="h-5 w-5" />
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "under":
        return "Under Budget"
      case "over":
        return "Over Budget"
      default:
        return "On Track"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Receipt className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Monthly Expense Tracker</CardTitle>
                    <CardDescription>Track and categorize your monthly spending</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Monthly Income (Optional) */}
                <div className="space-y-2">
                  <Label>Monthly Income (Optional)</Label>
                  <Input
                    type="number"
                    placeholder="Enter your monthly income"
                    value={monthlyIncome}
                    onChange={(e) => setMonthlyIncome(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Expenses */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Expenses</Label>
                    <Button variant="outline" size="sm" onClick={addExpense}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  <div className="max-h-80 overflow-y-auto space-y-3 pr-1">
                    {expenses.map((expense, index) => (
                      <div key={expense.id} className="p-3 border rounded-lg space-y-2 bg-muted/30">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium text-muted-foreground">Expense #{index + 1}</span>
                          {expenses.length > 1 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeExpense(expense.id)}
                              className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Input
                            placeholder="Expense name"
                            value={expense.name}
                            onChange={(e) => updateExpense(expense.id, "name", e.target.value)}
                          />
                          <Input
                            type="number"
                            placeholder="Amount"
                            value={expense.amount}
                            onChange={(e) => updateExpense(expense.id, "amount", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Select
                            value={expense.category}
                            onValueChange={(value) => updateExpense(expense.id, "category", value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Category" />
                            </SelectTrigger>
                            <SelectContent>
                              {EXPENSE_CATEGORIES.map((cat) => (
                                <SelectItem key={cat} value={cat}>
                                  {cat}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Select
                            value={expense.paymentMethod}
                            onValueChange={(value) => updateExpense(expense.id, "paymentMethod", value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Payment" />
                            </SelectTrigger>
                            <SelectContent>
                              {PAYMENT_METHODS.map((method) => (
                                <SelectItem key={method} value={method}>
                                  {method}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <Input
                          type="date"
                          value={expense.date}
                          onChange={(e) => updateExpense(expense.id, "date", e.target.value)}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Category Budgets (Optional) */}
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowBudgets(!showBudgets)}
                    className="w-full justify-between"
                  >
                    <span>Category Budgets (Optional)</span>
                    {showBudgets ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>

                  {showBudgets && (
                    <div className="space-y-2">
                      {categoryBudgets.map((budget, index) => (
                        <div key={index} className="flex gap-2 items-center">
                          <Select
                            value={budget.category}
                            onValueChange={(value) => updateCategoryBudget(index, "category", value)}
                          >
                            <SelectTrigger className="flex-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {EXPENSE_CATEGORIES.map((cat) => (
                                <SelectItem key={cat} value={cat}>
                                  {cat}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Input
                            type="number"
                            placeholder="Limit"
                            value={budget.limit}
                            onChange={(e) => updateCategoryBudget(index, "limit", e.target.value)}
                            className="w-24"
                            min="0"
                          />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeCategoryBudget(index)}
                            className="h-8 w-8 p-0 text-red-500"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={addCategoryBudget}
                        disabled={categoryBudgets.length >= EXPENSE_CATEGORIES.length}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Add Budget
                      </Button>
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateExpenses} className="w-full" size="lg">
                  Track Expenses
                </Button>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleReset} className="flex-1 bg-transparent">
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                  <Button variant="outline" onClick={handleCopy} disabled={!result} className="flex-1 bg-transparent">
                    {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                    {copied ? "Copied!" : "Copy"}
                  </Button>
                  <Button variant="outline" onClick={handleShare} disabled={!result} className="flex-1 bg-transparent">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${monthlyIncome ? getStatusColor(result.status) : "bg-blue-50 border-blue-200 text-blue-700"}`}
                  >
                    <div className="text-center mb-4">
                      {monthlyIncome && (
                        <div className="flex items-center justify-center gap-2 mb-1">
                          {getStatusIcon(result.status)}
                          <p className="text-sm font-medium">{getStatusLabel(result.status)}</p>
                        </div>
                      )}
                      <p className="text-3xl font-bold mb-1">{formatCurrency(result.totalExpenses)}</p>
                      <p className="text-sm opacity-80">Total Monthly Expenses ({result.expenseCount} items)</p>
                    </div>

                    {monthlyIncome && (
                      <div className="grid grid-cols-2 gap-3 mb-4">
                        <div className="p-3 bg-white/80 rounded-lg text-center">
                          <p className="text-xs text-muted-foreground">Monthly Income</p>
                          <p className="text-lg font-semibold text-green-600">
                            {formatCurrency(Number.parseFloat(monthlyIncome))}
                          </p>
                        </div>
                        <div className="p-3 bg-white/80 rounded-lg text-center">
                          <p className="text-xs text-muted-foreground">Remaining</p>
                          <p
                            className={`text-lg font-semibold ${result.remainingBudget >= 0 ? "text-green-600" : "text-red-600"}`}
                          >
                            {formatCurrency(result.remainingBudget)}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Category Breakdown */}
                    <div className="mb-4">
                      <p className="text-sm font-semibold mb-2">By Category:</p>
                      <div className="space-y-2 max-h-40 overflow-y-auto">
                        {result.expensesByCategory.map((item) => (
                          <div key={item.category} className="bg-white/80 rounded-lg p-2">
                            <div className="flex justify-between text-sm mb-1">
                              <span className="flex items-center gap-1">
                                {item.category}
                                {item.overBudget && (
                                  <AlertTriangle className="h-3 w-3 text-red-500" title="Over budget" />
                                )}
                              </span>
                              <span className="font-medium">
                                {formatCurrency(item.amount)} ({item.percentage.toFixed(1)}%)
                              </span>
                            </div>
                            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${item.overBudget ? "bg-red-500" : "bg-green-500"}`}
                                style={{ width: `${Math.min(item.percentage, 100)}%` }}
                              />
                            </div>
                            {item.budget && (
                              <p className="text-xs text-muted-foreground mt-1">
                                Budget: {formatCurrency(item.budget)} (
                                {item.overBudget ? (
                                  <span className="text-red-500">{formatCurrency(item.amount - item.budget)} over</span>
                                ) : (
                                  <span className="text-green-500">
                                    {formatCurrency(item.budget - item.amount)} left
                                  </span>
                                )}
                                )
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full justify-center"
                    >
                      {showDetails ? "Hide Details" : "Show Details"}
                      {showDetails ? <ChevronUp className="ml-2 h-4 w-4" /> : <ChevronDown className="ml-2 h-4 w-4" />}
                    </Button>

                    {showDetails && (
                      <div className="mt-3 space-y-3">
                        {/* Payment Method Breakdown */}
                        <div>
                          <p className="text-sm font-semibold mb-2">By Payment Method:</p>
                          <div className="space-y-1">
                            {result.expensesByPaymentMethod.map((item) => (
                              <div key={item.method} className="flex justify-between text-sm bg-white/80 rounded p-2">
                                <span>{item.method}</span>
                                <span className="font-medium">
                                  {formatCurrency(item.amount)} ({item.percentage.toFixed(1)}%)
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Insights */}
                        <div>
                          <p className="text-sm font-semibold mb-2">Insights:</p>
                          <div className="space-y-1 text-sm">
                            <div className="bg-white/80 rounded p-2">
                              <span className="text-muted-foreground">Largest Expense: </span>
                              <span className="font-medium">
                                {result.largestExpense.name} ({formatCurrency(result.largestExpense.amount)})
                              </span>
                            </div>
                            <div className="bg-white/80 rounded p-2">
                              <span className="text-muted-foreground">Average Expense: </span>
                              <span className="font-medium">{formatCurrency(result.averageExpense)}</span>
                            </div>
                            <div className="bg-white/80 rounded p-2">
                              <span className="text-muted-foreground">Top Category: </span>
                              <span className="font-medium">
                                {result.expensesByCategory[0]?.category} (
                                {result.expensesByCategory[0]?.percentage.toFixed(1)}%)
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-4">
              {/* Expense Categories Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Wallet className="h-5 w-5 text-green-600" />
                    Expense Categories
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-red-50 rounded">
                      <span>Housing</span>
                      <span className="text-muted-foreground">~30% of income</span>
                    </div>
                    <div className="flex justify-between p-2 bg-orange-50 rounded">
                      <span>Transportation</span>
                      <span className="text-muted-foreground">~15% of income</span>
                    </div>
                    <div className="flex justify-between p-2 bg-yellow-50 rounded">
                      <span>Food & Dining</span>
                      <span className="text-muted-foreground">~10-15% of income</span>
                    </div>
                    <div className="flex justify-between p-2 bg-green-50 rounded">
                      <span>Utilities</span>
                      <span className="text-muted-foreground">~5-10% of income</span>
                    </div>
                    <div className="flex justify-between p-2 bg-blue-50 rounded">
                      <span>Savings</span>
                      <span className="text-muted-foreground">~20% of income</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 50/30/20 Rule Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <PiggyBank className="h-5 w-5 text-green-600" />
                    50/30/20 Budget Rule
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-2 bg-blue-50 rounded">
                      <p className="font-semibold text-blue-700">50% - Needs</p>
                      <p className="text-muted-foreground">Housing, utilities, food, transportation, insurance</p>
                    </div>
                    <div className="p-2 bg-purple-50 rounded">
                      <p className="font-semibold text-purple-700">30% - Wants</p>
                      <p className="text-muted-foreground">Entertainment, dining out, hobbies, subscriptions</p>
                    </div>
                    <div className="p-2 bg-green-50 rounded">
                      <p className="font-semibold text-green-700">20% - Savings</p>
                      <p className="text-muted-foreground">Emergency fund, retirement, debt payments</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Tracking Tips Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-green-600" />
                    Tracking Tips
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-0.5">•</span>
                      Record expenses daily to avoid forgetting
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-0.5">•</span>
                      Use consistent categories for better analysis
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-0.5">•</span>
                      Set realistic budget limits for each category
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-0.5">•</span>
                      Review spending weekly to stay on track
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-0.5">•</span>
                      Identify and reduce unnecessary expenses
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            <Card className="shadow-md border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Info className="h-4 w-4 text-green-600" />
                  Why Track Expenses?
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>
                  Expense tracking is the foundation of financial health. By monitoring where your money goes, you can
                  identify spending patterns, find areas to cut back, and make informed decisions about your budget.
                  Studies show that people who track their expenses save 10-15% more than those who don&apos;t.
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-green-600" />
                  Payment Method Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>
                  Tracking by payment method reveals your spending habits. Credit card usage may indicate areas where
                  you&apos;re spending beyond your means, while cash transactions are often more mindful. Consider using
                  cash for discretionary spending to stay within budget.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <Card className="mt-4 shadow-md border-0 bg-amber-50">
            <CardContent className="pt-4">
              <p className="text-sm text-amber-800">
                <strong>Disclaimer:</strong> Monthly expense tracking is based on user inputs and provides estimates for
                budgeting purposes. This calculator is for informational purposes only. Consult a financial advisor for
                personalized guidance on managing your finances.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
