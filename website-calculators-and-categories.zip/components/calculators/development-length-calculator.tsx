"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Ruler, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type ConcreteGrade = "M10" | "M15" | "M20" | "M25" | "M30" | "M35" | "M40"
type SteelType = "TMT" | "Mild Steel"
type StressCondition = "Tension" | "Compression"

interface DevelopmentLengthResult {
  developmentLength: number
  adjustedLength: number
  unit: string
}

export function DevelopmentLengthCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [barDiameter, setBarDiameter] = useState("")
  const [concreteGrade, setConcreteGrade] = useState<ConcreteGrade>("M20")
  const [steelType, setSteelType] = useState<SteelType>("TMT")
  const [stressCondition, setStressCondition] = useState<StressCondition>("Tension")
  const [concreteCover, setConcreteCover] = useState("")
  const [safetyFactor, setSafetyFactor] = useState("1.0")
  const [result, setResult] = useState<DevelopmentLengthResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDevelopmentLength = () => {
    setError("")
    setResult(null)

    const diameter = Number.parseFloat(barDiameter)
    const cover = Number.parseFloat(concreteCover) || 0
    const safety = Number.parseFloat(safetyFactor)

    if (isNaN(diameter) || diameter <= 0) {
      setError("Please enter a valid bar diameter greater than 0")
      return
    }

    if (isNaN(safety) || safety <= 0) {
      setError("Please enter a valid safety factor greater than 0")
      return
    }

    // Convert to mm if imperial
    const diameterMm = unitSystem === "imperial" ? diameter * 25.4 : diameter

    // Bond stress factors (τbd) based on concrete grade (N/mm²)
    const bondStressFactors: Record<ConcreteGrade, number> = {
      M10: 1.2,
      M15: 1.4,
      M20: 1.6,
      M25: 1.8,
      M30: 2.0,
      M35: 2.2,
      M40: 2.4,
    }

    // Steel stress factors (σs) in N/mm²
    const steelStressFactor = steelType === "TMT" ? 415 : 250

    // Stress condition multiplier
    const stressMultiplier = stressCondition === "Tension" ? 1.0 : 0.8

    const bondStress = bondStressFactors[concreteGrade]

    // Basic development length formula: Ld = (σs × φ) / (4 × τbd)
    const basicLd = (steelStressFactor * diameterMm) / (4 * bondStress)

    // Apply stress condition multiplier
    const adjustedLd = basicLd * stressMultiplier

    // Apply safety factor
    const finalLd = adjustedLd * safety

    // Convert to meters or feet
    let developmentLengthDisplay: number
    let adjustedLengthDisplay: number
    let unit: string

    if (unitSystem === "metric") {
      developmentLengthDisplay = basicLd / 1000 // Convert mm to m
      adjustedLengthDisplay = finalLd / 1000
      unit = "m"
    } else {
      developmentLengthDisplay = (basicLd / 1000) * 3.28084 // Convert mm to feet
      adjustedLengthDisplay = (finalLd / 1000) * 3.28084
      unit = "ft"
    }

    setResult({
      developmentLength: Math.round(developmentLengthDisplay * 100) / 100,
      adjustedLength: Math.round(adjustedLengthDisplay * 100) / 100,
      unit,
    })
  }

  const handleReset = () => {
    setBarDiameter("")
    setConcreteGrade("M20")
    setSteelType("TMT")
    setStressCondition("Tension")
    setConcreteCover("")
    setSafetyFactor("1.0")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Development Length: ${result.adjustedLength} ${result.unit} (Grade: ${concreteGrade}, Steel: ${steelType}, Stress: ${stressCondition})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Development Length Calculation",
          text: `Development Length: ${result.adjustedLength} ${result.unit} for ${barDiameter}${unitSystem === "metric" ? "mm" : "in"} bar`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setBarDiameter("")
    setConcreteCover("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Ruler className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Development Length Calculator</CardTitle>
                    <CardDescription>Calculate required bar development length</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Bar Diameter */}
                <div className="space-y-2">
                  <Label htmlFor="barDiameter">Bar Diameter ({unitSystem === "metric" ? "mm" : "in"})</Label>
                  <Input
                    id="barDiameter"
                    type="number"
                    placeholder={`Enter bar diameter in ${unitSystem === "metric" ? "millimeters" : "inches"}`}
                    value={barDiameter}
                    onChange={(e) => setBarDiameter(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Concrete Grade */}
                <div className="space-y-2">
                  <Label htmlFor="concreteGrade">Concrete Grade</Label>
                  <Select value={concreteGrade} onValueChange={(value) => setConcreteGrade(value as ConcreteGrade)}>
                    <SelectTrigger id="concreteGrade">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M10">M10</SelectItem>
                      <SelectItem value="M15">M15</SelectItem>
                      <SelectItem value="M20">M20</SelectItem>
                      <SelectItem value="M25">M25</SelectItem>
                      <SelectItem value="M30">M30</SelectItem>
                      <SelectItem value="M35">M35</SelectItem>
                      <SelectItem value="M40">M40</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Steel Type */}
                <div className="space-y-2">
                  <Label htmlFor="steelType">Steel Type</Label>
                  <Select value={steelType} onValueChange={(value) => setSteelType(value as SteelType)}>
                    <SelectTrigger id="steelType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TMT">TMT (Fe 415)</SelectItem>
                      <SelectItem value="Mild Steel">Mild Steel (Fe 250)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Stress Condition */}
                <div className="space-y-2">
                  <Label htmlFor="stressCondition">Stress Condition</Label>
                  <Select
                    value={stressCondition}
                    onValueChange={(value) => setStressCondition(value as StressCondition)}
                  >
                    <SelectTrigger id="stressCondition">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Tension">Tension</SelectItem>
                      <SelectItem value="Compression">Compression</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Concrete Cover */}
                <div className="space-y-2">
                  <Label htmlFor="concreteCover">
                    Concrete Cover ({unitSystem === "metric" ? "mm" : "in"}) - Optional
                  </Label>
                  <Input
                    id="concreteCover"
                    type="number"
                    placeholder="Enter concrete cover (optional)"
                    value={concreteCover}
                    onChange={(e) => setConcreteCover(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Safety Factor */}
                <div className="space-y-2">
                  <Label htmlFor="safetyFactor">Safety Factor</Label>
                  <Input
                    id="safetyFactor"
                    type="number"
                    placeholder="Enter safety factor (default: 1.0)"
                    value={safetyFactor}
                    onChange={(e) => setSafetyFactor(e.target.value)}
                    min="0.1"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDevelopmentLength} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Development Length
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Development Length Required</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {result.adjustedLength} {result.unit}
                        </p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Basic Development Length:</span>
                          <span className="font-semibold">
                            {result.developmentLength} {result.unit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Final Length (with factors):</span>
                          <span className="font-semibold">
                            {result.adjustedLength} {result.unit}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bond Stress by Grade</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="font-medium">M10-M15</span>
                      <span className="text-muted-foreground">1.2-1.4 N/mm²</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="font-medium">M20-M25</span>
                      <span className="text-muted-foreground">1.6-1.8 N/mm²</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="font-medium">M30-M40</span>
                      <span className="text-muted-foreground">2.0-2.4 N/mm²</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Development Length Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Ld = (σs × φ) / (4 × τbd)</p>
                  </div>
                  <div className="space-y-1">
                    <p>
                      <strong>σs:</strong> Steel stress (415 N/mm² for TMT, 250 N/mm² for mild steel)
                    </p>
                    <p>
                      <strong>φ:</strong> Bar diameter
                    </p>
                    <p>
                      <strong>τbd:</strong> Bond stress (varies with concrete grade)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Development Length */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Development Length?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Development length is the minimum length of reinforcement bar required to be embedded in concrete to
                  develop the full design stress in the bar at a critical section. This ensures proper bond between
                  steel and concrete, preventing bar pullout under stress. Development length is a crucial design
                  parameter in reinforced concrete construction as it directly affects the structural integrity and
                  safety of the member.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of development length accounts for the transfer of forces from the reinforcement to the
                  surrounding concrete through bond stresses. Higher grade concrete provides better bond strength,
                  reducing the required development length. Similarly, deformed bars (TMT) develop better mechanical
                  interlock than plain bars, also reducing development length requirements.
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting Development Length */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Development Length</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence the required development length of reinforcement bars. The bar diameter is
                  directly proportional - larger diameter bars require longer development lengths. The concrete grade
                  affects bond stress capacity; higher grade concrete allows for shorter development lengths due to
                  better bond characteristics.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Steel type and grade significantly impact development length. TMT bars (Fe 415) require longer
                  development lengths than mild steel (Fe 250) due to higher stress levels. The stress condition also
                  matters - bars in compression can be embedded with 25% less length than those in tension. Concrete
                  cover, bar spacing, and the presence of transverse reinforcement can further modify development length
                  requirements according to code provisions.
                </p>
              </CardContent>
            </Card>

            {/* Common Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Placement Notes and Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Development length must be provided beyond critical sections where maximum stress occurs, such as at
                  supports in beams or at points of maximum moment. In practice, bars should extend beyond these
                  critical sections by at least the calculated development length to ensure adequate anchorage. Hooks
                  and bends can reduce development length requirements by providing mechanical anchorage.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Common applications include beam-column connections, slab reinforcement anchorage, footing
                  reinforcement, and column lap splices. Special attention is required in short spans where available
                  anchorage length may be limited. In such cases, hooks, mechanical anchorages, or increased
                  reinforcement may be necessary. Always ensure development length calculations comply with IS 456 or
                  relevant local building codes for your region.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p className="font-semibold text-amber-900">Important Disclaimer</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Development length calculations provided here are indicative and based on standard code formulas.
                      Actual structural design must be performed by qualified structural engineers and must comply with
                      IS 456, ACI 318, or other applicable building codes. Site-specific conditions, exposure
                      categories, and special load cases may require modifications to standard development length
                      requirements.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
