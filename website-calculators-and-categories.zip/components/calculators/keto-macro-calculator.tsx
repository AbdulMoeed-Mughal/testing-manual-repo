"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Beef, Info, AlertTriangle, Activity, Flame } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityLevel = "sedentary" | "light" | "moderate" | "very" | "athlete"
type Goal = "maintenance" | "fat-loss" | "muscle-gain"

interface KetoResult {
  calories: number
  fat: number
  fatCalories: number
  fatPercent: number
  protein: number
  proteinCalories: number
  proteinPercent: number
  carbs: number
  carbCalories: number
  carbPercent: number
  perMeal: {
    fat: number
    protein: number
    carbs: number
    calories: number
  }
}

const activityMultipliers: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  very: 1.725,
  athlete: 1.9,
}

const activityLabels: Record<ActivityLevel, string> = {
  sedentary: "Sedentary",
  light: "Lightly Active",
  moderate: "Moderately Active",
  very: "Very Active",
  athlete: "Athlete",
}

const goalLabels: Record<Goal, string> = {
  maintenance: "Maintenance",
  "fat-loss": "Fat Loss",
  "muscle-gain": "Muscle Gain",
}

export function KetoMacroCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")
  const [goal, setGoal] = useState<Goal>("fat-loss")
  const [mealsPerDay, setMealsPerDay] = useState("3")
  const [customCalories, setCustomCalories] = useState("")
  const [result, setResult] = useState<KetoResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateKetoMacros = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const weightNum = Number.parseFloat(weight)
    const meals = Number.parseInt(mealsPerDay) || 3

    if (isNaN(ageNum) || ageNum < 10) {
      setError("Please enter a valid age (10 or older)")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number
    if (unitSystem === "metric") {
      heightInCm = Number.parseFloat(heightCm)
      if (isNaN(heightInCm) || heightInCm <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = feet * 30.48 + inches * 2.54
    }

    // Convert to metric for calculations
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Calculate BMR using Mifflin-St Jeor
    let bmr: number
    if (gender === "male") {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
    } else {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
    }

    // Calculate TDEE
    let tdee = bmr * activityMultipliers[activityLevel]

    // Adjust for goal
    if (goal === "fat-loss") {
      tdee = tdee * 0.8 // 20% deficit
    } else if (goal === "muscle-gain") {
      tdee = tdee * 1.1 // 10% surplus
    }

    // Use custom calories if provided
    const totalCalories = customCalories ? Number.parseFloat(customCalories) : Math.round(tdee)

    if (customCalories && (isNaN(totalCalories) || totalCalories <= 0)) {
      setError("Please enter valid calories")
      return
    }

    // Keto macro ratios
    const fatPercent = 75
    const proteinPercent = 20
    const carbPercent = 5

    // Calculate macros
    const fatCalories = totalCalories * (fatPercent / 100)
    const proteinCalories = totalCalories * (proteinPercent / 100)
    const carbCalories = totalCalories * (carbPercent / 100)

    const fatGrams = Math.round(fatCalories / 9)
    const proteinGrams = Math.round(proteinCalories / 4)
    const carbGrams = Math.round(carbCalories / 4)

    // Per meal breakdown
    const perMeal = {
      fat: Math.round(fatGrams / meals),
      protein: Math.round(proteinGrams / meals),
      carbs: Math.round(carbGrams / meals),
      calories: Math.round(totalCalories / meals),
    }

    setResult({
      calories: totalCalories,
      fat: fatGrams,
      fatCalories: Math.round(fatCalories),
      fatPercent,
      protein: proteinGrams,
      proteinCalories: Math.round(proteinCalories),
      proteinPercent,
      carbs: carbGrams,
      carbCalories: Math.round(carbCalories),
      carbPercent,
      perMeal,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setActivityLevel("moderate")
    setGoal("fat-loss")
    setMealsPerDay("3")
    setCustomCalories("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `My Keto Macros: ${result.calories} kcal/day | Fat: ${result.fat}g (${result.fatPercent}%) | Protein: ${result.protein}g (${result.proteinPercent}%) | Carbs: ${result.carbs}g (${result.carbPercent}%)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Keto Macros",
          text: `I calculated my keto macros using CalcHub! ${result.calories} kcal/day | Fat: ${result.fat}g | Protein: ${result.protein}g | Carbs: ${result.carbs}g`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Beef className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Keto Macro Calculator</CardTitle>
                    <CardDescription>Calculate your ketogenic diet macros</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="Feet"
                        value={heightFeet}
                        onChange={(e) => setHeightFeet(e.target.value)}
                        min="0"
                      />
                      <Input
                        type="number"
                        placeholder="Inches"
                        value={heightInches}
                        onChange={(e) => setHeightInches(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                )}

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {(Object.keys(activityLabels) as ActivityLevel[]).map((level) => (
                      <Button
                        key={level}
                        type="button"
                        variant={activityLevel === level ? "default" : "outline"}
                        onClick={() => setActivityLevel(level)}
                        className="text-xs sm:text-sm"
                        size="sm"
                      >
                        {activityLabels[level]}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Goal Selection */}
                <div className="space-y-2">
                  <Label>Fitness Goal</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {(Object.keys(goalLabels) as Goal[]).map((g) => (
                      <Button
                        key={g}
                        type="button"
                        variant={goal === g ? "default" : "outline"}
                        onClick={() => setGoal(g)}
                        className={`text-xs sm:text-sm ${
                          goal === g
                            ? g === "fat-loss"
                              ? "bg-orange-600 hover:bg-orange-700"
                              : g === "muscle-gain"
                                ? "bg-blue-600 hover:bg-blue-700"
                                : ""
                            : ""
                        }`}
                        size="sm"
                      >
                        {goalLabels[g]}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Meals Per Day */}
                <div className="space-y-2">
                  <Label htmlFor="meals">Meals Per Day</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {["2", "3", "4", "5"].map((num) => (
                      <Button
                        key={num}
                        type="button"
                        variant={mealsPerDay === num ? "default" : "outline"}
                        onClick={() => setMealsPerDay(num)}
                        size="sm"
                      >
                        {num}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Custom Calories (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="customCalories">Custom Calories (optional)</Label>
                  <Input
                    id="customCalories"
                    type="number"
                    placeholder="Leave empty to auto-calculate"
                    value={customCalories}
                    onChange={(e) => setCustomCalories(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateKetoMacros} className="w-full" size="lg">
                  Calculate Keto Macros
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Daily Calories</p>
                      <p className="text-4xl font-bold text-green-600">{result.calories}</p>
                      <p className="text-sm text-green-600 font-medium">kcal/day</p>
                    </div>

                    {/* Macro Bars */}
                    <div className="space-y-3 mb-4">
                      {/* Fat */}
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium text-yellow-700">Fat</span>
                          <span className="text-yellow-600">
                            {result.fat}g ({result.fatPercent}%)
                          </span>
                        </div>
                        <div className="h-3 bg-yellow-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-yellow-500 rounded-full transition-all duration-500"
                            style={{ width: `${result.fatPercent}%` }}
                          />
                        </div>
                      </div>

                      {/* Protein */}
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium text-blue-700">Protein</span>
                          <span className="text-blue-600">
                            {result.protein}g ({result.proteinPercent}%)
                          </span>
                        </div>
                        <div className="h-3 bg-blue-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500 rounded-full transition-all duration-500"
                            style={{ width: `${result.proteinPercent}%` }}
                          />
                        </div>
                      </div>

                      {/* Carbs */}
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium text-green-700">Net Carbs</span>
                          <span className="text-green-600">
                            {result.carbs}g ({result.carbPercent}%)
                          </span>
                        </div>
                        <div className="h-3 bg-green-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-green-500 rounded-full transition-all duration-500"
                            style={{ width: `${result.carbPercent}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Per Meal Breakdown */}
                    <div className="p-3 bg-white/60 rounded-lg mb-4">
                      <p className="text-sm font-medium text-center mb-2">Per Meal ({mealsPerDay} meals)</p>
                      <div className="grid grid-cols-4 gap-2 text-center text-xs">
                        <div>
                          <p className="font-bold text-foreground">{result.perMeal.calories}</p>
                          <p className="text-muted-foreground">kcal</p>
                        </div>
                        <div>
                          <p className="font-bold text-yellow-600">{result.perMeal.fat}g</p>
                          <p className="text-muted-foreground">Fat</p>
                        </div>
                        <div>
                          <p className="font-bold text-blue-600">{result.perMeal.protein}g</p>
                          <p className="text-muted-foreground">Protein</p>
                        </div>
                        <div>
                          <p className="font-bold text-green-600">{result.perMeal.carbs}g</p>
                          <p className="text-muted-foreground">Carbs</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Keto Macro Ratios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Fat</span>
                      <span className="text-sm text-yellow-600">70-75%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Protein</span>
                      <span className="text-sm text-blue-600">20-25%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Net Carbs</span>
                      <span className="text-sm text-green-600">5-10%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Keto-Friendly Foods</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">High Fat Sources:</p>
                    <p>Avocados, olive oil, coconut oil, butter, cheese, nuts, fatty fish</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">Protein Sources:</p>
                    <p>Beef, chicken, pork, eggs, fish, seafood, tofu</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">Low-Carb Vegetables:</p>
                    <p>Leafy greens, broccoli, cauliflower, zucchini, asparagus</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates for ketogenic diets. Consult a healthcare or nutrition
                        professional for personalized guidance.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Ketogenic Diet?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The ketogenic diet, commonly known as keto, is a high-fat, moderate-protein, and very low-carbohydrate
                  eating plan that has gained significant popularity for weight loss and health improvement. The diet
                  was originally developed in the 1920s as a treatment for epilepsy but has since evolved into one of
                  the most researched dietary approaches for metabolic health. By drastically reducing carbohydrate
                  intake and replacing it with fat, the body enters a metabolic state called ketosis, where it becomes
                  remarkably efficient at burning fat for energy instead of relying on glucose from carbohydrates.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When you follow a ketogenic diet, your liver converts fatty acids into molecules called ketones, which
                  serve as an alternative fuel source for your brain and body. This metabolic shift can lead to numerous
                  health benefits beyond weight loss, including improved insulin sensitivity, reduced inflammation,
                  enhanced mental clarity, and more stable energy levels throughout the day. Many people report
                  decreased hunger and cravings once they become fat-adapted, making it easier to maintain a caloric
                  deficit if weight loss is the goal.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Keto Macronutrients</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The macronutrient ratios in a ketogenic diet are fundamentally different from traditional dietary
                  guidelines. While conventional nutrition advice recommends that carbohydrates make up 45-65% of daily
                  calories, keto restricts carbs to just 5-10% of total intake. This dramatic reduction forces your body
                  to find alternative fuel sources, primarily dietary and stored body fat. The typical keto macro
                  breakdown consists of approximately 70-75% fat, 20-25% protein, and 5-10% carbohydrates.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Fat becomes your primary energy source on keto, providing the majority of your daily calories. It's
                  important to focus on healthy fat sources such as avocados, olive oil, coconut oil, nuts, seeds, and
                  fatty fish. Protein intake should be moderate — enough to maintain muscle mass but not so high that it
                  interferes with ketosis through a process called gluconeogenesis, where excess protein can be
                  converted to glucose. Carbohydrates should come primarily from non-starchy vegetables and small
                  amounts of low-sugar fruits like berries.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Getting Into and Maintaining Ketosis</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Entering ketosis typically takes 2-7 days of consistently limiting carbohydrate intake to under 50
                  grams per day, with some individuals needing to go as low as 20-30 grams to achieve and maintain this
                  metabolic state. During this transition period, many people experience what's commonly called the
                  "keto flu" — a collection of symptoms including fatigue, headaches, brain fog, and irritability caused
                  by the body adapting to using ketones instead of glucose. These symptoms are temporary and can be
                  minimized by staying well-hydrated and ensuring adequate electrolyte intake.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Once you're in ketosis, maintaining this state requires consistent attention to your carbohydrate
                  intake. Hidden carbs in sauces, dressings, and processed foods can quickly add up and potentially kick
                  you out of ketosis. Many keto followers use blood ketone meters, breath analyzers, or urine strips to
                  monitor their ketone levels and ensure they're staying in the optimal range. Signs that you're in
                  ketosis include decreased appetite, increased energy, better mental focus, and sometimes a fruity or
                  metallic taste in your mouth from acetone, a type of ketone expelled through breath.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beef className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Keto Success</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Success on the ketogenic diet requires planning and preparation. Start by clearing your kitchen of
                  high-carb temptations and stocking up on keto-friendly foods. Meal prepping can help ensure you always
                  have compliant options available, reducing the temptation to reach for convenient but carb-heavy
                  alternatives. Reading nutrition labels becomes essential — look for hidden sugars in products like
                  condiments, dairy products, and even some meats that may contain added fillers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Electrolyte balance is crucial on keto. When you reduce carbohydrates, your body excretes more water
                  and electrolytes, which can lead to symptoms like muscle cramps, fatigue, and headaches. Consider
                  supplementing with sodium, potassium, and magnesium, or include electrolyte-rich foods in your diet.
                  Bone broth, leafy greens, avocados, and nuts are excellent sources. Additionally, don't fear fat —
                  many people new to keto undereat fat and feel hungry and low-energy as a result. Embrace healthy fats
                  as your primary fuel source to feel satisfied and maintain energy throughout the day.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
