"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, Thermometer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type ProcessType = "constant" | "variable"
type HeatUnit = "J" | "cal" | "BTU"
type EntropyUnit = "J/K" | "cal/K"

interface EntropyResult {
  entropyChange: number
  category: string
  color: string
  bgColor: string
  direction: string
}

export function EntropyCalculator() {
  const [processType, setProcessType] = useState<ProcessType>("constant")
  const [heat, setHeat] = useState("")
  const [temperature, setTemperature] = useState("")
  const [initialTemp, setInitialTemp] = useState("")
  const [finalTemp, setFinalTemp] = useState("")
  const [heatUnit, setHeatUnit] = useState<HeatUnit>("J")
  const [entropyUnit, setEntropyUnit] = useState<EntropyUnit>("J/K")
  const [result, setResult] = useState<EntropyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const convertHeatToJoules = (value: number, unit: HeatUnit): number => {
    switch (unit) {
      case "cal":
        return value * 4.184
      case "BTU":
        return value * 1055.06
      default:
        return value
    }
  }

  const convertEntropyFromSI = (value: number, unit: EntropyUnit): number => {
    if (unit === "cal/K") return value / 4.184
    return value
  }

  const calculateEntropy = () => {
    setError("")
    setResult(null)

    const heatNum = Number.parseFloat(heat)
    if (isNaN(heatNum)) {
      setError("Please enter a valid heat value")
      return
    }

    let entropyChange: number

    if (processType === "constant") {
      const tempNum = Number.parseFloat(temperature)
      if (isNaN(tempNum) || tempNum <= 0) {
        setError("Temperature must be positive (in Kelvin)")
        return
      }

      const heatInJoules = convertHeatToJoules(heatNum, heatUnit)
      entropyChange = heatInJoules / tempNum
    } else {
      const t1 = Number.parseFloat(initialTemp)
      const t2 = Number.parseFloat(finalTemp)
      if (isNaN(t1) || isNaN(t2) || t1 <= 0 || t2 <= 0) {
        setError("Both temperatures must be positive (in Kelvin)")
        return
      }

      const heatInJoules = convertHeatToJoules(heatNum, heatUnit)
      // For variable temperature: ΔS = Q * ln(T2/T1) / (T2 - T1) approximation
      // Or more accurately for constant heat capacity: ΔS = n*C*ln(T2/T1)
      // Using simplified average: ΔS ≈ Q / T_avg where T_avg = (T1 + T2) / 2
      const avgTemp = (t1 + t2) / 2
      entropyChange = heatInJoules / avgTemp
    }

    const displayEntropy = convertEntropyFromSI(entropyChange, entropyUnit)
    const absEntropy = Math.abs(displayEntropy)

    let category: string
    let color: string
    let bgColor: string

    if (absEntropy < 1) {
      category = "Very Small Change"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (absEntropy < 10) {
      category = "Small Change"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (absEntropy < 100) {
      category = "Moderate Change"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Large Change"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    const direction =
      displayEntropy >= 0 ? "Entropy Increase (Disorder increases)" : "Entropy Decrease (Disorder decreases)"

    setResult({
      entropyChange: Math.round(displayEntropy * 1000) / 1000,
      category,
      color,
      bgColor,
      direction,
    })
  }

  const handleReset = () => {
    setHeat("")
    setTemperature("")
    setInitialTemp("")
    setFinalTemp("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Entropy Change: ${result.entropyChange} ${entropyUnit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Thermometer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Entropy Calculator</CardTitle>
                    <CardDescription>Calculate entropy change of a system</CardDescription>
                  </div>
                </div>

                {/* Process Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Process Type</span>
                  <button
                    onClick={() => setProcessType(processType === "constant" ? "variable" : "constant")}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        processType === "variable" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        processType === "constant" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Constant T
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        processType === "variable" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Variable T
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Heat Input */}
                <div className="space-y-2">
                  <Label htmlFor="heat">Heat Transferred (Q)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="heat"
                      type="number"
                      placeholder="Enter heat value"
                      value={heat}
                      onChange={(e) => setHeat(e.target.value)}
                      className="flex-1"
                    />
                    <select
                      value={heatUnit}
                      onChange={(e) => setHeatUnit(e.target.value as HeatUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="J">J</option>
                      <option value="cal">cal</option>
                      <option value="BTU">BTU</option>
                    </select>
                  </div>
                  <p className="text-xs text-muted-foreground">Positive for heat added, negative for heat removed</p>
                </div>

                {/* Temperature Input(s) */}
                {processType === "constant" ? (
                  <div className="space-y-2">
                    <Label htmlFor="temperature">Temperature (K)</Label>
                    <Input
                      id="temperature"
                      type="number"
                      placeholder="Enter temperature in Kelvin"
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="initialTemp">Initial Temperature (K)</Label>
                      <Input
                        id="initialTemp"
                        type="number"
                        placeholder="Enter initial temperature"
                        value={initialTemp}
                        onChange={(e) => setInitialTemp(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="finalTemp">Final Temperature (K)</Label>
                      <Input
                        id="finalTemp"
                        type="number"
                        placeholder="Enter final temperature"
                        value={finalTemp}
                        onChange={(e) => setFinalTemp(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label>Entropy Unit</Label>
                  <select
                    value={entropyUnit}
                    onChange={(e) => setEntropyUnit(e.target.value as EntropyUnit)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="J/K">J/K</option>
                    <option value="cal/K">cal/K</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateEntropy} className="w-full" size="lg">
                  Calculate Entropy Change
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Entropy Change (ΔS)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.entropyChange > 0 ? "+" : ""}
                        {result.entropyChange}
                      </p>
                      <p className="text-lg text-muted-foreground mb-2">{entropyUnit}</p>
                      <p className={`text-sm font-medium ${result.color}`}>{result.direction}</p>
                      <p className="text-xs text-muted-foreground mt-1">{result.category}</p>
                    </div>

                    {/* Step-by-step breakdown toggle */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Formula:</strong> ΔS = Q / T
                        </p>
                        <p>
                          <strong>Heat (Q):</strong> {heat} {heatUnit}
                        </p>
                        {processType === "constant" ? (
                          <p>
                            <strong>Temperature (T):</strong> {temperature} K
                          </p>
                        ) : (
                          <>
                            <p>
                              <strong>Initial Temp (T₁):</strong> {initialTemp} K
                            </p>
                            <p>
                              <strong>Final Temp (T₂):</strong> {finalTemp} K
                            </p>
                            <p>
                              <strong>Average Temp:</strong>{" "}
                              {((Number(initialTemp) + Number(finalTemp)) / 2).toFixed(2)} K
                            </p>
                          </>
                        )}
                        <p>
                          <strong>Result:</strong> ΔS = {result.entropyChange} {entropyUnit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Entropy Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ΔS = Q / T</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>ΔS</strong> = Entropy change (J/K)
                    </p>
                    <p>
                      <strong>Q</strong> = Heat transferred (J)
                    </p>
                    <p>
                      <strong>T</strong> = Absolute temperature (K)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Entropy Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Ice melting at 273 K</span>
                      <span className="font-mono">+22.0 J/mol·K</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Water vaporizing at 373 K</span>
                      <span className="font-mono">+109 J/mol·K</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Ideal gas expansion</span>
                      <span className="font-mono">+nR·ln(V₂/V₁)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Entropy?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Entropy is a fundamental thermodynamic property that measures the degree of disorder or randomness in
                  a system. Introduced by Rudolf Clausius in 1865, entropy quantifies the amount of thermal energy in a
                  system that is unavailable for doing useful work. The Second Law of Thermodynamics states that the
                  total entropy of an isolated system can only increase over time, which explains why many natural
                  processes are irreversible.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In practical terms, entropy helps engineers understand energy efficiency, predict the direction of
                  spontaneous processes, and design more efficient thermal systems. Higher entropy means more disorder
                  and less available energy for work, while lower entropy indicates a more ordered state with greater
                  potential for useful work.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Entropy calculations assume ideal or reversible processes. Real systems
                  may have additional irreversibilities. Consult thermodynamics references for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
