"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, MoveVertical, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type StaircaseType = "straight" | "dog-legged" | "open-well"
type UnitSystem = "metric" | "imperial"

interface StaircaseResult {
  risers: number
  treads: number
  riserHeight: number
  treadDepth: number
  stairAngle: number
  concreteVolume: number
  slope: number
  slopeCheck: string
  color: string
  bgColor: string
}

export function StaircaseCalculator() {
  const [staircaseType, setStaircaseType] = useState<StaircaseType>("straight")
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [floorHeight, setFloorHeight] = useState("")
  const [riserHeight, setRiserHeight] = useState("")
  const [treadDepth, setTreadDepth] = useState("")
  const [stairWidth, setStairWidth] = useState("")
  const [slabThickness, setSlabThickness] = useState("0.15")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [result, setResult] = useState<StaircaseResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateStaircase = () => {
    setError("")
    setResult(null)

    const floorHeightNum = Number.parseFloat(floorHeight)
    const stairWidthNum = Number.parseFloat(stairWidth)
    const slabThicknessNum = Number.parseFloat(slabThickness)
    const dryVolumeFactorNum = Number.parseFloat(dryVolumeFactor) || 1.54

    if (isNaN(floorHeightNum) || floorHeightNum <= 0) {
      setError("Please enter a valid floor height greater than 0")
      return
    }

    if (isNaN(stairWidthNum) || stairWidthNum <= 0) {
      setError("Please enter a valid stair width greater than 0")
      return
    }

    if (isNaN(slabThicknessNum) || slabThicknessNum <= 0) {
      setError("Please enter a valid slab thickness greater than 0")
      return
    }

    // Convert to meters if imperial
    const floorHeightInMeters = unitSystem === "imperial" ? floorHeightNum * 0.3048 : floorHeightNum
    const stairWidthInMeters = unitSystem === "imperial" ? stairWidthNum * 0.3048 : stairWidthNum
    const slabThicknessInMeters = unitSystem === "imperial" ? slabThicknessNum * 0.3048 : slabThicknessNum

    // Calculate riser height
    let calculatedRiserHeight: number
    if (riserHeight) {
      const riserHeightNum = Number.parseFloat(riserHeight)
      if (isNaN(riserHeightNum) || riserHeightNum <= 0) {
        setError("Please enter a valid riser height greater than 0")
        return
      }
      calculatedRiserHeight = unitSystem === "imperial" ? riserHeightNum * 0.3048 : riserHeightNum
    } else {
      // Default riser height: 0.15-0.18m (residential standard)
      calculatedRiserHeight = 0.17
    }

    // Calculate number of risers
    const numRisers = Math.ceil(floorHeightInMeters / calculatedRiserHeight)
    
    // Recalculate exact riser height
    calculatedRiserHeight = floorHeightInMeters / numRisers

    // Calculate number of treads
    const numTreads = numRisers - 1

    // Calculate tread depth
    let calculatedTreadDepth: number
    if (treadDepth) {
      const treadDepthNum = Number.parseFloat(treadDepth)
      if (isNaN(treadDepthNum) || treadDepthNum <= 0) {
        setError("Please enter a valid tread depth greater than 0")
        return
      }
      calculatedTreadDepth = unitSystem === "imperial" ? treadDepthNum * 0.3048 : treadDepthNum
    } else {
      // Default tread depth: 0.25-0.30m (residential standard)
      calculatedTreadDepth = 0.27
    }

    // Check slope (2R + T should be 600-650mm or 24-26 inches)
    const slope = 2 * calculatedRiserHeight + calculatedTreadDepth
    const slopeInMm = slope * 1000
    let slopeCheck: string
    let color: string
    let bgColor: string

    if (slopeInMm >= 600 && slopeInMm <= 650) {
      slopeCheck = "Optimal"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (slopeInMm >= 580 && slopeInMm <= 670) {
      slopeCheck = "Acceptable"
      color = "text-amber-600"
      bgColor = "bg-amber-50 border-amber-200"
    } else {
      slopeCheck = "Non-Standard"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    // Calculate stair angle
    const stairAngle = Math.atan(calculatedRiserHeight / calculatedTreadDepth) * (180 / Math.PI)

    // Calculate stair length
    const stairLength = numTreads * calculatedTreadDepth

    // Calculate concrete volume
    // For straight flight: Volume = Width × Length × Thickness
    // For dog-legged and open-well: multiply by 2 (two flights)
    let wetVolume = stairWidthInMeters * stairLength * slabThicknessInMeters

    if (staircaseType === "dog-legged" || staircaseType === "open-well") {
      wetVolume = wetVolume * 2
    }

    const dryVolume = wetVolume * dryVolumeFactorNum

    // Convert back to display units if imperial
    const displayRiserHeight = unitSystem === "imperial" ? calculatedRiserHeight / 0.3048 : calculatedRiserHeight
    const displayTreadDepth = unitSystem === "imperial" ? calculatedTreadDepth / 0.3048 : calculatedTreadDepth
    const displayVolume = unitSystem === "imperial" ? dryVolume / 0.0283168 : dryVolume

    setResult({
      risers: numRisers,
      treads: numTreads,
      riserHeight: Math.round(displayRiserHeight * 1000) / 1000,
      treadDepth: Math.round(displayTreadDepth * 1000) / 1000,
      stairAngle: Math.round(stairAngle * 10) / 10,
      concreteVolume: Math.round(displayVolume * 1000) / 1000,
      slope: Math.round(slopeInMm),
      slopeCheck,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setFloorHeight("")
    setRiserHeight("")
    setTreadDepth("")
    setStairWidth("")
    setSlabThickness("0.15")
    setDryVolumeFactor("1.54")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "m" : "ft"
      const volumeUnit = unitSystem === "metric" ? "m³" : "ft³"
      await navigator.clipboard.writeText(
        `Staircase Design:\nRisers: ${result.risers}\nTreads: ${result.treads}\nRiser Height: ${result.riserHeight} ${unit}\nTread Depth: ${result.treadDepth} ${unit}\nStair Angle: ${result.stairAngle}°\nConcrete Volume: ${result.concreteVolume} ${volumeUnit}\nSlope Check: ${result.slopeCheck}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Staircase Calculation",
          text: `I calculated my staircase design using CalcHub! Risers: ${result.risers}, Treads: ${result.treads}, Angle: ${result.stairAngle}°`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setFloorHeight("")
    setRiserHeight("")
    setTreadDepth("")
    setStairWidth("")
    setSlabThickness(prev => prev === "0.15" ? "0.49" : "0.15")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <MoveVertical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Staircase Calculator</CardTitle>
                    <CardDescription>Calculate staircase dimensions and concrete volume</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Staircase Type */}
                <div className="space-y-2">
                  <Label>Staircase Type</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setStaircaseType("straight")}
                      className={`p-2 rounded-lg border-2 text-xs font-medium transition-colors ${
                        staircaseType === "straight"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-gray-200 hover:border-amber-200"
                      }`}
                    >
                      Straight
                    </button>
                    <button
                      onClick={() => setStaircaseType("dog-legged")}
                      className={`p-2 rounded-lg border-2 text-xs font-medium transition-colors ${
                        staircaseType === "dog-legged"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-gray-200 hover:border-amber-200"
                      }`}
                    >
                      Dog-Legged
                    </button>
                    <button
                      onClick={() => setStaircaseType("open-well")}
                      className={`p-2 rounded-lg border-2 text-xs font-medium transition-colors ${
                        staircaseType === "open-well"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-gray-200 hover:border-amber-200"
                      }`}
                    >
                      Open Well
                    </button>
                  </div>
                </div>

                {/* Floor Height */}
                <div className="space-y-2">
                  <Label htmlFor="floor-height">Floor-to-Floor Height ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="floor-height"
                    type="number"
                    placeholder={`Enter floor height in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={floorHeight}
                    onChange={(e) => setFloorHeight(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Riser Height (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="riser-height">
                    Desired Riser Height ({unitSystem === "metric" ? "m" : "ft"}) - Optional
                  </Label>
                  <Input
                    id="riser-height"
                    type="number"
                    placeholder={`Default: ${unitSystem === "metric" ? "0.17m" : "0.56ft"}`}
                    value={riserHeight}
                    onChange={(e) => setRiserHeight(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                </div>

                {/* Tread Depth (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="tread-depth">
                    Tread Depth ({unitSystem === "metric" ? "m" : "ft"}) - Optional
                  </Label>
                  <Input
                    id="tread-depth"
                    type="number"
                    placeholder={`Default: ${unitSystem === "metric" ? "0.27m" : "0.89ft"}`}
                    value={treadDepth}
                    onChange={(e) => setTreadDepth(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                </div>

                {/* Stair Width */}
                <div className="space-y-2">
                  <Label htmlFor="stair-width">Stair Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="stair-width"
                    type="number"
                    placeholder={`Enter stair width in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={stairWidth}
                    onChange={(e) => setStairWidth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Slab Thickness */}
                <div className="space-y-2">
                  <Label htmlFor="slab-thickness">Slab Thickness ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="slab-thickness"
                    type="number"
                    placeholder="Enter slab thickness"
                    value={slabThickness}
                    onChange={(e) => setSlabThickness(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Dry Volume Factor */}
                <div className="space-y-2">
                  <Label htmlFor="dry-volume">Dry Volume Factor</Label>
                  <Input
                    id="dry-volume"
                    type="number"
                    placeholder="Default: 1.54"
                    value={dryVolumeFactor}
                    onChange={(e) => setDryVolumeFactor(e.target.value)}
                    min="1"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateStaircase} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Number of Risers</p>
                          <p className={`text-2xl font-bold ${result.color}`}>{result.risers}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Number of Treads</p>
                          <p className={`text-2xl font-bold ${result.color}`}>{result.treads}</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Riser Height</p>
                          <p className={`text-lg font-bold ${result.color}`}>
                            {result.riserHeight} {unitSystem === "metric" ? "m" : "ft"}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Tread Depth</p>
                          <p className={`text-lg font-bold ${result.color}`}>
                            {result.treadDepth} {unitSystem === "metric" ? "m" : "ft"}
                          </p>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Stair Angle</p>
                        <p className={`text-2xl font-bold ${result.color}`}>{result.stairAngle}°</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Concrete Volume (Dry)</p>
                        <p className={`text-2xl font-bold ${result.color}`}>
                          {result.concreteVolume} {unitSystem === "metric" ? "m³" : "ft³"}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Slope Check (2R + T)</p>
                        <p className={`text-lg font-semibold ${result.color}`}>
                          {result.slope} mm - {result.slopeCheck}
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Dimensions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Riser Height</span>
                      <span className="text-muted-foreground">150-180 mm</span>
                    </div>
                    <div className="flex justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Tread Depth</span>
                      <span className="text-muted-foreground">250-300 mm</span>
                    </div>
                    <div className="flex justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Stair Width</span>
                      <span className="text-muted-foreground">900-1200 mm</span>
                    </div>
                    <div className="flex justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Stair Angle</span>
                      <span className="text-muted-foreground">30-35°</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Slope Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground text-center">Blondel's Formula</p>
                    <p className="font-mono text-center">2R + T ≈ 600-650 mm</p>
                    <p className="text-xs text-center mt-2">Where R = Riser, T = Tread</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                    Important Note
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    Staircase calculations follow standard building guidelines. Final dimensions should comply with
                    local building codes.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is a Staircase */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Staircase?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A staircase is a structural element that provides vertical access between different floor levels in a
                  building. It consists of a series of steps, each composed of a horizontal tread (where you place your
                  foot) and a vertical riser (the height between treads). The design of a staircase must balance
                  functionality, safety, comfort, and aesthetic considerations while complying with building codes and
                  regulations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Proper staircase design is critical for user comfort and safety. The relationship between riser height
                  and tread depth determines the staircase's steepness and ease of use. Standards and building codes
                  specify acceptable ranges for these dimensions to ensure safe and comfortable stair usage for people
                  of all ages and abilities.
                </p>
              </CardContent>
            </Card>

            {/* How are Staircases Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How are Staircases Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Staircase calculations begin with the floor-to-floor height and desired riser height. The number of
                  risers is determined by dividing the total height by the riser height, then rounding to the nearest
                  whole number. The exact riser height is recalculated by dividing the total height by the number of
                  risers. The number of treads is always one less than the number of risers since there is no tread at
                  the top landing.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A key design principle is Blondel's formula (2R + T ≈ 600-650mm), which relates riser height and
                  tread depth to create comfortable stairs. This formula is based on the average human stride and
                  ensures that the staircase is neither too steep nor too shallow. The stair angle can be calculated
                  using trigonometry, and typical residential stairs have angles between 30-35 degrees.
                </p>
              </CardContent>
            </Card>

            {/* Understanding Staircase Types */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <MoveVertical className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Staircase Types</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Straight flight staircases are the simplest type, consisting of a single continuous run of steps
                  without any turns or landings. They are space-efficient in one direction but require a long
                  horizontal distance. These stairs are easy to construct and navigate, making them popular for simple
                  residential applications where space permits.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Dog-legged staircases consist of two parallel flights connected by a landing, creating a 180-degree
                  turn. This configuration saves horizontal space and is common in residential buildings. Open-well
                  stairs are similar but include a gap (well) between the two flights, allowing light and air
                  circulation and providing a more spacious feel. Both types require careful calculation of individual
                  flight dimensions and landing sizes.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <CardTitle>Common Questions</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What is the ideal riser-tread relationship?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The ideal relationship follows Blondel's formula: 2R + T = 600-650mm. For residential stairs, a
                      common combination is 170mm riser with 270mm tread, giving 2(170) + 270 = 610mm, which falls
                      within the comfortable range. This ensures a natural stride pattern and reduces user fatigue.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What is the minimum staircase width?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Building codes typically require a minimum width of 900mm (36 inches) for residential stairs,
                      though 1000-1200mm is more comfortable and allows two people to pass. Commercial buildings often
                      require wider stairs, typically 1200mm or more, to accommodate higher traffic volumes and
                      emergency egress requirements.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Why use a dry volume factor for concrete?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The dry volume factor (typically 1.54) accounts for the volume reduction when mixing dry cement,
                      sand, and aggregate with water. Dry materials contain air voids that are filled when water is
                      added, resulting in a smaller final volume. Using this factor ensures you order enough dry
                      materials to achieve the required concrete volume.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Do all risers need to be exactly the same?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Yes, consistency is crucial for safety. Variation in riser heights can cause users to trip or
                      stumble as they develop a rhythm while climbing. Building codes typically allow a maximum
                      variation of 3-5mm between risers in a single flight. The human body expects uniform steps, and
                      even small variations can cause accidents.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
