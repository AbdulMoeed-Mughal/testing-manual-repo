"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Waves, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type SpeedUnit = "m/s" | "km/s" | "ft/s"
type FrequencyUnit = "Hz" | "kHz" | "MHz" | "GHz"
type WavelengthUnit = "m" | "cm" | "mm" | "nm" | "in"
type WaveType = "custom" | "light" | "sound-air" | "sound-water"

interface WavelengthResult {
  wavelength: number
  wavelengthM: number
  frequency: number
  waveSpeed: number
  category: string
  color: string
  bgColor: string
}

const speedConversions: Record<SpeedUnit, number> = {
  "m/s": 1,
  "km/s": 1000,
  "ft/s": 0.3048,
}

const frequencyConversions: Record<FrequencyUnit, number> = {
  Hz: 1,
  kHz: 1000,
  MHz: 1000000,
  GHz: 1000000000,
}

const wavelengthConversions: Record<WavelengthUnit, number> = {
  m: 1,
  cm: 0.01,
  mm: 0.001,
  nm: 1e-9,
  in: 0.0254,
}

const waveTypes: Record<WaveType, { speed: number; unit: SpeedUnit; label: string }> = {
  custom: { speed: 0, unit: "m/s", label: "Custom" },
  light: { speed: 299792458, unit: "m/s", label: "Light (Vacuum)" },
  "sound-air": { speed: 343, unit: "m/s", label: "Sound (Air, 20°C)" },
  "sound-water": { speed: 1482, unit: "m/s", label: "Sound (Water)" },
}

export function WavelengthCalculator() {
  const [waveType, setWaveType] = useState<WaveType>("custom")
  const [waveSpeed, setWaveSpeed] = useState("")
  const [speedUnit, setSpeedUnit] = useState<SpeedUnit>("m/s")
  const [frequency, setFrequency] = useState("")
  const [frequencyUnit, setFrequencyUnit] = useState<FrequencyUnit>("Hz")
  const [wavelengthUnit, setWavelengthUnit] = useState<WavelengthUnit>("m")
  const [result, setResult] = useState<WavelengthResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const selectWaveType = (type: WaveType) => {
    setWaveType(type)
    if (type !== "custom") {
      const waveInfo = waveTypes[type]
      setWaveSpeed(waveInfo.speed.toString())
      setSpeedUnit(waveInfo.unit)
    }
  }

  const calculateWavelength = () => {
    setError("")
    setResult(null)

    const speedNum = Number.parseFloat(waveSpeed)
    const freqNum = Number.parseFloat(frequency)

    if (isNaN(speedNum) || speedNum <= 0) {
      setError("Please enter a valid wave speed greater than 0")
      return
    }

    if (isNaN(freqNum) || freqNum <= 0) {
      setError("Please enter a valid frequency greater than 0")
      return
    }

    // Convert to base units (m/s and Hz)
    const speedInMS = speedNum * speedConversions[speedUnit]
    const freqInHz = freqNum * frequencyConversions[frequencyUnit]

    // Calculate wavelength: λ = v / f
    const wavelengthM = speedInMS / freqInHz

    // Convert to selected output unit
    const wavelengthInUnit = wavelengthM / wavelengthConversions[wavelengthUnit]

    // Categorize based on wavelength
    let category: string
    let color: string
    let bgColor: string

    if (wavelengthM < 1e-9) {
      category = "Gamma Rays"
      color = "text-violet-600"
      bgColor = "bg-violet-50 border-violet-200"
    } else if (wavelengthM < 400e-9) {
      category = "X-Rays / UV"
      color = "text-purple-600"
      bgColor = "bg-purple-50 border-purple-200"
    } else if (wavelengthM < 700e-9) {
      category = "Visible Light"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (wavelengthM < 1e-3) {
      category = "Infrared"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else if (wavelengthM < 1) {
      category = "Microwave"
      color = "text-amber-600"
      bgColor = "bg-amber-50 border-amber-200"
    } else if (wavelengthM < 1000) {
      category = "Radio Waves"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else {
      category = "Long Radio Waves"
      color = "text-teal-600"
      bgColor = "bg-teal-50 border-teal-200"
    }

    setResult({
      wavelength: wavelengthInUnit,
      wavelengthM,
      frequency: freqInHz,
      waveSpeed: speedInMS,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setWaveType("custom")
    setWaveSpeed("")
    setSpeedUnit("m/s")
    setFrequency("")
    setFrequencyUnit("Hz")
    setWavelengthUnit("m")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Wavelength: ${result.wavelength.toFixed(6)} ${wavelengthUnit} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Wavelength Calculation",
          text: `I calculated a wavelength using CalcHub! Result: ${result.wavelength.toFixed(6)} ${wavelengthUnit} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Waves className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Wavelength Calculator</CardTitle>
                    <CardDescription>Calculate wavelength from speed and frequency</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Wave Type Selection */}
                <div className="space-y-2">
                  <Label>Wave Type</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {(Object.keys(waveTypes) as WaveType[]).map((type) => (
                      <Button
                        key={type}
                        variant={waveType === type ? "default" : "outline"}
                        size="sm"
                        onClick={() => selectWaveType(type)}
                        className="h-auto py-2"
                      >
                        {waveTypes[type].label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Wave Speed Input */}
                <div className="space-y-2">
                  <Label htmlFor="speed">Wave Speed (v)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="speed"
                      type="number"
                      placeholder="Enter wave speed"
                      value={waveSpeed}
                      onChange={(e) => {
                        setWaveSpeed(e.target.value)
                        if (waveType !== "custom") setWaveType("custom")
                      }}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <select
                      value={speedUnit}
                      onChange={(e) => setSpeedUnit(e.target.value as SpeedUnit)}
                      className="h-10 rounded-md border border-input bg-background px-3 text-sm"
                    >
                      <option value="m/s">m/s</option>
                      <option value="km/s">km/s</option>
                      <option value="ft/s">ft/s</option>
                    </select>
                  </div>
                </div>

                {/* Frequency Input */}
                <div className="space-y-2">
                  <Label htmlFor="frequency">Frequency (f)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="frequency"
                      type="number"
                      placeholder="Enter frequency"
                      value={frequency}
                      onChange={(e) => setFrequency(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <select
                      value={frequencyUnit}
                      onChange={(e) => setFrequencyUnit(e.target.value as FrequencyUnit)}
                      className="h-10 rounded-md border border-input bg-background px-3 text-sm"
                    >
                      <option value="Hz">Hz</option>
                      <option value="kHz">kHz</option>
                      <option value="MHz">MHz</option>
                      <option value="GHz">GHz</option>
                    </select>
                  </div>
                </div>

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="output-unit">Output Unit</Label>
                  <select
                    id="output-unit"
                    value={wavelengthUnit}
                    onChange={(e) => setWavelengthUnit(e.target.value as WavelengthUnit)}
                    className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  >
                    <option value="m">Meters (m)</option>
                    <option value="cm">Centimeters (cm)</option>
                    <option value="mm">Millimeters (mm)</option>
                    <option value="nm">Nanometers (nm)</option>
                    <option value="in">Inches (in)</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWavelength} className="w-full" size="lg">
                  Calculate Wavelength
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center mb-3">
                      <p className="text-sm text-muted-foreground mb-1">Wavelength (λ)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.wavelength < 0.001 ? result.wavelength.toExponential(4) : result.wavelength.toFixed(6)}
                      </p>
                      <p className="text-sm text-muted-foreground mb-2">{wavelengthUnit}</p>
                      <p className={`text-base font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Additional Info */}
                    <div className="grid grid-cols-2 gap-2 text-sm mt-3 pt-3 border-t">
                      <div>
                        <p className="text-muted-foreground">Frequency</p>
                        <p className="font-semibold">
                          {result.frequency >= 1e9
                            ? `${(result.frequency / 1e9).toFixed(3)} GHz`
                            : result.frequency >= 1e6
                              ? `${(result.frequency / 1e6).toFixed(3)} MHz`
                              : result.frequency >= 1e3
                                ? `${(result.frequency / 1e3).toFixed(3)} kHz`
                                : `${result.frequency.toFixed(3)} Hz`}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Wave Speed</p>
                        <p className="font-semibold">
                          {result.waveSpeed >= 1e6
                            ? `${(result.waveSpeed / 1e6).toFixed(2)} Mm/s`
                            : result.waveSpeed >= 1e3
                              ? `${(result.waveSpeed / 1e3).toFixed(2)} km/s`
                              : `${result.waveSpeed.toFixed(2)} m/s`}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step breakdown */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? <ChevronUp className="h-4 w-4 mr-1" /> : <ChevronDown className="h-4 w-4 mr-1" />}
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-background/50 rounded-lg text-sm space-y-2">
                        <p className="font-semibold">Step-by-step:</p>
                        <p>
                          1. Formula: <strong>λ = v / f</strong>
                        </p>
                        <p>2. Wave speed (v) = {result.waveSpeed.toExponential(4)} m/s</p>
                        <p>3. Frequency (f) = {result.frequency.toExponential(4)} Hz</p>
                        <p>
                          4. λ = {result.waveSpeed.toExponential(4)} ÷ {result.frequency.toExponential(4)}
                        </p>
                        <p>5. λ = {result.wavelengthM.toExponential(4)} m</p>
                        {wavelengthUnit !== "m" && (
                          <p>
                            6. Converting to {wavelengthUnit}: {result.wavelength.toExponential(4)} {wavelengthUnit}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Wavelength Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">λ = v / f</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>λ</strong> = Wavelength
                    </p>
                    <p>
                      <strong>v</strong> = Wave speed (velocity)
                    </p>
                    <p>
                      <strong>f</strong> = Frequency
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Wave Speeds</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span>Light (vacuum)</span>
                      <span className="font-mono">299,792,458 m/s</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span>Sound (air, 20°C)</span>
                      <span className="font-mono">343 m/s</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span>Sound (water)</span>
                      <span className="font-mono">1,482 m/s</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span>Sound (steel)</span>
                      <span className="font-mono">5,960 m/s</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>About Wavelength</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Wavelength is the distance between consecutive corresponding points of the same phase on a wave, such
                  as adjacent crests or troughs. It is fundamentally related to the wave's frequency and velocity
                  through the equation λ = v / f, where λ represents wavelength, v is the wave speed, and f is the
                  frequency. This relationship shows that wavelength and frequency are inversely proportional for a
                  given wave speed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of wavelength applies to all types of waves, including electromagnetic waves (light, radio
                  waves, X-rays), mechanical waves (sound, water waves), and quantum mechanical waves (matter waves).
                  Different wavelengths of electromagnetic radiation correspond to different types of radiation in the
                  electromagnetic spectrum, from gamma rays with wavelengths less than a picometer to radio waves with
                  wavelengths that can exceed kilometers.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Applications</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4 text-muted-foreground">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Optics and Light</h4>
                    <p className="text-sm leading-relaxed">
                      Wavelength determines the color of visible light, with red light having longer wavelengths (around
                      700 nm) and violet light having shorter wavelengths (around 400 nm). This is crucial for designing
                      optical instruments, fiber optic communications, and laser systems.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Telecommunications</h4>
                    <p className="text-sm leading-relaxed">
                      Radio wave wavelengths determine antenna design and signal propagation characteristics. Different
                      wavelengths are used for AM radio, FM radio, Wi-Fi, cellular networks, and satellite
                      communications.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Acoustics</h4>
                    <p className="text-sm leading-relaxed">
                      Sound wavelengths affect how sound behaves in different environments, influencing room acoustics,
                      speaker design, and noise control. Lower frequencies have longer wavelengths and can diffract
                      around obstacles more easily.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Medical Imaging</h4>
                    <p className="text-sm leading-relaxed">
                      Different wavelengths of electromagnetic radiation are used in various medical imaging techniques,
                      from X-rays (short wavelength) for bone imaging to radio waves (long wavelength) in MRI scans.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <div className="text-amber-600 mt-0.5">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path
                        fillRule="evenodd"
                        d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-amber-800 font-medium mb-1">Disclaimer</p>
                    <p className="text-sm text-amber-700 leading-relaxed">
                      Wavelength calculations assume ideal wave propagation. Actual wavelengths may vary due to medium
                      properties, interference, or dispersion. Consult physics references for precise analysis.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
