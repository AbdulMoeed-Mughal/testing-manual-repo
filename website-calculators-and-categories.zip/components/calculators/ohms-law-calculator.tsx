"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Zap, Info, AlertTriangle, Lightbulb } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculateTarget = "voltage" | "current" | "resistance" | "power"

interface OhmsResult {
  value: number
  unit: string
  formula: string
  formattedValue: string
}

const prefixes = [
  { symbol: "p", name: "pico", factor: 1e-12 },
  { symbol: "n", name: "nano", factor: 1e-9 },
  { symbol: "µ", name: "micro", factor: 1e-6 },
  { symbol: "m", name: "milli", factor: 1e-3 },
  { symbol: "", name: "", factor: 1 },
  { symbol: "k", name: "kilo", factor: 1e3 },
  { symbol: "M", name: "mega", factor: 1e6 },
  { symbol: "G", name: "giga", factor: 1e9 },
]

function formatWithPrefix(value: number, baseUnit: string): string {
  if (value === 0) return `0 ${baseUnit}`

  const absValue = Math.abs(value)

  for (let i = prefixes.length - 1; i >= 0; i--) {
    const prefix = prefixes[i]
    if (absValue >= prefix.factor || i === 0) {
      const scaledValue = value / prefix.factor
      const formatted =
        scaledValue >= 1000
          ? scaledValue.toLocaleString(undefined, { maximumFractionDigits: 2 })
          : scaledValue.toPrecision(4).replace(/\.?0+$/, "")
      return `${formatted} ${prefix.symbol}${baseUnit}`
    }
  }

  return `${value} ${baseUnit}`
}

export function OhmsLawCalculator() {
  const [calculateTarget, setCalculateTarget] = useState<CalculateTarget>("voltage")
  const [voltage, setVoltage] = useState("")
  const [voltagePrefix, setVoltagePrefix] = useState("")
  const [current, setCurrent] = useState("")
  const [currentPrefix, setCurrentPrefix] = useState("")
  const [resistance, setResistance] = useState("")
  const [resistancePrefix, setResistancePrefix] = useState("")
  const [power, setPower] = useState("")
  const [powerPrefix, setPowerPrefix] = useState("")
  const [result, setResult] = useState<OhmsResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const getMultiplier = (prefix: string): number => {
    const found = prefixes.find((p) => p.symbol === prefix)
    return found ? found.factor : 1
  }

  const getValue = (input: string, prefix: string): number | null => {
    const num = Number.parseFloat(input)
    if (isNaN(num) || num < 0) return null
    return num * getMultiplier(prefix)
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const V = calculateTarget !== "voltage" ? getValue(voltage, voltagePrefix) : null
    const I = calculateTarget !== "current" ? getValue(current, currentPrefix) : null
    const R = calculateTarget !== "resistance" ? getValue(resistance, resistancePrefix) : null
    const P = calculateTarget !== "power" ? getValue(power, powerPrefix) : null

    // Count valid inputs
    const validInputs = [V, I, R, P].filter((v) => v !== null && v > 0)

    if (validInputs.length < 2) {
      setError("Please enter at least two valid values to calculate")
      return
    }

    let calculatedValue: number
    let formula: string
    let unit: string

    try {
      switch (calculateTarget) {
        case "voltage":
          if (I !== null && I > 0 && R !== null && R > 0) {
            calculatedValue = I * R
            formula = "V = I × R"
          } else if (P !== null && P > 0 && I !== null && I > 0) {
            calculatedValue = P / I
            formula = "V = P ÷ I"
          } else if (P !== null && P > 0 && R !== null && R > 0) {
            calculatedValue = Math.sqrt(P * R)
            formula = "V = √(P × R)"
          } else {
            setError("Please provide valid values for Current & Resistance, Power & Current, or Power & Resistance")
            return
          }
          unit = "V"
          break

        case "current":
          if (V !== null && V > 0 && R !== null && R > 0) {
            calculatedValue = V / R
            formula = "I = V ÷ R"
          } else if (P !== null && P > 0 && V !== null && V > 0) {
            calculatedValue = P / V
            formula = "I = P ÷ V"
          } else if (P !== null && P > 0 && R !== null && R > 0) {
            calculatedValue = Math.sqrt(P / R)
            formula = "I = √(P ÷ R)"
          } else {
            setError("Please provide valid values for Voltage & Resistance, Power & Voltage, or Power & Resistance")
            return
          }
          unit = "A"
          break

        case "resistance":
          if (V !== null && V > 0 && I !== null && I > 0) {
            calculatedValue = V / I
            formula = "R = V ÷ I"
          } else if (V !== null && V > 0 && P !== null && P > 0) {
            calculatedValue = (V * V) / P
            formula = "R = V² ÷ P"
          } else if (P !== null && P > 0 && I !== null && I > 0) {
            calculatedValue = P / (I * I)
            formula = "R = P ÷ I²"
          } else {
            setError("Please provide valid values for Voltage & Current, Voltage & Power, or Power & Current")
            return
          }
          unit = "Ω"
          break

        case "power":
          if (V !== null && V > 0 && I !== null && I > 0) {
            calculatedValue = V * I
            formula = "P = V × I"
          } else if (V !== null && V > 0 && R !== null && R > 0) {
            calculatedValue = (V * V) / R
            formula = "P = V² ÷ R"
          } else if (I !== null && I > 0 && R !== null && R > 0) {
            calculatedValue = I * I * R
            formula = "P = I² × R"
          } else {
            setError("Please provide valid values for Voltage & Current, Voltage & Resistance, or Current & Resistance")
            return
          }
          unit = "W"
          break

        default:
          return
      }

      if (!isFinite(calculatedValue)) {
        setError("Calculation resulted in an invalid value. Please check your inputs.")
        return
      }

      setResult({
        value: calculatedValue,
        unit,
        formula,
        formattedValue: formatWithPrefix(calculatedValue, unit),
      })
    } catch {
      setError("An error occurred during calculation")
    }
  }

  const handleReset = () => {
    setVoltage("")
    setVoltagePrefix("")
    setCurrent("")
    setCurrentPrefix("")
    setResistance("")
    setResistancePrefix("")
    setPower("")
    setPowerPrefix("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `${getTargetLabel(calculateTarget)}: ${result.formattedValue} (${result.formula})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getTargetLabel = (target: CalculateTarget): string => {
    switch (target) {
      case "voltage":
        return "Voltage"
      case "current":
        return "Current"
      case "resistance":
        return "Resistance"
      case "power":
        return "Power"
    }
  }

  const getTargetUnit = (target: CalculateTarget): string => {
    switch (target) {
      case "voltage":
        return "V"
      case "current":
        return "A"
      case "resistance":
        return "Ω"
      case "power":
        return "W"
    }
  }

  const renderInput = (
    label: string,
    value: string,
    setValue: (v: string) => void,
    prefix: string,
    setPrefix: (v: string) => void,
    unit: string,
    disabled: boolean,
  ) => (
    <div className={`space-y-2 ${disabled ? "opacity-50" : ""}`}>
      <Label>{label}</Label>
      <div className="flex gap-2">
        <Input
          type="number"
          placeholder={`Enter ${label.toLowerCase()}`}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          disabled={disabled}
          min="0"
          step="any"
          className="flex-1"
        />
        <select
          value={prefix}
          onChange={(e) => setPrefix(e.target.value)}
          disabled={disabled}
          className="w-24 rounded-md border border-input bg-background px-3 py-2 text-sm"
        >
          <option value="p">p{unit}</option>
          <option value="n">n{unit}</option>
          <option value="µ">µ{unit}</option>
          <option value="m">m{unit}</option>
          <option value="">{unit}</option>
          <option value="k">k{unit}</option>
          <option value="M">M{unit}</option>
          <option value="G">G{unit}</option>
        </select>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Ohm's Law Calculator</CardTitle>
                    <CardDescription>Calculate V, I, R, or P</CardDescription>
                  </div>
                </div>

                {/* Calculate Target Selection */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Calculate</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {(["voltage", "current", "resistance", "power"] as CalculateTarget[]).map((target) => (
                      <button
                        key={target}
                        onClick={() => {
                          setCalculateTarget(target)
                          setResult(null)
                          setError("")
                        }}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                          calculateTarget === target
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        {target === "voltage" && "V"}
                        {target === "current" && "I"}
                        {target === "resistance" && "R"}
                        {target === "power" && "P"}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Calculating: {getTargetLabel(calculateTarget)} ({getTargetUnit(calculateTarget)})
                  </p>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Voltage Input */}
                {renderInput(
                  "Voltage (V)",
                  voltage,
                  setVoltage,
                  voltagePrefix,
                  setVoltagePrefix,
                  "V",
                  calculateTarget === "voltage",
                )}

                {/* Current Input */}
                {renderInput(
                  "Current (I)",
                  current,
                  setCurrent,
                  currentPrefix,
                  setCurrentPrefix,
                  "A",
                  calculateTarget === "current",
                )}

                {/* Resistance Input */}
                {renderInput(
                  "Resistance (R)",
                  resistance,
                  setResistance,
                  resistancePrefix,
                  setResistancePrefix,
                  "Ω",
                  calculateTarget === "resistance",
                )}

                {/* Power Input */}
                {renderInput(
                  "Power (P)",
                  power,
                  setPower,
                  powerPrefix,
                  setPowerPrefix,
                  "W",
                  calculateTarget === "power",
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {getTargetLabel(calculateTarget)}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{getTargetLabel(calculateTarget)}</p>
                      <p className="text-4xl font-bold text-orange-600 mb-2">{result.formattedValue}</p>
                      <p className="text-sm text-orange-700 font-medium">Formula: {result.formula}</p>
                    </div>

                    {/* Show Steps Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-sm text-orange-600 hover:text-orange-700 font-medium"
                    >
                      {showSteps ? "Hide Steps" : "Show Calculation Steps"}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-1">
                        <p className="font-medium text-foreground">Calculation:</p>
                        <p className="text-muted-foreground font-mono">{result.formula}</p>
                        <p className="text-muted-foreground font-mono">= {result.value.toExponential(4)}</p>
                        <p className="text-muted-foreground font-mono">= {result.formattedValue}</p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Ohm's Law Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Voltage (V)</span>
                      <p className="text-sm text-blue-600 font-mono mt-1">V = I × R = P ÷ I = √(P × R)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Current (I)</span>
                      <p className="text-sm text-green-600 font-mono mt-1">I = V ÷ R = P ÷ V = √(P ÷ R)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Resistance (R)</span>
                      <p className="text-sm text-yellow-600 font-mono mt-1">R = V ÷ I = V² ÷ P = P ÷ I²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Power (P)</span>
                      <p className="text-sm text-purple-600 font-mono mt-1">P = V × I = V² ÷ R = I² × R</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Prefixes</CardTitle>
                </CardHeader>
                <CardContent className="text-sm">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">p</span> = pico (10⁻¹²)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">n</span> = nano (10⁻⁹)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">µ</span> = micro (10⁻⁶)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">m</span> = milli (10⁻³)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">k</span> = kilo (10³)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">M</span> = mega (10⁶)
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Disclaimer</p>
                      <p className="text-sm text-amber-700 mt-1">
                        This calculator provides theoretical values for ideal circuits. Real-world components may behave
                        differently due to tolerance, temperature, and other factors.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Ohm's Law?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ohm's Law is one of the most fundamental principles in electrical engineering and physics, named after
                  German physicist Georg Simon Ohm who first described it in 1827. This law establishes the relationship
                  between voltage, current, and resistance in an electrical circuit, forming the foundation for
                  understanding how electricity behaves in conductors.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The law states that the current flowing through a conductor between two points is directly
                  proportional to the voltage across the two points and inversely proportional to the resistance between
                  them. Mathematically expressed as V = I × R, this elegant equation allows engineers and technicians to
                  predict and control electrical behavior in countless applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Variables</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Voltage (V) - Electrical Pressure</h4>
                    <p className="text-blue-700 text-sm">
                      Voltage, measured in volts (V), represents the electrical potential difference between two points
                      in a circuit. Think of it as the "pressure" that pushes electrons through a conductor. Higher
                      voltage means more force pushing the current through the circuit. Common examples include 1.5V
                      batteries, 120V household outlets in North America, and 230V in Europe.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Current (I) - Electrical Flow</h4>
                    <p className="text-green-700 text-sm">
                      Current, measured in amperes (A), represents the rate of electron flow through a conductor. It's
                      analogous to the volume of water flowing through a pipe. One ampere equals approximately 6.24 ×
                      10¹⁸ electrons passing a point per second. Electronic devices typically use milliamps (mA), while
                      high-power applications may use tens or hundreds of amps.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Resistance (R) - Opposition to Flow</h4>
                    <p className="text-yellow-700 text-sm">
                      Resistance, measured in ohms (Ω), represents how much a material opposes the flow of current. Like
                      friction in mechanical systems, resistance converts electrical energy into heat. Conductors like
                      copper have low resistance, while insulators like rubber have extremely high resistance. Resistors
                      are components specifically designed to provide controlled resistance.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Power (P) - Energy Consumption</h4>
                    <p className="text-purple-700 text-sm">
                      Power, measured in watts (W), represents the rate at which electrical energy is consumed or
                      produced. It combines voltage and current (P = V × I) to show how much work is being done. A 60W
                      light bulb converts 60 joules of electrical energy into light and heat every second. Understanding
                      power is essential for sizing circuits and calculating energy costs.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ohm's Law has countless practical applications in everyday life and professional settings.
                  Electricians use it to determine proper wire gauge for circuits, ensuring safety and efficiency.
                  Electronics engineers apply it when designing circuits, calculating component values, and
                  troubleshooting problems. Even hobbyists building simple LED circuits need to understand Ohm's Law to
                  select the correct resistor values.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In power distribution, utility companies use these principles to design transmission lines that
                  minimize power loss over long distances. Automotive technicians apply Ohm's Law when diagnosing
                  electrical problems in vehicles. The extended power formulas (P = V × I, P = I²R, P = V²/R) are
                  essential for calculating heat dissipation, determining battery life, and sizing power supplies for
                  electronic devices.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding the relationship between these variables also helps with energy efficiency. For
                  instance, knowing that power loss in a wire equals I²R explains why high-voltage transmission lines
                  are more efficient - for the same power, higher voltage means lower current, and lower current means
                  less energy lost as heat in the wire's resistance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
