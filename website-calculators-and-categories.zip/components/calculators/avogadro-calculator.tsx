"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Atom, Info, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AvogadroResult {
  particles: number
  particlesFormatted: string
  moles: number
  particleType: string
  avogadroConstant: string
}

const AVOGADRO_CONSTANT = 6.02214076e23

export function AvogadroCalculator() {
  const [moles, setMoles] = useState("")
  const [particleType, setParticleType] = useState("molecules")
  const [useScientific, setUseScientific] = useState(true)
  const [result, setResult] = useState<AvogadroResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatNumber = (num: number, scientific: boolean): string => {
    if (scientific) {
      return num.toExponential(4)
    }
    return num.toLocaleString("en-US", { maximumFractionDigits: 0 })
  }

  const calculateParticles = () => {
    setError("")
    setResult(null)

    const molesNum = Number.parseFloat(moles)
    if (isNaN(molesNum) || molesNum <= 0) {
      setError("Please enter a valid positive number of moles")
      return
    }

    const particles = molesNum * AVOGADRO_CONSTANT

    setResult({
      particles,
      particlesFormatted: formatNumber(particles, useScientific),
      moles: molesNum,
      particleType,
      avogadroConstant: "6.022 × 10²³ mol⁻¹",
    })
  }

  const handleReset = () => {
    setMoles("")
    setParticleType("molecules")
    setUseScientific(true)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `${result.moles} mol = ${result.particlesFormatted} ${result.particleType}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Avogadro's Number Calculation",
          text: `I calculated ${result.moles} mol = ${result.particlesFormatted} ${result.particleType} using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getMagnitudeCategory = (particles: number): { label: string; color: string; bgColor: string } => {
    const exponent = Math.floor(Math.log10(particles))
    if (exponent < 20) {
      return { label: "Small Sample", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    } else if (exponent < 23) {
      return { label: "Laboratory Scale", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    } else if (exponent < 26) {
      return { label: "Standard Scale", color: "text-purple-600", bgColor: "bg-purple-50 border-purple-200" }
    } else {
      return { label: "Large Scale", color: "text-amber-600", bgColor: "bg-amber-50 border-amber-200" }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Atom className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Avogadro's Number Calculator</CardTitle>
                    <CardDescription>Calculate particle count from moles</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Moles Input */}
                <div className="space-y-2">
                  <Label htmlFor="moles">Amount of Substance (mol)</Label>
                  <Input
                    id="moles"
                    type="number"
                    placeholder="Enter amount in moles"
                    value={moles}
                    onChange={(e) => setMoles(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Particle Type Selection */}
                <div className="space-y-2">
                  <Label htmlFor="particleType">Particle Type</Label>
                  <Select value={particleType} onValueChange={setParticleType}>
                    <SelectTrigger id="particleType">
                      <SelectValue placeholder="Select particle type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="atoms">Atoms</SelectItem>
                      <SelectItem value="molecules">Molecules</SelectItem>
                      <SelectItem value="ions">Ions</SelectItem>
                      <SelectItem value="particles">Particles (generic)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Scientific Notation Toggle */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Display Format</span>
                  <button
                    onClick={() => setUseScientific(!useScientific)}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        !useScientific ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        useScientific ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Scientific
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !useScientific ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Standard
                    </span>
                  </button>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateParticles} className="w-full" size="lg">
                  Calculate Particles
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getMagnitudeCategory(result.particles).bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Number of {result.particleType}</p>
                      <p className={`text-3xl sm:text-4xl font-bold ${getMagnitudeCategory(result.particles).color} mb-2 break-all`}>
                        {result.particlesFormatted}
                      </p>
                      <p className={`text-lg font-semibold ${getMagnitudeCategory(result.particles).color}`}>
                        {getMagnitudeCategory(result.particles).label}
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset} className="bg-transparent">
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy} className="bg-transparent">
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare} className="bg-transparent">
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">N = n × N<sub>A</sub></p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p><strong>N</strong> = Number of particles</p>
                    <p><strong>n</strong> = Amount of substance (moles)</p>
                    <p><strong>N<sub>A</sub></strong> = Avogadro's constant = 6.022 × 10²³ mol⁻¹</p>
                  </div>
                </CardContent>
              </Card>

              {result && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Calculation Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between p-2 bg-muted/50 rounded">
                        <span>Amount of substance (n)</span>
                        <span className="font-medium">{result.moles} mol</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted/50 rounded">
                        <span>Avogadro's constant (N<sub>A</sub>)</span>
                        <span className="font-medium">{result.avogadroConstant}</span>
                      </div>
                      <div className="flex justify-between p-2 bg-purple-50 rounded border border-purple-200">
                        <span className="text-purple-700">N = n × N<sub>A</sub></span>
                        <span className="font-medium text-purple-700">{result.particlesFormatted}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">1 mole</span>
                      <span className="text-sm text-purple-600">6.022 × 10²³ particles</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">0.5 moles</span>
                      <span className="text-sm text-blue-600">3.011 × 10²³ particles</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">2 moles</span>
                      <span className="text-sm text-green-600">1.204 × 10²⁴ particles</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Avogadro's Number */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Avogadro's Number?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Avogadro's number (N<sub>A</sub>), approximately 6.022 × 10²³, is one of the most fundamental constants 
                  in chemistry and physics. It represents the number of constituent particles (atoms, molecules, ions, 
                  or other entities) contained in one mole of a substance. This constant is named after the Italian 
                  scientist Amedeo Avogadro, who in 1811 first proposed that equal volumes of gases at the same 
                  temperature and pressure contain equal numbers of molecules.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The exact value of Avogadro's constant, as defined by the International Bureau of Weights and 
                  Measures since 2019, is exactly 6.02214076 × 10²³ mol⁻¹. This redefinition was part of the 
                  2019 revision of the SI units, which tied fundamental constants to exact numerical values rather 
                  than physical artifacts. Understanding Avogadro's number is essential for converting between 
                  macroscopic measurements and the microscopic world of atoms and molecules.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications in Chemistry</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Avogadro's number serves as a bridge between the atomic scale and the macroscopic world we can 
                  observe and measure. In stoichiometry, it allows chemists to calculate the exact number of atoms 
                  or molecules involved in a chemical reaction from measurable quantities like mass and volume. 
                  This is crucial for understanding reaction ratios and predicting product yields.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Molar Mass Calculations</h4>
                    <p className="text-purple-700 text-sm">
                      Convert between grams and moles using molar mass, then use Avogadro's number to find particle counts.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Gas Law Problems</h4>
                    <p className="text-blue-700 text-sm">
                      At STP, one mole of any ideal gas occupies 22.4 L, containing 6.022 × 10²³ molecules.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Solution Chemistry</h4>
                    <p className="text-green-700 text-sm">
                      Calculate the number of solute particles in solutions of known molarity and volume.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Electrochemistry</h4>
                    <p className="text-amber-700 text-sm">
                      Determine electron transfer in redox reactions using Faraday's constant (N<sub>A</sub> × e).
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50 border-dashed">
              <CardContent className="py-4">
                <p className="text-sm text-muted-foreground text-center">
                  Calculations are based on the defined value of Avogadro's constant (6.02214076 × 10²³ mol⁻¹). 
                  Results represent theoretical particle counts and assume ideal conditions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
