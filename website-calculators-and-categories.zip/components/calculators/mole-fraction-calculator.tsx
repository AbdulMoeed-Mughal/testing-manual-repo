"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Beaker, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface MoleFractionResult {
  moleFraction: number
  percentage: number
  category: string
  color: string
  bgColor: string
}

export function MoleFractionCalculator() {
  const [componentMoles, setComponentMoles] = useState("")
  const [totalMoles, setTotalMoles] = useState("")
  const [result, setResult] = useState<MoleFractionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateMoleFraction = () => {
    setError("")
    setResult(null)

    const nComponent = Number.parseFloat(componentMoles)
    const nTotal = Number.parseFloat(totalMoles)

    if (isNaN(nComponent) || nComponent <= 0) {
      setError("Please enter valid component moles greater than 0")
      return
    }

    if (isNaN(nTotal) || nTotal <= 0) {
      setError("Please enter valid total moles greater than 0")
      return
    }

    if (nComponent > nTotal) {
      setError("Component moles cannot exceed total moles")
      return
    }

    const moleFraction = nComponent / nTotal
    const percentage = moleFraction * 100

    let category: string
    let color: string
    let bgColor: string

    if (moleFraction < 0.1) {
      category = "Minor Component"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (moleFraction < 0.3) {
      category = "Moderate Component"
      color = "text-cyan-600"
      bgColor = "bg-cyan-50 border-cyan-200"
    } else if (moleFraction < 0.5) {
      category = "Significant Component"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (moleFraction < 0.9) {
      category = "Major Component"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Dominant Component"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    }

    setResult({
      moleFraction: Math.round(moleFraction * 10000) / 10000,
      percentage: Math.round(percentage * 100) / 100,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setComponentMoles("")
    setTotalMoles("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Mole Fraction: ${result.moleFraction} (${result.percentage}%) - ${result.category}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Mole Fraction Result",
          text: `I calculated mole fraction: ${result.moleFraction} (${result.percentage}%)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Beaker className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Mole Fraction Calculator</CardTitle>
                    <CardDescription>Calculate component composition in mixtures</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Component Moles Input */}
                <div className="space-y-2">
                  <Label htmlFor="componentMoles">Component Moles (n₁)</Label>
                  <Input
                    id="componentMoles"
                    type="number"
                    placeholder="Enter moles of component"
                    value={componentMoles}
                    onChange={(e) => setComponentMoles(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                </div>

                {/* Total Moles Input */}
                <div className="space-y-2">
                  <Label htmlFor="totalMoles">Total Moles (nₜ)</Label>
                  <Input
                    id="totalMoles"
                    type="number"
                    placeholder="Enter total moles in mixture"
                    value={totalMoles}
                    onChange={(e) => setTotalMoles(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMoleFraction} className="w-full" size="lg">
                  Calculate Mole Fraction
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Mole Fraction (x)</p>
                        <p className={`text-4xl font-bold ${result.color}`}>{result.moleFraction}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Percentage Composition</p>
                        <p className={`text-2xl font-semibold ${result.color}`}>{result.percentage}%</p>
                      </div>
                      <p className={`text-base font-medium ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Calculation Steps */}
                    <div className="mt-4 p-3 bg-background/50 rounded-lg text-sm space-y-2">
                      <p className="font-semibold text-foreground">Calculation:</p>
                      <p className="text-muted-foreground font-mono">
                        x = n₁ / nₜ = {componentMoles} / {totalMoles} = {result.moleFraction}
                      </p>
                      <p className="text-muted-foreground font-mono">
                        Percentage = x × 100% = {result.moleFraction} × 100% = {result.percentage}%
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Composition Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Minor Component</span>
                      <span className="text-sm text-blue-600">{"< 0.1"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Moderate Component</span>
                      <span className="text-sm text-cyan-600">0.1 – 0.3</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Significant Component</span>
                      <span className="text-sm text-yellow-600">0.3 – 0.5</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Major Component</span>
                      <span className="text-sm text-orange-600">0.5 – 0.9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Dominant Component</span>
                      <span className="text-sm text-green-600">{"≥ 0.9"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mole Fraction Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">xᵢ = nᵢ / nₜ</p>
                  </div>
                  <p>
                    Where <strong>xᵢ</strong> is the mole fraction of component i, <strong>nᵢ</strong> is the number of
                    moles of component i, and <strong>nₜ</strong> is the total number of moles in the mixture.
                  </p>
                  <p>
                    The sum of all mole fractions in a mixture equals 1: <strong>Σxᵢ = 1</strong>
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Mole Fraction */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Mole Fraction?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Mole fraction is a way of expressing the concentration of a component in a mixture. It is defined as
                  the ratio of the number of moles of a particular component to the total number of moles of all
                  components in the mixture. Unlike other concentration measures such as molarity or molality, mole
                  fraction is a dimensionless quantity that ranges from 0 to 1 and is independent of temperature and
                  pressure.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Mole fraction is particularly useful in thermodynamics, chemical engineering, and physical chemistry
                  because it provides a direct measure of the proportion of molecules of each component in a mixture. This
                  makes it ideal for calculations involving vapor pressure, partial pressure, and phase equilibria in
                  solutions and gas mixtures.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Mole Fraction</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Raoult's Law</h4>
                    <p className="text-purple-700 text-sm">
                      Mole fraction is used in Raoult's law to calculate the vapor pressure of ideal solutions. The
                      partial pressure of each component is equal to its mole fraction times its pure vapor pressure.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Dalton's Law</h4>
                    <p className="text-blue-700 text-sm">
                      In gas mixtures, the partial pressure of each gas is equal to its mole fraction times the total
                      pressure, as described by Dalton's law of partial pressures.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Phase Equilibria</h4>
                    <p className="text-cyan-700 text-sm">
                      Mole fractions are essential in studying phase diagrams and determining the composition of phases
                      in equilibrium, such as in distillation and extraction processes.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Chemical Reactions</h4>
                    <p className="text-green-700 text-sm">
                      In reaction equilibria, mole fractions are used to calculate equilibrium constants and predict the
                      direction and extent of chemical reactions.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Note</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 leading-relaxed">
                  Mole fraction calculations assume ideal mixtures. Real systems may show deviations due to interactions
                  between components, such as hydrogen bonding, dipole-dipole interactions, or changes in molecular
                  structure. For non-ideal solutions, activity coefficients may need to be considered.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
