"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calendar,
  Info,
  AlertTriangle,
  Cake,
  Clock,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface AgeResult {
  years: number
  months: number
  days: number
  totalDays: number
  totalWeeks: number
  totalMonths: number
  totalHours: number
  totalMinutes: number
  daysUntilBirthday: number
  nextBirthdayDate: string
  zodiacSign: string
}

export function AgeCalculator() {
  const [birthDate, setBirthDate] = useState("")
  const [referenceDate, setReferenceDate] = useState("")
  const [includeTime, setIncludeTime] = useState(false)
  const [birthTime, setBirthTime] = useState("")
  const [referenceTime, setReferenceTime] = useState("")
  const [result, setResult] = useState<AgeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const getZodiacSign = (month: number, day: number): string => {
    if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return "Aquarius"
    if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return "Pisces"
    if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return "Aries"
    if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return "Taurus"
    if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return "Gemini"
    if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return "Cancer"
    if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return "Leo"
    if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return "Virgo"
    if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return "Libra"
    if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return "Scorpio"
    if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return "Sagittarius"
    return "Capricorn"
  }

  const calculateAge = () => {
    setError("")
    setResult(null)

    if (!birthDate) {
      setError("Please enter your date of birth")
      return
    }

    const birth = new Date(birthDate)
    const reference = referenceDate ? new Date(referenceDate) : new Date()

    if (includeTime && birthTime) {
      const [birthHours, birthMinutes] = birthTime.split(":").map(Number)
      birth.setHours(birthHours, birthMinutes, 0, 0)
    }

    if (includeTime && referenceTime) {
      const [refHours, refMinutes] = referenceTime.split(":").map(Number)
      reference.setHours(refHours, refMinutes, 0, 0)
    }

    if (birth > reference) {
      setError("Date of birth must be earlier than the reference date")
      return
    }

    // Calculate years, months, days
    let years = reference.getFullYear() - birth.getFullYear()
    let months = reference.getMonth() - birth.getMonth()
    let days = reference.getDate() - birth.getDate()

    if (days < 0) {
      months--
      const prevMonth = new Date(reference.getFullYear(), reference.getMonth(), 0)
      days += prevMonth.getDate()
    }

    if (months < 0) {
      years--
      months += 12
    }

    // Calculate total values
    const diffTime = Math.abs(reference.getTime() - birth.getTime())
    const totalDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))
    const totalWeeks = Math.floor(totalDays / 7)
    const totalMonths = years * 12 + months
    const totalHours = Math.floor(diffTime / (1000 * 60 * 60))
    const totalMinutes = Math.floor(diffTime / (1000 * 60))

    // Calculate days until next birthday
    const thisYearBirthday = new Date(reference.getFullYear(), birth.getMonth(), birth.getDate())
    let nextBirthday = thisYearBirthday

    if (thisYearBirthday <= reference) {
      nextBirthday = new Date(reference.getFullYear() + 1, birth.getMonth(), birth.getDate())
    }

    const daysUntilBirthday = Math.ceil((nextBirthday.getTime() - reference.getTime()) / (1000 * 60 * 60 * 24))
    const nextBirthdayDate = nextBirthday.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    // Get zodiac sign
    const zodiacSign = getZodiacSign(birth.getMonth() + 1, birth.getDate())

    setResult({
      years,
      months,
      days,
      totalDays,
      totalWeeks,
      totalMonths,
      totalHours,
      totalMinutes,
      daysUntilBirthday,
      nextBirthdayDate,
      zodiacSign,
    })
  }

  const handleReset = () => {
    setBirthDate("")
    setReferenceDate("")
    setBirthTime("")
    setReferenceTime("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `I am ${result.years} years, ${result.months} months, and ${result.days} days old (${result.totalDays.toLocaleString()} days total)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Age Result",
          text: `I calculated my age using CalcHub! I am ${result.years} years, ${result.months} months, and ${result.days} days old.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number) => num.toLocaleString()

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Age Calculator</CardTitle>
                    <CardDescription>Calculate your exact age</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Date of Birth */}
                <div className="space-y-2">
                  <Label htmlFor="birthDate">Date of Birth</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                {/* Reference Date */}
                <div className="space-y-2">
                  <Label htmlFor="referenceDate">Reference Date (default: today)</Label>
                  <Input
                    id="referenceDate"
                    type="date"
                    value={referenceDate}
                    onChange={(e) => setReferenceDate(e.target.value)}
                    placeholder="Leave empty for today"
                  />
                </div>

                {/* Include Time Toggle */}
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm font-medium">Include Time</span>
                  <button
                    onClick={() => setIncludeTime(!includeTime)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      includeTime ? "bg-primary" : "bg-muted"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform ${
                        includeTime ? "translate-x-6" : "translate-x-1"
                      }`}
                    />
                  </button>
                </div>

                {/* Time Inputs */}
                {includeTime && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="birthTime">Birth Time</Label>
                      <Input
                        id="birthTime"
                        type="time"
                        value={birthTime}
                        onChange={(e) => setBirthTime(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="referenceTime">Reference Time</Label>
                      <Input
                        id="referenceTime"
                        type="time"
                        value={referenceTime}
                        onChange={(e) => setReferenceTime(e.target.value)}
                      />
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAge} className="w-full" size="lg">
                  Calculate Age
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Age</p>
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <span className="text-4xl sm:text-5xl font-bold text-cyan-600">{result.years}</span>
                        <span className="text-lg text-cyan-600">years</span>
                      </div>
                      <p className="text-lg font-medium text-cyan-700">
                        {result.months} months, {result.days} days
                      </p>
                    </div>

                    {/* Next Birthday */}
                    <div className="mt-4 p-3 bg-white/60 rounded-lg">
                      <div className="flex items-center justify-center gap-2 text-cyan-700">
                        <Cake className="h-4 w-4" />
                        <span className="text-sm font-medium">
                          {result.daysUntilBirthday === 0
                            ? "Happy Birthday! 🎉"
                            : `${result.daysUntilBirthday} days until your next birthday`}
                        </span>
                      </div>
                      <p className="text-xs text-center text-muted-foreground mt-1">{result.nextBirthdayDate}</p>
                    </div>

                    {/* Zodiac Sign */}
                    <div className="mt-3 text-center">
                      <span className="text-sm text-muted-foreground">Zodiac Sign: </span>
                      <span className="text-sm font-medium text-cyan-700">{result.zodiacSign}</span>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              {/* Age Breakdown */}
              {result && (
                <Card>
                  <CardHeader className="cursor-pointer" onClick={() => setShowBreakdown(!showBreakdown)}>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">Age in Different Units</CardTitle>
                      {showBreakdown ? (
                        <ChevronUp className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                  </CardHeader>
                  {showBreakdown && (
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <span className="text-sm text-muted-foreground">Total Months</span>
                          <span className="font-semibold">{formatNumber(result.totalMonths)}</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <span className="text-sm text-muted-foreground">Total Weeks</span>
                          <span className="font-semibold">{formatNumber(result.totalWeeks)}</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <span className="text-sm text-muted-foreground">Total Days</span>
                          <span className="font-semibold">{formatNumber(result.totalDays)}</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <span className="text-sm text-muted-foreground">Total Hours</span>
                          <span className="font-semibold">{formatNumber(result.totalHours)}</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <span className="text-sm text-muted-foreground">Total Minutes</span>
                          <span className="font-semibold">{formatNumber(result.totalMinutes)}</span>
                        </div>
                      </div>
                    </CardContent>
                  )}
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-medium text-foreground mb-2">Age Calculation</p>
                    <p>
                      Your exact age is calculated by finding the difference between your date of birth and the
                      reference date (today by default), accounting for varying month lengths and leap years.
                    </p>
                  </div>
                  <p>
                    The calculator also determines your zodiac sign and calculates how many days remain until your next
                    birthday.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Features</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <Calendar className="h-5 w-5 text-cyan-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-cyan-800">Custom Reference Date</p>
                        <p className="text-sm text-cyan-700">Calculate age at any point in time</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <Clock className="h-5 w-5 text-cyan-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-cyan-800">Time Precision</p>
                        <p className="text-sm text-cyan-700">Include hours and minutes for exact calculation</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <Cake className="h-5 w-5 text-cyan-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-cyan-800">Birthday Countdown</p>
                        <p className="text-sm text-cyan-700">See days until your next birthday</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an Age Calculator?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An age calculator is a tool that determines the exact time elapsed between a date of birth and a
                  reference date (typically today). Unlike simply subtracting years, a precise age calculator accounts
                  for the varying lengths of months, leap years, and can even include time down to the hour and minute
                  for maximum accuracy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator is useful for various purposes including determining eligibility for age-restricted
                  activities, calculating retirement dates, planning milestone celebrations, or simply satisfying
                  curiosity about exactly how long you've been alive in various units of time.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Age Calculation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Age calculation involves more complexity than simple year subtraction because months have different
                  numbers of days, and leap years add an extra day to February. The calculator handles these variations
                  by computing the difference in years, then adjusting for the remaining months and days.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Years Calculation</h4>
                    <p className="text-cyan-700 text-sm">
                      The number of complete years between the birth date and reference date, adjusted if the birthday
                      hasn't occurred yet in the current year.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Months Calculation</h4>
                    <p className="text-cyan-700 text-sm">
                      The number of complete months after accounting for full years. If the day of the month hasn't
                      passed, one month is subtracted.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Days Calculation</h4>
                    <p className="text-cyan-700 text-sm">
                      The remaining days after full years and months are accounted for, considering the actual number of
                      days in each month.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Age calculators serve many practical purposes in everyday life and professional settings. They help
                  determine eligibility for services, plan events, and track personal milestones.
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Legal Requirements:</strong> Verify age for voting, driving licenses, alcohol purchase, or
                    retirement benefits
                  </li>
                  <li>
                    <strong>Healthcare:</strong> Calculate precise age for medical dosages, developmental milestones, or
                    insurance purposes
                  </li>
                  <li>
                    <strong>Education:</strong> Determine school enrollment eligibility or academic year placement
                  </li>
                  <li>
                    <strong>Employment:</strong> Verify age requirements for jobs, calculate pension eligibility, or
                    plan retirement
                  </li>
                  <li>
                    <strong>Personal:</strong> Track life milestones, plan birthday celebrations, or satisfy curiosity
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-amber-800 mb-1">Disclaimer</h4>
                    <p className="text-sm text-amber-700">
                      Age calculations are based on calendar dates and may vary depending on time zone or calendar
                      conventions. For legal or official purposes, always verify age requirements with the relevant
                      authority. This calculator uses the Gregorian calendar system.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
