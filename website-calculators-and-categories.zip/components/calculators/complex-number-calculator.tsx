"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, Calculator, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type Operation =
  | "add"
  | "subtract"
  | "multiply"
  | "divide"
  | "conjugate"
  | "magnitude"
  | "argument"
  | "polar"
  | "rectangular"

interface ComplexNumber {
  real: number
  imag: number
}

interface PolarForm {
  r: number
  theta: number // in radians
}

interface Result {
  rectangular: ComplexNumber
  polar: PolarForm
  steps: string[]
}

export function ComplexNumberCalculator() {
  const [z1Real, setZ1Real] = useState("")
  const [z1Imag, setZ1Imag] = useState("")
  const [z2Real, setZ2Real] = useState("")
  const [z2Imag, setZ2Imag] = useState("")
  const [polarR, setPolarR] = useState("")
  const [polarTheta, setPolarTheta] = useState("")
  const [operation, setOperation] = useState<Operation>("add")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const formatComplex = (z: ComplexNumber): string => {
    const { real, imag } = z
    if (imag === 0) return `${real}`
    if (real === 0) return imag === 1 ? "i" : imag === -1 ? "-i" : `${imag}i`
    const sign = imag >= 0 ? "+" : "-"
    const imagPart = Math.abs(imag) === 1 ? "i" : `${Math.abs(imag)}i`
    return `${real} ${sign} ${imagPart}`
  }

  const formatPolar = (p: PolarForm): string => {
    const thetaDeg = (p.theta * 180) / Math.PI
    return `${p.r.toFixed(4)}(cos(${thetaDeg.toFixed(2)}°) + i·sin(${thetaDeg.toFixed(2)}°))`
  }

  const formatExponential = (p: PolarForm): string => {
    const thetaDeg = (p.theta * 180) / Math.PI
    return `${p.r.toFixed(4)}·e^(i·${thetaDeg.toFixed(2)}°)`
  }

  const toPolar = (z: ComplexNumber): PolarForm => {
    const r = Math.sqrt(z.real * z.real + z.imag * z.imag)
    const theta = Math.atan2(z.imag, z.real)
    return { r, theta }
  }

  const toRectangular = (p: PolarForm): ComplexNumber => {
    return {
      real: p.r * Math.cos(p.theta),
      imag: p.r * Math.sin(p.theta),
    }
  }

  const needsSecondOperand = !["conjugate", "magnitude", "argument", "polar", "rectangular"].includes(operation)

  const calculate = () => {
    setError("")
    setResult(null)

    const steps: string[] = []

    if (operation === "rectangular") {
      // Convert from polar to rectangular
      const r = Number.parseFloat(polarR)
      const thetaDeg = Number.parseFloat(polarTheta)

      if (isNaN(r) || isNaN(thetaDeg)) {
        setError("Please enter valid polar coordinates (r and θ)")
        return
      }

      const theta = (thetaDeg * Math.PI) / 180
      const rectangular: ComplexNumber = {
        real: Math.round(r * Math.cos(theta) * 10000) / 10000,
        imag: Math.round(r * Math.sin(theta) * 10000) / 10000,
      }

      steps.push(`Given polar form: r = ${r}, θ = ${thetaDeg}°`)
      steps.push(`Convert θ to radians: θ = ${thetaDeg}° × (π/180) = ${theta.toFixed(4)} rad`)
      steps.push(`Real part: a = r × cos(θ) = ${r} × cos(${theta.toFixed(4)}) = ${rectangular.real}`)
      steps.push(`Imaginary part: b = r × sin(θ) = ${r} × sin(${theta.toFixed(4)}) = ${rectangular.imag}`)
      steps.push(`Result: z = ${formatComplex(rectangular)}`)

      setResult({
        rectangular,
        polar: { r, theta },
        steps,
      })
      return
    }

    // Parse z1
    const a = Number.parseFloat(z1Real) || 0
    const b = Number.parseFloat(z1Imag) || 0

    if (z1Real === "" && z1Imag === "") {
      setError("Please enter at least one component for z₁")
      return
    }

    const z1: ComplexNumber = { real: a, imag: b }
    steps.push(`z₁ = ${formatComplex(z1)}`)

    // Parse z2 if needed
    let z2: ComplexNumber = { real: 0, imag: 0 }
    if (needsSecondOperand) {
      const c = Number.parseFloat(z2Real) || 0
      const d = Number.parseFloat(z2Imag) || 0

      if (z2Real === "" && z2Imag === "") {
        setError("Please enter at least one component for z₂")
        return
      }

      z2 = { real: c, imag: d }
      steps.push(`z₂ = ${formatComplex(z2)}`)
    }

    let resultComplex: ComplexNumber = { real: 0, imag: 0 }

    switch (operation) {
      case "add":
        steps.push(`Addition: z₁ + z₂ = (a + c) + (b + d)i`)
        steps.push(`= (${a} + ${z2.real}) + (${b} + ${z2.imag})i`)
        resultComplex = {
          real: a + z2.real,
          imag: b + z2.imag,
        }
        steps.push(`= ${formatComplex(resultComplex)}`)
        break

      case "subtract":
        steps.push(`Subtraction: z₁ - z₂ = (a - c) + (b - d)i`)
        steps.push(`= (${a} - ${z2.real}) + (${b} - ${z2.imag})i`)
        resultComplex = {
          real: a - z2.real,
          imag: b - z2.imag,
        }
        steps.push(`= ${formatComplex(resultComplex)}`)
        break

      case "multiply":
        steps.push(`Multiplication: z₁ × z₂ = (ac - bd) + (ad + bc)i`)
        const ac = a * z2.real
        const bd = b * z2.imag
        const ad = a * z2.imag
        const bc = b * z2.real
        steps.push(`ac = ${a} × ${z2.real} = ${ac}`)
        steps.push(`bd = ${b} × ${z2.imag} = ${bd}`)
        steps.push(`ad = ${a} × ${z2.imag} = ${ad}`)
        steps.push(`bc = ${b} × ${z2.real} = ${bc}`)
        resultComplex = {
          real: ac - bd,
          imag: ad + bc,
        }
        steps.push(`= (${ac} - ${bd}) + (${ad} + ${bc})i`)
        steps.push(`= ${formatComplex(resultComplex)}`)
        break

      case "divide":
        if (z2.real === 0 && z2.imag === 0) {
          setError("Cannot divide by zero")
          return
        }
        steps.push(`Division: z₁ ÷ z₂ = [(ac + bd) + (bc - ad)i] / (c² + d²)`)
        const c2d2 = z2.real * z2.real + z2.imag * z2.imag
        steps.push(`Denominator: c² + d² = ${z2.real}² + ${z2.imag}² = ${c2d2}`)
        const acPbd = a * z2.real + b * z2.imag
        const bcMad = b * z2.real - a * z2.imag
        steps.push(`Numerator real: ac + bd = ${a}×${z2.real} + ${b}×${z2.imag} = ${acPbd}`)
        steps.push(`Numerator imag: bc - ad = ${b}×${z2.real} - ${a}×${z2.imag} = ${bcMad}`)
        resultComplex = {
          real: Math.round((acPbd / c2d2) * 10000) / 10000,
          imag: Math.round((bcMad / c2d2) * 10000) / 10000,
        }
        steps.push(`= ${formatComplex(resultComplex)}`)
        break

      case "conjugate":
        steps.push(`Conjugate: z̄ = a - bi`)
        steps.push(`= ${a} - (${b})i`)
        resultComplex = {
          real: a,
          imag: -b,
        }
        steps.push(`= ${formatComplex(resultComplex)}`)
        break

      case "magnitude":
        steps.push(`Magnitude: |z| = √(a² + b²)`)
        steps.push(`= √(${a}² + ${b}²)`)
        steps.push(`= √(${a * a} + ${b * b})`)
        const mag = Math.sqrt(a * a + b * b)
        steps.push(`= √${a * a + b * b}`)
        steps.push(`= ${mag.toFixed(6)}`)
        resultComplex = { real: Math.round(mag * 10000) / 10000, imag: 0 }
        break

      case "argument":
        steps.push(`Argument: θ = arctan(b/a)`)
        if (a === 0 && b === 0) {
          setError("Argument is undefined for z = 0")
          return
        }
        const theta = Math.atan2(b, a)
        const thetaDeg = (theta * 180) / Math.PI
        steps.push(`= arctan(${b}/${a})`)
        steps.push(`= ${theta.toFixed(6)} radians`)
        steps.push(`= ${thetaDeg.toFixed(4)}°`)
        resultComplex = { real: Math.round(thetaDeg * 10000) / 10000, imag: 0 }
        break

      case "polar":
        steps.push(`Convert to polar form: z = r(cos(θ) + i·sin(θ))`)
        const r = Math.sqrt(a * a + b * b)
        const thetaRad = Math.atan2(b, a)
        const thetaD = (thetaRad * 180) / Math.PI
        steps.push(`Magnitude: r = √(a² + b²) = √(${a}² + ${b}²) = ${r.toFixed(6)}`)
        steps.push(`Argument: θ = arctan(b/a) = arctan(${b}/${a}) = ${thetaD.toFixed(4)}°`)
        steps.push(`Polar form: ${r.toFixed(4)}(cos(${thetaD.toFixed(2)}°) + i·sin(${thetaD.toFixed(2)}°))`)
        steps.push(`Exponential form: ${r.toFixed(4)}·e^(i·${thetaD.toFixed(2)}°)`)
        resultComplex = z1
        setResult({
          rectangular: z1,
          polar: { r, theta: thetaRad },
          steps,
        })
        return
    }

    const polar = toPolar(resultComplex)
    setResult({
      rectangular: resultComplex,
      polar,
      steps,
    })
  }

  const handleReset = () => {
    setZ1Real("")
    setZ1Imag("")
    setZ2Real("")
    setZ2Imag("")
    setPolarR("")
    setPolarTheta("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        operation === "magnitude"
          ? `|z| = ${result.rectangular.real}`
          : operation === "argument"
            ? `θ = ${result.rectangular.real}°`
            : `${formatComplex(result.rectangular)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getOperationLabel = (op: Operation): string => {
    const labels: Record<Operation, string> = {
      add: "Addition (z₁ + z₂)",
      subtract: "Subtraction (z₁ − z₂)",
      multiply: "Multiplication (z₁ × z₂)",
      divide: "Division (z₁ ÷ z₂)",
      conjugate: "Conjugate (z̄₁)",
      magnitude: "Magnitude (|z₁|)",
      argument: "Argument (θ)",
      polar: "Polar Form",
      rectangular: "Rectangular Form",
    }
    return labels[op]
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Complex Number Calculator</CardTitle>
                    <CardDescription>Perform operations with complex numbers</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Operation Selection */}
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <Select value={operation} onValueChange={(v) => setOperation(v as Operation)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="add">Addition (z₁ + z₂)</SelectItem>
                      <SelectItem value="subtract">Subtraction (z₁ − z₂)</SelectItem>
                      <SelectItem value="multiply">Multiplication (z₁ × z₂)</SelectItem>
                      <SelectItem value="divide">Division (z₁ ÷ z₂)</SelectItem>
                      <SelectItem value="conjugate">Conjugate (z̄)</SelectItem>
                      <SelectItem value="magnitude">Magnitude (|z|)</SelectItem>
                      <SelectItem value="argument">Argument (θ)</SelectItem>
                      <SelectItem value="polar">To Polar Form</SelectItem>
                      <SelectItem value="rectangular">To Rectangular Form</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {operation === "rectangular" ? (
                  <>
                    {/* Polar Input */}
                    <div className="p-4 bg-muted/50 rounded-lg space-y-3">
                      <Label className="text-sm font-medium">Polar Coordinates</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label htmlFor="polarR" className="text-xs text-muted-foreground">
                            r (magnitude)
                          </Label>
                          <Input
                            id="polarR"
                            type="number"
                            placeholder="r"
                            value={polarR}
                            onChange={(e) => setPolarR(e.target.value)}
                            step="any"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="polarTheta" className="text-xs text-muted-foreground">
                            θ (degrees)
                          </Label>
                          <Input
                            id="polarTheta"
                            type="number"
                            placeholder="θ°"
                            value={polarTheta}
                            onChange={(e) => setPolarTheta(e.target.value)}
                            step="any"
                          />
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* z1 Input */}
                    <div className="p-4 bg-muted/50 rounded-lg space-y-3">
                      <Label className="text-sm font-medium">z₁ = a + bi</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label htmlFor="z1Real" className="text-xs text-muted-foreground">
                            a (real)
                          </Label>
                          <Input
                            id="z1Real"
                            type="number"
                            placeholder="Real part"
                            value={z1Real}
                            onChange={(e) => setZ1Real(e.target.value)}
                            step="any"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="z1Imag" className="text-xs text-muted-foreground">
                            b (imaginary)
                          </Label>
                          <Input
                            id="z1Imag"
                            type="number"
                            placeholder="Imaginary part"
                            value={z1Imag}
                            onChange={(e) => setZ1Imag(e.target.value)}
                            step="any"
                          />
                        </div>
                      </div>
                    </div>

                    {/* z2 Input */}
                    {needsSecondOperand && (
                      <div className="p-4 bg-muted/50 rounded-lg space-y-3">
                        <Label className="text-sm font-medium">z₂ = c + di</Label>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <Label htmlFor="z2Real" className="text-xs text-muted-foreground">
                              c (real)
                            </Label>
                            <Input
                              id="z2Real"
                              type="number"
                              placeholder="Real part"
                              value={z2Real}
                              onChange={(e) => setZ2Real(e.target.value)}
                              step="any"
                            />
                          </div>
                          <div className="space-y-1">
                            <Label htmlFor="z2Imag" className="text-xs text-muted-foreground">
                              d (imaginary)
                            </Label>
                            <Input
                              id="z2Imag"
                              type="number"
                              placeholder="Imaginary part"
                              value={z2Imag}
                              onChange={(e) => setZ2Imag(e.target.value)}
                              step="any"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* Step Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps" className="text-sm">
                    Show step-by-step solution
                  </Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{getOperationLabel(operation)}</p>
                      {operation === "magnitude" ? (
                        <p className="text-3xl font-bold text-blue-600 mb-2">|z| = {result.rectangular.real}</p>
                      ) : operation === "argument" ? (
                        <p className="text-3xl font-bold text-blue-600 mb-2">θ = {result.rectangular.real}°</p>
                      ) : operation === "polar" ? (
                        <div className="space-y-1">
                          <p className="text-xl font-bold text-blue-600">{formatPolar(result.polar)}</p>
                          <p className="text-lg text-blue-500">{formatExponential(result.polar)}</p>
                        </div>
                      ) : (
                        <>
                          <p className="text-3xl font-bold text-blue-600 mb-2">{formatComplex(result.rectangular)}</p>
                          <p className="text-sm text-muted-foreground">
                            Polar: r = {result.polar.r.toFixed(4)}, θ ={" "}
                            {((result.polar.theta * 180) / Math.PI).toFixed(2)}°
                          </p>
                        </>
                      )}
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>

                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-blue-200">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="flex items-center gap-2 text-sm font-medium text-blue-700 hover:text-blue-800"
                        >
                          {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          Step-by-Step Solution
                        </button>
                        {showDetails && (
                          <div className="mt-3 space-y-2 text-sm text-blue-800">
                            {result.steps.map((step, i) => (
                              <div key={i} className="flex gap-2">
                                <span className="font-mono text-blue-500">{i + 1}.</span>
                                <span className="font-mono">{step}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Operation Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold mb-1">Addition</p>
                    <p className="font-mono text-xs">(a+bi) + (c+di) = (a+c) + (b+d)i</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold mb-1">Multiplication</p>
                    <p className="font-mono text-xs">(a+bi)(c+di) = (ac−bd) + (ad+bc)i</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold mb-1">Division</p>
                    <p className="font-mono text-xs">(a+bi)/(c+di) = [(ac+bd)+(bc−ad)i]/(c²+d²)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold mb-1">Magnitude</p>
                    <p className="font-mono text-xs">|z| = √(a² + b²)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Polar Form</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">z = r(cos θ + i sin θ)</p>
                    <p className="text-xs mt-1">or z = r·e^(iθ)</p>
                  </div>
                  <p>
                    <strong>r</strong> = magnitude = √(a² + b²)
                  </p>
                  <p>
                    <strong>θ</strong> = argument = arctan(b/a)
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>i² =</span>
                      <span className="font-mono">−1</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>|3 + 4i| =</span>
                      <span className="font-mono">5</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>(1+i)(1−i) =</span>
                      <span className="font-mono">2</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>conjugate(3+2i) =</span>
                      <span className="font-mono">3 − 2i</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Complex Numbers?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Complex numbers are numbers that extend the real number system by including an imaginary unit, denoted
                  as "i", which is defined by the property i² = −1. A complex number is written in the form z = a + bi,
                  where "a" is the real part and "b" is the imaginary part. Complex numbers are essential in many areas
                  of mathematics, physics, and engineering.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The complex plane (also called the Argand diagram) is a geometric representation where the real part
                  is plotted on the horizontal axis and the imaginary part on the vertical axis. This visualization
                  helps understand operations like addition (vector addition) and multiplication (rotation and scaling).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Complex Numbers</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Complex numbers have wide-ranging applications across science and engineering. In electrical
                  engineering, they represent alternating current (AC) circuits where the real part represents
                  resistance and the imaginary part represents reactance. In signal processing, the Fourier transform
                  uses complex exponentials to analyze frequency components.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In quantum mechanics, complex numbers are fundamental to wave functions. In control systems, they help
                  analyze stability. Even in fractal geometry, the famous Mandelbrot set is defined using complex number
                  iterations. Understanding complex arithmetic is essential for advanced mathematics and physics.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <Card className="mt-8 bg-amber-50 border-amber-200">
            <CardContent className="pt-6">
              <p className="text-sm text-amber-800">
                <strong>Note:</strong> Complex number calculations follow standard mathematical formulas. Results depend
                on correct input and selected operation. Angles are displayed in degrees for readability.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
