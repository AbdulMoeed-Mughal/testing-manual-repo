"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Circle, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type VelocityType = "linear" | "angular"
type MassUnit = "kg" | "g" | "lb"
type RadiusUnit = "m" | "cm" | "ft" | "in"
type ForceUnit = "N" | "kN" | "lbf"

interface CentripetalResult {
  force: number
  forceFormatted: string
  category: string
  color: string
  bgColor: string
  linearVelocity: number
  angularVelocity: number
  acceleration: number
}

export function CentripetalForceCalculator() {
  const [velocityType, setVelocityType] = useState<VelocityType>("linear")
  const [mass, setMass] = useState("")
  const [radius, setRadius] = useState("")
  const [velocity, setVelocity] = useState("")
  const [massUnit, setMassUnit] = useState<MassUnit>("kg")
  const [radiusUnit, setRadiusUnit] = useState<RadiusUnit>("m")
  const [forceUnit, setForceUnit] = useState<ForceUnit>("N")
  const [result, setResult] = useState<CentripetalResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Unit conversion functions
  const convertMassToKg = (value: number, unit: MassUnit): number => {
    switch (unit) {
      case "g":
        return value / 1000
      case "lb":
        return value * 0.453592
      default:
        return value
    }
  }

  const convertRadiusToM = (value: number, unit: RadiusUnit): number => {
    switch (unit) {
      case "cm":
        return value / 100
      case "ft":
        return value * 0.3048
      case "in":
        return value * 0.0254
      default:
        return value
    }
  }

  const convertForceFromN = (value: number, unit: ForceUnit): number => {
    switch (unit) {
      case "kN":
        return value / 1000
      case "lbf":
        return value * 0.224809
      default:
        return value
    }
  }

  const calculateCentripetalForce = () => {
    setError("")
    setResult(null)

    const massNum = Number.parseFloat(mass)
    const radiusNum = Number.parseFloat(radius)
    const velocityNum = Number.parseFloat(velocity)

    if (isNaN(massNum) || massNum <= 0) {
      setError("Please enter a valid mass greater than 0")
      return
    }

    if (isNaN(radiusNum) || radiusNum <= 0) {
      setError("Please enter a valid radius greater than 0")
      return
    }

    if (isNaN(velocityNum) || velocityNum <= 0) {
      setError(`Please enter a valid ${velocityType === "linear" ? "velocity" : "angular velocity"} greater than 0`)
      return
    }

    // Convert to SI units
    const massKg = convertMassToKg(massNum, massUnit)
    const radiusM = convertRadiusToM(radiusNum, radiusUnit)

    let forceN: number
    let linearV: number
    let angularV: number

    if (velocityType === "linear") {
      // F_c = m × v² / r
      linearV = velocityNum
      angularV = velocityNum / radiusM // ω = v / r
      forceN = (massKg * velocityNum * velocityNum) / radiusM
    } else {
      // F_c = m × r × ω²
      angularV = velocityNum
      linearV = velocityNum * radiusM // v = ω × r
      forceN = massKg * radiusM * velocityNum * velocityNum
    }

    const acceleration = forceN / massKg // a_c = F_c / m

    // Convert force to selected unit
    const forceConverted = convertForceFromN(forceN, forceUnit)

    // Categorize force magnitude
    let category: string
    let color: string
    let bgColor: string

    if (forceN < 10) {
      category = "Very Low"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (forceN < 100) {
      category = "Low"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (forceN < 1000) {
      category = "Moderate"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (forceN < 10000) {
      category = "High"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Very High"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    const forceFormatted =
      forceConverted < 0.01 ? forceConverted.toExponential(3) : forceConverted.toFixed(forceConverted < 1 ? 4 : 2)

    setResult({
      force: forceConverted,
      forceFormatted,
      category,
      color,
      bgColor,
      linearVelocity: linearV,
      angularVelocity: angularV,
      acceleration,
    })
  }

  const handleReset = () => {
    setMass("")
    setRadius("")
    setVelocity("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Centripetal Force: ${result.forceFormatted} ${forceUnit} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Centripetal Force Result",
          text: `I calculated centripetal force using CalcHub! Force = ${result.forceFormatted} ${forceUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleVelocityType = () => {
    setVelocityType((prev) => (prev === "linear" ? "angular" : "linear"))
    setVelocity("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Circle className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Centripetal Force Calculator</CardTitle>
                    <CardDescription>Calculate force in circular motion</CardDescription>
                  </div>
                </div>

                {/* Velocity Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Velocity Input</span>
                  <button
                    onClick={toggleVelocityType}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        velocityType === "angular" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        velocityType === "linear" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Linear
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        velocityType === "angular" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Angular
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Mass Input */}
                <div className="space-y-2">
                  <Label htmlFor="mass">Mass (m)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="mass"
                      type="number"
                      placeholder="Enter mass"
                      value={mass}
                      onChange={(e) => setMass(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <select
                      value={massUnit}
                      onChange={(e) => setMassUnit(e.target.value as MassUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="kg">kg</option>
                      <option value="g">g</option>
                      <option value="lb">lb</option>
                    </select>
                  </div>
                </div>

                {/* Radius Input */}
                <div className="space-y-2">
                  <Label htmlFor="radius">Radius (r)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="radius"
                      type="number"
                      placeholder="Enter radius"
                      value={radius}
                      onChange={(e) => setRadius(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <select
                      value={radiusUnit}
                      onChange={(e) => setRadiusUnit(e.target.value as RadiusUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="m">m</option>
                      <option value="cm">cm</option>
                      <option value="ft">ft</option>
                      <option value="in">in</option>
                    </select>
                  </div>
                </div>

                {/* Velocity Input */}
                <div className="space-y-2">
                  <Label htmlFor="velocity">
                    {velocityType === "linear" ? "Tangential Velocity (v)" : "Angular Velocity (ω)"}
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="velocity"
                      type="number"
                      placeholder={
                        velocityType === "linear" ? "Enter velocity in m/s" : "Enter angular velocity in rad/s"
                      }
                      value={velocity}
                      onChange={(e) => setVelocity(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <div className="w-20 rounded-md border border-input bg-muted px-3 py-2 text-sm text-center">
                      {velocityType === "linear" ? "m/s" : "rad/s"}
                    </div>
                  </div>
                </div>

                {/* Force Unit Selection */}
                <div className="space-y-2">
                  <Label>Force Output Unit</Label>
                  <div className="flex gap-2">
                    {(["N", "kN", "lbf"] as ForceUnit[]).map((unit) => (
                      <button
                        key={unit}
                        onClick={() => setForceUnit(unit)}
                        className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                          forceUnit === unit ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        {unit}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCentripetalForce} className="w-full" size="lg">
                  Calculate Centripetal Force
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Centripetal Force</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.forceFormatted} <span className="text-2xl">{forceUnit}</span>
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Linear Velocity</p>
                        <p className="font-semibold">{result.linearVelocity.toFixed(2)} m/s</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Angular Velocity</p>
                        <p className="font-semibold">{result.angularVelocity.toFixed(3)} rad/s</p>
                      </div>
                      <div className="col-span-2 p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Centripetal Acceleration</p>
                        <p className="font-semibold">{result.acceleration.toFixed(2)} m/s²</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>

                    {/* Step-by-step toggle */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/70 rounded-lg text-sm space-y-2">
                        <p className="font-semibold">Step-by-Step Calculation:</p>
                        <p>
                          1. Mass (m) = {mass} {massUnit} = {convertMassToKg(Number(mass), massUnit).toFixed(4)} kg
                        </p>
                        <p>
                          2. Radius (r) = {radius} {radiusUnit} ={" "}
                          {convertRadiusToM(Number(radius), radiusUnit).toFixed(4)} m
                        </p>
                        {velocityType === "linear" ? (
                          <>
                            <p>3. Velocity (v) = {velocity} m/s</p>
                            <p>4. Using F_c = m × v² / r</p>
                            <p>
                              5. F_c = {convertMassToKg(Number(mass), massUnit).toFixed(4)} × {velocity}² /{" "}
                              {convertRadiusToM(Number(radius), radiusUnit).toFixed(4)}
                            </p>
                          </>
                        ) : (
                          <>
                            <p>3. Angular Velocity (ω) = {velocity} rad/s</p>
                            <p>4. Using F_c = m × r × ω²</p>
                            <p>
                              5. F_c = {convertMassToKg(Number(mass), massUnit).toFixed(4)} ×{" "}
                              {convertRadiusToM(Number(radius), radiusUnit).toFixed(4)} × {velocity}²
                            </p>
                          </>
                        )}
                        <p className="font-semibold">
                          6. F_c = {result.forceFormatted} {forceUnit}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Centripetal Force Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <p className="font-mono text-center font-semibold text-purple-800">F_c = m × v² / r</p>
                      <p className="text-sm text-purple-600 text-center mt-1">Using linear velocity</p>
                    </div>
                    <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                      <p className="font-mono text-center font-semibold text-indigo-800">F_c = m × r × ω²</p>
                      <p className="text-sm text-indigo-600 text-center mt-1">Using angular velocity</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Variables</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span className="font-medium">F_c</span>
                    <span className="text-muted-foreground">Centripetal force (N)</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span className="font-medium">m</span>
                    <span className="text-muted-foreground">Mass (kg)</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span className="font-medium">v</span>
                    <span className="text-muted-foreground">Linear velocity (m/s)</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span className="font-medium">r</span>
                    <span className="text-muted-foreground">Radius (m)</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span className="font-medium">ω</span>
                    <span className="text-muted-foreground">Angular velocity (rad/s)</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-medium">Car on curved road</p>
                      <p className="text-muted-foreground">1000 kg car, 50 m radius, 20 m/s → 8000 N</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-medium">Spinning ball on string</p>
                      <p className="text-muted-foreground">0.5 kg ball, 1 m string, 5 m/s → 12.5 N</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-medium">Satellite orbit</p>
                      <p className="text-muted-foreground">Provides gravitational centripetal force</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Centripetal Force?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Centripetal force is the force that acts on an object moving in a circular path, directed toward the
                  center of the circle around which the object is moving. The word "centripetal" comes from Latin,
                  meaning "center-seeking." This force is essential for any object to maintain circular motion rather
                  than moving in a straight line according to Newton's first law of motion.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  It's important to note that centripetal force is not a fundamental force like gravity or
                  electromagnetism. Rather, it describes the net force required to keep an object moving in a circle.
                  This force can be provided by various sources such as tension in a string, friction between tires and
                  road, gravitational attraction, or electromagnetic forces, depending on the physical situation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Formulas</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The centripetal force formula F_c = mv²/r shows that the force depends on three factors: the mass of
                  the object, its velocity, and the radius of the circular path. Notice that velocity is squared, which
                  means doubling the speed quadruples the required force. This is why high-speed turns require much more
                  force than slow turns, and why race tracks have banked curves.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The alternative formula F_c = mrω² uses angular velocity (ω) instead of linear velocity. Angular
                  velocity measures how fast an object rotates in radians per second. The relationship between linear
                  and angular velocity is v = ωr, which is why both formulas give identical results when properly
                  applied. Using angular velocity is often more convenient for rotating systems like wheels, gears, and
                  planetary motion.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Centripetal force calculations are estimates based on ideal circular motion. Actual force may vary due
                  to friction, gravity, air resistance, or other external forces. This calculator assumes uniform
                  circular motion with constant speed and does not account for real-world factors such as changing
                  velocity, non-circular paths, or energy losses. For engineering applications, consult with qualified
                  professionals and use appropriate safety factors.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
