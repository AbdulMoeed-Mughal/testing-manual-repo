"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Sun, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface SolarResult {
  dailyOutput: number
  monthlyOutput: number
  yearlyOutput: number
  outputPerPanel: number
  effectivePower: number
  unit: string
}

export function SolarPanelOutputCalculator() {
  const [panelPower, setPanelPower] = useState("")
  const [numPanels, setNumPanels] = useState("")
  const [sunlightHours, setSunlightHours] = useState("")
  const [efficiency, setEfficiency] = useState("85")
  const [useTemperatureDerating, setUseTemperatureDerating] = useState(false)
  const [temperatureDerating, setTemperatureDerating] = useState("90")
  const [outputUnit, setOutputUnit] = useState<"Wh" | "kWh">("kWh")
  const [result, setResult] = useState<SolarResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateOutput = () => {
    setError("")
    setResult(null)

    const power = Number.parseFloat(panelPower)
    const panels = Number.parseInt(numPanels)
    const hours = Number.parseFloat(sunlightHours)
    const eff = Number.parseFloat(efficiency)

    if (isNaN(power) || power <= 0) {
      setError("Please enter a valid panel power greater than 0")
      return
    }
    if (isNaN(panels) || panels <= 0) {
      setError("Please enter a valid number of panels greater than 0")
      return
    }
    if (isNaN(hours) || hours <= 0 || hours > 24) {
      setError("Please enter valid sunlight hours (1-24)")
      return
    }
    if (isNaN(eff) || eff <= 0 || eff > 100) {
      setError("Efficiency must be between 1% and 100%")
      return
    }

    let tempDerating = 100
    if (useTemperatureDerating) {
      tempDerating = Number.parseFloat(temperatureDerating)
      if (isNaN(tempDerating) || tempDerating <= 0 || tempDerating > 100) {
        setError("Temperature derating factor must be between 1% and 100%")
        return
      }
    }

    // Calculate daily energy output in Wh
    const effectiveEfficiency = (eff / 100) * (tempDerating / 100)
    const dailyWh = panels * power * hours * effectiveEfficiency
    const monthlyWh = dailyWh * 30
    const yearlyWh = dailyWh * 365
    const perPanelWh = power * hours * effectiveEfficiency
    const effectivePowerW = power * panels * effectiveEfficiency

    // Convert based on selected unit
    const divisor = outputUnit === "kWh" ? 1000 : 1

    setResult({
      dailyOutput: dailyWh / divisor,
      monthlyOutput: monthlyWh / divisor,
      yearlyOutput: yearlyWh / divisor,
      outputPerPanel: perPanelWh / divisor,
      effectivePower: effectivePowerW,
      unit: outputUnit,
    })
  }

  const handleReset = () => {
    setPanelPower("")
    setNumPanels("")
    setSunlightHours("")
    setEfficiency("85")
    setTemperatureDerating("90")
    setUseTemperatureDerating(false)
    setOutputUnit("kWh")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Solar Panel Output:\nDaily: ${result.dailyOutput.toFixed(2)} ${result.unit}\nMonthly: ${result.monthlyOutput.toFixed(2)} ${result.unit}\nYearly: ${result.yearlyOutput.toFixed(2)} ${result.unit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Solar Panel Output Calculator",
          text: `My solar system output: Daily ${result.dailyOutput.toFixed(2)} ${result.unit}, Monthly ${result.monthlyOutput.toFixed(2)} ${result.unit}, Yearly ${result.yearlyOutput.toFixed(2)} ${result.unit}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return num.toLocaleString(undefined, { maximumFractionDigits: 2 })
    }
    return num.toFixed(2)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Sun className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Solar Panel Output Calculator</CardTitle>
                    <CardDescription>Estimate solar energy generation</CardDescription>
                  </div>
                </div>

                {/* Output Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Output Unit</span>
                  <button
                    onClick={() => setOutputUnit(outputUnit === "Wh" ? "kWh" : "Wh")}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        outputUnit === "kWh" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        outputUnit === "Wh" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Wh
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        outputUnit === "kWh" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      kWh
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Panel Power Input */}
                <div className="space-y-2">
                  <Label htmlFor="panelPower">Panel Rated Power (W)</Label>
                  <Input
                    id="panelPower"
                    type="number"
                    placeholder="e.g., 400"
                    value={panelPower}
                    onChange={(e) => setPanelPower(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Number of Panels Input */}
                <div className="space-y-2">
                  <Label htmlFor="numPanels">Number of Panels</Label>
                  <Input
                    id="numPanels"
                    type="number"
                    placeholder="e.g., 10"
                    value={numPanels}
                    onChange={(e) => setNumPanels(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Sunlight Hours Input */}
                <div className="space-y-2">
                  <Label htmlFor="sunlightHours">Average Sunlight Hours per Day</Label>
                  <Input
                    id="sunlightHours"
                    type="number"
                    placeholder="e.g., 5"
                    value={sunlightHours}
                    onChange={(e) => setSunlightHours(e.target.value)}
                    min="0"
                    max="24"
                    step="0.1"
                  />
                </div>

                {/* System Efficiency Input */}
                <div className="space-y-2">
                  <Label htmlFor="efficiency">System Efficiency (%)</Label>
                  <Input
                    id="efficiency"
                    type="number"
                    placeholder="e.g., 85"
                    value={efficiency}
                    onChange={(e) => setEfficiency(e.target.value)}
                    min="1"
                    max="100"
                    step="1"
                  />
                </div>

                {/* Temperature Derating Toggle */}
                <div className="flex items-center justify-between py-2">
                  <Label htmlFor="tempDerating" className="cursor-pointer">
                    Include Temperature Derating
                  </Label>
                  <Switch
                    id="tempDerating"
                    checked={useTemperatureDerating}
                    onCheckedChange={setUseTemperatureDerating}
                  />
                </div>

                {/* Temperature Derating Input */}
                {useTemperatureDerating && (
                  <div className="space-y-2">
                    <Label htmlFor="temperatureDerating">Temperature Derating Factor (%)</Label>
                    <Input
                      id="temperatureDerating"
                      type="number"
                      placeholder="e.g., 90"
                      value={temperatureDerating}
                      onChange={(e) => setTemperatureDerating(e.target.value)}
                      min="1"
                      max="100"
                      step="1"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateOutput} className="w-full" size="lg">
                  Calculate Output
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Daily Energy Output</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">
                        {formatNumber(result.dailyOutput)} {result.unit}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border border-amber-200 text-center">
                        <p className="text-xs text-muted-foreground">Monthly</p>
                        <p className="text-lg font-semibold text-amber-700">
                          {formatNumber(result.monthlyOutput)} {result.unit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border border-amber-200 text-center">
                        <p className="text-xs text-muted-foreground">Yearly</p>
                        <p className="text-lg font-semibold text-amber-700">
                          {formatNumber(result.yearlyOutput)} {result.unit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border border-amber-200 text-center">
                        <p className="text-xs text-muted-foreground">Per Panel (Daily)</p>
                        <p className="text-lg font-semibold text-amber-700">
                          {formatNumber(result.outputPerPanel)} {result.unit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border border-amber-200 text-center">
                        <p className="text-xs text-muted-foreground">Effective Power</p>
                        <p className="text-lg font-semibold text-amber-700">{formatNumber(result.effectivePower)} W</p>
                      </div>
                    </div>

                    {/* Step-by-step Solution Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-between w-full p-2 text-sm text-amber-700 hover:bg-amber-100 rounded-lg transition-colors"
                    >
                      <span className="font-medium">Step-by-step Calculation</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-2 p-3 bg-white rounded-lg border border-amber-200 text-sm space-y-2">
                        <p className="font-medium text-amber-800">Formula:</p>
                        <p className="font-mono text-xs bg-amber-50 p-2 rounded">
                          Daily Output = Panels × Power × Hours × Efficiency
                          {useTemperatureDerating ? " × Temp Factor" : ""}
                        </p>
                        <div className="space-y-1 text-muted-foreground">
                          <p>1. Number of panels: {numPanels}</p>
                          <p>2. Panel rated power: {panelPower} W</p>
                          <p>3. Sunlight hours: {sunlightHours} hrs/day</p>
                          <p>
                            4. System efficiency: {efficiency}% = {(Number.parseFloat(efficiency) / 100).toFixed(2)}
                          </p>
                          {useTemperatureDerating && (
                            <p>
                              5. Temperature derating: {temperatureDerating}% ={" "}
                              {(Number.parseFloat(temperatureDerating) / 100).toFixed(2)}
                            </p>
                          )}
                          <p className="pt-2 font-medium text-foreground">
                            Daily = {numPanels} × {panelPower} × {sunlightHours} ×{" "}
                            {(Number.parseFloat(efficiency) / 100).toFixed(2)}
                            {useTemperatureDerating
                              ? ` × ${(Number.parseFloat(temperatureDerating) / 100).toFixed(2)}`
                              : ""}{" "}
                            = {formatNumber(result.dailyOutput * (outputUnit === "kWh" ? 1000 : 1))} Wh
                          </p>
                          {outputUnit === "kWh" && (
                            <p className="font-medium text-foreground">= {formatNumber(result.dailyOutput)} kWh</p>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Daily Output = N × P × H × η</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>N</strong> = Number of panels
                    </p>
                    <p>
                      <strong>P</strong> = Panel rated power (W)
                    </p>
                    <p>
                      <strong>H</strong> = Sunlight hours per day
                    </p>
                    <p>
                      <strong>η</strong> = System efficiency (decimal)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Sunlight Hours</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-amber-50 rounded border border-amber-200">
                      <span>Arizona, USA</span>
                      <span className="font-medium">6-7 hrs</span>
                    </div>
                    <div className="flex justify-between p-2 bg-amber-50 rounded border border-amber-200">
                      <span>California, USA</span>
                      <span className="font-medium">5-6 hrs</span>
                    </div>
                    <div className="flex justify-between p-2 bg-amber-50 rounded border border-amber-200">
                      <span>Germany</span>
                      <span className="font-medium">3-4 hrs</span>
                    </div>
                    <div className="flex justify-between p-2 bg-amber-50 rounded border border-amber-200">
                      <span>Australia</span>
                      <span className="font-medium">5-6 hrs</span>
                    </div>
                    <div className="flex justify-between p-2 bg-amber-50 rounded border border-amber-200">
                      <span>Middle East</span>
                      <span className="font-medium">6-8 hrs</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Efficiency Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>System Efficiency (80-90%):</strong> Accounts for inverter losses, wiring losses, and panel
                    degradation.
                  </p>
                  <p>
                    <strong>Temperature Derating (85-95%):</strong> Solar panels lose efficiency in high temperatures,
                    typically 0.3-0.5% per °C above 25°C.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Solar Panel Output</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Solar panel output depends on several factors including panel wattage, the number of panels installed,
                  available sunlight hours (also known as peak sun hours), and system efficiency. The rated power of a
                  solar panel (measured in watts) represents its output under ideal laboratory conditions (Standard Test
                  Conditions or STC). Real-world output is typically 15-25% lower due to various losses.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Peak sun hours refer to the number of hours per day when solar irradiance averages 1,000 W/m². This
                  varies significantly by location, season, and weather conditions. Areas closer to the equator
                  generally receive more peak sun hours than those at higher latitudes.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Solar panel output calculations are estimates. Actual energy generation
                  may vary due to weather, shading, temperature, panel orientation, and system conditions. Consult
                  manufacturer specifications and local solar installers for precise performance projections.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
