"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  Calculator,
  Scale,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, currencySymbols, formatCurrency } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

type CompoundFrequency = "annually" | "semi-annually" | "quarterly" | "monthly"

interface OptionResult {
  name: string
  initialValue: number
  returnRate: number
  futureValue: number
  totalGain: number
  gainPercentage: number
}

interface OpportunityCostResult {
  optionA: OptionResult
  optionB: OptionResult
  opportunityCost: number
  betterOption: "A" | "B"
  yearlyBreakdown: {
    year: number
    valueA: number
    valueB: number
    difference: number
  }[]
}

const frequencyMultipliers: Record<CompoundFrequency, number> = {
  annually: 1,
  "semi-annually": 2,
  quarterly: 4,
  monthly: 12,
}

export function OpportunityCostCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [optionAName, setOptionAName] = useState("Option A")
  const [optionBName, setOptionBName] = useState("Option B")
  const [optionAValue, setOptionAValue] = useState("")
  const [optionBValue, setOptionBValue] = useState("")
  const [optionAReturn, setOptionAReturn] = useState("")
  const [optionBReturn, setOptionBReturn] = useState("")
  const [timePeriod, setTimePeriod] = useState("")
  const [periodType, setPeriodType] = useState<"years" | "months">("years")
  const [compoundFrequency, setCompoundFrequency] = useState<CompoundFrequency>("annually")
  const [optionACosts, setOptionACosts] = useState("")
  const [optionBCosts, setOptionBCosts] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<OpportunityCostResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateOpportunityCost = () => {
    setError("")
    setResult(null)

    const valueA = Number.parseFloat(optionAValue)
    const valueB = Number.parseFloat(optionBValue)
    const returnA = Number.parseFloat(optionAReturn)
    const returnB = Number.parseFloat(optionBReturn)
    const period = Number.parseFloat(timePeriod)
    const costsA = Number.parseFloat(optionACosts) || 0
    const costsB = Number.parseFloat(optionBCosts) || 0

    if (isNaN(valueA) || valueA <= 0) {
      setError("Please enter a valid value for Option A greater than 0")
      return
    }
    if (isNaN(valueB) || valueB <= 0) {
      setError("Please enter a valid value for Option B greater than 0")
      return
    }
    if (isNaN(returnA) || returnA < 0 || returnA > 100) {
      setError("Please enter a valid return rate for Option A (0-100%)")
      return
    }
    if (isNaN(returnB) || returnB < 0 || returnB > 100) {
      setError("Please enter a valid return rate for Option B (0-100%)")
      return
    }
    if (isNaN(period) || period <= 0) {
      setError("Please enter a valid time period greater than 0")
      return
    }

    // Convert period to years if needed
    const periodInYears = periodType === "months" ? period / 12 : period
    const n = frequencyMultipliers[compoundFrequency]

    // Calculate future values using compound interest formula: FV = PV * (1 + r/n)^(n*t)
    const netValueA = valueA - costsA
    const netValueB = valueB - costsB

    const futureValueA = netValueA * Math.pow(1 + returnA / 100 / n, n * periodInYears)
    const futureValueB = netValueB * Math.pow(1 + returnB / 100 / n, n * periodInYears)

    const totalGainA = futureValueA - netValueA
    const totalGainB = futureValueB - netValueB

    const gainPercentageA = ((futureValueA - netValueA) / netValueA) * 100
    const gainPercentageB = ((futureValueB - netValueB) / netValueB) * 100

    // Opportunity cost is the difference between the better and chosen option
    const opportunityCost = Math.abs(futureValueA - futureValueB)
    const betterOption = futureValueA >= futureValueB ? "A" : "B"

    // Calculate yearly breakdown
    const yearlyBreakdown = []
    const yearsToShow = Math.min(Math.ceil(periodInYears), 30)
    for (let year = 1; year <= yearsToShow; year++) {
      const valueAtYearA = netValueA * Math.pow(1 + returnA / 100 / n, n * year)
      const valueAtYearB = netValueB * Math.pow(1 + returnB / 100 / n, n * year)
      yearlyBreakdown.push({
        year,
        valueA: valueAtYearA,
        valueB: valueAtYearB,
        difference: Math.abs(valueAtYearA - valueAtYearB),
      })
    }

    setResult({
      optionA: {
        name: optionAName || "Option A",
        initialValue: netValueA,
        returnRate: returnA,
        futureValue: futureValueA,
        totalGain: totalGainA,
        gainPercentage: gainPercentageA,
      },
      optionB: {
        name: optionBName || "Option B",
        initialValue: netValueB,
        returnRate: returnB,
        futureValue: futureValueB,
        totalGain: totalGainB,
        gainPercentage: gainPercentageB,
      },
      opportunityCost,
      betterOption,
      yearlyBreakdown,
    })
  }

  const handleReset = () => {
    setOptionAName("Option A")
    setOptionBName("Option B")
    setOptionAValue("")
    setOptionBValue("")
    setOptionAReturn("")
    setOptionBReturn("")
    setTimePeriod("")
    setPeriodType("years")
    setCompoundFrequency("annually")
    setOptionACosts("")
    setOptionBCosts("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Opportunity Cost Analysis:
${result.optionA.name}: ${formatCurrency(result.optionA.futureValue, currency)}
${result.optionB.name}: ${formatCurrency(result.optionB.futureValue, currency)}
Opportunity Cost: ${formatCurrency(result.opportunityCost, currency)}
Better Option: ${result.betterOption === "A" ? result.optionA.name : result.optionB.name}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Opportunity Cost Analysis",
          text: `I compared two investment options! Opportunity cost: ${formatCurrency(result.opportunityCost, currency)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Opportunity Cost Calculator</CardTitle>
                    <CardDescription>Compare two options and quantify the opportunity cost</CardDescription>
                  </div>
                </div>
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Option A */}
                <div className="p-4 bg-blue-50 rounded-lg space-y-3">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-6 w-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-bold">
                      A
                    </div>
                    <Input
                      placeholder="Option A Name"
                      value={optionAName}
                      onChange={(e) => setOptionAName(e.target.value)}
                      className="bg-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs">Value ({symbol})</Label>
                      <Input
                        type="number"
                        placeholder="10000"
                        value={optionAValue}
                        onChange={(e) => setOptionAValue(e.target.value)}
                        min="0"
                        step="100"
                        className="bg-white"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Return Rate (%)</Label>
                      <Input
                        type="number"
                        placeholder="7"
                        value={optionAReturn}
                        onChange={(e) => setOptionAReturn(e.target.value)}
                        min="0"
                        max="100"
                        step="0.1"
                        className="bg-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Option B */}
                <div className="p-4 bg-purple-50 rounded-lg space-y-3">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-6 w-6 rounded-full bg-purple-500 text-white flex items-center justify-center text-sm font-bold">
                      B
                    </div>
                    <Input
                      placeholder="Option B Name"
                      value={optionBName}
                      onChange={(e) => setOptionBName(e.target.value)}
                      className="bg-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs">Value ({symbol})</Label>
                      <Input
                        type="number"
                        placeholder="10000"
                        value={optionBValue}
                        onChange={(e) => setOptionBValue(e.target.value)}
                        min="0"
                        step="100"
                        className="bg-white"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Return Rate (%)</Label>
                      <Input
                        type="number"
                        placeholder="5"
                        value={optionBReturn}
                        onChange={(e) => setOptionBReturn(e.target.value)}
                        min="0"
                        max="100"
                        step="0.1"
                        className="bg-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Time Period */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="timePeriod">Time Period</Label>
                    <Input
                      id="timePeriod"
                      type="number"
                      placeholder="10"
                      value={timePeriod}
                      onChange={(e) => setTimePeriod(e.target.value)}
                      min="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="periodType">Period Type</Label>
                    <Select value={periodType} onValueChange={(value: "years" | "months") => setPeriodType(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="years">Years</SelectItem>
                        <SelectItem value="months">Months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between">
                      Advanced Options
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-3 pt-2">
                    <div className="space-y-2">
                      <Label>Compounding Frequency</Label>
                      <Select
                        value={compoundFrequency}
                        onValueChange={(value: CompoundFrequency) => setCompoundFrequency(value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="annually">Annually</SelectItem>
                          <SelectItem value="semi-annually">Semi-Annually</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Option A Costs ({symbol})</Label>
                        <Input
                          type="number"
                          placeholder="0"
                          value={optionACosts}
                          onChange={(e) => setOptionACosts(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Option B Costs ({symbol})</Label>
                        <Input
                          type="number"
                          placeholder="0"
                          value={optionBCosts}
                          onChange={(e) => setOptionBCosts(e.target.value)}
                          min="0"
                        />
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateOpportunityCost} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Opportunity Cost
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    {/* Opportunity Cost Result */}
                    <div
                      className={`p-4 rounded-xl border-2 ${result.betterOption === "A" ? "bg-blue-50 border-blue-200" : "bg-purple-50 border-purple-200"} transition-all duration-300`}
                    >
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Opportunity Cost</p>
                        <p className="text-4xl font-bold text-foreground mb-2">
                          {formatCurrency(result.opportunityCost, currency)}
                        </p>
                        <p className="text-sm font-medium text-green-600">
                          Better Option: {result.betterOption === "A" ? result.optionA.name : result.optionB.name}
                        </p>
                      </div>
                    </div>

                    {/* Comparison Cards */}
                    <div className="grid grid-cols-2 gap-3">
                      <div
                        className={`p-3 rounded-lg ${result.betterOption === "A" ? "bg-blue-100 border-2 border-blue-400" : "bg-blue-50"}`}
                      >
                        <p className="text-xs text-muted-foreground mb-1">{result.optionA.name}</p>
                        <p className="text-lg font-bold">{formatCurrency(result.optionA.futureValue, currency)}</p>
                        <p className="text-xs text-green-600">+{result.optionA.gainPercentage.toFixed(1)}%</p>
                      </div>
                      <div
                        className={`p-3 rounded-lg ${result.betterOption === "B" ? "bg-purple-100 border-2 border-purple-400" : "bg-purple-50"}`}
                      >
                        <p className="text-xs text-muted-foreground mb-1">{result.optionB.name}</p>
                        <p className="text-lg font-bold">{formatCurrency(result.optionB.futureValue, currency)}</p>
                        <p className="text-xs text-green-600">+{result.optionB.gainPercentage.toFixed(1)}%</p>
                      </div>
                    </div>

                    {/* Visual Comparison Bar */}
                    <div className="space-y-2">
                      <p className="text-sm font-medium">Value Comparison</p>
                      <div className="h-8 bg-muted rounded-lg overflow-hidden flex">
                        <div
                          className="bg-blue-500 flex items-center justify-center text-xs text-white font-medium"
                          style={{
                            width: `${(result.optionA.futureValue / (result.optionA.futureValue + result.optionB.futureValue)) * 100}%`,
                          }}
                        >
                          {result.optionA.name}
                        </div>
                        <div
                          className="bg-purple-500 flex items-center justify-center text-xs text-white font-medium"
                          style={{
                            width: `${(result.optionB.futureValue / (result.optionA.futureValue + result.optionB.futureValue)) * 100}%`,
                          }}
                        >
                          {result.optionB.name}
                        </div>
                      </div>
                    </div>

                    {/* Year-by-Year Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" className="w-full justify-between bg-transparent">
                          Year-by-Year Comparison
                          {showBreakdown ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="mt-3 max-h-60 overflow-y-auto rounded-lg border">
                          <table className="w-full text-sm">
                            <thead className="bg-muted sticky top-0">
                              <tr>
                                <th className="p-2 text-left font-medium">Year</th>
                                <th className="p-2 text-right font-medium">{result.optionA.name}</th>
                                <th className="p-2 text-right font-medium">{result.optionB.name}</th>
                                <th className="p-2 text-right font-medium">Difference</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.yearlyBreakdown.map((row) => (
                                <tr key={row.year} className="border-t">
                                  <td className="p-2">{row.year}</td>
                                  <td className="p-2 text-right">{formatCurrency(row.valueA, currency)}</td>
                                  <td className="p-2 text-right">{formatCurrency(row.valueB, currency)}</td>
                                  <td className="p-2 text-right text-amber-600">
                                    {formatCurrency(row.difference, currency)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">What is Opportunity Cost?</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    Opportunity cost represents the potential benefits you miss out on when choosing one alternative
                    over another. It's a fundamental concept in economics and finance.
                  </p>
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <p className="font-medium text-amber-800 mb-1">Example</p>
                    <p className="text-amber-700 text-xs">
                      If you invest {symbol}10,000 in stocks earning 8% instead of bonds earning 5%, your opportunity
                      cost of choosing bonds would be the difference in returns.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">The Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      FV = PV × (1 + r/n)<sup>n×t</sup>
                    </p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>FV</strong> = Future Value
                    </p>
                    <p>
                      <strong>PV</strong> = Present Value (initial investment)
                    </p>
                    <p>
                      <strong>r</strong> = Annual interest rate
                    </p>
                    <p>
                      <strong>n</strong> = Compounding frequency
                    </p>
                    <p>
                      <strong>t</strong> = Time in years
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-800 mb-1">Opportunity Cost</p>
                    <p className="text-green-700 text-xs">= |Future Value of Option A - Future Value of Option B|</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Comparisons</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between p-2 rounded bg-muted text-sm">
                      <span>Stocks vs Bonds</span>
                      <span className="text-muted-foreground">8% vs 4%</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted text-sm">
                      <span>Real Estate vs Index Fund</span>
                      <span className="text-muted-foreground">6% vs 10%</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted text-sm">
                      <span>Savings Account vs CD</span>
                      <span className="text-muted-foreground">0.5% vs 4%</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted text-sm">
                      <span>Pay Off Debt vs Invest</span>
                      <span className="text-muted-foreground">Varies</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Opportunity Cost</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Opportunity cost is the value of the next best alternative that you give up when making a decision. In
                  financial terms, it represents the potential return you could have earned by choosing a different
                  investment or financial path. Understanding opportunity cost helps you make more informed decisions by
                  considering not just the direct benefits of a choice, but also what you're giving up.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, if you have {symbol}50,000 and choose to put it in a savings account earning 1% instead
                  of investing in a diversified portfolio earning 7%, your opportunity cost over 10 years could be
                  substantial. This calculator helps you visualize and quantify these trade-offs.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>When to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Investment Decisions</h4>
                    <p className="text-blue-700 text-sm">
                      Compare different investment vehicles like stocks, bonds, real estate, or retirement accounts to
                      see which option provides better long-term returns.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Debt vs Investment</h4>
                    <p className="text-green-700 text-sm">
                      Decide whether to pay off debt early or invest the extra money by comparing the guaranteed return
                      of debt payoff against potential investment returns.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Business Decisions</h4>
                    <p className="text-purple-700 text-sm">
                      Evaluate business investments, expansion opportunities, or equipment purchases by comparing
                      expected returns of different options.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Career Choices</h4>
                    <p className="text-amber-700 text-sm">
                      Compare job offers or career paths by factoring in salary differences, benefits, and potential
                      future earnings growth.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Opportunity cost calculations are estimates based on entered values and assumed rates of return.
                  Actual outcomes may vary due to market conditions, inflation, fees, taxes, and other factors. Past
                  performance does not guarantee future results. This calculator is for educational and informational
                  purposes only and should not be considered financial advice. Consult a qualified financial advisor for
                  personalized guidance before making investment decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
