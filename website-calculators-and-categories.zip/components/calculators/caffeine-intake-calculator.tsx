"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Coffee, Info, AlertTriangle, Clock, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type UnitSystem = "metric" | "imperial"
type Sensitivity = "low" | "medium" | "high"
type Goal = "alertness" | "performance" | "fatigue"
type CaffeineSource = "coffee" | "tea" | "energy-drink" | "supplement"

interface CaffeineResult {
  maxDaily: number
  currentIntake: number
  remaining: number
  status: string
  statusColor: string
  statusBgColor: string
  perServingSuggestions: { source: string; amount: string; servings: number }[]
  timingSuggestions: string[]
}

const caffeineContent: Record<CaffeineSource, { name: string; mgPerServing: number; servingSize: string }> = {
  coffee: { name: "Coffee (8 oz)", mgPerServing: 95, servingSize: "8 oz cup" },
  tea: { name: "Tea (8 oz)", mgPerServing: 47, servingSize: "8 oz cup" },
  "energy-drink": { name: "Energy Drink (8 oz)", mgPerServing: 80, servingSize: "8 oz can" },
  supplement: { name: "Caffeine Pill", mgPerServing: 200, servingSize: "1 pill" },
}

export function CaffeineIntakeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [currentIntake, setCurrentIntake] = useState("")
  const [sensitivity, setSensitivity] = useState<Sensitivity>("medium")
  const [goal, setGoal] = useState<Goal>("alertness")
  const [caffeineSource, setCaffeineSource] = useState<CaffeineSource>("coffee")
  const [result, setResult] = useState<CaffeineResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  const calculateCaffeineIntake = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const weightNum = Number.parseFloat(weight)
    const currentIntakeNum = Number.parseFloat(currentIntake) || 0

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (currentIntakeNum < 0) {
      setError("Current caffeine intake cannot be negative")
      return
    }

    // Convert weight to kg if imperial
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Base recommendation: 3-6 mg/kg/day (using middle value of 4.5 mg/kg)
    let baseMax = weightInKg * 4.5

    // Adjust for sensitivity
    if (sensitivity === "low") {
      baseMax *= 1.1 // +10% allowance
    } else if (sensitivity === "high") {
      baseMax *= 0.8 // -20% allowance
    }

    // Age adjustments
    if (ageNum < 18) {
      baseMax = Math.min(baseMax, 100) // Cap for adolescents
    } else if (ageNum >= 65) {
      baseMax *= 0.85 // Reduce for seniors
    }

    // General safety cap at 400mg for healthy adults
    if (ageNum >= 18 && ageNum < 65) {
      baseMax = Math.min(baseMax, 400)
    }

    const maxDaily = Math.round(baseMax)
    const remaining = Math.max(0, maxDaily - currentIntakeNum)

    // Determine status
    let status: string
    let statusColor: string
    let statusBgColor: string

    const intakeRatio = currentIntakeNum / maxDaily

    if (currentIntakeNum === 0) {
      status = "No Intake"
      statusColor = "text-gray-600"
      statusBgColor = "bg-gray-50 border-gray-200"
    } else if (intakeRatio <= 0.5) {
      status = "Low Intake"
      statusColor = "text-green-600"
      statusBgColor = "bg-green-50 border-green-200"
    } else if (intakeRatio <= 0.75) {
      status = "Moderate Intake"
      statusColor = "text-blue-600"
      statusBgColor = "bg-blue-50 border-blue-200"
    } else if (intakeRatio <= 1) {
      status = "Near Limit"
      statusColor = "text-yellow-600"
      statusBgColor = "bg-yellow-50 border-yellow-200"
    } else {
      status = "Over Limit"
      statusColor = "text-red-600"
      statusBgColor = "bg-red-50 border-red-200"
    }

    // Calculate per-serving suggestions
    const perServingSuggestions = Object.entries(caffeineContent).map(([key, value]) => {
      const servings = Math.floor(remaining / value.mgPerServing)
      return {
        source: value.name,
        amount: `${value.mgPerServing}mg per ${value.servingSize}`,
        servings: Math.max(0, servings),
      }
    })

    // Timing suggestions based on goal
    const timingSuggestions: string[] = []
    if (goal === "alertness") {
      timingSuggestions.push("Consume caffeine 30-60 minutes after waking for best alertness")
      timingSuggestions.push("Avoid caffeine at least 6 hours before bedtime")
      timingSuggestions.push("Space out intake every 3-4 hours to maintain steady alertness")
    } else if (goal === "performance") {
      timingSuggestions.push("Take 3-6 mg/kg caffeine 30-60 minutes before exercise")
      timingSuggestions.push("For endurance events, consider small doses throughout activity")
      timingSuggestions.push("Avoid using caffeine daily to prevent tolerance buildup")
    } else {
      timingSuggestions.push("Use caffeine strategically during periods of low energy")
      timingSuggestions.push("Consider smaller, more frequent doses rather than large amounts")
      timingSuggestions.push("Pair with a 20-minute power nap for enhanced effect")
    }

    setResult({
      maxDaily,
      currentIntake: currentIntakeNum,
      remaining,
      status,
      statusColor,
      statusBgColor,
      perServingSuggestions,
      timingSuggestions,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setGender("male")
    setCurrentIntake("")
    setSensitivity("medium")
    setGoal("alertness")
    setCaffeineSource("coffee")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `My recommended max daily caffeine: ${result.maxDaily}mg. Current intake: ${result.currentIntake}mg. Remaining safe intake: ${result.remaining}mg (${result.status})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Caffeine Intake Results",
          text: `I calculated my caffeine intake using CalcHub! Max daily: ${result.maxDaily}mg, Status: ${result.status}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Coffee className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Caffeine Intake Calculator</CardTitle>
                    <CardDescription>Calculate your safe daily caffeine limit</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["male", "female"] as const).map((g) => (
                      <button
                        key={g}
                        onClick={() => setGender(g)}
                        className={`p-3 rounded-lg border text-sm font-medium transition-colors ${
                          gender === g
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background hover:bg-muted border-input"
                        }`}
                      >
                        {g.charAt(0).toUpperCase() + g.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Current Caffeine Intake */}
                <div className="space-y-2">
                  <Label htmlFor="currentIntake">Current Daily Caffeine Intake (mg)</Label>
                  <Input
                    id="currentIntake"
                    type="number"
                    placeholder="Enter current intake (optional)"
                    value={currentIntake}
                    onChange={(e) => setCurrentIntake(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Sensitivity Level */}
                <div className="space-y-2">
                  <Label>Caffeine Sensitivity</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["low", "medium", "high"] as const).map((s) => (
                      <button
                        key={s}
                        onClick={() => setSensitivity(s)}
                        className={`p-3 rounded-lg border text-sm font-medium transition-colors ${
                          sensitivity === s
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background hover:bg-muted border-input"
                        }`}
                      >
                        {s.charAt(0).toUpperCase() + s.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="w-full justify-between bg-transparent">
                      Advanced Options
                      <span className="text-xs text-muted-foreground">{showAdvanced ? "Hide" : "Show"}</span>
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    {/* Goal Selection */}
                    <div className="space-y-2">
                      <Label>Goal</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {(
                          [
                            { value: "alertness", label: "Alertness" },
                            { value: "performance", label: "Performance" },
                            { value: "fatigue", label: "Fatigue Mgmt" },
                          ] as const
                        ).map((g) => (
                          <button
                            key={g.value}
                            onClick={() => setGoal(g.value)}
                            className={`p-3 rounded-lg border text-sm font-medium transition-colors ${
                              goal === g.value
                                ? "bg-primary text-primary-foreground border-primary"
                                : "bg-background hover:bg-muted border-input"
                            }`}
                          >
                            {g.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Caffeine Source */}
                    <div className="space-y-2">
                      <Label>Primary Caffeine Source</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {(
                          [
                            { value: "coffee", label: "Coffee" },
                            { value: "tea", label: "Tea" },
                            { value: "energy-drink", label: "Energy Drink" },
                            { value: "supplement", label: "Supplement" },
                          ] as const
                        ).map((s) => (
                          <button
                            key={s.value}
                            onClick={() => setCaffeineSource(s.value)}
                            className={`p-3 rounded-lg border text-sm font-medium transition-colors ${
                              caffeineSource === s.value
                                ? "bg-primary text-primary-foreground border-primary"
                                : "bg-background hover:bg-muted border-input"
                            }`}
                          >
                            {s.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCaffeineIntake} className="w-full" size="lg">
                  Calculate Caffeine Limit
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.statusBgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Recommended Max Daily Caffeine</p>
                      <p className={`text-5xl font-bold ${result.statusColor} mb-1`}>{result.maxDaily}</p>
                      <p className="text-lg text-muted-foreground mb-2">mg/day</p>
                      <p className={`text-lg font-semibold ${result.statusColor}`}>{result.status}</p>
                    </div>

                    {/* Quick Stats */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="bg-background/50 rounded-lg p-3 text-center">
                        <p className="text-xs text-muted-foreground">Current Intake</p>
                        <p className="text-lg font-bold">{result.currentIntake} mg</p>
                      </div>
                      <div className="bg-background/50 rounded-lg p-3 text-center">
                        <p className="text-xs text-muted-foreground">Remaining Safe</p>
                        <p className="text-lg font-bold text-green-600">{result.remaining} mg</p>
                      </div>
                    </div>

                    {/* Warning if over limit */}
                    {result.currentIntake > result.maxDaily && (
                      <div className="mt-4 p-3 bg-red-100 border border-red-300 rounded-lg flex items-start gap-2">
                        <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                        <div className="text-sm text-red-700">
                          <p className="font-semibold">Warning: Exceeding Safe Limit</p>
                          <p>
                            You are currently {result.currentIntake - result.maxDaily}mg over your recommended daily
                            limit. Consider reducing intake.
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Expandable Details */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          {showDetails ? "Hide Details" : "Show Details"}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-4">
                        {/* Timing Suggestions */}
                        <div className="bg-background/50 rounded-lg p-3">
                          <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                            <Clock className="h-4 w-4" />
                            Optimal Timing
                          </h4>
                          <ul className="text-sm text-muted-foreground space-y-1">
                            {result.timingSuggestions.map((tip, index) => (
                              <li key={index} className="flex items-start gap-2">
                                <span className="text-primary">•</span>
                                {tip}
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Serving Suggestions */}
                        <div className="bg-background/50 rounded-lg p-3">
                          <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                            <Zap className="h-4 w-4" />
                            Safe Servings Remaining
                          </h4>
                          <div className="space-y-2">
                            {result.perServingSuggestions.map((suggestion, index) => (
                              <div key={index} className="flex justify-between text-sm">
                                <span className="text-muted-foreground">{suggestion.source}</span>
                                <span className="font-medium">
                                  {suggestion.servings} {suggestion.servings === 1 ? "serving" : "servings"}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Caffeine Content Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Coffee (8 oz)</span>
                      <span className="text-sm text-amber-600">80-100 mg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Green Tea (8 oz)</span>
                      <span className="text-sm text-green-600">25-50 mg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Black Tea (8 oz)</span>
                      <span className="text-sm text-blue-600">40-70 mg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Energy Drink (8 oz)</span>
                      <span className="text-sm text-purple-600">70-100 mg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Espresso (1 shot)</span>
                      <span className="text-sm text-red-600">63 mg</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recommended Limits</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Healthy Adults</p>
                    <p>Up to 400 mg/day (about 4 cups of coffee)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Pregnant Women</p>
                    <p>Up to 200 mg/day (consult healthcare provider)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Adolescents (12-18)</p>
                    <p>Up to 100 mg/day maximum</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Children (&lt;12)</p>
                    <p>Not recommended</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Max Daily = Weight (kg) × 3-6 mg</p>
                  </div>
                  <p>
                    The calculator uses 4.5 mg/kg as a baseline, then adjusts for sensitivity level (±10-20%), age, and
                    general safety caps established by health organizations.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Caffeine and Its Effects</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Caffeine is a natural stimulant found in coffee beans, tea leaves, cacao pods, and many other plants.
                  It works by blocking adenosine receptors in the brain, which helps reduce feelings of tiredness and
                  increase alertness. Caffeine is the most widely consumed psychoactive substance in the world, with
                  billions of people relying on it daily for increased mental focus and energy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When consumed in moderate amounts, caffeine can enhance cognitive function, improve physical
                  performance, and boost mood. However, individual responses to caffeine vary significantly based on
                  genetics, body weight, tolerance levels, and overall health. Understanding your personal caffeine
                  sensitivity is crucial for optimizing its benefits while minimizing potential side effects.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Benefits of Moderate Caffeine Consumption</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Mental Performance</h4>
                    <p className="text-green-700 text-sm">
                      Improves concentration, alertness, reaction time, and short-term memory. Can enhance
                      problem-solving abilities and reduce mental fatigue.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Physical Performance</h4>
                    <p className="text-blue-700 text-sm">
                      Increases endurance, reduces perceived exertion, and can improve strength and power output during
                      exercise. Often used by athletes as an ergogenic aid.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Metabolic Effects</h4>
                    <p className="text-purple-700 text-sm">
                      Can slightly boost metabolic rate and increase fat oxidation. May support weight management when
                      combined with a healthy diet and exercise.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Health Associations</h4>
                    <p className="text-amber-700 text-sm">
                      Research suggests moderate coffee consumption may be associated with reduced risk of certain
                      conditions including type 2 diabetes and Parkinson's disease.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Signs of Excessive Caffeine Intake</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While caffeine offers many benefits, consuming too much can lead to uncomfortable and potentially
                  harmful side effects. Being aware of these signs can help you adjust your intake accordingly.
                </p>
                <div className="mt-4 grid gap-3 md:grid-cols-2">
                  <div className="flex items-start gap-2">
                    <span className="text-red-500">•</span>
                    <span className="text-muted-foreground text-sm">Anxiety, restlessness, or nervousness</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-red-500">•</span>
                    <span className="text-muted-foreground text-sm">Insomnia or difficulty falling asleep</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-red-500">•</span>
                    <span className="text-muted-foreground text-sm">Rapid or irregular heartbeat</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-red-500">•</span>
                    <span className="text-muted-foreground text-sm">Digestive issues or upset stomach</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-red-500">•</span>
                    <span className="text-muted-foreground text-sm">Headaches (especially during withdrawal)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-red-500">•</span>
                    <span className="text-muted-foreground text-sm">Muscle tremors or twitching</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p>
                      Caffeine intake recommendations are general guidelines. Individual tolerance varies significantly
                      based on genetics, medications, and health conditions. Pregnant or breastfeeding women,
                      individuals with heart conditions, anxiety disorders, or those taking certain medications should
                      consult a healthcare professional before consuming caffeine. This calculator is for educational
                      purposes only and should not replace professional medical advice.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
