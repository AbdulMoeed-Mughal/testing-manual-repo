"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Home, Info, Calculator, Ruler } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface CarpetAreaResult {
  carpetArea: number
  carpetPercentage: number
  carpetAreaPerFloor: number | null
  category: string
  color: string
  bgColor: string
}

export function CarpetAreaCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [builtUpArea, setBuiltUpArea] = useState("")
  const [wallDeduction, setWallDeduction] = useState("")
  const [commonAreaDeduction, setCommonAreaDeduction] = useState("")
  const [numFloors, setNumFloors] = useState("")
  const [result, setResult] = useState<CarpetAreaResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCarpetArea = () => {
    setError("")
    setResult(null)

    const builtUpNum = Number.parseFloat(builtUpArea)
    const wallNum = Number.parseFloat(wallDeduction) || 0
    const commonNum = Number.parseFloat(commonAreaDeduction) || 0
    const floorsNum = Number.parseInt(numFloors) || 0

    if (isNaN(builtUpNum) || builtUpNum <= 0) {
      setError("Please enter a valid built-up area greater than 0")
      return
    }

    const totalDeduction = wallNum + commonNum

    if (totalDeduction > builtUpNum) {
      setError("Total deductions cannot exceed built-up area")
      return
    }

    const carpetArea = builtUpNum - totalDeduction
    const carpetPercentage = (carpetArea / builtUpNum) * 100
    const carpetAreaPerFloor = floorsNum > 0 ? carpetArea / floorsNum : null

    let category: string
    let color: string
    let bgColor: string

    if (carpetPercentage >= 80) {
      category = "Excellent"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (carpetPercentage >= 70) {
      category = "Good"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (carpetPercentage >= 60) {
      category = "Average"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Below Average"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      carpetArea,
      carpetPercentage,
      carpetAreaPerFloor,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setBuiltUpArea("")
    setWallDeduction("")
    setCommonAreaDeduction("")
    setNumFloors("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "m²" : "ft²"
      const text = `Carpet Area: ${result.carpetArea.toFixed(2)} ${unit} (${result.carpetPercentage.toFixed(1)}% of built-up area)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const unit = unitSystem === "metric" ? "m²" : "ft²"
      try {
        await navigator.share({
          title: "Carpet Area Calculation",
          text: `Carpet Area: ${result.carpetArea.toFixed(2)} ${unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setBuiltUpArea("")
    setWallDeduction("")
    setCommonAreaDeduction("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Carpet Area Calculator</CardTitle>
                    <CardDescription>Calculate usable interior area</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      m²
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      ft²
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Built-up Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="builtUpArea">Built-up Area ({unitSystem === "metric" ? "m²" : "ft²"})</Label>
                  <Input
                    id="builtUpArea"
                    type="number"
                    placeholder={`Enter built-up area in ${unitSystem === "metric" ? "square meters" : "square feet"}`}
                    value={builtUpArea}
                    onChange={(e) => setBuiltUpArea(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Wall Deduction */}
                <div className="space-y-2">
                  <Label htmlFor="wallDeduction">
                    Wall Area Deduction ({unitSystem === "metric" ? "m²" : "ft²"}) (Optional)
                  </Label>
                  <Input
                    id="wallDeduction"
                    type="number"
                    placeholder="Enter wall area to deduct"
                    value={wallDeduction}
                    onChange={(e) => setWallDeduction(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">Typically 10-15% of built-up area</p>
                </div>

                {/* Common Area Deduction */}
                <div className="space-y-2">
                  <Label htmlFor="commonAreaDeduction">
                    Common Area Deduction ({unitSystem === "metric" ? "m²" : "ft²"}) (Optional)
                  </Label>
                  <Input
                    id="commonAreaDeduction"
                    type="number"
                    placeholder="Enter common area to deduct"
                    value={commonAreaDeduction}
                    onChange={(e) => setCommonAreaDeduction(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">Balconies, corridors, common spaces</p>
                </div>

                {/* Number of Floors (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="numFloors">Number of Floors (Optional)</Label>
                  <Input
                    id="numFloors"
                    type="number"
                    placeholder="Enter number of floors"
                    value={numFloors}
                    onChange={(e) => setNumFloors(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCarpetArea} className="w-full" size="lg">
                  Calculate Carpet Area
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-current/20">
                        <p className="text-sm text-muted-foreground mb-1">Carpet Area</p>
                        <p className={`text-4xl font-bold ${result.color} mb-1`}>
                          {result.carpetArea.toFixed(2)}
                        </p>
                        <p className="text-sm text-muted-foreground">{unitSystem === "metric" ? "m²" : "ft²"}</p>
                        <p className={`text-lg font-semibold ${result.color} mt-2`}>
                          {result.carpetPercentage.toFixed(1)}% - {result.category}
                        </p>
                      </div>

                      {result.carpetAreaPerFloor && (
                        <div className="text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Carpet Area per Floor:</span>
                            <span className={`font-semibold ${result.color}`}>
                              {result.carpetAreaPerFloor.toFixed(2)} {unitSystem === "metric" ? "m²" : "ft²"}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Carpet Area Efficiency</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-sm text-green-600">≥ 80%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-sm text-blue-600">70% – 79%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Average</span>
                      <span className="text-sm text-yellow-600">60% – 69%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Below Average</span>
                      <span className="text-sm text-red-600">{"< 60%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Deductions</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Wall thickness: 10-15% of built-up area</p>
                  <p>• Balconies and terraces</p>
                  <p>• Common corridors and staircases</p>
                  <p>• Lift shafts and lobbies</p>
                  <p>• Parking and utility areas</p>
                  <p>• External projections</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Carpet Area */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Carpet Area?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Carpet area is the actual usable floor area within a property where you can lay a carpet. It represents
                  the net usable area inside the apartment or house, excluding the thickness of the walls, balconies,
                  terraces, and common areas like lobbies, staircases, and lifts. This measurement is crucial for property
                  buyers as it reflects the actual living space available for use.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of carpet area became legally significant in many countries after real estate regulations
                  mandated that property developers must sell residential units based on carpet area rather than super
                  built-up area. This change was introduced to bring transparency to real estate transactions and protect
                  buyers from being misled about the actual usable space they are purchasing. Understanding carpet area
                  helps buyers make informed decisions and compare properties accurately.
                </p>
              </CardContent>
            </Card>

            {/* Types of Areas */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Different Area Types</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In real estate, three types of area measurements are commonly used: Carpet Area, Built-up Area, and Super
                  Built-up Area. Carpet area is the smallest and most practical measurement, representing only the usable
                  floor space. Built-up area includes the carpet area plus the thickness of walls, which typically adds
                  about 10-15% to the carpet area measurement.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Super built-up area, also known as saleable area, is the largest measurement and includes the built-up
                  area plus a proportionate share of common areas like lobbies, staircases, lifts, gardens, and amenities.
                  This can add 20-30% to the built-up area. Developers often use super built-up area for pricing, which is
                  why understanding these differences is crucial. The carpet area typically ranges from 60-80% of the super
                  built-up area, depending on the building design and common area proportions.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Carpet Area</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate carpet area, start with the built-up area and subtract the wall thickness area and any
                  non-usable spaces. Wall thickness typically accounts for 10-15% of the built-up area, though this can
                  vary based on construction methods and building codes. Measure the internal dimensions of each room from
                  wall to wall and add them together to get the total carpet area.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Exclude areas like balconies, terraces, dry balconies, and flower beds from your calculation. Also
                  exclude any exclusive service areas like AC plant rooms or utility shafts that cannot be used as living
                  space. For apartments, ensure you're not counting common areas like corridors, staircases, or lift
                  lobbies. A good carpet area efficiency ratio is 70% or higher compared to the built-up area, indicating
                  efficient space utilization.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Carpet area calculations provided by this calculator are approximate and for
                  planning purposes only. Actual usable area may vary due to wall thickness, architectural features,
                  columns, built-in fixtures, and specific building design. For legal and transaction purposes, always rely
                  on measurements provided in official property documents and verified by registered surveyors or
                  architects.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
