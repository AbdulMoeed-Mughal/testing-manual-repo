"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Activity } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

type CalculationMethod = "power" | "phase-angle" | "vi-power"

interface PowerFactorResult {
  powerFactor: number
  powerFactorPercent: number
  phaseAngle: number
  reactivePower: number
  apparentPower: number
  realPower: number
  powerFactorType: "Leading" | "Lagging" | "Unity"
  steps: string[]
}

export function PowerFactorCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("power")
  const [realPower, setRealPower] = useState("")
  const [apparentPower, setApparentPower] = useState("")
  const [phaseAngleInput, setPhaseAngleInput] = useState("")
  const [voltage, setVoltage] = useState("")
  const [current, setCurrent] = useState("")
  const [powerUnit, setPowerUnit] = useState<"W" | "kW" | "MW">("W")
  const [apparentPowerUnit, setApparentPowerUnit] = useState<"VA" | "kVA" | "MVA">("VA")
  const [isLeading, setIsLeading] = useState(false)
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<PowerFactorResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const convertToBaseUnit = (value: number, unit: string): number => {
    switch (unit) {
      case "kW":
      case "kVA":
        return value * 1000
      case "MW":
      case "MVA":
        return value * 1000000
      default:
        return value
    }
  }

  const formatNumber = (num: number, decimals = 4): string => {
    if (Math.abs(num) >= 1000000) {
      return (num / 1000000).toFixed(decimals) + " M"
    } else if (Math.abs(num) >= 1000) {
      return (num / 1000).toFixed(decimals) + " k"
    }
    return num.toFixed(decimals)
  }

  const calculatePowerFactor = () => {
    setError("")
    setResult(null)
    const steps: string[] = []

    try {
      let pf: number
      let P: number
      let S: number
      let Q: number
      let phi: number

      if (method === "power") {
        // PF = P / S
        const realPowerNum = Number.parseFloat(realPower)
        const apparentPowerNum = Number.parseFloat(apparentPower)

        if (isNaN(realPowerNum) || realPowerNum < 0) {
          setError("Please enter a valid real power (P) >= 0")
          return
        }
        if (isNaN(apparentPowerNum) || apparentPowerNum <= 0) {
          setError("Please enter a valid apparent power (S) > 0")
          return
        }

        P = convertToBaseUnit(realPowerNum, powerUnit)
        S = convertToBaseUnit(apparentPowerNum, apparentPowerUnit)

        if (P > S) {
          setError("Real power (P) cannot be greater than apparent power (S)")
          return
        }

        pf = P / S
        Q = Math.sqrt(S * S - P * P)
        phi = Math.acos(pf) * (180 / Math.PI)

        steps.push(`Given: P = ${formatNumber(P)} W, S = ${formatNumber(S)} VA`)
        steps.push(`Power Factor: PF = P / S = ${formatNumber(P)} / ${formatNumber(S)}`)
        steps.push(`PF = ${pf.toFixed(4)}`)
        steps.push(`Reactive Power: Q = √(S² − P²) = √(${formatNumber(S)}² − ${formatNumber(P)}²)`)
        steps.push(`Q = ${formatNumber(Q)} VAR`)
        steps.push(`Phase Angle: φ = cos⁻¹(PF) = cos⁻¹(${pf.toFixed(4)}) = ${phi.toFixed(2)}°`)
      } else if (method === "phase-angle") {
        // PF = cos(φ)
        const phiInput = Number.parseFloat(phaseAngleInput)

        if (isNaN(phiInput) || phiInput < -90 || phiInput > 90) {
          setError("Please enter a valid phase angle between -90° and 90°")
          return
        }

        phi = Math.abs(phiInput)
        pf = Math.cos(phi * (Math.PI / 180))

        // Use optional power values if provided
        const realPowerNum = Number.parseFloat(realPower)
        if (!isNaN(realPowerNum) && realPowerNum > 0) {
          P = convertToBaseUnit(realPowerNum, powerUnit)
          S = P / pf
          Q = Math.sqrt(S * S - P * P)
        } else {
          P = 0
          S = 0
          Q = 0
        }

        steps.push(`Given: Phase Angle φ = ${phiInput}°`)
        steps.push(`Power Factor: PF = cos(φ) = cos(${phi}°)`)
        steps.push(`PF = ${pf.toFixed(4)}`)
        if (P > 0) {
          steps.push(`With P = ${formatNumber(P)} W:`)
          steps.push(`Apparent Power: S = P / PF = ${formatNumber(P)} / ${pf.toFixed(4)} = ${formatNumber(S)} VA`)
          steps.push(`Reactive Power: Q = √(S² − P²) = ${formatNumber(Q)} VAR`)
        }
      } else {
        // VI method: S = V × I, then PF = P / S
        const voltageNum = Number.parseFloat(voltage)
        const currentNum = Number.parseFloat(current)
        const realPowerNum = Number.parseFloat(realPower)

        if (isNaN(voltageNum) || voltageNum <= 0) {
          setError("Please enter a valid voltage > 0")
          return
        }
        if (isNaN(currentNum) || currentNum <= 0) {
          setError("Please enter a valid current > 0")
          return
        }
        if (isNaN(realPowerNum) || realPowerNum < 0) {
          setError("Please enter a valid real power (P) >= 0")
          return
        }

        P = convertToBaseUnit(realPowerNum, powerUnit)
        S = voltageNum * currentNum

        if (P > S) {
          setError("Real power (P) cannot be greater than apparent power (V × I)")
          return
        }

        pf = P / S
        Q = Math.sqrt(S * S - P * P)
        phi = Math.acos(pf) * (180 / Math.PI)

        steps.push(`Given: V = ${voltageNum} V, I = ${currentNum} A, P = ${formatNumber(P)} W`)
        steps.push(`Apparent Power: S = V × I = ${voltageNum} × ${currentNum} = ${formatNumber(S)} VA`)
        steps.push(`Power Factor: PF = P / S = ${formatNumber(P)} / ${formatNumber(S)}`)
        steps.push(`PF = ${pf.toFixed(4)}`)
        steps.push(`Reactive Power: Q = √(S² − P²) = ${formatNumber(Q)} VAR`)
        steps.push(`Phase Angle: φ = cos⁻¹(PF) = ${phi.toFixed(2)}°`)
      }

      // Determine power factor type
      let pfType: "Leading" | "Lagging" | "Unity"
      if (Math.abs(pf - 1) < 0.0001) {
        pfType = "Unity"
      } else if (isLeading) {
        pfType = "Leading"
      } else {
        pfType = "Lagging"
      }

      steps.push(`Power Factor Type: ${pfType}`)

      setResult({
        powerFactor: pf,
        powerFactorPercent: pf * 100,
        phaseAngle: phi,
        reactivePower: Q,
        apparentPower: S,
        realPower: P,
        powerFactorType: pfType,
        steps,
      })
    } catch {
      setError("An error occurred during calculation")
    }
  }

  const handleReset = () => {
    setRealPower("")
    setApparentPower("")
    setPhaseAngleInput("")
    setVoltage("")
    setCurrent("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Power Factor: ${result.powerFactor.toFixed(4)} (${result.powerFactorPercent.toFixed(2)}%), Phase Angle: ${result.phaseAngle.toFixed(2)}°, Type: ${result.powerFactorType}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Power Factor Calculation",
          text: `Power Factor: ${result.powerFactor.toFixed(4)} (${result.powerFactorPercent.toFixed(2)}%), Phase Angle: ${result.phaseAngle.toFixed(2)}°, Type: ${result.powerFactorType}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const getPowerFactorColor = (pf: number) => {
    if (pf >= 0.95) return { color: "text-green-600", bg: "bg-green-50 border-green-200", label: "Excellent" }
    if (pf >= 0.85) return { color: "text-blue-600", bg: "bg-blue-50 border-blue-200", label: "Good" }
    if (pf >= 0.7) return { color: "text-yellow-600", bg: "bg-yellow-50 border-yellow-200", label: "Fair" }
    return { color: "text-red-600", bg: "bg-red-50 border-red-200", label: "Poor" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Power Factor Calculator</CardTitle>
                    <CardDescription>Calculate AC power factor and reactive power</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Method Selection */}
                <div className="space-y-2">
                  <Label>Calculation Method</Label>
                  <Select value={method} onValueChange={(v) => setMethod(v as CalculationMethod)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="power">Real & Apparent Power (PF = P/S)</SelectItem>
                      <SelectItem value="phase-angle">Phase Angle (PF = cos φ)</SelectItem>
                      <SelectItem value="vi-power">Voltage, Current & Real Power</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Real Power Input */}
                {(method === "power" || method === "vi-power" || method === "phase-angle") && (
                  <div className="space-y-2">
                    <Label htmlFor="realPower">Real Power (P) {method === "phase-angle" && "(Optional)"}</Label>
                    <div className="flex gap-2">
                      <Input
                        id="realPower"
                        type="number"
                        placeholder="Enter real power"
                        value={realPower}
                        onChange={(e) => setRealPower(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={powerUnit} onValueChange={(v) => setPowerUnit(v as "W" | "kW" | "MW")}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="W">W</SelectItem>
                          <SelectItem value="kW">kW</SelectItem>
                          <SelectItem value="MW">MW</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Apparent Power Input */}
                {method === "power" && (
                  <div className="space-y-2">
                    <Label htmlFor="apparentPower">Apparent Power (S)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="apparentPower"
                        type="number"
                        placeholder="Enter apparent power"
                        value={apparentPower}
                        onChange={(e) => setApparentPower(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select
                        value={apparentPowerUnit}
                        onValueChange={(v) => setApparentPowerUnit(v as "VA" | "kVA" | "MVA")}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="VA">VA</SelectItem>
                          <SelectItem value="kVA">kVA</SelectItem>
                          <SelectItem value="MVA">MVA</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Phase Angle Input */}
                {method === "phase-angle" && (
                  <div className="space-y-2">
                    <Label htmlFor="phaseAngle">Phase Angle (φ) in degrees</Label>
                    <Input
                      id="phaseAngle"
                      type="number"
                      placeholder="Enter phase angle (-90° to 90°)"
                      value={phaseAngleInput}
                      onChange={(e) => setPhaseAngleInput(e.target.value)}
                      min="-90"
                      max="90"
                      step="any"
                    />
                  </div>
                )}

                {/* Voltage & Current Inputs */}
                {method === "vi-power" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="voltage">Voltage (V)</Label>
                      <Input
                        id="voltage"
                        type="number"
                        placeholder="Enter voltage in volts"
                        value={voltage}
                        onChange={(e) => setVoltage(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="current">Current (I)</Label>
                      <Input
                        id="current"
                        type="number"
                        placeholder="Enter current in amperes"
                        value={current}
                        onChange={(e) => setCurrent(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Leading/Lagging Toggle */}
                <div className="flex items-center justify-between py-2">
                  <Label htmlFor="leading" className="cursor-pointer">
                    Load Type: {isLeading ? "Leading (Capacitive)" : "Lagging (Inductive)"}
                  </Label>
                  <Switch id="leading" checked={isLeading} onCheckedChange={setIsLeading} />
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between py-2">
                  <Label htmlFor="showSteps" className="cursor-pointer">
                    Show step-by-step solution
                  </Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePowerFactor} className="w-full" size="lg">
                  Calculate Power Factor
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getPowerFactorColor(result.powerFactor).bg} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Power Factor</p>
                      <p className={`text-5xl font-bold ${getPowerFactorColor(result.powerFactor).color} mb-2`}>
                        {result.powerFactor.toFixed(4)}
                      </p>
                      <p className={`text-lg font-semibold ${getPowerFactorColor(result.powerFactor).color}`}>
                        {result.powerFactorPercent.toFixed(2)}% ({getPowerFactorColor(result.powerFactor).label})
                      </p>
                      <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/50">
                        <span className="text-sm font-medium">{result.powerFactorType}</span>
                      </div>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Phase Angle (φ)</p>
                        <p className="font-semibold">{result.phaseAngle.toFixed(2)}°</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Reactive Power (Q)</p>
                        <p className="font-semibold">{formatNumber(result.reactivePower)} VAR</p>
                      </div>
                      {result.realPower > 0 && (
                        <>
                          <div className="p-2 bg-white/50 rounded-lg text-center">
                            <p className="text-muted-foreground">Real Power (P)</p>
                            <p className="font-semibold">{formatNumber(result.realPower)} W</p>
                          </div>
                          <div className="p-2 bg-white/50 rounded-lg text-center">
                            <p className="text-muted-foreground">Apparent Power (S)</p>
                            <p className="font-semibold">{formatNumber(result.apparentPower)} VA</p>
                          </div>
                        </>
                      )}
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            <span>Step-by-Step Solution</span>
                            <ChevronDown className="h-4 w-4" />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-2 p-3 bg-white/50 rounded-lg space-y-1 text-sm">
                            {result.steps.map((step, index) => (
                              <p key={index} className="font-mono text-xs">
                                {step}
                              </p>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Power Factor Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-mono text-sm font-semibold">PF = P / S</p>
                      <p className="text-xs text-muted-foreground mt-1">P = Real Power (W), S = Apparent Power (VA)</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-mono text-sm font-semibold">PF = cos(φ)</p>
                      <p className="text-xs text-muted-foreground mt-1">φ = Phase angle between V and I</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-mono text-sm font-semibold">Q = √(S² − P²)</p>
                      <p className="text-xs text-muted-foreground mt-1">Q = Reactive Power (VAR)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Power Factor Ratings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-green-600">0.95 – 1.00</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-blue-600">0.85 – 0.94</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Fair</span>
                      <span className="text-yellow-600">0.70 – 0.84</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Poor</span>
                      <span className="text-red-600">{"< 0.70"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Leading vs Lagging</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Lagging (Inductive):</strong> Current lags voltage. Common in motors, transformers, and
                    inductive loads.
                  </p>
                  <p>
                    <strong>Leading (Capacitive):</strong> Current leads voltage. Common in capacitor banks and some
                    electronic equipment.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Power Factor?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Power factor is a measure of how efficiently electrical power is being used in an AC circuit. It is
                  the ratio of real power (the power actually consumed by equipment) to apparent power (the total power
                  supplied to the circuit). A power factor of 1 (unity) means all the power supplied is being used
                  effectively, while a lower power factor indicates that some power is being wasted as reactive power.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In practical terms, power factor represents the efficiency of power utilization. Industrial facilities
                  with large motors, transformers, and other inductive loads often have power factors below 1, which can
                  result in higher electricity bills and require power factor correction using capacitor banks.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>The Power Triangle</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The relationship between real power (P), reactive power (Q), and apparent power (S) can be visualized
                  as a right triangle known as the power triangle. Real power forms the adjacent side, reactive power
                  forms the opposite side, and apparent power is the hypotenuse. The angle between real and apparent
                  power is the phase angle (φ), and cos(φ) equals the power factor.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="font-mono text-sm">S² = P² + Q²</p>
                  <p className="font-mono text-sm">PF = P/S = cos(φ)</p>
                  <p className="font-mono text-sm">tan(φ) = Q/P</p>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm">
                  Power factor calculations are estimates based on ideal conditions. Actual system power factor may vary
                  due to harmonics, non-linear loads, or measurement inaccuracies. Consult an electrical engineer for
                  precise analysis and power factor correction recommendations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
