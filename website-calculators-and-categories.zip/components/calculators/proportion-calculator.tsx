"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Scale, Info, AlertTriangle, Lightbulb } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type OperationType = "solve" | "check"
type MissingTerm = "A" | "B" | "C" | "D"

interface ProportionResult {
  isProportional?: boolean
  missingValue?: number
  steps: string[]
}

export function ProportionCalculator() {
  const [operation, setOperation] = useState<OperationType>("solve")
  const [missingTerm, setMissingTerm] = useState<MissingTerm>("D")
  const [termA, setTermA] = useState("")
  const [termB, setTermB] = useState("")
  const [termC, setTermC] = useState("")
  const [termD, setTermD] = useState("")
  const [result, setResult] = useState<ProportionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    if (operation === "solve") {
      // Get the known values
      const values: { [key: string]: number | null } = {
        A: termA !== "" ? Number.parseFloat(termA) : null,
        B: termB !== "" ? Number.parseFloat(termB) : null,
        C: termC !== "" ? Number.parseFloat(termC) : null,
        D: termD !== "" ? Number.parseFloat(termD) : null,
      }

      // Count known values
      const knownCount = Object.values(values).filter((v) => v !== null && !isNaN(v)).length

      if (knownCount < 3) {
        setError("Please enter at least three known values")
        return
      }

      // Validate all known values
      for (const [key, value] of Object.entries(values)) {
        if (value !== null && isNaN(value)) {
          setError(`Invalid value for term ${key}`)
          return
        }
      }

      const steps: string[] = []
      let missingValue: number

      // A/B = C/D => A × D = B × C (cross multiplication)
      steps.push("Using the proportion A : B = C : D")
      steps.push("Cross-multiplication: A × D = B × C")

      if (missingTerm === "A" && values.B !== null && values.C !== null && values.D !== null) {
        if (values.D === 0) {
          setError("Cannot divide by zero (D = 0)")
          return
        }
        missingValue = (values.B * values.C) / values.D
        steps.push(`A = (B × C) / D`)
        steps.push(`A = (${values.B} × ${values.C}) / ${values.D}`)
        steps.push(`A = ${values.B * values.C} / ${values.D}`)
        steps.push(`A = ${missingValue}`)
      } else if (missingTerm === "B" && values.A !== null && values.C !== null && values.D !== null) {
        if (values.C === 0) {
          setError("Cannot divide by zero (C = 0)")
          return
        }
        missingValue = (values.A * values.D) / values.C
        steps.push(`B = (A × D) / C`)
        steps.push(`B = (${values.A} × ${values.D}) / ${values.C}`)
        steps.push(`B = ${values.A * values.D} / ${values.C}`)
        steps.push(`B = ${missingValue}`)
      } else if (missingTerm === "C" && values.A !== null && values.B !== null && values.D !== null) {
        if (values.B === 0) {
          setError("Cannot divide by zero (B = 0)")
          return
        }
        missingValue = (values.A * values.D) / values.B
        steps.push(`C = (A × D) / B`)
        steps.push(`C = (${values.A} × ${values.D}) / ${values.B}`)
        steps.push(`C = ${values.A * values.D} / ${values.B}`)
        steps.push(`C = ${missingValue}`)
      } else if (missingTerm === "D" && values.A !== null && values.B !== null && values.C !== null) {
        if (values.A === 0) {
          setError("Cannot divide by zero (A = 0)")
          return
        }
        missingValue = (values.B * values.C) / values.A
        steps.push(`D = (B × C) / A`)
        steps.push(`D = (${values.B} × ${values.C}) / ${values.A}`)
        steps.push(`D = ${values.B * values.C} / ${values.A}`)
        steps.push(`D = ${missingValue}`)
      } else {
        setError("Please fill in the correct values for the selected missing term")
        return
      }

      setResult({ missingValue, steps })
    } else {
      // Check if proportional
      const a = Number.parseFloat(termA)
      const b = Number.parseFloat(termB)
      const c = Number.parseFloat(termC)
      const d = Number.parseFloat(termD)

      if (isNaN(a) || isNaN(b) || isNaN(c) || isNaN(d)) {
        setError("Please enter all four values to check proportion")
        return
      }

      if (b === 0 || d === 0) {
        setError("Denominators (B and D) cannot be zero")
        return
      }

      const steps: string[] = []
      steps.push(`Checking if ${a} : ${b} = ${c} : ${d}`)
      steps.push("Method: Cross-multiplication")
      steps.push(`A × D = ${a} × ${d} = ${a * d}`)
      steps.push(`B × C = ${b} × ${c} = ${b * c}`)

      const leftProduct = a * d
      const rightProduct = b * c
      const isProportional = Math.abs(leftProduct - rightProduct) < 0.0001

      if (isProportional) {
        steps.push(`Since ${leftProduct} = ${rightProduct}, the ratios are proportional ✓`)
      } else {
        steps.push(`Since ${leftProduct} ≠ ${rightProduct}, the ratios are NOT proportional ✗`)
      }

      // Also show the ratio values
      const ratio1 = a / b
      const ratio2 = c / d
      steps.push(`Ratio A/B = ${a}/${b} = ${ratio1.toFixed(4)}`)
      steps.push(`Ratio C/D = ${c}/${d} = ${ratio2.toFixed(4)}`)

      setResult({ isProportional, steps })
    }
  }

  const handleReset = () => {
    setTermA("")
    setTermB("")
    setTermC("")
    setTermD("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = ""
      if (result.missingValue !== undefined) {
        text = `Proportion: ${termA || "?"} : ${termB || "?"} = ${termC || "?"} : ${termD || "?"}\nMissing term ${missingTerm} = ${result.missingValue}`
      } else {
        text = `Proportion check: ${termA} : ${termB} = ${termC} : ${termD}\nResult: ${result.isProportional ? "Proportional" : "Not Proportional"}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        let text = ""
        if (result.missingValue !== undefined) {
          text = `I solved a proportion using CalcHub! Missing term ${missingTerm} = ${result.missingValue}`
        } else {
          text = `I checked a proportion using CalcHub! ${termA}:${termB} = ${termC}:${termD} is ${result.isProportional ? "proportional" : "not proportional"}`
        }
        await navigator.share({
          title: "Proportion Calculator Result",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Number.isInteger(num)) return num.toString()
    return num.toFixed(4).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Proportion Calculator</CardTitle>
                    <CardDescription>Solve proportions using cross-multiplication</CardDescription>
                  </div>
                </div>

                {/* Operation Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Operation</span>
                  <button
                    onClick={() => {
                      setOperation((prev) => (prev === "solve" ? "check" : "solve"))
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        operation === "check" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        operation === "solve" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Solve
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        operation === "check" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Check
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Proportion Visual */}
                <div className="p-4 bg-muted rounded-lg">
                  <div className="flex items-center justify-center gap-2 text-lg font-mono">
                    <span
                      className={`px-2 py-1 rounded ${missingTerm === "A" && operation === "solve" ? "bg-blue-100 text-blue-700" : ""}`}
                    >
                      {operation === "solve" && missingTerm === "A" ? "?" : termA || "A"}
                    </span>
                    <span>:</span>
                    <span
                      className={`px-2 py-1 rounded ${missingTerm === "B" && operation === "solve" ? "bg-blue-100 text-blue-700" : ""}`}
                    >
                      {operation === "solve" && missingTerm === "B" ? "?" : termB || "B"}
                    </span>
                    <span>=</span>
                    <span
                      className={`px-2 py-1 rounded ${missingTerm === "C" && operation === "solve" ? "bg-blue-100 text-blue-700" : ""}`}
                    >
                      {operation === "solve" && missingTerm === "C" ? "?" : termC || "C"}
                    </span>
                    <span>:</span>
                    <span
                      className={`px-2 py-1 rounded ${missingTerm === "D" && operation === "solve" ? "bg-blue-100 text-blue-700" : ""}`}
                    >
                      {operation === "solve" && missingTerm === "D" ? "?" : termD || "D"}
                    </span>
                  </div>
                </div>

                {/* Missing Term Selection (only for solve mode) */}
                {operation === "solve" && (
                  <div className="space-y-2">
                    <Label>Select Missing Term</Label>
                    <div className="grid grid-cols-4 gap-2">
                      {(["A", "B", "C", "D"] as MissingTerm[]).map((term) => (
                        <button
                          key={term}
                          onClick={() => {
                            setMissingTerm(term)
                            setResult(null)
                          }}
                          className={`p-2 rounded-lg font-medium transition-colors ${
                            missingTerm === term
                              ? "bg-blue-600 text-white"
                              : "bg-muted hover:bg-muted/80 text-foreground"
                          }`}
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Term Inputs */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="termA" className="text-blue-600 font-semibold">
                      Term A
                    </Label>
                    <Input
                      id="termA"
                      type="number"
                      placeholder="Enter value"
                      value={termA}
                      onChange={(e) => setTermA(e.target.value)}
                      disabled={operation === "solve" && missingTerm === "A"}
                      className={operation === "solve" && missingTerm === "A" ? "bg-blue-50" : ""}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="termB" className="text-green-600 font-semibold">
                      Term B
                    </Label>
                    <Input
                      id="termB"
                      type="number"
                      placeholder="Enter value"
                      value={termB}
                      onChange={(e) => setTermB(e.target.value)}
                      disabled={operation === "solve" && missingTerm === "B"}
                      className={operation === "solve" && missingTerm === "B" ? "bg-green-50" : ""}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="termC" className="text-orange-600 font-semibold">
                      Term C
                    </Label>
                    <Input
                      id="termC"
                      type="number"
                      placeholder="Enter value"
                      value={termC}
                      onChange={(e) => setTermC(e.target.value)}
                      disabled={operation === "solve" && missingTerm === "C"}
                      className={operation === "solve" && missingTerm === "C" ? "bg-orange-50" : ""}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="termD" className="text-purple-600 font-semibold">
                      Term D
                    </Label>
                    <Input
                      id="termD"
                      type="number"
                      placeholder="Enter value"
                      value={termD}
                      onChange={(e) => setTermD(e.target.value)}
                      disabled={operation === "solve" && missingTerm === "D"}
                      className={operation === "solve" && missingTerm === "D" ? "bg-purple-50" : ""}
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  {operation === "solve" ? "Solve Proportion" : "Check Proportion"}
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.isProportional === true
                        ? "bg-green-50 border-green-200"
                        : result.isProportional === false
                          ? "bg-red-50 border-red-200"
                          : "bg-blue-50 border-blue-200"
                    }`}
                  >
                    <div className="text-center">
                      {result.missingValue !== undefined ? (
                        <>
                          <p className="text-sm text-muted-foreground mb-1">Missing Term {missingTerm}</p>
                          <p className="text-5xl font-bold text-blue-600 mb-2">{formatNumber(result.missingValue)}</p>
                        </>
                      ) : (
                        <>
                          <p className="text-sm text-muted-foreground mb-1">Proportion Check</p>
                          <p
                            className={`text-3xl font-bold mb-2 ${result.isProportional ? "text-green-600" : "text-red-600"}`}
                          >
                            {result.isProportional ? "Proportional ✓" : "Not Proportional ✗"}
                          </p>
                        </>
                      )}
                    </div>

                    {/* Step-by-step */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg">
                      <p className="text-sm font-medium mb-2">Step-by-step solution:</p>
                      <div className="space-y-1 text-sm text-muted-foreground font-mono">
                        {result.steps.map((step, index) => (
                          <p key={index}>{step}</p>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cross-Multiplication Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-4 bg-muted rounded-lg font-mono text-center">
                      <p className="text-lg font-semibold">A : B = C : D</p>
                      <p className="text-sm text-muted-foreground mt-2">↓</p>
                      <p className="text-lg font-semibold">A × D = B × C</p>
                    </div>
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <p>
                        <strong>Solve for A:</strong> A = (B × C) / D
                      </p>
                      <p>
                        <strong>Solve for B:</strong> B = (A × D) / C
                      </p>
                      <p>
                        <strong>Solve for C:</strong> C = (A × D) / B
                      </p>
                      <p>
                        <strong>Solve for D:</strong> D = (B × C) / A
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-medium text-blue-700">2 : 3 = 4 : ?</p>
                    <p className="text-sm text-blue-600">Answer: ? = 6</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-medium text-green-700">5 : 10 = 15 : 30</p>
                    <p className="text-sm text-green-600">Proportional ✓</p>
                  </div>
                  <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <p className="font-medium text-orange-700">3 : 4 = 6 : 9</p>
                    <p className="text-sm text-orange-600">Not Proportional ✗</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>This calculator provides estimates only. Verify manually for critical calculations.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Proportion?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A proportion is a mathematical statement that two ratios or fractions are equal. When we write A:B =
                  C:D, we're saying that the relationship between A and B is the same as the relationship between C and
                  D. Proportions are fundamental in mathematics and have countless real-world applications, from scaling
                  recipes to calculating distances on maps to determining similar shapes in geometry.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of proportionality is essential in understanding relationships between quantities. When
                  two quantities are proportional, they increase or decrease at the same rate. For example, if you
                  double one quantity, the other also doubles. This relationship is expressed mathematically through
                  proportions and is crucial in fields ranging from cooking and construction to science and finance.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Cross-Multiplication</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Cross-multiplication is the primary method for solving proportions. Given a proportion A:B = C:D
                  (which can also be written as A/B = C/D), cross-multiplication states that A × D = B × C. This
                  technique works because multiplying both sides of an equation by the same value maintains equality,
                  and this process effectively eliminates the fractions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This method is incredibly powerful because it allows us to find any unknown term when we know the
                  other three. For instance, if we know that 2:3 = 4:x, we can cross-multiply to get 2x = 12, and then
                  solve for x = 6. Cross-multiplication is also used to verify whether two ratios are truly proportional
                  - if the cross products are equal, the ratios form a true proportion.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Proportions appear everywhere in daily life. In cooking, if a recipe serves 4 people and you need to
                  serve 6, you use proportions to scale the ingredients. Architects and engineers use proportions to
                  create scale drawings and models. Maps use proportions to represent real distances in smaller,
                  manageable sizes - a map scale of 1:100,000 means 1 cm on the map equals 100,000 cm (1 km) in reality.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In finance, proportions help calculate interest rates, exchange rates, and investment returns. In
                  medicine, dosages are often calculated proportionally based on body weight. Artists use proportions to
                  ensure their work is balanced and aesthetically pleasing, following principles like the golden ratio.
                  Understanding proportions is essential for problem-solving across virtually every field and
                  profession.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Common Mistakes to Avoid</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  One common mistake when working with proportions is setting up the ratios incorrectly. Always ensure
                  that corresponding quantities are in the same position - if the first ratio compares length to width,
                  the second ratio must also compare length to width in the same order. Another frequent error is
                  forgetting that proportions involve equivalent ratios, not just any two fractions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Division by zero is mathematically undefined, so always check that denominators are not zero before
                  attempting to solve. When checking if ratios are proportional, remember that small rounding errors in
                  calculations don't necessarily mean the ratios aren't proportional - consider using a small tolerance
                  for comparison. Finally, always verify your answer by substituting it back into the original
                  proportion to confirm it creates equal ratios.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
