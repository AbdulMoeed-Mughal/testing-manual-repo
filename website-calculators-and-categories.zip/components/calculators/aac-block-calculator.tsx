"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Box, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface AACResult {
  totalBlocks: number
  mortarVolume: number
  cementBags: number
  sandVolume: number
}

export function AACBlockCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [wallLength, setWallLength] = useState("")
  const [wallHeight, setWallHeight] = useState("")
  const [wallThickness, setWallThickness] = useState("")
  const [blockLength, setBlockLength] = useState("0.6")
  const [blockHeight, setBlockHeight] = useState("0.2")
  const [blockWidth, setBlockWidth] = useState("0.2")
  const [mortarType, setMortarType] = useState("thin")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<AACResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateAAC = () => {
    setError("")
    setResult(null)

    const lengthNum = parseFloat(wallLength)
    const heightNum = parseFloat(wallHeight)
    const thicknessNum = parseFloat(wallThickness)
    const bLengthNum = parseFloat(blockLength)
    const bHeightNum = parseFloat(blockHeight)
    const bWidthNum = parseFloat(blockWidth)
    const wastageNum = parseFloat(wastage)

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid wall length greater than 0")
      return
    }

    if (isNaN(heightNum) || heightNum <= 0) {
      setError("Please enter a valid wall height greater than 0")
      return
    }

    if (isNaN(thicknessNum) || thicknessNum <= 0) {
      setError("Please enter a valid wall thickness greater than 0")
      return
    }

    if (isNaN(bLengthNum) || bLengthNum <= 0 || isNaN(bHeightNum) || bHeightNum <= 0 || isNaN(bWidthNum) || bWidthNum <= 0) {
      setError("Please enter valid block dimensions")
      return
    }

    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }

    // Convert to meters if imperial
    const lengthM = unitSystem === "imperial" ? lengthNum * 0.3048 : lengthNum
    const heightM = unitSystem === "imperial" ? heightNum * 0.3048 : heightNum
    const thicknessM = unitSystem === "imperial" ? thicknessNum * 0.3048 : thicknessNum
    const bLengthM = unitSystem === "imperial" ? bLengthNum * 0.3048 : bLengthNum
    const bHeightM = unitSystem === "imperial" ? bHeightNum * 0.3048 : bHeightNum
    const bWidthM = unitSystem === "imperial" ? bWidthNum * 0.3048 : bWidthNum

    // Validate wall thickness
    if (thicknessM < bWidthM) {
      setError("Wall thickness must be greater than or equal to block width")
      return
    }

    // Calculate wall area
    const wallArea = lengthM * heightM

    // Calculate block area (face area)
    const blockArea = bLengthM * bHeightM

    // Calculate number of blocks
    const blocksNeeded = wallArea / blockArea
    const totalBlocks = Math.ceil(blocksNeeded * (1 + wastageNum / 100))

    // Calculate mortar volume
    const mortarThickness = mortarType === "thin" ? 0.006 : 0.012 // 6mm or 12mm
    const jointArea = wallArea * 2 // horizontal and vertical joints
    const mortarVolume = jointArea * mortarThickness

    // Calculate cement and sand for mortar (1:4 ratio)
    const dryMortarVolume = mortarVolume * 1.33
    const cementVolume = dryMortarVolume * (1 / 5)
    const sandVolume = dryMortarVolume * (4 / 5)

    const cementWeight = cementVolume * 1440 // kg
    const cementBags = cementWeight / 50 // 50kg bags

    setResult({
      totalBlocks: totalBlocks,
      mortarVolume: Math.round(mortarVolume * 1000) / 1000,
      cementBags: Math.ceil(cementBags * 10) / 10,
      sandVolume: Math.round(sandVolume * 1000) / 1000,
    })
  }

  const handleReset = () => {
    setWallLength("")
    setWallHeight("")
    setWallThickness("")
    setBlockLength("0.6")
    setBlockHeight("0.2")
    setBlockWidth("0.2")
    setMortarType("thin")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `AAC Block Calculator Results:\nBlocks Needed: ${result.totalBlocks}\nMortar: ${result.mortarVolume} m³\nCement: ${result.cementBags} bags\nSand: ${result.sandVolume} m³`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "AAC Block Calculator Results",
          text: `Blocks Needed: ${result.totalBlocks}, Mortar: ${result.mortarVolume} m³`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWallLength("")
    setWallHeight("")
    setWallThickness("")
    setResult(null)
    setError("")
  }

  const setPresetBlock = (preset: string) => {
    switch (preset) {
      case "600x200x200":
        setBlockLength("0.6")
        setBlockHeight("0.2")
        setBlockWidth("0.2")
        break
      case "600x200x100":
        setBlockLength("0.6")
        setBlockHeight("0.2")
        setBlockWidth("0.1")
        break
      case "600x200x150":
        setBlockLength("0.6")
        setBlockHeight("0.2")
        setBlockWidth("0.15")
        break
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Box className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">AAC Block Calculator</CardTitle>
                    <CardDescription>Calculate blocks and mortar for AAC walls</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Wall Dimensions ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Input
                      type="number"
                      placeholder="Length"
                      value={wallLength}
                      onChange={(e) => setWallLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                    <Input
                      type="number"
                      placeholder="Height"
                      value={wallHeight}
                      onChange={(e) => setWallHeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                    <Input
                      type="number"
                      placeholder="Thickness"
                      value={wallThickness}
                      onChange={(e) => setWallThickness(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="blockPreset">AAC Block Size</Label>
                  <Select onValueChange={setPresetBlock}>
                    <SelectTrigger id="blockPreset">
                      <SelectValue placeholder="Select preset or enter custom" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="600x200x200">600×200×200 mm</SelectItem>
                      <SelectItem value="600x200x100">600×200×100 mm</SelectItem>
                      <SelectItem value="600x200x150">600×200×150 mm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Block Dimensions ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Input
                      type="number"
                      placeholder="Length"
                      value={blockLength}
                      onChange={(e) => setBlockLength(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                    <Input
                      type="number"
                      placeholder="Height"
                      value={blockHeight}
                      onChange={(e) => setBlockHeight(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                    <Input
                      type="number"
                      placeholder="Width"
                      value={blockWidth}
                      onChange={(e) => setBlockWidth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="mortarType">Mortar Type</Label>
                    <Select value={mortarType} onValueChange={setMortarType}>
                      <SelectTrigger id="mortarType">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="thin">Thin Joint (6mm)</SelectItem>
                        <SelectItem value="standard">Standard (12mm)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="wastage">Wastage (%)</Label>
                    <Input
                      id="wastage"
                      type="number"
                      placeholder="5-10%"
                      value={wastage}
                      onChange={(e) => setWastage(e.target.value)}
                      min="0"
                      max="30"
                      step="1"
                    />
                  </div>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculateAAC} className="w-full" size="lg">
                  Calculate Blocks
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Material Requirements</p>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-amber-900">AAC Blocks</span>
                          <span className="text-2xl font-bold text-amber-700">{result.totalBlocks}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-amber-900">Mortar Volume</span>
                          <span className="text-lg font-bold text-amber-700">{result.mortarVolume} m³</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-amber-900">Cement</span>
                          <span className="text-lg font-bold text-amber-700">{result.cementBags} bags</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-amber-900">Sand</span>
                          <span className="text-lg font-bold text-amber-700">{result.sandVolume} m³</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4 pt-3 border-t border-amber-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common AAC Block Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-900">600×200×200</span>
                      <span className="text-sm text-amber-700">External walls</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-900">600×200×150</span>
                      <span className="text-sm text-amber-700">Partition walls</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-900">600×200×100</span>
                      <span className="text-sm text-amber-700">Internal walls</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">AAC Block Advantages</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Lightweight and easy to handle</p>
                  <p>• Excellent thermal insulation</p>
                  <p>• Fire resistant up to 4 hours</p>
                  <p>• Earthquake resistant</p>
                  <p>• Faster construction time</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are AAC Blocks?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Autoclaved Aerated Concrete (AAC) blocks are lightweight, precast building materials that provide
                  structure, insulation, and fire resistance. They are made from cement, lime, sand, gypsum, and
                  aluminum powder, which creates air bubbles giving them their distinctive cellular structure. AAC
                  blocks are cured under heat and pressure in an autoclave, making them significantly lighter than
                  traditional clay bricks while maintaining excellent structural properties.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  AAC blocks offer numerous advantages including superior thermal insulation, fire resistance, sound
                  absorption, and faster construction times. They are eco-friendly, using fly ash as a primary raw
                  material, and consume less energy during production. The lightweight nature reduces dead load on
                  structures, allowing for more economical foundation designs and easier handling on construction sites.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate AAC Blocks</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating AAC block requirements involves determining the wall area and dividing by the face area of
                  individual blocks. The formula is: Number of blocks = (Wall length × Wall height) ÷ (Block length ×
                  Block height). Add 5-10% wastage for cutting, breakage, and fitting around openings. For example, a
                  10m × 3m wall needs approximately (10 × 3) ÷ (0.6 × 0.2) = 250 blocks, plus 5% wastage = 263 blocks.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Mortar quantity depends on joint thickness. AAC blocks typically use thin-joint mortar (6mm) which
                  requires significantly less material than standard 12mm joints. The mortar volume is calculated based
                  on joint area multiplied by thickness, then converted to dry volume and divided into cement and sand
                  according to the mix ratio (usually 1:4). Thin-joint mortar reduces material costs and construction
                  time while providing superior bonding.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <p className="text-amber-900 text-sm leading-relaxed m-0">
                    <strong>Disclaimer:</strong> These estimates are approximate. Actual blockwork depends on joint
                    thickness, block size variation, openings for doors and windows, and workmanship quality. AAC blocks
                    should be handled carefully to prevent damage. Store blocks on level ground covered with plastic
                    sheets. Use appropriate thin-joint mortar or adhesive for best results. Always verify calculations
                    with site conditions and consult structural engineers for load-bearing walls.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
