"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Activity, FlaskConical } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type TempUnit = "K" | "C"
type EnergyUnit = "kJ/mol" | "J/mol"

interface ActivationEnergyResult {
  value: number
  unit: string
}

export function ActivationEnergyCalculator() {
  const [tempUnit, setTempUnit] = useState<TempUnit>("K")
  const [energyUnit, setEnergyUnit] = useState<EnergyUnit>("kJ/mol")
  const [k1, setK1] = useState("")
  const [k2, setK2] = useState("")
  const [t1, setT1] = useState("")
  const [t2, setT2] = useState("")
  const [result, setResult] = useState<ActivationEnergyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const R = 8.314 // J/(mol·K)

  const toKelvin = (temp: number, unit: TempUnit): number => {
    return unit === "C" ? temp + 273.15 : temp
  }

  const convertEnergy = (energyJmol: number, unit: EnergyUnit): number => {
    return unit === "kJ/mol" ? energyJmol / 1000 : energyJmol
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const k1Val = Number.parseFloat(k1)
    const k2Val = Number.parseFloat(k2)
    const t1Val = Number.parseFloat(t1)
    const t2Val = Number.parseFloat(t2)

    if (isNaN(k1Val) || isNaN(k2Val) || isNaN(t1Val) || isNaN(t2Val)) {
      setError("Please enter valid numbers for all fields")
      return
    }

    if (k1Val <= 0 || k2Val <= 0) {
      setError("Rate constants must be positive values")
      return
    }

    const t1Kelvin = toKelvin(t1Val, tempUnit)
    const t2Kelvin = toKelvin(t2Val, tempUnit)

    if (t1Kelvin <= 0 || t2Kelvin <= 0) {
      setError("Temperatures must be above absolute zero")
      return
    }

    if (t1Kelvin === t2Kelvin) {
      setError("Temperatures must be different")
      return
    }

    // Ea = R × ln(k2/k1) / (1/T1 - 1/T2)
    const lnRatio = Math.log(k2Val / k1Val)
    const tempDiff = 1 / t1Kelvin - 1 / t2Kelvin

    const activationEnergyJmol = R * lnRatio / tempDiff
    const activationEnergy = convertEnergy(activationEnergyJmol, energyUnit)

    setResult({
      value: activationEnergy,
      unit: energyUnit,
    })
  }

  const handleReset = () => {
    setK1("")
    setK2("")
    setT1("")
    setT2("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Activation Energy: ${formatNumber(result.value)} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Activation Energy Calculator Result",
          text: `Activation Energy: ${formatNumber(result.value)} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.01 || Math.abs(num) >= 100000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 2 })
  }

  const toggleTempUnit = () => {
    setTempUnit((prev) => (prev === "K" ? "C" : "K"))
    setT1("")
    setT2("")
    setResult(null)
  }

  const toggleEnergyUnit = () => {
    setEnergyUnit((prev) => (prev === "kJ/mol" ? "J/mol" : "kJ/mol"))
    setResult(null)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Activation Energy Calculator</CardTitle>
                    <CardDescription>Calculate Ea from two temperature points</CardDescription>
                  </div>
                </div>

                {/* Temperature Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Temperature Unit</span>
                  <button
                    onClick={toggleTempUnit}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        tempUnit === "C" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        tempUnit === "K" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Kelvin
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        tempUnit === "C" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Celsius
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Condition 1 */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-purple-700">Condition 1</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="k1">Rate Constant (k₁)</Label>
                      <Input
                        id="k1"
                        type="number"
                        placeholder="e.g., 0.015"
                        value={k1}
                        onChange={(e) => setK1(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="t1">Temperature (T₁) {tempUnit === "K" ? "K" : "°C"}</Label>
                      <Input
                        id="t1"
                        type="number"
                        placeholder={tempUnit === "K" ? "e.g., 300" : "e.g., 27"}
                        value={t1}
                        onChange={(e) => setT1(e.target.value)}
                        step="any"
                      />
                    </div>
                  </div>
                </div>

                {/* Condition 2 */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-purple-700">Condition 2</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="k2">Rate Constant (k₂)</Label>
                      <Input
                        id="k2"
                        type="number"
                        placeholder="e.g., 0.045"
                        value={k2}
                        onChange={(e) => setK2(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="t2">Temperature (T₂) {tempUnit === "K" ? "K" : "°C"}</Label>
                      <Input
                        id="t2"
                        type="number"
                        placeholder={tempUnit === "K" ? "e.g., 320" : "e.g., 47"}
                        value={t2}
                        onChange={(e) => setT2(e.target.value)}
                        step="any"
                      />
                    </div>
                  </div>
                </div>

                {/* Energy Unit Toggle */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Energy Unit</span>
                  <button
                    onClick={toggleEnergyUnit}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        energyUnit === "J/mol" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        energyUnit === "kJ/mol" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      kJ/mol
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        energyUnit === "J/mol" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      J/mol
                    </span>
                  </button>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Activation Energy
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Activation Energy (Ea)</p>
                      <p className="text-5xl font-bold text-purple-600 mb-2">{formatNumber(result.value)}</p>
                      <p className="text-lg font-semibold text-purple-600">{result.unit}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Two-Point Arrhenius Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-4 bg-muted rounded-lg font-mono text-center">
                      <p className="font-semibold text-foreground">Ea = R × ln(k₂/k₁) / (1/T₁ - 1/T₂)</p>
                    </div>
                    <div className="text-sm text-muted-foreground space-y-2">
                      <p><strong>Ea</strong> = Activation energy</p>
                      <p><strong>R</strong> = 8.314 J/(mol·K)</p>
                      <p><strong>k₁, k₂</strong> = Rate constants</p>
                      <p><strong>T₁, T₂</strong> = Temperatures (K)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Values</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Enzyme-catalyzed</span>
                      <span className="text-sm text-green-600">20-80 kJ/mol</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Simple ionic</span>
                      <span className="text-sm text-blue-600">40-80 kJ/mol</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Most reactions</span>
                      <span className="text-sm text-yellow-600">40-400 kJ/mol</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Bond breaking</span>
                      <span className="text-sm text-red-600">150-500 kJ/mol</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Activation Energy */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Activation Energy?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Activation energy (Ea) is the minimum energy required for a chemical reaction to occur. It represents
                  the energy barrier that reactants must overcome to transform into products. This concept was introduced
                  by Svante Arrhenius in 1889 and is fundamental to understanding reaction kinetics and catalysis.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  At the molecular level, activation energy corresponds to the energy needed to break or weaken existing
                  bonds before new bonds can form. Only molecules with kinetic energy equal to or greater than the
                  activation energy can successfully undergo the chemical transformation.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How is Activation Energy Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The two-point method uses rate constants measured at two different temperatures to calculate activation
                  energy. By comparing how the reaction rate changes with temperature, we can determine the energy barrier
                  without needing to know the pre-exponential factor A.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This method derives from the Arrhenius equation: k = A × e^(-Ea/RT). By taking the ratio of rate
                  constants at two temperatures and applying logarithms, we eliminate the unknown A factor and can solve
                  directly for Ea.
                </p>
              </CardContent>
            </Card>

            {/* Physical Significance */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Physical Significance of Activation Energy</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Reactions with high activation energies proceed slowly at room temperature because few molecules have
                  sufficient energy to overcome the barrier. These reactions are highly sensitive to temperature changes.
                  A small temperature increase can dramatically increase the reaction rate by significantly increasing
                  the fraction of molecules with enough energy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Catalysts work by providing an alternative reaction pathway with a lower activation energy. This allows
                  more molecules to react at a given temperature, speeding up the reaction without being consumed
                  themselves. Understanding activation energy is crucial for industrial process optimization.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations of This Method</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The two-point method assumes that the activation energy remains constant over the temperature range
                  studied. For complex reactions or very wide temperature ranges, this assumption may not hold. The method
                  also assumes ideal Arrhenius behavior, which may not apply to all reaction types.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For more accurate results, especially for research applications, measuring rate constants at multiple
                  temperatures and using linear regression on an Arrhenius plot (ln k vs. 1/T) is recommended. This
                  approach provides both the activation energy and information about how well the data fits the Arrhenius
                  model.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
