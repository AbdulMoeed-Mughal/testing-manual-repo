"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Heart,
  Info,
  ChevronDown,
  ChevronUp,
  Calculator,
  Coins,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { formatCurrency, currencySymbols, type Currency } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

interface ZakatResult {
  totalAssets: number
  totalDebts: number
  netZakatableWealth: number
  nisaabThreshold: number
  meetsNisaab: boolean
  zakatAmount: number
  breakdown: {
    cash: number
    gold: number
    silver: number
    investments: number
    business: number
    other: number
  }
}

// Current approximate values for Nisaab calculation (in USD)
const GOLD_PRICE_PER_GRAM = 65 // USD per gram
const SILVER_PRICE_PER_GRAM = 0.8 // USD per gram
const NISAAB_GOLD_GRAMS = 87.48 // 7.5 tola = 87.48 grams
const NISAAB_SILVER_GRAMS = 612.36 // 52.5 tola = 612.36 grams
const ZAKAT_RATE = 0.025 // 2.5%

export function ZakatCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [nisaabType, setNisaabType] = useState<"gold" | "silver">("gold")

  // Asset inputs
  const [cashInHand, setCashInHand] = useState("")
  const [cashInBank, setCashInBank] = useState("")
  const [goldWeight, setGoldWeight] = useState("")
  const [goldPurity, setGoldPurity] = useState("24")
  const [silverWeight, setSilverWeight] = useState("")
  const [silverPurity, setSilverPurity] = useState("999")
  const [investments, setInvestments] = useState("")
  const [businessInventory, setBusinessInventory] = useState("")
  const [otherAssets, setOtherAssets] = useState("")

  // Liabilities
  const [debtsOwed, setDebtsOwed] = useState("")

  const [result, setResult] = useState<ZakatResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateZakat = () => {
    setError("")
    setResult(null)

    // Parse all inputs
    const cash = (Number.parseFloat(cashInHand) || 0) + (Number.parseFloat(cashInBank) || 0)
    const goldGrams = Number.parseFloat(goldWeight) || 0
    const goldPurityPercent = Number.parseFloat(goldPurity) / 24
    const silverGrams = Number.parseFloat(silverWeight) || 0
    const silverPurityPercent = Number.parseFloat(silverPurity) / 1000
    const investmentValue = Number.parseFloat(investments) || 0
    const businessValue = Number.parseFloat(businessInventory) || 0
    const otherValue = Number.parseFloat(otherAssets) || 0
    const debts = Number.parseFloat(debtsOwed) || 0

    // Calculate gold and silver values
    const goldValue = goldGrams * goldPurityPercent * GOLD_PRICE_PER_GRAM
    const silverValue = silverGrams * silverPurityPercent * SILVER_PRICE_PER_GRAM

    // Calculate total assets
    const totalAssets = cash + goldValue + silverValue + investmentValue + businessValue + otherValue

    if (totalAssets <= 0) {
      setError("Please enter at least one asset value greater than 0")
      return
    }

    // Calculate net zakatable wealth
    const netZakatableWealth = totalAssets - debts

    // Calculate Nisaab threshold based on selection
    const nisaabThreshold =
      nisaabType === "gold" ? NISAAB_GOLD_GRAMS * GOLD_PRICE_PER_GRAM : NISAAB_SILVER_GRAMS * SILVER_PRICE_PER_GRAM

    // Check if wealth meets Nisaab
    const meetsNisaab = netZakatableWealth >= nisaabThreshold

    // Calculate Zakat amount (2.5% if above Nisaab)
    const zakatAmount = meetsNisaab ? netZakatableWealth * ZAKAT_RATE : 0

    setResult({
      totalAssets,
      totalDebts: debts,
      netZakatableWealth,
      nisaabThreshold,
      meetsNisaab,
      zakatAmount,
      breakdown: {
        cash,
        gold: goldValue,
        silver: silverValue,
        investments: investmentValue,
        business: businessValue,
        other: otherValue,
      },
    })
  }

  const handleReset = () => {
    setCashInHand("")
    setCashInBank("")
    setGoldWeight("")
    setGoldPurity("24")
    setSilverWeight("")
    setSilverPurity("999")
    setInvestments("")
    setBusinessInventory("")
    setOtherAssets("")
    setDebtsOwed("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Zakat Calculation:\nTotal Assets: ${formatCurrency(result.totalAssets, currency)}\nNet Zakatable Wealth: ${formatCurrency(result.netZakatableWealth, currency)}\nZakat Due: ${formatCurrency(result.zakatAmount, currency)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Zakat Calculation",
          text: `I calculated my Zakat using CalcHub! Zakat Due: ${formatCurrency(result.zakatAmount, currency)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                    <Heart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Zakat Calculator</CardTitle>
                    <CardDescription>Calculate your annual Zakat obligation</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <CurrencySelector currency={currency} onCurrencyChange={setCurrency} />

                {/* Nisaab Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Nisaab Threshold</span>
                  <button
                    onClick={() => setNisaabType(nisaabType === "gold" ? "silver" : "gold")}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        nisaabType === "silver" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        nisaabType === "gold" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Gold
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        nisaabType === "silver" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Silver
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Cash Inputs */}
                <div className="space-y-2">
                  <Label>Cash & Bank Balances ({symbol})</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      type="number"
                      placeholder="Cash in hand"
                      value={cashInHand}
                      onChange={(e) => setCashInHand(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                    <Input
                      type="number"
                      placeholder="Cash in bank"
                      value={cashInBank}
                      onChange={(e) => setCashInBank(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Gold Input */}
                <div className="space-y-2">
                  <Label>Gold Holdings</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      type="number"
                      placeholder="Weight (grams)"
                      value={goldWeight}
                      onChange={(e) => setGoldWeight(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                    <select
                      value={goldPurity}
                      onChange={(e) => setGoldPurity(e.target.value)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <option value="24">24K (Pure)</option>
                      <option value="22">22K</option>
                      <option value="21">21K</option>
                      <option value="18">18K</option>
                      <option value="14">14K</option>
                    </select>
                  </div>
                </div>

                {/* Silver Input */}
                <div className="space-y-2">
                  <Label>Silver Holdings</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      type="number"
                      placeholder="Weight (grams)"
                      value={silverWeight}
                      onChange={(e) => setSilverWeight(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                    <select
                      value={silverPurity}
                      onChange={(e) => setSilverPurity(e.target.value)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <option value="999">999 (Pure)</option>
                      <option value="925">925 (Sterling)</option>
                      <option value="900">900</option>
                      <option value="800">800</option>
                    </select>
                  </div>
                </div>

                {/* Investments */}
                <div className="space-y-2">
                  <Label htmlFor="investments">Investments - Stocks, Bonds, etc. ({symbol})</Label>
                  <Input
                    id="investments"
                    type="number"
                    placeholder="Enter investment value"
                    value={investments}
                    onChange={(e) => setInvestments(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Additional Assets</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="business">Business Inventory ({symbol})</Label>
                      <Input
                        id="business"
                        type="number"
                        placeholder="Enter business inventory value"
                        value={businessInventory}
                        onChange={(e) => setBusinessInventory(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="other">Other Zakatable Assets ({symbol})</Label>
                      <Input
                        id="other"
                        type="number"
                        placeholder="Enter other assets value"
                        value={otherAssets}
                        onChange={(e) => setOtherAssets(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Debts */}
                <div className="space-y-2">
                  <Label htmlFor="debts">Outstanding Debts ({symbol})</Label>
                  <Input
                    id="debts"
                    type="number"
                    placeholder="Enter debts owed to others"
                    value={debtsOwed}
                    onChange={(e) => setDebtsOwed(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateZakat} className="w-full" size="lg">
                  Calculate Zakat
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.meetsNisaab ? "bg-emerald-50 border-emerald-200" : "bg-gray-50 border-gray-200"
                    }`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.meetsNisaab ? "Zakat Due" : "Below Nisaab - No Zakat Due"}
                      </p>
                      <p
                        className={`text-4xl font-bold mb-2 ${
                          result.meetsNisaab ? "text-emerald-600" : "text-gray-600"
                        }`}
                      >
                        {formatCurrency(result.zakatAmount, currency)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Net Zakatable Wealth: {formatCurrency(result.netZakatableWealth, currency)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Nisaab Threshold ({nisaabType}): {formatCurrency(result.nisaabThreshold, currency)}
                      </p>
                    </div>

                    {/* Asset Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3">
                          {showBreakdown ? "Hide" : "Show"} Asset Breakdown
                          {showBreakdown ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="space-y-2 text-sm">
                          {result.breakdown.cash > 0 && (
                            <div className="flex justify-between p-2 bg-white rounded-lg">
                              <span>Cash & Bank</span>
                              <span className="font-medium">{formatCurrency(result.breakdown.cash, currency)}</span>
                            </div>
                          )}
                          {result.breakdown.gold > 0 && (
                            <div className="flex justify-between p-2 bg-white rounded-lg">
                              <span>Gold Value</span>
                              <span className="font-medium">{formatCurrency(result.breakdown.gold, currency)}</span>
                            </div>
                          )}
                          {result.breakdown.silver > 0 && (
                            <div className="flex justify-between p-2 bg-white rounded-lg">
                              <span>Silver Value</span>
                              <span className="font-medium">{formatCurrency(result.breakdown.silver, currency)}</span>
                            </div>
                          )}
                          {result.breakdown.investments > 0 && (
                            <div className="flex justify-between p-2 bg-white rounded-lg">
                              <span>Investments</span>
                              <span className="font-medium">
                                {formatCurrency(result.breakdown.investments, currency)}
                              </span>
                            </div>
                          )}
                          {result.breakdown.business > 0 && (
                            <div className="flex justify-between p-2 bg-white rounded-lg">
                              <span>Business Inventory</span>
                              <span className="font-medium">{formatCurrency(result.breakdown.business, currency)}</span>
                            </div>
                          )}
                          {result.breakdown.other > 0 && (
                            <div className="flex justify-between p-2 bg-white rounded-lg">
                              <span>Other Assets</span>
                              <span className="font-medium">{formatCurrency(result.breakdown.other, currency)}</span>
                            </div>
                          )}
                          {result.totalDebts > 0 && (
                            <div className="flex justify-between p-2 bg-red-50 rounded-lg text-red-700">
                              <span>Less: Debts</span>
                              <span className="font-medium">-{formatCurrency(result.totalDebts, currency)}</span>
                            </div>
                          )}
                          <div className="flex justify-between p-2 bg-emerald-100 rounded-lg font-semibold">
                            <span>Total Zakatable</span>
                            <span>{formatCurrency(result.netZakatableWealth, currency)}</span>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Nisaab Thresholds</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <div>
                        <span className="font-medium text-yellow-800">Gold Nisaab</span>
                        <p className="text-xs text-yellow-600">87.48 grams (7.5 tola)</p>
                      </div>
                      <span className="text-sm text-yellow-700 font-medium">
                        ~{formatCurrency(NISAAB_GOLD_GRAMS * GOLD_PRICE_PER_GRAM, "USD")}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <div>
                        <span className="font-medium text-gray-800">Silver Nisaab</span>
                        <p className="text-xs text-gray-600">612.36 grams (52.5 tola)</p>
                      </div>
                      <span className="text-sm text-gray-700 font-medium">
                        ~{formatCurrency(NISAAB_SILVER_GRAMS * SILVER_PRICE_PER_GRAM, "USD")}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      * Values are approximate. Please verify current market prices.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Zakat Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Zakat = 2.5% × Net Zakatable Wealth</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>Net Zakatable Wealth =</strong>
                    </p>
                    <p className="pl-4">Cash + Gold + Silver + Investments + Business Assets - Debts</p>
                  </div>
                  <p className="text-xs">
                    Zakat is only due if net wealth exceeds the Nisaab threshold for one complete lunar year.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Zakatable Assets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start gap-2">
                      <Coins className="h-4 w-4 text-emerald-600 mt-0.5" />
                      <span>Cash, bank balances, savings</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Coins className="h-4 w-4 text-yellow-600 mt-0.5" />
                      <span>Gold and silver (jewelry, bars, coins)</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Coins className="h-4 w-4 text-blue-600 mt-0.5" />
                      <span>Stocks, bonds, mutual funds</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Coins className="h-4 w-4 text-purple-600 mt-0.5" />
                      <span>Business inventory and goods for trade</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Coins className="h-4 w-4 text-gray-600 mt-0.5" />
                      <span>Rental income, cryptocurrency</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Zakat?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Zakat is one of the Five Pillars of Islam and represents a mandatory form of charity. It is an
                  obligation upon every Muslim who possesses wealth above the Nisaab (minimum threshold) for one
                  complete lunar year. The word "Zakat" comes from the Arabic root meaning "to purify" or "to grow,"
                  signifying that paying Zakat purifies one's wealth and brings blessings.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The standard Zakat rate is 2.5% (1/40th) of one's net zakatable assets. This annual obligation helps
                  redistribute wealth within the Muslim community and provides support for those in need, including the
                  poor, those in debt, travelers, and others specified in Islamic teachings.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Zakat</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate Zakat, first determine your total zakatable assets including cash, gold, silver,
                  investments, and business inventory. Then subtract any outstanding debts you owe. If your net
                  zakatable wealth exceeds the Nisaab threshold and you have held this wealth for one lunar year, you
                  owe Zakat at 2.5% of the total.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <h4 className="font-semibold text-emerald-800 mb-1">Step 1: Add All Zakatable Assets</h4>
                    <p className="text-emerald-700 text-sm">
                      Include cash, bank balances, gold, silver, stocks, business goods, and receivables.
                    </p>
                  </div>
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <h4 className="font-semibold text-emerald-800 mb-1">Step 2: Subtract Liabilities</h4>
                    <p className="text-emerald-700 text-sm">
                      Deduct debts, bills due, and other financial obligations from the total.
                    </p>
                  </div>
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <h4 className="font-semibold text-emerald-800 mb-1">Step 3: Check Against Nisaab</h4>
                    <p className="text-emerald-700 text-sm">
                      Compare your net wealth to the Nisaab threshold (gold or silver equivalent).
                    </p>
                  </div>
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <h4 className="font-semibold text-emerald-800 mb-1">Step 4: Calculate 2.5%</h4>
                    <p className="text-emerald-700 text-sm">
                      If above Nisaab, multiply your net zakatable wealth by 2.5% to get your Zakat due.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Who Can Receive Zakat?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  According to Islamic teachings, there are eight categories of people eligible to receive Zakat:
                </p>
                <div className="mt-4 grid gap-2 sm:grid-cols-2">
                  <div className="p-2 bg-muted rounded text-sm">1. The poor (Al-Fuqara)</div>
                  <div className="p-2 bg-muted rounded text-sm">2. The needy (Al-Masakin)</div>
                  <div className="p-2 bg-muted rounded text-sm">3. Zakat administrators</div>
                  <div className="p-2 bg-muted rounded text-sm">4. Those whose hearts are to be reconciled</div>
                  <div className="p-2 bg-muted rounded text-sm">5. Those in bondage (freeing slaves)</div>
                  <div className="p-2 bg-muted rounded text-sm">6. Those in debt</div>
                  <div className="p-2 bg-muted rounded text-sm">7. In the cause of Allah</div>
                  <div className="p-2 bg-muted rounded text-sm">8. The wayfarer (stranded traveler)</div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  This Zakat calculator provides estimates based on entered values and general guidelines. The
                  calculations use approximate market values for gold and silver which may vary. Different schools of
                  Islamic jurisprudence may have varying opinions on certain aspects of Zakat calculation. Please
                  consult a qualified Islamic scholar or religious authority for precise Zakat obligations and to ensure
                  compliance with your specific school of thought.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
