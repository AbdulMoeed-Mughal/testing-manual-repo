"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Building, Info, Calculator, Package } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type WallType = "brick" | "block" | "rcc"
type MixRatio = "1:3" | "1:4" | "1:5" | "1:6" | "M15" | "M20"

interface WallResult {
  wallVolume: number
  dryVolume: number
  cement: { bags: number; kg: number }
  sand: { volume: number; kg: number }
  aggregate?: { volume: number; kg: number }
  bricksOrBlocks?: number
}

export function BoundaryWallCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [wallType, setWallType] = useState<WallType>("brick")
  const [length, setLength] = useState("")
  const [height, setHeight] = useState("")
  const [thickness, setThickness] = useState("")
  const [openings, setOpenings] = useState("")
  const [mixRatio, setMixRatio] = useState<MixRatio>("1:4")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<WallResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateWall = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const heightNum = Number.parseFloat(height)
    const thicknessNum = Number.parseFloat(thickness)
    const openingsNum = Number.parseFloat(openings) || 0
    const dryVolumeFactorNum = Number.parseFloat(dryVolumeFactor)
    const wastageNum = Number.parseFloat(wastage)

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid wall length greater than 0")
      return
    }

    if (isNaN(heightNum) || heightNum <= 0) {
      setError("Please enter a valid wall height greater than 0")
      return
    }

    if (isNaN(thicknessNum) || thicknessNum <= 0) {
      setError("Please enter a valid wall thickness greater than 0")
      return
    }

    if (isNaN(dryVolumeFactorNum) || dryVolumeFactorNum <= 0) {
      setError("Please enter a valid dry volume factor")
      return
    }

    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }

    // Convert to meters if imperial
    let lengthM = lengthNum
    let heightM = heightNum
    let thicknessM = thicknessNum
    let openingsM = openingsNum

    if (unitSystem === "imperial") {
      lengthM = lengthNum * 0.3048
      heightM = heightNum * 0.3048
      thicknessM = thicknessNum * 0.0254
      openingsM = openingsNum * 0.092903
    }

    // Calculate wall volume
    const wallVolume = lengthM * heightM * thicknessM - openingsM
    const dryVolume = wallVolume * dryVolumeFactorNum
    const wastageMultiplier = 1 + wastageNum / 100

    // Calculate based on wall type
    if (wallType === "rcc") {
      // RCC wall - calculate cement, sand, aggregate
      const ratio = mixRatio === "M15" ? "1:2:4" : mixRatio === "M20" ? "1:1.5:3" : mixRatio
      const parts = ratio.split(":").map((p) => Number.parseFloat(p))
      const totalParts = parts.reduce((sum, p) => sum + p, 0)

      const cementVolume = (dryVolume * parts[0]) / totalParts
      const sandVolume = (dryVolume * parts[1]) / totalParts
      const aggregateVolume = (dryVolume * parts[2]) / totalParts

      const cementKg = cementVolume * 1440 * wastageMultiplier // Cement density
      const cementBags = cementKg / 50

      setResult({
        wallVolume,
        dryVolume,
        cement: { bags: cementBags, kg: cementKg },
        sand: { volume: sandVolume * wastageMultiplier, kg: sandVolume * 1600 * wastageMultiplier },
        aggregate: {
          volume: aggregateVolume * wastageMultiplier,
          kg: aggregateVolume * 1450 * wastageMultiplier,
        },
      })
    } else {
      // Brick or Block wall
      const ratio = mixRatio.split(":").map((p) => Number.parseFloat(p))
      const totalParts = ratio.reduce((sum, p) => sum + p, 0)

      const mortarVolume = wallVolume * 0.3 // 30% mortar in masonry
      const dryMortarVolume = mortarVolume * dryVolumeFactorNum

      const cementVolume = (dryMortarVolume * ratio[0]) / totalParts
      const sandVolume = (dryMortarVolume * ratio[1]) / totalParts

      const cementKg = cementVolume * 1440 * wastageMultiplier
      const cementBags = cementKg / 50

      // Calculate number of bricks/blocks
      const unitVolume = wallType === "brick" ? 0.00189 : 0.020736 // Standard brick or block volume
      const bricksOrBlocks = Math.ceil((wallVolume / unitVolume) * wastageMultiplier)

      setResult({
        wallVolume,
        dryVolume: dryMortarVolume,
        cement: { bags: cementBags, kg: cementKg },
        sand: { volume: sandVolume * wastageMultiplier, kg: sandVolume * 1600 * wastageMultiplier },
        bricksOrBlocks,
      })
    }
  }

  const handleReset = () => {
    setLength("")
    setHeight("")
    setThickness("")
    setOpenings("")
    setMixRatio("1:4")
    setDryVolumeFactor("1.54")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Boundary Wall Calculator Results:\nWall Volume: ${result.wallVolume.toFixed(2)} m³\nCement: ${result.cement.bags.toFixed(0)} bags (${result.cement.kg.toFixed(0)} kg)\nSand: ${result.sand.volume.toFixed(2)} m³`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Boundary Wall Calculator Results",
          text: `Wall Volume: ${result.wallVolume.toFixed(2)} m³, Cement: ${result.cement.bags.toFixed(0)} bags`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setHeight("")
    setThickness("")
    setOpenings("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Building className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Boundary Wall Calculator</CardTitle>
                    <CardDescription>Calculate materials for boundary walls</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Wall Type */}
                <div className="space-y-2">
                  <Label htmlFor="wallType">Wall Type</Label>
                  <Select value={wallType} onValueChange={(value: WallType) => setWallType(value)}>
                    <SelectTrigger id="wallType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="brick">Brick Wall</SelectItem>
                      <SelectItem value="block">Block Wall</SelectItem>
                      <SelectItem value="rcc">RCC Wall</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder="Enter wall length"
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                <div className="space-y-2">
                  <Label htmlFor="height">Height ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="Enter wall height"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Thickness Input */}
                <div className="space-y-2">
                  <Label htmlFor="thickness">Thickness ({unitSystem === "metric" ? "m" : "in"})</Label>
                  <Input
                    id="thickness"
                    type="number"
                    placeholder="Enter wall thickness"
                    value={thickness}
                    onChange={(e) => setThickness(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Openings Input */}
                <div className="space-y-2">
                  <Label htmlFor="openings">Openings/Gates Area ({unitSystem === "metric" ? "m²" : "ft²"})</Label>
                  <Input
                    id="openings"
                    type="number"
                    placeholder="Optional: Enter total opening area"
                    value={openings}
                    onChange={(e) => setOpenings(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Mix Ratio */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="mixRatio">{wallType === "rcc" ? "Concrete Grade" : "Mortar Mix"}</Label>
                    <Select value={mixRatio} onValueChange={(value: MixRatio) => setMixRatio(value)}>
                      <SelectTrigger id="mixRatio">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {wallType === "rcc" ? (
                          <>
                            <SelectItem value="M15">M15 (1:2:4)</SelectItem>
                            <SelectItem value="M20">M20 (1:1.5:3)</SelectItem>
                            <SelectItem value="1:3">Custom 1:3</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="1:3">1:3 (Rich)</SelectItem>
                            <SelectItem value="1:4">1:4 (Standard)</SelectItem>
                            <SelectItem value="1:5">1:5 (Medium)</SelectItem>
                            <SelectItem value="1:6">1:6 (Lean)</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wastage">Wastage (%)</Label>
                    <Input
                      id="wastage"
                      type="number"
                      value={wastage}
                      onChange={(e) => setWastage(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWall} className="w-full" size="lg">
                  Calculate Materials
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Wall Volume</p>
                        <p className="text-3xl font-bold text-amber-600">{result.wallVolume.toFixed(2)} m³</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between p-2 bg-white rounded">
                          <span className="font-medium">Cement:</span>
                          <span className="text-amber-700">
                            {result.cement.bags.toFixed(0)} bags ({result.cement.kg.toFixed(0)} kg)
                          </span>
                        </div>
                        <div className="flex justify-between p-2 bg-white rounded">
                          <span className="font-medium">Sand:</span>
                          <span className="text-amber-700">
                            {result.sand.volume.toFixed(2)} m³ ({result.sand.kg.toFixed(0)} kg)
                          </span>
                        </div>
                        {result.aggregate && (
                          <div className="flex justify-between p-2 bg-white rounded">
                            <span className="font-medium">Aggregate:</span>
                            <span className="text-amber-700">
                              {result.aggregate.volume.toFixed(2)} m³ ({result.aggregate.kg.toFixed(0)} kg)
                            </span>
                          </div>
                        )}
                        {result.bricksOrBlocks && (
                          <div className="flex justify-between p-2 bg-white rounded">
                            <span className="font-medium">{wallType === "brick" ? "Bricks:" : "Blocks:"}</span>
                            <span className="text-amber-700">{result.bricksOrBlocks.toLocaleString()} units</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Wall Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Brick Wall</h4>
                      <p className="text-sm text-amber-700">Traditional masonry using clay or concrete bricks</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Block Wall</h4>
                      <p className="text-sm text-amber-700">Larger concrete or AAC blocks for faster construction</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">RCC Wall</h4>
                      <p className="text-sm text-amber-700">Reinforced concrete for higher strength and durability</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Dimensions</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Standard Brick</p>
                    <p>230 × 115 × 75 mm</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Standard Block</p>
                    <p>400 × 200 × 200 mm</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Common Thickness</p>
                    <p>4 in (100mm) to 9 in (230mm)</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Boundary Wall */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Boundary Wall?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A boundary wall, also known as a fence or compound wall, is a vertical structure that encloses or
                  borders a property, serving multiple essential functions. It acts as a physical barrier that marks
                  property lines, provides security against trespassing, offers privacy from neighbors and
                  passersby, and can enhance the aesthetic appeal of a property. Boundary walls are constructed using
                  various materials including bricks, concrete blocks, reinforced concrete (RCC), or a combination of
                  these materials depending on requirements, budget, and local building codes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The choice of wall type significantly impacts construction costs, durability, and maintenance
                  requirements. Brick walls offer traditional aesthetics and good structural integrity, block walls
                  provide faster construction with larger units, while RCC walls deliver maximum strength suitable for
                  areas requiring heightened security or where the wall must support additional loads. Understanding
                  material quantities helps in accurate budgeting, procurement planning, and ensuring efficient
                  construction without material shortages or excessive wastage.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Boundary Wall Materials?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating materials for a boundary wall involves several systematic steps. First, determine the
                  wall volume by multiplying length, height, and thickness, then subtracting any openings for gates
                  or doors. For masonry walls (brick or block), approximately 30% of the wall volume consists of
                  mortar, while 70% is the masonry units. Apply the dry volume factor (typically 1.54) to convert wet
                  mortar volume to dry material quantities, accounting for the compaction that occurs during mixing
                  and application.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For RCC walls, use the specified concrete mix ratio to determine proportions of cement, sand, and
                  aggregate. Standard densities help convert volumes to weights: cement is approximately 1440 kg/m³,
                  sand 1600 kg/m³, and aggregate 1450 kg/m³. Always add a wastage factor (typically 5-10%) to account
                  for cutting losses, spillage, and material handling inefficiencies. For brick or block quantities,
                  divide the net masonry volume by the individual unit volume, considering standard sizes or actual
                  dimensions of materials being used.
                </p>
              </CardContent>
            </Card>

            {/* Tips and Considerations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  <CardTitle>Construction Tips & Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When planning boundary wall construction, several important factors deserve careful consideration.
                  The foundation depth and width must be adequate for the wall height and soil conditions – typically
                  foundations should be at least one-third the wall height and extend below the frost line in cold
                  climates. Wall thickness affects both material quantities and structural stability; taller walls
                  require greater thickness or additional reinforcement such as pilasters or buttresses at regular
                  intervals to prevent lateral movement or collapse.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Check local building codes and regulations before construction, as many jurisdictions have specific
                  requirements for boundary wall height, setback distances from property lines, and structural
                  specifications. Consider drainage provisions to prevent water accumulation against the wall, which
                  can cause deterioration and structural issues. For areas with significant height differences or
                  slopes, stepped foundations or retaining wall designs may be necessary. Quality of materials,
                  proper mortar mixing, adequate curing of concrete or mortar joints, and skilled workmanship all
                  significantly impact the wall's longevity and performance.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Material quantities calculated by this tool are approximate estimates
                  based on standard formulas and assumptions. Actual material requirements can vary based on brick or
                  block sizes, mortar thickness, joint quality, site conditions, workmanship quality, and construction
                  methods employed. Always consult with structural engineers or experienced contractors for critical
                  projects, obtain multiple material quotes, and order slightly more than calculated quantities to
                  account for unforeseen circumstances. This calculator is intended for planning and estimation
                  purposes only and should not replace professional engineering advice for structural designs.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
