"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Droplets, Activity } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type TitrationType = "strong-strong" | "strong-weak" | "weak-strong" | "weak-weak"
type VolumeUnit = "mL" | "L"

interface TitrationResult {
  pH: number
  equivalenceVolume: number
  molesAnalyte: number
  molesTitrant: number
  region: string
  color: string
  bgColor: string
}

export function TitrationCalculator() {
  const [titrationType, setTitrationType] = useState<TitrationType>("strong-strong")
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("mL")
  const [titrantConc, setTitrantConc] = useState("")
  const [titrantVolume, setTitrantVolume] = useState("")
  const [analyteConc, setAnalyteConc] = useState("")
  const [analyteVolume, setAnalyteVolume] = useState("")
  const [pKa, setPKa] = useState("")
  const [result, setResult] = useState<TitrationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateTitration = () => {
    setError("")
    setResult(null)

    const titrantConcNum = Number.parseFloat(titrantConc)
    const titrantVolumeNum = Number.parseFloat(titrantVolume)
    const analyteConcNum = Number.parseFloat(analyteConc)
    const analyteVolumeNum = Number.parseFloat(analyteVolume)

    if (isNaN(titrantConcNum) || titrantConcNum <= 0) {
      setError("Please enter a valid titrant concentration greater than 0")
      return
    }
    if (isNaN(titrantVolumeNum) || titrantVolumeNum < 0) {
      setError("Please enter a valid titrant volume (0 or greater)")
      return
    }
    if (isNaN(analyteConcNum) || analyteConcNum <= 0) {
      setError("Please enter a valid analyte concentration greater than 0")
      return
    }
    if (isNaN(analyteVolumeNum) || analyteVolumeNum <= 0) {
      setError("Please enter a valid analyte volume greater than 0")
      return
    }

    // Convert to liters if needed
    const volumeMultiplier = volumeUnit === "mL" ? 0.001 : 1
    const titrantVolumeL = titrantVolumeNum * volumeMultiplier
    const analyteVolumeL = analyteVolumeNum * volumeMultiplier

    // Calculate moles
    const molesAnalyte = analyteConcNum * analyteVolumeL
    const molesTitrant = titrantConcNum * titrantVolumeL

    // Calculate equivalence point volume
    const equivalenceVolume = molesAnalyte / titrantConcNum / volumeMultiplier

    // Calculate pH based on titration type and progress
    let pH: number
    let region: string
    let color: string
    let bgColor: string

    const totalVolume = analyteVolumeL + titrantVolumeL
    const fractionTitrated = molesTitrant / molesAnalyte

    if (titrationType === "strong-strong") {
      // Strong acid - Strong base titration
      if (fractionTitrated < 0.999) {
        // Before equivalence point - excess acid
        const excessH = (molesAnalyte - molesTitrant) / totalVolume
        pH = -Math.log10(excessH)
        region = "Before Equivalence"
        color = "text-red-600"
        bgColor = "bg-red-50 border-red-200"
      } else if (fractionTitrated > 1.001) {
        // After equivalence point - excess base
        const excessOH = (molesTitrant - molesAnalyte) / totalVolume
        const pOH = -Math.log10(excessOH)
        pH = 14 - pOH
        region = "After Equivalence"
        color = "text-blue-600"
        bgColor = "bg-blue-50 border-blue-200"
      } else {
        // At equivalence point
        pH = 7.0
        region = "At Equivalence Point"
        color = "text-green-600"
        bgColor = "bg-green-50 border-green-200"
      }
    } else if (titrationType === "weak-strong" || titrationType === "strong-weak") {
      const pKaNum = Number.parseFloat(pKa)
      if (isNaN(pKaNum) || pKaNum <= 0 || pKaNum >= 14) {
        setError("Please enter a valid pKa value between 0 and 14")
        return
      }

      const Ka = Math.pow(10, -pKaNum)
      
      if (titrationType === "weak-strong") {
        // Weak acid titrated with strong base
        if (fractionTitrated < 0.001) {
          // Initial pH of weak acid
          const H = Math.sqrt(Ka * analyteConcNum)
          pH = -Math.log10(H)
          region = "Initial (Weak Acid)"
          color = "text-orange-600"
          bgColor = "bg-orange-50 border-orange-200"
        } else if (fractionTitrated < 0.999) {
          // Buffer region - Henderson-Hasselbalch
          const acidRemaining = molesAnalyte - molesTitrant
          const conjugateBase = molesTitrant
          pH = pKaNum + Math.log10(conjugateBase / acidRemaining)
          region = "Buffer Region"
          color = "text-yellow-600"
          bgColor = "bg-yellow-50 border-yellow-200"
        } else if (fractionTitrated > 1.001) {
          // After equivalence - excess strong base
          const excessOH = (molesTitrant - molesAnalyte) / totalVolume
          const pOH = -Math.log10(excessOH)
          pH = 14 - pOH
          region = "After Equivalence"
          color = "text-blue-600"
          bgColor = "bg-blue-50 border-blue-200"
        } else {
          // At equivalence - conjugate base solution
          const conjugateBaseConc = molesAnalyte / totalVolume
          const Kb = 1e-14 / Ka
          const OH = Math.sqrt(Kb * conjugateBaseConc)
          const pOH = -Math.log10(OH)
          pH = 14 - pOH
          region = "At Equivalence Point"
          color = "text-green-600"
          bgColor = "bg-green-50 border-green-200"
        }
      } else {
        // Strong acid titrated with weak base
        const Kb = Math.pow(10, -pKaNum)
        const pKb = pKaNum
        
        if (fractionTitrated < 0.999) {
          // Before equivalence - excess strong acid
          const excessH = (molesAnalyte - molesTitrant) / totalVolume
          pH = -Math.log10(excessH)
          region = "Before Equivalence"
          color = "text-red-600"
          bgColor = "bg-red-50 border-red-200"
        } else if (fractionTitrated > 1.001) {
          // After equivalence - buffer region
          const excessBase = molesTitrant - molesAnalyte
          const conjugateAcid = molesAnalyte
          const pOH = pKb + Math.log10(conjugateAcid / excessBase)
          pH = 14 - pOH
          region = "After Equivalence"
          color = "text-blue-600"
          bgColor = "bg-blue-50 border-blue-200"
        } else {
          // At equivalence - conjugate acid solution
          const conjugateAcidConc = molesAnalyte / totalVolume
          const KaConj = 1e-14 / Kb
          const H = Math.sqrt(KaConj * conjugateAcidConc)
          pH = -Math.log10(H)
          region = "At Equivalence Point"
          color = "text-green-600"
          bgColor = "bg-green-50 border-green-200"
        }
      }
    } else {
      // Weak acid - Weak base (simplified)
      const pKaNum = Number.parseFloat(pKa)
      if (isNaN(pKaNum) || pKaNum <= 0 || pKaNum >= 14) {
        setError("Please enter a valid pKa value between 0 and 14")
        return
      }
      
      // Approximation for weak-weak titration
      pH = 7 + (pKaNum - 7) * (1 - fractionTitrated)
      region = fractionTitrated < 0.999 ? "Before Equivalence" : fractionTitrated > 1.001 ? "After Equivalence" : "At Equivalence Point"
      color = fractionTitrated < 0.999 ? "text-orange-600" : fractionTitrated > 1.001 ? "text-blue-600" : "text-green-600"
      bgColor = fractionTitrated < 0.999 ? "bg-orange-50 border-orange-200" : fractionTitrated > 1.001 ? "bg-blue-50 border-blue-200" : "bg-green-50 border-green-200"
    }

    // Clamp pH to valid range
    pH = Math.max(0, Math.min(14, pH))

    setResult({
      pH: Math.round(pH * 100) / 100,
      equivalenceVolume: Math.round(equivalenceVolume * 1000) / 1000,
      molesAnalyte: molesAnalyte,
      molesTitrant: molesTitrant,
      region,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setTitrantConc("")
    setTitrantVolume("")
    setAnalyteConc("")
    setAnalyteVolume("")
    setPKa("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Titration Result: pH = ${result.pH}, Equivalence Volume = ${result.equivalenceVolume} ${volumeUnit}, Region: ${result.region}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Titration Calculator Result",
          text: `Titration Result: pH = ${result.pH}, Equivalence Volume = ${result.equivalenceVolume} ${volumeUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleVolumeUnit = () => {
    setVolumeUnit((prev) => (prev === "mL" ? "L" : "mL"))
    setResult(null)
  }

  const needsPKa = titrationType !== "strong-strong"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Titration Calculator</CardTitle>
                    <CardDescription>Calculate pH at any point in a titration</CardDescription>
                  </div>
                </div>

                {/* Volume Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Volume Unit</span>
                  <button
                    onClick={toggleVolumeUnit}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        volumeUnit === "L" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        volumeUnit === "mL" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      mL
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        volumeUnit === "L" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      L
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Titration Type */}
                <div className="space-y-2">
                  <Label>Titration Type</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "strong-strong", label: "Strong-Strong" },
                      { value: "weak-strong", label: "Weak Acid-Strong Base" },
                      { value: "strong-weak", label: "Strong Acid-Weak Base" },
                      { value: "weak-weak", label: "Weak-Weak" },
                    ].map((type) => (
                      <button
                        key={type.value}
                        onClick={() => {
                          setTitrationType(type.value as TitrationType)
                          setResult(null)
                        }}
                        className={`p-2 text-xs rounded-lg border transition-colors ${
                          titrationType === type.value
                            ? "bg-purple-50 border-purple-300 text-purple-700"
                            : "bg-background hover:bg-muted"
                        }`}
                      >
                        {type.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Analyte Inputs */}
                <div className="space-y-2">
                  <Label className="text-purple-700 font-semibold">Analyte (Sample)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="analyteConc" className="text-xs text-muted-foreground">Concentration (M)</Label>
                      <Input
                        id="analyteConc"
                        type="number"
                        placeholder="0.1"
                        value={analyteConc}
                        onChange={(e) => setAnalyteConc(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div>
                      <Label htmlFor="analyteVolume" className="text-xs text-muted-foreground">Volume ({volumeUnit})</Label>
                      <Input
                        id="analyteVolume"
                        type="number"
                        placeholder="25"
                        value={analyteVolume}
                        onChange={(e) => setAnalyteVolume(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                </div>

                {/* Titrant Inputs */}
                <div className="space-y-2">
                  <Label className="text-purple-700 font-semibold">Titrant (Added Solution)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="titrantConc" className="text-xs text-muted-foreground">Concentration (M)</Label>
                      <Input
                        id="titrantConc"
                        type="number"
                        placeholder="0.1"
                        value={titrantConc}
                        onChange={(e) => setTitrantConc(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div>
                      <Label htmlFor="titrantVolume" className="text-xs text-muted-foreground">Volume Added ({volumeUnit})</Label>
                      <Input
                        id="titrantVolume"
                        type="number"
                        placeholder="0"
                        value={titrantVolume}
                        onChange={(e) => setTitrantVolume(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                </div>

                {/* pKa Input (conditional) */}
                {needsPKa && (
                  <div className="space-y-2">
                    <Label htmlFor="pka">
                      {titrationType === "strong-weak" ? "pKb of Weak Base" : "pKa of Weak Acid"}
                    </Label>
                    <Input
                      id="pka"
                      type="number"
                      placeholder={titrationType === "weak-strong" ? "e.g., 4.76 for acetic acid" : "e.g., 4.75 for ammonia"}
                      value={pKa}
                      onChange={(e) => setPKa(e.target.value)}
                      min="0"
                      max="14"
                      step="0.01"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTitration} className="w-full" size="lg">
                  Calculate pH
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">pH at Current Point</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.pH}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.region}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Equivalence Volume</p>
                        <p className="font-semibold">{result.equivalenceVolume} {volumeUnit}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Moles Analyte</p>
                        <p className="font-semibold">{result.molesAnalyte.toExponential(3)}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Titration Regions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Initial Point</span>
                      <span className="text-sm text-orange-600">No titrant added</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Buffer Region</span>
                      <span className="text-sm text-yellow-600">Before equivalence</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Equivalence Point</span>
                      <span className="text-sm text-green-600">Moles equal</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">After Equivalence</span>
                      <span className="text-sm text-blue-600">Excess titrant</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">n = C × V</p>
                    <p className="text-xs mt-1">moles = concentration × volume</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">pH = pKa + log([A⁻]/[HA])</p>
                    <p className="text-xs mt-1">Henderson-Hasselbalch (buffer region)</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Detailed Content Cards */}
          <div className="mt-12 space-y-8">
            {/* What is Titration */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Acid-Base Titration?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Acid-base titration is a quantitative analytical technique used to determine the concentration of an 
                  unknown acid or base solution by reacting it with a solution of known concentration (the titrant). 
                  During the titration, the titrant is gradually added to the analyte until the reaction reaches its 
                  equivalence point—the point at which stoichiometrically equivalent amounts of acid and base have reacted.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The pH of the solution changes throughout the titration process, creating a characteristic titration curve. 
                  Understanding these pH changes is crucial for selecting appropriate indicators and interpreting results. 
                  This calculator helps you determine the pH at any point during a titration based on the volumes and 
                  concentrations of the solutions involved.
                </p>
              </CardContent>
            </Card>

            {/* How Titration Works */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How Titration Calculations Work</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The pH calculation during titration depends on the type of acid-base reaction and the amount of titrant 
                  added. For strong acid-strong base titrations, the pH is determined by the excess H⁺ or OH⁻ ions present 
                  after partial neutralization. At the equivalence point of such titrations, the pH is exactly 7.0.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For titrations involving weak acids or bases, the Henderson-Hasselbalch equation becomes essential in 
                  the buffer region: pH = pKa + log([A⁻]/[HA]). The equivalence point pH is not 7.0 for weak acid-strong 
                  base titrations (pH greater than 7) or strong acid-weak base titrations (pH less than 7) because the conjugate 
                  species formed affects the solution pH.
                </p>
              </CardContent>
            </Card>

            {/* Types of Titrations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Acid-Base Titrations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="mt-2 space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Strong Acid - Strong Base</h4>
                    <p className="text-purple-700 text-sm">
                      The most straightforward titration type. The equivalence point pH is exactly 7.0. Examples include 
                      HCl with NaOH or H₂SO₄ with KOH. The titration curve shows a sharp vertical rise at the equivalence point.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Weak Acid - Strong Base</h4>
                    <p className="text-purple-700 text-sm">
                      Common in laboratory practice. The equivalence point pH is greater than 7 due to the basic conjugate 
                      formed. A buffer region exists before the equivalence point. Example: acetic acid with NaOH.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Strong Acid - Weak Base</h4>
                    <p className="text-purple-700 text-sm">
                      The equivalence point pH is less than 7 because the conjugate acid of the weak base is formed. 
                      Example: HCl with ammonia (NH₃).
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Weak Acid - Weak Base</h4>
                    <p className="text-purple-700 text-sm">
                      The most complex case with no sharp equivalence point. The pH change is gradual throughout, 
                      making endpoint detection difficult. Special indicators or potentiometric methods are often needed.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations and Assumptions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator assumes ideal solution behavior and complete dissociation of strong acids and bases. 
                  In real laboratory conditions, factors such as temperature, ionic strength, and activity coefficients 
                  can affect the actual pH values observed. The calculations also assume a 1:1 stoichiometric ratio 
                  between the acid and base.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For polyprotic acids (acids that can donate more than one proton), multiple equivalence points exist, 
                  and the calculations become more complex. This calculator handles monoprotic acids and bases. For 
                  more complex systems, consider the individual dissociation steps and their respective equilibrium constants.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The weak-weak titration calculations provided are simplified approximations. In practice, these 
                  titrations are rarely performed due to the poorly defined equivalence points and the difficulty 
                  in detecting the endpoint.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-purple-500" />
                  <CardTitle>Applications of Titration</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Acid-base titrations have numerous practical applications across various fields. In the food industry, 
                  titrations determine the acidity of products like vinegar, wine, and fruit juices. Environmental 
                  scientists use titrations to measure the alkalinity of water samples and assess acid rain impacts.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In pharmaceutical analysis, titrations verify the purity and concentration of drug formulations. 
                  Clinical laboratories use titration techniques for measuring bicarbonate levels in blood samples. 
                  Industrial applications include quality control in manufacturing processes for acids, bases, and 
                  buffer solutions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding titration calculations helps students and professionals design experiments, select 
                  appropriate indicators, and interpret results accurately. The ability to predict pH changes 
                  throughout a titration is fundamental to analytical chemistry education and practice.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
