"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, AlertTriangle, Gauge, Settings } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

type CalculationMethod = "linear-speed" | "gear-ratio"

interface RPMResult {
  rpm: number
  rps: number
  angularVelocity: number
  outputRPM?: number
  steps: string[]
}

const speedUnits = [
  { value: "m/s", label: "m/s", toMPS: 1 },
  { value: "km/h", label: "km/h", toMPS: 1 / 3.6 },
  { value: "ft/min", label: "ft/min", toMPS: 0.00508 },
  { value: "ft/s", label: "ft/s", toMPS: 0.3048 },
  { value: "mph", label: "mph", toMPS: 0.44704 },
]

const diameterUnits = [
  { value: "m", label: "meters (m)", toM: 1 },
  { value: "cm", label: "centimeters (cm)", toM: 0.01 },
  { value: "mm", label: "millimeters (mm)", toM: 0.001 },
  { value: "in", label: "inches (in)", toM: 0.0254 },
  { value: "ft", label: "feet (ft)", toM: 0.3048 },
]

export function RPMCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("linear-speed")
  const [linearSpeed, setLinearSpeed] = useState("")
  const [speedUnit, setSpeedUnit] = useState("m/s")
  const [diameter, setDiameter] = useState("")
  const [diameterUnit, setDiameterUnit] = useState("m")
  const [inputRPM, setInputRPM] = useState("")
  const [drivingTeeth, setDrivingTeeth] = useState("")
  const [drivenTeeth, setDrivenTeeth] = useState("")
  const [result, setResult] = useState<RPMResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateRPM = () => {
    setError("")
    setResult(null)

    const steps: string[] = []

    if (method === "linear-speed") {
      const speedNum = Number.parseFloat(linearSpeed)
      const diameterNum = Number.parseFloat(diameter)

      if (isNaN(speedNum) || speedNum < 0) {
        setError("Please enter a valid linear speed (≥ 0)")
        return
      }
      if (isNaN(diameterNum) || diameterNum <= 0) {
        setError("Please enter a valid diameter greater than 0")
        return
      }

      const speedConversion = speedUnits.find((u) => u.value === speedUnit)?.toMPS || 1
      const diameterConversion = diameterUnits.find((u) => u.value === diameterUnit)?.toM || 1

      const speedMPS = speedNum * speedConversion
      const diameterM = diameterNum * diameterConversion

      steps.push(`Step 1: Convert linear speed to m/s`)
      steps.push(`v = ${speedNum} ${speedUnit} = ${speedMPS.toFixed(4)} m/s`)

      steps.push(`Step 2: Convert diameter to meters`)
      steps.push(`d = ${diameterNum} ${diameterUnit} = ${diameterM.toFixed(4)} m`)

      steps.push(`Step 3: Calculate circumference`)
      const circumference = Math.PI * diameterM
      steps.push(`C = π × d = π × ${diameterM.toFixed(4)} = ${circumference.toFixed(4)} m`)

      steps.push(`Step 4: Calculate revolutions per second (RPS)`)
      const rps = speedMPS / circumference
      steps.push(`RPS = v / C = ${speedMPS.toFixed(4)} / ${circumference.toFixed(4)} = ${rps.toFixed(4)} rev/s`)

      steps.push(`Step 5: Convert to RPM`)
      const rpm = rps * 60
      steps.push(`RPM = RPS × 60 = ${rps.toFixed(4)} × 60 = ${rpm.toFixed(2)} RPM`)

      const angularVelocity = (2 * Math.PI * rpm) / 60

      setResult({
        rpm: Math.round(rpm * 100) / 100,
        rps: Math.round(rps * 1000) / 1000,
        angularVelocity: Math.round(angularVelocity * 1000) / 1000,
        steps,
      })
    } else {
      const inputRPMNum = Number.parseFloat(inputRPM)
      const drivingTeethNum = Number.parseFloat(drivingTeeth)
      const drivenTeethNum = Number.parseFloat(drivenTeeth)

      if (isNaN(inputRPMNum) || inputRPMNum < 0) {
        setError("Please enter a valid input RPM (≥ 0)")
        return
      }
      if (isNaN(drivingTeethNum) || drivingTeethNum <= 0 || !Number.isInteger(drivingTeethNum)) {
        setError("Please enter a valid number of driving gear teeth (positive integer)")
        return
      }
      if (isNaN(drivenTeethNum) || drivenTeethNum <= 0 || !Number.isInteger(drivenTeethNum)) {
        setError("Please enter a valid number of driven gear teeth (positive integer)")
        return
      }

      steps.push(`Step 1: Identify gear teeth counts`)
      steps.push(`Driving gear teeth (T₁) = ${drivingTeethNum}`)
      steps.push(`Driven gear teeth (T₂) = ${drivenTeethNum}`)

      steps.push(`Step 2: Calculate gear ratio`)
      const gearRatio = drivingTeethNum / drivenTeethNum
      steps.push(`Gear Ratio = T₁ / T₂ = ${drivingTeethNum} / ${drivenTeethNum} = ${gearRatio.toFixed(4)}`)

      steps.push(`Step 3: Calculate output RPM`)
      const outputRPM = inputRPMNum * gearRatio
      steps.push(`RPM_output = RPM_input × Gear Ratio`)
      steps.push(`RPM_output = ${inputRPMNum} × ${gearRatio.toFixed(4)} = ${outputRPM.toFixed(2)} RPM`)

      const rps = outputRPM / 60
      const angularVelocity = (2 * Math.PI * outputRPM) / 60

      setResult({
        rpm: Math.round(outputRPM * 100) / 100,
        rps: Math.round(rps * 1000) / 1000,
        angularVelocity: Math.round(angularVelocity * 1000) / 1000,
        outputRPM: Math.round(outputRPM * 100) / 100,
        steps,
      })
    }
  }

  const handleReset = () => {
    setLinearSpeed("")
    setDiameter("")
    setInputRPM("")
    setDrivingTeeth("")
    setDrivenTeeth("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        method === "linear-speed"
          ? `RPM: ${result.rpm}, RPS: ${result.rps}, Angular Velocity: ${result.angularVelocity} rad/s`
          : `Output RPM: ${result.rpm}, Gear Ratio: ${(Number(drivingTeeth) / Number(drivenTeeth)).toFixed(4)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "RPM Calculator Result",
          text: `Rotational Speed: ${result.rpm} RPM (${result.rps} RPS)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">RPM Calculator</CardTitle>
                    <CardDescription>Calculate rotational speed</CardDescription>
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <Label className="text-sm font-medium">Calculation Method</Label>
                  <Select value={method} onValueChange={(v) => setMethod(v as CalculationMethod)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="linear-speed">From Linear Speed & Diameter</SelectItem>
                      <SelectItem value="gear-ratio">From Gear Ratio</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {method === "linear-speed" ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="linearSpeed">Linear Speed</Label>
                      <div className="flex gap-2">
                        <Input
                          id="linearSpeed"
                          type="number"
                          placeholder="Enter speed"
                          value={linearSpeed}
                          onChange={(e) => setLinearSpeed(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <Select value={speedUnit} onValueChange={setSpeedUnit}>
                          <SelectTrigger className="w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {speedUnits.map((unit) => (
                              <SelectItem key={unit.value} value={unit.value}>
                                {unit.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="diameter">Diameter of Rotating Object</Label>
                      <div className="flex gap-2">
                        <Input
                          id="diameter"
                          type="number"
                          placeholder="Enter diameter"
                          value={diameter}
                          onChange={(e) => setDiameter(e.target.value)}
                          min="0"
                          step="0.001"
                          className="flex-1"
                        />
                        <Select value={diameterUnit} onValueChange={setDiameterUnit}>
                          <SelectTrigger className="w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {diameterUnits.map((unit) => (
                              <SelectItem key={unit.value} value={unit.value}>
                                {unit.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="inputRPM">Input RPM</Label>
                      <Input
                        id="inputRPM"
                        type="number"
                        placeholder="Enter input shaft RPM"
                        value={inputRPM}
                        onChange={(e) => setInputRPM(e.target.value)}
                        min="0"
                        step="1"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="drivingTeeth">Driving Gear Teeth (T₁)</Label>
                        <Input
                          id="drivingTeeth"
                          type="number"
                          placeholder="e.g., 20"
                          value={drivingTeeth}
                          onChange={(e) => setDrivingTeeth(e.target.value)}
                          min="1"
                          step="1"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="drivenTeeth">Driven Gear Teeth (T₂)</Label>
                        <Input
                          id="drivenTeeth"
                          type="number"
                          placeholder="e.g., 40"
                          value={drivenTeeth}
                          onChange={(e) => setDrivenTeeth(e.target.value)}
                          min="1"
                          step="1"
                        />
                      </div>
                    </div>
                  </>
                )}

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateRPM} className="w-full" size="lg">
                  Calculate RPM
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Rotational Speed</p>
                      <p className="text-4xl font-bold text-orange-600 mb-1">{result.rpm.toLocaleString()}</p>
                      <p className="text-lg font-semibold text-orange-600">RPM</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg border border-orange-100 text-center">
                        <p className="text-xs text-muted-foreground">Revs per Second</p>
                        <p className="text-lg font-semibold text-foreground">{result.rps} RPS</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border border-orange-100 text-center">
                        <p className="text-xs text-muted-foreground">Angular Velocity</p>
                        <p className="text-lg font-semibold text-foreground">{result.angularVelocity} rad/s</p>
                      </div>
                    </div>

                    {method === "gear-ratio" && drivingTeeth && drivenTeeth && (
                      <div className="mt-3 p-3 bg-white rounded-lg border border-orange-100 text-center">
                        <p className="text-xs text-muted-foreground">Gear Ratio</p>
                        <p className="text-lg font-semibold text-foreground">
                          {(Number(drivingTeeth) / Number(drivenTeeth)).toFixed(4)} : 1
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {Number(drivingTeeth) > Number(drivenTeeth) ? "Speed Increase" : "Speed Reduction"}
                        </p>
                      </div>
                    )}

                    <Collapsible open={showSteps} onOpenChange={setShowSteps} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full bg-transparent">
                          <ChevronDown
                            className={`h-4 w-4 mr-2 transition-transform ${showSteps ? "rotate-180" : ""}`}
                          />
                          {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="p-3 bg-white rounded-lg border border-orange-100 text-sm space-y-1">
                          {result.steps.map((step, index) => (
                            <p
                              key={index}
                              className={step.startsWith("Step") ? "font-semibold mt-2" : "text-muted-foreground ml-2"}
                            >
                              {step}
                            </p>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">RPM Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-2">From Linear Speed:</p>
                    <p className="font-mono text-center text-foreground">RPM = (v × 60) / (π × d)</p>
                    <p className="text-xs text-muted-foreground mt-2 text-center">v = linear speed, d = diameter</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-2">From Gear Ratio:</p>
                    <p className="font-mono text-center text-foreground">RPM_out = RPM_in × (T₁ / T₂)</p>
                    <p className="text-xs text-muted-foreground mt-2 text-center">
                      T₁ = driving teeth, T₂ = driven teeth
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common RPM Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Washing Machine</span>
                      <span className="font-mono">400-1600 RPM</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Car Engine (Idle)</span>
                      <span className="font-mono">600-1000 RPM</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Hard Disk Drive</span>
                      <span className="font-mono">5400-7200 RPM</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Electric Motor</span>
                      <span className="font-mono">1000-10000 RPM</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Turbocharger</span>
                      <span className="font-mono">100k-300k RPM</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 RPM</span>
                      <span className="font-mono">0.01667 RPS</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 RPM</span>
                      <span className="font-mono">0.1047 rad/s</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 rad/s</span>
                      <span className="font-mono">9.549 RPM</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is RPM?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  RPM stands for Revolutions Per Minute, a unit of rotational speed that measures how many complete
                  rotations an object makes around a fixed axis in one minute. It is one of the most commonly used
                  measurements in mechanical engineering, automotive applications, and industrial machinery.
                  Understanding RPM is essential for designing gear systems, selecting motors, and analyzing the
                  performance of rotating equipment.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The relationship between linear speed and rotational speed depends on the radius or diameter of the
                  rotating object. A larger wheel rotating at the same RPM will have a higher linear velocity at its
                  edge than a smaller wheel. This principle is fundamental in applications ranging from vehicle
                  speedometers to conveyor belt systems and industrial machinery.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-primary" />
                  <CardTitle>Gear Systems and RPM</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gear systems are used to transfer rotational motion between shafts while changing the speed and
                  torque. When a smaller gear drives a larger gear, the output speed decreases but the torque increases
                  (speed reduction). Conversely, when a larger gear drives a smaller gear, the output speed increases
                  but the torque decreases (speed increase). The gear ratio, calculated as the number of teeth on the
                  driving gear divided by the teeth on the driven gear, determines this relationship.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In practical applications, gear systems are designed to match motor speeds to load requirements. For
                  example, a high-speed motor might be paired with a gear reducer to provide the lower speed and higher
                  torque needed to drive heavy machinery. Understanding these relationships is crucial for efficient
                  mechanical design.
                </p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Rotational speed calculations are estimates based on ideal conditions. Actual RPM may vary due to
                  slip, friction, belt/chain stretch, or mechanical tolerances. In gear systems, efficiency losses
                  typically reduce output power by 1-3% per gear stage. Consult engineering references and conduct
                  proper testing for precise measurements in critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
