"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Bike, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface CyclingResult {
  totalCalories: number
  caloriesPerUnit: number
  metValue: number
  durationMinutes: number
  averageSpeed: number
}

const terrainTypes = [
  { value: "flat", label: "Flat Road", metAdjustment: 0 },
  { value: "hilly", label: "Hilly Terrain", metAdjustment: 2 },
  { value: "trail", label: "Off-road / Trail", metAdjustment: 1.5 },
]

const intensityLevels = [
  { value: "low", label: "Low (Leisurely)", baseMet: 4 },
  { value: "moderate", label: "Moderate (Steady)", baseMet: 6.8 },
  { value: "high", label: "High (Vigorous)", baseMet: 10 },
]

export function CyclingCaloriesCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [distance, setDistance] = useState("")
  const [duration, setDuration] = useState("")
  const [speed, setSpeed] = useState("")
  const [terrain, setTerrain] = useState("flat")
  const [intensity, setIntensity] = useState("moderate")
  const [gender, setGender] = useState("male")
  const [result, setResult] = useState<CyclingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateCalories = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    const distanceNum = Number.parseFloat(distance)
    const durationNum = Number.parseFloat(duration)
    const speedNum = Number.parseFloat(speed)

    if ((isNaN(distanceNum) || distanceNum <= 0) && (isNaN(durationNum) || durationNum <= 0)) {
      setError("Please enter either distance or duration")
      return
    }

    // Convert weight to kg if imperial
    const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Get base MET from intensity
    const intensityData = intensityLevels.find((i) => i.value === intensity)
    let metValue = intensityData?.baseMet || 6.8

    // Adjust MET based on speed if provided
    if (!isNaN(speedNum) && speedNum > 0) {
      const speedKmh = unitSystem === "imperial" ? speedNum * 1.60934 : speedNum
      if (speedKmh < 16) metValue = 4
      else if (speedKmh < 20) metValue = 6.8
      else if (speedKmh < 25) metValue = 8
      else if (speedKmh < 30) metValue = 10
      else metValue = 12
    }

    // Adjust for terrain
    const terrainData = terrainTypes.find((t) => t.value === terrain)
    metValue += terrainData?.metAdjustment || 0

    // Adjust for gender (women burn slightly fewer calories)
    if (gender === "female") {
      metValue *= 0.9
    }

    // Calculate duration
    let finalDuration = durationNum
    let calculatedSpeed = speedNum

    if (!isNaN(distanceNum) && distanceNum > 0 && !isNaN(speedNum) && speedNum > 0) {
      // Calculate duration from distance and speed
      const distanceKm = unitSystem === "imperial" ? distanceNum * 1.60934 : distanceNum
      const speedKmh = unitSystem === "imperial" ? speedNum * 1.60934 : speedNum
      finalDuration = (distanceKm / speedKmh) * 60
    } else if (!isNaN(distanceNum) && distanceNum > 0 && !isNaN(durationNum) && durationNum > 0) {
      // Calculate speed from distance and duration
      const distanceKm = unitSystem === "imperial" ? distanceNum * 1.60934 : distanceNum
      calculatedSpeed = distanceKm / (durationNum / 60)
      if (unitSystem === "imperial") {
        calculatedSpeed = calculatedSpeed / 1.60934
      }
      finalDuration = durationNum
    } else if (!isNaN(durationNum) && durationNum > 0) {
      finalDuration = durationNum
      // Use average speed based on intensity
      const avgSpeeds = { low: 12, moderate: 20, high: 28 }
      calculatedSpeed = avgSpeeds[intensity as keyof typeof avgSpeeds]
      if (unitSystem === "imperial") {
        calculatedSpeed = calculatedSpeed / 1.60934
      }
    }

    if (isNaN(finalDuration) || finalDuration <= 0) {
      setError("Could not calculate duration. Please provide valid inputs.")
      return
    }

    // Calculate calories: (MET × 3.5 × Weight in kg) ÷ 200 × duration
    const caloriesPerMinute = (metValue * 3.5 * weightKg) / 200
    const totalCalories = caloriesPerMinute * finalDuration

    // Calculate calories per km/mile
    let caloriesPerUnit = 0
    if (!isNaN(distanceNum) && distanceNum > 0) {
      caloriesPerUnit = totalCalories / distanceNum
    } else if (!isNaN(calculatedSpeed) && calculatedSpeed > 0) {
      const estimatedDistance = (calculatedSpeed * finalDuration) / 60
      caloriesPerUnit = totalCalories / estimatedDistance
    }

    setResult({
      totalCalories: Math.round(totalCalories),
      caloriesPerUnit: Math.round(caloriesPerUnit * 10) / 10,
      metValue: Math.round(metValue * 10) / 10,
      durationMinutes: Math.round(finalDuration),
      averageSpeed: Math.round((calculatedSpeed || speedNum || 0) * 10) / 10,
    })
  }

  const handleReset = () => {
    setWeight("")
    setDistance("")
    setDuration("")
    setSpeed("")
    setTerrain("flat")
    setIntensity("moderate")
    setGender("male")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Cycling Session: ${result.totalCalories} calories burned in ${result.durationMinutes} minutes (MET: ${result.metValue})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Cycling Calories Result",
          text: `I burned ${result.totalCalories} calories during my ${result.durationMinutes}-minute cycling session!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setDistance("")
    setSpeed("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Bike className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Cycling Calories Calculator</CardTitle>
                    <CardDescription>Estimate calories burned while cycling</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"}) *</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Distance Input */}
                <div className="space-y-2">
                  <Label htmlFor="distance">Distance ({unitSystem === "metric" ? "km" : "miles"})</Label>
                  <Input
                    id="distance"
                    type="number"
                    placeholder={`Enter distance in ${unitSystem === "metric" ? "kilometers" : "miles"}`}
                    value={distance}
                    onChange={(e) => setDistance(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Duration Input */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Enter duration in minutes"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Speed Input */}
                <div className="space-y-2">
                  <Label htmlFor="speed">Average Speed ({unitSystem === "metric" ? "km/h" : "mph"}) (Optional)</Label>
                  <Input
                    id="speed"
                    type="number"
                    placeholder={`Enter speed in ${unitSystem === "metric" ? "km/h" : "mph"}`}
                    value={speed}
                    onChange={(e) => setSpeed(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Terrain Select */}
                <div className="space-y-2">
                  <Label>Terrain Type</Label>
                  <Select value={terrain} onValueChange={setTerrain}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select terrain" />
                    </SelectTrigger>
                    <SelectContent>
                      {terrainTypes.map((t) => (
                        <SelectItem key={t.value} value={t.value}>
                          {t.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Intensity Select */}
                <div className="space-y-2">
                  <Label>Intensity Level</Label>
                  <Select value={intensity} onValueChange={setIntensity}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select intensity" />
                    </SelectTrigger>
                    <SelectContent>
                      {intensityLevels.map((i) => (
                        <SelectItem key={i.value} value={i.value}>
                          {i.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Gender Select */}
                <div className="space-y-2">
                  <Label>Gender (Optional)</Label>
                  <Select value={gender} onValueChange={setGender}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCalories} className="w-full" size="lg">
                  Calculate Calories
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Calories Burned</p>
                      <p className="text-5xl font-bold text-green-600 mb-2">{result.totalCalories}</p>
                      <p className="text-lg font-semibold text-green-600">kcal</p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? "Hide Details" : "Show Details"}
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-green-200 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Duration:</span>
                          <span className="font-medium">{result.durationMinutes} minutes</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">MET Value:</span>
                          <span className="font-medium">{result.metValue}</span>
                        </div>
                        {result.caloriesPerUnit > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">
                              Calories per {unitSystem === "metric" ? "km" : "mile"}:
                            </span>
                            <span className="font-medium">{result.caloriesPerUnit} kcal</span>
                          </div>
                        )}
                        {result.averageSpeed > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Average Speed:</span>
                            <span className="font-medium">
                              {result.averageSpeed} {unitSystem === "metric" ? "km/h" : "mph"}
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">MET Values by Speed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">{"< 16 km/h (10 mph)"}</span>
                      <span className="text-sm text-blue-600">MET 4.0</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">16-20 km/h (10-12 mph)</span>
                      <span className="text-sm text-green-600">MET 6.8</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">20-25 km/h (12-16 mph)</span>
                      <span className="text-sm text-yellow-600">MET 8.0</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">25-30 km/h (16-19 mph)</span>
                      <span className="text-sm text-orange-600">MET 10.0</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">{"> 30 km/h (19+ mph)"}</span>
                      <span className="text-sm text-red-600">MET 12.0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calorie Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Calories/min = (MET × 3.5 × Weight) ÷ 200</p>
                  </div>
                  <p>
                    MET (Metabolic Equivalent of Task) represents the energy cost of physical activity. Cycling MET
                    values range from 4.0 (leisurely) to 12.0+ (racing).
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Cycling Calories Calculator?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Cycling Calories Calculator estimates the number of calories you burn during a cycling session
                  based on your body weight, cycling duration or distance, speed, terrain type, and exercise intensity.
                  It uses the MET (Metabolic Equivalent of Task) formula, which is a standardized method for estimating
                  energy expenditure during physical activities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Cycling is an excellent cardiovascular exercise that can burn significant calories while being low
                  impact on joints. The number of calories burned varies greatly based on factors like speed, terrain,
                  wind resistance, and individual metabolism. This calculator provides estimates based on established
                  research data from the Compendium of Physical Activities.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Bike className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Calories Burned</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence how many calories you burn while cycling:
                </p>
                <div className="mt-4 space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Body Weight</h4>
                    <p className="text-blue-700 text-sm">
                      Heavier individuals burn more calories because more energy is required to move greater mass. A
                      person weighing 90 kg will burn approximately 30% more calories than someone weighing 70 kg at the
                      same speed and duration.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Speed and Intensity</h4>
                    <p className="text-green-700 text-sm">
                      Faster cycling requires more energy output, significantly increasing calorie burn. Racing at 30+
                      km/h can burn three times more calories per minute than leisurely cycling at 15 km/h.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Terrain</h4>
                    <p className="text-yellow-700 text-sm">
                      Hilly terrain and off-road trails require more effort than flat roads due to elevation changes and
                      surface resistance. Climbing hills can increase calorie burn by 50-100% compared to flat riding.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Wind Resistance</h4>
                    <p className="text-purple-700 text-sm">
                      Wind resistance increases exponentially with speed. At higher speeds, overcoming air resistance
                      becomes the primary factor in energy expenditure, which is why aerodynamic positioning matters for
                      competitive cyclists.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tips for Maximizing Calorie Burn</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-3 list-disc list-inside">
                  <li>
                    <strong>Interval Training:</strong> Alternate between high-intensity bursts and recovery periods to
                    increase overall calorie burn and improve cardiovascular fitness.
                  </li>
                  <li>
                    <strong>Add Hills:</strong> Incorporate routes with elevation changes to challenge your muscles and
                    boost calorie expenditure significantly.
                  </li>
                  <li>
                    <strong>Increase Duration:</strong> Longer rides at moderate intensity can burn substantial calories
                    while being sustainable for beginners.
                  </li>
                  <li>
                    <strong>Try Different Terrain:</strong> Mix road cycling with mountain biking or gravel riding to
                    engage different muscle groups and prevent plateaus.
                  </li>
                  <li>
                    <strong>Monitor Heart Rate:</strong> Use a heart rate monitor to ensure you are cycling in your
                    target heart rate zone for optimal fat burning.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Calories burned are estimates based on MET values and may vary depending
                  on individual metabolism, cycling style, terrain, weather conditions, and bike type. For precise
                  measurements, consider using a power meter or heart rate monitor. Always consult with a healthcare
                  professional before starting any new exercise program.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
