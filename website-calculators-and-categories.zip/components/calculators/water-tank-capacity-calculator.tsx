"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Droplets, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type TankShape = "cylindrical" | "rectangular" | "spherical"
type VolumeUnit = "liters" | "cubic-meters" | "gallons"

interface TankResult {
  totalCapacity: number
  usableCapacity: number
  unit: VolumeUnit
  conversions: {
    liters: number
    cubicMeters: number
    gallons: number
  }
}

export function WaterTankCapacityCalculator() {
  const [tankShape, setTankShape] = useState<TankShape>("cylindrical")
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("liters")
  
  // Cylindrical inputs
  const [radius, setRadius] = useState("")
  const [height, setHeight] = useState("")
  
  // Rectangular inputs
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [rectHeight, setRectHeight] = useState("")
  
  // Spherical inputs
  const [sphereRadius, setSphereRadius] = useState("")
  
  // Optional freeboard
  const [freeboard, setFreeboard] = useState("5")
  
  const [result, setResult] = useState<TankResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCapacity = () => {
    setError("")
    setResult(null)

    const freeboardNum = Number.parseFloat(freeboard)
    if (isNaN(freeboardNum) || freeboardNum < 0 || freeboardNum > 15) {
      setError("Freeboard percentage must be between 0 and 15")
      return
    }

    let volumeInCubicMeters = 0

    if (tankShape === "cylindrical") {
      const r = Number.parseFloat(radius)
      const h = Number.parseFloat(height)
      
      if (isNaN(r) || r <= 0 || isNaN(h) || h <= 0) {
        setError("Please enter valid positive values for radius and height")
        return
      }
      
      // Volume = π × radius² × height
      volumeInCubicMeters = Math.PI * r * r * h
    } else if (tankShape === "rectangular") {
      const l = Number.parseFloat(length)
      const w = Number.parseFloat(width)
      const h = Number.parseFloat(rectHeight)
      
      if (isNaN(l) || l <= 0 || isNaN(w) || w <= 0 || isNaN(h) || h <= 0) {
        setError("Please enter valid positive values for length, width, and height")
        return
      }
      
      // Volume = length × width × height
      volumeInCubicMeters = l * w * h
    } else if (tankShape === "spherical") {
      const r = Number.parseFloat(sphereRadius)
      
      if (isNaN(r) || r <= 0) {
        setError("Please enter a valid positive value for radius")
        return
      }
      
      // Volume = (4/3) × π × radius³
      volumeInCubicMeters = (4 / 3) * Math.PI * r * r * r
    }

    // Calculate usable capacity considering freeboard
    const usableVolumeFactor = 1 - (freeboardNum / 100)
    const usableVolumeInCubicMeters = volumeInCubicMeters * usableVolumeFactor

    // Convert to different units
    const volumeInLiters = volumeInCubicMeters * 1000
    const volumeInGallons = volumeInCubicMeters * 264.172
    
    const usableInLiters = usableVolumeInCubicMeters * 1000
    const usableInGallons = usableVolumeInCubicMeters * 264.172

    let totalCapacity: number
    let usableCapacity: number

    if (volumeUnit === "liters") {
      totalCapacity = volumeInLiters
      usableCapacity = usableInLiters
    } else if (volumeUnit === "cubic-meters") {
      totalCapacity = volumeInCubicMeters
      usableCapacity = usableVolumeInCubicMeters
    } else {
      totalCapacity = volumeInGallons
      usableCapacity = usableInGallons
    }

    setResult({
      totalCapacity: Math.round(totalCapacity * 100) / 100,
      usableCapacity: Math.round(usableCapacity * 100) / 100,
      unit: volumeUnit,
      conversions: {
        liters: Math.round(volumeInLiters * 100) / 100,
        cubicMeters: Math.round(volumeInCubicMeters * 1000) / 1000,
        gallons: Math.round(volumeInGallons * 100) / 100,
      },
    })
  }

  const handleReset = () => {
    setRadius("")
    setHeight("")
    setLength("")
    setWidth("")
    setRectHeight("")
    setSphereRadius("")
    setFreeboard("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unitLabel = result.unit === "cubic-meters" ? "m³" : result.unit === "liters" ? "L" : "gal"
      await navigator.clipboard.writeText(
        `Water Tank Capacity: ${result.totalCapacity} ${unitLabel} (Usable: ${result.usableCapacity} ${unitLabel})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const unitLabel = result.unit === "cubic-meters" ? "m³" : result.unit === "liters" ? "L" : "gal"
      try {
        await navigator.share({
          title: "Water Tank Capacity",
          text: `I calculated my water tank capacity using CalcHub! Total: ${result.totalCapacity} ${unitLabel}, Usable: ${result.usableCapacity} ${unitLabel}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getUnitLabel = () => {
    if (volumeUnit === "cubic-meters") return "m³"
    if (volumeUnit === "liters") return "L"
    return "gal"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Water Tank Capacity Calculator</CardTitle>
                    <CardDescription>Calculate tank storage capacity</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Tank Shape Selection */}
                <div className="space-y-2">
                  <Label htmlFor="tank-shape">Tank Shape</Label>
                  <Select value={tankShape} onValueChange={(value) => setTankShape(value as TankShape)}>
                    <SelectTrigger id="tank-shape">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cylindrical">Cylindrical</SelectItem>
                      <SelectItem value="rectangular">Rectangular</SelectItem>
                      <SelectItem value="spherical">Spherical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Volume Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="volume-unit">Volume Unit</Label>
                  <Select value={volumeUnit} onValueChange={(value) => setVolumeUnit(value as VolumeUnit)}>
                    <SelectTrigger id="volume-unit">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="liters">Liters (L)</SelectItem>
                      <SelectItem value="cubic-meters">Cubic Meters (m³)</SelectItem>
                      <SelectItem value="gallons">Gallons (gal)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dynamic Shape Inputs */}
                {tankShape === "cylindrical" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="radius">Radius (m)</Label>
                      <Input
                        id="radius"
                        type="number"
                        placeholder="Enter radius"
                        value={radius}
                        onChange={(e) => setRadius(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="height">Height (m)</Label>
                      <Input
                        id="height"
                        type="number"
                        placeholder="Enter height"
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                )}

                {tankShape === "rectangular" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="length">Length (m)</Label>
                      <Input
                        id="length"
                        type="number"
                        placeholder="Enter length"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="width">Width (m)</Label>
                      <Input
                        id="width"
                        type="number"
                        placeholder="Enter width"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rect-height">Height (m)</Label>
                      <Input
                        id="rect-height"
                        type="number"
                        placeholder="Enter height"
                        value={rectHeight}
                        onChange={(e) => setRectHeight(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                )}

                {tankShape === "spherical" && (
                  <div className="space-y-2">
                    <Label htmlFor="sphere-radius">Radius (m)</Label>
                    <Input
                      id="sphere-radius"
                      type="number"
                      placeholder="Enter radius"
                      value={sphereRadius}
                      onChange={(e) => setSphereRadius(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                {/* Freeboard Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="freeboard">Freeboard Allowance (%)</Label>
                  <Input
                    id="freeboard"
                    type="number"
                    placeholder="Enter freeboard percentage"
                    value={freeboard}
                    onChange={(e) => setFreeboard(e.target.value)}
                    min="0"
                    max="15"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Space reserved at top (typically 5-10%)</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCapacity} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Capacity
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-4">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total Tank Capacity</p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">
                          {result.totalCapacity.toLocaleString()} {getUnitLabel()}
                        </p>
                      </div>
                      
                      <div className="text-center pt-3 border-t border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Usable Capacity ({100 - Number.parseFloat(freeboard)}%)</p>
                        <p className="text-2xl font-semibold text-amber-700">
                          {result.usableCapacity.toLocaleString()} {getUnitLabel()}
                        </p>
                      </div>

                      {/* Unit Conversions */}
                      <div className="pt-3 border-t border-amber-200 space-y-2">
                        <p className="text-xs font-medium text-amber-800">Unit Conversions:</p>
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          <div className="text-center p-2 bg-white rounded">
                            <p className="font-semibold text-amber-900">{result.conversions.liters.toLocaleString()}</p>
                            <p className="text-muted-foreground">Liters</p>
                          </div>
                          <div className="text-center p-2 bg-white rounded">
                            <p className="font-semibold text-amber-900">{result.conversions.cubicMeters}</p>
                            <p className="text-muted-foreground">m³</p>
                          </div>
                          <div className="text-center p-2 bg-white rounded">
                            <p className="font-semibold text-amber-900">{result.conversions.gallons.toLocaleString()}</p>
                            <p className="text-muted-foreground">Gallons</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tank Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <p className="font-semibold text-amber-900 mb-1">Cylindrical Tank</p>
                    <p className="text-amber-700 font-mono text-xs">V = π × r² × h</p>
                  </div>
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <p className="font-semibold text-amber-900 mb-1">Rectangular Tank</p>
                    <p className="text-amber-700 font-mono text-xs">V = L × W × H</p>
                  </div>
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <p className="font-semibold text-amber-900 mb-1">Spherical Tank</p>
                    <p className="text-amber-700 font-mono text-xs">V = (4/3) × π × r³</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Tank Sizes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Household Tank:</span>
                    <span className="font-medium text-foreground">500-2,000 L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Commercial Tank:</span>
                    <span className="font-medium text-foreground">5,000-20,000 L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Industrial Tank:</span>
                    <span className="font-medium text-foreground">50,000+ L</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-amber-600" />
                  <CardTitle>What is Water Tank Capacity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Water tank capacity refers to the total volume of water that a tank can hold, typically measured in liters, cubic meters, or gallons. Calculating the correct tank capacity is essential for ensuring adequate water storage for residential, commercial, or industrial applications. The capacity depends on the tank's shape and dimensions, with common shapes including cylindrical (most popular for overhead and underground tanks), rectangular (common for concrete tanks), and spherical (used for large-capacity storage).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding your water tank capacity helps in planning water usage, managing supply during shortages, and ensuring your storage meets daily water requirements. For household applications, a typical family of four might need 500-1000 liters of storage, while commercial buildings and industries require much larger capacities based on their specific water consumption patterns and backup requirements.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-amber-600" />
                  <CardTitle>Understanding Freeboard Allowance</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Freeboard is the vertical space between the maximum water level and the top of the tank. This allowance is crucial for several reasons: it prevents water overflow during filling, allows for thermal expansion of water, accommodates wave action or sloshing during earthquakes or strong winds, and provides space for maintenance access. Standard practice recommends maintaining 5-10% freeboard, though this can vary based on tank size and application.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, a tank with 10,000 liters total capacity and 5% freeboard would have 9,500 liters of usable capacity. In seismic zones or areas prone to extreme weather, a higher freeboard percentage (10-15%) is recommended. Industrial tanks storing volatile liquids may require even greater freeboard for safety reasons.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-amber-600" />
                  <CardTitle>Choosing the Right Tank Shape</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The choice of tank shape significantly impacts both capacity and installation requirements. Cylindrical tanks are the most common due to their structural strength, ease of manufacturing, and efficient use of materials. They distribute internal pressure evenly and are ideal for both overhead and underground installations. Rectangular tanks are preferred when space constraints require fitting storage into specific areas or when tanks need to be integrated with building structures. They're easier to partition for storing different liquids but require more reinforcement.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Spherical tanks offer the maximum volume-to-surface-area ratio, making them ideal for large-capacity storage where minimizing material usage is important. They're commonly used in industrial applications for storing liquefied gases or large water volumes. However, they're more expensive to manufacture and install. Consider factors like available space, structural support, installation costs, maintenance requirements, and whether the tank will be placed underground, at ground level, or overhead when selecting your tank shape.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-amber-900 mb-1">Important Note</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Water tank capacity calculations are approximate. Actual volume may vary with tank thickness, shape deviations, and construction tolerances. For critical applications, consult with a structural engineer or tank manufacturer to verify capacity requirements and ensure proper installation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
