"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Target,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { formatCurrency, currencyOptions, type Currency, currencySymbols } from "@/lib/currency"

interface Investment {
  id: string
  name: string
  amount: string
  expectedReturn: string
  risk: string
}

interface InvestmentResult {
  name: string
  amount: number
  expectedReturn: number
  risk: number
  monetaryReturn: number
  sharpeRatio: number
  riskAdjustedReturn: number
  category: string
  color: string
  bgColor: string
}

interface Results {
  investments: InvestmentResult[]
  riskFreeRate: number
  bestInvestment: string
}

export function RiskVsReturnCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [investments, setInvestments] = useState<Investment[]>([
    { id: "1", name: "Investment 1", amount: "", expectedReturn: "", risk: "" },
  ])
  const [riskFreeRate, setRiskFreeRate] = useState("3")
  const [duration, setDuration] = useState("1")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [results, setResults] = useState<Results | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const addInvestment = () => {
    if (investments.length < 5) {
      setInvestments([
        ...investments,
        {
          id: Date.now().toString(),
          name: `Investment ${investments.length + 1}`,
          amount: "",
          expectedReturn: "",
          risk: "",
        },
      ])
    }
  }

  const removeInvestment = (id: string) => {
    if (investments.length > 1) {
      setInvestments(investments.filter((inv) => inv.id !== id))
    }
  }

  const updateInvestment = (id: string, field: keyof Investment, value: string) => {
    setInvestments(investments.map((inv) => (inv.id === id ? { ...inv, [field]: value } : inv)))
  }

  const getRiskCategory = (sharpeRatio: number): { category: string; color: string; bgColor: string } => {
    if (sharpeRatio < 0) {
      return { category: "Poor", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    } else if (sharpeRatio < 1) {
      return { category: "Sub-optimal", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    } else if (sharpeRatio < 2) {
      return { category: "Good", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    } else if (sharpeRatio < 3) {
      return { category: "Very Good", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    } else {
      return { category: "Excellent", color: "text-purple-600", bgColor: "bg-purple-50 border-purple-200" }
    }
  }

  const calculate = () => {
    setError("")
    setResults(null)

    const rfRate = Number.parseFloat(riskFreeRate) || 0
    const years = Number.parseFloat(duration) || 1

    const validInvestments: InvestmentResult[] = []

    for (const inv of investments) {
      const amount = Number.parseFloat(inv.amount)
      const expectedReturn = Number.parseFloat(inv.expectedReturn)
      const risk = Number.parseFloat(inv.risk)

      if (isNaN(amount) || amount <= 0) {
        setError(`Please enter a valid positive amount for ${inv.name}`)
        return
      }
      if (isNaN(expectedReturn)) {
        setError(`Please enter a valid expected return for ${inv.name}`)
        return
      }
      if (isNaN(risk) || risk <= 0) {
        setError(`Please enter a valid positive risk (standard deviation) for ${inv.name}`)
        return
      }

      // Calculate cumulative return over duration
      const cumulativeReturn = ((1 + expectedReturn / 100) ** years - 1) * 100
      const monetaryReturn = amount * (cumulativeReturn / 100)

      // Sharpe Ratio = (Expected Return - Risk-Free Rate) / Standard Deviation
      const sharpeRatio = (expectedReturn - rfRate) / risk
      const riskAdjustedReturn = sharpeRatio * risk

      const { category, color, bgColor } = getRiskCategory(sharpeRatio)

      validInvestments.push({
        name: inv.name,
        amount,
        expectedReturn,
        risk,
        monetaryReturn,
        sharpeRatio,
        riskAdjustedReturn,
        category,
        color,
        bgColor,
      })
    }

    // Find best investment by Sharpe Ratio
    const bestInvestment = validInvestments.reduce((best, current) =>
      current.sharpeRatio > best.sharpeRatio ? current : best,
    ).name

    setResults({
      investments: validInvestments,
      riskFreeRate: rfRate,
      bestInvestment,
    })
  }

  const handleReset = () => {
    setInvestments([{ id: "1", name: "Investment 1", amount: "", expectedReturn: "", risk: "" }])
    setRiskFreeRate("3")
    setDuration("1")
    setResults(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (results) {
      const text = results.investments
        .map((inv) => `${inv.name}: Sharpe Ratio ${inv.sharpeRatio.toFixed(2)} (${inv.category})`)
        .join("\n")
      await navigator.clipboard.writeText(
        `Risk vs Return Analysis:\n${text}\nBest Investment: ${results.bestInvestment}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (results && navigator.share) {
      try {
        await navigator.share({
          title: "Risk vs Return Analysis",
          text: `I analyzed my investments using CalcHub! Best investment: ${results.bestInvestment}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl">Risk vs Return Calculator</CardTitle>
                    <CardDescription>Evaluate investment potential relative to risk</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <Select value={currency} onValueChange={(value: Currency) => setCurrency(value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencyOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.symbol} {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Risk-Free Rate */}
                <div className="space-y-2">
                  <Label htmlFor="riskFreeRate">Risk-Free Rate (%)</Label>
                  <Input
                    id="riskFreeRate"
                    type="number"
                    placeholder="e.g., 3"
                    value={riskFreeRate}
                    onChange={(e) => setRiskFreeRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Usually the treasury bond rate</p>
                </div>

                {/* Investments */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Investments</Label>
                    {investments.length < 5 && (
                      <Button variant="outline" size="sm" onClick={addInvestment}>
                        <Plus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                    )}
                  </div>

                  {investments.map((inv, index) => (
                    <div key={inv.id} className="p-3 bg-muted/50 rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Input
                          value={inv.name}
                          onChange={(e) => updateInvestment(inv.id, "name", e.target.value)}
                          className="font-medium h-8 w-40"
                          placeholder="Investment name"
                        />
                        {investments.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeInvestment(inv.id)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <Label className="text-xs">Amount ({symbol})</Label>
                          <Input
                            type="number"
                            placeholder="10000"
                            value={inv.amount}
                            onChange={(e) => updateInvestment(inv.id, "amount", e.target.value)}
                            min="0"
                            className="h-8"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Return (%)</Label>
                          <Input
                            type="number"
                            placeholder="8"
                            value={inv.expectedReturn}
                            onChange={(e) => updateInvestment(inv.id, "expectedReturn", e.target.value)}
                            step="0.1"
                            className="h-8"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Risk (%)</Label>
                          <Input
                            type="number"
                            placeholder="15"
                            value={inv.risk}
                            onChange={(e) => updateInvestment(inv.id, "risk", e.target.value)}
                            min="0.1"
                            step="0.1"
                            className="h-8"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-3 pt-3">
                    <div className="space-y-2">
                      <Label htmlFor="duration">Investment Duration (years)</Label>
                      <Input
                        id="duration"
                        type="number"
                        placeholder="1"
                        value={duration}
                        onChange={(e) => setDuration(e.target.value)}
                        min="1"
                        step="1"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Risk vs Return
                </Button>

                {/* Results */}
                {results && (
                  <div className="space-y-4">
                    {/* Best Investment */}
                    <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Best Risk-Adjusted Investment</p>
                        <p className="text-2xl font-bold text-green-600 mb-1">{results.bestInvestment}</p>
                        <p className="text-sm text-green-600">Highest Sharpe Ratio</p>
                      </div>
                    </div>

                    {/* Investment Results */}
                    {results.investments.map((inv, index) => (
                      <div key={index} className={`p-4 rounded-xl border-2 ${inv.bgColor}`}>
                        <div className="flex items-center justify-between mb-3">
                          <span className="font-semibold">{inv.name}</span>
                          <span className={`text-sm font-medium ${inv.color}`}>{inv.category}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div>
                            <p className="text-muted-foreground">Investment</p>
                            <p className="font-semibold">{formatCurrency(inv.amount, currency)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Expected Return</p>
                            <p className="font-semibold">{formatCurrency(inv.monetaryReturn, currency)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Sharpe Ratio</p>
                            <p className={`font-bold text-lg ${inv.color}`}>{inv.sharpeRatio.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Risk (Std Dev)</p>
                            <p className="font-semibold">{inv.risk.toFixed(1)}%</p>
                          </div>
                        </div>

                        {/* Visual Risk vs Return Bar */}
                        <div className="mt-3 pt-3 border-t border-current/10">
                          <div className="flex justify-between text-xs text-muted-foreground mb-1">
                            <span>Risk</span>
                            <span>Return</span>
                          </div>
                          <div className="h-2 bg-gray-200 rounded-full overflow-hidden flex">
                            <div
                              className="bg-red-400 transition-all"
                              style={{ width: `${Math.min(inv.risk, 50)}%` }}
                            />
                            <div
                              className="bg-green-400 transition-all"
                              style={{ width: `${Math.min(inv.expectedReturn, 50)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Comparison Table */}
                    {results.investments.length > 1 && (
                      <Collapsible open={showDetails} onOpenChange={setShowDetails}>
                        <CollapsibleTrigger asChild>
                          <Button variant="outline" className="w-full bg-transparent">
                            {showDetails ? "Hide" : "Show"} Comparison Table
                            {showDetails ? (
                              <ChevronUp className="ml-2 h-4 w-4" />
                            ) : (
                              <ChevronDown className="ml-2 h-4 w-4" />
                            )}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="pt-3">
                          <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="border-b">
                                  <th className="text-left py-2 px-2">Investment</th>
                                  <th className="text-right py-2 px-2">Return %</th>
                                  <th className="text-right py-2 px-2">Risk %</th>
                                  <th className="text-right py-2 px-2">Sharpe</th>
                                  <th className="text-right py-2 px-2">Rank</th>
                                </tr>
                              </thead>
                              <tbody>
                                {results.investments
                                  .sort((a, b) => b.sharpeRatio - a.sharpeRatio)
                                  .map((inv, index) => (
                                    <tr key={index} className="border-b last:border-0">
                                      <td className="py-2 px-2 font-medium">{inv.name}</td>
                                      <td className="text-right py-2 px-2 text-green-600">
                                        {inv.expectedReturn.toFixed(1)}%
                                      </td>
                                      <td className="text-right py-2 px-2 text-red-600">{inv.risk.toFixed(1)}%</td>
                                      <td className={`text-right py-2 px-2 font-semibold ${inv.color}`}>
                                        {inv.sharpeRatio.toFixed(2)}
                                      </td>
                                      <td className="text-right py-2 px-2">#{index + 1}</td>
                                    </tr>
                                  ))}
                              </tbody>
                            </table>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sharpe Ratio Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Poor</span>
                      <span className="text-sm text-red-600">{"< 0"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Sub-optimal</span>
                      <span className="text-sm text-yellow-600">0 – 0.99</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Good</span>
                      <span className="text-sm text-green-600">1 – 1.99</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Very Good</span>
                      <span className="text-sm text-blue-600">2 – 2.99</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Excellent</span>
                      <span className="text-sm text-purple-600">≥ 3</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Risk vs Return Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Sharpe Ratio = (R - Rf) / σ</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>R</strong> = Expected return of investment
                    </p>
                    <p>
                      <strong>Rf</strong> = Risk-free rate (e.g., treasury bonds)
                    </p>
                    <p>
                      <strong>σ</strong> = Standard deviation (volatility/risk)
                    </p>
                  </div>
                  <p className="text-xs">
                    Higher Sharpe Ratio indicates better risk-adjusted returns. An investment with 10% return and 5%
                    risk is better than one with 15% return and 20% risk.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Risk vs Return?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Risk vs Return is a fundamental investment concept that describes the relationship between the
                  potential reward of an investment and the level of risk involved. Generally, investments with higher
                  potential returns come with greater risk, while safer investments typically offer lower returns. The
                  key to successful investing is finding the right balance between risk and return that aligns with your
                  financial goals and risk tolerance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Sharpe Ratio, developed by Nobel laureate William Sharpe, is one of the most widely used metrics
                  for evaluating risk-adjusted returns. It measures how much excess return you receive for the extra
                  volatility you endure. A higher Sharpe Ratio indicates that an investment provides better returns
                  relative to the risk taken, making it easier to compare different investment options on a level
                  playing field.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Start by entering the risk-free rate, typically the current treasury bond yield. Then add your
                  investment options with their expected returns and risk levels (standard deviation). The calculator
                  will compute the Sharpe Ratio for each investment and rank them by risk-adjusted performance.
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Expected Return</h4>
                    <p className="text-blue-700 text-sm">
                      The anticipated annual percentage gain from the investment based on historical data or
                      projections.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Risk (Standard Deviation)</h4>
                    <p className="text-red-700 text-sm">
                      A measure of volatility showing how much returns can deviate from the average. Higher values mean
                      more uncertainty.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-800 text-sm leading-relaxed">
                  Risk vs return calculations are estimates based on entered values. Actual investment outcomes may vary
                  due to market conditions, volatility, and other factors. Past performance does not guarantee future
                  results. This calculator is for educational purposes only and should not be considered financial
                  advice. Consult a qualified financial advisor for personalized investment guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
