"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Flame,
  Info,
  AlertTriangle,
  Target,
  Apple,
  Dumbbell,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityLevel = "sedentary" | "light" | "moderate" | "very" | "athlete"
type GoalIntensity = "mild" | "moderate" | "aggressive"

interface FatLossResult {
  bmr: number
  tdee: number
  targetCalories: number
  protein: number
  carbs: number
  fat: number
  weeklyLoss: number
  deficit: number
}

const activityMultipliers: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  very: 1.725,
  athlete: 1.9,
}

const activityLabels: Record<ActivityLevel, string> = {
  sedentary: "Sedentary",
  light: "Lightly Active",
  moderate: "Moderately Active",
  very: "Very Active",
  athlete: "Athlete",
}

const goalDeficits: Record<GoalIntensity, number> = {
  mild: 250,
  moderate: 500,
  aggressive: 750,
}

const goalLabels: Record<GoalIntensity, string> = {
  mild: "Mild (-250)",
  moderate: "Moderate (-500)",
  aggressive: "Aggressive (-750)",
}

export function FatLossCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")
  const [goalIntensity, setGoalIntensity] = useState<GoalIntensity>("moderate")
  const [mealsPerDay, setMealsPerDay] = useState("3")
  const [result, setResult] = useState<FatLossResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateFatLoss = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseInt(age)
    const weightNum = Number.parseFloat(weight)

    if (isNaN(ageNum) || ageNum < 10) {
      setError("Please enter a valid age (10 or older)")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Mifflin-St Jeor Equation
    let bmr: number
    if (gender === "male") {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
    } else {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
    }

    const tdee = bmr * activityMultipliers[activityLevel]
    const deficit = goalDeficits[goalIntensity]
    let targetCalories = tdee - deficit

    // Enforce minimum safe calories
    const minCalories = gender === "male" ? 1500 : 1200
    if (targetCalories < minCalories) {
      targetCalories = minCalories
    }

    // Macronutrient breakdown for fat loss (30% protein, 40% carbs, 30% fat)
    const proteinCalories = targetCalories * 0.3
    const carbCalories = targetCalories * 0.4
    const fatCalories = targetCalories * 0.3

    const protein = Math.round(proteinCalories / 4)
    const carbs = Math.round(carbCalories / 4)
    const fat = Math.round(fatCalories / 9)

    // Weekly weight loss (1 lb = 3500 calories deficit)
    const actualDeficit = tdee - targetCalories
    const weeklyLossLbs = (actualDeficit * 7) / 3500
    const weeklyLoss = unitSystem === "metric" ? weeklyLossLbs * 0.453592 : weeklyLossLbs

    setResult({
      bmr: Math.round(bmr),
      tdee: Math.round(tdee),
      targetCalories: Math.round(targetCalories),
      protein,
      carbs,
      fat,
      weeklyLoss: Math.round(weeklyLoss * 100) / 100,
      deficit: Math.round(actualDeficit),
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setActivityLevel("moderate")
    setGoalIntensity("moderate")
    setMealsPerDay("3")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Fat Loss Plan:\nDaily Calories: ${result.targetCalories} kcal\nProtein: ${result.protein}g\nCarbs: ${result.carbs}g\nFat: ${result.fat}g\nWeekly Loss: ${result.weeklyLoss} ${unitSystem === "metric" ? "kg" : "lb"}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Fat Loss Plan",
          text: `My daily target is ${result.targetCalories} calories with ${result.protein}g protein, ${result.carbs}g carbs, and ${result.fat}g fat for fat loss!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  const mealsNum = Number.parseInt(mealsPerDay) || 3

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Fat Loss Calculator</CardTitle>
                    <CardDescription>Calculate your optimal fat loss plan</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {(Object.keys(activityMultipliers) as ActivityLevel[]).map((level) => (
                      <Button
                        key={level}
                        type="button"
                        variant={activityLevel === level ? "default" : "outline"}
                        onClick={() => setActivityLevel(level)}
                        className="w-full text-xs sm:text-sm"
                        size="sm"
                      >
                        {activityLabels[level]}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Goal Intensity */}
                <div className="space-y-2">
                  <Label>Goal Intensity (daily deficit)</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {(Object.keys(goalDeficits) as GoalIntensity[]).map((intensity) => (
                      <Button
                        key={intensity}
                        type="button"
                        variant={goalIntensity === intensity ? "default" : "outline"}
                        onClick={() => setGoalIntensity(intensity)}
                        className={`w-full text-xs sm:text-sm ${
                          goalIntensity === intensity
                            ? intensity === "mild"
                              ? "bg-green-600 hover:bg-green-700"
                              : intensity === "moderate"
                                ? "bg-yellow-600 hover:bg-yellow-700"
                                : "bg-red-600 hover:bg-red-700"
                            : ""
                        }`}
                        size="sm"
                      >
                        {goalLabels[intensity]}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Meals Per Day */}
                <div className="space-y-2">
                  <Label htmlFor="meals">Meals Per Day</Label>
                  <Input
                    id="meals"
                    type="number"
                    placeholder="Number of meals"
                    value={mealsPerDay}
                    onChange={(e) => setMealsPerDay(e.target.value)}
                    min="1"
                    max="10"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFatLoss} className="w-full" size="lg">
                  Calculate Fat Loss Plan
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Daily Calorie Target</p>
                      <p className="text-5xl font-bold text-orange-600 mb-1">{result.targetCalories}</p>
                      <p className="text-lg font-medium text-orange-600">kcal/day</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        {result.deficit} kcal deficit from TDEE ({result.tdee} kcal)
                      </p>
                    </div>

                    {/* Macro Breakdown */}
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="p-3 rounded-lg bg-blue-100 text-center">
                        <p className="text-2xl font-bold text-blue-700">{result.protein}g</p>
                        <p className="text-xs text-blue-600">Protein (30%)</p>
                      </div>
                      <div className="p-3 rounded-lg bg-amber-100 text-center">
                        <p className="text-2xl font-bold text-amber-700">{result.carbs}g</p>
                        <p className="text-xs text-amber-600">Carbs (40%)</p>
                      </div>
                      <div className="p-3 rounded-lg bg-purple-100 text-center">
                        <p className="text-2xl font-bold text-purple-700">{result.fat}g</p>
                        <p className="text-xs text-purple-600">Fat (30%)</p>
                      </div>
                    </div>

                    {/* Per Meal Breakdown */}
                    <div className="p-3 rounded-lg bg-white border mb-4">
                      <p className="text-sm font-medium text-center mb-2">Per Meal ({mealsNum} meals/day)</p>
                      <div className="grid grid-cols-4 gap-2 text-center text-sm">
                        <div>
                          <p className="font-bold text-foreground">{Math.round(result.targetCalories / mealsNum)}</p>
                          <p className="text-xs text-muted-foreground">kcal</p>
                        </div>
                        <div>
                          <p className="font-bold text-blue-600">{Math.round(result.protein / mealsNum)}g</p>
                          <p className="text-xs text-muted-foreground">Protein</p>
                        </div>
                        <div>
                          <p className="font-bold text-amber-600">{Math.round(result.carbs / mealsNum)}g</p>
                          <p className="text-xs text-muted-foreground">Carbs</p>
                        </div>
                        <div>
                          <p className="font-bold text-purple-600">{Math.round(result.fat / mealsNum)}g</p>
                          <p className="text-xs text-muted-foreground">Fat</p>
                        </div>
                      </div>
                    </div>

                    {/* Weekly Loss Estimate */}
                    <div className="p-3 rounded-lg bg-green-100 text-center mb-4">
                      <p className="text-sm text-green-700">Estimated Weekly Loss</p>
                      <p className="text-2xl font-bold text-green-700">
                        {result.weeklyLoss} {unitSystem === "metric" ? "kg" : "lb"}
                      </p>
                    </div>

                    {/* Warning for aggressive deficit */}
                    {result.deficit >= 750 && (
                      <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200 text-yellow-700 text-sm flex items-start gap-2 mb-4">
                        <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                        <span>
                          Aggressive deficits may be difficult to sustain. Consider a moderate approach for long-term
                          success.
                        </span>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fat Loss Macro Ratios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Protein</span>
                      <span className="text-sm text-blue-600">30% of calories</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Carbohydrates</span>
                      <span className="text-sm text-amber-600">40% of calories</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Fat</span>
                      <span className="text-sm text-purple-600">30% of calories</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Safe Calorie Limits</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Minimum Daily Calories</p>
                    <p className="mt-1">Male: 1,500 kcal | Female: 1,200 kcal</p>
                  </div>
                  <p>
                    Going below these limits can lead to nutrient deficiencies, muscle loss, and metabolic slowdown.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-yellow-50 border-yellow-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Individual results may vary. Consult a healthcare or
                        nutrition professional for personalized guidance.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Fat Loss</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Fat loss occurs when you consistently consume fewer calories than your body burns, creating what is
                  known as a calorie deficit. This fundamental principle of energy balance is the foundation of all
                  successful fat loss programs. When your body needs more energy than it receives from food, it turns to
                  stored fat as fuel, leading to gradual weight reduction over time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key to sustainable fat loss is finding the right balance between creating enough of a deficit to
                  see results while not being so aggressive that you feel deprived, lose muscle mass, or slow down your
                  metabolism. A moderate deficit of 500 calories per day typically results in about 1 pound (0.45 kg) of
                  fat loss per week, which is considered a safe and sustainable rate for most people.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>The Science Behind Calorie Deficits</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Your Total Daily Energy Expenditure (TDEE) represents the total number of calories your body burns in
                  a day, including your Basal Metabolic Rate (BMR), physical activity, and the thermic effect of food.
                  The Mifflin-St Jeor equation, which this calculator uses, is considered one of the most accurate
                  methods for estimating BMR and has been validated in numerous research studies.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When you subtract calories from your TDEE, you create a deficit. A deficit of 3,500 calories is
                  approximately equal to one pound of body fat. However, this isn't perfectly linear—as you lose weight,
                  your TDEE decreases, which is why periodic recalculation of your calorie needs is important for
                  continued progress.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Apple className="h-5 w-5 text-primary" />
                  <CardTitle>Why Macronutrients Matter for Fat Loss</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While calories determine whether you lose or gain weight, macronutrients (protein, carbohydrates, and
                  fat) determine the quality of your weight loss. A higher protein intake during a calorie deficit is
                  crucial for preserving lean muscle mass. Protein also has the highest thermic effect of food, meaning
                  your body burns more calories digesting protein compared to carbs or fat.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The 30% protein, 40% carbohydrate, 30% fat ratio used in this calculator is optimized for fat loss
                  while maintaining energy levels and satiety. Adequate carbohydrates fuel your workouts and support
                  recovery, while healthy fats are essential for hormone production, nutrient absorption, and overall
                  health. This balanced approach helps ensure you feel satisfied and energized throughout your fat loss
                  journey.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Dumbbell className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Successful Fat Loss</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Successful fat loss requires more than just hitting your calorie target. Prioritize protein at every
                  meal to preserve muscle mass and stay satisfied longer. Incorporate resistance training 2-4 times per
                  week to maintain or build muscle, which helps keep your metabolism elevated. Stay hydrated, as thirst
                  is often mistaken for hunger, and adequate water intake supports fat metabolism.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Sleep 7-9 hours per night, as poor sleep disrupts hunger hormones and increases cravings. Track your
                  food intake consistently, at least initially, to develop awareness of portion sizes and calorie
                  content. Be patient and focus on trends rather than daily fluctuations—weight can vary by several
                  pounds day-to-day due to water retention, sodium intake, and other factors unrelated to actual fat
                  loss.
                </p>
                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Do</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Eat protein with every meal</li>
                      <li>• Strength train regularly</li>
                      <li>• Get adequate sleep</li>
                      <li>• Stay consistent over time</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Avoid</h4>
                    <ul className="text-red-700 text-sm space-y-1">
                      <li>• Extreme calorie restriction</li>
                      <li>• Skipping meals</li>
                      <li>• Relying on cardio alone</li>
                      <li>• Expecting overnight results</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
