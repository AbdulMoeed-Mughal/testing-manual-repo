"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, User, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "female" | "male"

interface BodyShapeResult {
  shape: string
  description: string
  whr: number
  swr: number
  color: string
  bgColor: string
  recommendations: string[]
}

const femaleShapes = [
  { name: "Hourglass", description: "Balanced shoulders and hips with a defined waist" },
  { name: "Pear", description: "Hips wider than shoulders with a defined waist" },
  { name: "Apple", description: "Wider midsection with slimmer hips and legs" },
  { name: "Rectangle", description: "Similar measurements for shoulders, waist, and hips" },
  { name: "Inverted Triangle", description: "Shoulders wider than hips" },
]

const maleShapes = [
  { name: "Inverted Triangle", description: "Broad shoulders tapering to narrow waist and hips" },
  { name: "Rectangle", description: "Similar measurements for shoulders, waist, and hips" },
  { name: "Trapezoid", description: "Broad shoulders with moderate waist definition" },
  { name: "Oval", description: "Wider midsection with narrower shoulders and hips" },
  { name: "Triangle", description: "Hips and waist wider than shoulders" },
]

export function BodyShapeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("female")
  const [shoulders, setShoulders] = useState("")
  const [waist, setWaist] = useState("")
  const [hips, setHips] = useState("")
  const [result, setResult] = useState<BodyShapeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateBodyShape = () => {
    setError("")
    setResult(null)

    const shouldersNum = Number.parseFloat(shoulders)
    const waistNum = Number.parseFloat(waist)
    const hipsNum = Number.parseFloat(hips)

    if (isNaN(shouldersNum) || shouldersNum <= 0) {
      setError("Please enter a valid shoulder measurement greater than 0")
      return
    }
    if (isNaN(waistNum) || waistNum <= 0) {
      setError("Please enter a valid waist measurement greater than 0")
      return
    }
    if (isNaN(hipsNum) || hipsNum <= 0) {
      setError("Please enter a valid hip measurement greater than 0")
      return
    }

    // Calculate ratios
    const whr = waistNum / hipsNum
    const swr = shouldersNum / waistNum
    const hipsToShoulders = hipsNum / shouldersNum

    let shape: string
    let description: string
    let color: string
    let bgColor: string
    let recommendations: string[]

    if (gender === "female") {
      // Female body shape determination
      if (Math.abs(shouldersNum - hipsNum) < hipsNum * 0.05 && waistNum < hipsNum * 0.75) {
        shape = "Hourglass"
        description =
          "Your shoulders and hips are balanced with a well-defined waist. This is often considered the classic feminine silhouette."
        color = "text-pink-600"
        bgColor = "bg-pink-50 border-pink-200"
        recommendations = [
          "Fitted clothing that accentuates your waist",
          "Wrap dresses and belted styles",
          "Form-fitting silhouettes",
          "High-waisted bottoms",
        ]
      } else if (hipsNum > shouldersNum * 1.05 && waistNum < hipsNum * 0.85) {
        shape = "Pear"
        description =
          "Your hips are wider than your shoulders with a defined waist. Your lower body is your feature area."
        color = "text-purple-600"
        bgColor = "bg-purple-50 border-purple-200"
        recommendations = [
          "Emphasize your upper body with detailed tops",
          "A-line skirts and bootcut pants",
          "Structured shoulders and neckline details",
          "Dark colors on bottom, bright on top",
        ]
      } else if (waistNum >= hipsNum * 0.85 && waistNum >= shouldersNum * 0.9) {
        shape = "Apple"
        description = "You carry more weight in your midsection with slimmer hips and legs."
        color = "text-orange-600"
        bgColor = "bg-orange-50 border-orange-200"
        recommendations = [
          "Empire waist and flowy tops",
          "V-necklines to elongate torso",
          "Straight-leg or bootcut pants",
          "Structured jackets that skim the body",
        ]
      } else if (shouldersNum > hipsNum * 1.05) {
        shape = "Inverted Triangle"
        description = "Your shoulders are broader than your hips. Your upper body is your feature area."
        color = "text-blue-600"
        bgColor = "bg-blue-50 border-blue-200"
        recommendations = [
          "Wide-leg pants and A-line skirts",
          "Simple, minimal tops",
          "Detailed bottoms to balance proportions",
          "Avoid shoulder pads and boat necks",
        ]
      } else {
        shape = "Rectangle"
        description = "Your shoulders, waist, and hips are similar in measurement with little waist definition."
        color = "text-green-600"
        bgColor = "bg-green-50 border-green-200"
        recommendations = [
          "Create curves with peplum tops and belts",
          "Layered outfits add dimension",
          "Ruffles and details at bust or hips",
          "High-waisted bottoms",
        ]
      }
    } else {
      // Male body shape determination
      if (shouldersNum > hipsNum * 1.1 && waistNum < shouldersNum * 0.85) {
        shape = "Inverted Triangle"
        description =
          "You have broad shoulders that taper to a narrow waist and hips. This is often considered the athletic male build."
        color = "text-blue-600"
        bgColor = "bg-blue-50 border-blue-200"
        recommendations = [
          "Straight or slim-fit pants to balance proportions",
          "Avoid overly padded shoulders",
          "Horizontal stripes on lower body",
          "Fitted shirts that follow body contour",
        ]
      } else if (shouldersNum > hipsNum * 1.05 && waistNum >= shouldersNum * 0.85 && waistNum < shouldersNum * 0.95) {
        shape = "Trapezoid"
        description = "You have broad shoulders with moderate waist definition. A well-proportioned athletic build."
        color = "text-green-600"
        bgColor = "bg-green-50 border-green-200"
        recommendations = [
          "Most clothing styles work well",
          "Fitted shirts and jackets",
          "Straight-leg pants",
          "Emphasize natural proportions",
        ]
      } else if (waistNum >= shouldersNum * 0.95 || waistNum >= hipsNum * 1.0) {
        shape = "Oval"
        description = "You carry more weight in your midsection with narrower shoulders and hips."
        color = "text-orange-600"
        bgColor = "bg-orange-50 border-orange-200"
        recommendations = [
          "Structured blazers and jackets",
          "Vertical stripes and darker colors",
          "Avoid tight-fitting clothing",
          "Flat-front pants with a comfortable fit",
        ]
      } else if (hipsNum > shouldersNum * 1.05) {
        shape = "Triangle"
        description = "Your hips and waist are wider than your shoulders."
        color = "text-purple-600"
        bgColor = "bg-purple-50 border-purple-200"
        recommendations = [
          "Structured shoulders in jackets",
          "Layered tops to add upper body volume",
          "Dark-colored pants",
          "Horizontal patterns on top",
        ]
      } else {
        shape = "Rectangle"
        description = "Your shoulders, waist, and hips are similar in measurement with a straight silhouette."
        color = "text-teal-600"
        bgColor = "bg-teal-50 border-teal-200"
        recommendations = [
          "Layering creates visual interest",
          "Textured fabrics add dimension",
          "Fitted clothing works well",
          "Can experiment with various styles",
        ]
      }
    }

    setResult({
      shape,
      description,
      whr: Math.round(whr * 100) / 100,
      swr: Math.round(swr * 100) / 100,
      color,
      bgColor,
      recommendations,
    })
  }

  const handleReset = () => {
    setShoulders("")
    setWaist("")
    setHips("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`My body shape is ${result.shape}. WHR: ${result.whr}, SWR: ${result.swr}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Body Shape Result",
          text: `I calculated my body shape using CalcHub! My body shape is ${result.shape}.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setShoulders("")
    setWaist("")
    setHips("")
    setResult(null)
    setError("")
  }

  const unit = unitSystem === "metric" ? "cm" : "inches"
  const shapes = gender === "female" ? femaleShapes : maleShapes

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <User className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Body Shape Calculator</CardTitle>
                    <CardDescription>Determine your body shape type</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => {
                        setGender("female")
                        setResult(null)
                      }}
                      className={`p-3 rounded-lg border-2 text-center transition-all ${
                        gender === "female"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted-foreground/20 hover:border-muted-foreground/40"
                      }`}
                    >
                      <span className="font-medium">Female</span>
                    </button>
                    <button
                      onClick={() => {
                        setGender("male")
                        setResult(null)
                      }}
                      className={`p-3 rounded-lg border-2 text-center transition-all ${
                        gender === "male"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted-foreground/20 hover:border-muted-foreground/40"
                      }`}
                    >
                      <span className="font-medium">Male</span>
                    </button>
                  </div>
                </div>

                {/* Shoulder Input */}
                <div className="space-y-2">
                  <Label htmlFor="shoulders">Shoulder Circumference ({unit})</Label>
                  <Input
                    id="shoulders"
                    type="number"
                    placeholder={`Enter shoulder circumference in ${unit}`}
                    value={shoulders}
                    onChange={(e) => setShoulders(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Measure around the widest part of your shoulders</p>
                </div>

                {/* Waist Input */}
                <div className="space-y-2">
                  <Label htmlFor="waist">Waist Circumference ({unit})</Label>
                  <Input
                    id="waist"
                    type="number"
                    placeholder={`Enter waist circumference in ${unit}`}
                    value={waist}
                    onChange={(e) => setWaist(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Measure at the narrowest part of your waist</p>
                </div>

                {/* Hip Input */}
                <div className="space-y-2">
                  <Label htmlFor="hips">Hip Circumference ({unit})</Label>
                  <Input
                    id="hips"
                    type="number"
                    placeholder={`Enter hip circumference in ${unit}`}
                    value={hips}
                    onChange={(e) => setHips(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Measure around the widest part of your hips</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBodyShape} className="w-full" size="lg">
                  Calculate Body Shape
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Body Shape</p>
                      <p className={`text-3xl font-bold ${result.color} mb-2`}>{result.shape}</p>
                      <p className="text-sm text-muted-foreground">{result.description}</p>
                    </div>

                    {/* Ratios */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="text-center p-2 bg-background/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Waist-to-Hip Ratio</p>
                        <p className="font-semibold">{result.whr}</p>
                      </div>
                      <div className="text-center p-2 bg-background/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Shoulder-to-Waist Ratio</p>
                        <p className="font-semibold">{result.swr}</p>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-1 mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          Hide Recommendations <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Recommendations <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-current/10 space-y-2">
                        <p className="text-sm font-medium">Style Recommendations:</p>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          {result.recommendations.map((rec, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <span className="text-primary mt-0.5">•</span>
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">{gender === "female" ? "Female" : "Male"} Body Shapes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {shapes.map((shape, index) => (
                      <div key={index} className="p-3 rounded-lg bg-muted/50 border border-muted-foreground/10">
                        <span className="font-medium">{shape.name}</span>
                        <p className="text-sm text-muted-foreground mt-1">{shape.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How to Measure</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-medium text-foreground mb-1">Shoulders</p>
                    <p>Measure around the widest part of your shoulders, across the shoulder blades.</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-medium text-foreground mb-1">Waist</p>
                    <p>Measure at the narrowest part of your torso, usually just above the belly button.</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-medium text-foreground mb-1">Hips</p>
                    <p>Measure around the widest part of your hips and buttocks.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Body Shape Types</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Body shape refers to the natural distribution of fat and muscle across your frame, determined by your
                  bone structure and genetics. Understanding your body shape can help you make informed decisions about
                  clothing choices, fitness goals, and health awareness. While body shapes are often used in fashion to
                  guide clothing selection, they can also provide insights into potential health considerations based on
                  where you naturally carry weight.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  It's important to note that body shapes are generalizations and most people don't fit perfectly into
                  one category. Your body shape can also change over time due to factors like weight fluctuation, aging,
                  pregnancy, or changes in fitness level. The goal of understanding your body shape isn't to change it,
                  but to work with your natural proportions to feel confident and comfortable.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  <CardTitle>Health Considerations by Body Shape</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Research has shown that where you carry weight can have implications for your health. People who tend
                  to carry weight around their midsection (apple shapes) may have a higher risk of certain health
                  conditions like heart disease and type 2 diabetes compared to those who carry weight in their hips and
                  thighs (pear shapes). This is because visceral fat, which accumulates around the organs in the
                  abdominal area, is metabolically more active and can contribute to inflammation and insulin
                  resistance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Regardless of your body shape, maintaining a healthy lifestyle through balanced nutrition, regular
                  physical activity, adequate sleep, and stress management is beneficial for everyone. Focus on overall
                  health markers like blood pressure, cholesterol levels, and blood sugar rather than trying to achieve
                  a specific body shape.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Body shape assessments are estimates based on standard measurements and ratios. Individual
                      variation exists and this tool is for informational purposes only. Body shape does not define your
                      worth, health, or fitness level. For personalized health advice, please consult with a healthcare
                      professional or registered dietitian.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
