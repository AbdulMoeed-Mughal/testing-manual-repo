"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Moon, Info, AlertTriangle, Clock, Sun, Bed } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Mode = "bedtime" | "wakeup"
type TimeFormat = "12h" | "24h"

interface SleepResult {
  times: string[]
  cycles: number[]
  totalSleep: string[]
  recommended: number
}

export function SleepCalculator() {
  const [mode, setMode] = useState<Mode>("bedtime")
  const [timeFormat, setTimeFormat] = useState<TimeFormat>("12h")
  const [targetTime, setTargetTime] = useState("")
  const [fallAsleepTime, setFallAsleepTime] = useState("14")
  const [cycleLength, setCycleLength] = useState("90")
  const [result, setResult] = useState<SleepResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [warning, setWarning] = useState("")

  const formatTime = (date: Date): string => {
    if (timeFormat === "24h") {
      return date.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })
    }
    return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true })
  }

  const calculateSleep = () => {
    setError("")
    setWarning("")
    setResult(null)

    if (!targetTime) {
      setError(`Please enter a ${mode === "bedtime" ? "wake-up" : "bed"} time`)
      return
    }

    const fallAsleepMinutes = Number.parseInt(fallAsleepTime) || 14
    const cycleLengthMinutes = Number.parseInt(cycleLength) || 90

    if (fallAsleepMinutes < 0 || fallAsleepMinutes > 60) {
      setError("Fall asleep time should be between 0 and 60 minutes")
      return
    }

    if (cycleLengthMinutes < 60 || cycleLengthMinutes > 120) {
      setError("Sleep cycle length should be between 60 and 120 minutes")
      return
    }

    const [hours, minutes] = targetTime.split(":").map(Number)
    const targetDate = new Date()
    targetDate.setHours(hours, minutes, 0, 0)

    const times: string[] = []
    const cycles: number[] = []
    const totalSleep: string[] = []

    // Calculate for 4, 5, 6 sleep cycles (recommended range)
    for (let numCycles = 6; numCycles >= 4; numCycles--) {
      const sleepDurationMinutes = numCycles * cycleLengthMinutes
      const totalMinutes = sleepDurationMinutes + fallAsleepMinutes

      const calculatedDate = new Date(targetDate)

      if (mode === "bedtime") {
        // Calculate bedtime from wake-up time
        calculatedDate.setMinutes(calculatedDate.getMinutes() - totalMinutes)
      } else {
        // Calculate wake-up time from bedtime
        calculatedDate.setMinutes(calculatedDate.getMinutes() + totalMinutes)
      }

      // Round to nearest 5 minutes
      const roundedMinutes = Math.round(calculatedDate.getMinutes() / 5) * 5
      calculatedDate.setMinutes(roundedMinutes)

      times.push(formatTime(calculatedDate))
      cycles.push(numCycles)

      const sleepHours = Math.floor(sleepDurationMinutes / 60)
      const sleepMins = sleepDurationMinutes % 60
      totalSleep.push(`${sleepHours}h ${sleepMins > 0 ? `${sleepMins}m` : ""}`.trim())
    }

    // Check for warnings
    const minSleepHours = (4 * cycleLengthMinutes) / 60
    const maxSleepHours = (6 * cycleLengthMinutes) / 60

    if (minSleepHours < 3) {
      setWarning("Warning: Very short sleep duration may affect your health and cognitive function.")
    } else if (maxSleepHours > 12) {
      setWarning(
        "Warning: Unusually long sleep duration. Consider consulting a healthcare provider if this is regular.",
      )
    }

    setResult({
      times,
      cycles,
      totalSleep,
      recommended: 1, // 5 cycles is typically recommended (middle option)
    })
  }

  const handleReset = () => {
    setTargetTime("")
    setFallAsleepTime("14")
    setCycleLength("90")
    setResult(null)
    setError("")
    setWarning("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        mode === "bedtime"
          ? `Optimal bedtimes to wake up at ${targetTime}: ${result.times.join(", ")}`
          : `Optimal wake-up times for bedtime ${targetTime}: ${result.times.join(", ")}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Sleep Schedule",
          text:
            mode === "bedtime"
              ? `Optimal bedtimes to wake up at ${targetTime}: ${result.times.join(", ")}`
              : `Optimal wake-up times for bedtime ${targetTime}: ${result.times.join(", ")}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleMode = () => {
    setMode((prev) => (prev === "bedtime" ? "wakeup" : "bedtime"))
    setTargetTime("")
    setResult(null)
    setError("")
    setWarning("")
  }

  const toggleTimeFormat = () => {
    setTimeFormat((prev) => (prev === "12h" ? "24h" : "12h"))
    if (result) {
      calculateSleep()
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                    <Moon className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Sleep Calculator</CardTitle>
                    <CardDescription>Optimize your sleep schedule</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculate</span>
                  <button
                    onClick={toggleMode}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "wakeup" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "bedtime" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Bedtime
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "wakeup" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Wake-up
                    </span>
                  </button>
                </div>

                {/* Time Format Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Time Format</span>
                  <button
                    onClick={toggleTimeFormat}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        timeFormat === "24h" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        timeFormat === "12h" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      12h
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        timeFormat === "24h" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      24h
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Target Time Input */}
                <div className="space-y-2">
                  <Label htmlFor="targetTime">
                    {mode === "bedtime" ? "I want to wake up at" : "I want to go to bed at"}
                  </Label>
                  <Input
                    id="targetTime"
                    type="time"
                    value={targetTime}
                    onChange={(e) => setTargetTime(e.target.value)}
                    className="text-lg"
                  />
                </div>

                {/* Fall Asleep Time */}
                <div className="space-y-2">
                  <Label htmlFor="fallAsleep">Time to fall asleep (minutes)</Label>
                  <Input
                    id="fallAsleep"
                    type="number"
                    placeholder="14"
                    value={fallAsleepTime}
                    onChange={(e) => setFallAsleepTime(e.target.value)}
                    min="0"
                    max="60"
                  />
                  <p className="text-xs text-muted-foreground">Average is 10-20 minutes</p>
                </div>

                {/* Sleep Cycle Length */}
                <div className="space-y-2">
                  <Label htmlFor="cycleLength">Sleep cycle length (minutes)</Label>
                  <Input
                    id="cycleLength"
                    type="number"
                    placeholder="90"
                    value={cycleLength}
                    onChange={(e) => setCycleLength(e.target.value)}
                    min="60"
                    max="120"
                  />
                  <p className="text-xs text-muted-foreground">Default is 90 minutes (typical range: 80-110)</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Warning Message */}
                {warning && (
                  <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200 text-yellow-700 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {warning}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSleep} className="w-full" size="lg">
                  Calculate {mode === "bedtime" ? "Bedtimes" : "Wake-up Times"}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-indigo-50 border-indigo-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "bedtime" ? "Optimal bedtimes" : "Optimal wake-up times"}
                      </p>
                      <p className="text-lg font-medium text-indigo-700">
                        {mode === "bedtime" ? `To wake up at ${targetTime}` : `If you go to bed at ${targetTime}`}
                      </p>
                    </div>

                    <div className="space-y-3">
                      {result.times.map((time, index) => (
                        <div
                          key={index}
                          className={`p-3 rounded-lg border ${
                            index === result.recommended ? "bg-green-50 border-green-300" : "bg-white border-gray-200"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              {mode === "bedtime" ? (
                                <Bed
                                  className={`h-5 w-5 ${index === result.recommended ? "text-green-600" : "text-indigo-500"}`}
                                />
                              ) : (
                                <Sun
                                  className={`h-5 w-5 ${index === result.recommended ? "text-green-600" : "text-yellow-500"}`}
                                />
                              )}
                              <span
                                className={`text-xl font-bold ${index === result.recommended ? "text-green-700" : "text-foreground"}`}
                              >
                                {time}
                              </span>
                              {index === result.recommended && (
                                <span className="text-xs bg-green-200 text-green-800 px-2 py-0.5 rounded-full font-medium">
                                  Recommended
                                </span>
                              )}
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-medium">{result.cycles[index]} cycles</p>
                              <p className="text-xs text-muted-foreground">{result.totalSleep[index]} of sleep</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sleep Cycles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">4 cycles</span>
                      <span className="text-sm text-red-600">~6 hours (minimum)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">5 cycles</span>
                      <span className="text-sm text-green-600">~7.5 hours (ideal)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">6 cycles</span>
                      <span className="text-sm text-blue-600">~9 hours (restorative)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sleep Cycle Stages</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Stage 1: Light Sleep</p>
                    <p>Transition between wake and sleep (5-10 min)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Stage 2: True Sleep</p>
                    <p>Body temperature drops, heart rate slows (10-25 min)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Stage 3: Deep Sleep</p>
                    <p>Restorative sleep, tissue repair, immune boost (20-40 min)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">REM Sleep</p>
                    <p>Dreams occur, memory consolidation (10-60 min)</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Individual sleep needs vary based on age, health, and
                        lifestyle. Consult a healthcare professional for personalized advice.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Sleep Cycles */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Sleep Cycles</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Sleep is not a uniform state but rather a dynamic process consisting of multiple cycles that repeat
                  throughout the night. Each sleep cycle typically lasts between 80 to 110 minutes, with the average
                  being around 90 minutes. During a full night&apos;s rest, most adults complete 4 to 6 complete sleep
                  cycles. Understanding these cycles is crucial for optimizing your sleep quality and waking up feeling
                  refreshed rather than groggy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Each sleep cycle consists of four distinct stages: three stages of non-REM (NREM) sleep and one stage
                  of REM (Rapid Eye Movement) sleep. The first stage is a light transitional sleep where you can be
                  easily awakened. Stage two represents true sleep onset, where your body temperature drops and brain
                  activity slows. Stage three is deep sleep, the most restorative phase where tissue repair, immune
                  function enhancement, and growth hormone release occur. Finally, REM sleep is when most dreaming
                  happens and is essential for memory consolidation and emotional processing.
                </p>
              </CardContent>
            </Card>

            {/* Why Timing Matters */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Why Sleep Timing Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The timing of when you wake up can significantly impact how you feel throughout the day. Waking up in
                  the middle of a sleep cycle, particularly during deep sleep (Stage 3), can leave you feeling groggy,
                  disoriented, and fatigued—a phenomenon known as sleep inertia. This grogginess can persist for 30
                  minutes to several hours and can impair cognitive function, reaction time, and mood.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  By timing your sleep to complete full cycles, you&apos;re more likely to wake during lighter sleep
                  stages when your brain is naturally closer to wakefulness. This is why someone who sleeps for 7.5
                  hours (5 complete cycles) often feels more rested than someone who sleeps for 8 hours but wakes mid-
                  cycle. The Sleep Calculator helps you plan your bedtime or wake-up time to align with these natural
                  cycles, maximizing the restorative benefits of your sleep.
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting Sleep */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Moon className="h-5 w-5 text-primary" />
                  <CardTitle>Factors That Affect Sleep Quality</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While sleep cycles provide a framework for understanding rest, numerous factors influence how well you
                  actually sleep. Your circadian rhythm—the internal 24-hour clock that regulates sleepiness and
                  alertness—plays a fundamental role. This rhythm is primarily influenced by light exposure, which is
                  why maintaining consistent sleep and wake times, even on weekends, helps regulate your body&apos;s
                  natural sleep-wake cycle.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                    <h4 className="font-semibold text-indigo-800 mb-2">Sleep Environment</h4>
                    <p className="text-indigo-700 text-sm">
                      Keep your bedroom cool (65-68°F/18-20°C), dark, and quiet. Use blackout curtains and consider
                      white noise if needed. A comfortable mattress and pillows are essential investments.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Screen Time</h4>
                    <p className="text-purple-700 text-sm">
                      Blue light from screens suppresses melatonin production. Avoid screens 1-2 hours before bed, or
                      use blue light filters and night mode settings on your devices.
                    </p>
                  </div>
                  <div className="p-4 bg-teal-50 border border-teal-200 rounded-lg">
                    <h4 className="font-semibold text-teal-800 mb-2">Diet & Caffeine</h4>
                    <p className="text-teal-700 text-sm">
                      Avoid caffeine 6+ hours before bed and heavy meals 2-3 hours before sleep. Alcohol may help you
                      fall asleep but disrupts REM sleep and overall sleep quality.
                    </p>
                  </div>
                  <div className="p-4 bg-rose-50 border border-rose-200 rounded-lg">
                    <h4 className="font-semibold text-rose-800 mb-2">Exercise Timing</h4>
                    <p className="text-rose-700 text-sm">
                      Regular exercise improves sleep quality, but vigorous workouts too close to bedtime can be
                      stimulating. Aim to finish intense exercise 3-4 hours before bed.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips for Better Sleep */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Sun className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Better Sleep</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Improving your sleep quality often requires a holistic approach that addresses multiple aspects of
                  your lifestyle and sleep environment. Here are evidence-based strategies to help you get better rest:
                </p>
                <ul className="mt-4 space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Maintain a consistent schedule:</strong> Go to bed and wake up at the same time every day,
                      even on weekends. This helps regulate your circadian rhythm and improves sleep quality over time.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Create a bedtime routine:</strong> Develop relaxing pre-sleep rituals like reading, gentle
                      stretching, or taking a warm bath. This signals to your body that it&apos;s time to wind down.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Get morning sunlight:</strong> Exposure to natural light in the morning helps regulate
                      your circadian rhythm and improves alertness during the day while promoting better sleep at night.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Limit naps:</strong> If you nap, keep it to 20-30 minutes and avoid napping after 3 PM.
                      Long or late naps can interfere with nighttime sleep quality and duration.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Manage stress:</strong> Practice relaxation techniques like deep breathing, meditation, or
                      journaling before bed to calm your mind and reduce sleep-disrupting anxiety.
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
