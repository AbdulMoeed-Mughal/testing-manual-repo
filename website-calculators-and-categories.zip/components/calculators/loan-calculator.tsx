"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  DollarSign,
  Info,
  AlertTriangle,
  FileText,
  CableIcon as CalcIcon,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type PaymentFrequency = "monthly" | "bi-weekly" | "weekly"

interface LoanResult {
  paymentAmount: number
  totalPayment: number
  totalInterest: number
  interestSavings?: number
  monthsReduced?: number
  payoffDate: Date
}

interface AmortizationEntry {
  payment: number
  principal: number
  interest: number
  balance: number
}

export function LoanCalculator() {
  const [loanAmount, setLoanAmount] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [loanTermYears, setLoanTermYears] = useState("")
  const [loanTermMonths, setLoanTermMonths] = useState("")
  const [frequency, setFrequency] = useState<PaymentFrequency>("monthly")
  const [extraPayment, setExtraPayment] = useState("")
  const [startDate, setStartDate] = useState("")
  const [result, setResult] = useState<LoanResult | null>(null)
  const [showAmortization, setShowAmortization] = useState(false)
  const [amortizationSchedule, setAmortizationSchedule] = useState<AmortizationEntry[]>([])
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateLoan = () => {
    setError("")
    setResult(null)
    setAmortizationSchedule([])

    const principal = Number.parseFloat(loanAmount)
    const annualRate = Number.parseFloat(interestRate) / 100
    const years = Number.parseFloat(loanTermYears) || 0
    const months = Number.parseFloat(loanTermMonths) || 0
    const extra = Number.parseFloat(extraPayment) || 0

    if (isNaN(principal) || principal <= 0) {
      setError("Please enter a valid loan amount greater than 0")
      return
    }

    if (isNaN(annualRate) || annualRate < 0) {
      setError("Please enter a valid interest rate (0 or higher)")
      return
    }

    if (years <= 0 && months <= 0) {
      setError("Please enter a valid loan term")
      return
    }

    const totalMonths = years * 12 + months

    // Calculate frequency multipliers
    let periodsPerYear: number
    let totalPeriods: number

    if (frequency === "monthly") {
      periodsPerYear = 12
      totalPeriods = totalMonths
    } else if (frequency === "bi-weekly") {
      periodsPerYear = 26
      totalPeriods = Math.ceil((totalMonths / 12) * 26)
    } else {
      periodsPerYear = 52
      totalPeriods = Math.ceil((totalMonths / 12) * 52)
    }

    const periodicRate = annualRate / periodsPerYear

    // Calculate payment using amortization formula
    let payment: number
    if (annualRate === 0) {
      payment = principal / totalPeriods
    } else {
      payment =
        (principal * (periodicRate * Math.pow(1 + periodicRate, totalPeriods))) /
        (Math.pow(1 + periodicRate, totalPeriods) - 1)
    }

    // Calculate with extra payments
    let balance = principal
    let totalInterestPaid = 0
    let paymentNumber = 0
    const schedule: AmortizationEntry[] = []

    while (balance > 0 && paymentNumber < totalPeriods * 2) {
      paymentNumber++
      const interestPayment = balance * periodicRate
      let principalPayment = payment - interestPayment + extra

      if (principalPayment > balance) {
        principalPayment = balance
      }

      balance -= principalPayment
      totalInterestPaid += interestPayment

      if (paymentNumber <= 360) {
        // Limit schedule to first 360 payments for display
        schedule.push({
          payment: paymentNumber,
          principal: principalPayment,
          interest: interestPayment,
          balance: Math.max(0, balance),
        })
      }

      if (balance <= 0) break
    }

    // Calculate without extra payments for comparison
    let totalInterestWithoutExtra = 0
    if (extra > 0) {
      let balanceNoExtra = principal
      for (let i = 0; i < totalPeriods; i++) {
        const interestPayment = balanceNoExtra * periodicRate
        const principalPayment = payment - interestPayment
        balanceNoExtra -= principalPayment
        totalInterestWithoutExtra += interestPayment
        if (balanceNoExtra <= 0) break
      }
    }

    // Calculate payoff date
    const start = startDate ? new Date(startDate) : new Date()
    const payoffDate = new Date(start)

    if (frequency === "monthly") {
      payoffDate.setMonth(payoffDate.getMonth() + paymentNumber)
    } else if (frequency === "bi-weekly") {
      payoffDate.setDate(payoffDate.getDate() + paymentNumber * 14)
    } else {
      payoffDate.setDate(payoffDate.getDate() + paymentNumber * 7)
    }

    setResult({
      paymentAmount: payment + extra,
      totalPayment: (payment + extra) * paymentNumber,
      totalInterest: totalInterestPaid,
      interestSavings: extra > 0 ? totalInterestWithoutExtra - totalInterestPaid : undefined,
      monthsReduced: extra > 0 ? totalPeriods - paymentNumber : undefined,
      payoffDate,
    })

    setAmortizationSchedule(schedule)
  }

  const handleReset = () => {
    setLoanAmount("")
    setInterestRate("")
    setLoanTermYears("")
    setLoanTermMonths("")
    setExtraPayment("")
    setStartDate("")
    setFrequency("monthly")
    setResult(null)
    setAmortizationSchedule([])
    setShowAmortization(false)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Loan Payment: $${result.paymentAmount.toFixed(2)} per ${frequency === "monthly" ? "month" : frequency === "bi-weekly" ? "two weeks" : "week"}
Total Payment: $${result.totalPayment.toFixed(2)}
Total Interest: $${result.totalInterest.toFixed(2)}
Payoff Date: ${result.payoffDate.toLocaleDateString()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Loan Calculation",
          text: `I calculated my loan using CalcHub! Payment: $${result.paymentAmount.toFixed(2)} per ${frequency === "monthly" ? "month" : frequency === "bi-weekly" ? "two weeks" : "week"}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Loan Calculator</CardTitle>
                    <CardDescription>Calculate your loan payments and schedule</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Loan Amount */}
                <div className="space-y-2">
                  <Label htmlFor="loanAmount">Loan Amount ($)</Label>
                  <Input
                    id="loanAmount"
                    type="number"
                    placeholder="Enter loan amount"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Enter interest rate"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Loan Term */}
                <div className="space-y-2">
                  <Label>Loan Term</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder="Years"
                        value={loanTermYears}
                        onChange={(e) => setLoanTermYears(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Months"
                        value={loanTermMonths}
                        onChange={(e) => setLoanTermMonths(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Frequency */}
                <div className="space-y-2">
                  <Label>Payment Frequency</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      type="button"
                      variant={frequency === "monthly" ? "default" : "outline"}
                      onClick={() => setFrequency("monthly")}
                      className="w-full"
                    >
                      Monthly
                    </Button>
                    <Button
                      type="button"
                      variant={frequency === "bi-weekly" ? "default" : "outline"}
                      onClick={() => setFrequency("bi-weekly")}
                      className="w-full"
                    >
                      Bi-weekly
                    </Button>
                    <Button
                      type="button"
                      variant={frequency === "weekly" ? "default" : "outline"}
                      onClick={() => setFrequency("weekly")}
                      className="w-full"
                    >
                      Weekly
                    </Button>
                  </div>
                </div>

                {/* Extra Payment */}
                <div className="space-y-2">
                  <Label htmlFor="extraPayment">Extra Payment (Optional)</Label>
                  <Input
                    id="extraPayment"
                    type="number"
                    placeholder="Additional payment per period"
                    value={extraPayment}
                    onChange={(e) => setExtraPayment(e.target.value)}
                    min="0"
                    step="10"
                  />
                </div>

                {/* Start Date */}
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date (Optional)</Label>
                  <Input id="startDate" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLoan} className="w-full" size="lg">
                  Calculate Loan
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                      <div className="space-y-3">
                        <div className="text-center pb-3 border-b border-green-200">
                          <p className="text-sm text-muted-foreground mb-1">Payment Amount</p>
                          <p className="text-4xl font-bold text-green-600">{formatCurrency(result.paymentAmount)}</p>
                          <p className="text-sm text-green-600 mt-1">
                            per {frequency === "monthly" ? "month" : frequency === "bi-weekly" ? "two weeks" : "week"}
                          </p>
                        </div>

                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div className="text-center p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground mb-1">Total Payment</p>
                            <p className="font-semibold text-foreground">{formatCurrency(result.totalPayment)}</p>
                          </div>
                          <div className="text-center p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground mb-1">Total Interest</p>
                            <p className="font-semibold text-foreground">{formatCurrency(result.totalInterest)}</p>
                          </div>
                        </div>

                        {result.interestSavings !== undefined && result.interestSavings > 0 && (
                          <div className="p-3 bg-white rounded-lg border border-green-300">
                            <p className="text-sm text-muted-foreground mb-1">Extra Payment Benefits</p>
                            <p className="font-semibold text-green-700">
                              Save {formatCurrency(result.interestSavings)} in interest
                            </p>
                            <p className="text-sm text-green-600">Pay off {result.monthsReduced} payments earlier</p>
                          </div>
                        )}

                        <div className="text-center p-2 bg-white rounded-lg">
                          <p className="text-sm text-muted-foreground mb-1">Payoff Date</p>
                          <p className="font-semibold text-foreground">
                            {result.payoffDate.toLocaleDateString("en-US", {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })}
                          </p>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>

                    {/* Amortization Toggle */}
                    {amortizationSchedule.length > 0 && (
                      <Button
                        variant="outline"
                        className="w-full bg-transparent"
                        onClick={() => setShowAmortization(!showAmortization)}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        {showAmortization ? "Hide" : "Show"} Amortization Schedule
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Payment Frequency Impact</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-foreground mb-1">Monthly Payments</p>
                      <p>Standard 12 payments per year. Lower payment amount but highest total interest.</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-foreground mb-1">Bi-weekly Payments</p>
                      <p>26 payments per year (one extra month). Saves interest and pays off loan faster.</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-foreground mb-1">Weekly Payments</p>
                      <p>52 payments per year. Highest frequency, maximum interest savings.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Loan Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-xs">
                    <p className="font-semibold text-foreground mb-2">Payment = P × [r × (1 + r)ⁿ] / [(1 + r)ⁿ − 1]</p>
                    <div className="space-y-1 text-muted-foreground">
                      <p>P = Principal (loan amount)</p>
                      <p>r = Periodic interest rate</p>
                      <p>n = Total number of payments</p>
                    </div>
                  </div>
                  <p>
                    This amortization formula ensures each payment covers both interest and principal, with the balance
                    gradually shifting toward principal over time.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-yellow-200 bg-yellow-50">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-600" />
                    <CardTitle className="text-lg text-yellow-900">Disclaimer</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-yellow-800">
                    This calculator provides estimates only. Actual loan terms may vary based on lender policies, credit
                    score, fees, and other factors. Consult with a financial advisor for personalized advice.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Amortization Schedule */}
          {showAmortization && amortizationSchedule.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Amortization Schedule</CardTitle>
                <CardDescription>First {Math.min(amortizationSchedule.length, 360)} payments breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Payment #</th>
                        <th className="text-right p-2">Principal</th>
                        <th className="text-right p-2">Interest</th>
                        <th className="text-right p-2">Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {amortizationSchedule.slice(0, 12).map((entry) => (
                        <tr key={entry.payment} className="border-b hover:bg-muted/50">
                          <td className="p-2">{entry.payment}</td>
                          <td className="text-right p-2">{formatCurrency(entry.principal)}</td>
                          <td className="text-right p-2">{formatCurrency(entry.interest)}</td>
                          <td className="text-right p-2 font-medium">{formatCurrency(entry.balance)}</td>
                        </tr>
                      ))}
                      {amortizationSchedule.length > 12 && (
                        <tr>
                          <td colSpan={4} className="text-center p-4 text-muted-foreground">
                            ... {amortizationSchedule.length - 12} more payments ...
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Loan Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A loan is a financial agreement where a lender provides money to a borrower with the expectation that
                  it will be repaid over time, typically with interest. Understanding how loans work is crucial for
                  making informed financial decisions, whether you're considering a mortgage, auto loan, student loan,
                  or personal loan. The loan calculator helps you visualize the true cost of borrowing and plan your
                  budget accordingly.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When you take out a loan, you agree to repay the principal (the amount borrowed) plus interest (the
                  cost of borrowing) over a specified period called the loan term. Each payment you make typically
                  includes both principal and interest, with the proportion changing over time in a process called
                  amortization. In the early stages of the loan, most of your payment goes toward interest, but as the
                  balance decreases, more of each payment is applied to the principal.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CalcIcon className="h-5 w-5 text-primary" />
                  <CardTitle>How Loan Payments Are Calculated</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Loan payments are calculated using an amortization formula that ensures you pay off both the principal
                  and interest by the end of the loan term. The formula takes into account three key variables: the
                  principal amount, the interest rate, and the number of payments. The result is a fixed payment amount
                  that remains constant throughout the loan term (for fixed-rate loans), making budgeting predictable
                  and straightforward.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The periodic interest rate is determined by dividing your annual interest rate by the number of
                  payment periods per year. For monthly payments, you divide by 12; for bi-weekly payments, by 26; and
                  for weekly payments, by 52. This periodic rate is then applied to your remaining balance each period
                  to calculate the interest portion of your payment. The remainder of your payment goes toward reducing
                  the principal balance. Over time, as your balance decreases, the interest portion shrinks and the
                  principal portion grows, even though your total payment stays the same.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>The Impact of Payment Frequency</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  One of the most effective strategies for saving money on a loan is to increase your payment frequency.
                  While monthly payments are the standard, making bi-weekly or weekly payments can significantly reduce
                  the total interest you pay and help you pay off your loan faster. This works because more frequent
                  payments mean you're reducing the principal balance more often, which in turn reduces the amount of
                  interest that accrues.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, switching from monthly to bi-weekly payments results in 26 payments per year instead of
                  12, which is equivalent to making 13 monthly payments instead of 12. This extra payment each year goes
                  entirely toward principal reduction, accelerating your loan payoff. Similarly, weekly payments create
                  even more opportunities to chip away at the principal. While each individual payment is smaller, the
                  cumulative effect can save you thousands of dollars in interest over the life of a large loan like a
                  mortgage.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  <CardTitle>Extra Payments and Early Payoff</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Making extra payments toward your loan principal is one of the most powerful ways to save money and
                  achieve debt freedom faster. Even small additional payments can have a substantial impact over time
                  because they reduce the principal balance on which future interest is calculated. For instance, adding
                  just $100 to a monthly mortgage payment could save tens of thousands of dollars in interest over a
                  30-year term and shave years off your payoff date.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When making extra payments, it's important to specify that the additional amount should be applied to
                  the principal, not future payments. Some lenders automatically apply extra payments to principal,
                  while others may apply them differently unless instructed. Check with your lender about their policy
                  and whether there are any prepayment penalties. Most modern loans don't have these penalties, but it's
                  always wise to verify before implementing an accelerated payment strategy.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Managing Your Loan</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Successfully managing a loan requires careful planning and disciplined execution. Start by ensuring
                  you can comfortably afford the monthly payment before taking out the loan. A general rule of thumb is
                  that all your debt payments combined shouldn't exceed 36% of your gross monthly income. Set up
                  automatic payments to ensure you never miss a due date, as late payments can result in fees and damage
                  your credit score.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Consider refinancing if interest rates drop significantly or if your credit score improves
                  substantially after taking out the original loan. Refinancing can lower your interest rate, reduce
                  your monthly payment, or shorten your loan term. However, be aware of closing costs and fees
                  associated with refinancing, and calculate whether the long-term savings justify these upfront
                  expenses. Additionally, maintain an emergency fund to cover several months of loan payments in case of
                  unexpected financial challenges, ensuring you can stay current on your loan obligations even during
                  difficult times.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
