"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Square, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type ElementType = "slab" | "beam" | "column" | "footing"

interface FormworkResult {
  area: number
  totalArea: number
  estimatedCost: number
}

export function FormworkAreaCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [elementType, setElementType] = useState<ElementType>("slab")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [depth, setDepth] = useState("")
  const [diameter, setDiameter] = useState("")
  const [quantity, setQuantity] = useState("1")
  const [costRate, setCostRate] = useState("")
  const [result, setResult] = useState<FormworkResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateArea = () => {
    setError("")
    setResult(null)

    const quantityNum = Number.parseInt(quantity)
    if (isNaN(quantityNum) || quantityNum < 1) {
      setError("Quantity must be at least 1")
      return
    }

    let areaPerElement = 0

    if (elementType === "slab") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)

      if (isNaN(lengthNum) || lengthNum <= 0 || isNaN(widthNum) || widthNum <= 0) {
        setError("Length and width must be positive numbers")
        return
      }

      areaPerElement = lengthNum * widthNum
    } else if (elementType === "beam") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)
      const depthNum = Number.parseFloat(depth)

      if (
        isNaN(lengthNum) ||
        lengthNum <= 0 ||
        isNaN(widthNum) ||
        widthNum <= 0 ||
        isNaN(depthNum) ||
        depthNum <= 0
      ) {
        setError("All dimensions must be positive numbers")
        return
      }

      areaPerElement = 2 * (depthNum * lengthNum) + widthNum * lengthNum
    } else if (elementType === "column") {
      const heightNum = Number.parseFloat(height)

      if (isNaN(heightNum) || heightNum <= 0) {
        setError("Height must be a positive number")
        return
      }

      if (diameter) {
        const diameterNum = Number.parseFloat(diameter)
        if (isNaN(diameterNum) || diameterNum <= 0) {
          setError("Diameter must be a positive number")
          return
        }
        const perimeter = Math.PI * diameterNum
        areaPerElement = perimeter * heightNum
      } else {
        const lengthNum = Number.parseFloat(length)
        const widthNum = Number.parseFloat(width)

        if (isNaN(lengthNum) || lengthNum <= 0 || isNaN(widthNum) || widthNum <= 0) {
          setError("Length and width must be positive numbers")
          return
        }

        const perimeter = 2 * (lengthNum + widthNum)
        areaPerElement = perimeter * heightNum
      }
    } else if (elementType === "footing") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)
      const depthNum = Number.parseFloat(depth)

      if (
        isNaN(lengthNum) ||
        lengthNum <= 0 ||
        isNaN(widthNum) ||
        widthNum <= 0 ||
        isNaN(depthNum) ||
        depthNum <= 0
      ) {
        setError("All dimensions must be positive numbers")
        return
      }

      areaPerElement = 2 * (lengthNum * depthNum) + 2 * (widthNum * depthNum) + lengthNum * widthNum
    }

    const totalArea = areaPerElement * quantityNum

    let estimatedCost = 0
    if (costRate) {
      const costRateNum = Number.parseFloat(costRate)
      if (!isNaN(costRateNum) && costRateNum > 0) {
        estimatedCost = totalArea * costRateNum
      }
    }

    setResult({
      area: areaPerElement,
      totalArea,
      estimatedCost,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setHeight("")
    setDepth("")
    setDiameter("")
    setQuantity("1")
    setCostRate("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Formwork Area: ${result.totalArea.toFixed(2)} ${unitSystem === "metric" ? "m²" : "ft²"} (${quantity} ${elementType}${Number.parseInt(quantity) > 1 ? "s" : ""})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Formwork Area Calculator Result",
          text: `Total Formwork Area: ${result.totalArea.toFixed(2)} ${unitSystem === "metric" ? "m²" : "ft²"}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setHeight("")
    setDepth("")
    setDiameter("")
    setResult(null)
    setError("")
  }

  const getInputFields = () => {
    const unit = unitSystem === "metric" ? "m" : "ft"

    switch (elementType) {
      case "slab":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="length">Length ({unit})</Label>
              <Input
                id="length"
                type="number"
                placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                value={length}
                onChange={(e) => setLength(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="width">Width ({unit})</Label>
              <Input
                id="width"
                type="number"
                placeholder={`Enter width in ${unitSystem === "metric" ? "meters" : "feet"}`}
                value={width}
                onChange={(e) => setWidth(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
          </>
        )
      case "beam":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="length">Length ({unit})</Label>
              <Input
                id="length"
                type="number"
                placeholder="Enter length"
                value={length}
                onChange={(e) => setLength(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="width">Width ({unit})</Label>
              <Input
                id="width"
                type="number"
                placeholder="Enter width"
                value={width}
                onChange={(e) => setWidth(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="depth">Depth ({unit})</Label>
              <Input
                id="depth"
                type="number"
                placeholder="Enter depth"
                value={depth}
                onChange={(e) => setDepth(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
          </>
        )
      case "column":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="height">Height ({unit})</Label>
              <Input
                id="height"
                type="number"
                placeholder="Enter height"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
            <div className="space-y-2">
              <Label>Column Shape</Label>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  type="button"
                  variant={diameter ? "outline" : "secondary"}
                  onClick={() => {
                    setDiameter("")
                  }}
                  className="h-10"
                >
                  Rectangular
                </Button>
                <Button
                  type="button"
                  variant={diameter ? "secondary" : "outline"}
                  onClick={() => {
                    setLength("")
                    setWidth("")
                    setDiameter("0.3")
                  }}
                  className="h-10"
                >
                  Circular
                </Button>
              </div>
            </div>
            {diameter ? (
              <div className="space-y-2">
                <Label htmlFor="diameter">Diameter ({unit})</Label>
                <Input
                  id="diameter"
                  type="number"
                  placeholder="Enter diameter"
                  value={diameter}
                  onChange={(e) => setDiameter(e.target.value)}
                  min="0"
                  step="0.01"
                />
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="length">Length ({unit})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder="Enter length"
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="width">Width ({unit})</Label>
                  <Input
                    id="width"
                    type="number"
                    placeholder="Enter width"
                    value={width}
                    onChange={(e) => setWidth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>
              </>
            )}
          </>
        )
      case "footing":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="length">Length ({unit})</Label>
              <Input
                id="length"
                type="number"
                placeholder="Enter length"
                value={length}
                onChange={(e) => setLength(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="width">Width ({unit})</Label>
              <Input
                id="width"
                type="number"
                placeholder="Enter width"
                value={width}
                onChange={(e) => setWidth(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="depth">Depth ({unit})</Label>
              <Input
                id="depth"
                type="number"
                placeholder="Enter depth"
                value={depth}
                onChange={(e) => setDepth(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>
          </>
        )
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Square className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Formwork Area Calculator</CardTitle>
                    <CardDescription>Calculate formwork area for concrete elements</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="element-type">Element Type</Label>
                  <Select value={elementType} onValueChange={(value: ElementType) => {
                    setElementType(value)
                    setLength("")
                    setWidth("")
                    setHeight("")
                    setDepth("")
                    setDiameter("")
                    setResult(null)
                    setError("")
                  }}>
                    <SelectTrigger id="element-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="slab">Slab</SelectItem>
                      <SelectItem value="beam">Beam</SelectItem>
                      <SelectItem value="column">Column</SelectItem>
                      <SelectItem value="footing">Footing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {getInputFields()}

                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    placeholder="Number of elements"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cost-rate">
                    Cost Rate (Optional) ({unitSystem === "metric" ? "per m²" : "per ft²"})
                  </Label>
                  <Input
                    id="cost-rate"
                    type="number"
                    placeholder="Enter cost per unit area"
                    value={costRate}
                    onChange={(e) => setCostRate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculateArea} className="w-full" size="lg">
                  Calculate Area
                </Button>

                {result && (
                  <div className="p-5 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Total Formwork Area</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {result.totalArea.toFixed(2)} {unitSystem === "metric" ? "m²" : "ft²"}
                        </p>
                        <p className="text-sm text-muted-foreground mt-2">
                          Area per element: {result.area.toFixed(2)} {unitSystem === "metric" ? "m²" : "ft²"}
                        </p>
                      </div>

                      {result.estimatedCost > 0 && (
                        <div className="pt-3 border-t border-amber-200">
                          <p className="text-sm text-muted-foreground">Estimated Cost</p>
                          <p className="text-lg font-semibold text-amber-700">
                            ${result.estimatedCost.toFixed(2)}
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t border-amber-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formwork Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium mb-1">Slab</p>
                      <p className="text-muted-foreground">Area = Length × Width</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium mb-1">Beam</p>
                      <p className="text-muted-foreground">Area = 2(Depth × Length) + Width × Length</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium mb-1">Column</p>
                      <p className="text-muted-foreground">Area = Perimeter × Height</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium mb-1">Footing</p>
                      <p className="text-muted-foreground">Area = Side areas + Bottom area</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Tips</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Measure dimensions accurately for precise estimates</p>
                  <p>• Add 5-10% wastage for material planning</p>
                  <p>• Consider reusability of formwork materials</p>
                  <p>• Check local cost rates for accurate budgeting</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Formwork Area?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Formwork area refers to the total surface area of temporary molds or structures used to hold concrete
                  in place while it sets and gains strength. Accurate calculation of formwork area is essential for
                  estimating material requirements, labor costs, and project budgets in concrete construction work.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The formwork area varies depending on the type of concrete element being constructed. Slabs require
                  formwork only on the bottom surface, while beams need formwork on three sides (bottom and two sides).
                  Columns require formwork around the entire perimeter, and footings typically need formwork on all sides
                  including the bottom, though the bottom may sometimes rest directly on excavated soil.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Formwork Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Different types of formwork are used for various structural elements. Slab formwork typically consists
                  of plywood or metal sheets supported by props and beams. Beam formwork includes side panels and soffit
                  boards that create a three-sided mold. Column formwork can be prefabricated panels or site-built forms
                  that completely enclose the column perimeter.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Material selection for formwork depends on project requirements, budget, and reusability needs. Plywood
                  is commonly used for smaller projects and can be reused several times. Steel formwork offers higher
                  durability and more reuses but has a higher initial cost. Aluminum formwork is lightweight and ideal for
                  repetitive structures like residential buildings, while plastic formwork is increasingly used for
                  specific applications due to its light weight and ease of handling.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle>Important Notes</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Formwork area calculations are approximate and may vary based on construction method and site practices.
                  Always add appropriate wastage factors and consider the complexity of the structure when ordering
                  materials. The actual formwork requirements may increase with architectural features, openings, or
                  irregular shapes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Ensure formwork is properly designed to withstand the weight and pressure of fresh concrete. Inadequate
                  formwork can lead to structural failures, safety hazards, and costly repairs. Consult structural
                  engineers and follow local building codes for critical formwork design and installation requirements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
