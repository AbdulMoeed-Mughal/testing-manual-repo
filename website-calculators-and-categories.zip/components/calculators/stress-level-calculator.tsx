"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Brain,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Moon,
  Briefcase,
  Activity,
  Heart,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface StressResult {
  score: number
  maxScore: number
  percentage: number
  category: string
  color: string
  bgColor: string
  topFactors: { name: string; score: number; maxScore: number }[]
}

type ActivityLevel = "sedentary" | "light" | "moderate" | "active"

export function StressLevelCalculator() {
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [sleepHours, setSleepHours] = useState("")
  const [workHours, setWorkHours] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")

  // Optional stress indicators
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [irritability, setIrritability] = useState(false)
  const [anxiety, setAnxiety] = useState(false)
  const [fatigue, setFatigue] = useState(false)
  const [moodSwings, setMoodSwings] = useState(false)
  const [recentStressors, setRecentStressors] = useState(false)

  const [result, setResult] = useState<StressResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateStress = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    if (isNaN(ageNum) || ageNum < 10 || ageNum > 120) {
      setError("Please enter a valid age between 10 and 120")
      return
    }

    const sleepNum = Number.parseFloat(sleepHours)
    if (isNaN(sleepNum) || sleepNum < 0 || sleepNum > 24) {
      setError("Please enter valid sleep hours between 0 and 24")
      return
    }

    const workNum = Number.parseFloat(workHours)
    if (isNaN(workNum) || workNum < 0 || workNum > 168) {
      setError("Please enter valid work hours per week (0-168)")
      return
    }

    // Calculate stress scores for each factor
    const factors: { name: string; score: number; maxScore: number }[] = []

    // Sleep score (optimal: 7-9 hours) - max 25 points
    let sleepScore = 0
    if (sleepNum < 5) sleepScore = 25
    else if (sleepNum < 6) sleepScore = 20
    else if (sleepNum < 7) sleepScore = 10
    else if (sleepNum <= 9) sleepScore = 0
    else if (sleepNum <= 10) sleepScore = 5
    else sleepScore = 15
    factors.push({ name: "Sleep", score: sleepScore, maxScore: 25 })

    // Work hours score (optimal: 35-45 hours) - max 25 points
    let workScore = 0
    if (workNum > 60) workScore = 25
    else if (workNum > 50) workScore = 20
    else if (workNum > 45) workScore = 10
    else if (workNum >= 35) workScore = 0
    else if (workNum >= 20) workScore = 5
    else workScore = 10
    factors.push({ name: "Work Hours", score: workScore, maxScore: 25 })

    // Activity level score - max 15 points
    let activityScore = 0
    switch (activityLevel) {
      case "sedentary":
        activityScore = 15
        break
      case "light":
        activityScore = 10
        break
      case "moderate":
        activityScore = 5
        break
      case "active":
        activityScore = 0
        break
    }
    factors.push({ name: "Physical Activity", score: activityScore, maxScore: 15 })

    // Stress indicators (optional) - max 35 points total
    let indicatorScore = 0
    if (irritability) indicatorScore += 7
    if (anxiety) indicatorScore += 10
    if (fatigue) indicatorScore += 8
    if (moodSwings) indicatorScore += 5
    if (recentStressors) indicatorScore += 5
    factors.push({ name: "Stress Indicators", score: indicatorScore, maxScore: 35 })

    const totalScore = sleepScore + workScore + activityScore + indicatorScore
    const maxScore = 100
    const percentage = Math.round((totalScore / maxScore) * 100)

    // Determine category
    let category: string
    let color: string
    let bgColor: string

    if (percentage <= 25) {
      category = "Low Stress"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (percentage <= 50) {
      category = "Moderate Stress"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (percentage <= 75) {
      category = "High Stress"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Very High Stress"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    // Sort factors by score (highest first) for top contributors
    const topFactors = [...factors].sort((a, b) => b.score - a.score)

    setResult({
      score: totalScore,
      maxScore,
      percentage,
      category,
      color,
      bgColor,
      topFactors,
    })
  }

  const handleReset = () => {
    setAge("")
    setGender("male")
    setSleepHours("")
    setWorkHours("")
    setActivityLevel("moderate")
    setIrritability(false)
    setAnxiety(false)
    setFatigue(false)
    setMoodSwings(false)
    setRecentStressors(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`My Stress Level: ${result.percentage}% (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Stress Level Assessment",
          text: `I assessed my stress level using CalcHub! My stress level is ${result.percentage}% (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getRecommendations = () => {
    if (!result) return []

    const recommendations: string[] = []

    const sleepNum = Number.parseFloat(sleepHours)
    if (sleepNum < 7) {
      recommendations.push("Aim for 7-9 hours of quality sleep per night to reduce stress hormones")
    }

    const workNum = Number.parseFloat(workHours)
    if (workNum > 45) {
      recommendations.push("Consider setting boundaries on work hours to prevent burnout")
    }

    if (activityLevel === "sedentary" || activityLevel === "light") {
      recommendations.push("Increase physical activity - even 30 minutes of walking can reduce stress")
    }

    if (anxiety || irritability) {
      recommendations.push("Practice relaxation techniques like deep breathing, meditation, or yoga")
    }

    if (fatigue) {
      recommendations.push("Evaluate your nutrition and hydration - deficiencies can worsen stress")
    }

    if (recommendations.length === 0) {
      recommendations.push("Continue maintaining your healthy habits to keep stress levels low")
    }

    return recommendations
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Brain className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Stress Level Calculator</CardTitle>
                    <CardDescription>Assess your stress based on lifestyle factors</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                    max="120"
                  />
                </div>

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setGender("male")}
                      className={`p-3 rounded-lg border text-sm font-medium transition-colors ${
                        gender === "male"
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-background hover:bg-muted border-input"
                      }`}
                    >
                      Male
                    </button>
                    <button
                      onClick={() => setGender("female")}
                      className={`p-3 rounded-lg border text-sm font-medium transition-colors ${
                        gender === "female"
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-background hover:bg-muted border-input"
                      }`}
                    >
                      Female
                    </button>
                  </div>
                </div>

                {/* Sleep Hours Input */}
                <div className="space-y-2">
                  <Label htmlFor="sleep" className="flex items-center gap-2">
                    <Moon className="h-4 w-4" />
                    Sleep Duration (hours/day)
                  </Label>
                  <Input
                    id="sleep"
                    type="number"
                    placeholder="Average hours of sleep per night"
                    value={sleepHours}
                    onChange={(e) => setSleepHours(e.target.value)}
                    min="0"
                    max="24"
                    step="0.5"
                  />
                </div>

                {/* Work Hours Input */}
                <div className="space-y-2">
                  <Label htmlFor="work" className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4" />
                    Work Hours (per week)
                  </Label>
                  <Input
                    id="work"
                    type="number"
                    placeholder="Average work hours per week"
                    value={workHours}
                    onChange={(e) => setWorkHours(e.target.value)}
                    min="0"
                    max="168"
                  />
                </div>

                {/* Activity Level Selection */}
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Activity className="h-4 w-4" />
                    Physical Activity Level
                  </Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "sedentary", label: "Sedentary" },
                      { value: "light", label: "Light" },
                      { value: "moderate", label: "Moderate" },
                      { value: "active", label: "Active" },
                    ].map((level) => (
                      <button
                        key={level.value}
                        onClick={() => setActivityLevel(level.value as ActivityLevel)}
                        className={`p-2 rounded-lg border text-sm font-medium transition-colors ${
                          activityLevel === level.value
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background hover:bg-muted border-input"
                        }`}
                      >
                        {level.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Advanced Options Toggle */}
                <button
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  Optional: Stress Indicators
                </button>

                {/* Advanced Options */}
                {showAdvanced && (
                  <div className="space-y-3 p-4 bg-muted/50 rounded-lg">
                    <Label className="text-sm font-medium">Self-reported indicators (check all that apply)</Label>
                    <div className="space-y-2">
                      {[
                        { id: "irritability", label: "Irritability", state: irritability, setter: setIrritability },
                        { id: "anxiety", label: "Anxiety", state: anxiety, setter: setAnxiety },
                        { id: "fatigue", label: "Persistent Fatigue", state: fatigue, setter: setFatigue },
                        { id: "moodSwings", label: "Mood Swings", state: moodSwings, setter: setMoodSwings },
                        {
                          id: "stressors",
                          label: "Recent Major Life Events",
                          state: recentStressors,
                          setter: setRecentStressors,
                        },
                      ].map((indicator) => (
                        <label
                          key={indicator.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={indicator.state}
                            onChange={(e) => indicator.setter(e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300"
                          />
                          <span className="text-sm">{indicator.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateStress} className="w-full" size="lg">
                  Calculate Stress Level
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Stress Level</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.percentage}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Visual Gauge */}
                    <div className="mt-4 mb-4">
                      <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            result.percentage <= 25
                              ? "bg-green-500"
                              : result.percentage <= 50
                                ? "bg-yellow-500"
                                : result.percentage <= 75
                                  ? "bg-orange-500"
                                  : "bg-red-500"
                          }`}
                          style={{ width: `${result.percentage}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>Low</span>
                        <span>Moderate</span>
                        <span>High</span>
                        <span>Very High</span>
                      </div>
                    </div>

                    {/* Toggle Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground py-2"
                    >
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showDetails ? "Hide Details" : "Show Details"}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-current/10 space-y-3">
                        <div className="text-sm space-y-2">
                          <p className="font-medium">Contributing Factors:</p>
                          {result.topFactors.map((factor) => (
                            <div key={factor.name} className="flex items-center justify-between">
                              <span>{factor.name}</span>
                              <div className="flex items-center gap-2">
                                <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                                  <div
                                    className={`h-full ${
                                      factor.score === 0
                                        ? "bg-green-500"
                                        : factor.score <= factor.maxScore * 0.3
                                          ? "bg-yellow-500"
                                          : factor.score <= factor.maxScore * 0.6
                                            ? "bg-orange-500"
                                            : "bg-red-500"
                                    }`}
                                    style={{ width: `${(factor.score / factor.maxScore) * 100}%` }}
                                  />
                                </div>
                                <span className="text-xs w-12 text-right">
                                  {factor.score}/{factor.maxScore}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="text-sm">
                          <p className="font-medium mb-2">Recommendations:</p>
                          <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                            {getRecommendations().map((rec, idx) => (
                              <li key={idx}>{rec}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Stress Level Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low Stress</span>
                      <span className="text-sm text-green-600">0 - 25%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Stress</span>
                      <span className="text-sm text-yellow-600">26 - 50%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">High Stress</span>
                      <span className="text-sm text-orange-600">51 - 75%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very High Stress</span>
                      <span className="text-sm text-red-600">76 - 100%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Optimal Ranges</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Sleep Duration</p>
                    <p className="text-muted-foreground">7-9 hours per night for adults</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Work Hours</p>
                    <p className="text-muted-foreground">35-45 hours per week is ideal</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Physical Activity</p>
                    <p className="text-muted-foreground">Moderate to active for stress reduction</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Scoring Methodology</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>This calculator assigns weighted scores to each lifestyle factor:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Sleep quality: up to 25 points</li>
                    <li>Work hours: up to 25 points</li>
                    <li>Physical activity: up to 15 points</li>
                    <li>Stress indicators: up to 35 points</li>
                  </ul>
                  <p className="mt-2">
                    Higher scores indicate higher stress levels. The percentage is calculated from the total possible
                    score of 100 points.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Stress</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Stress is the body's natural response to challenges or demands. While short-term stress can be
                  beneficial (helping you meet deadlines or avoid danger), chronic stress can have serious negative
                  effects on both physical and mental health. Understanding your stress level is the first step toward
                  managing it effectively.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Key factors that contribute to stress include sleep quality, work-life balance, physical activity
                  levels, and psychological symptoms like anxiety and irritability. By identifying which factors
                  contribute most to your stress, you can develop targeted strategies for stress reduction.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Health Effects of Chronic Stress</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Prolonged exposure to stress can lead to various health problems including cardiovascular issues,
                  weakened immune function, digestive problems, sleep disorders, and mental health conditions like
                  anxiety and depression. Physical symptoms may include headaches, muscle tension, fatigue, and changes
                  in appetite.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Recognizing early warning signs of elevated stress allows you to take proactive steps before health
                  problems develop. Regular stress assessment can help track patterns and identify triggers that may
                  require attention or lifestyle modifications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Stress Management Strategies</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Physical Strategies</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>Regular exercise (30+ minutes daily)</li>
                      <li>Adequate sleep (7-9 hours)</li>
                      <li>Balanced nutrition</li>
                      <li>Limiting caffeine and alcohol</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Mental Strategies</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>Meditation and mindfulness</li>
                      <li>Deep breathing exercises</li>
                      <li>Setting realistic goals</li>
                      <li>Maintaining social connections</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Lifestyle Changes</h4>
                    <ul className="text-sm text-purple-700 space-y-1">
                      <li>Time management techniques</li>
                      <li>Setting work-life boundaries</li>
                      <li>Engaging in hobbies</li>
                      <li>Taking regular breaks</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Professional Support</h4>
                    <ul className="text-sm text-orange-700 space-y-1">
                      <li>Counseling or therapy</li>
                      <li>Stress management programs</li>
                      <li>Support groups</li>
                      <li>Medical consultation</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Stress level assessments are estimates based on self-reported and standard inputs. This tool is not a
                  medical diagnosis and should not replace professional evaluation. If you are experiencing significant
                  stress, anxiety, depression, or other mental health concerns, please consult a healthcare professional
                  or mental health specialist for personalized evaluation and guidance. If you are in crisis, contact
                  emergency services or a crisis helpline immediately.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
