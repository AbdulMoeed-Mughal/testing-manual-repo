"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, Gauge, Droplets, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface PumpPowerResult {
  power: number
  powerUnit: string
  hydraulicPower: number
  category: string
  color: string
  bgColor: string
}

const fluidPresets = {
  water: { density: 998, name: "Water (20°C)" },
  seawater: { density: 1025, name: "Sea Water" },
  oil: { density: 850, name: "Oil (SAE 30)" },
  gasoline: { density: 750, name: "Gasoline" },
}

export function PumpPowerCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [flowRate, setFlowRate] = useState("")
  const [flowRateUnit, setFlowRateUnit] = useState("m3s")
  const [density, setDensity] = useState("")
  const [head, setHead] = useState("")
  const [efficiency, setEfficiency] = useState("")
  const [efficiencyMode, setEfficiencyMode] = useState<"decimal" | "percent">("percent")
  const [powerUnit, setPowerUnit] = useState("kW")
  const [result, setResult] = useState<PumpPowerResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const g = 9.81 // gravitational acceleration m/s²

  const calculatePumpPower = () => {
    setError("")
    setResult(null)

    const flowRateNum = Number.parseFloat(flowRate)
    const densityNum = Number.parseFloat(density)
    const headNum = Number.parseFloat(head)
    const efficiencyNum = Number.parseFloat(efficiency)

    if (isNaN(flowRateNum) || flowRateNum <= 0) {
      setError("Please enter a valid flow rate greater than 0")
      return
    }

    if (isNaN(densityNum) || densityNum <= 0) {
      setError("Please enter a valid fluid density greater than 0")
      return
    }

    if (isNaN(headNum) || headNum <= 0) {
      setError("Please enter a valid total head greater than 0")
      return
    }

    if (isNaN(efficiencyNum) || efficiencyNum <= 0) {
      setError("Please enter a valid pump efficiency greater than 0")
      return
    }

    // Convert efficiency to decimal
    const effDecimal = efficiencyMode === "percent" ? efficiencyNum / 100 : efficiencyNum
    if (effDecimal > 1) {
      setError("Efficiency cannot exceed 100%")
      return
    }

    // Convert flow rate to m³/s
    let flowRateM3s = flowRateNum
    if (flowRateUnit === "Ls") flowRateM3s = flowRateNum / 1000
    else if (flowRateUnit === "m3h") flowRateM3s = flowRateNum / 3600
    else if (flowRateUnit === "gpm") flowRateM3s = flowRateNum * 0.0000630902
    else if (flowRateUnit === "cfm") flowRateM3s = flowRateNum * 0.000471947

    // Convert density to kg/m³ if imperial
    let densityKgM3 = densityNum
    if (unitSystem === "imperial") densityKgM3 = densityNum * 16.0185 // lb/ft³ to kg/m³

    // Convert head to meters if imperial
    let headM = headNum
    if (unitSystem === "imperial") headM = headNum * 0.3048 // feet to meters

    // Calculate hydraulic power: P_hydraulic = ρ × g × Q × H (in Watts)
    const hydraulicPowerW = densityKgM3 * g * flowRateM3s * headM

    // Calculate pump power: P = P_hydraulic / η
    const pumpPowerW = hydraulicPowerW / effDecimal

    // Convert power to selected unit
    let displayPower = pumpPowerW
    let displayUnit = "W"
    if (powerUnit === "kW") {
      displayPower = pumpPowerW / 1000
      displayUnit = "kW"
    } else if (powerUnit === "HP") {
      displayPower = pumpPowerW / 745.7
      displayUnit = "HP"
    } else if (powerUnit === "W") {
      displayPower = pumpPowerW
      displayUnit = "W"
    }

    // Categorize pump size
    let category: string
    let color: string
    let bgColor: string

    const powerKW = pumpPowerW / 1000
    if (powerKW < 1) {
      category = "Small Pump"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (powerKW < 10) {
      category = "Medium Pump"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (powerKW < 100) {
      category = "Large Pump"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Industrial Pump"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      power: displayPower,
      powerUnit: displayUnit,
      hydraulicPower: hydraulicPowerW / 1000, // in kW
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setFlowRate("")
    setDensity("")
    setHead("")
    setEfficiency("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Pump Power: ${result.power.toFixed(3)} ${result.powerUnit} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setFlowRate("")
    setDensity("")
    setHead("")
    setResult(null)
    setError("")
    if (unitSystem === "metric") {
      setFlowRateUnit("gpm")
    } else {
      setFlowRateUnit("m3s")
    }
  }

  const applyFluidPreset = (preset: keyof typeof fluidPresets) => {
    setDensity(fluidPresets[preset].density.toString())
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Pump Power Calculator</CardTitle>
                    <CardDescription>Calculate required pump power for fluid systems</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Fluid Presets */}
                <div className="space-y-2">
                  <Label>Quick Fluid Selection</Label>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(fluidPresets).map(([key, preset]) => (
                      <Button
                        key={key}
                        variant="outline"
                        size="sm"
                        onClick={() => applyFluidPreset(key as keyof typeof fluidPresets)}
                        className="text-xs"
                      >
                        {preset.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Flow Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="flowRate">Volumetric Flow Rate (Q)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="flowRate"
                      type="number"
                      placeholder="Enter flow rate"
                      value={flowRate}
                      onChange={(e) => setFlowRate(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={flowRateUnit} onValueChange={setFlowRateUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {unitSystem === "metric" ? (
                          <>
                            <SelectItem value="m3s">m³/s</SelectItem>
                            <SelectItem value="Ls">L/s</SelectItem>
                            <SelectItem value="m3h">m³/h</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="gpm">GPM</SelectItem>
                            <SelectItem value="cfm">CFM</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Density Input */}
                <div className="space-y-2">
                  <Label htmlFor="density">Fluid Density (ρ) ({unitSystem === "metric" ? "kg/m³" : "lb/ft³"})</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder={`Enter density in ${unitSystem === "metric" ? "kg/m³" : "lb/ft³"}`}
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Total Head Input */}
                <div className="space-y-2">
                  <Label htmlFor="head">Total Head (H) ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="head"
                    type="number"
                    placeholder={`Enter total head in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={head}
                    onChange={(e) => setHead(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Efficiency Input */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="efficiency">Pump Efficiency (η)</Label>
                    <button
                      onClick={() => setEfficiencyMode((prev) => (prev === "decimal" ? "percent" : "decimal"))}
                      className="text-xs text-primary hover:underline"
                    >
                      {efficiencyMode === "percent" ? "Switch to decimal" : "Switch to %"}
                    </button>
                  </div>
                  <Input
                    id="efficiency"
                    type="number"
                    placeholder={efficiencyMode === "percent" ? "e.g., 75 for 75%" : "e.g., 0.75"}
                    value={efficiency}
                    onChange={(e) => setEfficiency(e.target.value)}
                    min="0"
                    max={efficiencyMode === "percent" ? "100" : "1"}
                    step="any"
                  />
                </div>

                {/* Power Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Power Unit</Label>
                  <Select value={powerUnit} onValueChange={setPowerUnit}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="W">Watts (W)</SelectItem>
                      <SelectItem value="kW">Kilowatts (kW)</SelectItem>
                      <SelectItem value="HP">Horsepower (HP)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePumpPower} className="w-full" size="lg">
                  Calculate Pump Power
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Required Pump Power</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.power.toFixed(3)} {result.powerUnit}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    <div className="mt-4 grid grid-cols-1 gap-2 text-sm">
                      <div className="flex justify-between p-2 bg-white/50 rounded">
                        <span className="text-muted-foreground">Hydraulic Power:</span>
                        <span className="font-medium">{result.hydraulicPower.toFixed(4)} kW</span>
                      </div>
                      <div className="flex justify-between p-2 bg-white/50 rounded">
                        <span className="text-muted-foreground">Power Loss (inefficiency):</span>
                        <span className="font-medium">
                          {(
                            result.power * (powerUnit === "kW" ? 1 : powerUnit === "HP" ? 0.7457 : 0.001) -
                            result.hydraulicPower
                          ).toFixed(4)}{" "}
                          kW
                        </span>
                      </div>
                    </div>

                    {/* Show Steps Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="mt-3 text-sm text-primary hover:underline w-full text-center"
                    >
                      {showSteps ? "Hide calculation steps" : "Show calculation steps"}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/70 rounded-lg text-sm space-y-2">
                        <p className="font-medium">Step-by-step calculation:</p>
                        <p>1. Formula: P = (ρ × g × Q × H) / η</p>
                        <p>2. Hydraulic Power = ρ × g × Q × H</p>
                        <p>3. Pump Power = Hydraulic Power / Efficiency</p>
                        <p>
                          4. Result: {result.power.toFixed(3)} {result.powerUnit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pump Power Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">P = (ρ × g × Q × H) / η</p>
                  </div>
                  <div className="space-y-1">
                    <p>
                      <strong>P</strong> = Pump power (W)
                    </p>
                    <p>
                      <strong>ρ</strong> = Fluid density (kg/m³)
                    </p>
                    <p>
                      <strong>g</strong> = Gravitational acceleration (9.81 m/s²)
                    </p>
                    <p>
                      <strong>Q</strong> = Volumetric flow rate (m³/s)
                    </p>
                    <p>
                      <strong>H</strong> = Total head (m)
                    </p>
                    <p>
                      <strong>η</strong> = Pump efficiency (decimal)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Pump Efficiencies</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Centrifugal Pumps</span>
                      <span className="font-medium">70-85%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Positive Displacement</span>
                      <span className="font-medium">80-95%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Submersible Pumps</span>
                      <span className="font-medium">50-70%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Diaphragm Pumps</span>
                      <span className="font-medium">40-60%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Pump Power?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pump power is the mechanical energy required to drive a pump and transport fluid from one location to
                  another at a specified flow rate and pressure (head). Understanding pump power requirements is
                  essential for selecting the right pump and motor for your application, ensuring energy efficiency, and
                  properly sizing electrical systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The total pump power consists of hydraulic power (the useful work done on the fluid) plus losses due
                  to pump inefficiency. Higher efficiency pumps require less input power to achieve the same hydraulic
                  output, resulting in lower operating costs and energy consumption.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Total Head</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Total head represents the total energy the pump must impart to the fluid, expressed as an equivalent
                  height of fluid column. It includes static head (elevation difference), pressure head (system pressure
                  requirements), velocity head (kinetic energy), and friction head (losses in pipes, fittings, and
                  valves).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Accurately calculating total head is critical for proper pump selection. Underestimating head will
                  result in insufficient flow, while overestimating leads to oversized pumps that operate inefficiently
                  and may cause system problems like cavitation or excessive pressure.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Pump Efficiency Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pump efficiency varies significantly based on pump type, size, operating conditions, and maintenance.
                  Most pumps have a best efficiency point (BEP) where they operate most effectively. Operating too far
                  from the BEP reduces efficiency and can cause mechanical problems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When selecting a pump, consider not just the initial cost but the lifetime operating costs. A more
                  efficient pump may have a higher purchase price but can save significantly on energy costs over its
                  operating life, especially for pumps that run continuously.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Pump power calculations are estimates based on ideal conditions. Actual
                  power requirements may vary due to friction losses, pump design characteristics, operating
                  temperature, and system-specific factors. Always consult pump datasheets, performance curves, and
                  engineering specifications for precise requirements. Consider safety margins when sizing motors and
                  electrical systems.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
