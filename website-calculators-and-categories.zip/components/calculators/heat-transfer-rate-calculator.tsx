"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Thermometer, Info, Flame, Wind, Sun } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type TransferMode = "conduction" | "convection" | "radiation"
type PowerUnit = "W" | "kW"

interface HeatTransferResult {
  heatRate: number
  category: string
  color: string
  bgColor: string
}

export function HeatTransferRateCalculator() {
  const [mode, setMode] = useState<TransferMode>("conduction")
  const [outputUnit, setOutputUnit] = useState<PowerUnit>("W")

  // Conduction inputs
  const [thermalConductivity, setThermalConductivity] = useState("")
  const [area, setArea] = useState("")
  const [tempDiff, setTempDiff] = useState("")
  const [thickness, setThickness] = useState("")

  // Convection inputs
  const [heatTransferCoeff, setHeatTransferCoeff] = useState("")

  // Radiation inputs
  const [emissivity, setEmissivity] = useState("")
  const [surfaceTemp, setSurfaceTemp] = useState("")
  const [surroundingTemp, setSurroundingTemp] = useState("")

  const [result, setResult] = useState<HeatTransferResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const STEFAN_BOLTZMANN = 5.67e-8 // W/m²·K⁴

  const calculateHeatTransfer = () => {
    setError("")
    setResult(null)

    const areaNum = Number.parseFloat(area)
    if (isNaN(areaNum) || areaNum <= 0) {
      setError("Please enter a valid area greater than 0")
      return
    }

    let heatRate: number

    if (mode === "conduction") {
      const k = Number.parseFloat(thermalConductivity)
      const deltaT = Number.parseFloat(tempDiff)
      const L = Number.parseFloat(thickness)

      if (isNaN(k) || k <= 0) {
        setError("Please enter a valid thermal conductivity greater than 0")
        return
      }
      if (isNaN(deltaT)) {
        setError("Please enter a valid temperature difference")
        return
      }
      if (isNaN(L) || L <= 0) {
        setError("Please enter a valid thickness greater than 0")
        return
      }

      heatRate = (k * areaNum * Math.abs(deltaT)) / L
    } else if (mode === "convection") {
      const h = Number.parseFloat(heatTransferCoeff)
      const deltaT = Number.parseFloat(tempDiff)

      if (isNaN(h) || h <= 0) {
        setError("Please enter a valid heat transfer coefficient greater than 0")
        return
      }
      if (isNaN(deltaT)) {
        setError("Please enter a valid temperature difference")
        return
      }

      heatRate = h * areaNum * Math.abs(deltaT)
    } else {
      const eps = Number.parseFloat(emissivity)
      const Ts = Number.parseFloat(surfaceTemp)
      const Tinf = Number.parseFloat(surroundingTemp)

      if (isNaN(eps) || eps <= 0 || eps > 1) {
        setError("Please enter a valid emissivity between 0 and 1")
        return
      }
      if (isNaN(Ts) || Ts <= 0) {
        setError("Please enter a valid surface temperature in Kelvin (must be > 0)")
        return
      }
      if (isNaN(Tinf) || Tinf <= 0) {
        setError("Please enter a valid surrounding temperature in Kelvin (must be > 0)")
        return
      }

      heatRate = eps * STEFAN_BOLTZMANN * areaNum * (Math.pow(Ts, 4) - Math.pow(Tinf, 4))
    }

    const displayRate = outputUnit === "kW" ? heatRate / 1000 : heatRate

    let category: string
    let color: string
    let bgColor: string

    const absRate = Math.abs(heatRate)
    if (absRate < 100) {
      category = "Low Heat Transfer"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (absRate < 1000) {
      category = "Moderate Heat Transfer"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (absRate < 10000) {
      category = "High Heat Transfer"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Heat Transfer"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({ heatRate: displayRate, category, color, bgColor })
  }

  const handleReset = () => {
    setThermalConductivity("")
    setArea("")
    setTempDiff("")
    setThickness("")
    setHeatTransferCoeff("")
    setEmissivity("")
    setSurfaceTemp("")
    setSurroundingTemp("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Heat Transfer Rate: ${result.heatRate.toFixed(4)} ${outputUnit} (${result.category})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getModeIcon = () => {
    switch (mode) {
      case "conduction":
        return <Thermometer className="h-5 w-5" />
      case "convection":
        return <Wind className="h-5 w-5" />
      case "radiation":
        return <Sun className="h-5 w-5" />
    }
  }

  const getFormula = () => {
    switch (mode) {
      case "conduction":
        return "Q = k × A × ΔT / L"
      case "convection":
        return "Q = h × A × ΔT"
      case "radiation":
        return "Q = ε × σ × A × (T_s⁴ − T_∞⁴)"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Heat Transfer Rate Calculator</CardTitle>
                    <CardDescription>Calculate heat transfer via conduction, convection, or radiation</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="space-y-2 pt-2">
                  <span className="text-sm font-medium">Transfer Mode</span>
                  <div className="grid grid-cols-3 gap-2">
                    {(["conduction", "convection", "radiation"] as TransferMode[]).map((m) => (
                      <button
                        key={m}
                        onClick={() => {
                          setMode(m)
                          setResult(null)
                          setError("")
                        }}
                        className={`p-2 rounded-lg text-sm font-medium transition-colors ${
                          mode === m ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        {m.charAt(0).toUpperCase() + m.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Area Input (common to all modes) */}
                <div className="space-y-2">
                  <Label htmlFor="area">Cross-sectional Area (m²)</Label>
                  <Input
                    id="area"
                    type="number"
                    placeholder="Enter area in m²"
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Mode-specific inputs */}
                {mode === "conduction" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="k">Thermal Conductivity, k (W/m·K)</Label>
                      <Input
                        id="k"
                        type="number"
                        placeholder="e.g., 401 for copper"
                        value={thermalConductivity}
                        onChange={(e) => setThermalConductivity(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="deltaT">Temperature Difference, ΔT (°C or K)</Label>
                      <Input
                        id="deltaT"
                        type="number"
                        placeholder="Enter temperature difference"
                        value={tempDiff}
                        onChange={(e) => setTempDiff(e.target.value)}
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="thickness">Thickness, L (m)</Label>
                      <Input
                        id="thickness"
                        type="number"
                        placeholder="Enter material thickness"
                        value={thickness}
                        onChange={(e) => setThickness(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                  </>
                )}

                {mode === "convection" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="h">Heat Transfer Coefficient, h (W/m²·K)</Label>
                      <Input
                        id="h"
                        type="number"
                        placeholder="e.g., 10-100 for natural, 100-1000 for forced"
                        value={heatTransferCoeff}
                        onChange={(e) => setHeatTransferCoeff(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="deltaTConv">Temperature Difference, ΔT (°C or K)</Label>
                      <Input
                        id="deltaTConv"
                        type="number"
                        placeholder="Enter temperature difference"
                        value={tempDiff}
                        onChange={(e) => setTempDiff(e.target.value)}
                        step="0.1"
                      />
                    </div>
                  </>
                )}

                {mode === "radiation" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="emissivity">Emissivity, ε (0 to 1)</Label>
                      <Input
                        id="emissivity"
                        type="number"
                        placeholder="e.g., 0.9 for most surfaces"
                        value={emissivity}
                        onChange={(e) => setEmissivity(e.target.value)}
                        min="0"
                        max="1"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="Ts">Surface Temperature, T_s (K)</Label>
                      <Input
                        id="Ts"
                        type="number"
                        placeholder="Enter surface temperature in Kelvin"
                        value={surfaceTemp}
                        onChange={(e) => setSurfaceTemp(e.target.value)}
                        min="0"
                        step="1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="Tinf">Surrounding Temperature, T_∞ (K)</Label>
                      <Input
                        id="Tinf"
                        type="number"
                        placeholder="Enter surrounding temperature in Kelvin"
                        value={surroundingTemp}
                        onChange={(e) => setSurroundingTemp(e.target.value)}
                        min="0"
                        step="1"
                      />
                    </div>
                  </>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["W", "kW"] as PowerUnit[]).map((unit) => (
                      <button
                        key={unit}
                        onClick={() => setOutputUnit(unit)}
                        className={`p-2 rounded-lg text-sm font-medium transition-colors ${
                          outputUnit === unit ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        {unit}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateHeatTransfer} className="w-full" size="lg">
                  Calculate Heat Transfer Rate
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Heat Transfer Rate (Q)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-2`}>
                        {Math.abs(result.heatRate) < 0.0001
                          ? result.heatRate.toExponential(4)
                          : result.heatRate.toFixed(4)}{" "}
                        {outputUnit}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      {result.heatRate < 0 && (
                        <p className="text-sm text-muted-foreground mt-1">(Heat flows from surroundings to surface)</p>
                      )}
                    </div>

                    {/* Step-by-step breakdown toggle */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="text-sm text-primary hover:underline w-full text-center"
                      >
                        {showSteps ? "Hide" : "Show"} calculation steps
                      </button>
                      {showSteps && (
                        <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                          <p>
                            <strong>Formula:</strong> {getFormula()}
                          </p>
                          {mode === "conduction" && (
                            <>
                              <p>k = {thermalConductivity} W/m·K</p>
                              <p>A = {area} m²</p>
                              <p>ΔT = {tempDiff} K</p>
                              <p>L = {thickness} m</p>
                              <p>
                                <strong>
                                  Q = ({thermalConductivity} × {area} × |{tempDiff}|) / {thickness}
                                </strong>
                              </p>
                            </>
                          )}
                          {mode === "convection" && (
                            <>
                              <p>h = {heatTransferCoeff} W/m²·K</p>
                              <p>A = {area} m²</p>
                              <p>ΔT = {tempDiff} K</p>
                              <p>
                                <strong>
                                  Q = {heatTransferCoeff} × {area} × |{tempDiff}|
                                </strong>
                              </p>
                            </>
                          )}
                          {mode === "radiation" && (
                            <>
                              <p>ε = {emissivity}</p>
                              <p>σ = 5.67 × 10⁻⁸ W/m²·K⁴</p>
                              <p>A = {area} m²</p>
                              <p>T_s = {surfaceTemp} K</p>
                              <p>T_∞ = {surroundingTemp} K</p>
                              <p>
                                <strong>
                                  Q = {emissivity} × σ × {area} × ({surfaceTemp}⁴ − {surroundingTemp}⁴)
                                </strong>
                              </p>
                            </>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    {getModeIcon()}
                    {mode.charAt(0).toUpperCase() + mode.slice(1)} Formula
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="font-semibold text-foreground">{getFormula()}</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    {mode === "conduction" && (
                      <>
                        <p>
                          <strong>Q</strong> = Heat transfer rate (W)
                        </p>
                        <p>
                          <strong>k</strong> = Thermal conductivity (W/m·K)
                        </p>
                        <p>
                          <strong>A</strong> = Cross-sectional area (m²)
                        </p>
                        <p>
                          <strong>ΔT</strong> = Temperature difference (K or °C)
                        </p>
                        <p>
                          <strong>L</strong> = Material thickness (m)
                        </p>
                      </>
                    )}
                    {mode === "convection" && (
                      <>
                        <p>
                          <strong>Q</strong> = Heat transfer rate (W)
                        </p>
                        <p>
                          <strong>h</strong> = Heat transfer coefficient (W/m²·K)
                        </p>
                        <p>
                          <strong>A</strong> = Surface area (m²)
                        </p>
                        <p>
                          <strong>ΔT</strong> = Temperature difference (K or °C)
                        </p>
                      </>
                    )}
                    {mode === "radiation" && (
                      <>
                        <p>
                          <strong>Q</strong> = Heat transfer rate (W)
                        </p>
                        <p>
                          <strong>ε</strong> = Emissivity (0 to 1)
                        </p>
                        <p>
                          <strong>σ</strong> = Stefan-Boltzmann constant (5.67×10⁻⁸ W/m²·K⁴)
                        </p>
                        <p>
                          <strong>A</strong> = Surface area (m²)
                        </p>
                        <p>
                          <strong>T_s</strong> = Surface temperature (K)
                        </p>
                        <p>
                          <strong>T_∞</strong> = Surrounding temperature (K)
                        </p>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Values</CardTitle>
                </CardHeader>
                <CardContent>
                  {mode === "conduction" && (
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Copper</span>
                        <span className="font-mono">k = 401 W/m·K</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Aluminum</span>
                        <span className="font-mono">k = 237 W/m·K</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Steel</span>
                        <span className="font-mono">k = 50 W/m·K</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Glass</span>
                        <span className="font-mono">k = 1.0 W/m·K</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Wood</span>
                        <span className="font-mono">k = 0.15 W/m·K</span>
                      </div>
                    </div>
                  )}
                  {mode === "convection" && (
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Natural (air)</span>
                        <span className="font-mono">h = 5-25 W/m²·K</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Forced (air)</span>
                        <span className="font-mono">h = 25-250 W/m²·K</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Natural (water)</span>
                        <span className="font-mono">h = 100-900 W/m²·K</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Forced (water)</span>
                        <span className="font-mono">h = 500-10000 W/m²·K</span>
                      </div>
                    </div>
                  )}
                  {mode === "radiation" && (
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Black body</span>
                        <span className="font-mono">ε = 1.0</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Polished metal</span>
                        <span className="font-mono">ε = 0.02-0.1</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Oxidized metal</span>
                        <span className="font-mono">ε = 0.6-0.9</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Paint/Wood</span>
                        <span className="font-mono">ε = 0.8-0.95</span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Heat Transfer */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Heat Transfer?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Heat transfer is the movement of thermal energy from a higher temperature region to a lower
                  temperature region. This fundamental process occurs through three primary mechanisms: conduction,
                  convection, and radiation. Understanding heat transfer is essential in engineering, physics, and
                  everyday applications such as building insulation, electronic cooling, and industrial processes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Conduction</strong> is the transfer of heat through a solid material or between materials in
                  direct contact. <strong>Convection</strong> involves heat transfer through the movement of fluids
                  (liquids or gases). <strong>Radiation</strong> is the transfer of heat through electromagnetic waves,
                  which can occur even in a vacuum.
                </p>
              </CardContent>
            </Card>

            {/* Engineering Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Engineering Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">HVAC Systems</h4>
                    <p className="text-orange-700 text-sm">
                      Heat exchangers, radiators, and air conditioning systems rely on convection and conduction
                      calculations for efficient thermal management.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Electronics Cooling</h4>
                    <p className="text-blue-700 text-sm">
                      Heat sinks and thermal interface materials use conduction to dissipate heat from electronic
                      components, preventing overheating and failure.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Building Insulation</h4>
                    <p className="text-yellow-700 text-sm">
                      Understanding conduction through walls and radiation from surfaces helps design energy-efficient
                      buildings with optimal thermal comfort.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Heat transfer rate calculations are estimates based on ideal conditions.
                  Actual heat transfer may vary due to material properties, surface conditions, and environmental
                  factors. Consult engineering references for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
