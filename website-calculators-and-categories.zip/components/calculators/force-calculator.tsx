"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "force" | "mass" | "acceleration"

interface ForceResult {
  force: number
  mass: number
  acceleration: number
  weightForce?: number
}

const forceUnits = [
  { value: "N", label: "Newtons (N)", factor: 1 },
  { value: "kN", label: "Kilonewtons (kN)", factor: 1000 },
  { value: "lbf", label: "Pound-force (lbf)", factor: 4.44822 },
]

const massUnits = [
  { value: "kg", label: "Kilograms (kg)", factor: 1 },
  { value: "g", label: "Grams (g)", factor: 0.001 },
  { value: "lb", label: "Pounds (lb)", factor: 0.453592 },
]

const gravityPresets = [
  { name: "Earth", value: 9.81, label: "Earth (9.81 m/s²)" },
  { name: "Moon", value: 1.62, label: "Moon (1.62 m/s²)" },
  { name: "Mars", value: 3.71, label: "Mars (3.71 m/s²)" },
  { name: "Jupiter", value: 24.79, label: "Jupiter (24.79 m/s²)" },
  { name: "Custom", value: 0, label: "Custom" },
]

export function ForceCalculator() {
  const [mode, setMode] = useState<CalculationMode>("force")
  const [force, setForce] = useState("")
  const [forceUnit, setForceUnit] = useState("N")
  const [mass, setMass] = useState("")
  const [massUnit, setMassUnit] = useState("kg")
  const [acceleration, setAcceleration] = useState("")
  const [useGravity, setUseGravity] = useState(false)
  const [gravityPreset, setGravityPreset] = useState("Earth")
  const [customGravity, setCustomGravity] = useState("9.81")
  const [result, setResult] = useState<ForceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [steps, setSteps] = useState<string[]>([])

  const getGravityValue = (): number => {
    if (gravityPreset === "Custom") {
      return Number.parseFloat(customGravity) || 9.81
    }
    return gravityPresets.find((p) => p.name === gravityPreset)?.value || 9.81
  }

  const convertToBase = (value: number, unit: string, type: "force" | "mass"): number => {
    const units = type === "force" ? forceUnits : massUnits
    const unitData = units.find((u) => u.value === unit)
    return value * (unitData?.factor || 1)
  }

  const calculate = () => {
    setError("")
    setResult(null)
    setSteps([])

    const calculationSteps: string[] = []
    let forceN: number, massKg: number, accelMps2: number

    if (mode === "force") {
      const massVal = Number.parseFloat(mass)
      const accelVal = useGravity ? getGravityValue() : Number.parseFloat(acceleration)

      if (isNaN(massVal) || massVal <= 0) {
        setError("Please enter a valid mass greater than 0")
        return
      }
      if (isNaN(accelVal) || accelVal === 0) {
        setError("Please enter a valid acceleration (cannot be zero)")
        return
      }

      massKg = convertToBase(massVal, massUnit, "mass")
      accelMps2 = accelVal
      forceN = massKg * accelMps2

      calculationSteps.push(`Convert mass to kg: ${massVal} ${massUnit} = ${massKg.toFixed(4)} kg`)
      calculationSteps.push(`Acceleration: ${accelMps2} m/s²${useGravity ? ` (${gravityPreset} gravity)` : ""}`)
      calculationSteps.push(`Apply Newton's Second Law: F = m × a`)
      calculationSteps.push(`F = ${massKg.toFixed(4)} kg × ${accelMps2} m/s²`)
      calculationSteps.push(`F = ${forceN.toFixed(4)} N`)
    } else if (mode === "mass") {
      const forceVal = Number.parseFloat(force)
      const accelVal = useGravity ? getGravityValue() : Number.parseFloat(acceleration)

      if (isNaN(forceVal) || forceVal <= 0) {
        setError("Please enter a valid force greater than 0")
        return
      }
      if (isNaN(accelVal) || accelVal === 0) {
        setError("Please enter a valid acceleration (cannot be zero)")
        return
      }

      forceN = convertToBase(forceVal, forceUnit, "force")
      accelMps2 = accelVal
      massKg = forceN / accelMps2

      calculationSteps.push(`Convert force to N: ${forceVal} ${forceUnit} = ${forceN.toFixed(4)} N`)
      calculationSteps.push(`Acceleration: ${accelMps2} m/s²${useGravity ? ` (${gravityPreset} gravity)` : ""}`)
      calculationSteps.push(`Rearrange Newton's Second Law: m = F ÷ a`)
      calculationSteps.push(`m = ${forceN.toFixed(4)} N ÷ ${accelMps2} m/s²`)
      calculationSteps.push(`m = ${massKg.toFixed(4)} kg`)
    } else {
      const forceVal = Number.parseFloat(force)
      const massVal = Number.parseFloat(mass)

      if (isNaN(forceVal) || forceVal <= 0) {
        setError("Please enter a valid force greater than 0")
        return
      }
      if (isNaN(massVal) || massVal <= 0) {
        setError("Please enter a valid mass greater than 0")
        return
      }

      forceN = convertToBase(forceVal, forceUnit, "force")
      massKg = convertToBase(massVal, massUnit, "mass")
      accelMps2 = forceN / massKg

      calculationSteps.push(`Convert force to N: ${forceVal} ${forceUnit} = ${forceN.toFixed(4)} N`)
      calculationSteps.push(`Convert mass to kg: ${massVal} ${massUnit} = ${massKg.toFixed(4)} kg`)
      calculationSteps.push(`Rearrange Newton's Second Law: a = F ÷ m`)
      calculationSteps.push(`a = ${forceN.toFixed(4)} N ÷ ${massKg.toFixed(4)} kg`)
      calculationSteps.push(`a = ${accelMps2.toFixed(4)} m/s²`)
    }

    const weightForce = useGravity ? massKg * getGravityValue() : undefined

    setSteps(calculationSteps)
    setResult({
      force: forceN,
      mass: massKg,
      acceleration: accelMps2,
      weightForce,
    })
  }

  const handleReset = () => {
    setForce("")
    setMass("")
    setAcceleration("")
    setResult(null)
    setError("")
    setSteps([])
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        mode === "force"
          ? `Force: ${result.force.toFixed(4)} N`
          : mode === "mass"
            ? `Mass: ${result.mass.toFixed(4)} kg`
            : `Acceleration: ${result.acceleration.toFixed(4)} m/s²`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text =
          mode === "force"
            ? `Force: ${result.force.toFixed(4)} N`
            : mode === "mass"
              ? `Mass: ${result.mass.toFixed(4)} kg`
              : `Acceleration: ${result.acceleration.toFixed(4)} m/s²`
        await navigator.share({
          title: "Force Calculator Result",
          text: `I calculated using Newton's Second Law: ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1e6 || (Math.abs(num) < 0.001 && num !== 0)) {
      return num.toExponential(4)
    }
    return num.toFixed(4)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Force Calculator</CardTitle>
                    <CardDescription>Newton's Second Law: F = m × a</CardDescription>
                  </div>
                </div>

                {/* Mode Selector */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Calculate</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "force", label: "Force" },
                      { value: "mass", label: "Mass" },
                      { value: "acceleration", label: "Acceleration" },
                    ].map((m) => (
                      <button
                        key={m.value}
                        onClick={() => {
                          setMode(m.value as CalculationMode)
                          setResult(null)
                          setError("")
                        }}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                          mode === m.value ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Force Input (when not calculating force) */}
                {mode !== "force" && (
                  <div className="space-y-2">
                    <Label>Force</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter force"
                        value={force}
                        onChange={(e) => setForce(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={forceUnit} onValueChange={setForceUnit}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {forceUnits.map((u) => (
                            <SelectItem key={u.value} value={u.value}>
                              {u.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Mass Input (when not calculating mass) */}
                {mode !== "mass" && (
                  <div className="space-y-2">
                    <Label>Mass</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter mass"
                        value={mass}
                        onChange={(e) => setMass(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={massUnit} onValueChange={setMassUnit}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {massUnits.map((u) => (
                            <SelectItem key={u.value} value={u.value}>
                              {u.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Acceleration Input or Gravity Toggle (when not calculating acceleration) */}
                {mode !== "acceleration" && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Acceleration</Label>
                      <button
                        onClick={() => setUseGravity(!useGravity)}
                        className={`text-xs px-2 py-1 rounded-full transition-colors ${
                          useGravity ? "bg-orange-100 text-orange-700" : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {useGravity ? "Using Gravity" : "Use Gravity"}
                      </button>
                    </div>

                    {useGravity ? (
                      <div className="space-y-2">
                        <Select value={gravityPreset} onValueChange={setGravityPreset}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {gravityPresets.map((p) => (
                              <SelectItem key={p.name} value={p.name}>
                                {p.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {gravityPreset === "Custom" && (
                          <Input
                            type="number"
                            placeholder="Enter gravity (m/s²)"
                            value={customGravity}
                            onChange={(e) => setCustomGravity(e.target.value)}
                            step="any"
                          />
                        )}
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          placeholder="Enter acceleration"
                          value={acceleration}
                          onChange={(e) => setAcceleration(e.target.value)}
                          step="any"
                          className="flex-1"
                        />
                        <div className="flex items-center px-3 bg-muted rounded-md text-sm text-muted-foreground">
                          m/s²
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate {mode.charAt(0).toUpperCase() + mode.slice(1)}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "force"
                          ? "Calculated Force"
                          : mode === "mass"
                            ? "Calculated Mass"
                            : "Calculated Acceleration"}
                      </p>
                      <p className="text-4xl font-bold text-orange-600 mb-1">
                        {mode === "force"
                          ? formatNumber(result.force)
                          : mode === "mass"
                            ? formatNumber(result.mass)
                            : formatNumber(result.acceleration)}
                      </p>
                      <p className="text-lg text-orange-600">
                        {mode === "force"
                          ? "N (Newtons)"
                          : mode === "mass"
                            ? "kg (Kilograms)"
                            : "m/s² (Meters per second²)"}
                      </p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                      {mode !== "force" && (
                        <div className="p-2 bg-white rounded-lg text-center">
                          <p className="text-muted-foreground">Force</p>
                          <p className="font-semibold">{formatNumber(result.force)} N</p>
                        </div>
                      )}
                      {mode !== "mass" && (
                        <div className="p-2 bg-white rounded-lg text-center">
                          <p className="text-muted-foreground">Mass</p>
                          <p className="font-semibold">{formatNumber(result.mass)} kg</p>
                        </div>
                      )}
                      {mode !== "acceleration" && (
                        <div className="p-2 bg-white rounded-lg text-center">
                          <p className="text-muted-foreground">Acceleration</p>
                          <p className="font-semibold">{formatNumber(result.acceleration)} m/s²</p>
                        </div>
                      )}
                      {result.weightForce !== undefined && (
                        <div className="p-2 bg-white rounded-lg text-center">
                          <p className="text-muted-foreground">Weight Force</p>
                          <p className="font-semibold">{formatNumber(result.weightForce)} N</p>
                        </div>
                      )}
                    </div>

                    {/* Steps */}
                    {steps.length > 0 && (
                      <div className="mt-4 p-3 bg-white rounded-lg">
                        <p className="text-sm font-medium mb-2">Calculation Steps:</p>
                        <ol className="text-xs text-muted-foreground space-y-1">
                          {steps.map((step, i) => (
                            <li key={i}>
                              {i + 1}. {step}
                            </li>
                          ))}
                        </ol>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Newton's Second Law</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="text-xl font-bold text-foreground">F = m × a</p>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-orange-50 rounded">
                      <span className="font-medium">F (Force)</span>
                      <span className="text-muted-foreground">Newtons (N)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-blue-50 rounded">
                      <span className="font-medium">m (Mass)</span>
                      <span className="text-muted-foreground">Kilograms (kg)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-green-50 rounded">
                      <span className="font-medium">a (Acceleration)</span>
                      <span className="text-muted-foreground">m/s²</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gravity Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {gravityPresets
                      .filter((p) => p.name !== "Custom")
                      .map((p) => (
                        <div key={p.name} className="flex justify-between p-2 bg-muted rounded">
                          <span className="font-medium">{p.name}</span>
                          <span className="text-muted-foreground">{p.value} m/s²</span>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are based on classical mechanics and assume no friction or external forces. For
                        real-world applications, additional factors may need to be considered.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Newton's Second Law of Motion</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Newton's Second Law of Motion is one of the most fundamental principles in classical mechanics,
                  formulated by Sir Isaac Newton in the 17th century. This law describes the relationship between the
                  net force acting on an object, its mass, and the resulting acceleration. The mathematical expression F
                  = ma states that the force acting on an object is equal to the mass of that object multiplied by its
                  acceleration. This seemingly simple equation forms the foundation for understanding how objects move
                  and respond to forces in our universe.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The elegance of this law lies in its universal applicability. Whether you're calculating the force
                  needed to accelerate a car, determining the mass of an object from a known force and acceleration, or
                  understanding how rockets achieve liftoff, Newton's Second Law provides the mathematical framework.
                  The law also introduces the concept that force is a vector quantity, meaning it has both magnitude and
                  direction, and that the acceleration produced will be in the same direction as the net force applied.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Force, Mass, and Acceleration</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Force (F)</h4>
                    <p className="text-orange-700 text-sm">
                      Force is a push or pull upon an object resulting from its interaction with another object.
                      Measured in Newtons (N), one Newton is defined as the force required to accelerate a one-kilogram
                      mass at one meter per second squared.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Mass (m)</h4>
                    <p className="text-blue-700 text-sm">
                      Mass is a measure of the amount of matter in an object and represents its resistance to
                      acceleration. Unlike weight, mass remains constant regardless of location. It's measured in
                      kilograms (kg) in the SI system.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Acceleration (a)</h4>
                    <p className="text-green-700 text-sm">
                      Acceleration is the rate of change of velocity over time. It describes how quickly an object's
                      speed or direction changes. Measured in meters per second squared (m/s²), it indicates how
                      velocity changes each second.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Newton's Second Law has countless practical applications across various fields. In automotive
                  engineering, it helps determine the engine power needed to achieve desired acceleration. Aerospace
                  engineers use it to calculate the thrust required for rocket launches and aircraft maneuvers. Sports
                  scientists apply these principles to optimize athletic performance, from analyzing the force of a
                  sprinter's push-off to calculating the impact forces in contact sports.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In construction and civil engineering, understanding force relationships is crucial for designing
                  structures that can withstand various loads. Medical professionals use force calculations in
                  biomechanics to design prosthetics and understand joint mechanics. Even everyday activities like
                  pushing a shopping cart or throwing a ball are governed by these fundamental principles, making
                  Newton's Second Law one of the most practically relevant physics concepts in our daily lives.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Weight vs. Mass: Understanding the Difference</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A common source of confusion is the difference between weight and mass. Mass is an intrinsic property
                  of matter and remains constant regardless of location. Weight, however, is the force of gravity acting
                  on that mass, calculated as W = m × g, where g is the gravitational acceleration. This is why
                  astronauts on the Moon weigh less than on Earth (lower g) but have the same mass.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  On Earth, gravitational acceleration is approximately 9.81 m/s², but this value varies across
                  celestial bodies. The Moon's gravity is about 1.62 m/s², Mars has 3.71 m/s², and Jupiter's massive
                  gravity produces 24.79 m/s². Understanding this distinction is essential for space exploration,
                  satellite design, and any application where objects experience different gravitational environments.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
