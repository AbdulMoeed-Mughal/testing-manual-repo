"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, Droplets, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type SolveFor = "pressure" | "velocity" | "height"

interface BernoulliResult {
  value: number
  unit: string
  label: string
  description: string
}

export function BernoulliEquationCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [solveFor, setSolveFor] = useState<SolveFor>("pressure")
  const [density, setDensity] = useState("")
  const [pressure1, setPressure1] = useState("")
  const [velocity1, setVelocity1] = useState("")
  const [height1, setHeight1] = useState("")
  const [velocity2, setVelocity2] = useState("")
  const [height2, setHeight2] = useState("")
  const [pressure2, setPressure2] = useState("")
  const [gravity, setGravity] = useState("9.81")
  const [result, setResult] = useState<BernoulliResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const rho = Number.parseFloat(density)
    const g = Number.parseFloat(gravity)

    if (isNaN(rho) || rho <= 0) {
      setError("Please enter a valid fluid density greater than 0")
      return
    }

    if (isNaN(g) || g <= 0) {
      setError("Please enter a valid gravitational acceleration greater than 0")
      return
    }

    // Convert units if imperial
    const densityKg = unitSystem === "imperial" ? rho * 16.0185 : rho // lb/ft³ to kg/m³

    const P1 = Number.parseFloat(pressure1)
    const v1 = Number.parseFloat(velocity1)
    const h1 = Number.parseFloat(height1)
    const v2 = Number.parseFloat(velocity2)
    const h2 = Number.parseFloat(height2)
    const P2 = Number.parseFloat(pressure2)

    // Convert units for imperial
    const v1_ms = unitSystem === "imperial" ? v1 * 0.3048 : v1
    const v2_ms = unitSystem === "imperial" ? v2 * 0.3048 : v2
    const h1_m = unitSystem === "imperial" ? h1 * 0.3048 : h1
    const h2_m = unitSystem === "imperial" ? h2 * 0.3048 : h2
    const P1_Pa = unitSystem === "imperial" ? P1 * 6894.76 : P1
    const P2_Pa = unitSystem === "imperial" ? P2 * 6894.76 : P2

    let calculatedValue: number
    let unit: string
    let label: string
    let description: string

    // Bernoulli: P1 + 0.5*ρ*v1² + ρ*g*h1 = P2 + 0.5*ρ*v2² + ρ*g*h2

    if (solveFor === "pressure") {
      // Solve for P2
      if (isNaN(P1) || isNaN(v1) || isNaN(h1) || isNaN(v2) || isNaN(h2)) {
        setError("Please fill in all required fields for point 1 and velocity/height for point 2")
        return
      }

      const totalEnergy1 = P1_Pa + 0.5 * densityKg * v1_ms * v1_ms + densityKg * g * h1_m
      const kineticEnergy2 = 0.5 * densityKg * v2_ms * v2_ms
      const potentialEnergy2 = densityKg * g * h2_m
      calculatedValue = totalEnergy1 - kineticEnergy2 - potentialEnergy2

      // Convert back if imperial
      if (unitSystem === "imperial") {
        calculatedValue = calculatedValue / 6894.76
        unit = "psi"
      } else {
        unit = "Pa"
      }
      label = "Pressure at Point 2"
      description = `P₂ = P₁ + ½ρv₁² + ρgh₁ - ½ρv₂² - ρgh₂`
    } else if (solveFor === "velocity") {
      // Solve for v2
      if (isNaN(P1) || isNaN(v1) || isNaN(h1) || isNaN(P2) || isNaN(h2)) {
        setError("Please fill in all required fields for point 1 and pressure/height for point 2")
        return
      }

      const totalEnergy1 = P1_Pa + 0.5 * densityKg * v1_ms * v1_ms + densityKg * g * h1_m
      const staticEnergy2 = P2_Pa + densityKg * g * h2_m
      const kineticEnergy2 = totalEnergy1 - staticEnergy2

      if (kineticEnergy2 < 0) {
        setError("Invalid input: resulting kinetic energy is negative. Check your values.")
        return
      }

      calculatedValue = Math.sqrt((2 * kineticEnergy2) / densityKg)

      // Convert back if imperial
      if (unitSystem === "imperial") {
        calculatedValue = calculatedValue / 0.3048
        unit = "ft/s"
      } else {
        unit = "m/s"
      }
      label = "Velocity at Point 2"
      description = `v₂ = √(2(P₁ + ½ρv₁² + ρgh₁ - P₂ - ρgh₂) / ρ)`
    } else {
      // Solve for h2
      if (isNaN(P1) || isNaN(v1) || isNaN(h1) || isNaN(P2) || isNaN(v2)) {
        setError("Please fill in all required fields for point 1 and pressure/velocity for point 2")
        return
      }

      const totalEnergy1 = P1_Pa + 0.5 * densityKg * v1_ms * v1_ms + densityKg * g * h1_m
      const staticDynamicEnergy2 = P2_Pa + 0.5 * densityKg * v2_ms * v2_ms
      const potentialEnergy2 = totalEnergy1 - staticDynamicEnergy2
      calculatedValue = potentialEnergy2 / (densityKg * g)

      // Convert back if imperial
      if (unitSystem === "imperial") {
        calculatedValue = calculatedValue / 0.3048
        unit = "ft"
      } else {
        unit = "m"
      }
      label = "Height at Point 2"
      description = `h₂ = (P₁ + ½ρv₁² + ρgh₁ - P₂ - ½ρv₂²) / (ρg)`
    }

    setResult({
      value: Math.round(calculatedValue * 1000) / 1000,
      unit,
      label,
      description,
    })
  }

  const handleReset = () => {
    setDensity("")
    setPressure1("")
    setVelocity1("")
    setHeight1("")
    setVelocity2("")
    setHeight2("")
    setPressure2("")
    setGravity("9.81")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`${result.label}: ${result.value} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    handleReset()
  }

  const fluidPresets = [
    { name: "Water", density: unitSystem === "metric" ? "1000" : "62.4" },
    { name: "Air", density: unitSystem === "metric" ? "1.225" : "0.0765" },
    { name: "Oil", density: unitSystem === "metric" ? "850" : "53.1" },
    { name: "Seawater", density: unitSystem === "metric" ? "1025" : "64" },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Bernoulli Equation Calculator</CardTitle>
                    <CardDescription>Analyze fluid flow using energy conservation</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Solve For Selection */}
                <div className="space-y-2">
                  <Label>Solve For</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "pressure", label: "Pressure (P₂)" },
                      { value: "velocity", label: "Velocity (v₂)" },
                      { value: "height", label: "Height (h₂)" },
                    ].map((option) => (
                      <button
                        key={option.value}
                        onClick={() => setSolveFor(option.value as SolveFor)}
                        className={`px-3 py-2 text-sm rounded-lg border transition-colors ${
                          solveFor === option.value
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background hover:bg-muted border-input"
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Fluid Density */}
                <div className="space-y-2">
                  <Label htmlFor="density">Fluid Density (ρ) ({unitSystem === "metric" ? "kg/m³" : "lb/ft³"})</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder="Enter fluid density"
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                  <div className="flex flex-wrap gap-2">
                    {fluidPresets.map((preset) => (
                      <button
                        key={preset.name}
                        onClick={() => setDensity(preset.density)}
                        className="px-2 py-1 text-xs rounded bg-muted hover:bg-muted/80 transition-colors"
                      >
                        {preset.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Point 1 Inputs */}
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200 space-y-3">
                  <h4 className="font-medium text-blue-800">Point 1 (Known Values)</h4>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="space-y-1">
                      <Label htmlFor="pressure1" className="text-sm">
                        Pressure P₁ ({unitSystem === "metric" ? "Pa" : "psi"})
                      </Label>
                      <Input
                        id="pressure1"
                        type="number"
                        placeholder="Enter pressure"
                        value={pressure1}
                        onChange={(e) => setPressure1(e.target.value)}
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="velocity1" className="text-sm">
                        Velocity v₁ ({unitSystem === "metric" ? "m/s" : "ft/s"})
                      </Label>
                      <Input
                        id="velocity1"
                        type="number"
                        placeholder="Enter velocity"
                        value={velocity1}
                        onChange={(e) => setVelocity1(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="height1" className="text-sm">
                        Height h₁ ({unitSystem === "metric" ? "m" : "ft"})
                      </Label>
                      <Input
                        id="height1"
                        type="number"
                        placeholder="Enter height"
                        value={height1}
                        onChange={(e) => setHeight1(e.target.value)}
                        step="0.01"
                      />
                    </div>
                  </div>
                </div>

                {/* Point 2 Inputs */}
                <div className="p-3 bg-green-50 rounded-lg border border-green-200 space-y-3">
                  <h4 className="font-medium text-green-800">Point 2 (Enter Known Values)</h4>
                  <div className="grid grid-cols-1 gap-3">
                    {solveFor !== "pressure" && (
                      <div className="space-y-1">
                        <Label htmlFor="pressure2" className="text-sm">
                          Pressure P₂ ({unitSystem === "metric" ? "Pa" : "psi"})
                        </Label>
                        <Input
                          id="pressure2"
                          type="number"
                          placeholder="Enter pressure"
                          value={pressure2}
                          onChange={(e) => setPressure2(e.target.value)}
                          step="0.01"
                        />
                      </div>
                    )}
                    {solveFor !== "velocity" && (
                      <div className="space-y-1">
                        <Label htmlFor="velocity2" className="text-sm">
                          Velocity v₂ ({unitSystem === "metric" ? "m/s" : "ft/s"})
                        </Label>
                        <Input
                          id="velocity2"
                          type="number"
                          placeholder="Enter velocity"
                          value={velocity2}
                          onChange={(e) => setVelocity2(e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                    )}
                    {solveFor !== "height" && (
                      <div className="space-y-1">
                        <Label htmlFor="height2" className="text-sm">
                          Height h₂ ({unitSystem === "metric" ? "m" : "ft"})
                        </Label>
                        <Input
                          id="height2"
                          type="number"
                          placeholder="Enter height"
                          value={height2}
                          onChange={(e) => setHeight2(e.target.value)}
                          step="0.01"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Gravity Input */}
                <div className="space-y-2">
                  <Label htmlFor="gravity">Gravitational Acceleration (m/s²)</Label>
                  <Input
                    id="gravity"
                    type="number"
                    placeholder="9.81"
                    value={gravity}
                    onChange={(e) => setGravity(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{result.label}</p>
                      <p className="text-4xl font-bold text-cyan-600 mb-1">
                        {result.value.toLocaleString()} {result.unit}
                      </p>
                    </div>

                    {/* Step-by-step toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-center gap-1 w-full mt-3 text-sm text-cyan-700 hover:text-cyan-800"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p className="font-medium">Bernoulli Equation:</p>
                        <p className="font-mono text-xs bg-muted p-2 rounded">P₁ + ½ρv₁² + ρgh₁ = P₂ + ½ρv₂² + ρgh₂</p>
                        <p className="font-medium mt-2">Rearranged to solve:</p>
                        <p className="font-mono text-xs bg-muted p-2 rounded">{result.description}</p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bernoulli Equation</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">P + ½ρv² + ρgh = constant</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>P</strong> = Static pressure (Pa or psi)
                    </p>
                    <p>
                      <strong>ρ</strong> = Fluid density (kg/m³ or lb/ft³)
                    </p>
                    <p>
                      <strong>v</strong> = Fluid velocity (m/s or ft/s)
                    </p>
                    <p>
                      <strong>g</strong> = Gravitational acceleration (m/s²)
                    </p>
                    <p>
                      <strong>h</strong> = Height/elevation (m or ft)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Energy Components</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Static Pressure</span>
                      <span className="text-sm text-blue-600">P</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Dynamic Pressure</span>
                      <span className="text-sm text-green-600">½ρv²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Hydrostatic Pressure</span>
                      <span className="text-sm text-yellow-600">ρgh</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Bernoulli's Principle */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Bernoulli's Principle?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bernoulli's principle states that for an ideal fluid flowing along a streamline, the sum of pressure
                  energy, kinetic energy, and potential energy remains constant. This fundamental principle of fluid
                  dynamics was formulated by Swiss mathematician Daniel Bernoulli in his book Hydrodynamica (1738) and
                  forms the basis for understanding fluid behavior in pipes, aircraft wings, and many other
                  applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equation describes the conservation of mechanical energy in a flowing fluid. When fluid velocity
                  increases (such as in a constricted pipe section), the static pressure must decrease to maintain
                  energy conservation. This inverse relationship between velocity and pressure is the key insight that
                  explains phenomena from airplane lift to the curve of a baseball.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Engineering Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Venturi Effect</h4>
                    <p className="text-blue-700 text-sm">
                      Used in carburetors, vacuum pumps, and flow measurement devices where fluid velocity changes
                      through a constricted section create pressure differences.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Airplane Wings</h4>
                    <p className="text-green-700 text-sm">
                      Air flows faster over the curved top surface of a wing, creating lower pressure above than below,
                      generating lift force.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Pipe Flow Analysis</h4>
                    <p className="text-yellow-700 text-sm">
                      Engineers use Bernoulli's equation to design water supply systems, calculate pressure drops, and
                      size pumps for fluid transport.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Medical Devices</h4>
                    <p className="text-purple-700 text-sm">
                      Blood flow analysis, respiratory equipment, and nebulizers all rely on Bernoulli's principle for
                      their operation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Bernoulli equation calculations assume ideal, incompressible, non-viscous
                  fluid flow along a streamline. Actual behavior may vary due to friction, turbulence, compressibility
                  effects, and energy losses. Consult fluid mechanics references and professional engineers for precise
                  analysis in critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
