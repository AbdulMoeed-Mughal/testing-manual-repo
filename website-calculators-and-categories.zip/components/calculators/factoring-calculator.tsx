"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Calculator, Info, Sparkles, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type FactoringDepth = "basic" | "complete" | "advanced"

interface FactoringResult {
  original: string
  factored: string
  expanded: string
  classification: string
  steps: string[]
  latex: string
  isPrime: boolean
}

export function FactoringCalculator() {
  const [expression, setExpression] = useState("")
  const [variable, setVariable] = useState("x")
  const [depth, setDepth] = useState<FactoringDepth>("complete")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<FactoringResult | null>(null)
  const [copied, setCopied] = useState<"text" | "latex" | null>(null)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  // Parse expression into terms
  const parseExpression = (expr: string): { coefficients: number[]; variable: string } | null => {
    const v = variable
    const cleaned = expr.replace(/\s/g, "").replace(/−/g, "-")

    // Try to parse as polynomial
    const terms: { coef: number; power: number }[] = []
    let maxPower = 0

    // Match terms like 3x^2, -5x, 7, x^3, etc.
    const termRegex = new RegExp(`([+-]?\\d*\\.?\\d*)\\*?${v}(?:\\^(\\d+))?|([+-]?\\d+\\.?\\d*)(?![${v}])`, "g")
    let match
    let foundTerms = false

    // Handle standalone variable like "x" or "-x"
    const simpleVarRegex = new RegExp(`^([+-]?)${v}$`)
    if (simpleVarRegex.test(cleaned)) {
      const sign = cleaned.startsWith("-") ? -1 : 1
      return { coefficients: [0, sign], variable: v }
    }

    // Parse each term
    const parts = cleaned
      .replace(/([+-])/g, " $1")
      .trim()
      .split(/\s+/)

    for (const part of parts) {
      if (!part) continue
      foundTerms = true

      // Check for x^n term
      const powerMatch = part.match(new RegExp(`^([+-]?\\d*\\.?\\d*)\\*?${v}\\^(\\d+)$`))
      if (powerMatch) {
        const coef =
          powerMatch[1] === "" || powerMatch[1] === "+"
            ? 1
            : powerMatch[1] === "-"
              ? -1
              : Number.parseFloat(powerMatch[1])
        const power = Number.parseInt(powerMatch[2])
        terms.push({ coef, power })
        maxPower = Math.max(maxPower, power)
        continue
      }

      // Check for x term (power 1)
      const linearMatch = part.match(new RegExp(`^([+-]?\\d*\\.?\\d*)\\*?${v}$`))
      if (linearMatch) {
        const coef =
          linearMatch[1] === "" || linearMatch[1] === "+"
            ? 1
            : linearMatch[1] === "-"
              ? -1
              : Number.parseFloat(linearMatch[1])
        terms.push({ coef, power: 1 })
        maxPower = Math.max(maxPower, 1)
        continue
      }

      // Check for constant term
      const constMatch = part.match(/^([+-]?\d+\.?\d*)$/)
      if (constMatch) {
        terms.push({ coef: Number.parseFloat(constMatch[1]), power: 0 })
        continue
      }

      return null // Invalid term
    }

    if (!foundTerms) return null

    // Convert to coefficient array
    const coefficients = new Array(maxPower + 1).fill(0)
    for (const term of terms) {
      coefficients[term.power] += term.coef
    }

    return { coefficients: coefficients.reverse(), variable: v }
  }

  // Find GCD of numbers
  const gcd = (a: number, b: number): number => {
    a = Math.abs(a)
    b = Math.abs(b)
    while (b) {
      const t = b
      b = a % b
      a = t
    }
    return a
  }

  // Find GCD of array of numbers
  const gcdArray = (arr: number[]): number => {
    return arr.filter((n) => n !== 0).reduce((a, b) => gcd(a, b))
  }

  // Format polynomial term
  const formatTerm = (coef: number, power: number, v: string, isFirst: boolean): string => {
    if (coef === 0) return ""

    let result = ""
    if (isFirst) {
      if (coef === -1 && power > 0) result = "-"
      else if (coef !== 1 || power === 0) result = coef.toString()
    } else {
      if (coef > 0) result = " + "
      else result = " - "
      const absCoef = Math.abs(coef)
      if (absCoef !== 1 || power === 0) result += absCoef.toString()
    }

    if (power === 0) {
      if (isFirst && coef === 1) return "1"
      if (isFirst && coef === -1) return "-1"
      return result
    }
    if (power === 1) return result + v
    return result + v + "^" + power
  }

  // Format polynomial from coefficients
  const formatPolynomial = (coeffs: number[], v: string): string => {
    if (coeffs.every((c) => c === 0)) return "0"

    let result = ""
    let isFirst = true
    for (let i = 0; i < coeffs.length; i++) {
      const power = coeffs.length - 1 - i
      const term = formatTerm(coeffs[i], power, v, isFirst)
      if (term && term !== " + " && term !== " - ") {
        result += term
        isFirst = false
      }
    }
    return result || "0"
  }

  // Check if number is a perfect square
  const isPerfectSquare = (n: number): boolean => {
    if (n < 0) return false
    const sqrt = Math.sqrt(n)
    return Math.floor(sqrt) === sqrt
  }

  // Factor quadratic ax^2 + bx + c
  const factorQuadratic = (
    a: number,
    b: number,
    c: number,
    v: string,
  ): { factored: string; classification: string; steps: string[] } | null => {
    const steps: string[] = []

    // Check for difference of squares: a*x^2 - c where b = 0
    if (b === 0 && c < 0 && isPerfectSquare(a) && isPerfectSquare(-c)) {
      const sqrtA = Math.sqrt(a)
      const sqrtC = Math.sqrt(-c)
      steps.push(`Recognize as difference of squares: a² - b² = (a + b)(a - b)`)
      steps.push(`${a}${v}² - ${-c} = (${sqrtA === 1 ? "" : sqrtA}${v})² - (${sqrtC})²`)
      const factor1 = sqrtA === 1 ? `(${v} + ${sqrtC})` : `(${sqrtA}${v} + ${sqrtC})`
      const factor2 = sqrtA === 1 ? `(${v} - ${sqrtC})` : `(${sqrtA}${v} - ${sqrtC})`
      steps.push(`Factor: ${factor1}${factor2}`)
      return { factored: `${factor1}${factor2}`, classification: "Difference of Squares", steps }
    }

    // Check for perfect square trinomial
    const discriminant = b * b - 4 * a * c
    if (discriminant === 0) {
      const root = -b / (2 * a)
      if (Number.isInteger(root) || Math.abs(root - Math.round(root)) < 0.0001) {
        const r = Math.round(root)
        steps.push(`Perfect square trinomial: discriminant = b² - 4ac = ${discriminant}`)
        const sqrtA = Math.sqrt(Math.abs(a))
        if (a === 1) {
          const sign = r >= 0 ? "+" : "-"
          steps.push(`Factor as: (${v} ${sign} ${Math.abs(r)})²`)
          return { factored: `(${v} ${sign} ${Math.abs(r)})²`, classification: "Perfect Square Trinomial", steps }
        }
      }
    }

    // Factor using AC method for integer roots
    if (a !== 0 && discriminant >= 0) {
      const sqrtDisc = Math.sqrt(discriminant)
      if (Number.isInteger(sqrtDisc) || Math.abs(sqrtDisc - Math.round(sqrtDisc)) < 0.0001) {
        const root1 = (-b + sqrtDisc) / (2 * a)
        const root2 = (-b - sqrtDisc) / (2 * a)

        // Try to express as integer factors
        const ac = a * c
        steps.push(`Using AC method: a × c = ${a} × ${c} = ${ac}`)
        steps.push(`Find two numbers that multiply to ${ac} and add to ${b}`)

        // Find factors
        for (let i = -Math.abs(ac); i <= Math.abs(ac); i++) {
          if (i === 0) continue
          if (ac % i === 0) {
            const j = ac / i
            if (i + j === b) {
              steps.push(`Numbers found: ${i} and ${j}`)
              steps.push(`${i} × ${j} = ${ac} and ${i} + ${j} = ${b}`)

              if (a === 1) {
                const sign1 = i >= 0 ? "+" : "-"
                const sign2 = j >= 0 ? "+" : "-"
                const factored = `(${v} ${sign1} ${Math.abs(i)})(${v} ${sign2} ${Math.abs(j)})`
                steps.push(`Factor: ${factored}`)
                return { factored, classification: "Quadratic Trinomial", steps }
              } else {
                // Use grouping for a != 1
                steps.push(`Rewrite middle term: ${a}${v}² + ${i}${v} + ${j}${v} + ${c}`)

                // Simplify to factored form using roots
                const d1 = gcd(Math.abs(a), Math.abs(i))
                const d2 = gcd(Math.abs(j), Math.abs(c))

                // Express as (ax + p)(x + q) form
                if (Number.isInteger(root1) && Number.isInteger(root2)) {
                  const r1 = -Math.round(root1)
                  const r2 = -Math.round(root2)
                  const sign1 = r1 >= 0 ? "+" : "-"
                  const sign2 = r2 >= 0 ? "+" : "-"
                  const factored =
                    a === 1
                      ? `(${v} ${sign1} ${Math.abs(r1)})(${v} ${sign2} ${Math.abs(r2)})`
                      : `${a}(${v} ${sign1} ${Math.abs(r1)})(${v} ${sign2} ${Math.abs(r2)})`
                  steps.push(`Factor: ${factored}`)
                  return { factored, classification: "Quadratic Trinomial", steps }
                }
              }
              break
            }
          }
        }
      }
    }

    return null
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (!expression.trim()) {
      setError("Please enter an algebraic expression")
      return
    }

    const parsed = parseExpression(expression)
    if (!parsed) {
      setError("Invalid expression. Please enter a valid polynomial (e.g., x² - 5x + 6)")
      return
    }

    const { coefficients, variable: v } = parsed
    const steps: string[] = []
    let factored = ""
    let classification = ""
    let isPrime = false

    steps.push(`Original expression: ${formatPolynomial(coefficients, v)}`)

    // Step 1: Factor out GCD
    const nonZeroCoeffs = coefficients.filter((c) => c !== 0)
    const gcf = nonZeroCoeffs.length > 0 ? gcdArray(nonZeroCoeffs.map(Math.abs)) : 1

    // Check if all coefficients are negative
    const allNegative = nonZeroCoeffs.every((c) => c < 0)
    const gcfWithSign = allNegative ? -gcf : gcf

    let workingCoeffs = coefficients
    let gcfFactor = ""

    if (Math.abs(gcfWithSign) > 1 || (gcfWithSign === -1 && allNegative)) {
      workingCoeffs = coefficients.map((c) => c / gcfWithSign)
      gcfFactor = gcfWithSign === -1 ? "-" : gcfWithSign.toString()
      steps.push(
        `Factor out GCF of ${Math.abs(gcfWithSign)}${allNegative ? " (including negative sign)" : ""}: ${gcfFactor}(${formatPolynomial(workingCoeffs, v)})`,
      )
    }

    // Step 2: Factor out common variable powers
    let minPower = workingCoeffs.length - 1
    for (let i = workingCoeffs.length - 1; i >= 0; i--) {
      if (workingCoeffs[i] !== 0) {
        minPower = workingCoeffs.length - 1 - i
        break
      }
    }

    // Find minimum power of variable
    let varPower = 0
    for (let i = workingCoeffs.length - 1; i >= 0; i--) {
      if (workingCoeffs[i] !== 0) break
      varPower++
    }

    let varFactor = ""
    if (varPower > 0) {
      workingCoeffs = workingCoeffs.slice(0, workingCoeffs.length - varPower)
      varFactor = varPower === 1 ? v : `${v}^${varPower}`
      steps.push(`Factor out ${varFactor}: ${gcfFactor}${varFactor}(${formatPolynomial(workingCoeffs, v)})`)
    }

    // Step 3: Try to factor the remaining polynomial
    const degree = workingCoeffs.length - 1

    if (degree === 2) {
      // Quadratic
      const [a, b, c] = workingCoeffs
      const quadResult = factorQuadratic(a, b, c, v)

      if (quadResult) {
        steps.push(...quadResult.steps)
        factored = `${gcfFactor}${varFactor}${quadResult.factored}`
        classification = quadResult.classification
        if (gcf > 1) classification = `GCF + ${classification}`
        if (varPower > 0) classification = `Variable Factor + ${classification}`
      } else {
        // Check if it's prime
        const discriminant = b * b - 4 * a * c
        if (discriminant < 0) {
          steps.push(`Discriminant = ${b}² - 4(${a})(${c}) = ${discriminant} < 0`)
          steps.push(`No real factors exist - expression is prime over real numbers`)
          isPrime = true
          classification = "Prime (Irreducible)"
        } else {
          steps.push(`Expression does not factor nicely with integer coefficients`)
          isPrime = true
          classification = "Prime (Irreducible)"
        }
        factored =
          gcfFactor || varFactor
            ? `${gcfFactor}${varFactor}(${formatPolynomial(workingCoeffs, v)})`
            : formatPolynomial(coefficients, v)
      }
    } else if (degree === 1) {
      // Linear - already factored
      factored = `${gcfFactor}${varFactor}(${formatPolynomial(workingCoeffs, v)})`
      classification = gcf > 1 || varPower > 0 ? "GCF Factoring" : "Linear (Already Factored)"
      steps.push(`Linear expression - already in simplest form`)
    } else if (degree === 0) {
      // Constant
      factored = gcfFactor || formatPolynomial(coefficients, v)
      classification = "Constant"
      steps.push(`Constant expression`)
    } else {
      // Higher degree - try basic factoring
      factored =
        gcfFactor || varFactor
          ? `${gcfFactor}${varFactor}(${formatPolynomial(workingCoeffs, v)})`
          : formatPolynomial(coefficients, v)

      if (gcf > 1 || varPower > 0) {
        classification = "GCF Factoring"
      } else {
        classification = "Higher Degree Polynomial"
        steps.push(`Higher degree polynomial - may require advanced factoring techniques`)
        isPrime = true
      }
    }

    // Clean up factored form
    if (!factored || factored === "") {
      factored = formatPolynomial(coefficients, v)
    }
    factored = factored.replace(/^\s+|\s+$/g, "").replace(/$$$$/g, "")
    if (factored === "" || factored === "()") {
      factored = formatPolynomial(coefficients, v)
    }

    // Generate LaTeX
    const latex = factored.replace(/\^(\d+)/g, "^{$1}").replace(/\*/g, " \\cdot ")

    setResult({
      original: formatPolynomial(coefficients, v),
      factored: factored,
      expanded: formatPolynomial(coefficients, v),
      classification,
      steps,
      latex,
      isPrime,
    })
  }

  const handleReset = () => {
    setExpression("")
    setResult(null)
    setError("")
    setCopied(null)
    setShowDetails(false)
  }

  const handleCopy = async (type: "text" | "latex") => {
    if (result) {
      const text = type === "latex" ? result.latex : result.factored
      await navigator.clipboard.writeText(text)
      setCopied(type)
      setTimeout(() => setCopied(null), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Factoring Calculator</CardTitle>
                    <CardDescription>Factor algebraic expressions completely</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Expression Input */}
                <div className="space-y-2">
                  <Label htmlFor="expression">Algebraic Expression</Label>
                  <Input
                    id="expression"
                    type="text"
                    placeholder="e.g., x^2 - 5x + 6, 3x^2 - 12"
                    value={expression}
                    onChange={(e) => setExpression(e.target.value)}
                    className="font-mono"
                  />
                  <p className="text-xs text-muted-foreground">Use ^ for powers (e.g., x^2 for x²)</p>
                </div>

                {/* Variable and Depth */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="variable">Variable</Label>
                    <Select value={variable} onValueChange={setVariable}>
                      <SelectTrigger id="variable">
                        <SelectValue placeholder="Select variable" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="x">x</SelectItem>
                        <SelectItem value="y">y</SelectItem>
                        <SelectItem value="z">z</SelectItem>
                        <SelectItem value="n">n</SelectItem>
                        <SelectItem value="t">t</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="depth">Factoring Depth</Label>
                    <Select value={depth} onValueChange={(v) => setDepth(v as FactoringDepth)}>
                      <SelectTrigger id="depth">
                        <SelectValue placeholder="Select depth" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic</SelectItem>
                        <SelectItem value="complete">Complete</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step solution</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Factor Expression
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    <div
                      className={`p-4 rounded-xl border-2 ${result.isPrime ? "bg-yellow-50 border-yellow-200" : "bg-green-50 border-green-200"} transition-all duration-300`}
                    >
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Factored Form</p>
                        <p
                          className={`text-2xl sm:text-3xl font-bold font-mono ${result.isPrime ? "text-yellow-700" : "text-green-700"} mb-2`}
                        >
                          {result.factored}
                        </p>
                        <p className={`text-sm font-medium ${result.isPrime ? "text-yellow-600" : "text-green-600"}`}>
                          {result.classification}
                        </p>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleCopy("text")}>
                          {copied === "text" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied === "text" ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleCopy("latex")}>
                          {copied === "latex" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          LaTeX
                        </Button>
                      </div>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="border rounded-lg overflow-hidden">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="w-full flex items-center justify-between p-3 bg-muted/50 hover:bg-muted transition-colors"
                        >
                          <span className="font-medium text-sm">Step-by-Step Solution</span>
                          {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>
                        {showDetails && (
                          <div className="p-4 space-y-2 bg-background">
                            {result.steps.map((step, index) => (
                              <div key={index} className="flex gap-3">
                                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-medium flex items-center justify-center">
                                  {index + 1}
                                </span>
                                <p className="text-sm text-muted-foreground font-mono">{step}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Factoring Techniques</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700 block mb-1">GCF (Greatest Common Factor)</span>
                      <span className="text-xs text-blue-600">Factor out the largest common factor from all terms</span>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700 block mb-1">Difference of Squares</span>
                      <span className="text-xs text-green-600">a² - b² = (a + b)(a - b)</span>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700 block mb-1">Perfect Square Trinomial</span>
                      <span className="text-xs text-purple-600">a² ± 2ab + b² = (a ± b)²</span>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700 block mb-1">Quadratic Trinomial</span>
                      <span className="text-xs text-orange-600">ax² + bx + c using AC method</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">Examples:</p>
                    <ul className="space-y-1 ml-4 list-disc">
                      <li>
                        <code className="bg-muted px-1 rounded">x^2 - 5x + 6</code> → (x - 2)(x - 3)
                      </li>
                      <li>
                        <code className="bg-muted px-1 rounded">x^2 - 9</code> → (x + 3)(x - 3)
                      </li>
                      <li>
                        <code className="bg-muted px-1 rounded">2x^2 + 4x</code> → 2x(x + 2)
                      </li>
                      <li>
                        <code className="bg-muted px-1 rounded">x^2 + 6x + 9</code> → (x + 3)²
                      </li>
                    </ul>
                  </div>
                  <p>
                    Use <code className="bg-muted px-1 rounded">^</code> for exponents,
                    <code className="bg-muted px-1 rounded">*</code> for multiplication (optional), and standard{" "}
                    <code className="bg-muted px-1 rounded">+</code> and{" "}
                    <code className="bg-muted px-1 rounded">-</code> for operations.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Factoring?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Factoring is the process of breaking down an algebraic expression into simpler expressions (called
                  factors) that, when multiplied together, give the original expression. It's the reverse of expanding
                  or multiplying expressions. Factoring is a fundamental skill in algebra that helps solve equations,
                  simplify expressions, and find roots of polynomials.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, the expression x² - 5x + 6 can be factored into (x - 2)(x - 3). When you multiply these
                  factors back together using FOIL (First, Outer, Inner, Last), you get the original expression. This
                  factored form reveals that x = 2 and x = 3 are the roots (solutions) of the equation x² - 5x + 6 = 0.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter your polynomial expression using standard notation. Use <code>^</code> for exponents (e.g., x^2
                  for x²). The calculator will automatically identify the best factoring technique and provide
                  step-by-step solutions. You can choose different variables and factoring depths based on your needs.
                </p>
                <div className="mt-4 space-y-2">
                  <p className="font-medium text-foreground">The calculator handles:</p>
                  <ul className="text-muted-foreground list-disc ml-6 space-y-1">
                    <li>Greatest Common Factor (GCF) extraction</li>
                    <li>Difference of squares (a² - b²)</li>
                    <li>Perfect square trinomials (a² ± 2ab + b²)</li>
                    <li>Quadratic trinomials using the AC method</li>
                    <li>Factoring by grouping for higher-degree polynomials</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground text-center">
                  This factoring calculator applies standard algebraic factoring techniques. Some expressions may be
                  irreducible over the real numbers. For complex factoring needs or expressions that don't factor nicely
                  with integer coefficients, additional mathematical tools may be required.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
