"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  PiggyBank,
  Info,
  AlertTriangle,
  TrendingUp,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, formatCurrency, currencySymbols } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

interface PFResult {
  totalBalance: number
  totalContributions: number
  employeeContributions: number
  employerContributions: number
  totalInterest: number
  yearWiseBreakdown: YearBreakdown[]
}

interface YearBreakdown {
  year: number
  openingBalance: number
  employeeContribution: number
  employerContribution: number
  interest: number
  closingBalance: number
}

export function ProvidentFundCalculator() {
  const [currency, setCurrency] = useState<Currency>("INR")
  const [employeeContribution, setEmployeeContribution] = useState("")
  const [employerContribution, setEmployerContribution] = useState("")
  const [interestRate, setInterestRate] = useState("8.25")
  const [years, setYears] = useState("")
  const [compoundingFrequency, setCompoundingFrequency] = useState("monthly")
  const [annualIncrease, setAnnualIncrease] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<PFResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculatePF = () => {
    setError("")
    setResult(null)

    const empContrib = Number.parseFloat(employeeContribution)
    const emplrContrib = Number.parseFloat(employerContribution)
    const rate = Number.parseFloat(interestRate)
    const tenure = Number.parseInt(years)
    const increaseRate = Number.parseFloat(annualIncrease) || 0

    if (isNaN(empContrib) || empContrib <= 0) {
      setError("Please enter a valid employee contribution greater than 0")
      return
    }
    if (isNaN(emplrContrib) || emplrContrib < 0) {
      setError("Please enter a valid employer contribution")
      return
    }
    if (isNaN(rate) || rate <= 0) {
      setError("Please enter a valid interest rate greater than 0")
      return
    }
    if (isNaN(tenure) || tenure <= 0) {
      setError("Please enter a valid tenure greater than 0")
      return
    }

    const periodsPerYear = compoundingFrequency === "monthly" ? 12 : compoundingFrequency === "quarterly" ? 4 : 1
    const ratePerPeriod = rate / 100 / periodsPerYear

    let totalBalance = 0
    let totalEmployeeContributions = 0
    let totalEmployerContributions = 0
    let totalInterest = 0
    const yearWiseBreakdown: YearBreakdown[] = []

    let currentEmpContrib = empContrib
    let currentEmplrContrib = emplrContrib

    for (let year = 1; year <= tenure; year++) {
      const openingBalance = totalBalance
      let yearEmployeeContrib = 0
      let yearEmployerContrib = 0
      let yearInterest = 0

      for (let period = 0; period < periodsPerYear; period++) {
        totalBalance += currentEmpContrib + currentEmplrContrib
        yearEmployeeContrib += currentEmpContrib
        yearEmployerContrib += currentEmplrContrib

        const periodInterest = totalBalance * ratePerPeriod
        totalBalance += periodInterest
        yearInterest += periodInterest
      }

      totalEmployeeContributions += yearEmployeeContrib
      totalEmployerContributions += yearEmployerContrib
      totalInterest += yearInterest

      yearWiseBreakdown.push({
        year,
        openingBalance,
        employeeContribution: yearEmployeeContrib,
        employerContribution: yearEmployerContrib,
        interest: yearInterest,
        closingBalance: totalBalance,
      })

      if (increaseRate > 0) {
        currentEmpContrib *= 1 + increaseRate / 100
        currentEmplrContrib *= 1 + increaseRate / 100
      }
    }

    setResult({
      totalBalance,
      totalContributions: totalEmployeeContributions + totalEmployerContributions,
      employeeContributions: totalEmployeeContributions,
      employerContributions: totalEmployerContributions,
      totalInterest,
      yearWiseBreakdown,
    })
  }

  const handleReset = () => {
    setEmployeeContribution("")
    setEmployerContribution("")
    setInterestRate("8.25")
    setYears("")
    setCompoundingFrequency("monthly")
    setAnnualIncrease("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `PF Balance: ${formatCurrency(result.totalBalance, currency)} | Total Contributions: ${formatCurrency(result.totalContributions, currency)} | Interest Earned: ${formatCurrency(result.totalInterest, currency)}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My PF Calculation",
          text: `I calculated my Provident Fund balance using CalcHub! Total Balance: ${formatCurrency(result.totalBalance, currency)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatAmount = (value: number) => formatCurrency(value, currency)

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <PiggyBank className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Provident Fund Calculator</CardTitle>
                    <CardDescription>Estimate your PF balance over time</CardDescription>
                  </div>
                </div>

                <CurrencySelector value={currency} onChange={setCurrency} className="pt-2" />
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="employeeContribution">
                    Employee Monthly Contribution ({currencySymbols[currency]})
                  </Label>
                  <Input
                    id="employeeContribution"
                    type="number"
                    placeholder="Enter employee contribution"
                    value={employeeContribution}
                    onChange={(e) => setEmployeeContribution(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="employerContribution">
                    Employer Monthly Contribution ({currencySymbols[currency]})
                  </Label>
                  <Input
                    id="employerContribution"
                    type="number"
                    placeholder="Enter employer contribution"
                    value={employerContribution}
                    onChange={(e) => setEmployerContribution(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Enter interest rate"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="years">Total Years of Contribution</Label>
                  <Input
                    id="years"
                    type="number"
                    placeholder="Enter years"
                    value={years}
                    onChange={(e) => setYears(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="compoundingFrequency">Compounding Frequency</Label>
                      <Select value={compoundingFrequency} onValueChange={setCompoundingFrequency}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                          <SelectItem value="annually">Annually</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="annualIncrease">Annual Contribution Increase (%)</Label>
                      <Input
                        id="annualIncrease"
                        type="number"
                        placeholder="Enter annual increase rate"
                        value={annualIncrease}
                        onChange={(e) => setAnnualIncrease(e.target.value)}
                        min="0"
                        step="0.5"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculatePF} className="w-full" size="lg">
                  Calculate PF Balance
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total PF Balance</p>
                      <p className="text-4xl font-bold text-green-600 mb-2">{formatAmount(result.totalBalance)}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Contributions</p>
                        <p className="text-lg font-semibold text-foreground">
                          {formatAmount(result.totalContributions)}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Interest Earned</p>
                        <p className="text-lg font-semibold text-green-600">{formatAmount(result.totalInterest)}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-3">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Employee Contributions</p>
                        <p className="text-sm font-semibold">{formatAmount(result.employeeContributions)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Employer Contributions</p>
                        <p className="text-sm font-semibold">{formatAmount(result.employerContributions)}</p>
                      </div>
                    </div>

                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" className="w-full bg-transparent">
                          {showBreakdown ? "Hide" : "Show"} Year-wise Breakdown
                          {showBreakdown ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="max-h-64 overflow-y-auto rounded-lg border bg-white">
                          <table className="w-full text-xs">
                            <thead className="bg-muted sticky top-0">
                              <tr>
                                <th className="p-2 text-left">Year</th>
                                <th className="p-2 text-right">Contributions</th>
                                <th className="p-2 text-right">Interest</th>
                                <th className="p-2 text-right">Balance</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.yearWiseBreakdown.map((row) => (
                                <tr key={row.year} className="border-t">
                                  <td className="p-2">{row.year}</td>
                                  <td className="p-2 text-right">
                                    {formatAmount(row.employeeContribution + row.employerContribution)}
                                  </td>
                                  <td className="p-2 text-right text-green-600">{formatAmount(row.interest)}</td>
                                  <td className="p-2 text-right font-medium">{formatAmount(row.closingBalance)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">PF Interest Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">EPF Rate (2023-24)</span>
                      <span className="text-sm text-green-600">8.25%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">VPF Rate</span>
                      <span className="text-sm text-blue-600">8.25%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">PPF Rate</span>
                      <span className="text-sm text-purple-600">7.10%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">PF Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">A = P × (1 + r/n)^(n×t)</p>
                  </div>
                  <div className="space-y-2 text-xs">
                    <p>
                      <strong>A</strong> = Final amount
                    </p>
                    <p>
                      <strong>P</strong> = Monthly contribution (Employee + Employer)
                    </p>
                    <p>
                      <strong>r</strong> = Annual interest rate
                    </p>
                    <p>
                      <strong>n</strong> = Compounding frequency per year
                    </p>
                    <p>
                      <strong>t</strong> = Time in years
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Provident Fund (PF)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Provident Fund (PF) is a government-backed retirement savings scheme where both the employee and
                  employer contribute a percentage of the employee's salary each month. These contributions earn
                  interest over time, creating a substantial corpus for retirement. The fund is managed by the
                  Employees' Provident Fund Organisation (EPFO) and provides financial security after retirement.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The PF scheme offers tax benefits under various sections of the Income Tax Act, making it an
                  attractive investment option for salaried individuals. The interest earned is also tax-free up to
                  certain limits, and the final corpus at retirement is exempt from tax under specific conditions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>How PF Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Both the employee and employer contribute 12% of the basic salary plus dearness allowance to the PF
                  account. The employee's entire contribution goes to the EPF, while the employer's contribution is
                  split between EPF (3.67%) and EPS (8.33%). The government announces the interest rate annually, which
                  is then credited to all accounts.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The power of compounding makes PF an excellent long-term investment. As you continue contributing over
                  the years, your balance grows exponentially due to interest being calculated on both your
                  contributions and the accumulated interest from previous years.
                </p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  This calculator provides estimates based on the inputs provided and assumed constant interest rates.
                  Actual PF accumulation may vary based on changes in interest rates, salary increments, and
                  contribution patterns. For accurate information about your PF account, please check your official EPFO
                  passbook or consult a financial advisor.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
