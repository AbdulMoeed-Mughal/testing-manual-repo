"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  Divide,
  Plus,
  Minus,
  X,
  Equal,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Operation = "add" | "subtract" | "multiply" | "divide" | "simplify"

interface FractionResult {
  numerator: number
  denominator: number
  simplified: { numerator: number; denominator: number }
  decimal: number
  mixed: { whole: number; numerator: number; denominator: number } | null
  steps: string[]
}

// Calculate GCD using Euclidean algorithm
function gcd(a: number, b: number): number {
  a = Math.abs(a)
  b = Math.abs(b)
  while (b !== 0) {
    const temp = b
    b = a % b
    a = temp
  }
  return a
}

// Calculate LCM
function lcm(a: number, b: number): number {
  return Math.abs(a * b) / gcd(a, b)
}

// Simplify a fraction
function simplifyFraction(num: number, den: number): { numerator: number; denominator: number } {
  if (den === 0) return { numerator: num, denominator: den }
  const divisor = gcd(num, den)
  let simplifiedNum = num / divisor
  let simplifiedDen = den / divisor
  // Handle negative denominator
  if (simplifiedDen < 0) {
    simplifiedNum = -simplifiedNum
    simplifiedDen = -simplifiedDen
  }
  return { numerator: simplifiedNum, denominator: simplifiedDen }
}

// Convert to mixed number
function toMixedNumber(num: number, den: number): { whole: number; numerator: number; denominator: number } | null {
  if (den === 0 || Math.abs(num) < Math.abs(den)) return null
  const whole = Math.trunc(num / den)
  const remainder = Math.abs(num % den)
  if (remainder === 0) return null
  return { whole, numerator: remainder, denominator: Math.abs(den) }
}

export function FractionCalculator() {
  const [operation, setOperation] = useState<Operation>("add")
  const [num1, setNum1] = useState("")
  const [den1, setDen1] = useState("")
  const [whole1, setWhole1] = useState("")
  const [num2, setNum2] = useState("")
  const [den2, setDen2] = useState("")
  const [whole2, setWhole2] = useState("")
  const [useMixed, setUseMixed] = useState(false)
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<FractionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const operations: { value: Operation; label: string; icon: React.ReactNode }[] = [
    { value: "add", label: "Add", icon: <Plus className="h-4 w-4" /> },
    { value: "subtract", label: "Subtract", icon: <Minus className="h-4 w-4" /> },
    { value: "multiply", label: "Multiply", icon: <X className="h-4 w-4" /> },
    { value: "divide", label: "Divide", icon: <Divide className="h-4 w-4" /> },
    { value: "simplify", label: "Simplify", icon: <Equal className="h-4 w-4" /> },
  ]

  const calculate = () => {
    setError("")
    setResult(null)

    // Parse fraction 1
    let numerator1 = Number.parseInt(num1) || 0
    const denominator1 = Number.parseInt(den1) || 1
    const wholeNumber1 = Number.parseInt(whole1) || 0

    // Convert mixed number to improper fraction
    if (useMixed && wholeNumber1 !== 0) {
      const sign = wholeNumber1 < 0 ? -1 : 1
      numerator1 = sign * (Math.abs(wholeNumber1) * Math.abs(denominator1) + Math.abs(numerator1))
    }

    // Validate fraction 1
    if (denominator1 === 0) {
      setError("Denominator cannot be zero")
      return
    }

    let resultNum: number
    let resultDen: number
    const steps: string[] = []

    if (operation === "simplify") {
      resultNum = numerator1
      resultDen = denominator1
      const simplified = simplifyFraction(numerator1, denominator1)
      steps.push(`Original fraction: ${numerator1}/${denominator1}`)
      steps.push(`Find GCD of ${Math.abs(numerator1)} and ${Math.abs(denominator1)}: ${gcd(numerator1, denominator1)}`)
      steps.push(`Divide both by GCD: ${simplified.numerator}/${simplified.denominator}`)
    } else {
      // Parse fraction 2
      let numerator2 = Number.parseInt(num2) || 0
      const denominator2 = Number.parseInt(den2) || 1
      const wholeNumber2 = Number.parseInt(whole2) || 0

      // Convert mixed number to improper fraction
      if (useMixed && wholeNumber2 !== 0) {
        const sign = wholeNumber2 < 0 ? -1 : 1
        numerator2 = sign * (Math.abs(wholeNumber2) * Math.abs(denominator2) + Math.abs(numerator2))
      }

      // Validate fraction 2
      if (denominator2 === 0) {
        setError("Denominator cannot be zero")
        return
      }

      if (operation === "divide" && numerator2 === 0) {
        setError("Cannot divide by zero")
        return
      }

      steps.push(`Fraction 1: ${numerator1}/${denominator1}`)
      steps.push(`Fraction 2: ${numerator2}/${denominator2}`)

      switch (operation) {
        case "add":
        case "subtract": {
          const commonDen = lcm(denominator1, denominator2)
          const newNum1 = numerator1 * (commonDen / denominator1)
          const newNum2 = numerator2 * (commonDen / denominator2)
          steps.push(`Find LCM of denominators: ${commonDen}`)
          steps.push(`Convert fractions: ${newNum1}/${commonDen} and ${newNum2}/${commonDen}`)
          if (operation === "add") {
            resultNum = newNum1 + newNum2
            steps.push(`Add numerators: ${newNum1} + ${newNum2} = ${resultNum}`)
          } else {
            resultNum = newNum1 - newNum2
            steps.push(`Subtract numerators: ${newNum1} - ${newNum2} = ${resultNum}`)
          }
          resultDen = commonDen
          break
        }
        case "multiply": {
          resultNum = numerator1 * numerator2
          resultDen = denominator1 * denominator2
          steps.push(`Multiply numerators: ${numerator1} × ${numerator2} = ${resultNum}`)
          steps.push(`Multiply denominators: ${denominator1} × ${denominator2} = ${resultDen}`)
          break
        }
        case "divide": {
          resultNum = numerator1 * denominator2
          resultDen = denominator1 * numerator2
          steps.push(`Flip fraction 2: ${denominator2}/${numerator2}`)
          steps.push(`Multiply: ${numerator1}/${denominator1} × ${denominator2}/${numerator2}`)
          steps.push(`Result: ${resultNum}/${resultDen}`)
          break
        }
        default:
          return
      }
    }

    const simplified = simplifyFraction(resultNum, resultDen)
    if (resultNum !== simplified.numerator || resultDen !== simplified.denominator) {
      steps.push(`Simplify: ${resultNum}/${resultDen} = ${simplified.numerator}/${simplified.denominator}`)
    }

    const decimal = resultDen !== 0 ? resultNum / resultDen : 0
    const mixed = toMixedNumber(simplified.numerator, simplified.denominator)

    setResult({
      numerator: resultNum,
      denominator: resultDen,
      simplified,
      decimal,
      mixed,
      steps,
    })
  }

  const handleReset = () => {
    setNum1("")
    setDen1("")
    setWhole1("")
    setNum2("")
    setDen2("")
    setWhole2("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `${result.simplified.numerator}/${result.simplified.denominator} = ${result.decimal.toFixed(4)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Fraction Calculation Result",
          text: `I calculated a fraction using CalcHub! Result: ${result.simplified.numerator}/${result.simplified.denominator} = ${result.decimal.toFixed(4)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Fraction Calculator</CardTitle>
                    <CardDescription>Perform operations with fractions</CardDescription>
                  </div>
                </div>

                {/* Mixed Number Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Type</span>
                  <button
                    onClick={() => setUseMixed(!useMixed)}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        useMixed ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !useMixed ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Simple
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        useMixed ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Mixed
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Operation Selection */}
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <div className="grid grid-cols-5 gap-1">
                    {operations.map((op) => (
                      <button
                        key={op.value}
                        onClick={() => setOperation(op.value)}
                        className={`flex flex-col items-center justify-center p-2 rounded-lg border-2 transition-all ${
                          operation === op.value
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-muted bg-background hover:border-muted-foreground/30"
                        }`}
                      >
                        {op.icon}
                        <span className="text-xs mt-1">{op.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Fraction 1 */}
                <div className="space-y-2">
                  <Label>Fraction 1</Label>
                  <div className="flex items-center gap-2">
                    {useMixed && (
                      <Input
                        type="number"
                        placeholder="Whole"
                        value={whole1}
                        onChange={(e) => setWhole1(e.target.value)}
                        className="w-20"
                      />
                    )}
                    <div className="flex-1 flex items-center gap-1">
                      <Input
                        type="number"
                        placeholder="Numerator"
                        value={num1}
                        onChange={(e) => setNum1(e.target.value)}
                        className="text-center"
                      />
                      <span className="text-2xl text-muted-foreground">/</span>
                      <Input
                        type="number"
                        placeholder="Denominator"
                        value={den1}
                        onChange={(e) => setDen1(e.target.value)}
                        className="text-center"
                      />
                    </div>
                  </div>
                </div>

                {/* Fraction 2 (hidden for simplify) */}
                {operation !== "simplify" && (
                  <div className="space-y-2">
                    <Label>Fraction 2</Label>
                    <div className="flex items-center gap-2">
                      {useMixed && (
                        <Input
                          type="number"
                          placeholder="Whole"
                          value={whole2}
                          onChange={(e) => setWhole2(e.target.value)}
                          className="w-20"
                        />
                      )}
                      <div className="flex-1 flex items-center gap-1">
                        <Input
                          type="number"
                          placeholder="Numerator"
                          value={num2}
                          onChange={(e) => setNum2(e.target.value)}
                          className="text-center"
                        />
                        <span className="text-2xl text-muted-foreground">/</span>
                        <Input
                          type="number"
                          placeholder="Denominator"
                          value={den2}
                          onChange={(e) => setDen2(e.target.value)}
                          className="text-center"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <span className="text-4xl font-bold text-blue-600">{result.simplified.numerator}</span>
                        <span className="text-4xl font-bold text-blue-400">/</span>
                        <span className="text-4xl font-bold text-blue-600">{result.simplified.denominator}</span>
                      </div>
                      <div className="flex flex-wrap justify-center gap-3 text-sm">
                        <span className="px-3 py-1 bg-white/60 rounded-full">
                          Decimal: <strong>{result.decimal.toFixed(4)}</strong>
                        </span>
                        {result.mixed && (
                          <span className="px-3 py-1 bg-white/60 rounded-full">
                            Mixed:{" "}
                            <strong>
                              {result.mixed.whole} {result.mixed.numerator}/{result.mixed.denominator}
                            </strong>
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Step-by-step toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-sm text-blue-600 hover:underline"
                    >
                      {showSteps ? "Hide Steps" : "Show Steps"}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/60 rounded-lg text-sm space-y-1">
                        {result.steps.map((step, idx) => (
                          <p key={idx} className="text-muted-foreground">
                            <span className="font-medium text-blue-600">Step {idx + 1}:</span> {step}
                          </p>
                        ))}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Operations Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex items-center gap-2">
                        <Plus className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-blue-700">Addition</span>
                      </div>
                      <span className="text-sm text-blue-600">a/b + c/d</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex items-center gap-2">
                        <Minus className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-700">Subtraction</span>
                      </div>
                      <span className="text-sm text-green-600">a/b - c/d</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <div className="flex items-center gap-2">
                        <X className="h-4 w-4 text-yellow-600" />
                        <span className="font-medium text-yellow-700">Multiplication</span>
                      </div>
                      <span className="text-sm text-yellow-600">a/b × c/d</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <div className="flex items-center gap-2">
                        <Divide className="h-4 w-4 text-orange-600" />
                        <span className="font-medium text-orange-700">Division</span>
                      </div>
                      <span className="text-sm text-orange-600">a/b ÷ c/d</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex items-center gap-2">
                        <Equal className="h-4 w-4 text-purple-600" />
                        <span className="font-medium text-purple-700">Simplify</span>
                      </div>
                      <span className="text-sm text-purple-600">Reduce to lowest terms</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas Used</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Addition/Subtraction</p>
                    <p className="mt-1">a/b ± c/d = (ad ± bc) / bd</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Multiplication</p>
                    <p className="mt-1">a/b × c/d = ac / bd</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Division</p>
                    <p className="mt-1">a/b ÷ c/d = ad / bc</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <p className="text-sm text-amber-800">
                    <strong>Note:</strong> This calculator provides estimates only. Verify manually for critical
                    calculations.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What Are Fractions?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A fraction represents a part of a whole or, more generally, any number of equal parts. It consists of
                  two numbers: a numerator (the top number) and a denominator (the bottom number). The numerator
                  indicates how many parts we have, while the denominator indicates how many equal parts make up one
                  whole. For example, in the fraction 3/4, the numerator 3 tells us we have three parts, and the
                  denominator 4 tells us that one whole is divided into four equal parts.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Fractions are fundamental in mathematics and appear in everyday life, from cooking recipes and
                  construction measurements to financial calculations and scientific research. Understanding how to work
                  with fractions is essential for more advanced mathematical concepts including algebra, calculus, and
                  statistics.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Fractions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Proper Fractions:</strong> These have a numerator smaller than the denominator (e.g., 2/5,
                  3/8). They represent values less than one whole. When you visualize a proper fraction, imagine a pie
                  divided into equal slices where you have fewer slices than the total number of slices in the pie.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Improper Fractions:</strong> These have a numerator equal to or greater than the denominator
                  (e.g., 7/4, 5/3). They represent values equal to or greater than one whole. Improper fractions are
                  perfectly valid and often easier to work with in calculations than mixed numbers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Mixed Numbers:</strong> These combine a whole number with a proper fraction (e.g., 2 1/2, 3
                  3/4). They represent values greater than one and are often used in everyday contexts because they're
                  intuitive to understand. A mixed number like 2 1/2 means two wholes plus one-half.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Plus className="h-5 w-5 text-primary" />
                  <CardTitle>How to Perform Fraction Operations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Addition and Subtraction:</strong> To add or subtract fractions, you first need a common
                  denominator. Find the least common multiple (LCM) of both denominators, convert each fraction to an
                  equivalent fraction with this common denominator, then add or subtract the numerators while keeping
                  the denominator the same. For example, 1/4 + 2/3 requires finding LCM(4,3) = 12, converting to 3/12 +
                  8/12 = 11/12.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Multiplication:</strong> Multiplying fractions is straightforward - multiply the numerators
                  together to get the new numerator, and multiply the denominators together to get the new denominator.
                  For example, 2/3 × 4/5 = 8/15. You can simplify before multiplying by canceling common factors between
                  any numerator and any denominator.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Division:</strong> To divide fractions, multiply the first fraction by the reciprocal (flipped
                  version) of the second fraction. For example, 2/3 ÷ 4/5 = 2/3 × 5/4 = 10/12 = 5/6. Remember the phrase
                  "keep, change, flip" - keep the first fraction, change division to multiplication, and flip the second
                  fraction.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Equal className="h-5 w-5 text-primary" />
                  <CardTitle>Simplifying Fractions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Simplifying (or reducing) a fraction means expressing it in its lowest terms, where the numerator and
                  denominator share no common factors other than 1. To simplify, find the greatest common divisor (GCD)
                  of both numbers and divide each by this value. For example, to simplify 12/18, find GCD(12,18) = 6,
                  then divide: 12÷6 = 2 and 18÷6 = 3, giving 2/3.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Simplifying fractions makes them easier to understand and compare. A fraction like 24/36 is much
                  clearer when expressed as 2/3. In academic and professional contexts, answers are typically expected
                  in simplified form. The process also helps in identifying equivalent fractions and makes subsequent
                  calculations more manageable.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Cooking and Baking:</strong> Recipes frequently use fractions for ingredient measurements.
                  Knowing how to add, subtract, and scale fractions helps when doubling recipes or adjusting serving
                  sizes. If a recipe calls for 3/4 cup of flour and you want to make 1.5 times the amount, you'll need
                  to calculate 3/4 × 3/2 = 9/8 = 1 1/8 cups.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Construction and DIY:</strong> Measurements in construction often involve fractions of inches
                  or feet. Carpenters, plumbers, and electricians regularly add and subtract fractional measurements
                  when cutting materials, spacing fixtures, or planning layouts. Accuracy with fractions can mean the
                  difference between a perfect fit and costly mistakes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Finance:</strong> Stock prices, interest rates, and partial ownership all involve fractional
                  concepts. Understanding fractions helps in calculating proportional investments, splitting costs, and
                  comprehending financial ratios. Many financial calculations become clearer when you can mentally work
                  with fractional representations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
