"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, Calculator, Percent } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type FormulaType = "standard" | "custom" | "indian-10" | "indian-4" | "us-4"

interface FormulaOption {
  id: FormulaType
  name: string
  description: string
  multiplier: number
  maxCGPA: number
}

const formulaOptions: FormulaOption[] = [
  {
    id: "indian-10",
    name: "Indian Universities (10-point)",
    description: "CGPA × 9.5 (Most common in India)",
    multiplier: 9.5,
    maxCGPA: 10,
  },
  {
    id: "indian-4",
    name: "Indian Universities (4-point)",
    description: "CGPA × 25 (Some Indian institutions)",
    multiplier: 25,
    maxCGPA: 4,
  },
  {
    id: "us-4",
    name: "US Universities (4-point)",
    description: "CGPA × 25 (Standard US conversion)",
    multiplier: 25,
    maxCGPA: 4,
  },
  {
    id: "standard",
    name: "Standard Percentage",
    description: "(CGPA / Max CGPA) × 100",
    multiplier: 0,
    maxCGPA: 10,
  },
  {
    id: "custom",
    name: "Custom Multiplier",
    description: "Use your own conversion multiplier",
    multiplier: 9.5,
    maxCGPA: 10,
  },
]

export function CGPAToPercentageCalculator() {
  const [cgpa, setCgpa] = useState<string>("")
  const [formulaType, setFormulaType] = useState<FormulaType>("indian-10")
  const [customMultiplier, setCustomMultiplier] = useState<string>("9.5")
  const [customMaxCGPA, setCustomMaxCGPA] = useState<string>("10")
  const [result, setResult] = useState<{
    percentage: number
    cgpa: number
    formula: string
    multiplier: number
  } | null>(null)
  const [copied, setCopied] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  const selectedFormula = formulaOptions.find((f) => f.id === formulaType) || formulaOptions[0]

  const getMaxCGPA = () => {
    if (formulaType === "custom") {
      return Number.parseFloat(customMaxCGPA) || 10
    }
    return selectedFormula.maxCGPA
  }

  const getMultiplier = () => {
    if (formulaType === "custom") {
      return Number.parseFloat(customMultiplier) || 9.5
    }
    if (formulaType === "standard") {
      return 100 / getMaxCGPA()
    }
    return selectedFormula.multiplier
  }

  const calculate = () => {
    const cgpaValue = Number.parseFloat(cgpa)
    const maxCGPA = getMaxCGPA()
    const multiplier = getMultiplier()

    if (isNaN(cgpaValue) || cgpaValue < 0) {
      return
    }

    if (cgpaValue > maxCGPA) {
      return
    }

    let percentage: number
    let formulaUsed: string

    if (formulaType === "standard") {
      percentage = (cgpaValue / maxCGPA) * 100
      formulaUsed = `(${cgpaValue} / ${maxCGPA}) × 100`
    } else {
      percentage = cgpaValue * multiplier
      formulaUsed = `${cgpaValue} × ${multiplier}`
    }

    if (percentage > 100) {
      percentage = 100
    }

    setResult({
      percentage,
      cgpa: cgpaValue,
      formula: formulaUsed,
      multiplier,
    })
  }

  const handleReset = () => {
    setCgpa("")
    setFormulaType("indian-10")
    setCustomMultiplier("9.5")
    setCustomMaxCGPA("10")
    setResult(null)
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `CGPA: ${result.cgpa}\nPercentage: ${result.percentage.toFixed(2)}%\nFormula: ${result.formula}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "CGPA to Percentage Conversion",
          text: `CGPA: ${result.cgpa} = ${result.percentage.toFixed(2)}%`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const getGradeCategory = (percentage: number) => {
    if (percentage >= 90)
      return { label: "Outstanding", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    if (percentage >= 80) return { label: "Excellent", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    if (percentage >= 70) return { label: "Very Good", color: "text-cyan-600", bgColor: "bg-cyan-50 border-cyan-200" }
    if (percentage >= 60) return { label: "Good", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    if (percentage >= 50)
      return { label: "Average", color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    return { label: "Below Average", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
  }

  const isValidInput = () => {
    const cgpaValue = Number.parseFloat(cgpa)
    const maxCGPA = getMaxCGPA()
    return !isNaN(cgpaValue) && cgpaValue >= 0 && cgpaValue <= maxCGPA
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/education-learning">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Education & Learning
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                    <Percent className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">CGPA to Percentage</CardTitle>
                    <CardDescription>Convert your CGPA to percentage</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Formula Selection */}
                <div className="space-y-2">
                  <Label htmlFor="formula">Conversion Formula</Label>
                  <Select value={formulaType} onValueChange={(v) => setFormulaType(v as FormulaType)}>
                    <SelectTrigger id="formula">
                      <SelectValue placeholder="Select formula" />
                    </SelectTrigger>
                    <SelectContent>
                      {formulaOptions.map((formula) => (
                        <SelectItem key={formula.id} value={formula.id}>
                          {formula.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">{selectedFormula.description}</p>
                </div>

                {/* Custom Options */}
                {formulaType === "custom" && (
                  <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
                    <div className="space-y-2">
                      <Label htmlFor="customMax">Max CGPA Scale</Label>
                      <Input
                        id="customMax"
                        type="number"
                        step="0.1"
                        min="1"
                        max="100"
                        value={customMaxCGPA}
                        onChange={(e) => setCustomMaxCGPA(e.target.value)}
                        placeholder="e.g., 10"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customMult">Multiplier</Label>
                      <Input
                        id="customMult"
                        type="number"
                        step="0.1"
                        min="0.1"
                        max="100"
                        value={customMultiplier}
                        onChange={(e) => setCustomMultiplier(e.target.value)}
                        placeholder="e.g., 9.5"
                      />
                    </div>
                  </div>
                )}

                {/* CGPA Input */}
                <div className="space-y-2">
                  <Label htmlFor="cgpa">Your CGPA</Label>
                  <div className="relative">
                    <Input
                      id="cgpa"
                      type="number"
                      step="0.01"
                      min="0"
                      max={getMaxCGPA()}
                      value={cgpa}
                      onChange={(e) => setCgpa(e.target.value)}
                      placeholder={`Enter CGPA (0 - ${getMaxCGPA()})`}
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                      / {getMaxCGPA()}
                    </span>
                  </div>
                  {cgpa && Number.parseFloat(cgpa) > getMaxCGPA() && (
                    <p className="text-sm text-red-600">CGPA cannot exceed {getMaxCGPA()}</p>
                  )}
                </div>

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg" disabled={!isValidInput()}>
                  Calculate Percentage
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getGradeCategory(result.percentage).bgColor} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Equivalent Percentage</p>
                      <p className={`text-5xl font-bold ${getGradeCategory(result.percentage).color} mb-2`}>
                        {result.percentage.toFixed(2)}%
                      </p>
                      <p className={`text-lg font-semibold ${getGradeCategory(result.percentage).color}`}>
                        {getGradeCategory(result.percentage).label}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-current/10">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">CGPA Entered</p>
                        <p className="text-lg font-semibold">{result.cgpa}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Multiplier</p>
                        <p className="text-lg font-semibold">×{result.multiplier}</p>
                      </div>
                    </div>

                    {/* Calculation Breakdown */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3 text-muted-foreground">
                          {showDetails ? "Hide" : "Show"} Calculation
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="p-3 bg-background/50 rounded text-sm font-mono text-center">
                          {result.formula} = {result.percentage.toFixed(2)}%
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Conversions (10-point)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {[
                      { cgpa: 10, percent: 95 },
                      { cgpa: 9, percent: 85.5 },
                      { cgpa: 8, percent: 76 },
                      { cgpa: 7, percent: 66.5 },
                      { cgpa: 6, percent: 57 },
                    ].map((item) => (
                      <div key={item.cgpa} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <span className="font-medium">CGPA {item.cgpa.toFixed(1)}</span>
                        <span className="text-sm text-muted-foreground">{item.percent.toFixed(1)}%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula Reference</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-indigo-50 rounded-lg">
                    <p className="font-medium text-indigo-700 text-sm mb-1">Indian (10-point)</p>
                    <p className="text-indigo-600 font-mono text-xs">Percentage = CGPA × 9.5</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="font-medium text-blue-700 text-sm mb-1">US (4-point)</p>
                    <p className="text-blue-600 font-mono text-xs">Percentage = CGPA × 25</p>
                  </div>
                  <div className="p-3 bg-cyan-50 rounded-lg">
                    <p className="font-medium text-cyan-700 text-sm mb-1">Standard</p>
                    <p className="text-cyan-600 font-mono text-xs">Percentage = (CGPA / Max) × 100</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Grade Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {[
                      { range: "90% - 100%", label: "Outstanding", color: "bg-green-50 text-green-700" },
                      { range: "80% - 89%", label: "Excellent", color: "bg-blue-50 text-blue-700" },
                      { range: "70% - 79%", label: "Very Good", color: "bg-cyan-50 text-cyan-700" },
                      { range: "60% - 69%", label: "Good", color: "bg-yellow-50 text-yellow-700" },
                      { range: "50% - 59%", label: "Average", color: "bg-orange-50 text-orange-700" },
                    ].map((grade) => (
                      <div
                        key={grade.range}
                        className={`flex justify-between items-center p-2 rounded-lg ${grade.color}`}
                      >
                        <span className="text-sm">{grade.range}</span>
                        <span className="text-sm font-medium">{grade.label}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is CGPA?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  CGPA (Cumulative Grade Point Average) is a grading system used by educational institutions to measure
                  academic performance. Instead of using traditional percentage marks, CGPA represents grades on a scale
                  (commonly 4.0 or 10.0). Converting CGPA to percentage is often required for job applications, higher
                  education admissions, or comparing grades across different grading systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Different institutions use different conversion formulas. The most common formula in Indian
                  universities is multiplying CGPA by 9.5, while US universities typically use a 4.0 scale where CGPA is
                  multiplied by 25 to get the equivalent percentage.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Important Note</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The conversion formulas provided here are general guidelines. Different universities and institutions
                  may have their own specific conversion methods. Always check with your institution for their official
                  conversion formula when submitting academic documents for applications or official purposes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
