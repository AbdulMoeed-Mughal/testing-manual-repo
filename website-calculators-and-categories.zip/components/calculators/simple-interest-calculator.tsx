"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  DollarSign,
  Info,
  AlertTriangle,
  TrendingUp,
  Calculator,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface SimpleInterestResult {
  principal: number
  interestEarned: number
  totalAmount: number
  timeInYears: number
  rate: number
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
]

export function SimpleInterestCalculator() {
  const [principal, setPrincipal] = useState("")
  const [rate, setRate] = useState("")
  const [years, setYears] = useState("")
  const [months, setMonths] = useState("")
  const [currency, setCurrency] = useState(currencies[0])
  const [result, setResult] = useState<SimpleInterestResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateSimpleInterest = () => {
    setError("")
    setResult(null)

    const principalNum = Number.parseFloat(principal)
    if (isNaN(principalNum) || principalNum <= 0) {
      setError("Please enter a valid principal amount greater than 0")
      return
    }

    const rateNum = Number.parseFloat(rate)
    if (isNaN(rateNum) || rateNum < 0) {
      setError("Please enter a valid interest rate (0 or greater)")
      return
    }

    const yearsNum = Number.parseFloat(years) || 0
    const monthsNum = Number.parseFloat(months) || 0

    if (yearsNum <= 0 && monthsNum <= 0) {
      setError("Please enter a valid time period greater than 0")
      return
    }

    // Calculate time in years
    const timeInYears = yearsNum + monthsNum / 12

    // Simple Interest formula: SI = P × r × t
    const rateDecimal = rateNum / 100
    const interestEarned = principalNum * rateDecimal * timeInYears
    const totalAmount = principalNum + interestEarned

    setResult({
      principal: principalNum,
      interestEarned: Math.round(interestEarned * 100) / 100,
      totalAmount: Math.round(totalAmount * 100) / 100,
      timeInYears: Math.round(timeInYears * 100) / 100,
      rate: rateNum,
    })
  }

  const handleReset = () => {
    setPrincipal("")
    setRate("")
    setYears("")
    setMonths("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Simple Interest Calculation:
Principal: ${currency.symbol}${result.principal.toLocaleString()}
Interest Rate: ${result.rate}% per year
Time Period: ${result.timeInYears} years
Interest Earned: ${currency.symbol}${result.interestEarned.toLocaleString()}
Total Amount: ${currency.symbol}${result.totalAmount.toLocaleString()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Simple Interest Calculation",
          text: `I calculated simple interest using CalcHub! Principal: ${currency.symbol}${result.principal.toLocaleString()}, Interest Earned: ${currency.symbol}${result.interestEarned.toLocaleString()}, Total: ${currency.symbol}${result.totalAmount.toLocaleString()}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return `${currency.symbol}${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Simple Interest Calculator</CardTitle>
                    <CardDescription>Calculate interest using simple interest formula</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency.code}
                    onChange={(e) => setCurrency(currencies.find((c) => c.code === e.target.value) || currencies[0])}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    {currencies.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.symbol})
                      </option>
                    ))}
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Principal Amount */}
                <div className="space-y-2">
                  <Label htmlFor="principal">Principal Amount ({currency.symbol})</Label>
                  <Input
                    id="principal"
                    type="number"
                    placeholder="Enter principal amount"
                    value={principal}
                    onChange={(e) => setPrincipal(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="rate">Annual Interest Rate (%)</Label>
                  <Input
                    id="rate"
                    type="number"
                    placeholder="Enter annual interest rate"
                    value={rate}
                    onChange={(e) => setRate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Time Period */}
                <div className="space-y-2">
                  <Label>Time Period</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder="Years"
                        value={years}
                        onChange={(e) => setYears(e.target.value)}
                        min="0"
                      />
                      <span className="text-xs text-muted-foreground mt-1 block">Years</span>
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Months"
                        value={months}
                        onChange={(e) => setMonths(e.target.value)}
                        min="0"
                        max="11"
                      />
                      <span className="text-xs text-muted-foreground mt-1 block">Months (optional)</span>
                    </div>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSimpleInterest} className="w-full" size="lg">
                  Calculate Interest
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Amount</p>
                      <p className="text-4xl sm:text-5xl font-bold text-green-600 mb-2">
                        {formatCurrency(result.totalAmount)}
                      </p>
                      <p className="text-lg font-semibold text-green-600">
                        Interest Earned: {formatCurrency(result.interestEarned)}
                      </p>
                    </div>

                    {/* Breakdown */}
                    <div className="mt-4 pt-4 border-t border-green-200 grid grid-cols-2 gap-4 text-sm">
                      <div className="text-center">
                        <p className="text-muted-foreground">Principal</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.principal)}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground">Time Period</p>
                        <p className="font-semibold text-foreground">{result.timeInYears} years</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Simple Interest Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="font-semibold text-foreground">SI = P × r × t</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>SI</strong> = Simple Interest
                    </p>
                    <p>
                      <strong>P</strong> = Principal amount
                    </p>
                    <p>
                      <strong>r</strong> = Annual interest rate (decimal)
                    </p>
                    <p>
                      <strong>t</strong> = Time period in years
                    </p>
                  </div>
                  <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-700">
                      <strong>Total Amount (A)</strong> = Principal + Interest = P + SI
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700 text-sm">$10,000 at 5% for 3 years</p>
                      <p className="text-xs text-blue-600 mt-1">Interest: $1,500 | Total: $11,500</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-700 text-sm">$5,000 at 8% for 2 years</p>
                      <p className="text-xs text-purple-600 mt-1">Interest: $800 | Total: $5,800</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-700 text-sm">$25,000 at 4.5% for 5 years</p>
                      <p className="text-xs text-amber-600 mt-1">Interest: $5,625 | Total: $30,625</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Actual financial results may vary based on specific
                        terms and conditions of your financial agreement.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Simple Interest */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Simple Interest?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Simple interest is a straightforward method of calculating the interest charge on a loan or the return
                  on an investment. Unlike compound interest, where interest is calculated on both the initial principal
                  and the accumulated interest from previous periods, simple interest is computed solely on the original
                  principal amount throughout the entire duration of the loan or investment.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This method of interest calculation is commonly used in short-term loans, auto loans, and some types
                  of mortgages. It's also frequently applied to certificates of deposit (CDs) and savings bonds. The
                  simplicity of this calculation method makes it easy to understand and predict exactly how much
                  interest will accrue over a given period, which is why it remains popular for certain financial
                  products despite the prevalence of compound interest in modern finance.
                </p>
              </CardContent>
            </Card>

            {/* How Simple Interest Works */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How Simple Interest Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation of simple interest follows a straightforward formula: Interest = Principal × Rate ×
                  Time (I = P × r × t). The principal is the original sum of money borrowed or invested, the rate is the
                  annual interest rate expressed as a decimal, and time is the duration in years. For example, if you
                  invest $10,000 at an annual interest rate of 5% for 3 years, the simple interest earned would be
                  $10,000 × 0.05 × 3 = $1,500.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  One key characteristic of simple interest is that the interest amount remains constant for each time
                  period, assuming the principal and rate don't change. This linear growth pattern differs significantly
                  from compound interest, where the interest earned in each period is added to the principal, causing
                  exponential growth. Understanding this distinction is crucial when comparing different financial
                  products or evaluating loan offers.
                </p>
              </CardContent>
            </Card>

            {/* Simple vs Compound Interest */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Simple Interest vs. Compound Interest</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The fundamental difference between simple and compound interest lies in how the interest is calculated
                  over time. With simple interest, you earn or pay interest only on the original principal amount. The
                  interest doesn't earn additional interest, resulting in a linear growth pattern. This means if you
                  invest $1,000 at 10% simple interest, you'll earn exactly $100 each year, regardless of how long your
                  money stays invested.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Compound interest, on the other hand, calculates interest on both the principal and any previously
                  accumulated interest. This "interest on interest" effect leads to exponential growth over time. For
                  borrowers, simple interest is generally more favorable because you pay less interest overall. For
                  investors and savers, compound interest is typically preferred because your money grows faster,
                  especially over longer periods.
                </p>
                <div className="mt-6 grid sm:grid-cols-2 gap-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">When Simple Interest Benefits You</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Taking out a short-term loan</li>
                      <li>• Auto loans with simple interest terms</li>
                      <li>• Personal loans with fixed terms</li>
                      <li>• Making extra payments on principal</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">When Compound Interest Benefits You</h4>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>• Long-term investments</li>
                      <li>• Retirement accounts</li>
                      <li>• Savings accounts</li>
                      <li>• Reinvesting dividends</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Practical Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications of Simple Interest</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Simple interest is commonly applied in various real-world financial scenarios. Auto loans often use
                  simple interest calculations, where the interest is computed on the outstanding principal balance.
                  This means that making extra payments directly reduces the principal, which in turn reduces future
                  interest charges. Similarly, some short-term personal loans and installment loans use simple interest
                  to determine the total cost of borrowing.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In the investment world, certain fixed-income securities like Treasury bills and some certificates of
                  deposit use simple interest. Government savings bonds often calculate returns using simple interest
                  formulas. Understanding how simple interest works can help you make better financial decisions,
                  whether you're evaluating loan offers, comparing investment options, or planning your savings
                  strategy. Always read the terms carefully to understand whether simple or compound interest applies to
                  your specific financial product.
                </p>
                <div className="mt-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
                  <h4 className="font-semibold text-gray-800 mb-3">Tips for Using Simple Interest to Your Advantage</h4>
                  <ul className="text-gray-700 text-sm space-y-2">
                    <li>
                      <strong>For Borrowers:</strong> Make extra principal payments early to reduce total interest paid
                      over the loan term.
                    </li>
                    <li>
                      <strong>For Savers:</strong> Understand that simple interest may be suitable for short-term
                      savings, but compound interest is better for long-term growth.
                    </li>
                    <li>
                      <strong>Compare Offers:</strong> When evaluating loans, compare both the interest rate and whether
                      it's simple or compound interest.
                    </li>
                    <li>
                      <strong>Calculate Total Cost:</strong> Always calculate the total amount you'll pay or receive,
                      not just the interest rate.
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
