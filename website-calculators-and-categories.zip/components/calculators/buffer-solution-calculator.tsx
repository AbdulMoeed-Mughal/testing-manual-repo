"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Beaker, TestTube } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type BufferType = "acidic" | "basic"

interface BufferResult {
  pH: number
  pOH: number
  pKa: number
  pKb: number
  ratio: number
  bufferCapacity: string
  effectiveRange: { min: number; max: number }
}

export function BufferSolutionCalculator() {
  const [bufferType, setBufferType] = useState<BufferType>("acidic")
  const [ka, setKa] = useState("")
  const [kb, setKb] = useState("")
  const [acidConc, setAcidConc] = useState("")
  const [baseConc, setBaseConc] = useState("")
  const [result, setResult] = useState<BufferResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBuffer = () => {
    setError("")
    setResult(null)

    const acidConcNum = Number.parseFloat(acidConc)
    const baseConcNum = Number.parseFloat(baseConc)

    if (isNaN(acidConcNum) || acidConcNum <= 0) {
      setError("Please enter a valid acid/weak base concentration greater than 0")
      return
    }

    if (isNaN(baseConcNum) || baseConcNum <= 0) {
      setError("Please enter a valid conjugate concentration greater than 0")
      return
    }

    let pH: number
    let pOH: number
    let pKa: number
    let pKb: number
    let ratio: number

    if (bufferType === "acidic") {
      const kaNum = Number.parseFloat(ka)
      if (isNaN(kaNum) || kaNum <= 0) {
        setError("Please enter a valid Ka value greater than 0")
        return
      }
      pKa = -Math.log10(kaNum)
      pKb = 14 - pKa
      ratio = baseConcNum / acidConcNum
      pH = pKa + Math.log10(ratio)
      pOH = 14 - pH
    } else {
      const kbNum = Number.parseFloat(kb)
      if (isNaN(kbNum) || kbNum <= 0) {
        setError("Please enter a valid Kb value greater than 0")
        return
      }
      pKb = -Math.log10(kbNum)
      pKa = 14 - pKb
      ratio = acidConcNum / baseConcNum
      pOH = pKb + Math.log10(ratio)
      pH = 14 - pOH
    }

    // Buffer capacity estimation (qualitative)
    const totalConc = acidConcNum + baseConcNum
    let bufferCapacity: string
    if (totalConc >= 0.5) {
      bufferCapacity = "High"
    } else if (totalConc >= 0.1) {
      bufferCapacity = "Moderate"
    } else {
      bufferCapacity = "Low"
    }

    // Effective buffer range (pKa ± 1)
    const effectiveRange = {
      min: Math.round((pKa - 1) * 100) / 100,
      max: Math.round((pKa + 1) * 100) / 100,
    }

    setResult({
      pH: Math.round(pH * 1000) / 1000,
      pOH: Math.round(pOH * 1000) / 1000,
      pKa: Math.round(pKa * 1000) / 1000,
      pKb: Math.round(pKb * 1000) / 1000,
      ratio: Math.round(ratio * 1000) / 1000,
      bufferCapacity,
      effectiveRange,
    })
  }

  const handleReset = () => {
    setKa("")
    setKb("")
    setAcidConc("")
    setBaseConc("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Buffer Solution: pH = ${result.pH}, pOH = ${result.pOH}, Ratio = ${result.ratio}, Buffer Capacity = ${result.bufferCapacity}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Buffer Solution Calculator Result",
          text: `Buffer Solution: pH = ${result.pH}, pOH = ${result.pOH}, Ratio = ${result.ratio}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleBufferType = () => {
    setBufferType((prev) => (prev === "acidic" ? "basic" : "acidic"))
    setKa("")
    setKb("")
    setAcidConc("")
    setBaseConc("")
    setResult(null)
    setError("")
  }

  const getpHColor = (pH: number) => {
    if (pH < 3) return { color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    if (pH < 6) return { color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    if (pH < 8) return { color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    if (pH < 11) return { color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    return { color: "text-purple-600", bgColor: "bg-purple-50 border-purple-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Buffer Solution Calculator</CardTitle>
                    <CardDescription>Calculate pH using Henderson-Hasselbalch</CardDescription>
                  </div>
                </div>

                {/* Buffer Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Buffer Type</span>
                  <button
                    onClick={toggleBufferType}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        bufferType === "basic" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        bufferType === "acidic" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Acidic
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        bufferType === "basic" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Basic
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Ka or Kb Input */}
                {bufferType === "acidic" ? (
                  <div className="space-y-2">
                    <Label htmlFor="ka">Acid Dissociation Constant (Ka)</Label>
                    <Input
                      id="ka"
                      type="text"
                      placeholder="e.g., 1.8e-5 or 0.000018"
                      value={ka}
                      onChange={(e) => setKa(e.target.value)}
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="kb">Base Dissociation Constant (Kb)</Label>
                    <Input
                      id="kb"
                      type="text"
                      placeholder="e.g., 1.8e-5 or 0.000018"
                      value={kb}
                      onChange={(e) => setKb(e.target.value)}
                    />
                  </div>
                )}

                {/* Concentration Inputs */}
                {bufferType === "acidic" ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="acidConc">Weak Acid Concentration [HA] (M)</Label>
                      <Input
                        id="acidConc"
                        type="number"
                        placeholder="Enter concentration in mol/L"
                        value={acidConc}
                        onChange={(e) => setAcidConc(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="baseConc">Conjugate Base Concentration [A⁻] (M)</Label>
                      <Input
                        id="baseConc"
                        type="number"
                        placeholder="Enter concentration in mol/L"
                        value={baseConc}
                        onChange={(e) => setBaseConc(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="acidConc">Weak Base Concentration [B] (M)</Label>
                      <Input
                        id="acidConc"
                        type="number"
                        placeholder="Enter concentration in mol/L"
                        value={acidConc}
                        onChange={(e) => setAcidConc(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="baseConc">Conjugate Acid Concentration [HB⁺] (M)</Label>
                      <Input
                        id="baseConc"
                        type="number"
                        placeholder="Enter concentration in mol/L"
                        value={baseConc}
                        onChange={(e) => setBaseConc(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBuffer} className="w-full" size="lg">
                  Calculate Buffer pH
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getpHColor(result.pH).bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Buffer pH</p>
                      <p className={`text-5xl font-bold ${getpHColor(result.pH).color} mb-2`}>{result.pH}</p>
                      <p className="text-sm text-muted-foreground">pOH = {result.pOH}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Ratio</p>
                        <p className="font-semibold">{result.ratio}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Buffer Capacity</p>
                        <p className="font-semibold">{result.bufferCapacity}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">pKa</p>
                        <p className="font-semibold">{result.pKa}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Effective Range</p>
                        <p className="font-semibold">{result.effectiveRange.min} - {result.effectiveRange.max}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Henderson-Hasselbalch Equation</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">pH = pKa + log([A⁻] / [HA])</p>
                  </div>
                  <p>For basic buffers:</p>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">pOH = pKb + log([HB⁺] / [B])</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">pH Scale Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Strongly Acidic</span>
                      <span className="text-sm text-red-600">pH 0-3</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Weakly Acidic</span>
                      <span className="text-sm text-orange-600">pH 3-6</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Neutral</span>
                      <span className="text-sm text-green-600">pH 6-8</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Weakly Basic</span>
                      <span className="text-sm text-blue-600">pH 8-11</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Strongly Basic</span>
                      <span className="text-sm text-purple-600">pH 11-14</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is a Buffer Solution */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Buffer Solution?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A buffer solution is an aqueous solution that resists changes in pH when small amounts of acid or base
                  are added. Buffers are essential in many biological and chemical systems where maintaining a constant
                  pH is critical. They consist of a weak acid and its conjugate base (acidic buffer) or a weak base and
                  its conjugate acid (basic buffer).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The buffering capacity comes from the equilibrium between the weak acid/base and its conjugate pair.
                  When acid is added, the conjugate base neutralizes it; when base is added, the weak acid neutralizes it.
                  This dual action maintains the pH within a narrow range, typically within ±1 pH unit of the pKa value.
                </p>
              </CardContent>
            </Card>

            {/* How Buffer Calculations Work */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>How Buffer Calculations Work</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Henderson-Hasselbalch equation is derived from the acid dissociation equilibrium expression. For
                  an acidic buffer containing weak acid HA and its conjugate base A⁻, the equation relates pH to the
                  pKa (negative log of the acid dissociation constant) and the ratio of conjugate base to weak acid
                  concentrations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, if you have an acetic acid buffer with Ka = 1.8 × 10⁻⁵ (pKa = 4.74), [CH₃COOH] = 0.1 M,
                  and [CH₃COO⁻] = 0.15 M, the pH would be: pH = 4.74 + log(0.15/0.1) = 4.74 + 0.18 = 4.92. The buffer
                  works most effectively when the ratio of conjugate base to acid is between 0.1 and 10.
                </p>
              </CardContent>
            </Card>

            {/* Buffer Capacity and Range */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TestTube className="h-5 w-5 text-primary" />
                  <CardTitle>Buffer Capacity and Effective Range</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Buffer capacity refers to the amount of acid or base a buffer can neutralize before its pH changes
                  significantly. Higher concentrations of buffer components result in greater buffer capacity. A buffer
                  with 1 M concentrations can neutralize more acid/base than one with 0.1 M concentrations while
                  maintaining the same pH.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The effective buffer range is typically pKa ± 1, which corresponds to a conjugate base to acid ratio
                  between 0.1 and 10. Outside this range, the buffer loses its effectiveness because one component
                  becomes too depleted to effectively neutralize added acid or base. For optimal buffering, choose a
                  weak acid with a pKa close to the desired pH.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations and Assumptions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Henderson-Hasselbalch equation assumes ideal solution behavior, which means it works best for
                  dilute solutions (typically less than 0.1 M). At higher concentrations, activity coefficients deviate
                  from unity, and the calculated pH may differ from the actual pH. Temperature also affects Ka values,
                  so results are most accurate at 25°C.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equation also assumes that the weak acid/base does not significantly dissociate or associate,
                  which is valid when concentrations are much larger than Ka or Kb. For very dilute buffers or those
                  with pKa values near 0 or 14, more rigorous calculations may be necessary. Additionally, the presence
                  of ionic strength from other salts can affect buffer pH through activity coefficient effects.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-purple-500" />
                  <CardTitle>Applications of Buffer Solutions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Buffer solutions are crucial in biological systems where enzymes and proteins require specific pH
                  ranges to function. Blood is buffered primarily by the carbonic acid-bicarbonate system, maintaining
                  pH between 7.35 and 7.45. Cells use phosphate buffers to maintain intracellular pH, while proteins
                  act as buffers through their amino acid side chains.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In laboratories, buffers are essential for biochemical assays, chromatography, and electrophoresis.
                  Common laboratory buffers include PBS (phosphate-buffered saline) for biological work, TRIS for
                  molecular biology, and acetate buffers for chemical analysis. Industrial applications include food
                  preservation, pharmaceutical formulation, and water treatment processes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
