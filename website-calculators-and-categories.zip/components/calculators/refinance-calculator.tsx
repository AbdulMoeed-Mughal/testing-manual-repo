"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, RefreshCw, Info, TrendingDown, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

interface RefinanceResult {
  currentMonthlyPayment: number
  newMonthlyPayment: number
  monthlySavings: number
  currentTotalInterest: number
  newTotalInterest: number
  interestSavings: number
  netSavings: number
  breakEvenMonths: number
  category: string
  color: string
  bgColor: string
}

export function RefinanceCalculator() {
  const [currentBalance, setCurrentBalance] = useState("")
  const [currentRate, setCurrentRate] = useState("")
  const [remainingTerm, setRemainingTerm] = useState("")
  const [newRate, setNewRate] = useState("")
  const [newTerm, setNewTerm] = useState("")
  const [closingCosts, setClosingCosts] = useState("")
  const [extraPayment, setExtraPayment] = useState("")
  const [result, setResult] = useState<RefinanceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  const calculateMonthlyPayment = (principal: number, annualRate: number, termYears: number): number => {
    const monthlyRate = annualRate / 100 / 12
    const numPayments = termYears * 12
    if (monthlyRate === 0) return principal / numPayments
    return (
      (principal * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / (Math.pow(1 + monthlyRate, numPayments) - 1)
    )
  }

  const calculateTotalInterest = (principal: number, monthlyPayment: number, termYears: number): number => {
    return monthlyPayment * termYears * 12 - principal
  }

  const calculateRefinance = () => {
    setError("")
    setResult(null)

    const balance = Number.parseFloat(currentBalance)
    const currentRateNum = Number.parseFloat(currentRate)
    const remainingTermNum = Number.parseFloat(remainingTerm)
    const newRateNum = Number.parseFloat(newRate)
    const newTermNum = Number.parseFloat(newTerm)
    const closingCostsNum = Number.parseFloat(closingCosts) || 0
    const extraPaymentNum = Number.parseFloat(extraPayment) || 0

    if (isNaN(balance) || balance <= 0) {
      setError("Please enter a valid loan balance greater than 0")
      return
    }
    if (isNaN(currentRateNum) || currentRateNum < 0) {
      setError("Please enter a valid current interest rate")
      return
    }
    if (isNaN(remainingTermNum) || remainingTermNum <= 0) {
      setError("Please enter a valid remaining loan term")
      return
    }
    if (isNaN(newRateNum) || newRateNum < 0) {
      setError("Please enter a valid new interest rate")
      return
    }
    if (isNaN(newTermNum) || newTermNum <= 0) {
      setError("Please enter a valid new loan term")
      return
    }

    // Calculate current loan details
    const currentMonthlyPayment = calculateMonthlyPayment(balance, currentRateNum, remainingTermNum)
    const currentTotalInterest = calculateTotalInterest(balance, currentMonthlyPayment, remainingTermNum)

    // Calculate new loan details
    let newMonthlyPayment = calculateMonthlyPayment(balance, newRateNum, newTermNum)

    // Add extra payment if specified
    if (extraPaymentNum > 0) {
      newMonthlyPayment += extraPaymentNum
    }

    const newTotalInterest = calculateTotalInterest(balance, newMonthlyPayment - extraPaymentNum, newTermNum)

    // Calculate savings
    const monthlySavings = currentMonthlyPayment - newMonthlyPayment
    const interestSavings = currentTotalInterest - newTotalInterest
    const netSavings = interestSavings - closingCostsNum

    // Calculate break-even point
    const breakEvenMonths = monthlySavings > 0 ? Math.ceil(closingCostsNum / monthlySavings) : 0

    // Determine recommendation category
    let category: string
    let color: string
    let bgColor: string

    if (netSavings > 10000 && breakEvenMonths < 24) {
      category = "Highly Recommended"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (netSavings > 5000 && breakEvenMonths < 36) {
      category = "Recommended"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (netSavings > 0 && breakEvenMonths < 48) {
      category = "Consider Carefully"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Not Recommended"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      currentMonthlyPayment,
      newMonthlyPayment,
      monthlySavings,
      currentTotalInterest,
      newTotalInterest,
      interestSavings,
      netSavings,
      breakEvenMonths,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setCurrentBalance("")
    setCurrentRate("")
    setRemainingTerm("")
    setNewRate("")
    setNewTerm("")
    setClosingCosts("")
    setExtraPayment("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Refinance Analysis: Monthly savings $${result.monthlySavings.toFixed(2)}, Net savings $${result.netSavings.toFixed(2)}, Break-even ${result.breakEvenMonths} months - ${result.category}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Refinance Calculator Result",
          text: `Refinance Analysis: Monthly savings $${result.monthlySavings.toFixed(2)}, Net savings $${result.netSavings.toFixed(2)} - ${result.category}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <RefreshCw className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Refinance Calculator</CardTitle>
                    <CardDescription>Evaluate potential savings from refinancing</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Current Loan Section */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-muted-foreground">Current Loan</h3>

                  <div className="space-y-2">
                    <Label htmlFor="currentBalance">Current Loan Balance ($)</Label>
                    <Input
                      id="currentBalance"
                      type="number"
                      placeholder="e.g., 250000"
                      value={currentBalance}
                      onChange={(e) => setCurrentBalance(e.target.value)}
                      min="0"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="currentRate">Current Rate (%)</Label>
                      <Input
                        id="currentRate"
                        type="number"
                        placeholder="e.g., 6.5"
                        value={currentRate}
                        onChange={(e) => setCurrentRate(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="remainingTerm">Remaining Term (years)</Label>
                      <Input
                        id="remainingTerm"
                        type="number"
                        placeholder="e.g., 25"
                        value={remainingTerm}
                        onChange={(e) => setRemainingTerm(e.target.value)}
                        min="1"
                      />
                    </div>
                  </div>
                </div>

                {/* New Loan Section */}
                <div className="space-y-3 pt-2 border-t">
                  <h3 className="text-sm font-semibold text-muted-foreground">New Loan</h3>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="newRate">New Rate (%)</Label>
                      <Input
                        id="newRate"
                        type="number"
                        placeholder="e.g., 5.5"
                        value={newRate}
                        onChange={(e) => setNewRate(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="newTerm">New Term (years)</Label>
                      <Input
                        id="newTerm"
                        type="number"
                        placeholder="e.g., 30"
                        value={newTerm}
                        onChange={(e) => setNewTerm(e.target.value)}
                        min="1"
                      />
                    </div>
                  </div>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="w-full justify-between">
                      Advanced Options
                      <ChevronDown className={`h-4 w-4 transition-transform ${showAdvanced ? "rotate-180" : ""}`} />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-3 pt-2">
                    <div className="space-y-2">
                      <Label htmlFor="closingCosts">Closing Costs ($)</Label>
                      <Input
                        id="closingCosts"
                        type="number"
                        placeholder="e.g., 5000"
                        value={closingCosts}
                        onChange={(e) => setClosingCosts(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="extraPayment">Extra Monthly Payment ($)</Label>
                      <Input
                        id="extraPayment"
                        type="number"
                        placeholder="e.g., 200"
                        value={extraPayment}
                        onChange={(e) => setExtraPayment(e.target.value)}
                        min="0"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRefinance} className="w-full" size="lg">
                  Calculate Refinance Savings
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Monthly Savings</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.monthlySavings >= 0 ? "+" : ""}
                        {formatCurrency(result.monthlySavings)}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="text-center p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Net Savings</p>
                        <p className="font-semibold">{formatCurrency(result.netSavings)}</p>
                      </div>
                      <div className="text-center p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Break-Even</p>
                        <p className="font-semibold">{result.breakEvenMonths} months</p>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3">
                          {showDetails ? "Hide Details" : "Show Details"}
                          <ChevronDown
                            className={`ml-2 h-4 w-4 transition-transform ${showDetails ? "rotate-180" : ""}`}
                          />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2">
                        <div className="p-3 bg-white/50 rounded-lg space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Current Payment:</span>
                            <span className="font-medium">{formatCurrency(result.currentMonthlyPayment)}/mo</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">New Payment:</span>
                            <span className="font-medium">{formatCurrency(result.newMonthlyPayment)}/mo</span>
                          </div>
                          <div className="flex justify-between border-t pt-2">
                            <span className="text-muted-foreground">Current Total Interest:</span>
                            <span className="font-medium">{formatCurrency(result.currentTotalInterest)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">New Total Interest:</span>
                            <span className="font-medium">{formatCurrency(result.newTotalInterest)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Interest Savings:</span>
                            <span className="font-medium text-green-600">{formatCurrency(result.interestSavings)}</span>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Refinance Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Highly Recommended</span>
                      <span className="text-sm text-green-600">{">"} $10k savings</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Recommended</span>
                      <span className="text-sm text-blue-600">$5k - $10k savings</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Consider Carefully</span>
                      <span className="text-sm text-yellow-600">{"<"} $5k savings</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Not Recommended</span>
                      <span className="text-sm text-red-600">No net savings</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-xs mb-1">Monthly Payment</p>
                    <p className="font-mono text-xs">P × [r(1+r)^n] / [(1+r)^n - 1]</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-xs mb-1">Break-Even Point</p>
                    <p className="font-mono text-xs">Closing Costs ÷ Monthly Savings</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-xs mb-1">Net Savings</p>
                    <p className="font-mono text-xs">Interest Saved - Closing Costs</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Mortgage Refinancing?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Mortgage refinancing is the process of replacing your current home loan with a new one, typically to
                  secure better terms such as a lower interest rate, reduced monthly payments, or a different loan term.
                  When you refinance, you essentially pay off your existing mortgage and take out a new loan, which may
                  come with new terms and conditions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Homeowners often consider refinancing when interest rates drop significantly below their current rate,
                  when their credit score has improved substantially, or when they want to change from an
                  adjustable-rate mortgage to a fixed-rate mortgage for more predictable payments. The decision to
                  refinance should be based on a careful analysis of the potential savings versus the costs involved.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>When Should You Refinance?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The right time to refinance depends on several factors including current interest rates, your
                  financial situation, and how long you plan to stay in your home. A general rule of thumb is that
                  refinancing makes sense when you can reduce your interest rate by at least 0.5% to 1%, though this
                  varies based on your loan amount and other circumstances.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Good Reasons to Refinance</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Interest rates have dropped 1% or more below your current rate</li>
                      <li>• Your credit score has significantly improved</li>
                      <li>• You want to switch from ARM to fixed-rate mortgage</li>
                      <li>• You plan to stay in your home long enough to recoup costs</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">When to Avoid Refinancing</h4>
                    <ul className="text-red-700 text-sm space-y-1">
                      <li>• You plan to move before breaking even on closing costs</li>
                      <li>• The rate difference is less than 0.5%</li>
                      <li>• Your home value has decreased significantly</li>
                      <li>• You have a low loan balance remaining</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Refinance Costs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Refinancing isn't free—closing costs typically range from 2% to 5% of your loan amount. These costs
                  include application fees, appraisal fees, title insurance, attorney fees, and various other charges.
                  Understanding these costs is crucial for calculating whether refinancing makes financial sense for
                  your situation.
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Typical Closing Costs</p>
                    <p className="text-muted-foreground text-sm mt-1">2% - 5% of loan amount</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Appraisal Fee</p>
                    <p className="text-muted-foreground text-sm mt-1">$300 - $500</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Application Fee</p>
                    <p className="text-muted-foreground text-sm mt-1">$250 - $500</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Title Insurance</p>
                    <p className="text-muted-foreground text-sm mt-1">0.5% - 1% of loan</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Refinance calculations are estimates and may vary based on interest rates, fees, and lender terms.
                  Actual costs, savings, and break-even points may differ based on your specific situation, credit
                  score, loan-to-value ratio, and lender requirements. This calculator is for informational purposes
                  only and should not be considered financial advice. Consult a mortgage professional for personalized
                  advice before making refinancing decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
