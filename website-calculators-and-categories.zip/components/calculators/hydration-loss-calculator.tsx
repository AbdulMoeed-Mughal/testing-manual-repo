"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Droplets,
  Info,
  ChevronDown,
  ChevronUp,
  Thermometer,
  Activity,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type TempUnit = "celsius" | "fahrenheit"

interface HydrationResult {
  fluidLoss: number
  dailyRequirement: number
  preActivity: number
  duringActivity: number
  postActivity: number
  category: string
  color: string
  bgColor: string
}

export function HydrationLossCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [tempUnit, setTempUnit] = useState<TempUnit>("celsius")
  const [weight, setWeight] = useState("")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<string>("")
  const [duration, setDuration] = useState("")
  const [intensity, setIntensity] = useState<string>("")
  const [temperature, setTemperature] = useState("")
  const [humidity, setHumidity] = useState("")
  const [sweatRate, setSweatRate] = useState("")
  const [baselineIntake, setBaselineIntake] = useState("")
  const [result, setResult] = useState<HydrationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)

  const calculateHydration = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const ageNum = Number.parseFloat(age)
    const durationNum = Number.parseFloat(duration)
    const tempNum = Number.parseFloat(temperature)
    const humidityNum = Number.parseFloat(humidity)

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (!gender) {
      setError("Please select your gender")
      return
    }

    if (isNaN(durationNum) || durationNum <= 0) {
      setError("Please enter a valid activity duration greater than 0")
      return
    }

    if (!intensity) {
      setError("Please select activity intensity")
      return
    }

    if (isNaN(tempNum)) {
      setError("Please enter a valid temperature")
      return
    }

    if (isNaN(humidityNum) || humidityNum < 0 || humidityNum > 100) {
      setError("Please enter a valid humidity between 0 and 100%")
      return
    }

    // Convert to metric if needed
    const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum
    const tempC = tempUnit === "fahrenheit" ? (tempNum - 32) * (5 / 9) : tempNum

    // Intensity factors (ml/kg/hour base sweat rate)
    const intensityFactors: Record<string, number> = {
      low: 0.5,
      moderate: 0.8,
      high: 1.2,
      extreme: 1.6,
    }

    // Temperature multiplier
    let tempMultiplier = 1.0
    if (tempC > 35) tempMultiplier = 1.5
    else if (tempC > 30) tempMultiplier = 1.3
    else if (tempC > 25) tempMultiplier = 1.15
    else if (tempC > 20) tempMultiplier = 1.0
    else if (tempC > 15) tempMultiplier = 0.9
    else tempMultiplier = 0.8

    // Humidity multiplier
    let humidityMultiplier = 1.0
    if (humidityNum > 80) humidityMultiplier = 1.3
    else if (humidityNum > 60) humidityMultiplier = 1.15
    else if (humidityNum > 40) humidityMultiplier = 1.0
    else humidityMultiplier = 0.9

    // Gender adjustment
    const genderMultiplier = gender === "male" ? 1.0 : 0.85

    // Age adjustment
    let ageMultiplier = 1.0
    if (ageNum > 65) ageMultiplier = 0.85
    else if (ageNum > 50) ageMultiplier = 0.9
    else if (ageNum < 18) ageMultiplier = 0.95

    // Calculate sweat loss
    let sweatLossPerHour: number

    const sweatRateNum = Number.parseFloat(sweatRate)
    if (!isNaN(sweatRateNum) && sweatRateNum > 0) {
      // Use provided sweat rate
      sweatLossPerHour = sweatRateNum
    } else {
      // Estimate sweat rate
      const baseSweatRate = intensityFactors[intensity] || 0.8
      sweatLossPerHour =
        baseSweatRate * weightKg * tempMultiplier * humidityMultiplier * genderMultiplier * ageMultiplier * 10 // Convert to ml
    }

    const durationHours = durationNum / 60
    const fluidLoss = Math.round(sweatLossPerHour * durationHours)

    // Calculate baseline daily requirement
    const baselineIntakeNum = Number.parseFloat(baselineIntake)
    let baseDailyRequirement: number

    if (!isNaN(baselineIntakeNum) && baselineIntakeNum > 0) {
      baseDailyRequirement = baselineIntakeNum
    } else {
      // Standard recommendation: 30-35 ml per kg body weight
      baseDailyRequirement = Math.round(weightKg * 33)
    }

    // Total daily requirement = baseline + activity loss
    const dailyRequirement = Math.round(baseDailyRequirement + fluidLoss)

    // Pre, during, and post activity recommendations
    const preActivity = Math.round(5 * weightKg) // 5-7 ml/kg 2-4 hours before
    const duringActivity = Math.round(sweatLossPerHour * 0.8) // Replace 80% of losses during
    const postActivity = Math.round(fluidLoss * 1.5) // 150% of losses to fully rehydrate

    // Determine hydration status category
    let category: string
    let color: string
    let bgColor: string

    if (fluidLoss < 500) {
      category = "Low Fluid Loss"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (fluidLoss < 1000) {
      category = "Moderate Fluid Loss"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (fluidLoss < 1500) {
      category = "High Fluid Loss"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Fluid Loss"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      fluidLoss,
      dailyRequirement,
      preActivity,
      duringActivity,
      postActivity,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setWeight("")
    setAge("")
    setGender("")
    setDuration("")
    setIntensity("")
    setTemperature("")
    setHumidity("")
    setSweatRate("")
    setBaselineIntake("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Hydration Loss Calculator Results:
Estimated Fluid Loss: ${result.fluidLoss} ml
Daily Water Requirement: ${result.dailyRequirement} ml
Pre-Activity: ${result.preActivity} ml
During Activity: ${result.duringActivity} ml/hour
Post-Activity: ${result.postActivity} ml`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Hydration Loss Results",
          text: `I estimated my fluid loss using CalcHub! Estimated loss: ${result.fluidLoss} ml, Daily requirement: ${result.dailyRequirement} ml`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setResult(null)
    setError("")
  }

  const toggleTempUnit = () => {
    setTempUnit((prev) => (prev === "celsius" ? "fahrenheit" : "celsius"))
    setTemperature("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Hydration Loss Calculator</CardTitle>
                    <CardDescription>Estimate fluid loss and daily water needs</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <Select value={gender} onValueChange={setGender}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Activity Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Activity Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Enter duration in minutes"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Activity Intensity */}
                <div className="space-y-2">
                  <Label>Activity Intensity</Label>
                  <Select value={intensity} onValueChange={setIntensity}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select intensity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (walking, light yoga)</SelectItem>
                      <SelectItem value="moderate">Moderate (jogging, cycling)</SelectItem>
                      <SelectItem value="high">High (running, HIIT)</SelectItem>
                      <SelectItem value="extreme">Extreme (competitive sports)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Temperature Input */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="temperature">Temperature ({tempUnit === "celsius" ? "°C" : "°F"})</Label>
                    <button onClick={toggleTempUnit} className="text-xs text-primary hover:underline">
                      Switch to {tempUnit === "celsius" ? "°F" : "°C"}
                    </button>
                  </div>
                  <Input
                    id="temperature"
                    type="number"
                    placeholder={`Enter temperature in ${tempUnit === "celsius" ? "Celsius" : "Fahrenheit"}`}
                    value={temperature}
                    onChange={(e) => setTemperature(e.target.value)}
                  />
                </div>

                {/* Humidity Input */}
                <div className="space-y-2">
                  <Label htmlFor="humidity">Humidity (%)</Label>
                  <Input
                    id="humidity"
                    type="number"
                    placeholder="Enter humidity percentage"
                    value={humidity}
                    onChange={(e) => setHumidity(e.target.value)}
                    min="0"
                    max="100"
                  />
                </div>

                {/* Advanced Options */}
                <div className="pt-2">
                  <button
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="flex items-center gap-2 text-sm font-medium text-primary hover:underline"
                  >
                    {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    Advanced Options
                  </button>

                  {showAdvanced && (
                    <div className="mt-4 space-y-4 p-4 bg-muted/50 rounded-lg">
                      <div className="space-y-2">
                        <Label htmlFor="sweatRate">Known Sweat Rate (ml/hour) - Optional</Label>
                        <Input
                          id="sweatRate"
                          type="number"
                          placeholder="Enter if known from testing"
                          value={sweatRate}
                          onChange={(e) => setSweatRate(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="baselineIntake">Baseline Daily Intake (ml) - Optional</Label>
                        <Input
                          id="baselineIntake"
                          type="number"
                          placeholder="Your typical daily water intake"
                          value={baselineIntake}
                          onChange={(e) => setBaselineIntake(e.target.value)}
                          min="0"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateHydration} className="w-full" size="lg">
                  Calculate Hydration Needs
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Fluid Loss</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{result.fluidLoss} ml</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-3">
                      <div className="text-center p-3 bg-white/60 rounded-lg">
                        <p className="text-xs text-muted-foreground">Daily Requirement</p>
                        <p className="text-lg font-bold text-foreground">{result.dailyRequirement} ml</p>
                      </div>
                      <div className="text-center p-3 bg-white/60 rounded-lg">
                        <p className="text-xs text-muted-foreground">During Activity</p>
                        <p className="text-lg font-bold text-foreground">{result.duringActivity} ml/hr</p>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Hydration Plan
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          View Hydration Plan
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 space-y-3 text-sm">
                        <div className="flex justify-between items-center p-2 bg-white/60 rounded">
                          <span className="text-muted-foreground">Pre-Activity (2-4 hrs before)</span>
                          <span className="font-semibold">{result.preActivity} ml</span>
                        </div>
                        <div className="flex justify-between items-center p-2 bg-white/60 rounded">
                          <span className="text-muted-foreground">During Activity</span>
                          <span className="font-semibold">{result.duringActivity} ml/hour</span>
                        </div>
                        <div className="flex justify-between items-center p-2 bg-white/60 rounded">
                          <span className="text-muted-foreground">Post-Activity (within 2 hrs)</span>
                          <span className="font-semibold">{result.postActivity} ml</span>
                        </div>
                        <div className="flex justify-between items-center p-2 bg-white/60 rounded">
                          <span className="text-muted-foreground">Total Daily Target</span>
                          <span className="font-semibold">{result.dailyRequirement} ml</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fluid Loss Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low</span>
                      <span className="text-sm text-green-600">{"< 500 ml"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Moderate</span>
                      <span className="text-sm text-blue-600">500 - 1000 ml</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">High</span>
                      <span className="text-sm text-yellow-600">1000 - 1500 ml</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very High</span>
                      <span className="text-sm text-red-600">{"> 1500 ml"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Environment Impact</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                    <Thermometer className="h-5 w-5 text-orange-500" />
                    <div>
                      <p className="font-medium text-foreground">Temperature</p>
                      <p className="text-xs">Above 30°C increases sweat rate by 30-50%</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                    <Droplets className="h-5 w-5 text-blue-500" />
                    <div>
                      <p className="font-medium text-foreground">Humidity</p>
                      <p className="text-xs">Above 80% reduces evaporative cooling</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                    <Activity className="h-5 w-5 text-green-500" />
                    <div>
                      <p className="font-medium text-foreground">Intensity</p>
                      <p className="text-xs">High intensity can double fluid loss</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sweat Rate Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      Sweat Loss = Base Rate × Weight × Temp Factor × Humidity Factor
                    </p>
                  </div>
                  <p>Base rates vary by intensity: Low (0.5), Moderate (0.8), High (1.2), Extreme (1.6) ml/kg/hour.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Hydration and Fluid Loss</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Proper hydration is essential for maintaining optimal physical performance, cognitive function, and
                  overall health. During physical activity, your body loses fluids primarily through sweat, which helps
                  regulate body temperature. The rate of fluid loss varies significantly based on exercise intensity,
                  environmental conditions, individual physiology, and fitness level.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Dehydration of just 2% of body weight can impair physical performance and cognitive function. More
                  severe dehydration (4-5% or more) can lead to serious health consequences including heat exhaustion,
                  heat stroke, and cardiovascular strain. Understanding your hydration needs helps you maintain optimal
                  fluid balance during exercise and throughout the day.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Fluid Loss</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence how much fluid you lose during physical activity. Exercise intensity is the
                  primary determinant - high-intensity activities like running, cycling, or competitive sports can
                  result in sweat rates of 1-2 liters per hour or more. Environmental conditions play a crucial role;
                  hot and humid environments significantly increase sweat production as your body works harder to cool
                  itself.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Body Size & Composition</h4>
                    <p className="text-cyan-700 text-sm">
                      Larger individuals typically sweat more due to greater metabolic heat production. Body composition
                      also matters - muscle generates more heat than fat during exercise.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Fitness Level</h4>
                    <p className="text-blue-700 text-sm">
                      Well-trained athletes often sweat more efficiently, starting to sweat earlier and producing more
                      dilute sweat, which helps with thermoregulation.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Acclimatization</h4>
                    <p className="text-orange-700 text-sm">
                      Individuals acclimatized to hot conditions adapt by increasing sweat production and reducing
                      electrolyte concentration in sweat, improving cooling efficiency.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Clothing</h4>
                    <p className="text-green-700 text-sm">
                      Breathable, moisture-wicking fabrics help evaporative cooling. Heavy or non-breathable clothing
                      can trap heat and increase fluid loss.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Hydration Strategies</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Before Exercise</h4>
                    <p className="text-muted-foreground text-sm">
                      Drink 5-7 ml per kg of body weight 2-4 hours before activity. This allows time for optimal
                      hydration and elimination of excess fluid. Urine should be pale yellow before starting.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">During Exercise</h4>
                    <p className="text-muted-foreground text-sm">
                      Aim to replace 80% of sweat losses during activity. For most people, this means drinking 150-350
                      ml every 15-20 minutes. For activities over 60 minutes, consider sports drinks with electrolytes.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">After Exercise</h4>
                    <p className="text-muted-foreground text-sm">
                      Drink 150% of fluid lost within 2 hours post-exercise to account for continued sweating and
                      urination. Include sodium-containing foods or beverages to enhance fluid retention.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p>
                      Hydration estimates are based on standard formulas and may vary depending on individual
                      metabolism, activity intensity, and environmental factors. Individual sweat rates can vary
                      significantly. For precise hydration planning, especially for competitive athletes, consider
                      professional sweat testing. Consult a healthcare professional or sports dietitian for personalized
                      guidance, especially if you have health conditions affecting fluid balance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
