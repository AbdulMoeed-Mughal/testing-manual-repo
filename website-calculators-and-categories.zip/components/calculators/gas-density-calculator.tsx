"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Wind, Info, Beaker, Thermometer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type CalculationMethod = "mass-volume" | "ideal-gas"

interface DensityResult {
  density: number
  method: string
  category: string
  color: string
  bgColor: string
  steps: string[]
}

export function GasDensityCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("mass-volume")
  const [mass, setMass] = useState("")
  const [massUnit, setMassUnit] = useState("g")
  const [volume, setVolume] = useState("")
  const [volumeUnit, setVolumeUnit] = useState("L")
  const [pressure, setPressure] = useState("")
  const [pressureUnit, setPressureUnit] = useState("atm")
  const [molarMass, setMolarMass] = useState("")
  const [temperature, setTemperature] = useState("")
  const [temperatureUnit, setTemperatureUnit] = useState("K")
  const [outputUnit, setOutputUnit] = useState("g/L")
  const [result, setResult] = useState<DensityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const R = 0.0821 // L·atm/(mol·K)

  const convertMassToGrams = (value: number, unit: string): number => {
    switch (unit) {
      case "kg": return value * 1000
      case "mg": return value / 1000
      default: return value // g
    }
  }

  const convertVolumeToLiters = (value: number, unit: string): number => {
    switch (unit) {
      case "m3": return value * 1000
      case "mL": return value / 1000
      case "cm3": return value / 1000
      default: return value // L
    }
  }

  const convertPressureToAtm = (value: number, unit: string): number => {
    switch (unit) {
      case "kPa": return value / 101.325
      case "Pa": return value / 101325
      case "bar": return value / 1.01325
      case "mmHg": return value / 760
      case "psi": return value / 14.696
      default: return value // atm
    }
  }

  const convertTemperatureToKelvin = (value: number, unit: string): number => {
    switch (unit) {
      case "C": return value + 273.15
      case "F": return (value - 32) * 5/9 + 273.15
      default: return value // K
    }
  }

  const convertDensityFromGPerL = (value: number, unit: string): number => {
    switch (unit) {
      case "kg/m3": return value
      case "mg/mL": return value
      case "g/mL": return value / 1000
      default: return value // g/L
    }
  }

  const getDensityCategory = (densityGPerL: number): { category: string; color: string; bgColor: string } => {
    if (densityGPerL < 0.5) {
      return { category: "Very Light Gas", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    } else if (densityGPerL < 1.5) {
      return { category: "Light Gas", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    } else if (densityGPerL < 3) {
      return { category: "Moderate Density Gas", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    } else {
      return { category: "Heavy Gas", color: "text-purple-600", bgColor: "bg-purple-50 border-purple-200" }
    }
  }

  const calculateDensity = () => {
    setError("")
    setResult(null)

    const steps: string[] = []

    if (method === "mass-volume") {
      const massNum = Number.parseFloat(mass)
      const volumeNum = Number.parseFloat(volume)

      if (isNaN(massNum) || massNum <= 0) {
        setError("Please enter a valid mass greater than 0")
        return
      }
      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }

      const massInGrams = convertMassToGrams(massNum, massUnit)
      const volumeInLiters = convertVolumeToLiters(volumeNum, volumeUnit)

      steps.push(`Mass: ${massNum} ${massUnit} = ${massInGrams.toFixed(4)} g`)
      steps.push(`Volume: ${volumeNum} ${volumeUnit} = ${volumeInLiters.toFixed(4)} L`)
      steps.push(`Density = Mass / Volume`)
      steps.push(`Density = ${massInGrams.toFixed(4)} g / ${volumeInLiters.toFixed(4)} L`)

      const densityGPerL = massInGrams / volumeInLiters
      const finalDensity = convertDensityFromGPerL(densityGPerL, outputUnit)

      steps.push(`Density = ${finalDensity.toFixed(6)} ${outputUnit}`)

      const { category, color, bgColor } = getDensityCategory(densityGPerL)

      setResult({
        density: finalDensity,
        method: "Mass and Volume (ρ = m/V)",
        category,
        color,
        bgColor,
        steps,
      })
    } else {
      const pressureNum = Number.parseFloat(pressure)
      const molarMassNum = Number.parseFloat(molarMass)
      const temperatureNum = Number.parseFloat(temperature)

      if (isNaN(pressureNum) || pressureNum <= 0) {
        setError("Please enter a valid pressure greater than 0")
        return
      }
      if (isNaN(molarMassNum) || molarMassNum <= 0) {
        setError("Please enter a valid molar mass greater than 0")
        return
      }
      if (isNaN(temperatureNum)) {
        setError("Please enter a valid temperature")
        return
      }

      const pressureInAtm = convertPressureToAtm(pressureNum, pressureUnit)
      const temperatureInK = convertTemperatureToKelvin(temperatureNum, temperatureUnit)

      if (temperatureInK <= 0) {
        setError("Temperature must be above absolute zero")
        return
      }

      steps.push(`Pressure: ${pressureNum} ${pressureUnit} = ${pressureInAtm.toFixed(4)} atm`)
      steps.push(`Molar Mass: ${molarMassNum} g/mol`)
      steps.push(`Temperature: ${temperatureNum} ${temperatureUnit === "K" ? "K" : "°" + temperatureUnit} = ${temperatureInK.toFixed(2)} K`)
      steps.push(`Gas Constant (R): ${R} L·atm/(mol·K)`)
      steps.push(`Density = (P × M) / (R × T)`)
      steps.push(`Density = (${pressureInAtm.toFixed(4)} × ${molarMassNum}) / (${R} × ${temperatureInK.toFixed(2)})`)

      const densityGPerL = (pressureInAtm * molarMassNum) / (R * temperatureInK)
      const finalDensity = convertDensityFromGPerL(densityGPerL, outputUnit)

      steps.push(`Density = ${finalDensity.toFixed(6)} ${outputUnit}`)

      const { category, color, bgColor } = getDensityCategory(densityGPerL)

      setResult({
        density: finalDensity,
        method: "Ideal Gas Law (ρ = PM/RT)",
        category,
        color,
        bgColor,
        steps,
      })
    }
  }

  const handleReset = () => {
    setMass("")
    setVolume("")
    setPressure("")
    setMolarMass("")
    setTemperature("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Gas Density: ${result.density.toFixed(6)} ${outputUnit} (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Gas Density Calculation",
          text: `Gas Density: ${result.density.toFixed(6)} ${outputUnit} - Calculated using ${result.method}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleMethod = () => {
    setMethod((prev) => (prev === "mass-volume" ? "ideal-gas" : "mass-volume"))
    setResult(null)
    setError("")
  }

  // Common gases reference data
  const commonGases = [
    { name: "Hydrogen (H₂)", molarMass: 2.016, density: 0.0899 },
    { name: "Helium (He)", molarMass: 4.003, density: 0.179 },
    { name: "Nitrogen (N₂)", molarMass: 28.01, density: 1.251 },
    { name: "Oxygen (O₂)", molarMass: 32.00, density: 1.429 },
    { name: "Air", molarMass: 28.97, density: 1.293 },
    { name: "Carbon Dioxide (CO₂)", molarMass: 44.01, density: 1.977 },
    { name: "Methane (CH₄)", molarMass: 16.04, density: 0.717 },
    { name: "Propane (C₃H₈)", molarMass: 44.10, density: 2.010 },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Wind className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gas Density Calculator</CardTitle>
                    <CardDescription>Calculate gas density using mass-volume or ideal gas law</CardDescription>
                  </div>
                </div>

                {/* Method Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Method</span>
                  <button
                    onClick={toggleMethod}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        method === "ideal-gas" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "mass-volume" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Mass/Volume
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "ideal-gas" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Ideal Gas
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {method === "mass-volume" ? (
                  <>
                    {/* Mass Input */}
                    <div className="space-y-2">
                      <Label htmlFor="mass">Mass</Label>
                      <div className="flex gap-2">
                        <Input
                          id="mass"
                          type="number"
                          placeholder="Enter mass"
                          value={mass}
                          onChange={(e) => setMass(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <Select value={massUnit} onValueChange={setMassUnit}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="g">g</SelectItem>
                            <SelectItem value="kg">kg</SelectItem>
                            <SelectItem value="mg">mg</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Volume Input */}
                    <div className="space-y-2">
                      <Label htmlFor="volume">Volume</Label>
                      <div className="flex gap-2">
                        <Input
                          id="volume"
                          type="number"
                          placeholder="Enter volume"
                          value={volume}
                          onChange={(e) => setVolume(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <Select value={volumeUnit} onValueChange={setVolumeUnit}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="L">L</SelectItem>
                            <SelectItem value="mL">mL</SelectItem>
                            <SelectItem value="m3">m³</SelectItem>
                            <SelectItem value="cm3">cm³</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Pressure Input */}
                    <div className="space-y-2">
                      <Label htmlFor="pressure">Pressure (P)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="pressure"
                          type="number"
                          placeholder="Enter pressure"
                          value={pressure}
                          onChange={(e) => setPressure(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <Select value={pressureUnit} onValueChange={setPressureUnit}>
                          <SelectTrigger className="w-24">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="atm">atm</SelectItem>
                            <SelectItem value="kPa">kPa</SelectItem>
                            <SelectItem value="Pa">Pa</SelectItem>
                            <SelectItem value="bar">bar</SelectItem>
                            <SelectItem value="mmHg">mmHg</SelectItem>
                            <SelectItem value="psi">psi</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Molar Mass Input */}
                    <div className="space-y-2">
                      <Label htmlFor="molarMass">Molar Mass (M) in g/mol</Label>
                      <Input
                        id="molarMass"
                        type="number"
                        placeholder="Enter molar mass"
                        value={molarMass}
                        onChange={(e) => setMolarMass(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>

                    {/* Temperature Input */}
                    <div className="space-y-2">
                      <Label htmlFor="temperature">Temperature (T)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="temperature"
                          type="number"
                          placeholder="Enter temperature"
                          value={temperature}
                          onChange={(e) => setTemperature(e.target.value)}
                          step="any"
                          className="flex-1"
                        />
                        <Select value={temperatureUnit} onValueChange={setTemperatureUnit}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="K">K</SelectItem>
                            <SelectItem value="C">°C</SelectItem>
                            <SelectItem value="F">°F</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="outputUnit">Output Unit</Label>
                  <Select value={outputUnit} onValueChange={setOutputUnit}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="g/L">g/L</SelectItem>
                      <SelectItem value="kg/m3">kg/m³</SelectItem>
                      <SelectItem value="mg/mL">mg/mL</SelectItem>
                      <SelectItem value="g/mL">g/mL</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDensity} className="w-full" size="lg">
                  Calculate Density
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Gas Density</p>
                      <p className={`text-4xl font-bold ${result.color} mb-2`}>
                        {result.density < 0.001 ? result.density.toExponential(4) : result.density.toFixed(6)}
                      </p>
                      <p className="text-lg font-medium text-muted-foreground">{outputUnit}</p>
                      <p className={`text-sm font-semibold ${result.color} mt-1`}>{result.category}</p>
                    </div>

                    {/* Calculation Steps */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg">
                      <p className="text-xs font-medium text-muted-foreground mb-2">Calculation Steps:</p>
                      <div className="space-y-1">
                        {result.steps.map((step, index) => (
                          <p key={index} className="text-xs text-muted-foreground font-mono">{step}</p>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset} className="bg-transparent">
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy} className="bg-transparent">
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare} className="bg-transparent">
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gas Density Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-2">From Mass and Volume:</p>
                    <p className="font-mono text-center text-lg">ρ = m / V</p>
                    <p className="text-xs text-muted-foreground mt-2 text-center">
                      where ρ = density, m = mass, V = volume
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-2">From Ideal Gas Law:</p>
                    <p className="font-mono text-center text-lg">ρ = (P × M) / (R × T)</p>
                    <p className="text-xs text-muted-foreground mt-2 text-center">
                      where P = pressure, M = molar mass, R = gas constant, T = temperature
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Gases at STP</CardTitle>
                  <CardDescription>Standard Temperature and Pressure (0°C, 1 atm)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {commonGases.map((gas, index) => (
                      <div key={index} className="flex items-center justify-between p-2 rounded-lg bg-muted/50 text-sm">
                        <span className="font-medium">{gas.name}</span>
                        <span className="text-muted-foreground">{gas.density} g/L</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Gas Density?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gas density is a measure of how much mass is contained in a given volume of gas, typically 
                  expressed in grams per liter (g/L) or kilograms per cubic meter (kg/m³). Unlike solids and 
                  liquids, gas density varies significantly with changes in temperature and pressure, making 
                  it a crucial parameter in thermodynamics, atmospheric science, and chemical engineering.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The density of a gas depends on its molecular weight and the conditions under which it 
                  exists. Heavier molecules like carbon dioxide are denser than lighter molecules like 
                  hydrogen or helium. This property explains why helium balloons float in air while CO₂ 
                  sinks to the bottom of containers.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Calculation Methods</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Direct Measurement (m/V):</strong> The simplest method involves directly measuring 
                  the mass of a known volume of gas. This approach is often used in laboratory settings where 
                  the gas can be collected and weighed precisely. The formula ρ = m/V gives the density 
                  directly from these measurements.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Ideal Gas Law Method (PM/RT):</strong> When direct measurement isn't practical, 
                  the ideal gas law can be rearranged to calculate density. By knowing the pressure, 
                  temperature, and molar mass of the gas, along with the gas constant R, you can calculate 
                  the theoretical density. This method assumes ideal gas behavior, which is a good 
                  approximation at low pressures and high temperatures.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Gas Density</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gas density calculations are essential in numerous fields. In meteorology, air density 
                  variations drive weather patterns and atmospheric circulation. Aircraft designers must 
                  account for air density changes at different altitudes to calculate lift and engine 
                  performance. Chemical engineers use gas density to design reactors, separators, and 
                  storage systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In the energy sector, natural gas density measurements are critical for pipeline 
                  transportation and billing. HVAC systems rely on air density calculations for proper 
                  ventilation design. Even in everyday life, gas density explains phenomena like why 
                  hot air rises and why certain gases can accumulate in dangerous concentrations in 
                  enclosed spaces.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-purple-200 bg-purple-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-purple-800">
                  <strong>Disclaimer:</strong> Gas density calculations assume ideal behavior. Actual 
                  density may vary due to non-ideal gas effects at high pressures or low temperatures. 
                  For precise applications, consider using more sophisticated equations of state that 
                  account for molecular interactions and compressibility factors.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
