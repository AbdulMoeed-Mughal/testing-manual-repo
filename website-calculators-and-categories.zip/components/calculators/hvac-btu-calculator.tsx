"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Thermometer,
  Info,
  AlertTriangle,
  Snowflake,
  Sun,
  Home,
  Users,
  Laptop,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Climate = "hot" | "mild" | "cold"
type Insulation = "poor" | "average" | "good"

interface BTUResult {
  baseBTU: number
  occupantBTU: number
  deviceBTU: number
  totalBTU: number
  totalKW: number
  acSize: string
  acSizeColor: string
}

const climateFactors: Record<Climate, { factor: number; label: string }> = {
  hot: { factor: 30, label: "Hot Climate (30+ BTU/sq ft)" },
  mild: { factor: 25, label: "Mild Climate (25 BTU/sq ft)" },
  cold: { factor: 35, label: "Cold Climate (35 BTU/sq ft)" },
}

const insulationFactors: Record<Insulation, { factor: number; label: string }> = {
  poor: { factor: 1.3, label: "Poor (old windows, no insulation)" },
  average: { factor: 1.0, label: "Average (standard construction)" },
  good: { factor: 0.8, label: "Good (modern insulation, double-pane)" },
}

export function HVACBTUCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("imperial")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [climate, setClimate] = useState<Climate>("mild")
  const [insulation, setInsulation] = useState<Insulation>("average")
  const [occupants, setOccupants] = useState("2")
  const [devices, setDevices] = useState("1")
  const [result, setResult] = useState<BTUResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateBTU = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const heightNum = Number.parseFloat(height) || (unitSystem === "metric" ? 2.7 : 9)
    const occupantNum = Number.parseInt(occupants) || 0
    const deviceNum = Number.parseInt(devices) || 0

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid room length greater than 0")
      return
    }
    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid room width greater than 0")
      return
    }
    if (occupantNum < 0) {
      setError("Number of occupants cannot be negative")
      return
    }
    if (deviceNum < 0) {
      setError("Number of devices cannot be negative")
      return
    }

    // Convert to square feet if metric
    let areaInSqFt: number
    if (unitSystem === "metric") {
      const areaInSqM = lengthNum * widthNum
      areaInSqFt = areaInSqM * 10.764
    } else {
      areaInSqFt = lengthNum * widthNum
    }

    // Base BTU calculation
    const climateFactor = climateFactors[climate].factor
    const insulationFactor = insulationFactors[insulation].factor
    const baseBTU = areaInSqFt * climateFactor * insulationFactor

    // Additional BTU for occupants (600 BTU per person after first 2)
    const extraOccupants = Math.max(0, occupantNum - 2)
    const occupantBTU = extraOccupants * 600

    // Additional BTU for devices (500 BTU per device)
    const deviceBTU = deviceNum * 500

    // Total BTU
    const totalBTU = Math.round(baseBTU + occupantBTU + deviceBTU)

    // Convert to kW
    const totalKW = totalBTU / 3412

    // Determine AC size category
    let acSize: string
    let acSizeColor: string
    if (totalBTU < 8000) {
      acSize = "Small (5,000-8,000 BTU)"
      acSizeColor = "text-green-600"
    } else if (totalBTU < 14000) {
      acSize = "Medium (8,000-14,000 BTU)"
      acSizeColor = "text-blue-600"
    } else if (totalBTU < 24000) {
      acSize = "Large (14,000-24,000 BTU)"
      acSizeColor = "text-orange-600"
    } else {
      acSize = "Extra Large (24,000+ BTU)"
      acSizeColor = "text-red-600"
    }

    setResult({
      baseBTU: Math.round(baseBTU),
      occupantBTU,
      deviceBTU,
      totalBTU,
      totalKW,
      acSize,
      acSizeColor,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setHeight("")
    setClimate("mild")
    setInsulation("average")
    setOccupants("2")
    setDevices("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `HVAC BTU Requirement: ${result.totalBTU.toLocaleString()} BTU/h (${result.totalKW.toFixed(2)} kW) - ${result.acSize}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "HVAC BTU Calculation",
          text: `I calculated my HVAC requirements using CalcHub! Required: ${result.totalBTU.toLocaleString()} BTU/h (${result.totalKW.toFixed(2)} kW) - ${result.acSize}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setHeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Thermometer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">HVAC BTU Calculator</CardTitle>
                    <CardDescription>Calculate heating/cooling requirements</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Room Dimensions */}
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Home className="h-4 w-4" />
                    Room Dimensions ({unitSystem === "metric" ? "meters" : "feet"})
                  </Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Input
                        type="number"
                        placeholder="Length"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Width"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder={`Height (${unitSystem === "metric" ? "2.7" : "9"})`}
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Height is optional, defaults to standard ceiling height
                  </p>
                </div>

                {/* Climate Selection */}
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Sun className="h-4 w-4" />
                    Climate / Region
                  </Label>
                  <Select value={climate} onValueChange={(v) => setClimate(v as Climate)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hot">Hot Climate (tropical, desert)</SelectItem>
                      <SelectItem value="mild">Mild Climate (temperate)</SelectItem>
                      <SelectItem value="cold">Cold Climate (northern, mountain)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Insulation Quality */}
                <div className="space-y-2">
                  <Label>Insulation Quality</Label>
                  <Select value={insulation} onValueChange={(v) => setInsulation(v as Insulation)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="poor">Poor (old windows, no insulation)</SelectItem>
                      <SelectItem value="average">Average (standard construction)</SelectItem>
                      <SelectItem value="good">Good (modern insulation, double-pane)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Occupants and Devices */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Occupants
                    </Label>
                    <Input
                      type="number"
                      placeholder="2"
                      value={occupants}
                      onChange={(e) => setOccupants(e.target.value)}
                      min="0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <Laptop className="h-4 w-4" />
                      Heat Devices
                    </Label>
                    <Input
                      type="number"
                      placeholder="1"
                      value={devices}
                      onChange={(e) => setDevices(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Heat devices: computers, TVs, appliances that generate heat
                </p>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBTU} className="w-full" size="lg">
                  Calculate BTU Requirement
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Required BTU/h</p>
                      <p className="text-4xl font-bold text-orange-600 mb-1">{result.totalBTU.toLocaleString()}</p>
                      <p className="text-lg text-muted-foreground mb-2">{result.totalKW.toFixed(2)} kW</p>
                      <p className={`text-sm font-semibold ${result.acSizeColor}`}>Recommended: {result.acSize}</p>
                    </div>

                    {/* Toggle Steps */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? "Hide" : "Show"} Calculation Breakdown
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Base BTU (room size):</span>
                          <span className="font-medium">{result.baseBTU.toLocaleString()} BTU</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Occupant adjustment:</span>
                          <span className="font-medium">+{result.occupantBTU.toLocaleString()} BTU</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Device heat load:</span>
                          <span className="font-medium">+{result.deviceBTU.toLocaleString()} BTU</span>
                        </div>
                        <div className="border-t pt-2 flex justify-between font-semibold">
                          <span>Total:</span>
                          <span className="text-orange-600">{result.totalBTU.toLocaleString()} BTU/h</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Snowflake className="h-5 w-5 text-blue-500" />
                    AC Size Guide
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Small Room</span>
                      <span className="text-sm text-green-600">5,000 - 8,000 BTU</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Medium Room</span>
                      <span className="text-sm text-blue-600">8,000 - 14,000 BTU</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Large Room</span>
                      <span className="text-sm text-orange-600">14,000 - 24,000 BTU</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Extra Large</span>
                      <span className="text-sm text-red-600">24,000+ BTU</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BTU Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      BTU = Area × Climate Factor × Insulation Factor
                    </p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>Occupant adjustment:</strong> +600 BTU per person (after first 2)
                    </p>
                    <p>
                      <strong>Device adjustment:</strong> +500 BTU per heat-producing device
                    </p>
                    <p>
                      <strong>Power conversion:</strong> kW = BTU ÷ 3,412
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-orange-200 bg-orange-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-orange-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual HVAC requirements may vary based on building materials, windows,
                        sun exposure, and ventilation. Consult a professional for accurate sizing.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is BTU and Why Does It Matter?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  BTU stands for British Thermal Unit, a traditional unit of heat energy. One BTU is defined as the
                  amount of heat required to raise the temperature of one pound of water by one degree Fahrenheit. In
                  HVAC (Heating, Ventilation, and Air Conditioning), BTU ratings indicate the cooling or heating
                  capacity of equipment.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Choosing the right BTU capacity is crucial for both comfort and energy efficiency. An undersized unit
                  will struggle to maintain temperature, running constantly and increasing energy bills. An oversized
                  unit will cycle on and off too frequently, failing to properly dehumidify the air and creating
                  uncomfortable temperature swings.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting BTU Requirements</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4 mt-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Room Size</h4>
                    <p className="text-sm text-muted-foreground">
                      The primary factor in BTU calculation. Larger rooms require more cooling/heating capacity. Floor
                      area is the main consideration, though ceiling height also matters for rooms taller than standard
                      8-9 feet.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Climate Zone</h4>
                    <p className="text-sm text-muted-foreground">
                      Hot climates require more cooling capacity due to higher outdoor temperatures. Cold climates need
                      more heating power. Mild climates can often use smaller, more efficient units.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Insulation Quality</h4>
                    <p className="text-sm text-muted-foreground">
                      Well-insulated rooms retain conditioned air better, requiring less BTU capacity. Poor insulation,
                      old windows, and air leaks significantly increase requirements.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Heat Sources</h4>
                    <p className="text-sm text-muted-foreground">
                      Occupants, electronics, appliances, and lighting all generate heat. Rooms with multiple computers
                      or appliances need additional cooling capacity.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Home className="h-5 w-5 text-primary" />
                  <CardTitle>BTU Guidelines by Room Type</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 font-semibold">Room Type</th>
                        <th className="text-left py-2 font-semibold">Typical Size</th>
                        <th className="text-left py-2 font-semibold">BTU Range</th>
                      </tr>
                    </thead>
                    <tbody className="text-muted-foreground">
                      <tr className="border-b">
                        <td className="py-2">Small Bedroom</td>
                        <td>100-150 sq ft</td>
                        <td>5,000-6,000 BTU</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Master Bedroom</td>
                        <td>150-250 sq ft</td>
                        <td>6,000-8,000 BTU</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Living Room</td>
                        <td>250-400 sq ft</td>
                        <td>8,000-12,000 BTU</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Open Floor Plan</td>
                        <td>400-650 sq ft</td>
                        <td>12,000-18,000 BTU</td>
                      </tr>
                      <tr>
                        <td className="py-2">Large Space</td>
                        <td>650-1,000 sq ft</td>
                        <td>18,000-24,000 BTU</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Snowflake className="h-5 w-5 text-primary" />
                  <CardTitle>Energy Efficiency Tips</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Right-size your unit:</strong> Avoid the temptation to buy oversized equipment. Properly
                    sized units run longer cycles, providing better humidity control and efficiency.
                  </li>
                  <li>
                    <strong>Check SEER ratings:</strong> Higher Seasonal Energy Efficiency Ratio (SEER) ratings indicate
                    more efficient operation. Look for units with SEER 15 or higher.
                  </li>
                  <li>
                    <strong>Improve insulation:</strong> Sealing air leaks and adding insulation can reduce BTU
                    requirements by 20-30%, allowing for smaller, more efficient equipment.
                  </li>
                  <li>
                    <strong>Use programmable thermostats:</strong> Smart thermostats can reduce energy consumption by
                    automatically adjusting temperature when rooms are unoccupied.
                  </li>
                  <li>
                    <strong>Regular maintenance:</strong> Clean filters and annual professional servicing keep units
                    running at peak efficiency throughout their lifespan.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
