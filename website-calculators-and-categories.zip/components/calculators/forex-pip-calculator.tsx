"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, TrendingUp, Info, AlertTriangle, BarChart3 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"
import { type Currency, formatCurrency } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

// Common forex currency pairs
const forexPairs = [
  { value: "EUR/USD", label: "EUR/USD", pipSize: 0.0001, description: "Euro / US Dollar" },
  { value: "GBP/USD", label: "GBP/USD", pipSize: 0.0001, description: "British Pound / US Dollar" },
  { value: "USD/JPY", label: "USD/JPY", pipSize: 0.01, description: "US Dollar / Japanese Yen" },
  { value: "USD/CHF", label: "USD/CHF", pipSize: 0.0001, description: "US Dollar / Swiss Franc" },
  { value: "AUD/USD", label: "AUD/USD", pipSize: 0.0001, description: "Australian Dollar / US Dollar" },
  { value: "USD/CAD", label: "USD/CAD", pipSize: 0.0001, description: "US Dollar / Canadian Dollar" },
  { value: "NZD/USD", label: "NZD/USD", pipSize: 0.0001, description: "New Zealand Dollar / US Dollar" },
  { value: "EUR/GBP", label: "EUR/GBP", pipSize: 0.0001, description: "Euro / British Pound" },
  { value: "EUR/JPY", label: "EUR/JPY", pipSize: 0.01, description: "Euro / Japanese Yen" },
  { value: "GBP/JPY", label: "GBP/JPY", pipSize: 0.01, description: "British Pound / Japanese Yen" },
  { value: "EUR/CHF", label: "EUR/CHF", pipSize: 0.0001, description: "Euro / Swiss Franc" },
  { value: "AUD/JPY", label: "AUD/JPY", pipSize: 0.01, description: "Australian Dollar / Japanese Yen" },
  { value: "CHF/JPY", label: "CHF/JPY", pipSize: 0.01, description: "Swiss Franc / Japanese Yen" },
  { value: "CAD/JPY", label: "CAD/JPY", pipSize: 0.01, description: "Canadian Dollar / Japanese Yen" },
  { value: "EUR/AUD", label: "EUR/AUD", pipSize: 0.0001, description: "Euro / Australian Dollar" },
  { value: "GBP/AUD", label: "GBP/AUD", pipSize: 0.0001, description: "British Pound / Australian Dollar" },
  { value: "EUR/CAD", label: "EUR/CAD", pipSize: 0.0001, description: "Euro / Canadian Dollar" },
  { value: "GBP/CAD", label: "GBP/CAD", pipSize: 0.0001, description: "British Pound / Canadian Dollar" },
]

const lotSizes = [
  { value: "standard", label: "Standard Lot", units: 100000, description: "100,000 units" },
  { value: "mini", label: "Mini Lot", units: 10000, description: "10,000 units" },
  { value: "micro", label: "Micro Lot", units: 1000, description: "1,000 units" },
  { value: "nano", label: "Nano Lot", units: 100, description: "100 units" },
]

interface PipResult {
  pipValue: number
  pipValuePerMini: number
  pipValuePerMicro: number
  pipSize: number
  lotUnits: number
  quoteCurrency: string
  baseCurrency: string
}

export function ForexPipCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [currencyPair, setCurrencyPair] = useState("EUR/USD")
  const [lotSize, setLotSize] = useState("standard")
  const [customLots, setCustomLots] = useState("1")
  const [exchangeRate, setExchangeRate] = useState("")
  const [result, setResult] = useState<PipResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculatePipValue = () => {
    setError("")
    setResult(null)

    const lots = Number.parseFloat(customLots)
    if (isNaN(lots) || lots <= 0) {
      setError("Please enter a valid number of lots greater than 0")
      return
    }

    const selectedPair = forexPairs.find((p) => p.value === currencyPair)
    if (!selectedPair) {
      setError("Please select a valid currency pair")
      return
    }

    const selectedLot = lotSizes.find((l) => l.value === lotSize)
    if (!selectedLot) {
      setError("Please select a valid lot size")
      return
    }

    const pipSize = selectedPair.pipSize
    const lotUnits = selectedLot.units * lots
    const [baseCurrency, quoteCurrency] = currencyPair.split("/")

    // Calculate pip value
    // For pairs where USD is the quote currency (EUR/USD, GBP/USD, etc.)
    // Pip Value = Pip Size × Lot Size
    // For pairs where USD is the base currency (USD/JPY, USD/CHF, etc.)
    // Pip Value = (Pip Size × Lot Size) / Exchange Rate

    let pipValue: number

    if (quoteCurrency === "USD") {
      // USD is quote currency - pip value is in USD directly
      pipValue = pipSize * lotUnits
    } else {
      // USD is not quote currency - need exchange rate
      let rate = Number.parseFloat(exchangeRate)

      if (isNaN(rate) || rate <= 0) {
        // Use default rates for common pairs
        const defaultRates: Record<string, number> = {
          "USD/JPY": 150.0,
          "USD/CHF": 0.88,
          "USD/CAD": 1.36,
          "EUR/GBP": 0.86,
          "EUR/JPY": 163.0,
          "GBP/JPY": 190.0,
          "EUR/CHF": 0.96,
          "AUD/JPY": 98.0,
          "CHF/JPY": 170.0,
          "CAD/JPY": 110.0,
          "EUR/AUD": 1.66,
          "GBP/AUD": 1.93,
          "EUR/CAD": 1.48,
          "GBP/CAD": 1.72,
        }
        rate = defaultRates[currencyPair] || 1.0
      }

      // Pip value in quote currency, then convert to account currency
      const pipValueInQuote = pipSize * lotUnits

      // For JPY pairs, pip is 0.01, so 1 pip = 0.01 JPY × lot size
      // Convert to USD: pipValueInQuote / rate
      if (quoteCurrency === "JPY") {
        pipValue = pipValueInQuote / rate
      } else if (baseCurrency === "USD") {
        // For USD/XXX pairs: (pip size × lot size) / rate
        pipValue = pipValueInQuote / rate
      } else {
        // For cross pairs (EUR/GBP, etc.), need conversion
        // Simplified: assume direct conversion
        pipValue = pipValueInQuote / rate
      }
    }

    // Calculate for different lot sizes
    const pipValuePerMini = pipValue / (lots * 10) // Mini is 1/10 of standard
    const pipValuePerMicro = pipValue / (lots * 100) // Micro is 1/100 of standard

    setResult({
      pipValue,
      pipValuePerMini,
      pipValuePerMicro,
      pipSize,
      lotUnits,
      quoteCurrency,
      baseCurrency,
    })
  }

  const handleReset = () => {
    setCurrencyPair("EUR/USD")
    setLotSize("standard")
    setCustomLots("1")
    setExchangeRate("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Forex Pip Value: ${formatCurrency(result.pipValue, currency)} per pip for ${customLots} ${lotSize} lot(s) of ${currencyPair}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const selectedPair = forexPairs.find((p) => p.value === currencyPair)
  const needsExchangeRate = selectedPair && !currencyPair.endsWith("/USD")

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Forex Pip Value Calculator</CardTitle>
                    <CardDescription>Calculate the monetary value of pip movements</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <CurrencySelector currency={currency} onChange={setCurrency} label="Account Currency" />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Currency Pair */}
                <div className="space-y-2">
                  <Label>Currency Pair</Label>
                  <Select value={currencyPair} onValueChange={setCurrencyPair}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select currency pair" />
                    </SelectTrigger>
                    <SelectContent>
                      {forexPairs.map((pair) => (
                        <SelectItem key={pair.value} value={pair.value}>
                          <div className="flex items-center justify-between w-full">
                            <span className="font-medium">{pair.label}</span>
                            <span className="text-xs text-muted-foreground ml-2">
                              Pip: {pair.pipSize === 0.01 ? "0.01" : "0.0001"}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Lot Size */}
                <div className="space-y-2">
                  <Label>Lot Type</Label>
                  <Select value={lotSize} onValueChange={setLotSize}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select lot size" />
                    </SelectTrigger>
                    <SelectContent>
                      {lotSizes.map((lot) => (
                        <SelectItem key={lot.value} value={lot.value}>
                          <div className="flex items-center justify-between w-full">
                            <span className="font-medium">{lot.label}</span>
                            <span className="text-xs text-muted-foreground ml-2">{lot.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Number of Lots */}
                <div className="space-y-2">
                  <Label htmlFor="customLots">Number of Lots</Label>
                  <Input
                    id="customLots"
                    type="number"
                    placeholder="Enter number of lots"
                    value={customLots}
                    onChange={(e) => setCustomLots(e.target.value)}
                    min="0.01"
                    step="0.01"
                  />
                </div>

                {/* Exchange Rate (for non-USD quote pairs) */}
                {needsExchangeRate && (
                  <div className="space-y-2">
                    <Label htmlFor="exchangeRate">
                      Exchange Rate ({currencyPair}) <span className="text-muted-foreground">(Optional)</span>
                    </Label>
                    <Input
                      id="exchangeRate"
                      type="number"
                      placeholder="Enter current exchange rate"
                      value={exchangeRate}
                      onChange={(e) => setExchangeRate(e.target.value)}
                      min="0"
                      step="0.0001"
                    />
                    <p className="text-xs text-muted-foreground">Leave empty for estimated default rate</p>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePipValue} className="w-full" size="lg">
                  Calculate Pip Value
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Pip Value</p>
                      <p className="text-4xl font-bold text-green-600 mb-2">
                        {formatCurrency(result.pipValue, currency)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        per pip for {customLots} {lotSizes.find((l) => l.value === lotSize)?.label.toLowerCase()}(s)
                      </p>
                    </div>

                    {/* Lot Size Comparison */}
                    <div className="mt-4 grid grid-cols-3 gap-2">
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Standard</p>
                        <p className="text-sm font-semibold text-green-600">
                          {formatCurrency(result.pipValue * (100000 / result.lotUnits) * Number(customLots), currency)}
                        </p>
                      </div>
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Mini</p>
                        <p className="text-sm font-semibold text-blue-600">
                          {formatCurrency(result.pipValue * (10000 / result.lotUnits) * Number(customLots), currency)}
                        </p>
                      </div>
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Micro</p>
                        <p className="text-sm font-semibold text-purple-600">
                          {formatCurrency(result.pipValue * (1000 / result.lotUnits) * Number(customLots), currency)}
                        </p>
                      </div>
                    </div>

                    {/* Collapsible Details */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          <ChevronDown
                            className={`h-4 w-4 mr-2 transition-transform ${showDetails ? "rotate-180" : ""}`}
                          />
                          {showDetails ? "Hide" : "Show"} Details
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2">
                        <div className="bg-white p-3 rounded-lg space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Currency Pair:</span>
                            <span className="font-medium">{currencyPair}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Pip Size:</span>
                            <span className="font-medium">{result.pipSize}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Position Size:</span>
                            <span className="font-medium">{result.lotUnits.toLocaleString()} units</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Base Currency:</span>
                            <span className="font-medium">{result.baseCurrency}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Quote Currency:</span>
                            <span className="font-medium">{result.quoteCurrency}</span>
                          </div>
                        </div>

                        {/* Pip Movement Table */}
                        <div className="bg-white p-3 rounded-lg">
                          <p className="text-sm font-medium mb-2">Potential Profit/Loss by Pips</p>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            {[10, 25, 50, 100].map((pips) => (
                              <div key={pips} className="flex justify-between p-2 bg-muted/50 rounded">
                                <span>{pips} pips</span>
                                <span className="font-medium text-green-600">
                                  {formatCurrency(result.pipValue * pips, currency)}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Lot Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Standard Lot</span>
                      <span className="text-sm text-green-600">100,000 units</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Mini Lot</span>
                      <span className="text-sm text-blue-600">10,000 units</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Micro Lot</span>
                      <span className="text-sm text-purple-600">1,000 units</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <span className="font-medium text-gray-700">Nano Lot</span>
                      <span className="text-sm text-gray-600">100 units</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pip Value Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      Pip Value = (Pip Size × Lot Size) ÷ Exchange Rate
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>For USD quote pairs:</strong> Pip size is typically 0.0001 (or 0.01 for JPY pairs)
                    </p>
                    <p>
                      <strong>Standard lot:</strong> 1 pip = $10 for EUR/USD
                    </p>
                    <p>
                      <strong>Mini lot:</strong> 1 pip = $1 for EUR/USD
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Pip in Forex Trading?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A pip (Percentage in Point or Price Interest Point) is the smallest standardized price movement in
                  forex trading. For most currency pairs, a pip equals 0.0001 (the fourth decimal place). However, for
                  Japanese Yen pairs, a pip equals 0.01 (the second decimal place). Understanding pip values is crucial
                  for calculating potential profits, losses, and managing risk in forex trading.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The monetary value of a pip depends on three factors: the currency pair being traded, the size of the
                  trade (lot size), and the exchange rate. For pairs where USD is the quote currency (like EUR/USD), the
                  pip value calculation is straightforward. For other pairs, you need to convert the pip value to your
                  account currency using the current exchange rate.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use Pip Values for Risk Management</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Knowing your pip value helps you calculate position sizes that align with your risk tolerance. For
                  example, if you want to risk $100 on a trade with a 50-pip stop loss, you need a pip value of $2. This
                  means trading 0.2 standard lots (20,000 units) of EUR/USD. By calculating pip values before entering
                  trades, you can maintain consistent risk management across different currency pairs.
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-semibold text-blue-800 text-sm">Position Sizing</p>
                    <p className="text-blue-700 text-xs mt-1">
                      Risk Amount ÷ (Stop Loss Pips × Pip Value) = Position Size
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-semibold text-green-800 text-sm">Risk Percentage</p>
                    <p className="text-green-700 text-xs mt-1">Never risk more than 1-2% of account per trade</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Forex pip value calculations are estimates based on entered values and current exchange rates. Actual
                  pip values may vary due to market conditions, broker rules, spreads, and trade execution. Forex
                  trading involves significant risk of loss and is not suitable for all investors. Past performance is
                  not indicative of future results. Consult a qualified financial advisor before making trading
                  decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
