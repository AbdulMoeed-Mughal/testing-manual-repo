"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Ruler, Info, Activity, AlertTriangle, Heart } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"

interface WHRResult {
  value: number
  category: string
  color: string
  bgColor: string
  description: string
}

export function WaistToHipRatioCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender | null>(null)
  const [waist, setWaist] = useState("")
  const [hip, setHip] = useState("")
  const [result, setResult] = useState<WHRResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateWHR = () => {
    setError("")
    setResult(null)

    if (!gender) {
      setError("Please select your gender")
      return
    }

    const waistNum = Number.parseFloat(waist)
    const hipNum = Number.parseFloat(hip)

    if (isNaN(waistNum) || waistNum <= 0) {
      setError("Please enter a valid waist circumference greater than 0")
      return
    }

    if (isNaN(hipNum) || hipNum <= 0) {
      setError("Please enter a valid hip circumference greater than 0")
      return
    }

    if (hipNum === 0) {
      setError("Hip circumference cannot be zero")
      return
    }

    // Calculate WHR (same units, so no conversion needed)
    const whr = waistNum / hipNum
    const roundedWHR = Math.round(whr * 100) / 100

    let category: string
    let color: string
    let bgColor: string
    let description: string

    if (gender === "male") {
      if (roundedWHR < 0.9) {
        category = "Low Risk"
        color = "text-green-600"
        bgColor = "bg-green-50 border-green-200"
        description = "Your waist-to-hip ratio indicates a lower risk of weight-related health problems."
      } else if (roundedWHR < 1.0) {
        category = "Moderate Risk"
        color = "text-yellow-600"
        bgColor = "bg-yellow-50 border-yellow-200"
        description = "Your ratio indicates moderate health risk. Consider lifestyle modifications."
      } else {
        category = "High Risk"
        color = "text-red-600"
        bgColor = "bg-red-50 border-red-200"
        description = "Your ratio indicates higher risk for cardiovascular disease and other conditions."
      }
    } else {
      if (roundedWHR < 0.8) {
        category = "Low Risk"
        color = "text-green-600"
        bgColor = "bg-green-50 border-green-200"
        description = "Your waist-to-hip ratio indicates a lower risk of weight-related health problems."
      } else if (roundedWHR < 0.9) {
        category = "Moderate Risk"
        color = "text-yellow-600"
        bgColor = "bg-yellow-50 border-yellow-200"
        description = "Your ratio indicates moderate health risk. Consider lifestyle modifications."
      } else {
        category = "High Risk"
        color = "text-red-600"
        bgColor = "bg-red-50 border-red-200"
        description = "Your ratio indicates higher risk for cardiovascular disease and other conditions."
      }
    }

    setResult({ value: roundedWHR, category, color, bgColor, description })
  }

  const handleReset = () => {
    setWaist("")
    setHip("")
    setGender(null)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`My Waist-to-Hip Ratio is ${result.value} (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My WHR Result",
          text: `I calculated my Waist-to-Hip Ratio using CalcHub! My WHR is ${result.value} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWaist("")
    setHip("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Ruler className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Waist-to-Hip Ratio</CardTitle>
                    <CardDescription>Assess health risk from body fat distribution</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      className="w-full"
                      onClick={() => setGender("male")}
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      className="w-full"
                      onClick={() => setGender("female")}
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Waist Input */}
                <div className="space-y-2">
                  <Label htmlFor="waist">Waist Circumference ({unitSystem === "metric" ? "cm" : "inches"})</Label>
                  <Input
                    id="waist"
                    type="number"
                    placeholder={`Enter waist in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                    value={waist}
                    onChange={(e) => setWaist(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Measure around the narrowest part of your waist</p>
                </div>

                {/* Hip Input */}
                <div className="space-y-2">
                  <Label htmlFor="hip">Hip Circumference ({unitSystem === "metric" ? "cm" : "inches"})</Label>
                  <Input
                    id="hip"
                    type="number"
                    placeholder={`Enter hip in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                    value={hip}
                    onChange={(e) => setHip(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Measure around the widest part of your hips</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWHR} className="w-full" size="lg">
                  Calculate WHR
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Waist-to-Hip Ratio</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.value}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-sm text-muted-foreground mt-2">{result.description}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">WHR Risk Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2 text-sm">For Men</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                          <span className="font-medium text-green-700 text-sm">Low Risk</span>
                          <span className="text-xs text-green-600">{"< 0.90"}</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-yellow-50 border border-yellow-200">
                          <span className="font-medium text-yellow-700 text-sm">Moderate Risk</span>
                          <span className="text-xs text-yellow-600">0.90 – 0.99</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                          <span className="font-medium text-red-700 text-sm">High Risk</span>
                          <span className="text-xs text-red-600">≥ 1.00</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2 text-sm">For Women</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                          <span className="font-medium text-green-700 text-sm">Low Risk</span>
                          <span className="text-xs text-green-600">{"< 0.80"}</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-yellow-50 border border-yellow-200">
                          <span className="font-medium text-yellow-700 text-sm">Moderate Risk</span>
                          <span className="text-xs text-yellow-600">0.80 – 0.89</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                          <span className="font-medium text-red-700 text-sm">High Risk</span>
                          <span className="text-xs text-red-600">≥ 0.90</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">WHR Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">WHR = Waist ÷ Hip</p>
                  </div>
                  <p>
                    Simply divide your waist circumference by your hip circumference using the same unit of measurement
                    for both.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How to Measure</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Waist:</strong> Measure at the narrowest point, usually just above the belly button.
                  </p>
                  <p>
                    <strong>Hip:</strong> Measure at the widest point of your buttocks.
                  </p>
                  <p className="text-xs italic">Stand relaxed and keep the tape parallel to the floor.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is WHR */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Waist-to-Hip Ratio (WHR)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The waist-to-hip ratio (WHR) is a simple yet powerful measurement that compares the circumference of
                  your waist to that of your hips. Unlike BMI, which only considers overall weight relative to height,
                  WHR provides valuable insights into where your body stores fat. This distinction is crucial because
                  the location of body fat significantly impacts your health risks, often more so than the total amount
                  of fat you carry.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Medical researchers and healthcare professionals have used WHR for decades as a screening tool to
                  identify individuals who may be at increased risk for cardiovascular disease, type 2 diabetes, and
                  other metabolic conditions. The World Health Organization recognizes WHR as an important indicator of
                  abdominal obesity, which is considered more dangerous than fat stored in other areas of the body such
                  as the hips and thighs.
                </p>
              </CardContent>
            </Card>

            {/* Why Body Fat Distribution Matters */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Why Body Fat Distribution Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Not all body fat is created equal when it comes to health implications. Fat stored around the abdomen,
                  known as visceral fat or central obesity, is metabolically active and releases inflammatory substances
                  and hormones that can negatively affect your cardiovascular system, insulin sensitivity, and overall
                  metabolic health. This type of fat surrounds vital organs like the liver, pancreas, and intestines,
                  creating a direct pathway for harmful substances to enter your bloodstream.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In contrast, fat stored in the hips and thighs, called subcutaneous fat, is largely inert and does not
                  pose the same health risks. This explains why two individuals with identical BMIs can have vastly
                  different health profiles—the person with more abdominal fat faces significantly higher risks for
                  heart disease, stroke, and diabetes than someone who carries their weight predominantly in their lower
                  body.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Apple-Shaped Body</h4>
                    <p className="text-red-700 text-sm">
                      Higher WHR indicates central obesity with fat concentrated around the midsection. Associated with
                      increased health risks including heart disease and metabolic syndrome.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Pear-Shaped Body</h4>
                    <p className="text-green-700 text-sm">
                      Lower WHR indicates fat distribution mainly in hips and thighs. Generally associated with lower
                      cardiovascular and metabolic health risks compared to apple-shaped bodies.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Health Risks Associated with High WHR */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Health Risks Associated with High WHR</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Research consistently shows that individuals with higher waist-to-hip ratios face elevated risks for
                  numerous health conditions. Cardiovascular disease tops the list, with studies demonstrating that
                  central obesity is a stronger predictor of heart attacks and strokes than overall obesity measured by
                  BMI alone. The visceral fat that contributes to a high WHR promotes inflammation, increases blood
                  pressure, and adversely affects cholesterol levels.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Type 2 diabetes risk also increases substantially with higher WHR values. Abdominal fat impairs
                  insulin sensitivity, making it harder for your body to regulate blood sugar levels effectively. Other
                  conditions linked to elevated WHR include certain cancers (particularly breast and colorectal),
                  gallbladder disease, sleep apnea, and cognitive decline in older adults. Understanding your WHR can
                  serve as motivation to adopt healthier lifestyle habits before these conditions develop.
                </p>
              </CardContent>
            </Card>

            {/* Tips for Improving WHR */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Improving Your Waist-to-Hip Ratio</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Improving your WHR requires targeting abdominal fat through a combination of dietary changes, physical
                  activity, and lifestyle modifications. Focus on reducing refined carbohydrates and added sugars, which
                  contribute significantly to visceral fat accumulation. Instead, emphasize whole grains, lean proteins,
                  healthy fats from sources like olive oil and nuts, and plenty of vegetables and fruits.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Cardiovascular exercise is particularly effective at reducing abdominal fat. Activities like brisk
                  walking, running, cycling, and swimming, performed for at least 150 minutes per week, can make
                  significant improvements. Strength training also helps by building muscle mass, which increases your
                  metabolic rate and helps burn more calories throughout the day. Additionally, managing stress through
                  meditation, adequate sleep, and relaxation techniques is important, as chronic stress elevates
                  cortisol levels, which promotes fat storage around the midsection.
                </p>
                <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-amber-800 text-sm">
                    <strong>Disclaimer:</strong> Waist-to-hip ratio is a screening tool and does not replace
                    professional medical evaluation. If you have concerns about your health or risk factors, please
                    consult with a healthcare provider for personalized guidance.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
