"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  AlertTriangle,
  Calculator,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type InputMode = "vertex-focus" | "vertex-directrix" | "standard"
type Orientation = "vertical" | "horizontal"

interface ParabolaResult {
  vertex: { h: number; k: number }
  focus: { x: number; y: number }
  directrix: string
  axisOfSymmetry: string
  p: number
  a: number
  orientation: Orientation
  openingDirection: string
  vertexForm: string
  standardForm: string
  focalLength: number
  latusRectum: number
}

export function ParabolaCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("vertex-focus")
  const [orientation, setOrientation] = useState<Orientation>("vertical")

  // Vertex-Focus inputs
  const [vertexH, setVertexH] = useState("")
  const [vertexK, setVertexK] = useState("")
  const [focusX, setFocusX] = useState("")
  const [focusY, setFocusY] = useState("")

  // Vertex-Directrix inputs
  const [directrixValue, setDirectrixValue] = useState("")

  // Standard form inputs (y = ax² + bx + c or x = ay² + by + c)
  const [coeffA, setCoeffA] = useState("")
  const [coeffB, setCoeffB] = useState("")
  const [coeffC, setCoeffC] = useState("")

  const [result, setResult] = useState<ParabolaResult | null>(null)
  const [steps, setSteps] = useState<string[]>([])
  const [showSteps, setShowSteps] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateParabola = () => {
    setError("")
    setResult(null)
    setSteps([])

    const calculationSteps: string[] = []

    try {
      if (inputMode === "vertex-focus") {
        const h = Number.parseFloat(vertexH)
        const k = Number.parseFloat(vertexK)
        const fx = Number.parseFloat(focusX)
        const fy = Number.parseFloat(focusY)

        if (isNaN(h) || isNaN(k) || isNaN(fx) || isNaN(fy)) {
          setError("Please enter valid numeric values for vertex and focus")
          return
        }

        calculationSteps.push(`Given: Vertex (h, k) = (${h}, ${k}), Focus = (${fx}, ${fy})`)

        // Determine orientation based on vertex and focus
        let detectedOrientation: Orientation
        let p: number

        if (Math.abs(fx - h) < 0.0001) {
          // Vertical parabola (focus is directly above/below vertex)
          detectedOrientation = "vertical"
          p = fy - k
          calculationSteps.push(`Focus is vertically aligned with vertex → Vertical parabola`)
          calculationSteps.push(`p = focus_y - vertex_k = ${fy} - ${k} = ${p}`)
        } else if (Math.abs(fy - k) < 0.0001) {
          // Horizontal parabola (focus is directly left/right of vertex)
          detectedOrientation = "horizontal"
          p = fx - h
          calculationSteps.push(`Focus is horizontally aligned with vertex → Horizontal parabola`)
          calculationSteps.push(`p = focus_x - vertex_h = ${fx} - ${h} = ${p}`)
        } else {
          setError("Focus must be aligned vertically or horizontally with vertex")
          return
        }

        if (p === 0) {
          setError("Focus cannot be at the same position as vertex")
          return
        }

        const a = 1 / (4 * p)
        calculationSteps.push(`a = 1/(4p) = 1/(4 × ${p}) = ${a.toFixed(6)}`)

        const openingDirection =
          detectedOrientation === "vertical" ? (p > 0 ? "Upward" : "Downward") : p > 0 ? "Right" : "Left"
        calculationSteps.push(`Since p ${p > 0 ? ">" : "<"} 0, parabola opens ${openingDirection.toLowerCase()}`)

        let directrix: string
        let axisOfSymmetry: string
        let vertexForm: string
        let standardForm: string

        if (detectedOrientation === "vertical") {
          directrix = `y = ${(k - p).toFixed(4)}`
          axisOfSymmetry = `x = ${h}`
          vertexForm = `y = ${a.toFixed(6)}(x - ${h})² + ${k}`

          // Convert to standard form: y = ax² + bx + c
          const stdA = a
          const stdB = -2 * a * h
          const stdC = a * h * h + k
          standardForm = `y = ${stdA.toFixed(6)}x² ${stdB >= 0 ? "+" : ""} ${stdB.toFixed(6)}x ${stdC >= 0 ? "+" : ""} ${stdC.toFixed(6)}`

          calculationSteps.push(`Directrix: y = k - p = ${k} - ${p} = ${k - p}`)
          calculationSteps.push(`Axis of symmetry: x = h = ${h}`)
        } else {
          directrix = `x = ${(h - p).toFixed(4)}`
          axisOfSymmetry = `y = ${k}`
          vertexForm = `x = ${a.toFixed(6)}(y - ${k})² + ${h}`

          // Convert to standard form: x = ay² + by + c
          const stdA = a
          const stdB = -2 * a * k
          const stdC = a * k * k + h
          standardForm = `x = ${stdA.toFixed(6)}y² ${stdB >= 0 ? "+" : ""} ${stdB.toFixed(6)}y ${stdC >= 0 ? "+" : ""} ${stdC.toFixed(6)}`

          calculationSteps.push(`Directrix: x = h - p = ${h} - ${p} = ${h - p}`)
          calculationSteps.push(`Axis of symmetry: y = k = ${k}`)
        }

        calculationSteps.push(`Vertex form: ${vertexForm}`)
        calculationSteps.push(`Standard form: ${standardForm}`)
        calculationSteps.push(`Focal length |p| = ${Math.abs(p)}`)
        calculationSteps.push(`Latus rectum = 4|p| = ${4 * Math.abs(p)}`)

        setResult({
          vertex: { h, k },
          focus: { x: fx, y: fy },
          directrix,
          axisOfSymmetry,
          p,
          a,
          orientation: detectedOrientation,
          openingDirection,
          vertexForm,
          standardForm,
          focalLength: Math.abs(p),
          latusRectum: 4 * Math.abs(p),
        })
      } else if (inputMode === "vertex-directrix") {
        const h = Number.parseFloat(vertexH)
        const k = Number.parseFloat(vertexK)
        const d = Number.parseFloat(directrixValue)

        if (isNaN(h) || isNaN(k) || isNaN(d)) {
          setError("Please enter valid numeric values")
          return
        }

        calculationSteps.push(`Given: Vertex (h, k) = (${h}, ${k})`)
        calculationSteps.push(`Directrix: ${orientation === "vertical" ? `y = ${d}` : `x = ${d}`}`)

        let p: number
        let focus: { x: number; y: number }
        let directrix: string
        let axisOfSymmetry: string

        if (orientation === "vertical") {
          p = k - d
          if (p === 0) {
            setError("Directrix cannot pass through the vertex")
            return
          }
          focus = { x: h, y: k + p }
          directrix = `y = ${d}`
          axisOfSymmetry = `x = ${h}`
          calculationSteps.push(`p = vertex_k - directrix = ${k} - ${d} = ${p}`)
          calculationSteps.push(`Focus = (h, k + p) = (${h}, ${k + p})`)
        } else {
          p = h - d
          if (p === 0) {
            setError("Directrix cannot pass through the vertex")
            return
          }
          focus = { x: h + p, y: k }
          directrix = `x = ${d}`
          axisOfSymmetry = `y = ${k}`
          calculationSteps.push(`p = vertex_h - directrix = ${h} - ${d} = ${p}`)
          calculationSteps.push(`Focus = (h + p, k) = (${h + p}, ${k})`)
        }

        const a = 1 / (4 * p)
        calculationSteps.push(`a = 1/(4p) = 1/(4 × ${p}) = ${a.toFixed(6)}`)

        const openingDirection = orientation === "vertical" ? (p > 0 ? "Upward" : "Downward") : p > 0 ? "Right" : "Left"

        let vertexForm: string
        let standardForm: string

        if (orientation === "vertical") {
          vertexForm = `y = ${a.toFixed(6)}(x - ${h})² + ${k}`
          const stdA = a
          const stdB = -2 * a * h
          const stdC = a * h * h + k
          standardForm = `y = ${stdA.toFixed(6)}x² ${stdB >= 0 ? "+" : ""} ${stdB.toFixed(6)}x ${stdC >= 0 ? "+" : ""} ${stdC.toFixed(6)}`
        } else {
          vertexForm = `x = ${a.toFixed(6)}(y - ${k})² + ${h}`
          const stdA = a
          const stdB = -2 * a * k
          const stdC = a * k * k + h
          standardForm = `x = ${stdA.toFixed(6)}y² ${stdB >= 0 ? "+" : ""} ${stdB.toFixed(6)}y ${stdC >= 0 ? "+" : ""} ${stdC.toFixed(6)}`
        }

        calculationSteps.push(`Vertex form: ${vertexForm}`)
        calculationSteps.push(`Standard form: ${standardForm}`)

        setResult({
          vertex: { h, k },
          focus,
          directrix,
          axisOfSymmetry,
          p,
          a,
          orientation,
          openingDirection,
          vertexForm,
          standardForm,
          focalLength: Math.abs(p),
          latusRectum: 4 * Math.abs(p),
        })
      } else {
        // Standard form input
        const a = Number.parseFloat(coeffA)
        const b = Number.parseFloat(coeffB)
        const c = Number.parseFloat(coeffC)

        if (isNaN(a) || isNaN(b) || isNaN(c)) {
          setError("Please enter valid numeric coefficients")
          return
        }

        if (a === 0) {
          setError("Coefficient 'a' cannot be zero for a parabola")
          return
        }

        calculationSteps.push(
          `Given: ${orientation === "vertical" ? `y = ${a}x² + ${b}x + ${c}` : `x = ${a}y² + ${b}y + ${c}`}`,
        )
        calculationSteps.push(`Converting to vertex form using completing the square...`)

        // Convert to vertex form
        // For y = ax² + bx + c: h = -b/(2a), k = c - b²/(4a)
        // For x = ay² + by + c: k = -b/(2a), h = c - b²/(4a)

        let h: number, k: number

        if (orientation === "vertical") {
          h = -b / (2 * a)
          k = c - (b * b) / (4 * a)
          calculationSteps.push(`h = -b/(2a) = -${b}/(2×${a}) = ${h.toFixed(6)}`)
          calculationSteps.push(`k = c - b²/(4a) = ${c} - ${b}²/(4×${a}) = ${k.toFixed(6)}`)
        } else {
          k = -b / (2 * a)
          h = c - (b * b) / (4 * a)
          calculationSteps.push(`k = -b/(2a) = -${b}/(2×${a}) = ${k.toFixed(6)}`)
          calculationSteps.push(`h = c - b²/(4a) = ${c} - ${b}²/(4×${a}) = ${h.toFixed(6)}`)
        }

        calculationSteps.push(`Vertex (h, k) = (${h.toFixed(6)}, ${k.toFixed(6)})`)

        // Calculate p from a: a = 1/(4p) → p = 1/(4a)
        const p = 1 / (4 * a)
        calculationSteps.push(`p = 1/(4a) = 1/(4×${a}) = ${p.toFixed(6)}`)

        let focus: { x: number; y: number }
        let directrix: string
        let axisOfSymmetry: string

        if (orientation === "vertical") {
          focus = { x: h, y: k + p }
          directrix = `y = ${(k - p).toFixed(6)}`
          axisOfSymmetry = `x = ${h.toFixed(6)}`
          calculationSteps.push(`Focus = (h, k + p) = (${h.toFixed(6)}, ${(k + p).toFixed(6)})`)
          calculationSteps.push(`Directrix: y = k - p = ${(k - p).toFixed(6)}`)
        } else {
          focus = { x: h + p, y: k }
          directrix = `x = ${(h - p).toFixed(6)}`
          axisOfSymmetry = `y = ${k.toFixed(6)}`
          calculationSteps.push(`Focus = (h + p, k) = (${(h + p).toFixed(6)}, ${k.toFixed(6)})`)
          calculationSteps.push(`Directrix: x = h - p = ${(h - p).toFixed(6)}`)
        }

        const openingDirection = orientation === "vertical" ? (a > 0 ? "Upward" : "Downward") : a > 0 ? "Right" : "Left"
        calculationSteps.push(`Since a ${a > 0 ? ">" : "<"} 0, parabola opens ${openingDirection.toLowerCase()}`)

        const vertexForm =
          orientation === "vertical"
            ? `y = ${a}(x - ${h.toFixed(6)})² + ${k.toFixed(6)}`
            : `x = ${a}(y - ${k.toFixed(6)})² + ${h.toFixed(6)}`

        const standardForm = orientation === "vertical" ? `y = ${a}x² + ${b}x + ${c}` : `x = ${a}y² + ${b}y + ${c}`

        setResult({
          vertex: { h, k },
          focus,
          directrix,
          axisOfSymmetry,
          p,
          a,
          orientation,
          openingDirection,
          vertexForm,
          standardForm,
          focalLength: Math.abs(p),
          latusRectum: 4 * Math.abs(p),
        })
      }

      setSteps(calculationSteps)
    } catch {
      setError("An error occurred during calculation")
    }
  }

  const handleReset = () => {
    setVertexH("")
    setVertexK("")
    setFocusX("")
    setFocusY("")
    setDirectrixValue("")
    setCoeffA("")
    setCoeffB("")
    setCoeffC("")
    setResult(null)
    setSteps([])
    setError("")
    setCopied(false)
  }

  const formatNumber = (num: number): string => {
    return Number.isInteger(num) ? num.toString() : num.toFixed(6).replace(/\.?0+$/, "")
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Parabola Calculator Result:
Vertex: (${formatNumber(result.vertex.h)}, ${formatNumber(result.vertex.k)})
Focus: (${formatNumber(result.focus.x)}, ${formatNumber(result.focus.y)})
Directrix: ${result.directrix}
Axis of Symmetry: ${result.axisOfSymmetry}
Opening Direction: ${result.openingDirection}
Vertex Form: ${result.vertexForm}
Standard Form: ${result.standardForm}
Focal Length: ${formatNumber(result.focalLength)}
Latus Rectum: ${formatNumber(result.latusRectum)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Parabola Calculator Result",
          text: `Parabola: ${result.vertexForm}\nVertex: (${formatNumber(result.vertex.h)}, ${formatNumber(result.vertex.k)})\nFocus: (${formatNumber(result.focus.x)}, ${formatNumber(result.focus.y)})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Parabola Calculator</CardTitle>
                    <CardDescription>Find equation, vertex, focus, and directrix</CardDescription>
                  </div>
                </div>

                {/* Input Mode Selection */}
                <div className="space-y-3 pt-2">
                  <div>
                    <Label className="text-sm font-medium">Input Method</Label>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <button
                        onClick={() => {
                          setInputMode("vertex-focus")
                          handleReset()
                        }}
                        className={`px-3 py-2 text-xs font-medium rounded-lg transition-colors ${
                          inputMode === "vertex-focus"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        Vertex + Focus
                      </button>
                      <button
                        onClick={() => {
                          setInputMode("vertex-directrix")
                          handleReset()
                        }}
                        className={`px-3 py-2 text-xs font-medium rounded-lg transition-colors ${
                          inputMode === "vertex-directrix"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        Vertex + Directrix
                      </button>
                      <button
                        onClick={() => {
                          setInputMode("standard")
                          handleReset()
                        }}
                        className={`px-3 py-2 text-xs font-medium rounded-lg transition-colors ${
                          inputMode === "standard" ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        Standard Form
                      </button>
                    </div>
                  </div>

                  {/* Orientation Toggle for certain modes */}
                  {(inputMode === "vertex-directrix" || inputMode === "standard") && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Orientation</span>
                      <button
                        onClick={() => setOrientation((prev) => (prev === "vertical" ? "horizontal" : "vertical"))}
                        className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                      >
                        <span
                          className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                            orientation === "horizontal" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                          }`}
                        />
                        <span
                          className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                            orientation === "vertical" ? "text-primary-foreground" : "text-muted-foreground"
                          }`}
                        >
                          Vertical
                        </span>
                        <span
                          className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                            orientation === "horizontal" ? "text-primary-foreground" : "text-muted-foreground"
                          }`}
                        >
                          Horizontal
                        </span>
                      </button>
                    </div>
                  )}
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Vertex Inputs (for vertex-focus and vertex-directrix modes) */}
                {(inputMode === "vertex-focus" || inputMode === "vertex-directrix") && (
                  <div className="space-y-2">
                    <Label>Vertex (h, k)</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="h"
                          value={vertexH}
                          onChange={(e) => setVertexH(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="k"
                          value={vertexK}
                          onChange={(e) => setVertexK(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Focus Inputs (for vertex-focus mode) */}
                {inputMode === "vertex-focus" && (
                  <div className="space-y-2">
                    <Label>Focus (x, y)</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="x"
                          value={focusX}
                          onChange={(e) => setFocusX(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="y"
                          value={focusY}
                          onChange={(e) => setFocusY(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Directrix Input (for vertex-directrix mode) */}
                {inputMode === "vertex-directrix" && (
                  <div className="space-y-2">
                    <Label>Directrix ({orientation === "vertical" ? "y" : "x"} = ?)</Label>
                    <Input
                      type="number"
                      placeholder={`Enter ${orientation === "vertical" ? "y" : "x"} value`}
                      value={directrixValue}
                      onChange={(e) => setDirectrixValue(e.target.value)}
                      step="any"
                    />
                  </div>
                )}

                {/* Standard Form Coefficients */}
                {inputMode === "standard" && (
                  <div className="space-y-2">
                    <Label>{orientation === "vertical" ? "y = ax² + bx + c" : "x = ay² + by + c"}</Label>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="a"
                          value={coeffA}
                          onChange={(e) => setCoeffA(e.target.value)}
                          step="any"
                        />
                        <span className="text-xs text-muted-foreground mt-1 block text-center">a ≠ 0</span>
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="b"
                          value={coeffB}
                          onChange={(e) => setCoeffB(e.target.value)}
                          step="any"
                        />
                        <span className="text-xs text-muted-foreground mt-1 block text-center">b</span>
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="c"
                          value={coeffC}
                          onChange={(e) => setCoeffC(e.target.value)}
                          step="any"
                        />
                        <span className="text-xs text-muted-foreground mt-1 block text-center">c</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateParabola} className="w-full" size="lg">
                  Calculate Parabola
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Parabola Equation (Vertex Form)</p>
                      <p className="text-lg font-bold text-blue-600 font-mono break-all">{result.vertexForm}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Vertex</p>
                        <p className="font-semibold">
                          ({formatNumber(result.vertex.h)}, {formatNumber(result.vertex.k)})
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Focus</p>
                        <p className="font-semibold">
                          ({formatNumber(result.focus.x)}, {formatNumber(result.focus.y)})
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Directrix</p>
                        <p className="font-semibold">{result.directrix}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Axis of Symmetry</p>
                        <p className="font-semibold">{result.axisOfSymmetry}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Opening Direction</p>
                        <p className="font-semibold">{result.openingDirection}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Focal Length (|p|)</p>
                        <p className="font-semibold">{formatNumber(result.focalLength)}</p>
                      </div>
                      <div className="col-span-2 p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Standard Form</p>
                        <p className="font-semibold font-mono text-sm break-all">{result.standardForm}</p>
                      </div>
                      <div className="col-span-2 p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Latus Rectum Length</p>
                        <p className="font-semibold">{formatNumber(result.latusRectum)}</p>
                      </div>
                    </div>

                    {/* Step-by-step toggle */}
                    {steps.length > 0 && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowSteps(!showSteps)}
                          className="flex items-center gap-2 text-sm font-medium text-blue-600 hover:text-blue-700"
                        >
                          {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          {showSteps ? "Hide Steps" : "Show Steps"}
                        </button>
                        {showSteps && (
                          <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-1">
                            {steps.map((step, index) => (
                              <p key={index} className="text-muted-foreground">
                                <span className="font-medium text-foreground">{index + 1}.</span> {step}
                              </p>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Parabola Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-sm mb-2">Vertical Parabola</p>
                    <p className="font-mono text-sm">Vertex form: y = a(x − h)² + k</p>
                    <p className="font-mono text-sm">Focus: (h, k + 1/(4a))</p>
                    <p className="font-mono text-sm">Directrix: y = k − 1/(4a)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-sm mb-2">Horizontal Parabola</p>
                    <p className="font-mono text-sm">Vertex form: x = a(y − k)² + h</p>
                    <p className="font-mono text-sm">Focus: (h + 1/(4a), k)</p>
                    <p className="font-mono text-sm">Directrix: x = h − 1/(4a)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Properties</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="text-muted-foreground">p (focal distance)</span>
                      <span className="font-mono">1/(4a)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="text-muted-foreground">Latus rectum</span>
                      <span className="font-mono">4|p|</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="text-muted-foreground">Opens up</span>
                      <span className="font-mono">a {`>`} 0</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="text-muted-foreground">Opens down</span>
                      <span className="font-mono">a {`<`} 0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Vertex + Focus:</strong> Enter vertex coordinates and focus point. Focus must be aligned
                    with vertex.
                  </p>
                  <p>
                    <strong>Vertex + Directrix:</strong> Enter vertex and the directrix line value.
                  </p>
                  <p>
                    <strong>Standard Form:</strong> Enter coefficients a, b, c for the equation.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Parabola?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A parabola is a U-shaped curve that is the graph of a quadratic function. It is defined as the set of
                  all points that are equidistant from a fixed point called the focus and a fixed line called the
                  directrix. Parabolas have many important applications in physics, engineering, and architecture, from
                  satellite dishes to the paths of projectiles.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The vertex of a parabola is the point where it changes direction, and it represents either the minimum
                  or maximum value of the quadratic function depending on whether the parabola opens upward or downward.
                  The axis of symmetry passes through the vertex and divides the parabola into two mirror-image halves.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Parabola calculations follow standard mathematical formulas. Results depend on correct input values
                  and orientation. This calculator provides approximate decimal representations where exact values may
                  involve irrational numbers.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
