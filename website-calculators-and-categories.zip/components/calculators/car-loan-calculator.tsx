"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Car,
  Info,
  DollarSign,
  Percent,
  Calendar,
  ChevronDown,
  ChevronUp,
  TrendingDown,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type PaymentFrequency = "monthly" | "biweekly" | "weekly"

interface LoanResult {
  payment: number
  totalPayment: number
  totalInterest: number
  loanAmount: number
  effectiveRate: number
  paymentCount: number
  savingsWithExtra?: {
    totalInterest: number
    totalPayment: number
    paymentCount: number
    interestSaved: number
    timeSaved: number
  }
}

interface AmortizationEntry {
  period: number
  payment: number
  principal: number
  interest: number
  extraPayment: number
  balance: number
}

export function CarLoanCalculator() {
  const [vehiclePrice, setVehiclePrice] = useState("")
  const [downPayment, setDownPayment] = useState("")
  const [tradeInValue, setTradeInValue] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [loanTermYears, setLoanTermYears] = useState("")
  const [loanTermMonths, setLoanTermMonths] = useState("")
  const [termType, setTermType] = useState<"years" | "months">("years")
  const [paymentFrequency, setPaymentFrequency] = useState<PaymentFrequency>("monthly")
  const [extraPayment, setExtraPayment] = useState("")
  const [result, setResult] = useState<LoanResult | null>(null)
  const [amortization, setAmortization] = useState<AmortizationEntry[]>([])
  const [showAmortization, setShowAmortization] = useState(false)
  const [showBreakdown, setShowBreakdown] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateLoan = () => {
    setError("")
    setResult(null)
    setAmortization([])

    const price = Number.parseFloat(vehiclePrice)
    const down = Number.parseFloat(downPayment) || 0
    const tradeIn = Number.parseFloat(tradeInValue) || 0
    const rate = Number.parseFloat(interestRate)
    const termYears = Number.parseFloat(loanTermYears) || 0
    const termMonths = Number.parseFloat(loanTermMonths) || 0
    const extra = Number.parseFloat(extraPayment) || 0

    if (isNaN(price) || price <= 0) {
      setError("Please enter a valid vehicle price greater than 0")
      return
    }

    if (isNaN(rate) || rate < 0) {
      setError("Please enter a valid interest rate (0 or greater)")
      return
    }

    let totalMonths: number
    if (termType === "years") {
      if (termYears <= 0) {
        setError("Please enter a valid loan term greater than 0")
        return
      }
      totalMonths = termYears * 12
    } else {
      if (termMonths <= 0) {
        setError("Please enter a valid loan term in months greater than 0")
        return
      }
      totalMonths = termMonths
    }

    const loanAmount = price - down - tradeIn
    if (loanAmount <= 0) {
      setError("Down payment and trade-in value exceed the vehicle price")
      return
    }

    // Calculate payments based on frequency
    let periodsPerYear: number
    let totalPeriods: number

    switch (paymentFrequency) {
      case "biweekly":
        periodsPerYear = 26
        totalPeriods = Math.round((totalMonths / 12) * 26)
        break
      case "weekly":
        periodsPerYear = 52
        totalPeriods = Math.round((totalMonths / 12) * 52)
        break
      default:
        periodsPerYear = 12
        totalPeriods = totalMonths
    }

    const periodicRate = rate / 100 / periodsPerYear
    let payment: number

    if (rate === 0) {
      payment = loanAmount / totalPeriods
    } else {
      payment =
        (loanAmount * periodicRate * Math.pow(1 + periodicRate, totalPeriods)) /
        (Math.pow(1 + periodicRate, totalPeriods) - 1)
    }

    const totalPayment = payment * totalPeriods
    const totalInterest = totalPayment - loanAmount

    // Calculate amortization schedule
    const schedule: AmortizationEntry[] = []
    let balance = loanAmount
    let actualPeriods = 0

    for (let i = 1; i <= totalPeriods && balance > 0; i++) {
      const interestPayment = balance * periodicRate
      let principalPayment = payment - interestPayment
      let extraPmt = 0

      if (extra > 0 && balance - principalPayment > 0) {
        extraPmt = Math.min(extra, balance - principalPayment)
        principalPayment += extraPmt
      }

      if (principalPayment > balance) {
        principalPayment = balance
      }

      balance = Math.max(0, balance - principalPayment)
      actualPeriods = i

      schedule.push({
        period: i,
        payment: payment + extraPmt,
        principal: principalPayment,
        interest: interestPayment,
        extraPayment: extraPmt,
        balance: balance,
      })

      if (balance <= 0) break
    }

    setAmortization(schedule)

    // Calculate savings with extra payments
    let savingsWithExtra
    if (extra > 0) {
      const totalWithExtra = schedule.reduce((sum, entry) => sum + entry.payment, 0)
      const interestWithExtra = schedule.reduce((sum, entry) => sum + entry.interest, 0)

      savingsWithExtra = {
        totalInterest: interestWithExtra,
        totalPayment: totalWithExtra,
        paymentCount: actualPeriods,
        interestSaved: totalInterest - interestWithExtra,
        timeSaved: totalPeriods - actualPeriods,
      }
    }

    setResult({
      payment: Math.round(payment * 100) / 100,
      totalPayment: Math.round(totalPayment * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
      loanAmount: Math.round(loanAmount * 100) / 100,
      effectiveRate: rate,
      paymentCount: totalPeriods,
      savingsWithExtra,
    })
  }

  const handleReset = () => {
    setVehiclePrice("")
    setDownPayment("")
    setTradeInValue("")
    setInterestRate("")
    setLoanTermYears("")
    setLoanTermMonths("")
    setExtraPayment("")
    setResult(null)
    setAmortization([])
    setShowAmortization(false)
    setShowBreakdown(false)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const frequencyLabel =
        paymentFrequency === "monthly" ? "Monthly" : paymentFrequency === "biweekly" ? "Bi-weekly" : "Weekly"
      await navigator.clipboard.writeText(
        `Car Loan: $${result.loanAmount.toLocaleString()} at ${result.effectiveRate}% for ${result.paymentCount} ${paymentFrequency} payments\n` +
          `${frequencyLabel} Payment: $${result.payment.toLocaleString()}\n` +
          `Total Interest: $${result.totalInterest.toLocaleString()}\n` +
          `Total Payment: $${result.totalPayment.toLocaleString()}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Car Loan Calculation",
          text: `I calculated my car loan using CalcHub! ${paymentFrequency === "monthly" ? "Monthly" : paymentFrequency === "biweekly" ? "Bi-weekly" : "Weekly"} payment: $${result.payment.toLocaleString()}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getFrequencyLabel = () => {
    switch (paymentFrequency) {
      case "biweekly":
        return "Bi-weekly"
      case "weekly":
        return "Weekly"
      default:
        return "Monthly"
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/lifestyle-daily">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Lifestyle & Daily Use
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Car className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Car Loan Calculator</CardTitle>
                    <CardDescription>Calculate your auto loan payments</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Vehicle Price */}
                <div className="space-y-2">
                  <Label htmlFor="vehiclePrice">Vehicle Price ($)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="vehiclePrice"
                      type="number"
                      placeholder="25000"
                      value={vehiclePrice}
                      onChange={(e) => setVehiclePrice(e.target.value)}
                      className="pl-9"
                      min="0"
                      step="100"
                    />
                  </div>
                </div>

                {/* Down Payment & Trade-in */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="downPayment">Down Payment ($)</Label>
                    <Input
                      id="downPayment"
                      type="number"
                      placeholder="5000"
                      value={downPayment}
                      onChange={(e) => setDownPayment(e.target.value)}
                      min="0"
                      step="100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tradeInValue">Trade-in Value ($)</Label>
                    <Input
                      id="tradeInValue"
                      type="number"
                      placeholder="0"
                      value={tradeInValue}
                      onChange={(e) => setTradeInValue(e.target.value)}
                      min="0"
                      step="100"
                    />
                  </div>
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <div className="relative">
                    <Percent className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="interestRate"
                      type="number"
                      placeholder="6.5"
                      value={interestRate}
                      onChange={(e) => setInterestRate(e.target.value)}
                      className="pl-9"
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Loan Term */}
                <div className="space-y-2">
                  <Label>Loan Term</Label>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <Input
                        type="number"
                        placeholder={termType === "years" ? "5" : "60"}
                        value={termType === "years" ? loanTermYears : loanTermMonths}
                        onChange={(e) =>
                          termType === "years" ? setLoanTermYears(e.target.value) : setLoanTermMonths(e.target.value)
                        }
                        min="1"
                        step="1"
                      />
                    </div>
                    <div className="flex rounded-lg bg-muted p-1">
                      <button
                        onClick={() => setTermType("years")}
                        className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                          termType === "years" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"
                        }`}
                      >
                        Years
                      </button>
                      <button
                        onClick={() => setTermType("months")}
                        className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                          termType === "months" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"
                        }`}
                      >
                        Months
                      </button>
                    </div>
                  </div>
                </div>

                {/* Payment Frequency */}
                <div className="space-y-2">
                  <Label>Payment Frequency</Label>
                  <div className="flex rounded-lg bg-muted p-1">
                    {(["monthly", "biweekly", "weekly"] as PaymentFrequency[]).map((freq) => (
                      <button
                        key={freq}
                        onClick={() => setPaymentFrequency(freq)}
                        className={`flex-1 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                          paymentFrequency === freq
                            ? "bg-background text-foreground shadow-sm"
                            : "text-muted-foreground"
                        }`}
                      >
                        {freq === "monthly" ? "Monthly" : freq === "biweekly" ? "Bi-weekly" : "Weekly"}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Extra Payment (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="extraPayment">Extra Payment per Period (Optional)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="extraPayment"
                      type="number"
                      placeholder="0"
                      value={extraPayment}
                      onChange={(e) => setExtraPayment(e.target.value)}
                      className="pl-9"
                      min="0"
                      step="10"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Add extra payments to pay off your loan faster</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLoan} className="w-full" size="lg">
                  Calculate Loan
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">{getFrequencyLabel()} Payment</p>
                      <p className="text-4xl font-bold text-green-600">{formatCurrency(result.payment)}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-center">
                      <div className="p-3 bg-background rounded-lg">
                        <p className="text-xs text-muted-foreground">Loan Amount</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.loanAmount)}</p>
                      </div>
                      <div className="p-3 bg-background rounded-lg">
                        <p className="text-xs text-muted-foreground">Total Interest</p>
                        <p className="font-semibold text-red-600">{formatCurrency(result.totalInterest)}</p>
                      </div>
                      <div className="p-3 bg-background rounded-lg col-span-2">
                        <p className="text-xs text-muted-foreground">Total Payment</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.totalPayment)}</p>
                      </div>
                    </div>

                    {/* Savings with Extra Payments */}
                    {result.savingsWithExtra && (
                      <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <TrendingDown className="h-4 w-4 text-blue-600" />
                          <span className="font-medium text-blue-700">With Extra Payments</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <p className="text-muted-foreground">Interest Saved</p>
                            <p className="font-semibold text-blue-600">
                              {formatCurrency(result.savingsWithExtra.interestSaved)}
                            </p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Time Saved</p>
                            <p className="font-semibold text-blue-600">{result.savingsWithExtra.timeSaved} payments</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>

                    {/* Calculation Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-between">
                          <span>Calculation Breakdown</span>
                          {showBreakdown ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2 p-3 bg-background rounded-lg text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Vehicle Price:</span>
                          <span>{formatCurrency(Number.parseFloat(vehiclePrice) || 0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Down Payment:</span>
                          <span>- {formatCurrency(Number.parseFloat(downPayment) || 0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Trade-in Value:</span>
                          <span>- {formatCurrency(Number.parseFloat(tradeInValue) || 0)}</span>
                        </div>
                        <div className="flex justify-between font-medium border-t pt-2">
                          <span>Loan Amount:</span>
                          <span>{formatCurrency(result.loanAmount)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Interest Rate:</span>
                          <span>{result.effectiveRate}% APR</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Number of Payments:</span>
                          <span>{result.paymentCount}</span>
                        </div>
                        <div className="pt-2 border-t">
                          <p className="text-xs text-muted-foreground">
                            Formula: M = P × (r × (1+r)^n) ÷ ((1+r)^n − 1)
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Where P = Principal, r = periodic rate, n = total payments
                          </p>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </div>
                )}

                {/* Amortization Schedule */}
                {amortization.length > 0 && (
                  <Collapsible open={showAmortization} onOpenChange={setShowAmortization}>
                    <CollapsibleTrigger asChild>
                      <Button variant="outline" size="sm" className="w-full justify-between bg-transparent">
                        <span>Amortization Schedule</span>
                        {showAmortization ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-2">
                      <div className="max-h-64 overflow-y-auto rounded-lg border">
                        <table className="w-full text-xs">
                          <thead className="bg-muted sticky top-0">
                            <tr>
                              <th className="p-2 text-left">#</th>
                              <th className="p-2 text-right">Payment</th>
                              <th className="p-2 text-right">Principal</th>
                              <th className="p-2 text-right">Interest</th>
                              <th className="p-2 text-right">Balance</th>
                            </tr>
                          </thead>
                          <tbody>
                            {amortization.map((entry) => (
                              <tr key={entry.period} className="border-t">
                                <td className="p-2">{entry.period}</td>
                                <td className="p-2 text-right">{formatCurrency(entry.payment)}</td>
                                <td className="p-2 text-right text-green-600">{formatCurrency(entry.principal)}</td>
                                <td className="p-2 text-right text-red-600">{formatCurrency(entry.interest)}</td>
                                <td className="p-2 text-right">{formatCurrency(entry.balance)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Car Loan Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent Credit (750+)</span>
                      <span className="text-sm text-green-600">3.5% - 5.5%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good Credit (700-749)</span>
                      <span className="text-sm text-blue-600">5.5% - 7.5%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Fair Credit (650-699)</span>
                      <span className="text-sm text-yellow-600">7.5% - 11%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Poor Credit (below 650)</span>
                      <span className="text-sm text-red-600">11% - 20%+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Loan Terms</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>36 months (3 years)</span>
                      <span className="text-muted-foreground">Lower interest, higher payment</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>48 months (4 years)</span>
                      <span className="text-muted-foreground">Balanced option</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>60 months (5 years)</span>
                      <span className="text-muted-foreground">Most common term</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>72 months (6 years)</span>
                      <span className="text-muted-foreground">Lower payment, more interest</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tips for Better Rates</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Improve your credit score before applying</p>
                  <p>• Make a larger down payment (20% recommended)</p>
                  <p>• Shop around and compare multiple lenders</p>
                  <p>• Consider shorter loan terms for less interest</p>
                  <p>• Get pre-approved before visiting dealerships</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Car Loans</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A car loan, also known as an auto loan, is a type of secured loan where the vehicle itself serves as
                  collateral. When you finance a car purchase, you borrow money from a lender and agree to repay it over
                  a specified period with interest. The loan amount is typically the difference between the vehicle
                  price and any down payment or trade-in value you provide. Understanding the components of your car
                  loan helps you make informed decisions and potentially save thousands of dollars over the life of the
                  loan.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The monthly payment is calculated using an amortization formula that factors in the principal (loan
                  amount), interest rate, and loan term. Early in the loan, a larger portion of each payment goes toward
                  interest, while later payments apply more to the principal. This is why making extra payments early
                  can significantly reduce the total interest paid and shorten the loan term.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Payment Frequency Options</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Choosing a different payment frequency can affect both your cash flow and total interest paid. Monthly
                  payments are the standard option, but bi-weekly and weekly payments can help you pay off your loan
                  faster. With bi-weekly payments, you make 26 half-payments per year (equivalent to 13 monthly
                  payments), effectively making one extra monthly payment annually. This accelerates your loan payoff
                  and reduces total interest.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Weekly payments work similarly, with 52 weekly payments equating to slightly more than 12 monthly
                  payments per year. Both alternatives can be beneficial if your income is received on a similar
                  schedule, making budgeting easier while building equity in your vehicle faster.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>The Power of Extra Payments</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Making extra payments toward your car loan principal can save you significant money and help you
                  become debt-free sooner. When you pay extra, the additional amount goes directly toward reducing your
                  principal balance, which means less interest accrues on future payments. Even small extra payments of
                  $25-$50 per month can shave months off your loan term and save hundreds in interest.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Before making extra payments, verify with your lender that there are no prepayment penalties and that
                  extra payments are applied to the principal rather than being held for future scheduled payments. Some
                  lenders require you to specify that extra funds should reduce the principal balance.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Results are estimates. Actual loan amounts, interest, and payments may
                  vary depending on lender policies, fees, taxes, and other factors not included in this calculator.
                  Always consult with your lender for exact loan terms and conditions before making financial decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
