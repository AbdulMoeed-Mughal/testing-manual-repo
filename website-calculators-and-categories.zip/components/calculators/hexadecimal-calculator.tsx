"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Binary,
  Info,
  AlertTriangle,
  Calculator,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type Operation =
  | "add"
  | "subtract"
  | "multiply"
  | "divide"
  | "modulo"
  | "power"
  | "and"
  | "or"
  | "xor"
  | "not"
  | "leftShift"
  | "rightShift"
type BitWidth = 8 | 16 | 32 | 64
type InputMode = "hex" | "decimal"

interface HexResult {
  hex: string
  decimal: string
  binary: string
  octal: string
  overflow: boolean
  underflow: boolean
}

interface Step {
  description: string
  value?: string
}

export function HexadecimalCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("hex")
  const [valueA, setValueA] = useState("")
  const [valueB, setValueB] = useState("")
  const [operation, setOperation] = useState<Operation>("add")
  const [bitWidth, setBitWidth] = useState<BitWidth>(32)
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<HexResult | null>(null)
  const [steps, setSteps] = useState<Step[]>([])
  const [copiedField, setCopiedField] = useState<string | null>(null)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(true)

  const operations = [
    { value: "add", label: "Addition (+)", symbol: "+" },
    { value: "subtract", label: "Subtraction (−)", symbol: "−" },
    { value: "multiply", label: "Multiplication (×)", symbol: "×" },
    { value: "divide", label: "Division (÷)", symbol: "÷" },
    { value: "modulo", label: "Modulo (%)", symbol: "%" },
    { value: "power", label: "Exponentiation (^)", symbol: "^" },
    { value: "and", label: "Bitwise AND (&)", symbol: "&" },
    { value: "or", label: "Bitwise OR (|)", symbol: "|" },
    { value: "xor", label: "Bitwise XOR (⊕)", symbol: "⊕" },
    { value: "not", label: "Bitwise NOT (~)", symbol: "~" },
    { value: "leftShift", label: "Left Shift (<<)", symbol: "<<" },
    { value: "rightShift", label: "Right Shift (>>)", symbol: ">>" },
  ]

  const isUnaryOperation = operation === "not"
  const isShiftOperation = operation === "leftShift" || operation === "rightShift"

  const parseInput = (value: string, mode: InputMode): bigint | null => {
    if (!value.trim()) return null

    try {
      if (mode === "hex") {
        const cleanHex = value.replace(/^0x/i, "").toUpperCase()
        if (!/^[0-9A-F]+$/.test(cleanHex)) return null
        return BigInt("0x" + cleanHex)
      } else {
        if (!/^-?\d+$/.test(value.trim())) return null
        return BigInt(value.trim())
      }
    } catch {
      return null
    }
  }

  const applyBitWidth = (value: bigint, width: BitWidth): { result: bigint; overflow: boolean; underflow: boolean } => {
    const maxValue = (BigInt(1) << BigInt(width)) - BigInt(1)
    let overflow = false
    let underflow = false

    if (value > maxValue) {
      overflow = true
      value = value & maxValue
    } else if (value < BigInt(0)) {
      underflow = true
      // Two's complement for negative numbers
      value = (maxValue + BigInt(1) + (value % (maxValue + BigInt(1)))) & maxValue
    }

    return { result: value, overflow, underflow }
  }

  const toBinary = (value: bigint, width: BitWidth): string => {
    if (value < BigInt(0)) {
      const maxValue = (BigInt(1) << BigInt(width)) - BigInt(1)
      value = (maxValue + BigInt(1) + value) & maxValue
    }
    return value.toString(2).padStart(width, "0")
  }

  const calculate = () => {
    setError("")
    setResult(null)
    setSteps([])

    const numA = parseInput(valueA, inputMode)
    if (numA === null) {
      setError(`Please enter a valid ${inputMode === "hex" ? "hexadecimal" : "decimal"} number for the first value`)
      return
    }

    let numB: bigint | null = null
    if (!isUnaryOperation) {
      numB = parseInput(valueB, inputMode)
      if (numB === null) {
        setError(`Please enter a valid ${inputMode === "hex" ? "hexadecimal" : "decimal"} number for the second value`)
        return
      }

      if ((operation === "divide" || operation === "modulo") && numB === BigInt(0)) {
        setError("Division by zero is not allowed")
        return
      }
    }

    const calculationSteps: Step[] = []
    let resultValue: bigint

    // Convert inputs to hex for display
    const hexA = numA.toString(16).toUpperCase()
    const hexB = numB !== null ? numB.toString(16).toUpperCase() : ""

    calculationSteps.push({
      description: `Input A: 0x${hexA} (decimal: ${numA.toString()})`,
    })

    if (!isUnaryOperation && numB !== null) {
      calculationSteps.push({
        description: `Input B: 0x${hexB} (decimal: ${numB.toString()})`,
      })
    }

    const opSymbol = operations.find((op) => op.value === operation)?.symbol || ""

    switch (operation) {
      case "add":
        resultValue = numA + numB!
        calculationSteps.push({
          description: `Addition: 0x${hexA} + 0x${hexB}`,
          value: `${numA} + ${numB} = ${resultValue}`,
        })
        break
      case "subtract":
        resultValue = numA - numB!
        calculationSteps.push({
          description: `Subtraction: 0x${hexA} − 0x${hexB}`,
          value: `${numA} − ${numB} = ${resultValue}`,
        })
        break
      case "multiply":
        resultValue = numA * numB!
        calculationSteps.push({
          description: `Multiplication: 0x${hexA} × 0x${hexB}`,
          value: `${numA} × ${numB} = ${resultValue}`,
        })
        break
      case "divide":
        resultValue = numA / numB!
        calculationSteps.push({
          description: `Division: 0x${hexA} ÷ 0x${hexB}`,
          value: `${numA} ÷ ${numB} = ${resultValue} (integer division)`,
        })
        break
      case "modulo":
        resultValue = numA % numB!
        calculationSteps.push({
          description: `Modulo: 0x${hexA} % 0x${hexB}`,
          value: `${numA} % ${numB} = ${resultValue}`,
        })
        break
      case "power":
        if (numB! > BigInt(1000)) {
          setError("Exponent too large (max 1000)")
          return
        }
        resultValue = numA ** numB!
        calculationSteps.push({
          description: `Exponentiation: 0x${hexA} ^ 0x${hexB}`,
          value: `${numA} ^ ${numB} = ${resultValue}`,
        })
        break
      case "and":
        resultValue = numA & numB!
        calculationSteps.push({
          description: `Bitwise AND: 0x${hexA} & 0x${hexB}`,
          value: `Binary: ${toBinary(numA, bitWidth)} & ${toBinary(numB!, bitWidth)}`,
        })
        break
      case "or":
        resultValue = numA | numB!
        calculationSteps.push({
          description: `Bitwise OR: 0x${hexA} | 0x${hexB}`,
          value: `Binary: ${toBinary(numA, bitWidth)} | ${toBinary(numB!, bitWidth)}`,
        })
        break
      case "xor":
        resultValue = numA ^ numB!
        calculationSteps.push({
          description: `Bitwise XOR: 0x${hexA} ⊕ 0x${hexB}`,
          value: `Binary: ${toBinary(numA, bitWidth)} ⊕ ${toBinary(numB!, bitWidth)}`,
        })
        break
      case "not":
        const maxValue = (BigInt(1) << BigInt(bitWidth)) - BigInt(1)
        resultValue = ~numA & maxValue
        calculationSteps.push({
          description: `Bitwise NOT: ~0x${hexA}`,
          value: `Binary: ~${toBinary(numA, bitWidth)} = ${toBinary(resultValue, bitWidth)}`,
        })
        break
      case "leftShift":
        const shiftLeftAmount = Number(numB!)
        if (shiftLeftAmount < 0 || shiftLeftAmount > bitWidth) {
          setError(`Shift amount must be between 0 and ${bitWidth}`)
          return
        }
        resultValue = numA << numB!
        calculationSteps.push({
          description: `Left Shift: 0x${hexA} << ${numB}`,
          value: `Binary: ${toBinary(numA, bitWidth)} << ${numB}`,
        })
        break
      case "rightShift":
        const shiftRightAmount = Number(numB!)
        if (shiftRightAmount < 0 || shiftRightAmount > bitWidth) {
          setError(`Shift amount must be between 0 and ${bitWidth}`)
          return
        }
        resultValue = numA >> numB!
        calculationSteps.push({
          description: `Right Shift: 0x${hexA} >> ${numB}`,
          value: `Binary: ${toBinary(numA, bitWidth)} >> ${numB}`,
        })
        break
      default:
        resultValue = BigInt(0)
    }

    // Apply bit width constraints
    const { result: constrainedResult, overflow, underflow } = applyBitWidth(resultValue, bitWidth)

    if (overflow) {
      calculationSteps.push({
        description: `⚠️ Overflow detected! Result truncated to ${bitWidth} bits.`,
      })
    }
    if (underflow) {
      calculationSteps.push({
        description: `⚠️ Underflow detected! Result wrapped using two's complement.`,
      })
    }

    const hexResult = constrainedResult.toString(16).toUpperCase()
    calculationSteps.push({
      description: `Final Result: 0x${hexResult}`,
      value: `Decimal: ${constrainedResult.toString()}`,
    })

    setSteps(calculationSteps)
    setResult({
      hex: hexResult,
      decimal: constrainedResult.toString(),
      binary: toBinary(constrainedResult, bitWidth),
      octal: constrainedResult.toString(8),
      overflow,
      underflow,
    })
  }

  const handleReset = () => {
    setValueA("")
    setValueB("")
    setOperation("add")
    setResult(null)
    setSteps([])
    setError("")
    setCopiedField(null)
  }

  const handleCopy = async (text: string, field: string) => {
    await navigator.clipboard.writeText(text)
    setCopiedField(field)
    setTimeout(() => setCopiedField(null), 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Binary className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Hexadecimal Calculator</CardTitle>
                    <CardDescription>Perform hex arithmetic and bitwise operations</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={() => setInputMode(inputMode === "hex" ? "decimal" : "hex")}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "decimal" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "hex" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Hex
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "decimal" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Decimal
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Value A Input */}
                <div className="space-y-2">
                  <Label htmlFor="valueA">
                    {isUnaryOperation ? "Value" : "Value A"}{" "}
                    {inputMode === "hex" && <span className="text-muted-foreground">(e.g., 0xFF, 1A3)</span>}
                  </Label>
                  <Input
                    id="valueA"
                    type="text"
                    placeholder={inputMode === "hex" ? "Enter hexadecimal (e.g., 0xFF)" : "Enter decimal number"}
                    value={valueA}
                    onChange={(e) => setValueA(e.target.value)}
                    className="font-mono"
                  />
                </div>

                {/* Operation Select */}
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <Select value={operation} onValueChange={(v) => setOperation(v as Operation)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="add">Addition (+)</SelectItem>
                      <SelectItem value="subtract">Subtraction (−)</SelectItem>
                      <SelectItem value="multiply">Multiplication (×)</SelectItem>
                      <SelectItem value="divide">Division (÷)</SelectItem>
                      <SelectItem value="modulo">Modulo (%)</SelectItem>
                      <SelectItem value="power">Exponentiation (^)</SelectItem>
                      <SelectItem value="and">Bitwise AND (&)</SelectItem>
                      <SelectItem value="or">Bitwise OR (|)</SelectItem>
                      <SelectItem value="xor">Bitwise XOR (⊕)</SelectItem>
                      <SelectItem value="not">Bitwise NOT (~)</SelectItem>
                      <SelectItem value="leftShift">Left Shift ({"<<"})</SelectItem>
                      <SelectItem value="rightShift">Right Shift ({">>"})</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Value B Input */}
                {!isUnaryOperation && (
                  <div className="space-y-2">
                    <Label htmlFor="valueB">
                      {isShiftOperation ? "Shift Amount" : "Value B"}{" "}
                      {inputMode === "hex" && !isShiftOperation && (
                        <span className="text-muted-foreground">(e.g., 0xFF, 1A3)</span>
                      )}
                    </Label>
                    <Input
                      id="valueB"
                      type="text"
                      placeholder={
                        isShiftOperation
                          ? "Enter shift amount"
                          : inputMode === "hex"
                            ? "Enter hexadecimal (e.g., 0xFF)"
                            : "Enter decimal number"
                      }
                      value={valueB}
                      onChange={(e) => setValueB(e.target.value)}
                      className="font-mono"
                    />
                  </div>
                )}

                {/* Bit Width */}
                <div className="space-y-2">
                  <Label>Bit Width</Label>
                  <Select value={bitWidth.toString()} onValueChange={(v) => setBitWidth(Number(v) as BitWidth)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="8">8-bit (0 to 255)</SelectItem>
                      <SelectItem value="16">16-bit (0 to 65,535)</SelectItem>
                      <SelectItem value="32">32-bit (0 to 4,294,967,295)</SelectItem>
                      <SelectItem value="64">64-bit (0 to 18,446,744,073,709,551,615)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps" className="cursor-pointer">
                    Show step-by-step solution
                  </Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${result.overflow || result.underflow ? "bg-yellow-50 border-yellow-200" : "bg-blue-50 border-blue-200"} transition-all duration-300`}
                  >
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Hexadecimal Result</p>
                      <p className="text-4xl font-bold text-blue-600 font-mono">0x{result.hex}</p>
                      {(result.overflow || result.underflow) && (
                        <p className="text-sm text-yellow-600 mt-1">
                          {result.overflow ? "⚠️ Overflow occurred" : "⚠️ Underflow occurred"}
                        </p>
                      )}
                    </div>

                    {/* Multi-format Results */}
                    <div className="grid grid-cols-1 gap-2 text-sm">
                      <div className="flex items-center justify-between p-2 bg-white/50 rounded-lg">
                        <span className="text-muted-foreground">Decimal:</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-medium">{result.decimal}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => handleCopy(result.decimal, "decimal")}
                          >
                            {copiedField === "decimal" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-white/50 rounded-lg">
                        <span className="text-muted-foreground">Binary:</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-medium text-xs break-all">{result.binary}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => handleCopy(result.binary, "binary")}
                          >
                            {copiedField === "binary" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-white/50 rounded-lg">
                        <span className="text-muted-foreground">Octal:</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-medium">0o{result.octal}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => handleCopy("0o" + result.octal, "octal")}
                          >
                            {copiedField === "octal" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-white/50 rounded-lg">
                        <span className="text-muted-foreground">Hex:</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-medium">0x{result.hex}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => handleCopy("0x" + result.hex, "hex")}
                          >
                            {copiedField === "hex" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-step Solution */}
                {showSteps && steps.length > 0 && (
                  <Collapsible open={stepsOpen} onOpenChange={setStepsOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="outline" className="w-full justify-between bg-transparent">
                        Step-by-Step Solution
                        {stepsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-2">
                      <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                        {steps.map((step, index) => (
                          <div key={index} className="flex gap-3">
                            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                              {index + 1}
                            </span>
                            <div>
                              <p className="text-sm font-medium">{step.description}</p>
                              {step.value && <p className="text-xs text-muted-foreground font-mono">{step.value}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bitwise Operations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">AND (&)</span>
                      <p className="text-blue-600 text-xs mt-1">1 & 1 = 1, all others = 0</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">OR (|)</span>
                      <p className="text-green-600 text-xs mt-1">0 | 0 = 0, all others = 1</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">XOR (⊕)</span>
                      <p className="text-purple-600 text-xs mt-1">Same bits = 0, different = 1</p>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">NOT (~)</span>
                      <p className="text-orange-600 text-xs mt-1">Flips all bits: 0→1, 1→0</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm font-mono">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>0xFF</span>
                      <span className="text-muted-foreground">= 255</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>0x100</span>
                      <span className="text-muted-foreground">= 256</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>0xFFFF</span>
                      <span className="text-muted-foreground">= 65,535</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>0xFFFFFFFF</span>
                      <span className="text-muted-foreground">= 4,294,967,295</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    <strong>Hex Mode:</strong> Enter hexadecimal values with or without the 0x prefix. Valid characters:
                    0-9, A-F.
                  </p>
                  <p>
                    <strong>Decimal Mode:</strong> Enter standard decimal integers. Negative numbers use two's
                    complement representation.
                  </p>
                  <div className="p-3 bg-muted rounded-lg font-mono text-xs">
                    <p>Examples: 0xFF, FF, 1A3, 0x1234ABCD</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Hexadecimal?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Hexadecimal (base-16) is a positional numeral system that uses sixteen distinct symbols: 0-9 for
                  values zero to nine, and A-F for values ten to fifteen. It is widely used in computing and digital
                  electronics because it provides a human-friendly representation of binary-coded values. Each
                  hexadecimal digit represents exactly four binary bits (a nibble), making conversion between hex and
                  binary straightforward.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Hexadecimal is commonly used for memory addresses, color codes in web design (e.g., #FF5733), MAC
                  addresses, and representing byte values in assembly language and low-level programming. Understanding
                  hex arithmetic and bitwise operations is essential for systems programming, embedded development, and
                  computer security.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator supports both arithmetic operations (addition, subtraction, multiplication, division,
                  modulo, exponentiation) and bitwise operations (AND, OR, XOR, NOT, left shift, right shift). You can
                  input values in either hexadecimal or decimal format using the toggle switch.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The bit width setting determines the maximum value and how overflow/underflow is handled. For example,
                  8-bit mode limits values to 0-255, while 32-bit mode allows values up to 4,294,967,295. Negative
                  results are represented using two's complement notation within the selected bit width.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    <p className="font-medium text-foreground mb-1">Disclaimer</p>
                    <p>
                      Hexadecimal calculations are based on standard arithmetic and bitwise rules. Results may be
                      limited by selected bit-width and signed/unsigned settings. This calculator is intended for
                      educational and reference purposes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
