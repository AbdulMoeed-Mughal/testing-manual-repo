"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, Flame } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type HeatUnit = "J" | "cal" | "BTU"
type MassUnit = "kg" | "g" | "lb"
type TempUnit = "C" | "K"
type OutputUnit = "J/kg·K" | "J/g·°C" | "cal/g·°C" | "BTU/lb·°F"

interface SpecificHeatResult {
  specificHeat: number
  category: string
  color: string
  bgColor: string
  materialMatch: string
}

const commonMaterials = [
  { name: "Water", value: 4186, unit: "J/kg·K" },
  { name: "Ice", value: 2090, unit: "J/kg·K" },
  { name: "Steam", value: 2010, unit: "J/kg·K" },
  { name: "Aluminum", value: 897, unit: "J/kg·K" },
  { name: "Copper", value: 385, unit: "J/kg·K" },
  { name: "Iron", value: 449, unit: "J/kg·K" },
  { name: "Gold", value: 129, unit: "J/kg·K" },
  { name: "Silver", value: 235, unit: "J/kg·K" },
  { name: "Glass", value: 840, unit: "J/kg·K" },
  { name: "Wood", value: 1700, unit: "J/kg·K" },
  { name: "Concrete", value: 880, unit: "J/kg·K" },
  { name: "Air", value: 1005, unit: "J/kg·K" },
]

export function SpecificHeatCapacityCalculator() {
  const [heat, setHeat] = useState("")
  const [mass, setMass] = useState("")
  const [tempChange, setTempChange] = useState("")
  const [heatUnit, setHeatUnit] = useState<HeatUnit>("J")
  const [massUnit, setMassUnit] = useState<MassUnit>("kg")
  const [tempUnit, setTempUnit] = useState<TempUnit>("C")
  const [outputUnit, setOutputUnit] = useState<OutputUnit>("J/kg·K")
  const [result, setResult] = useState<SpecificHeatResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const convertHeatToJoules = (value: number, unit: HeatUnit): number => {
    switch (unit) {
      case "cal":
        return value * 4.184
      case "BTU":
        return value * 1055.06
      default:
        return value
    }
  }

  const convertMassToKg = (value: number, unit: MassUnit): number => {
    switch (unit) {
      case "g":
        return value / 1000
      case "lb":
        return value * 0.453592
      default:
        return value
    }
  }

  const convertOutputUnit = (valueJperKgK: number, unit: OutputUnit): number => {
    switch (unit) {
      case "J/g·°C":
        return valueJperKgK / 1000
      case "cal/g·°C":
        return valueJperKgK / 4184
      case "BTU/lb·°F":
        return valueJperKgK / 4186.8
      default:
        return valueJperKgK
    }
  }

  const findClosestMaterial = (specificHeat: number): string => {
    let closestMaterial = commonMaterials[0]
    let minDiff = Math.abs(specificHeat - closestMaterial.value)

    for (const material of commonMaterials) {
      const diff = Math.abs(specificHeat - material.value)
      if (diff < minDiff) {
        minDiff = diff
        closestMaterial = material
      }
    }

    const percentDiff = (minDiff / closestMaterial.value) * 100
    if (percentDiff < 15) {
      return `Similar to ${closestMaterial.name} (${closestMaterial.value} ${closestMaterial.unit})`
    }
    return "No close match to common materials"
  }

  const calculateSpecificHeat = () => {
    setError("")
    setResult(null)

    const heatNum = Number.parseFloat(heat)
    const massNum = Number.parseFloat(mass)
    const tempChangeNum = Number.parseFloat(tempChange)

    if (isNaN(heatNum)) {
      setError("Please enter a valid heat value")
      return
    }

    if (isNaN(massNum) || massNum <= 0) {
      setError("Mass must be positive")
      return
    }

    if (isNaN(tempChangeNum) || tempChangeNum === 0) {
      setError("Temperature change cannot be zero")
      return
    }

    const heatInJoules = convertHeatToJoules(Math.abs(heatNum), heatUnit)
    const massInKg = convertMassToKg(massNum, massUnit)
    const tempChangeInK = Math.abs(tempChangeNum) // ΔC = ΔK

    const specificHeatSI = heatInJoules / (massInKg * tempChangeInK)
    const displayValue = convertOutputUnit(specificHeatSI, outputUnit)

    let category: string
    let color: string
    let bgColor: string

    if (specificHeatSI < 500) {
      category = "Low Heat Capacity (Metal-like)"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (specificHeatSI < 1500) {
      category = "Moderate Heat Capacity"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (specificHeatSI < 3000) {
      category = "High Heat Capacity"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Heat Capacity (Water-like)"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    const materialMatch = findClosestMaterial(specificHeatSI)

    setResult({
      specificHeat: Math.round(displayValue * 1000) / 1000,
      category,
      color,
      bgColor,
      materialMatch,
    })
  }

  const handleReset = () => {
    setHeat("")
    setMass("")
    setTempChange("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Specific Heat Capacity: ${result.specificHeat} ${outputUnit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Specific Heat Capacity Calculator</CardTitle>
                    <CardDescription>Calculate specific heat from heat, mass, and temperature change</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Heat Input */}
                <div className="space-y-2">
                  <Label htmlFor="heat">Heat Added/Removed (Q)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="heat"
                      type="number"
                      placeholder="Enter heat value"
                      value={heat}
                      onChange={(e) => setHeat(e.target.value)}
                      className="flex-1"
                    />
                    <select
                      value={heatUnit}
                      onChange={(e) => setHeatUnit(e.target.value as HeatUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="J">J</option>
                      <option value="cal">cal</option>
                      <option value="BTU">BTU</option>
                    </select>
                  </div>
                </div>

                {/* Mass Input */}
                <div className="space-y-2">
                  <Label htmlFor="mass">Mass (m)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="mass"
                      type="number"
                      placeholder="Enter mass"
                      value={mass}
                      onChange={(e) => setMass(e.target.value)}
                      min="0"
                      className="flex-1"
                    />
                    <select
                      value={massUnit}
                      onChange={(e) => setMassUnit(e.target.value as MassUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="kg">kg</option>
                      <option value="g">g</option>
                      <option value="lb">lb</option>
                    </select>
                  </div>
                </div>

                {/* Temperature Change Input */}
                <div className="space-y-2">
                  <Label htmlFor="tempChange">Temperature Change (ΔT)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="tempChange"
                      type="number"
                      placeholder="Enter temperature change"
                      value={tempChange}
                      onChange={(e) => setTempChange(e.target.value)}
                      className="flex-1"
                    />
                    <select
                      value={tempUnit}
                      onChange={(e) => setTempUnit(e.target.value as TempUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="C">°C</option>
                      <option value="K">K</option>
                    </select>
                  </div>
                  <p className="text-xs text-muted-foreground">1°C change = 1 K change</p>
                </div>

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <select
                    value={outputUnit}
                    onChange={(e) => setOutputUnit(e.target.value as OutputUnit)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="J/kg·K">J/kg·K</option>
                    <option value="J/g·°C">J/g·°C</option>
                    <option value="cal/g·°C">cal/g·°C</option>
                    <option value="BTU/lb·°F">BTU/lb·°F</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSpecificHeat} className="w-full" size="lg">
                  Calculate Specific Heat
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Specific Heat Capacity (c)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{result.specificHeat}</p>
                      <p className="text-lg text-muted-foreground mb-2">{outputUnit}</p>
                      <p className={`text-sm font-medium ${result.color}`}>{result.category}</p>
                      <p className="text-xs text-muted-foreground mt-1">{result.materialMatch}</p>
                    </div>

                    {/* Step-by-step breakdown toggle */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Formula:</strong> c = Q / (m × ΔT)
                        </p>
                        <p>
                          <strong>Heat (Q):</strong> {heat} {heatUnit}
                        </p>
                        <p>
                          <strong>Mass (m):</strong> {mass} {massUnit}
                        </p>
                        <p>
                          <strong>Temperature Change (ΔT):</strong> {tempChange} °{tempUnit}
                        </p>
                        <p>
                          <strong>Result:</strong> c = {result.specificHeat} {outputUnit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Specific Heat Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">c = Q / (m × ΔT)</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>c</strong> = Specific heat capacity (J/kg·K)
                    </p>
                    <p>
                      <strong>Q</strong> = Heat transferred (J)
                    </p>
                    <p>
                      <strong>m</strong> = Mass (kg)
                    </p>
                    <p>
                      <strong>ΔT</strong> = Temperature change (K or °C)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Material Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm max-h-60 overflow-y-auto">
                    {commonMaterials.map((material) => (
                      <div key={material.name} className="flex justify-between p-2 bg-muted rounded">
                        <span>{material.name}</span>
                        <span className="font-mono">
                          {material.value} {material.unit}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Specific Heat Capacity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Specific heat capacity is a material property that measures how much heat energy is required to raise
                  the temperature of one unit mass of a substance by one degree. Materials with high specific heat
                  capacity, like water, can absorb large amounts of heat without significant temperature changes, making
                  them excellent for thermal storage and cooling applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This property is crucial in engineering for designing heating and cooling systems, understanding
                  climate patterns, and selecting materials for thermal management. Water's exceptionally high specific
                  heat (4186 J/kg·K) explains why coastal areas have milder climates and why water is used in radiators
                  and cooling systems.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Specific heat capacity calculations are based on ideal conditions. Actual
                  values may vary due to phase changes, impurities, and environmental factors. Consult material
                  datasheets for precise values.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
