"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Thermometer,
  Info,
  AlertTriangle,
  Droplets,
  Sun,
  Wind,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "celsius" | "fahrenheit"

interface HeatIndexResult {
  heatIndex: number
  category: string
  color: string
  bgColor: string
  description: string
  precautions: string[]
}

export function HeatIndexCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("celsius")
  const [temperature, setTemperature] = useState("")
  const [humidity, setHumidity] = useState("")
  const [result, setResult] = useState<HeatIndexResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateHeatIndex = () => {
    setError("")
    setResult(null)

    const tempNum = Number.parseFloat(temperature)
    const humidityNum = Number.parseFloat(humidity)

    if (isNaN(tempNum)) {
      setError("Please enter a valid temperature")
      return
    }

    if (isNaN(humidityNum) || humidityNum < 0 || humidityNum > 100) {
      setError("Please enter a valid humidity between 0 and 100%")
      return
    }

    // Convert to Fahrenheit if needed
    const tempF = unitSystem === "celsius" ? (tempNum * 9) / 5 + 32 : tempNum

    // Heat index formula is only valid for temperatures >= 80°F
    if (tempF < 80) {
      // For lower temperatures, heat index is approximately equal to air temperature
      const heatIndexResult = unitSystem === "celsius" ? tempNum : tempF
      setResult({
        heatIndex: Math.round(heatIndexResult * 10) / 10,
        category: "Comfortable",
        color: "text-green-600",
        bgColor: "bg-green-50 border-green-200",
        description: "Temperature is too low for significant heat index effect.",
        precautions: ["No special precautions needed", "Enjoy the comfortable weather"],
      })
      return
    }

    // Rothfusz regression equation
    let HI =
      -42.379 +
      2.04901523 * tempF +
      10.14333127 * humidityNum -
      0.22475541 * tempF * humidityNum -
      0.00683783 * tempF * tempF -
      0.05481717 * humidityNum * humidityNum +
      0.00122874 * tempF * tempF * humidityNum +
      0.00085282 * tempF * humidityNum * humidityNum -
      0.00000199 * tempF * tempF * humidityNum * humidityNum

    // Low humidity adjustment (RH < 13% and 80°F <= T <= 112°F)
    if (humidityNum < 13 && tempF >= 80 && tempF <= 112) {
      const adjustment = ((13 - humidityNum) / 4) * Math.sqrt((17 - Math.abs(tempF - 95)) / 17)
      HI -= adjustment
    }

    // High humidity adjustment (RH > 85% and 80°F <= T <= 87°F)
    if (humidityNum > 85 && tempF >= 80 && tempF <= 87) {
      const adjustment = ((humidityNum - 85) / 10) * ((87 - tempF) / 5)
      HI += adjustment
    }

    // Convert back to Celsius if needed
    const heatIndex = unitSystem === "celsius" ? ((HI - 32) * 5) / 9 : HI
    const roundedHI = Math.round(heatIndex * 10) / 10

    // Determine category based on heat index in Fahrenheit
    let category: string
    let color: string
    let bgColor: string
    let description: string
    let precautions: string[]

    if (HI < 80) {
      category = "Comfortable"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      description = "Conditions are comfortable with no heat-related risks."
      precautions = ["No special precautions needed", "Enjoy outdoor activities"]
    } else if (HI < 90) {
      category = "Caution"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
      description = "Fatigue possible with prolonged exposure and physical activity."
      precautions = [
        "Stay hydrated",
        "Take breaks in the shade",
        "Wear light, loose-fitting clothing",
        "Limit strenuous outdoor activities",
      ]
    } else if (HI < 103) {
      category = "Extreme Caution"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
      description = "Heat cramps and heat exhaustion possible with prolonged exposure."
      precautions = [
        "Drink plenty of water",
        "Rest frequently in cool areas",
        "Avoid prolonged sun exposure",
        "Monitor for signs of heat exhaustion",
      ]
    } else if (HI < 124) {
      category = "Danger"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
      description = "Heat cramps, heat exhaustion likely. Heat stroke possible with prolonged exposure."
      precautions = [
        "Avoid outdoor activities if possible",
        "Stay in air-conditioned spaces",
        "Drink water constantly",
        "Never leave children or pets in vehicles",
        "Check on elderly neighbors",
      ]
    } else {
      category = "Extreme Danger"
      color = "text-red-700"
      bgColor = "bg-red-100 border-red-300"
      description = "Heat stroke highly likely. This is a life-threatening situation."
      precautions = [
        "Stay indoors in air conditioning",
        "Avoid ALL outdoor physical activity",
        "Drink water even if not thirsty",
        "Seek medical attention if symptoms occur",
        "This is a medical emergency situation",
      ]
    }

    setResult({ heatIndex: roundedHI, category, color, bgColor, description, precautions })
  }

  const handleReset = () => {
    setTemperature("")
    setHumidity("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "celsius" ? "°C" : "°F"
      await navigator.clipboard.writeText(
        `Heat Index: ${result.heatIndex}${unit} (${result.category}) - Temperature: ${temperature}${unit}, Humidity: ${humidity}%`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const unit = unitSystem === "celsius" ? "°C" : "°F"
      try {
        await navigator.share({
          title: "Heat Index Result",
          text: `Heat Index: ${result.heatIndex}${unit} (${result.category}) - Calculated using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "celsius" ? "fahrenheit" : "celsius"))
    setTemperature("")
    setHumidity("")
    setResult(null)
    setError("")
  }

  const unit = unitSystem === "celsius" ? "°C" : "°F"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Thermometer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Heat Index Calculator</CardTitle>
                    <CardDescription>Calculate the "feels like" temperature</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Temperature Unit</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "fahrenheit" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "celsius" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Celsius
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "fahrenheit" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Fahrenheit
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Temperature Input */}
                <div className="space-y-2">
                  <Label htmlFor="temperature">Air Temperature ({unit})</Label>
                  <div className="relative">
                    <Input
                      id="temperature"
                      type="number"
                      placeholder={`Enter temperature in ${unitSystem === "celsius" ? "Celsius" : "Fahrenheit"}`}
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                      step="0.1"
                    />
                    <Sun className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                </div>

                {/* Humidity Input */}
                <div className="space-y-2">
                  <Label htmlFor="humidity">Relative Humidity (%)</Label>
                  <div className="relative">
                    <Input
                      id="humidity"
                      type="number"
                      placeholder="Enter humidity (0-100)"
                      value={humidity}
                      onChange={(e) => setHumidity(e.target.value)}
                      min="0"
                      max="100"
                      step="1"
                    />
                    <Droplets className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateHeatIndex} className="w-full" size="lg">
                  Calculate Heat Index
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Heat Index (Feels Like)</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>
                        {result.heatIndex}
                        <span className="text-2xl">{unit}</span>
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-sm text-muted-foreground mt-2">{result.description}</p>
                    </div>

                    {/* Precautions */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg">
                      <p className="text-sm font-medium mb-2">Recommended Precautions:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {result.precautions.map((precaution, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="text-primary mt-0.5">•</span>
                            {precaution}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Show Steps Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-sm text-primary hover:underline"
                    >
                      {showSteps ? "Hide calculation steps" : "Show calculation steps"}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm text-muted-foreground space-y-2">
                        <p>
                          <strong>Step 1:</strong> Input temperature: {temperature}
                          {unit}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Input humidity: {humidity}%
                        </p>
                        {unitSystem === "celsius" && (
                          <p>
                            <strong>Step 3:</strong> Convert to Fahrenheit:{" "}
                            {((Number.parseFloat(temperature) * 9) / 5 + 32).toFixed(1)}°F
                          </p>
                        )}
                        <p>
                          <strong>Step {unitSystem === "celsius" ? "4" : "3"}:</strong> Apply Rothfusz regression
                          equation
                        </p>
                        <p>
                          <strong>Step {unitSystem === "celsius" ? "5" : "4"}:</strong> Apply humidity adjustments if
                          needed
                        </p>
                        {unitSystem === "celsius" && (
                          <p>
                            <strong>Step 6:</strong> Convert back to Celsius
                          </p>
                        )}
                        <p>
                          <strong>Result:</strong> Heat Index = {result.heatIndex}
                          {unit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Heat Index Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Comfortable</span>
                      <span className="text-sm text-green-600">{"< 80°F / 27°C"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Caution</span>
                      <span className="text-sm text-yellow-600">80-89°F / 27-32°C</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Extreme Caution</span>
                      <span className="text-sm text-orange-600">90-102°F / 32-39°C</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Danger</span>
                      <span className="text-sm text-red-600">103-124°F / 39-51°C</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-100 border border-red-300">
                      <span className="font-medium text-red-800">Extreme Danger</span>
                      <span className="text-sm text-red-700">≥ 125°F / 52°C</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Heat Index Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-xs text-center overflow-x-auto">
                    <p className="font-semibold text-foreground whitespace-nowrap">
                      HI = -42.379 + 2.049T + 10.143RH - 0.225T×RH
                    </p>
                    <p className="font-semibold text-foreground whitespace-nowrap mt-1">
                      - 0.007T² - 0.055RH² + 0.001T²×RH + ...
                    </p>
                  </div>
                  <p>
                    The Rothfusz regression equation calculates heat index using temperature (T) in °F and relative
                    humidity (RH) in %.
                  </p>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-yellow-200 bg-yellow-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual perceived temperature may vary due to wind, sun exposure,
                        clothing, and individual factors. Always take appropriate precautions in hot weather.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Heat Index?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The heat index, also known as the "apparent temperature" or "feels like" temperature, is a measure of
                  how hot it really feels when relative humidity is factored in with the actual air temperature. It was
                  developed by Robert G. Steadman in 1979 and is widely used by meteorological services around the world
                  to warn the public about dangerous heat conditions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When humidity is high, the evaporation of sweat from our skin is less effective at cooling us down.
                  This is because the air is already saturated with water vapor, making it harder for our perspiration
                  to evaporate. As a result, our bodies cannot cool themselves as efficiently, and we feel hotter than
                  the actual air temperature would suggest.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>How Humidity Affects Perceived Temperature</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Humidity plays a crucial role in how we perceive temperature. At low humidity levels (below 40%), our
                  bodies can efficiently cool themselves through sweating, as the dry air readily absorbs moisture from
                  our skin. However, as humidity rises, this natural cooling mechanism becomes increasingly impaired.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, on a day when the actual temperature is 90°F (32°C), if the humidity is only 40%, the
                  heat index would be about 91°F (33°C) - nearly the same as the actual temperature. But if humidity
                  rises to 70%, the heat index jumps to approximately 106°F (41°C), making it feel significantly hotter
                  and more dangerous for prolonged outdoor activity.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Heat-Related Illnesses</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding heat-related illnesses is essential for staying safe during hot weather. These
                  conditions range from mild heat cramps to life-threatening heat stroke, and recognizing their symptoms
                  early can save lives.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Heat Cramps</h4>
                    <p className="text-yellow-700 text-sm">
                      Painful muscle cramps, usually in the legs or abdomen, caused by loss of salt through heavy
                      sweating. Move to a cool place, rest, and drink water or sports drinks.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Heat Exhaustion</h4>
                    <p className="text-orange-700 text-sm">
                      Symptoms include heavy sweating, weakness, cold/pale/clammy skin, fast/weak pulse, nausea, and
                      fainting. Move to a cool place, apply cool cloths, and sip water. Seek medical help if symptoms
                      worsen.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Heat Stroke</h4>
                    <p className="text-red-700 text-sm">
                      A medical emergency! Symptoms include high body temperature (103°F+), hot/red/dry skin, rapid
                      pulse, confusion, and unconsciousness. Call 911 immediately and cool the person with any means
                      available.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Wind className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Heat Perception</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the heat index provides a useful estimate of how hot it feels, several other factors can
                  influence your personal perception of heat:
                </p>
                <ul className="mt-4 space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Wind:</strong> A breeze can help evaporate sweat and make you feel cooler, while still air
                      can make heat feel more oppressive.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Sun exposure:</strong> Direct sunlight can add 10-15°F to the heat index, as solar
                      radiation heats your skin directly.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Clothing:</strong> Dark or tight clothing absorbs more heat and reduces evaporative
                      cooling. Light, loose-fitting clothes are best in hot weather.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Physical activity:</strong> Exercise generates internal heat, making the effective
                      temperature feel even higher.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Age and health:</strong> Elderly individuals, young children, and those with certain
                      health conditions are more vulnerable to heat.
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
