"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Thermometer, Flame } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type EnergyUnit = "kJ" | "J"

interface SpontaneityResult {
  deltaG: number
  status: string
  description: string
  color: string
  bgColor: string
  enthalpyContribution: string
  entropyContribution: string
}

export function ReactionSpontaneityChecker() {
  const [energyUnit, setEnergyUnit] = useState<EnergyUnit>("kJ")
  const [deltaH, setDeltaH] = useState("")
  const [deltaS, setDeltaS] = useState("")
  const [temperature, setTemperature] = useState("")
  const [result, setResult] = useState<SpontaneityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const deltaHNum = Number.parseFloat(deltaH)
    const deltaSNum = Number.parseFloat(deltaS)
    const tempNum = Number.parseFloat(temperature)

    if (isNaN(deltaHNum)) {
      setError("Please enter a valid enthalpy change (ΔH)")
      return
    }

    if (isNaN(deltaSNum)) {
      setError("Please enter a valid entropy change (ΔS)")
      return
    }

    if (isNaN(tempNum) || tempNum <= 0) {
      setError("Please enter a valid temperature greater than 0 K")
      return
    }

    // Convert units if necessary
    // ΔH is in kJ/mol or J/mol, ΔS is in J/(mol·K)
    // For calculation: ΔG = ΔH - TΔS (both in same units)
    let deltaHInKJ = energyUnit === "kJ" ? deltaHNum : deltaHNum / 1000
    let deltaSInKJ = deltaSNum / 1000 // ΔS is always in J/(mol·K), convert to kJ/(mol·K)

    const deltaG = deltaHInKJ - tempNum * deltaSInKJ
    const roundedDeltaG = Math.round(deltaG * 100) / 100

    let status: string
    let description: string
    let color: string
    let bgColor: string

    if (roundedDeltaG < -0.01) {
      status = "Spontaneous"
      description = "The reaction will proceed spontaneously under these conditions"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (roundedDeltaG > 0.01) {
      status = "Non-Spontaneous"
      description = "The reaction will not proceed spontaneously under these conditions"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else {
      status = "At Equilibrium"
      description = "The reaction is at equilibrium under these conditions"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    }

    // Analyze driving factors
    const enthalpyContribution = deltaHInKJ < 0 ? "Favorable (exothermic)" : deltaHInKJ > 0 ? "Unfavorable (endothermic)" : "Neutral"
    const entropyContribution = deltaSInKJ > 0 ? "Favorable (disorder increases)" : deltaSInKJ < 0 ? "Unfavorable (disorder decreases)" : "Neutral"

    setResult({
      deltaG: roundedDeltaG,
      status,
      description,
      color,
      bgColor,
      enthalpyContribution,
      entropyContribution,
    })
  }

  const handleReset = () => {
    setDeltaH("")
    setDeltaS("")
    setTemperature("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Reaction Spontaneity: ΔG = ${result.deltaG} kJ/mol (${result.status})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Reaction Spontaneity Check",
          text: `I checked reaction spontaneity using CalcHub! ΔG = ${result.deltaG} kJ/mol (${result.status})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleEnergyUnit = () => {
    setEnergyUnit((prev) => (prev === "kJ" ? "J" : "kJ"))
    setDeltaH("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Reaction Spontaneity Checker</CardTitle>
                    <CardDescription>Determine if a reaction is spontaneous</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Energy Unit (ΔH)</span>
                  <button
                    onClick={toggleEnergyUnit}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        energyUnit === "J" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        energyUnit === "kJ" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      kJ/mol
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        energyUnit === "J" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      J/mol
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Enthalpy Input */}
                <div className="space-y-2">
                  <Label htmlFor="deltaH">Enthalpy Change, ΔH ({energyUnit}/mol)</Label>
                  <Input
                    id="deltaH"
                    type="number"
                    placeholder="Enter ΔH (negative for exothermic)"
                    value={deltaH}
                    onChange={(e) => setDeltaH(e.target.value)}
                    step="0.01"
                  />
                </div>

                {/* Entropy Input */}
                <div className="space-y-2">
                  <Label htmlFor="deltaS">Entropy Change, ΔS (J/(mol·K))</Label>
                  <Input
                    id="deltaS"
                    type="number"
                    placeholder="Enter ΔS (positive for disorder increase)"
                    value={deltaS}
                    onChange={(e) => setDeltaS(e.target.value)}
                    step="0.01"
                  />
                </div>

                {/* Temperature Input */}
                <div className="space-y-2">
                  <Label htmlFor="temperature">Temperature (K)</Label>
                  <Input
                    id="temperature"
                    type="number"
                    placeholder="Enter temperature in Kelvin"
                    value={temperature}
                    onChange={(e) => setTemperature(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Check Spontaneity
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Gibbs Free Energy (ΔG)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{result.deltaG} kJ/mol</p>
                      <p className={`text-lg font-semibold ${result.color} mb-2`}>{result.status}</p>
                      <p className="text-sm text-muted-foreground">{result.description}</p>
                    </div>

                    {/* Driving Factors */}
                    <div className="mt-4 pt-4 border-t border-current/10 grid grid-cols-2 gap-3 text-sm">
                      <div className="text-center">
                        <p className="text-muted-foreground text-xs mb-1">Enthalpy (ΔH)</p>
                        <p className={`font-medium ${result.enthalpyContribution.includes("Favorable") ? "text-green-600" : result.enthalpyContribution.includes("Unfavorable") ? "text-red-600" : "text-gray-600"}`}>
                          {result.enthalpyContribution}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground text-xs mb-1">Entropy (TΔS)</p>
                        <p className={`font-medium ${result.entropyContribution.includes("Favorable") ? "text-green-600" : result.entropyContribution.includes("Unfavorable") ? "text-red-600" : "text-gray-600"}`}>
                          {result.entropyContribution}
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Spontaneity Criteria</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Spontaneous</span>
                      <span className="text-sm text-green-600">{"ΔG < 0"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">At Equilibrium</span>
                      <span className="text-sm text-yellow-600">{"ΔG = 0"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Non-Spontaneous</span>
                      <span className="text-sm text-red-600">{"ΔG > 0"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gibbs Free Energy Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ΔG = ΔH - TΔS</p>
                  </div>
                  <p>
                    Where <strong>ΔG</strong> is Gibbs free energy, <strong>ΔH</strong> is enthalpy change, <strong>T</strong> is absolute temperature (K), and <strong>ΔS</strong> is entropy change.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Spontaneity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Reaction Spontaneity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Reaction spontaneity refers to whether a chemical reaction will occur on its own without external intervention. A spontaneous reaction is thermodynamically favorable and will proceed in the forward direction under the given conditions. This does not mean the reaction happens quickly - spontaneity only indicates the thermodynamic tendency, not the rate of reaction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The spontaneity of a reaction is determined by the Gibbs free energy change (ΔG). When ΔG is negative, the reaction releases free energy and is spontaneous. When ΔG is positive, the reaction requires energy input and is non-spontaneous. At ΔG = 0, the system is at equilibrium with no net change occurring.
                </p>
              </CardContent>
            </Card>

            {/* Driving Factors */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Enthalpy vs Entropy: Driving Factors</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Spontaneity depends on the balance between two competing factors: enthalpy (ΔH) and entropy (ΔS). Exothermic reactions (negative ΔH) release heat and favor spontaneity, while reactions that increase disorder (positive ΔS) also favor spontaneity. The temperature determines how much weight entropy carries in the equation.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">ΔH {"<"} 0 and ΔS {">"} 0</h4>
                    <p className="text-green-700 text-sm">
                      Always spontaneous at all temperatures. Both enthalpy and entropy favor the reaction.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">ΔH {">"} 0 and ΔS {"<"} 0</h4>
                    <p className="text-red-700 text-sm">
                      Never spontaneous at any temperature. Both factors oppose the reaction.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">ΔH {"<"} 0 and ΔS {"<"} 0</h4>
                    <p className="text-yellow-700 text-sm">
                      Spontaneous at low temperatures. Enthalpy favors, entropy opposes.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">ΔH {">"} 0 and ΔS {">"} 0</h4>
                    <p className="text-blue-700 text-sm">
                      Spontaneous at high temperatures. Entropy favors, enthalpy opposes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Temperature Dependence */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Temperature Dependence</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Temperature plays a crucial role in determining spontaneity when enthalpy and entropy have opposing effects. The term TΔS in the Gibbs equation shows that entropy's contribution increases with temperature. This is why some reactions that are non-spontaneous at low temperatures become spontaneous at high temperatures (and vice versa).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The temperature at which a reaction transitions from non-spontaneous to spontaneous (or equilibrium) can be found when ΔG = 0, giving T = ΔH/ΔS. This crossover temperature is important for understanding reaction behavior across different conditions.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations and Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Spontaneity calculations assume ideal conditions and equilibrium thermodynamics. Real reactions may be influenced by kinetic barriers, catalysts, non-standard conditions, or non-ideal behavior. A spontaneous reaction may still be extremely slow without appropriate activation energy or catalysis.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator provides theoretical predictions based on thermodynamic data. Actual reaction behavior may differ due to concentration effects, pressure changes, or other factors not captured in standard calculations. Always verify results with experimental data for critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
