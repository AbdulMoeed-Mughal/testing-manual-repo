"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  BarChart3,
  Plus,
  Trash2,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Portfolio {
  id: string
  name: string
  expectedReturn: string
  standardDeviation: string
}

interface PortfolioResult {
  id: string
  name: string
  sharpeRatio: number
  expectedReturn: number
  standardDeviation: number
  excessReturn: number
  rank: number
  category: string
  color: string
  bgColor: string
}

interface Result {
  portfolios: PortfolioResult[]
  riskFreeRate: number
  timePeriod: string
}

export function SharpeRatioCalculator() {
  const [portfolios, setPortfolios] = useState<Portfolio[]>([
    { id: "1", name: "Portfolio 1", expectedReturn: "", standardDeviation: "" },
  ])
  const [riskFreeRate, setRiskFreeRate] = useState("")
  const [timePeriod, setTimePeriod] = useState<"annual" | "monthly">("annual")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const addPortfolio = () => {
    if (portfolios.length < 5) {
      setPortfolios([
        ...portfolios,
        {
          id: Date.now().toString(),
          name: `Portfolio ${portfolios.length + 1}`,
          expectedReturn: "",
          standardDeviation: "",
        },
      ])
    }
  }

  const removePortfolio = (id: string) => {
    if (portfolios.length > 1) {
      setPortfolios(portfolios.filter((p) => p.id !== id))
    }
  }

  const updatePortfolio = (id: string, field: keyof Portfolio, value: string) => {
    setPortfolios(portfolios.map((p) => (p.id === id ? { ...p, [field]: value } : p)))
  }

  const getSharpeCategory = (ratio: number): { category: string; color: string; bgColor: string } => {
    if (ratio < 0) {
      return { category: "Negative", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    } else if (ratio < 1) {
      return { category: "Sub-optimal", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    } else if (ratio < 2) {
      return { category: "Good", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    } else if (ratio < 3) {
      return { category: "Very Good", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    } else {
      return { category: "Excellent", color: "text-emerald-600", bgColor: "bg-emerald-50 border-emerald-200" }
    }
  }

  const calculateSharpeRatio = () => {
    setError("")
    setResult(null)

    const riskFreeRateNum = Number.parseFloat(riskFreeRate)
    if (isNaN(riskFreeRateNum) || riskFreeRateNum < 0) {
      setError("Please enter a valid risk-free rate (0 or greater)")
      return
    }

    const portfolioResults: PortfolioResult[] = []

    for (const portfolio of portfolios) {
      const expectedReturnNum = Number.parseFloat(portfolio.expectedReturn)
      const stdDevNum = Number.parseFloat(portfolio.standardDeviation)

      if (isNaN(expectedReturnNum)) {
        setError(`Please enter a valid expected return for ${portfolio.name}`)
        return
      }

      if (isNaN(stdDevNum) || stdDevNum <= 0) {
        setError(`Please enter a valid standard deviation greater than 0 for ${portfolio.name}`)
        return
      }

      // Annualize if monthly
      let annualizedReturn = expectedReturnNum
      let annualizedStdDev = stdDevNum
      let annualizedRiskFreeRate = riskFreeRateNum

      if (timePeriod === "monthly") {
        annualizedReturn = expectedReturnNum * 12
        annualizedStdDev = stdDevNum * Math.sqrt(12)
        annualizedRiskFreeRate = riskFreeRateNum * 12
      }

      const excessReturn = annualizedReturn - annualizedRiskFreeRate
      const sharpeRatio = excessReturn / annualizedStdDev

      const { category, color, bgColor } = getSharpeCategory(sharpeRatio)

      portfolioResults.push({
        id: portfolio.id,
        name: portfolio.name,
        sharpeRatio: Math.round(sharpeRatio * 100) / 100,
        expectedReturn: annualizedReturn,
        standardDeviation: annualizedStdDev,
        excessReturn,
        rank: 0,
        category,
        color,
        bgColor,
      })
    }

    // Sort by Sharpe Ratio (highest first) and assign ranks
    portfolioResults.sort((a, b) => b.sharpeRatio - a.sharpeRatio)
    portfolioResults.forEach((p, index) => {
      p.rank = index + 1
    })

    setResult({
      portfolios: portfolioResults,
      riskFreeRate: timePeriod === "monthly" ? riskFreeRateNum * 12 : riskFreeRateNum,
      timePeriod,
    })
  }

  const handleReset = () => {
    setPortfolios([{ id: "1", name: "Portfolio 1", expectedReturn: "", standardDeviation: "" }])
    setRiskFreeRate("")
    setTimePeriod("annual")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.portfolios.map((p) => `${p.name}: Sharpe Ratio ${p.sharpeRatio} (${p.category})`).join("\n")
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = result.portfolios.map((p) => `${p.name}: Sharpe Ratio ${p.sharpeRatio} (${p.category})`).join("\n")
        await navigator.share({
          title: "Sharpe Ratio Results",
          text: `I calculated Sharpe Ratios using CalcHub!\n${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Sharpe Ratio Calculator</CardTitle>
                    <CardDescription>Evaluate risk-adjusted returns</CardDescription>
                  </div>
                </div>

                {/* Time Period Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Time Period</span>
                  <Select value={timePeriod} onValueChange={(value: "annual" | "monthly") => setTimePeriod(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="annual">Annual</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Risk-Free Rate */}
                <div className="space-y-2">
                  <Label htmlFor="risk-free-rate">Risk-Free Rate (%)</Label>
                  <Input
                    id="risk-free-rate"
                    type="number"
                    placeholder="e.g., 4.5"
                    value={riskFreeRate}
                    onChange={(e) => setRiskFreeRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Typically the yield on Treasury bills (T-bills)</p>
                </div>

                {/* Portfolios */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Portfolios</Label>
                    {portfolios.length < 5 && (
                      <Button variant="outline" size="sm" onClick={addPortfolio}>
                        <Plus className="h-4 w-4 mr-1" />
                        Add Portfolio
                      </Button>
                    )}
                  </div>

                  {portfolios.map((portfolio, index) => (
                    <div key={portfolio.id} className="p-3 bg-muted/50 rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Input
                          value={portfolio.name}
                          onChange={(e) => updatePortfolio(portfolio.id, "name", e.target.value)}
                          className="h-8 w-32 text-sm font-medium"
                          placeholder="Portfolio name"
                        />
                        {portfolios.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removePortfolio(portfolio.id)}
                            className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs">Expected Return (%)</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 12"
                            value={portfolio.expectedReturn}
                            onChange={(e) => updatePortfolio(portfolio.id, "expectedReturn", e.target.value)}
                            step="0.1"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Std Deviation (%)</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 15"
                            value={portfolio.standardDeviation}
                            onChange={(e) => updatePortfolio(portfolio.id, "standardDeviation", e.target.value)}
                            min="0.01"
                            step="0.1"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSharpeRatio} className="w-full" size="lg">
                  Calculate Sharpe Ratio
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    {result.portfolios.map((portfolio, index) => (
                      <div
                        key={portfolio.id}
                        className={`p-4 rounded-xl border-2 ${portfolio.bgColor} transition-all duration-300`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-foreground">{portfolio.name}</span>
                          {result.portfolios.length > 1 && (
                            <span className="text-xs px-2 py-1 bg-white/50 rounded-full">Rank #{portfolio.rank}</span>
                          )}
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground mb-1">Sharpe Ratio</p>
                          <p className={`text-4xl font-bold ${portfolio.color} mb-1`}>
                            {portfolio.sharpeRatio.toFixed(2)}
                          </p>
                          <p className={`text-sm font-semibold ${portfolio.color}`}>{portfolio.category}</p>
                        </div>

                        <div className="mt-3 pt-3 border-t border-current/10 grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <span className="text-muted-foreground">Expected Return:</span>
                            <span className="ml-1 font-medium">{portfolio.expectedReturn.toFixed(2)}%</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Std Deviation:</span>
                            <span className="ml-1 font-medium">{portfolio.standardDeviation.toFixed(2)}%</span>
                          </div>
                          <div className="col-span-2">
                            <span className="text-muted-foreground">Excess Return:</span>
                            <span className="ml-1 font-medium">{portfolio.excessReturn.toFixed(2)}%</span>
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sharpe Ratio Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Negative</span>
                      <span className="text-sm text-red-600">{"< 0"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Sub-optimal</span>
                      <span className="text-sm text-yellow-600">0 – 0.99</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-sm text-blue-600">1 – 1.99</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Very Good</span>
                      <span className="text-sm text-green-600">2 – 2.99</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                      <span className="font-medium text-emerald-700">Excellent</span>
                      <span className="text-sm text-emerald-600">≥ 3</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sharpe Ratio Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Sharpe Ratio = (Rp - Rf) / σp</p>
                  </div>
                  <div className="space-y-2 text-xs">
                    <p>
                      <strong>Rp</strong> = Expected portfolio return
                    </p>
                    <p>
                      <strong>Rf</strong> = Risk-free rate
                    </p>
                    <p>
                      <strong>σp</strong> = Portfolio standard deviation (volatility)
                    </p>
                  </div>
                  <p className="text-xs">
                    Higher Sharpe ratios indicate better risk-adjusted returns. A ratio above 1 is considered
                    acceptable, above 2 is very good, and above 3 is excellent.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Sharpe Ratio?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Sharpe Ratio, developed by Nobel laureate William F. Sharpe in 1966, is one of the most widely
                  used metrics for evaluating the risk-adjusted performance of an investment or portfolio. It measures
                  the excess return per unit of risk, helping investors understand whether a portfolio's returns are due
                  to smart investment decisions or simply taking on more risk.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  By comparing the return of an investment above the risk-free rate to its standard deviation
                  (volatility), the Sharpe Ratio provides a standardized way to compare investments with different risk
                  profiles. This makes it invaluable for portfolio optimization, fund selection, and performance
                  evaluation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  <CardTitle>How to Interpret Sharpe Ratio</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Interpreting the Sharpe Ratio is straightforward: higher values indicate better risk-adjusted
                  performance. A Sharpe Ratio of 1 means you're earning one unit of return for every unit of risk taken.
                  A ratio above 1 is generally considered acceptable for most investors, while ratios above 2 indicate
                  excellent risk-adjusted returns.
                </p>
                <div className="mt-4 grid gap-3">
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-red-700 text-sm">
                      <strong>Negative Sharpe Ratio:</strong> The investment is performing worse than a risk-free asset.
                      Consider re-evaluating the investment strategy.
                    </p>
                  </div>
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-yellow-700 text-sm">
                      <strong>Sharpe Ratio 0-1:</strong> Returns don't adequately compensate for risk. May be acceptable
                      for diversification purposes.
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-green-700 text-sm">
                      <strong>Sharpe Ratio above 1:</strong> Good risk-adjusted returns. The investment is generating
                      excess returns relative to its volatility.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations and Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the Sharpe Ratio is a powerful tool, it has some limitations. It assumes returns are normally
                  distributed, which may not always be the case for investments with skewed or fat-tailed return
                  distributions. It also uses standard deviation as the sole measure of risk, which treats upside and
                  downside volatility equally.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For a more comprehensive analysis, consider using the Sharpe Ratio alongside other metrics like the
                  Sortino Ratio (which only penalizes downside volatility), Treynor Ratio (which uses beta instead of
                  standard deviation), and maximum drawdown analysis.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Sharpe ratio calculations are estimates based on entered values. Actual investment performance may
                  vary due to market conditions, volatility, and other factors. Past performance is not indicative of
                  future results. This calculator is for educational purposes only and should not be considered
                  investment advice. Consult a qualified financial advisor for personalized guidance before making
                  investment decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
