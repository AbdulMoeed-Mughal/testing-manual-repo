"use client"

import type React from "react"

import { useState, useCallback } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Grid3X3,
  Info,
  AlertTriangle,
  Plus,
  Minus,
  X,
  Divide,
  RotateCw,
  FlipHorizontal,
  Calculator,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Operation = "add" | "subtract" | "multiply" | "determinant" | "inverse" | "transpose" | "trace" | "rank"

interface MatrixResult {
  matrix?: number[][]
  scalar?: number
  error?: string
}

export function MatrixCalculator() {
  const [operation, setOperation] = useState<Operation>("add")
  const [rowsA, setRowsA] = useState(2)
  const [colsA, setColsA] = useState(2)
  const [rowsB, setRowsB] = useState(2)
  const [colsB, setColsB] = useState(2)
  const [matrixA, setMatrixA] = useState<string[][]>([
    ["1", "2"],
    ["3", "4"],
  ])
  const [matrixB, setMatrixB] = useState<string[][]>([
    ["5", "6"],
    ["7", "8"],
  ])
  const [result, setResult] = useState<MatrixResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const needsSecondMatrix = ["add", "subtract", "multiply"].includes(operation)
  const needsSquareMatrix = ["determinant", "inverse", "trace"].includes(operation)

  const initMatrix = (rows: number, cols: number): string[][] => {
    return Array(rows)
      .fill(null)
      .map(() => Array(cols).fill("0"))
  }

  const updateMatrixASize = (newRows: number, newCols: number) => {
    const newMatrix = initMatrix(newRows, newCols)
    for (let i = 0; i < Math.min(rowsA, newRows); i++) {
      for (let j = 0; j < Math.min(colsA, newCols); j++) {
        newMatrix[i][j] = matrixA[i]?.[j] || "0"
      }
    }
    setRowsA(newRows)
    setColsA(newCols)
    setMatrixA(newMatrix)
  }

  const updateMatrixBSize = (newRows: number, newCols: number) => {
    const newMatrix = initMatrix(newRows, newCols)
    for (let i = 0; i < Math.min(rowsB, newRows); i++) {
      for (let j = 0; j < Math.min(colsB, newCols); j++) {
        newMatrix[i][j] = matrixB[i]?.[j] || "0"
      }
    }
    setRowsB(newRows)
    setColsB(newCols)
    setMatrixB(newMatrix)
  }

  const updateMatrixAValue = (row: number, col: number, value: string) => {
    const newMatrix = matrixA.map((r) => [...r])
    newMatrix[row][col] = value
    setMatrixA(newMatrix)
  }

  const updateMatrixBValue = (row: number, col: number, value: string) => {
    const newMatrix = matrixB.map((r) => [...r])
    newMatrix[row][col] = value
    setMatrixB(newMatrix)
  }

  const parseMatrix = (matrix: string[][]): number[][] | null => {
    try {
      return matrix.map((row) =>
        row.map((val) => {
          const num = Number.parseFloat(val)
          if (isNaN(num)) throw new Error("Invalid number")
          return num
        }),
      )
    } catch {
      return null
    }
  }

  const addMatrices = (a: number[][], b: number[][]): number[][] => {
    return a.map((row, i) => row.map((val, j) => val + b[i][j]))
  }

  const subtractMatrices = (a: number[][], b: number[][]): number[][] => {
    return a.map((row, i) => row.map((val, j) => val - b[i][j]))
  }

  const multiplyMatrices = (a: number[][], b: number[][]): number[][] => {
    const result: number[][] = []
    for (let i = 0; i < a.length; i++) {
      result[i] = []
      for (let j = 0; j < b[0].length; j++) {
        let sum = 0
        for (let k = 0; k < a[0].length; k++) {
          sum += a[i][k] * b[k][j]
        }
        result[i][j] = sum
      }
    }
    return result
  }

  const transposeMatrix = (m: number[][]): number[][] => {
    return m[0].map((_, i) => m.map((row) => row[i]))
  }

  const calculateDeterminant = (m: number[][]): number => {
    const n = m.length
    if (n === 1) return m[0][0]
    if (n === 2) return m[0][0] * m[1][1] - m[0][1] * m[1][0]

    let det = 0
    for (let j = 0; j < n; j++) {
      const minor = m.slice(1).map((row) => [...row.slice(0, j), ...row.slice(j + 1)])
      det += Math.pow(-1, j) * m[0][j] * calculateDeterminant(minor)
    }
    return det
  }

  const calculateInverse = (m: number[][]): number[][] | null => {
    const n = m.length
    const det = calculateDeterminant(m)
    if (Math.abs(det) < 1e-10) return null

    if (n === 2) {
      return [
        [m[1][1] / det, -m[0][1] / det],
        [-m[1][0] / det, m[0][0] / det],
      ]
    }

    // For larger matrices, use adjugate method
    const adjugate: number[][] = []
    for (let i = 0; i < n; i++) {
      adjugate[i] = []
      for (let j = 0; j < n; j++) {
        const minor = m.filter((_, r) => r !== i).map((row) => row.filter((_, c) => c !== j))
        const cofactor = Math.pow(-1, i + j) * calculateDeterminant(minor)
        adjugate[i][j] = cofactor
      }
    }

    const adjugateT = transposeMatrix(adjugate)
    return adjugateT.map((row) => row.map((val) => val / det))
  }

  const calculateTrace = (m: number[][]): number => {
    let trace = 0
    for (let i = 0; i < m.length; i++) {
      trace += m[i][i]
    }
    return trace
  }

  const calculateRank = (m: number[][]): number => {
    // Create a copy to avoid modifying original
    const matrix = m.map((row) => [...row])
    const rows = matrix.length
    const cols = matrix[0].length
    let rank = 0

    for (let col = 0; col < cols && rank < rows; col++) {
      // Find pivot
      let pivotRow = rank
      for (let row = rank + 1; row < rows; row++) {
        if (Math.abs(matrix[row][col]) > Math.abs(matrix[pivotRow][col])) {
          pivotRow = row
        }
      }

      if (Math.abs(matrix[pivotRow][col]) < 1e-10) continue

      // Swap rows
      ;[matrix[rank], matrix[pivotRow]] = [matrix[pivotRow], matrix[rank]]

      // Eliminate
      for (let row = rank + 1; row < rows; row++) {
        const factor = matrix[row][col] / matrix[rank][col]
        for (let j = col; j < cols; j++) {
          matrix[row][j] -= factor * matrix[rank][j]
        }
      }

      rank++
    }

    return rank
  }

  const calculate = useCallback(() => {
    setError("")
    setResult(null)

    const A = parseMatrix(matrixA)
    if (!A) {
      setError("Matrix A contains invalid numbers")
      return
    }

    if (needsSquareMatrix && rowsA !== colsA) {
      setError(`${operation.charAt(0).toUpperCase() + operation.slice(1)} requires a square matrix`)
      return
    }

    if (needsSecondMatrix) {
      const B = parseMatrix(matrixB)
      if (!B) {
        setError("Matrix B contains invalid numbers")
        return
      }

      if (operation === "add" || operation === "subtract") {
        if (rowsA !== rowsB || colsA !== colsB) {
          setError("Matrices must have the same dimensions for addition/subtraction")
          return
        }
        const res = operation === "add" ? addMatrices(A, B) : subtractMatrices(A, B)
        setResult({ matrix: res })
      } else if (operation === "multiply") {
        if (colsA !== rowsB) {
          setError("Number of columns in A must equal number of rows in B for multiplication")
          return
        }
        setResult({ matrix: multiplyMatrices(A, B) })
      }
    } else {
      switch (operation) {
        case "determinant":
          setResult({ scalar: calculateDeterminant(A) })
          break
        case "inverse":
          const inv = calculateInverse(A)
          if (!inv) {
            setError("Matrix is singular (determinant is 0). Inverse does not exist.")
            return
          }
          setResult({ matrix: inv })
          break
        case "transpose":
          setResult({ matrix: transposeMatrix(A) })
          break
        case "trace":
          setResult({ scalar: calculateTrace(A) })
          break
        case "rank":
          setResult({ scalar: calculateRank(A) })
          break
      }
    }
  }, [matrixA, matrixB, operation, rowsA, colsA, rowsB, colsB, needsSecondMatrix, needsSquareMatrix])

  const handleReset = () => {
    setRowsA(2)
    setColsA(2)
    setRowsB(2)
    setColsB(2)
    setMatrixA([
      ["1", "2"],
      ["3", "4"],
    ])
    setMatrixB([
      ["5", "6"],
      ["7", "8"],
    ])
    setResult(null)
    setError("")
    setCopied(false)
  }

  const formatNumber = (num: number): string => {
    const rounded = Math.round(num * 10000) / 10000
    return rounded.toString()
  }

  const matrixToString = (m: number[][]): string => {
    return m.map((row) => row.map(formatNumber).join("\t")).join("\n")
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.matrix
        ? `Result Matrix:\n${matrixToString(result.matrix)}`
        : `Result: ${formatNumber(result.scalar!)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = result.matrix
          ? `Matrix ${operation} result:\n${matrixToString(result.matrix)}`
          : `Matrix ${operation} = ${formatNumber(result.scalar!)}`
        await navigator.share({
          title: "Matrix Calculator Result",
          text: `I calculated matrix operations using CalcHub!\n${text}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const operationButtons: { op: Operation; label: string; icon: React.ReactNode }[] = [
    { op: "add", label: "A + B", icon: <Plus className="h-3 w-3" /> },
    { op: "subtract", label: "A − B", icon: <Minus className="h-3 w-3" /> },
    { op: "multiply", label: "A × B", icon: <X className="h-3 w-3" /> },
    { op: "determinant", label: "det(A)", icon: <Calculator className="h-3 w-3" /> },
    { op: "inverse", label: "A⁻¹", icon: <Divide className="h-3 w-3" /> },
    { op: "transpose", label: "Aᵀ", icon: <FlipHorizontal className="h-3 w-3" /> },
    { op: "trace", label: "tr(A)", icon: <RotateCw className="h-3 w-3" /> },
    { op: "rank", label: "rank(A)", icon: <Grid3X3 className="h-3 w-3" /> },
  ]

  const renderMatrixInput = (
    matrix: string[][],
    rows: number,
    cols: number,
    label: string,
    updateValue: (row: number, col: number, value: string) => void,
    updateSize: (rows: number, cols: number) => void,
  ) => (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="font-semibold">{label}</Label>
        <div className="flex items-center gap-2">
          <Input
            type="number"
            min="1"
            max="5"
            value={rows}
            onChange={(e) => updateSize(Math.max(1, Math.min(5, Number.parseInt(e.target.value) || 1)), cols)}
            className="w-14 h-8 text-center text-sm"
          />
          <span className="text-muted-foreground">×</span>
          <Input
            type="number"
            min="1"
            max="5"
            value={cols}
            onChange={(e) => updateSize(rows, Math.max(1, Math.min(5, Number.parseInt(e.target.value) || 1)))}
            className="w-14 h-8 text-center text-sm"
          />
        </div>
      </div>
      <div className="grid gap-1 p-3 bg-muted/50 rounded-lg" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
        {matrix.map((row, i) =>
          row.map((val, j) => (
            <Input
              key={`${i}-${j}`}
              type="text"
              value={val}
              onChange={(e) => updateValue(i, j, e.target.value)}
              className="h-10 text-center text-sm font-mono"
            />
          )),
        )}
      </div>
    </div>
  )

  const renderResultMatrix = (m: number[][]) => (
    <div
      className="grid gap-1 p-3 bg-primary/5 rounded-lg border-2 border-primary/20"
      style={{ gridTemplateColumns: `repeat(${m[0].length}, 1fr)` }}
    >
      {m.map((row, i) =>
        row.map((val, j) => (
          <div
            key={`${i}-${j}`}
            className="h-10 flex items-center justify-center text-sm font-mono bg-background rounded border"
          >
            {formatNumber(val)}
          </div>
        )),
      )}
    </div>
  )

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Grid3X3 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Matrix Calculator</CardTitle>
                    <CardDescription>Perform matrix operations</CardDescription>
                  </div>
                </div>

                {/* Operation Selection */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Operation</Label>
                  <div className="grid grid-cols-4 gap-1">
                    {operationButtons.map(({ op, label, icon }) => (
                      <button
                        key={op}
                        onClick={() => setOperation(op)}
                        className={`flex flex-col items-center justify-center p-2 rounded-lg text-xs font-medium transition-all ${
                          operation === op
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted hover:bg-muted/80 text-muted-foreground"
                        }`}
                      >
                        {icon}
                        <span className="mt-1">{label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Matrix A */}
                {renderMatrixInput(matrixA, rowsA, colsA, "Matrix A", updateMatrixAValue, updateMatrixASize)}

                {/* Matrix B (if needed) */}
                {needsSecondMatrix &&
                  renderMatrixInput(matrixB, rowsB, colsB, "Matrix B", updateMatrixBValue, updateMatrixBSize)}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-2">Result</p>
                      {result.matrix ? (
                        renderResultMatrix(result.matrix)
                      ) : (
                        <p className="text-4xl font-bold text-green-600">{formatNumber(result.scalar!)}</p>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Matrix Operations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <span className="font-medium text-blue-700">A + B / A − B</span>
                    <p className="text-sm text-blue-600 mt-1">Element-wise addition/subtraction (same dimensions)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <span className="font-medium text-green-700">A × B</span>
                    <p className="text-sm text-green-600 mt-1">Matrix multiplication (cols of A = rows of B)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <span className="font-medium text-purple-700">det(A) / A⁻¹ / tr(A)</span>
                    <p className="text-sm text-purple-600 mt-1">Determinant, inverse, trace (square matrices only)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <span className="font-medium text-orange-700">Aᵀ / rank(A)</span>
                    <p className="text-sm text-orange-600 mt-1">Transpose and rank (any matrix)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">det(2×2) = ad − bc</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">(AB)ᵀ = BᵀAᵀ</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">A × A⁻¹ = I</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium">Note</p>
                      <p className="mt-1">
                        This calculator supports matrices up to 5×5. Results are rounded to 4 decimal places. Verify
                        manually for critical calculations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Matrices?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A matrix is a rectangular array of numbers, symbols, or expressions arranged in rows and columns. The
                  individual items in a matrix are called elements or entries. Matrices are fundamental tools in linear
                  algebra and are used extensively in mathematics, physics, engineering, computer graphics, statistics,
                  and many other fields. A matrix with m rows and n columns is called an m×n matrix, and the dimensions
                  determine which operations can be performed on it.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of matrices was developed in the mid-19th century by mathematicians like Arthur Cayley and
                  James Joseph Sylvester. Today, matrices are indispensable in solving systems of linear equations,
                  representing linear transformations, analyzing networks, processing images, and implementing machine
                  learning algorithms. Understanding matrix operations opens doors to advanced mathematical concepts and
                  real-world applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Matrix Operations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Addition and Subtraction:</strong> Two matrices can be added or subtracted only if they have
                  the same dimensions. The operation is performed element by element—the element in row i, column j of
                  the result is the sum (or difference) of the corresponding elements in the input matrices. These
                  operations are commutative for addition (A + B = B + A) but not for subtraction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Multiplication:</strong> Matrix multiplication is more complex. To multiply matrix A (size
                  m×n) by matrix B (size p×q), the number of columns in A must equal the number of rows in B (n = p).
                  The resulting matrix will have dimensions m×q. Each element is calculated by taking the dot product of
                  the corresponding row from A and column from B. Unlike addition, matrix multiplication is not
                  commutative—AB generally does not equal BA.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Transpose:</strong> The transpose of a matrix A, denoted Aᵀ, is formed by interchanging its
                  rows and columns. If A is an m×n matrix, then Aᵀ is an n×m matrix. The element at position (i,j) in A
                  becomes the element at position (j,i) in Aᵀ. Transposition is useful in many applications, including
                  solving systems of equations and computing matrix products.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Grid3X3 className="h-5 w-5 text-primary" />
                  <CardTitle>Square Matrix Operations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Determinant:</strong> The determinant is a scalar value computed from a square matrix that
                  provides important information about the matrix. For a 2×2 matrix [[a,b],[c,d]], the determinant is
                  ad−bc. For larger matrices, the determinant is calculated recursively using cofactor expansion. A
                  non-zero determinant indicates the matrix is invertible, while a zero determinant means the matrix is
                  singular.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Inverse:</strong> The inverse of a square matrix A, denoted A⁻¹, is the matrix that when
                  multiplied by A gives the identity matrix (A × A⁻¹ = I). Not all matrices have inverses—only those
                  with non-zero determinants (non-singular matrices) are invertible. The inverse is crucial for solving
                  systems of linear equations: if Ax = b, then x = A⁻¹b.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Trace and Rank:</strong> The trace of a square matrix is the sum of its diagonal elements.
                  It's a simple but useful measure with properties like tr(A+B) = tr(A) + tr(B). The rank of a matrix is
                  the maximum number of linearly independent rows (or columns). It determines the dimension of the
                  vector space spanned by its rows or columns and is essential in understanding systems of equations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Matrices have countless practical applications across various fields. In computer graphics, matrices
                  represent transformations like rotation, scaling, and translation of objects in 2D and 3D space. Every
                  video game and animation software relies heavily on matrix operations. In physics and engineering,
                  matrices describe systems of equations, stress tensors, and quantum mechanical states.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In data science and machine learning, matrices are the backbone of neural networks and statistical
                  analysis. Images are represented as matrices of pixel values, enabling operations like filtering,
                  compression, and feature extraction. Google's PageRank algorithm, which revolutionized web search,
                  uses matrix operations on massive sparse matrices representing web link structures. Understanding
                  matrices is essential for anyone working in these rapidly growing fields.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
