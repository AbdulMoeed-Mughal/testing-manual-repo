"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Waves, Info } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type WavelengthUnit = "m" | "cm" | "mm" | "ft"
type FrequencyUnit = "Hz" | "kHz" | "MHz" | "GHz"
type SpeedUnit = "m/s" | "km/s" | "ft/s"
type WaveType = "sound" | "light" | "water" | "custom"

interface WaveSpeedResult {
  speed: number
  category: string
  color: string
  bgColor: string
}

export function WaveSpeedCalculator() {
  const [wavelength, setWavelength] = useState("")
  const [wavelengthUnit, setWavelengthUnit] = useState<WavelengthUnit>("m")
  const [frequency, setFrequency] = useState("")
  const [frequencyUnit, setFrequencyUnit] = useState<FrequencyUnit>("Hz")
  const [speedUnit, setSpeedUnit] = useState<SpeedUnit>("m/s")
  const [waveType, setWaveType] = useState<WaveType>("custom")
  const [result, setResult] = useState<WaveSpeedResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const wavelengthToMeters: Record<WavelengthUnit, number> = {
    m: 1,
    cm: 0.01,
    mm: 0.001,
    ft: 0.3048,
  }

  const frequencyToHz: Record<FrequencyUnit, number> = {
    Hz: 1,
    kHz: 1000,
    MHz: 1000000,
    GHz: 1000000000,
  }

  const speedConversion: Record<SpeedUnit, number> = {
    "m/s": 1,
    "km/s": 0.001,
    "ft/s": 3.28084,
  }

  const handleWaveTypeClick = (type: WaveType) => {
    setWaveType(type)
    if (type === "sound") {
      // Sound in air at 20°C: ~343 m/s
      setWavelength("1")
      setWavelengthUnit("m")
      setFrequency("343")
      setFrequencyUnit("Hz")
    } else if (type === "light") {
      // Light in vacuum: ~3×10⁸ m/s
      setWavelength("500")
      setWavelengthUnit("mm")
      setFrequency("600")
      setFrequencyUnit("GHz")
    } else if (type === "water") {
      // Water waves: ~1.5 m/s (typical)
      setWavelength("3")
      setWavelengthUnit("m")
      setFrequency("0.5")
      setFrequencyUnit("Hz")
    }
  }

  const calculateWaveSpeed = () => {
    setError("")
    setResult(null)

    const wavelengthNum = Number.parseFloat(wavelength)
    const frequencyNum = Number.parseFloat(frequency)

    if (isNaN(wavelengthNum) || wavelengthNum <= 0) {
      setError("Please enter a valid wavelength greater than 0")
      return
    }

    if (isNaN(frequencyNum) || frequencyNum <= 0) {
      setError("Please enter a valid frequency greater than 0")
      return
    }

    // Convert to base units
    const wavelengthInMeters = wavelengthNum * wavelengthToMeters[wavelengthUnit]
    const frequencyInHz = frequencyNum * frequencyToHz[frequencyUnit]

    // Calculate wave speed: v = λ × f
    const speedInMetersPerSecond = wavelengthInMeters * frequencyInHz

    // Convert to selected unit
    const speedInSelectedUnit = speedInMetersPerSecond * speedConversion[speedUnit]

    let category: string
    let color: string
    let bgColor: string

    if (speedInMetersPerSecond < 100) {
      category = "Low Speed (Mechanical Waves)"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (speedInMetersPerSecond < 1000) {
      category = "Moderate Speed (Sound Range)"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (speedInMetersPerSecond < 100000000) {
      category = "High Speed (Electromagnetic)"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Speed of Light Range"
      color = "text-purple-600"
      bgColor = "bg-purple-50 border-purple-200"
    }

    setResult({
      speed: speedInSelectedUnit,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setWavelength("")
    setFrequency("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
    setWaveType("custom")
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Wave speed: ${result.speed.toFixed(2)} ${speedUnit} (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Wave Speed Calculation",
          text: `I calculated a wave speed using CalcHub! Speed: ${result.speed.toFixed(2)} ${speedUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Waves className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Wave Speed Calculator</CardTitle>
                    <CardDescription>Calculate wave propagation speed</CardDescription>
                  </div>
                </div>

                {/* Wave Type Presets */}
                <div className="pt-3">
                  <Label className="text-sm text-muted-foreground mb-2 block">Quick Presets</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleWaveTypeClick("sound")}
                      className={waveType === "sound" ? "bg-primary text-primary-foreground" : ""}
                    >
                      Sound
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleWaveTypeClick("light")}
                      className={waveType === "light" ? "bg-primary text-primary-foreground" : ""}
                    >
                      Light
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleWaveTypeClick("water")}
                      className={waveType === "water" ? "bg-primary text-primary-foreground" : ""}
                    >
                      Water
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Wavelength Input */}
                <div className="space-y-2">
                  <Label htmlFor="wavelength">Wavelength (λ)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="wavelength"
                      type="number"
                      placeholder="Enter wavelength"
                      value={wavelength}
                      onChange={(e) => setWavelength(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <select
                      value={wavelengthUnit}
                      onChange={(e) => setWavelengthUnit(e.target.value as WavelengthUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="m">m</option>
                      <option value="cm">cm</option>
                      <option value="mm">mm</option>
                      <option value="ft">ft</option>
                    </select>
                  </div>
                </div>

                {/* Frequency Input */}
                <div className="space-y-2">
                  <Label htmlFor="frequency">Frequency (f)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="frequency"
                      type="number"
                      placeholder="Enter frequency"
                      value={frequency}
                      onChange={(e) => setFrequency(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <select
                      value={frequencyUnit}
                      onChange={(e) => setFrequencyUnit(e.target.value as FrequencyUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="Hz">Hz</option>
                      <option value="kHz">kHz</option>
                      <option value="MHz">MHz</option>
                      <option value="GHz">GHz</option>
                    </select>
                  </div>
                </div>

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="speedUnit">Speed Unit</Label>
                  <select
                    id="speedUnit"
                    value={speedUnit}
                    onChange={(e) => setSpeedUnit(e.target.value as SpeedUnit)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="m/s">m/s</option>
                    <option value="km/s">km/s</option>
                    <option value="ft/s">ft/s</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWaveSpeed} className="w-full" size="lg">
                  Calculate Wave Speed
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-3">
                    <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Wave Speed</p>
                        <p className={`text-4xl font-bold ${result.color} mb-2`}>
                          {result.speed.toFixed(2)} {speedUnit}
                        </p>
                        <p className={`text-sm font-semibold ${result.color}`}>{result.category}</p>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>

                    {/* Step-by-step Toggle */}
                    <Button variant="outline" onClick={() => setShowSteps(!showSteps)} className="w-full">
                      <Info className="mr-2 h-4 w-4" />
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {/* Calculation Steps */}
                    {showSteps && (
                      <div className="p-4 bg-muted rounded-lg space-y-2 text-sm">
                        <p className="font-semibold">Step-by-step calculation:</p>
                        <div className="space-y-1 text-muted-foreground">
                          <p>1. Convert wavelength to meters:</p>
                          <p className="pl-4">
                            λ = {wavelength} {wavelengthUnit} ={" "}
                            {(Number.parseFloat(wavelength) * wavelengthToMeters[wavelengthUnit]).toExponential(3)} m
                          </p>
                          <p>2. Convert frequency to Hz:</p>
                          <p className="pl-4">
                            f = {frequency} {frequencyUnit} ={" "}
                            {(Number.parseFloat(frequency) * frequencyToHz[frequencyUnit]).toExponential(3)} Hz
                          </p>
                          <p>3. Apply formula v = λ × f:</p>
                          <p className="pl-4">
                            v = {(Number.parseFloat(wavelength) * wavelengthToMeters[wavelengthUnit]).toExponential(3)}{" "}
                            × {(Number.parseFloat(frequency) * frequencyToHz[frequencyUnit]).toExponential(3)}
                          </p>
                          <p className="pl-4">
                            v ={" "}
                            {(
                              Number.parseFloat(wavelength) *
                              wavelengthToMeters[wavelengthUnit] *
                              (Number.parseFloat(frequency) * frequencyToHz[frequencyUnit])
                            ).toExponential(3)}{" "}
                            m/s
                          </p>
                          <p>4. Convert to selected unit ({speedUnit}):</p>
                          <p className="pl-4 font-semibold">
                            v = {result.speed.toFixed(2)} {speedUnit}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Wave Speed Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">v = λ × f</p>
                  </div>
                  <p>
                    Where <strong>v</strong> is wave speed, <strong>λ</strong> (lambda) is wavelength, and{" "}
                    <strong>f</strong> is frequency.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Wave Speeds</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span>Light in vacuum</span>
                      <span className="font-semibold">~3×10⁸ m/s</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span>Sound in air (20°C)</span>
                      <span className="font-semibold">~343 m/s</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span>Sound in water</span>
                      <span className="font-semibold">~1480 m/s</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span>Sound in steel</span>
                      <span className="font-semibold">~5000 m/s</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Information */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Wave Speed</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Wave speed is the rate at which a wave propagates through a medium. It depends on both the wavelength
                  (the distance between successive wave peaks) and the frequency (how many waves pass a point per
                  second). The fundamental relationship v = λf shows that wave speed equals wavelength times frequency.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Different types of waves travel at different speeds depending on the medium. Electromagnetic waves
                  (like light) travel fastest in a vacuum, while mechanical waves (like sound) require a physical medium
                  and travel at speeds determined by the medium's properties such as density and elasticity.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Wave speed calculations assume ideal wave propagation. Actual speed may vary due to medium
                      properties, temperature, or environmental factors. Consult physics references for precise
                      analysis.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
