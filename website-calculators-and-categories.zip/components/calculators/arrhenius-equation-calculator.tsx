"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Activity } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "rateConstant" | "activationEnergy" | "temperature" | "preExponential"
type EnergyUnit = "kJ/mol" | "J/mol"
type TempUnit = "K" | "C"

interface ArrheniusResult {
  value: number
  unit: string
  label: string
}

export function ArrheniusEquationCalculator() {
  const [mode, setMode] = useState<CalculationMode>("rateConstant")
  const [activationEnergy, setActivationEnergy] = useState("")
  const [preExponentialFactor, setPreExponentialFactor] = useState("")
  const [temperature, setTemperature] = useState("")
  const [rateConstant, setRateConstant] = useState("")
  const [energyUnit, setEnergyUnit] = useState<EnergyUnit>("kJ/mol")
  const [tempUnit, setTempUnit] = useState<TempUnit>("K")
  const [result, setResult] = useState<ArrheniusResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const R = 8.314 // J/(mol·K)

  const modeLabels: Record<CalculationMode, string> = {
    rateConstant: "Rate Constant (k)",
    activationEnergy: "Activation Energy (Ea)",
    temperature: "Temperature (T)",
    preExponential: "Pre-exponential Factor (A)",
  }

  const convertEnergyToJoules = (value: number, unit: EnergyUnit): number => {
    return unit === "kJ/mol" ? value * 1000 : value
  }

  const convertEnergyFromJoules = (value: number, unit: EnergyUnit): number => {
    return unit === "kJ/mol" ? value / 1000 : value
  }

  const toKelvin = (temp: number, unit: TempUnit): number => {
    return unit === "C" ? temp + 273.15 : temp
  }

  const fromKelvin = (temp: number, unit: TempUnit): number => {
    return unit === "C" ? temp - 273.15 : temp
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const T = toKelvin(Number.parseFloat(temperature), tempUnit)
    const Ea = convertEnergyToJoules(Number.parseFloat(activationEnergy), energyUnit)
    const A = Number.parseFloat(preExponentialFactor)
    const k = Number.parseFloat(rateConstant)

    switch (mode) {
      case "rateConstant": {
        if (isNaN(Ea) || Ea <= 0) {
          setError("Please enter a valid activation energy greater than 0")
          return
        }
        if (isNaN(A) || A <= 0) {
          setError("Please enter a valid pre-exponential factor greater than 0")
          return
        }
        if (isNaN(T) || T <= 0) {
          setError("Please enter a valid temperature greater than 0 K")
          return
        }
        const calculatedK = A * Math.exp(-Ea / (R * T))
        setResult({
          value: calculatedK,
          unit: "s⁻¹",
          label: "Rate Constant (k)",
        })
        break
      }
      case "activationEnergy": {
        if (isNaN(k) || k <= 0) {
          setError("Please enter a valid rate constant greater than 0")
          return
        }
        if (isNaN(A) || A <= 0) {
          setError("Please enter a valid pre-exponential factor greater than 0")
          return
        }
        if (isNaN(T) || T <= 0) {
          setError("Please enter a valid temperature greater than 0 K")
          return
        }
        if (k >= A) {
          setError("Rate constant must be less than pre-exponential factor")
          return
        }
        const calculatedEa = -R * T * Math.log(k / A)
        setResult({
          value: convertEnergyFromJoules(calculatedEa, energyUnit),
          unit: energyUnit,
          label: "Activation Energy (Ea)",
        })
        break
      }
      case "temperature": {
        if (isNaN(k) || k <= 0) {
          setError("Please enter a valid rate constant greater than 0")
          return
        }
        if (isNaN(A) || A <= 0) {
          setError("Please enter a valid pre-exponential factor greater than 0")
          return
        }
        if (isNaN(Ea) || Ea <= 0) {
          setError("Please enter a valid activation energy greater than 0")
          return
        }
        if (k >= A) {
          setError("Rate constant must be less than pre-exponential factor")
          return
        }
        const calculatedT = -Ea / (R * Math.log(k / A))
        setResult({
          value: fromKelvin(calculatedT, tempUnit),
          unit: tempUnit === "K" ? "K" : "°C",
          label: "Temperature (T)",
        })
        break
      }
      case "preExponential": {
        if (isNaN(k) || k <= 0) {
          setError("Please enter a valid rate constant greater than 0")
          return
        }
        if (isNaN(Ea) || Ea <= 0) {
          setError("Please enter a valid activation energy greater than 0")
          return
        }
        if (isNaN(T) || T <= 0) {
          setError("Please enter a valid temperature greater than 0 K")
          return
        }
        const calculatedA = k / Math.exp(-Ea / (R * T))
        setResult({
          value: calculatedA,
          unit: "s⁻¹",
          label: "Pre-exponential Factor (A)",
        })
        break
      }
    }
  }

  const handleReset = () => {
    setActivationEnergy("")
    setPreExponentialFactor("")
    setTemperature("")
    setRateConstant("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`${result.label}: ${formatNumber(result.value)} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Arrhenius Equation Calculator Result",
          text: `${result.label}: ${formatNumber(result.value)} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 6 })
  }

  const toggleTempUnit = () => {
    setTempUnit((prev) => (prev === "K" ? "C" : "K"))
    setTemperature("")
    setResult(null)
  }

  const toggleEnergyUnit = () => {
    setEnergyUnit((prev) => (prev === "kJ/mol" ? "J/mol" : "kJ/mol"))
    setActivationEnergy("")
    setResult(null)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Arrhenius Equation Calculator</CardTitle>
                    <CardDescription>Calculate reaction kinetics parameters</CardDescription>
                  </div>
                </div>

                {/* Temperature Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Temperature Unit</span>
                  <button
                    onClick={toggleTempUnit}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        tempUnit === "C" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        tempUnit === "K" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Kelvin
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        tempUnit === "C" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Celsius
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Mode */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select value={mode} onValueChange={(v) => setMode(v as CalculationMode)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select what to calculate" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rateConstant">Rate Constant (k)</SelectItem>
                      <SelectItem value="activationEnergy">Activation Energy (Ea)</SelectItem>
                      <SelectItem value="temperature">Temperature (T)</SelectItem>
                      <SelectItem value="preExponential">Pre-exponential Factor (A)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Conditional Inputs based on mode */}
                {mode !== "activationEnergy" && (
                  <div className="space-y-2">
                    <Label htmlFor="activationEnergy">Activation Energy ({energyUnit})</Label>
                    <div className="flex gap-2">
                      <Input
                        id="activationEnergy"
                        type="number"
                        placeholder={`Enter activation energy`}
                        value={activationEnergy}
                        onChange={(e) => setActivationEnergy(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Button variant="outline" size="icon" onClick={toggleEnergyUnit} className="shrink-0">
                        {energyUnit === "kJ/mol" ? "kJ" : "J"}
                      </Button>
                    </div>
                  </div>
                )}

                {mode !== "preExponential" && (
                  <div className="space-y-2">
                    <Label htmlFor="preExponentialFactor">Pre-exponential Factor (A) s⁻¹</Label>
                    <Input
                      id="preExponentialFactor"
                      type="number"
                      placeholder="e.g., 1e13"
                      value={preExponentialFactor}
                      onChange={(e) => setPreExponentialFactor(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {mode !== "temperature" && (
                  <div className="space-y-2">
                    <Label htmlFor="temperature">Temperature ({tempUnit === "K" ? "K" : "°C"})</Label>
                    <Input
                      id="temperature"
                      type="number"
                      placeholder={`Enter temperature in ${tempUnit === "K" ? "Kelvin" : "Celsius"}`}
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                      step="any"
                    />
                  </div>
                )}

                {mode !== "rateConstant" && (
                  <div className="space-y-2">
                    <Label htmlFor="rateConstant">Rate Constant (k) s⁻¹</Label>
                    <Input
                      id="rateConstant"
                      type="number"
                      placeholder="e.g., 1e-5"
                      value={rateConstant}
                      onChange={(e) => setRateConstant(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {modeLabels[mode]}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{result.label}</p>
                      <p className="text-5xl font-bold text-purple-600 mb-2">{formatNumber(result.value)}</p>
                      <p className="text-lg font-semibold text-purple-600">{result.unit}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Arrhenius Equation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-4 bg-muted rounded-lg font-mono text-center">
                      <p className="font-semibold text-foreground">k = A × e<sup>(-Ea/RT)</sup></p>
                    </div>
                    <div className="text-sm text-muted-foreground space-y-2">
                      <p><strong>k</strong> = Rate constant</p>
                      <p><strong>A</strong> = Pre-exponential factor</p>
                      <p><strong>Ea</strong> = Activation energy</p>
                      <p><strong>R</strong> = 8.314 J/(mol·K)</p>
                      <p><strong>T</strong> = Temperature (K)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Linearized Form</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ln(k) = ln(A) - Ea/(RT)</p>
                  </div>
                  <p>
                    Plotting ln(k) vs 1/T gives a straight line with slope = -Ea/R and y-intercept = ln(A).
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Arrhenius Equation */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Arrhenius Equation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Arrhenius equation is a fundamental formula in chemical kinetics that describes how the rate
                  constant of a chemical reaction depends on temperature. Developed by Swedish chemist Svante
                  Arrhenius in 1889, this equation shows that reaction rates increase exponentially with temperature,
                  explaining why most chemical reactions proceed faster at higher temperatures.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equation reveals that only molecules with sufficient energy (equal to or greater than the
                  activation energy) can undergo a chemical transformation. As temperature increases, a larger
                  fraction of molecules possess the required activation energy, leading to faster reaction rates.
                </p>
              </CardContent>
            </Card>

            {/* Understanding Parameters */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Parameters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The <strong>activation energy (Ea)</strong> represents the minimum energy required for a reaction
                  to occur. Higher activation energies mean the reaction is more sensitive to temperature changes.
                  Typical values range from 40-400 kJ/mol for most chemical reactions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The <strong>pre-exponential factor (A)</strong>, also called the frequency factor, relates to
                  the frequency of molecular collisions with the correct orientation. It typically ranges from
                  10⁹ to 10¹⁵ s⁻¹ for unimolecular reactions.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of the Arrhenius Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Arrhenius equation is widely used in various fields. In industrial chemistry, it helps
                  optimize reaction conditions and predict how temperature changes affect production rates.
                  Food scientists use it to predict shelf life and determine optimal storage temperatures.
                  Pharmaceutical researchers apply it to study drug stability and degradation kinetics.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Materials scientists use the equation to understand aging processes in polymers and
                  semiconductors. Environmental chemists apply it to model atmospheric reactions and
                  pollutant degradation. The equation is also fundamental in biochemistry for understanding
                  enzyme kinetics and protein denaturation.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations of the Arrhenius Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the Arrhenius equation is widely applicable, it has limitations. It assumes that the
                  activation energy remains constant over the temperature range, which may not hold for complex
                  reactions or very wide temperature ranges. For some reactions, particularly those with multiple
                  steps or involving quantum tunneling, deviations from Arrhenius behavior may occur.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For more accurate predictions, especially for reactions in solution or catalyzed reactions,
                  modified forms like the Eyring equation (from transition state theory) may be more appropriate.
                  Always validate calculated parameters with experimental data when possible.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
