"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Zap,
  Info,
  AlertTriangle,
  Calculator,
  Superscript,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Operation = "power" | "square-root" | "cube-root" | "nth-root" | "exponential"
type DisplayFormat = "decimal" | "scientific"

interface Result {
  value: number
  formattedValue: string
  scientificValue: string
  explanation: string
}

export function PowerRootCalculator() {
  const [operation, setOperation] = useState<Operation>("power")
  const [displayFormat, setDisplayFormat] = useState<DisplayFormat>("decimal")
  const [base, setBase] = useState("")
  const [exponent, setExponent] = useState("")
  const [rootIndex, setRootIndex] = useState("")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const operations: { value: Operation; label: string; symbol: string }[] = [
    { value: "power", label: "Power", symbol: "xⁿ" },
    { value: "square-root", label: "Square Root", symbol: "√x" },
    { value: "cube-root", label: "Cube Root", symbol: "∛x" },
    { value: "nth-root", label: "nth Root", symbol: "ⁿ√x" },
    { value: "exponential", label: "Exponential", symbol: "eˣ" },
  ]

  const formatNumber = (num: number, format: DisplayFormat): string => {
    if (!isFinite(num)) return "Undefined"
    if (isNaN(num)) return "NaN"

    if (format === "scientific") {
      return num.toExponential(8)
    }

    // For very large or very small numbers, use scientific notation automatically
    if (Math.abs(num) >= 1e10 || (Math.abs(num) < 1e-6 && num !== 0)) {
      return num.toExponential(8)
    }

    // Round to 10 decimal places to avoid floating point errors
    return Number(num.toPrecision(10)).toString()
  }

  const getScientificNotation = (num: number): string => {
    if (!isFinite(num) || isNaN(num)) return "N/A"
    return num.toExponential(8)
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const baseNum = Number.parseFloat(base)

    if (operation !== "exponential" && isNaN(baseNum)) {
      setError("Please enter a valid base number")
      return
    }

    let value: number
    let explanation: string

    switch (operation) {
      case "power": {
        const expNum = Number.parseFloat(exponent)
        if (isNaN(expNum)) {
          setError("Please enter a valid exponent")
          return
        }

        // Check for negative base with non-integer exponent
        if (baseNum < 0 && !Number.isInteger(expNum)) {
          setError("Cannot raise a negative number to a non-integer power (result would be complex)")
          return
        }

        value = Math.pow(baseNum, expNum)
        explanation = `${baseNum}^${expNum} = ${baseNum} raised to the power of ${expNum}`
        break
      }

      case "square-root": {
        if (baseNum < 0) {
          setError("Cannot calculate square root of a negative number (result would be complex)")
          return
        }
        value = Math.sqrt(baseNum)
        explanation = `√${baseNum} = The square root of ${baseNum}`
        break
      }

      case "cube-root": {
        value = Math.cbrt(baseNum)
        explanation = `∛${baseNum} = The cube root of ${baseNum}`
        break
      }

      case "nth-root": {
        const n = Number.parseFloat(rootIndex)
        if (isNaN(n) || n === 0) {
          setError("Root index cannot be zero or empty")
          return
        }

        // Check for even root of negative number
        if (baseNum < 0 && n % 2 === 0) {
          setError("Cannot calculate even root of a negative number (result would be complex)")
          return
        }

        // For negative bases with odd roots
        if (baseNum < 0) {
          value = -Math.pow(Math.abs(baseNum), 1 / n)
        } else {
          value = Math.pow(baseNum, 1 / n)
        }
        explanation = `${baseNum}^(1/${n}) = The ${n}th root of ${baseNum}`
        break
      }

      case "exponential": {
        if (isNaN(baseNum)) {
          setError("Please enter a valid exponent for e^x")
          return
        }
        value = Math.exp(baseNum)
        explanation = `e^${baseNum} = Euler's number (≈2.71828) raised to the power of ${baseNum}`
        break
      }

      default:
        return
    }

    if (!isFinite(value)) {
      setError("Result is too large or undefined")
      return
    }

    setResult({
      value,
      formattedValue: formatNumber(value, displayFormat),
      scientificValue: getScientificNotation(value),
      explanation,
    })
  }

  const handleReset = () => {
    setBase("")
    setExponent("")
    setRootIndex("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Result: ${result.formattedValue}\n${result.explanation}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Power & Root Calculator Result",
          text: `${result.explanation}\nResult: ${result.formattedValue}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleDisplayFormat = () => {
    const newFormat = displayFormat === "decimal" ? "scientific" : "decimal"
    setDisplayFormat(newFormat)
    if (result) {
      setResult({
        ...result,
        formattedValue: formatNumber(result.value, newFormat),
      })
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Power & Root Calculator</CardTitle>
                    <CardDescription>Calculate powers, roots, and exponentials</CardDescription>
                  </div>
                </div>

                {/* Display Format Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Display Format</span>
                  <button
                    onClick={toggleDisplayFormat}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        displayFormat === "scientific" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        displayFormat === "decimal" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Decimal
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        displayFormat === "scientific" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Scientific
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Operation Selection */}
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {operations.map((op) => (
                      <button
                        key={op.value}
                        onClick={() => {
                          setOperation(op.value)
                          setResult(null)
                          setError("")
                        }}
                        className={`p-2 rounded-lg border text-sm font-medium transition-all ${
                          operation === op.value
                            ? "bg-blue-600 text-white border-blue-600"
                            : "bg-background border-border hover:bg-muted"
                        }`}
                      >
                        <div className="text-lg">{op.symbol}</div>
                        <div className="text-xs mt-1">{op.label}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Input Fields */}
                {operation === "power" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="base">Base (x)</Label>
                      <Input
                        id="base"
                        type="number"
                        placeholder="Enter base number"
                        value={base}
                        onChange={(e) => setBase(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="exponent">Exponent (n)</Label>
                      <Input
                        id="exponent"
                        type="number"
                        placeholder="Enter exponent"
                        value={exponent}
                        onChange={(e) => setExponent(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {(operation === "square-root" || operation === "cube-root") && (
                  <div className="space-y-2">
                    <Label htmlFor="base">Number {operation === "square-root" ? "(√x)" : "(∛x)"}</Label>
                    <Input
                      id="base"
                      type="number"
                      placeholder="Enter number"
                      value={base}
                      onChange={(e) => setBase(e.target.value)}
                      step="any"
                    />
                  </div>
                )}

                {operation === "nth-root" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="base">Number (x)</Label>
                      <Input
                        id="base"
                        type="number"
                        placeholder="Enter number"
                        value={base}
                        onChange={(e) => setBase(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rootIndex">Root Index (n)</Label>
                      <Input
                        id="rootIndex"
                        type="number"
                        placeholder="Enter root index (e.g., 4 for 4th root)"
                        value={rootIndex}
                        onChange={(e) => setRootIndex(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {operation === "exponential" && (
                  <div className="space-y-2">
                    <Label htmlFor="base">Exponent (x in e^x)</Label>
                    <Input
                      id="base"
                      type="number"
                      placeholder="Enter exponent for e^x"
                      value={base}
                      onChange={(e) => setBase(e.target.value)}
                      step="any"
                    />
                    <p className="text-xs text-muted-foreground">e ≈ 2.71828 (Euler's number)</p>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <p className="text-4xl font-bold text-blue-600 mb-2 break-all">{result.formattedValue}</p>
                      <p className="text-sm text-muted-foreground mb-1">Scientific: {result.scientificValue}</p>
                      <p className="text-sm text-blue-700 bg-blue-100 rounded-lg p-2 mt-2">{result.explanation}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Operations Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">xⁿ Power</span>
                      <span className="text-sm text-blue-600 font-mono">x^n</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">√x Square Root</span>
                      <span className="text-sm text-green-600 font-mono">x^(1/2)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">∛x Cube Root</span>
                      <span className="text-sm text-purple-600 font-mono">x^(1/3)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">ⁿ√x nth Root</span>
                      <span className="text-sm text-orange-600 font-mono">x^(1/n)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-teal-50 border border-teal-200">
                      <span className="font-medium text-teal-700">eˣ Exponential</span>
                      <span className="text-sm text-teal-600 font-mono">e^x</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono">2^10 = 1024</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono">√144 = 12</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono">∛27 = 3</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono">⁴√16 = 2</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono">e^1 ≈ 2.71828</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Disclaimer</p>
                      <p className="text-sm text-amber-700 mt-1">
                        This calculator provides estimates only. Verify manually for critical calculations. Complex
                        numbers are not supported.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Powers and Exponents</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Powers and exponents are fundamental mathematical concepts that represent repeated multiplication.
                  When we write x^n (x raised to the power of n), we mean multiplying x by itself n times. For example,
                  2^4 equals 2 × 2 × 2 × 2 = 16. This notation was developed to simplify the representation of large
                  numbers and complex calculations, making it essential in fields ranging from basic arithmetic to
                  advanced physics and engineering.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Exponents can be positive integers, negative numbers, fractions, or even irrational numbers. Positive
                  integer exponents are straightforward multiplication, while negative exponents represent reciprocals
                  (x^-n = 1/x^n). Fractional exponents connect powers to roots: x^(1/n) is the nth root of x, and
                  x^(m/n) means taking the nth root and then raising to the power m. Understanding these relationships
                  is crucial for solving equations and working with scientific notation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Roots Explained: Square, Cube, and Beyond</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Roots are the inverse operation of powers. The square root of a number x (written as √x) answers the
                  question: "What number, when multiplied by itself, gives x?" For instance, √25 = 5 because 5 × 5 = 25.
                  Similarly, the cube root (∛x) finds the number that, when cubed, equals x. So ∛8 = 2 because 2 × 2 × 2
                  = 8. These operations are essential in geometry, physics, and everyday calculations like finding the
                  side length of a square given its area.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept extends to nth roots for any positive integer n. The fourth root of 16 is 2 (because 2^4 =
                  16), and the fifth root of 32 is 2 (because 2^5 = 32). An important distinction exists between even
                  and odd roots: even roots of negative numbers don't exist in real numbers (√-4 is imaginary), while
                  odd roots of negative numbers are real (∛-8 = -2). This calculator works with real numbers and will
                  alert you when complex results would occur.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Superscript className="h-5 w-5 text-primary" />
                  <CardTitle>The Exponential Function and Euler's Number</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Euler's number, denoted as e, is one of the most important mathematical constants, approximately equal
                  to 2.71828. The exponential function e^x appears throughout mathematics and science, describing
                  natural growth and decay processes. Unlike other bases, e^x has the unique property that its
                  derivative equals itself, making it fundamental in calculus. This constant emerges naturally when
                  studying compound interest, population growth, radioactive decay, and countless other phenomena.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The exponential function e^x grows faster than any polynomial as x increases and approaches zero (but
                  never reaches it) as x becomes very negative. This behavior makes it ideal for modeling situations
                  where growth rate is proportional to current size. In finance, continuous compound interest uses
                  e^(rt) where r is the rate and t is time. In physics, radioactive decay follows e^(-λt) where λ is the
                  decay constant. Understanding e^x opens doors to advanced mathematics including complex analysis and
                  differential equations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Powers and roots have countless real-world applications. In geometry, the Pythagorean theorem (a² + b²
                  = c²) uses squares and square roots to find distances. Computer science relies heavily on powers of 2:
                  binary systems, memory sizes (1024 = 2^10 bytes in a kilobyte), and algorithm complexity analysis.
                  Finance uses compound interest formulas involving exponents to calculate investment growth, and
                  physics employs these concepts in equations describing motion, energy, and wave behavior.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Scientific notation, which expresses numbers as a coefficient times a power of 10, is essential for
                  working with very large or very small quantities. Astronomers describe distances in space (the Sun is
                  about 1.5 × 10^11 meters from Earth), while chemists work with Avogadro's number (6.022 × 10^23).
                  Engineers use decibels (a logarithmic scale based on powers of 10) to measure sound intensity.
                  Understanding powers and roots is not just academic—it's a practical skill that enhances your ability
                  to solve real problems in science, technology, and everyday life.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
