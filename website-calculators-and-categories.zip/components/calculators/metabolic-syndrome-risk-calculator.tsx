"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Activity,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Heart,
  Droplets,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"

interface RiskFactor {
  name: string
  present: boolean
  value: string
  threshold: string
}

interface MetabolicSyndromeResult {
  riskFactors: RiskFactor[]
  totalRiskFactors: number
  riskCategory: string
  color: string
  bgColor: string
  hasMetabolicSyndrome: boolean
}

export function MetabolicSyndromeRiskCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [waist, setWaist] = useState("")
  const [fastingGlucose, setFastingGlucose] = useState("")
  const [glucoseUnit, setGlucoseUnit] = useState<"mg/dL" | "mmol/L">("mg/dL")
  const [systolic, setSystolic] = useState("")
  const [diastolic, setDiastolic] = useState("")
  const [triglycerides, setTriglycerides] = useState("")
  const [triglyceridesUnit, setTriglyceridesUnit] = useState<"mg/dL" | "mmol/L">("mg/dL")
  const [hdl, setHdl] = useState("")
  const [hdlUnit, setHdlUnit] = useState<"mg/dL" | "mmol/L">("mg/dL")
  const [result, setResult] = useState<MetabolicSyndromeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateRisk = () => {
    setError("")
    setResult(null)

    // Validate inputs
    const ageNum = Number.parseFloat(age)
    const waistNum = Number.parseFloat(waist)
    const glucoseNum = Number.parseFloat(fastingGlucose)
    const systolicNum = Number.parseFloat(systolic)
    const diastolicNum = Number.parseFloat(diastolic)
    const triglyceridesNum = Number.parseFloat(triglycerides)
    const hdlNum = Number.parseFloat(hdl)

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (isNaN(waistNum) || waistNum <= 0) {
      setError("Please enter a valid waist circumference")
      return
    }

    if (isNaN(glucoseNum) || glucoseNum <= 0) {
      setError("Please enter a valid fasting glucose level")
      return
    }

    if (isNaN(systolicNum) || systolicNum <= 0 || isNaN(diastolicNum) || diastolicNum <= 0) {
      setError("Please enter valid blood pressure values")
      return
    }

    if (diastolicNum >= systolicNum) {
      setError("Diastolic pressure must be lower than systolic pressure")
      return
    }

    if (isNaN(triglyceridesNum) || triglyceridesNum <= 0) {
      setError("Please enter a valid triglycerides level")
      return
    }

    if (isNaN(hdlNum) || hdlNum <= 0) {
      setError("Please enter a valid HDL cholesterol level")
      return
    }

    // Convert units to standard (mg/dL for glucose, triglycerides, HDL; cm for waist)
    const waistCm = unitSystem === "imperial" ? waistNum * 2.54 : waistNum
    const glucoseMgDl = glucoseUnit === "mmol/L" ? glucoseNum * 18 : glucoseNum
    const triglyceridesMgDl = triglyceridesUnit === "mmol/L" ? triglyceridesNum * 88.57 : triglyceridesNum
    const hdlMgDl = hdlUnit === "mmol/L" ? hdlNum * 38.67 : hdlNum

    // ATP III criteria thresholds
    const waistThreshold = gender === "male" ? 102 : 88 // cm
    const hdlThreshold = gender === "male" ? 40 : 50 // mg/dL

    const riskFactors: RiskFactor[] = []

    // 1. Abdominal obesity
    const waistRisk = waistCm > waistThreshold
    riskFactors.push({
      name: "Abdominal Obesity",
      present: waistRisk,
      value: `${waistCm.toFixed(1)} cm`,
      threshold: `>${waistThreshold} cm (${gender})`,
    })

    // 2. High triglycerides
    const triglyceridesRisk = triglyceridesMgDl >= 150
    riskFactors.push({
      name: "High Triglycerides",
      present: triglyceridesRisk,
      value: `${triglyceridesMgDl.toFixed(0)} mg/dL`,
      threshold: "≥150 mg/dL",
    })

    // 3. Low HDL cholesterol
    const hdlRisk = hdlMgDl < hdlThreshold
    riskFactors.push({
      name: "Low HDL Cholesterol",
      present: hdlRisk,
      value: `${hdlMgDl.toFixed(0)} mg/dL`,
      threshold: `<${hdlThreshold} mg/dL (${gender})`,
    })

    // 4. Elevated blood pressure
    const bpRisk = systolicNum >= 130 || diastolicNum >= 85
    riskFactors.push({
      name: "Elevated Blood Pressure",
      present: bpRisk,
      value: `${systolicNum}/${diastolicNum} mmHg`,
      threshold: "≥130/85 mmHg",
    })

    // 5. Elevated fasting glucose
    const glucoseRisk = glucoseMgDl >= 100
    riskFactors.push({
      name: "Elevated Fasting Glucose",
      present: glucoseRisk,
      value: `${glucoseMgDl.toFixed(0)} mg/dL`,
      threshold: "≥100 mg/dL",
    })

    const totalRiskFactors = riskFactors.filter((rf) => rf.present).length
    const hasMetabolicSyndrome = totalRiskFactors >= 3

    let riskCategory: string
    let color: string
    let bgColor: string

    if (totalRiskFactors === 0) {
      riskCategory = "Low Risk"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (totalRiskFactors <= 2) {
      riskCategory = "Moderate Risk"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      riskCategory = "High Risk"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      riskFactors,
      totalRiskFactors,
      riskCategory,
      color,
      bgColor,
      hasMetabolicSyndrome,
    })
  }

  const handleReset = () => {
    setAge("")
    setWaist("")
    setFastingGlucose("")
    setSystolic("")
    setDiastolic("")
    setTriglycerides("")
    setHdl("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Metabolic Syndrome Risk Assessment: ${result.totalRiskFactors}/5 risk factors present - ${result.riskCategory}${result.hasMetabolicSyndrome ? " (Metabolic Syndrome criteria met)" : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Metabolic Syndrome Risk Assessment",
          text: `My metabolic syndrome risk assessment: ${result.totalRiskFactors}/5 risk factors - ${result.riskCategory}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWaist("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Metabolic Syndrome Risk</CardTitle>
                    <CardDescription>Assess your metabolic health risk</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setGender("male")}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        gender === "male"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted hover:border-muted-foreground/30"
                      }`}
                    >
                      Male
                    </button>
                    <button
                      onClick={() => setGender("female")}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        gender === "female"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted hover:border-muted-foreground/30"
                      }`}
                    >
                      Female
                    </button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Waist Circumference */}
                <div className="space-y-2">
                  <Label htmlFor="waist">Waist Circumference ({unitSystem === "metric" ? "cm" : "inches"})</Label>
                  <Input
                    id="waist"
                    type="number"
                    placeholder={`Enter waist in ${unitSystem === "metric" ? "cm" : "inches"}`}
                    value={waist}
                    onChange={(e) => setWaist(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Blood Pressure */}
                <div className="space-y-2">
                  <Label>Blood Pressure (mmHg)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      type="number"
                      placeholder="Systolic"
                      value={systolic}
                      onChange={(e) => setSystolic(e.target.value)}
                      min="0"
                    />
                    <Input
                      type="number"
                      placeholder="Diastolic"
                      value={diastolic}
                      onChange={(e) => setDiastolic(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>

                {/* Fasting Glucose */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="glucose">Fasting Glucose</Label>
                    <select
                      value={glucoseUnit}
                      onChange={(e) => setGlucoseUnit(e.target.value as "mg/dL" | "mmol/L")}
                      className="text-xs border rounded px-2 py-1"
                    >
                      <option value="mg/dL">mg/dL</option>
                      <option value="mmol/L">mmol/L</option>
                    </select>
                  </div>
                  <Input
                    id="glucose"
                    type="number"
                    placeholder={`Enter fasting glucose in ${glucoseUnit}`}
                    value={fastingGlucose}
                    onChange={(e) => setFastingGlucose(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Triglycerides */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="triglycerides">Triglycerides</Label>
                    <select
                      value={triglyceridesUnit}
                      onChange={(e) => setTriglyceridesUnit(e.target.value as "mg/dL" | "mmol/L")}
                      className="text-xs border rounded px-2 py-1"
                    >
                      <option value="mg/dL">mg/dL</option>
                      <option value="mmol/L">mmol/L</option>
                    </select>
                  </div>
                  <Input
                    id="triglycerides"
                    type="number"
                    placeholder={`Enter triglycerides in ${triglyceridesUnit}`}
                    value={triglycerides}
                    onChange={(e) => setTriglycerides(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* HDL Cholesterol */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="hdl">HDL Cholesterol</Label>
                    <select
                      value={hdlUnit}
                      onChange={(e) => setHdlUnit(e.target.value as "mg/dL" | "mmol/L")}
                      className="text-xs border rounded px-2 py-1"
                    >
                      <option value="mg/dL">mg/dL</option>
                      <option value="mmol/L">mmol/L</option>
                    </select>
                  </div>
                  <Input
                    id="hdl"
                    type="number"
                    placeholder={`Enter HDL in ${hdlUnit}`}
                    value={hdl}
                    onChange={(e) => setHdl(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRisk} className="w-full" size="lg">
                  Assess Risk
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Risk Factors Present</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.totalRiskFactors}/5</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.riskCategory}</p>
                      {result.hasMetabolicSyndrome && (
                        <div className="mt-2 p-2 bg-red-100 rounded-lg">
                          <p className="text-sm font-medium text-red-700">
                            <AlertTriangle className="h-4 w-4 inline mr-1" />
                            Metabolic Syndrome Criteria Met (≥3 factors)
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          Hide Details <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Details <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 space-y-2">
                        {result.riskFactors.map((factor, index) => (
                          <div
                            key={index}
                            className={`p-3 rounded-lg border ${
                              factor.present ? "bg-red-50 border-red-200" : "bg-green-50 border-green-200"
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className={`font-medium ${factor.present ? "text-red-700" : "text-green-700"}`}>
                                {factor.name}
                              </span>
                              <span className={`text-sm ${factor.present ? "text-red-600" : "text-green-600"}`}>
                                {factor.present ? "At Risk" : "Normal"}
                              </span>
                            </div>
                            <div className="mt-1 text-xs text-muted-foreground">
                              Your value: {factor.value} | Threshold: {factor.threshold}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">ATP III Criteria</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Metabolic syndrome is diagnosed when 3 or more of these criteria are met:
                  </p>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Abdominal Obesity</p>
                      <p className="text-xs text-muted-foreground">
                        Waist: {">"} 102 cm (men) / {">"} 88 cm (women)
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">High Triglycerides</p>
                      <p className="text-xs text-muted-foreground">≥ 150 mg/dL (1.7 mmol/L)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Low HDL Cholesterol</p>
                      <p className="text-xs text-muted-foreground">
                        {"<"} 40 mg/dL (men) / {"<"} 50 mg/dL (women)
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Elevated Blood Pressure</p>
                      <p className="text-xs text-muted-foreground">≥ 130/85 mmHg</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Elevated Fasting Glucose</p>
                      <p className="text-xs text-muted-foreground">≥ 100 mg/dL (5.6 mmol/L)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Risk Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low Risk</span>
                      <span className="text-sm text-green-600">0 factors</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Risk</span>
                      <span className="text-sm text-yellow-600">1-2 factors</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">High Risk</span>
                      <span className="text-sm text-red-600">3+ factors</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Metabolic Syndrome?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Metabolic syndrome is a cluster of interconnected metabolic abnormalities that significantly increase
                  the risk of cardiovascular disease, type 2 diabetes, stroke, and other serious health conditions.
                  Rather than being a single disease, it represents a combination of risk factors that tend to occur
                  together and amplify each other's harmful effects on the body.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The syndrome affects approximately 25-30% of adults in developed countries, with prevalence increasing
                  with age. It is closely linked to insulin resistance, where the body's cells don't respond effectively
                  to insulin, leading to elevated blood sugar levels. This condition is often associated with excess
                  abdominal fat, sedentary lifestyle, and poor dietary habits.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Health Risks Associated with Metabolic Syndrome</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Having metabolic syndrome dramatically increases your risk of developing serious health conditions.
                  People with metabolic syndrome are twice as likely to develop heart disease and five times more likely
                  to develop type 2 diabetes compared to those without the syndrome. The combination of risk factors
                  creates a synergistic effect that is more dangerous than each factor alone.
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Cardiovascular Risks</h4>
                    <ul className="text-sm text-red-700 space-y-1">
                      <li>Heart attack</li>
                      <li>Stroke</li>
                      <li>Atherosclerosis</li>
                      <li>Peripheral artery disease</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Metabolic Risks</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>Type 2 diabetes</li>
                      <li>Non-alcoholic fatty liver</li>
                      <li>Polycystic ovary syndrome</li>
                      <li>Sleep apnea</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>How to Reduce Your Risk</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The good news is that metabolic syndrome is largely preventable and reversible through lifestyle
                  modifications. Even modest improvements in diet, exercise, and weight can significantly reduce your
                  risk factors and improve your overall metabolic health.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-800">Weight Management</p>
                    <p className="text-sm text-green-700">
                      Losing 5-10% of body weight can significantly improve all metabolic syndrome components
                    </p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-800">Regular Exercise</p>
                    <p className="text-sm text-blue-700">
                      Aim for 150+ minutes of moderate aerobic activity weekly, plus strength training
                    </p>
                  </div>
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-medium text-purple-800">Healthy Diet</p>
                    <p className="text-sm text-purple-700">
                      Focus on whole grains, fruits, vegetables, lean proteins, and healthy fats
                    </p>
                  </div>
                  <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                    <p className="font-medium text-orange-800">Quit Smoking</p>
                    <p className="text-sm text-orange-700">
                      Smoking worsens insulin resistance and increases cardiovascular risk
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Important Medical Disclaimer</p>
                    <p>
                      This calculator provides an estimate of metabolic syndrome risk based on the ATP III criteria and
                      is not a medical diagnosis. It is intended for educational purposes only. Please consult a
                      healthcare professional for proper evaluation, diagnosis, and personalized medical advice. Lab
                      values should be obtained from certified medical laboratories.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
