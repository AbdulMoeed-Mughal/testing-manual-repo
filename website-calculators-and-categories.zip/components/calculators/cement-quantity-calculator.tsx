"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Package,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface CementResult {
  concreteVolume: number
  concreteVolumeWithWaste: number
  cementVolume: number
  cementWeight: number
  cementBags: number
  sandVolume: number
  sandWeight: number
  aggregateVolume: number
  aggregateWeight: number
  waterVolume: number
}

export function CementQuantityCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [volume, setVolume] = useState("")
  const [cementRatio, setCementRatio] = useState("1")
  const [sandRatio, setSandRatio] = useState("2")
  const [aggregateRatio, setAggregateRatio] = useState("4")
  const [bagWeight, setBagWeight] = useState("50")
  const [wastePercentage, setWastePercentage] = useState("5")
  const [result, setResult] = useState<CementResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Densities (kg/m³)
  const CEMENT_DENSITY = 1440
  const SAND_DENSITY = 1600
  const AGGREGATE_DENSITY = 1500

  // Common mix ratios
  const mixPresets = [
    { name: "M15 (1:2:4)", cement: "1", sand: "2", aggregate: "4" },
    { name: "M20 (1:1.5:3)", cement: "1", sand: "1.5", aggregate: "3" },
    { name: "M25 (1:1:2)", cement: "1", sand: "1", aggregate: "2" },
    { name: "M10 (1:3:6)", cement: "1", sand: "3", aggregate: "6" },
  ]

  const calculateCement = () => {
    setError("")
    setResult(null)

    const volumeNum = Number.parseFloat(volume)
    const cementRatioNum = Number.parseFloat(cementRatio)
    const sandRatioNum = Number.parseFloat(sandRatio)
    const aggregateRatioNum = Number.parseFloat(aggregateRatio)
    const bagWeightNum = Number.parseFloat(bagWeight)
    const wasteNum = Number.parseFloat(wastePercentage)

    if (isNaN(volumeNum) || volumeNum <= 0) {
      setError("Please enter a valid concrete volume greater than 0")
      return
    }

    if (isNaN(cementRatioNum) || cementRatioNum <= 0) {
      setError("Please enter a valid cement ratio greater than 0")
      return
    }

    if (isNaN(sandRatioNum) || sandRatioNum < 0) {
      setError("Please enter a valid sand ratio (0 or greater)")
      return
    }

    if (isNaN(aggregateRatioNum) || aggregateRatioNum < 0) {
      setError("Please enter a valid aggregate ratio (0 or greater)")
      return
    }

    if (isNaN(bagWeightNum) || bagWeightNum <= 0) {
      setError("Please enter a valid bag weight greater than 0")
      return
    }

    if (isNaN(wasteNum) || wasteNum < 0) {
      setError("Please enter a valid waste percentage (0 or greater)")
      return
    }

    // Convert volume to m³ if imperial
    let volumeInM3 = volumeNum
    if (unitSystem === "imperial") {
      volumeInM3 = volumeNum * 0.0283168 // ft³ to m³
    }

    // Apply waste
    const volumeWithWaste = volumeInM3 * (1 + wasteNum / 100)

    // Total parts in mix ratio
    const totalParts = cementRatioNum + sandRatioNum + aggregateRatioNum

    // Dry volume factor (concrete shrinks when wet, so dry volume is ~1.54x wet volume)
    const dryVolumeFactor = 1.54

    // Calculate dry volume
    const dryVolume = volumeWithWaste * dryVolumeFactor

    // Calculate individual volumes
    const cementVolume = (cementRatioNum / totalParts) * dryVolume
    const sandVolume = (sandRatioNum / totalParts) * dryVolume
    const aggregateVolume = (aggregateRatioNum / totalParts) * dryVolume

    // Calculate weights
    const cementWeight = cementVolume * CEMENT_DENSITY
    const sandWeight = sandVolume * SAND_DENSITY
    const aggregateWeight = aggregateVolume * AGGREGATE_DENSITY

    // Calculate number of cement bags
    const bagWeightInKg = unitSystem === "imperial" ? bagWeightNum * 0.453592 : bagWeightNum
    const cementBags = Math.ceil(cementWeight / bagWeightInKg)

    // Water (approximately 0.45-0.55 water-cement ratio, using 0.5)
    const waterVolume = (cementWeight * 0.5) / 1000 // in liters (1000 kg/m³ for water)

    setResult({
      concreteVolume: volumeInM3,
      concreteVolumeWithWaste: volumeWithWaste,
      cementVolume,
      cementWeight,
      cementBags,
      sandVolume,
      sandWeight,
      aggregateVolume,
      aggregateWeight,
      waterVolume: waterVolume * 1000, // Convert to liters
    })
  }

  const handleReset = () => {
    setVolume("")
    setCementRatio("1")
    setSandRatio("2")
    setAggregateRatio("4")
    setBagWeight("50")
    setWastePercentage("5")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Cement Quantity Calculation:
- Concrete Volume: ${result.concreteVolumeWithWaste.toFixed(2)} m³
- Cement: ${result.cementWeight.toFixed(1)} kg (${result.cementBags} bags)
- Sand: ${result.sandWeight.toFixed(1)} kg
- Aggregate: ${result.aggregateWeight.toFixed(1)} kg
- Water: ${result.waterVolume.toFixed(1)} liters`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Cement Quantity Calculation",
          text: `Cement needed: ${result.cementWeight.toFixed(1)} kg (${result.cementBags} bags) for ${result.concreteVolumeWithWaste.toFixed(2)} m³ concrete`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setVolume("")
    setBagWeight(unitSystem === "metric" ? "110" : "50")
    setResult(null)
    setError("")
  }

  const applyPreset = (preset: (typeof mixPresets)[0]) => {
    setCementRatio(preset.cement)
    setSandRatio(preset.sand)
    setAggregateRatio(preset.aggregate)
  }

  const formatWeight = (kg: number) => {
    if (unitSystem === "imperial") {
      return `${(kg * 2.20462).toFixed(1)} lb`
    }
    return `${kg.toFixed(1)} kg`
  }

  const formatVolume = (m3: number) => {
    if (unitSystem === "imperial") {
      return `${(m3 * 35.3147).toFixed(2)} ft³`
    }
    return `${m3.toFixed(3)} m³`
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Package className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Cement Quantity Calculator</CardTitle>
                    <CardDescription>Calculate cement needed for concrete mix</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Volume Input */}
                <div className="space-y-2">
                  <Label htmlFor="volume">Concrete Volume ({unitSystem === "metric" ? "m³" : "ft³"})</Label>
                  <Input
                    id="volume"
                    type="number"
                    placeholder={`Enter volume in ${unitSystem === "metric" ? "cubic meters" : "cubic feet"}`}
                    value={volume}
                    onChange={(e) => setVolume(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Mix Ratio Presets */}
                <div className="space-y-2">
                  <Label>Mix Ratio Presets</Label>
                  <div className="flex flex-wrap gap-2">
                    {mixPresets.map((preset) => (
                      <Button
                        key={preset.name}
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => applyPreset(preset)}
                        className={
                          cementRatio === preset.cement &&
                          sandRatio === preset.sand &&
                          aggregateRatio === preset.aggregate
                            ? "border-amber-500 bg-amber-50 text-amber-700"
                            : ""
                        }
                      >
                        {preset.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Mix Ratio Inputs */}
                <div className="space-y-2">
                  <Label>Mix Ratio (Cement : Sand : Aggregate)</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Input
                        type="number"
                        placeholder="Cement"
                        value={cementRatio}
                        onChange={(e) => setCementRatio(e.target.value)}
                        min="0"
                        step="0.5"
                      />
                      <span className="text-xs text-muted-foreground mt-1 block text-center">Cement</span>
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Sand"
                        value={sandRatio}
                        onChange={(e) => setSandRatio(e.target.value)}
                        min="0"
                        step="0.5"
                      />
                      <span className="text-xs text-muted-foreground mt-1 block text-center">Sand</span>
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Aggregate"
                        value={aggregateRatio}
                        onChange={(e) => setAggregateRatio(e.target.value)}
                        min="0"
                        step="0.5"
                      />
                      <span className="text-xs text-muted-foreground mt-1 block text-center">Aggregate</span>
                    </div>
                  </div>
                </div>

                {/* Bag Weight & Waste */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bagWeight">Bag Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                    <Input
                      id="bagWeight"
                      type="number"
                      placeholder={unitSystem === "metric" ? "50" : "110"}
                      value={bagWeight}
                      onChange={(e) => setBagWeight(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="waste">Waste (%)</Label>
                    <Input
                      id="waste"
                      type="number"
                      placeholder="5"
                      value={wastePercentage}
                      onChange={(e) => setWastePercentage(e.target.value)}
                      min="0"
                      max="50"
                      step="1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCement} className="w-full" size="lg">
                  Calculate Cement Quantity
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Cement Required</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">{formatWeight(result.cementWeight)}</p>
                      <p className="text-2xl font-semibold text-amber-700">{result.cementBags} bags</p>
                    </div>

                    {/* Material Breakdown */}
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                        <span className="text-sm font-medium">Cement</span>
                        <span className="text-sm">
                          {formatWeight(result.cementWeight)} ({result.cementBags} bags)
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                        <span className="text-sm font-medium">Sand</span>
                        <span className="text-sm">{formatWeight(result.sandWeight)}</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                        <span className="text-sm font-medium">Aggregate</span>
                        <span className="text-sm">{formatWeight(result.aggregateWeight)}</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                        <span className="text-sm font-medium">Water (approx.)</span>
                        <span className="text-sm">{result.waterVolume.toFixed(0)} liters</span>
                      </div>
                    </div>

                    {/* Step-by-step calculation */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-between w-full p-2 bg-white rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors"
                    >
                      <span>Step-by-Step Calculation</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-2 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Concrete volume = {formatVolume(result.concreteVolume)}
                        </p>
                        <p>
                          <strong>Step 2:</strong> With {wastePercentage}% waste ={" "}
                          {formatVolume(result.concreteVolumeWithWaste)}
                        </p>
                        <p>
                          <strong>Step 3:</strong> Dry volume = {formatVolume(result.concreteVolumeWithWaste)} × 1.54 ={" "}
                          {formatVolume(result.concreteVolumeWithWaste * 1.54)}
                        </p>
                        <p>
                          <strong>Step 4:</strong> Total parts = {cementRatio} + {sandRatio} + {aggregateRatio} ={" "}
                          {Number(cementRatio) + Number(sandRatio) + Number(aggregateRatio)}
                        </p>
                        <p>
                          <strong>Step 5:</strong> Cement volume = {formatVolume(result.cementVolume)}
                        </p>
                        <p>
                          <strong>Step 6:</strong> Cement weight = {formatVolume(result.cementVolume)} × 1440 kg/m³ ={" "}
                          {formatWeight(result.cementWeight)}
                        </p>
                        <p>
                          <strong>Step 7:</strong> Number of bags = {result.cementWeight.toFixed(1)} ÷ {bagWeight} ={" "}
                          {result.cementBags} bags
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Mix Ratios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M10 (1:3:6)</span>
                      <span className="text-sm text-amber-600">PCC, Leveling</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">M15 (1:2:4)</span>
                      <span className="text-sm text-blue-600">Light Duty</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">M20 (1:1.5:3)</span>
                      <span className="text-sm text-green-600">General RCC</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">M25 (1:1:2)</span>
                      <span className="text-sm text-purple-600">Structural</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cement Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Dry Volume = Wet Volume × 1.54</p>
                    <p className="font-semibold text-foreground text-xs mt-2">
                      Cement = (Cement Ratio ÷ Total Parts) × Dry Vol
                    </p>
                  </div>
                  <p>
                    The dry volume factor of 1.54 accounts for voids in dry materials that get filled when mixed with
                    water and compacted.
                  </p>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Estimation Notice</p>
                      <p>
                        Results are estimates. Actual cement requirements may vary due to mix consistency, site
                        conditions, and compaction.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Cement Quantity Calculation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating the correct quantity of cement is crucial for any concrete construction project. Cement
                  acts as the binding agent in concrete, holding sand and aggregate together to form a strong, durable
                  material. Using the right amount ensures structural integrity while avoiding waste and cost overruns.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The calculation involves understanding mix ratios, which express the proportional relationship between
                  cement, sand, and aggregate. Common ratios like 1:2:4 (M15) or 1:1.5:3 (M20) indicate the relative
                  volumes of each component. The total parts help determine what fraction of the concrete volume is
                  cement.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  <CardTitle>The Dry Volume Factor</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When calculating cement quantities, we multiply the wet (final) concrete volume by a factor of
                  approximately 1.54 to get the dry volume of materials needed. This factor accounts for the voids
                  present in dry materials that get filled during mixing and compaction.
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Why 1.54?</h4>
                    <p className="text-blue-700 text-sm">
                      Dry materials contain air voids. When mixed with water and compacted, these voids are filled,
                      reducing the total volume by about 35%.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Practical Tip</h4>
                    <p className="text-green-700 text-sm">
                      Always add 5-10% extra material to account for spillage, waste, and variations in material
                      quality.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Cement Quantity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Mix Ratio</h4>
                    <p className="text-sm text-muted-foreground">
                      Higher cement ratios (like M25) require more cement but produce stronger concrete. Choose based on
                      structural requirements.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Aggregate Size</h4>
                    <p className="text-sm text-muted-foreground">
                      Larger aggregates have fewer voids, potentially reducing cement requirements. Standard
                      calculations assume typical graded aggregate.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Water-Cement Ratio</h4>
                    <p className="text-sm text-muted-foreground">
                      Typically 0.45-0.55 for workable concrete. More water improves workability but reduces strength.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Site Conditions</h4>
                    <p className="text-sm text-muted-foreground">
                      Spillage, uneven ground, and formwork absorption can increase actual cement needs by 5-15%.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
