"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Flame, Info, AlertTriangle, Beaker } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type VolumeUnit = "mL" | "L"
type HeatUnit = "J" | "kJ"

interface NeutralizationResult {
  heat: number
  molesAcid: number
  molesBase: number
  limitingReactant: string
  isExothermic: boolean
}

export function HeatOfNeutralizationCalculator() {
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("mL")
  const [heatUnit, setHeatUnit] = useState<HeatUnit>("kJ")
  const [acidConcentration, setAcidConcentration] = useState("")
  const [acidVolume, setAcidVolume] = useState("")
  const [baseConcentration, setBaseConcentration] = useState("")
  const [baseVolume, setBaseVolume] = useState("")
  const [deltaH, setDeltaH] = useState("-57.32")
  const [result, setResult] = useState<NeutralizationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const Ca = Number.parseFloat(acidConcentration)
    const Va = Number.parseFloat(acidVolume)
    const Cb = Number.parseFloat(baseConcentration)
    const Vb = Number.parseFloat(baseVolume)
    const dH = Number.parseFloat(deltaH)

    if (isNaN(Ca) || Ca <= 0) {
      setError("Please enter a valid acid concentration greater than 0")
      return
    }
    if (isNaN(Va) || Va <= 0) {
      setError("Please enter a valid acid volume greater than 0")
      return
    }
    if (isNaN(Cb) || Cb <= 0) {
      setError("Please enter a valid base concentration greater than 0")
      return
    }
    if (isNaN(Vb) || Vb <= 0) {
      setError("Please enter a valid base volume greater than 0")
      return
    }
    if (isNaN(dH)) {
      setError("Please enter a valid enthalpy of neutralization")
      return
    }

    // Convert volumes to liters if needed
    const VaL = volumeUnit === "mL" ? Va / 1000 : Va
    const VbL = volumeUnit === "mL" ? Vb / 1000 : Vb

    // Calculate moles
    const molesAcid = Ca * VaL
    const molesBase = Cb * VbL

    // Determine limiting reactant and moles reacting
    const limitingMoles = Math.min(molesAcid, molesBase)
    const limitingReactant = molesAcid <= molesBase ? "Acid" : "Base"

    // Calculate heat (q = n × ΔH)
    // ΔH is typically in kJ/mol for neutralization
    let heat = limitingMoles * dH

    // Convert heat to selected unit
    if (heatUnit === "J") {
      heat = heat * 1000
    }

    const isExothermic = heat < 0

    setResult({
      heat: Math.round(heat * 1000) / 1000,
      molesAcid: Math.round(molesAcid * 10000) / 10000,
      molesBase: Math.round(molesBase * 10000) / 10000,
      limitingReactant,
      isExothermic,
    })
  }

  const handleReset = () => {
    setAcidConcentration("")
    setAcidVolume("")
    setBaseConcentration("")
    setBaseVolume("")
    setDeltaH("-57.32")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Heat of Neutralization: ${Math.abs(result.heat)} ${heatUnit} (${result.isExothermic ? "Exothermic" : "Endothermic"})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Heat of Neutralization Result",
          text: `Heat of Neutralization: ${Math.abs(result.heat)} ${heatUnit} (${result.isExothermic ? "Exothermic" : "Endothermic"})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const toggleVolumeUnit = () => {
    setVolumeUnit((prev) => (prev === "mL" ? "L" : "mL"))
    setAcidVolume("")
    setBaseVolume("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Heat of Neutralization</CardTitle>
                    <CardDescription>Calculate heat released in acid-base reactions</CardDescription>
                  </div>
                </div>

                {/* Volume Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Volume Unit</span>
                  <button
                    onClick={toggleVolumeUnit}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        volumeUnit === "L" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        volumeUnit === "mL" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      mL
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        volumeUnit === "L" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      L
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Heat Unit Selection */}
                <div className="space-y-2">
                  <Label>Heat Unit</Label>
                  <div className="flex gap-2">
                    {(["kJ", "J"] as HeatUnit[]).map((unit) => (
                      <button
                        key={unit}
                        onClick={() => setHeatUnit(unit)}
                        className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                          heatUnit === unit
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {unit}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Acid Inputs */}
                <div className="p-3 rounded-lg bg-red-50/50 border border-red-100 space-y-3">
                  <Label className="text-red-700 font-medium">Acid</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label htmlFor="acidConc" className="text-xs text-muted-foreground">
                        Concentration (mol/L)
                      </Label>
                      <Input
                        id="acidConc"
                        type="number"
                        placeholder="e.g., 1.0"
                        value={acidConcentration}
                        onChange={(e) => setAcidConcentration(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="acidVol" className="text-xs text-muted-foreground">
                        Volume ({volumeUnit})
                      </Label>
                      <Input
                        id="acidVol"
                        type="number"
                        placeholder={volumeUnit === "mL" ? "e.g., 50" : "e.g., 0.05"}
                        value={acidVolume}
                        onChange={(e) => setAcidVolume(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                </div>

                {/* Base Inputs */}
                <div className="p-3 rounded-lg bg-blue-50/50 border border-blue-100 space-y-3">
                  <Label className="text-blue-700 font-medium">Base</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label htmlFor="baseConc" className="text-xs text-muted-foreground">
                        Concentration (mol/L)
                      </Label>
                      <Input
                        id="baseConc"
                        type="number"
                        placeholder="e.g., 1.0"
                        value={baseConcentration}
                        onChange={(e) => setBaseConcentration(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="baseVol" className="text-xs text-muted-foreground">
                        Volume ({volumeUnit})
                      </Label>
                      <Input
                        id="baseVol"
                        type="number"
                        placeholder={volumeUnit === "mL" ? "e.g., 50" : "e.g., 0.05"}
                        value={baseVolume}
                        onChange={(e) => setBaseVolume(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                </div>

                {/* Enthalpy Input */}
                <div className="space-y-2">
                  <Label htmlFor="deltaH">Enthalpy of Neutralization (kJ/mol)</Label>
                  <Input
                    id="deltaH"
                    type="number"
                    placeholder="-57.32"
                    value={deltaH}
                    onChange={(e) => setDeltaH(e.target.value)}
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">
                    Default: -57.32 kJ/mol (strong acid + strong base)
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Heat
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.isExothermic
                        ? "bg-red-50 border-red-200"
                        : "bg-blue-50 border-blue-200"
                    }`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Heat of Neutralization</p>
                      <p
                        className={`text-5xl font-bold mb-2 ${
                          result.isExothermic ? "text-red-600" : "text-blue-600"
                        }`}
                      >
                        {result.heat}
                      </p>
                      <p className="text-lg font-medium text-muted-foreground">{heatUnit}</p>
                      <p
                        className={`text-sm font-semibold mt-2 ${
                          result.isExothermic ? "text-red-600" : "text-blue-600"
                        }`}
                      >
                        {result.isExothermic ? "Exothermic (Heat Released)" : "Endothermic (Heat Absorbed)"}
                      </p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                      <div className="p-2 rounded bg-white/60">
                        <p className="text-muted-foreground">Moles of Acid</p>
                        <p className="font-medium">{result.molesAcid} mol</p>
                      </div>
                      <div className="p-2 rounded bg-white/60">
                        <p className="text-muted-foreground">Moles of Base</p>
                        <p className="font-medium">{result.molesBase} mol</p>
                      </div>
                      <div className="col-span-2 p-2 rounded bg-white/60">
                        <p className="text-muted-foreground">Limiting Reactant</p>
                        <p className="font-medium">{result.limitingReactant}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Enthalpy Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Strong Acid + Strong Base</span>
                      <span className="text-sm text-purple-600">-57.32 kJ/mol</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50/70 border border-purple-200">
                      <span className="font-medium text-purple-700">Weak Acid + Strong Base</span>
                      <span className="text-sm text-purple-600">-55 to -57 kJ/mol</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50/50 border border-purple-200">
                      <span className="font-medium text-purple-700">Strong Acid + Weak Base</span>
                      <span className="text-sm text-purple-600">-52 to -57 kJ/mol</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50/30 border border-purple-200">
                      <span className="font-medium text-purple-700">Weak Acid + Weak Base</span>
                      <span className="text-sm text-purple-600">Varies widely</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">q = n × ΔH</p>
                  </div>
                  <p>
                    Where <strong>n</strong> is the moles of limiting reactant and{" "}
                    <strong>ΔH</strong> is the enthalpy of neutralization.
                  </p>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">n = C × V</p>
                  </div>
                  <p>
                    Moles are calculated from concentration (C) in mol/L and volume (V) in liters.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Heat of Neutralization */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Heat of Neutralization?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Heat of neutralization is the enthalpy change that occurs when an acid and a base react to form water
                  and a salt. This is a fundamental concept in thermochemistry and is typically an exothermic process,
                  meaning heat is released to the surroundings. For strong acid-strong base reactions, the heat of
                  neutralization is approximately constant at -57.32 kJ/mol because the net ionic equation is always
                  the same: H⁺(aq) + OH⁻(aq) → H₂O(l).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The heat of neutralization provides important information about the energy changes in acid-base
                  reactions and is used extensively in calorimetry experiments, industrial processes, and understanding
                  chemical thermodynamics. It helps chemists predict and control temperature changes during neutralization
                  reactions in various applications.
                </p>
              </CardContent>
            </Card>

            {/* How It Works */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>How the Calculation Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation first determines the number of moles of acid and base present by multiplying their
                  concentrations by their respective volumes. The limiting reactant is then identified as the one
                  with fewer moles, since in a 1:1 neutralization reaction, equal moles of acid and base react
                  completely.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Once the limiting moles are determined, the heat released or absorbed is calculated using the
                  equation q = n × ΔH, where n is the moles of limiting reactant and ΔH is the enthalpy of
                  neutralization. The sign of the result indicates whether the process is exothermic (negative,
                  heat released) or endothermic (positive, heat absorbed).
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting Heat */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Heat of Neutralization</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence the actual heat of neutralization observed in experiments. For strong
                  acid-strong base reactions, the value is nearly constant because both the acid and base are fully
                  dissociated in solution. However, when weak acids or weak bases are involved, additional energy
                  is required for their dissociation, which reduces the overall heat released.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature, concentration, and the specific identity of the acid and base also play roles. Heat
                  losses to the calorimeter and surroundings, incomplete mixing, and heat capacity of the solution
                  can affect experimental measurements. In precision work, these factors must be carefully controlled
                  and accounted for to obtain accurate results.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculations assume complete neutralization with no heat loss to the surroundings. Actual
                  experimental heat values may vary due to solution properties, calorimeter efficiency, incomplete
                  reactions, or heat exchange with the environment. The default enthalpy value (-57.32 kJ/mol) is
                  specific to strong acid-strong base reactions at 25°C and may not apply to all acid-base combinations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For weak acids or weak bases, the enthalpy of neutralization will differ from the standard value.
                  Always consult thermodynamic tables or perform calorimetric experiments to determine accurate
                  enthalpy values for specific reaction systems. This calculator is intended for educational purposes
                  and preliminary calculations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
