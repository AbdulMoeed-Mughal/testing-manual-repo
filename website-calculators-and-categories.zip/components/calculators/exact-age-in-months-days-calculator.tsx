"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface AgeResult {
  years: number
  months: number
  days: number
  totalMonths: number
}

export function ExactAgeInMonthsDaysCalculator() {
  const [dateOfBirth, setDateOfBirth] = useState("")
  const [currentDate, setCurrentDate] = useState(new Date().toISOString().split("T")[0])
  const [includeCurrentDay, setIncludeCurrentDay] = useState(false)
  const [result, setResult] = useState<AgeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateAge = () => {
    setError("")
    setResult(null)

    if (!dateOfBirth) {
      setError("Please enter your date of birth")
      return
    }

    const birthDate = new Date(dateOfBirth)
    const current = new Date(currentDate)

    if (birthDate > current) {
      setError("Date of birth cannot be in the future")
      return
    }

    if (isNaN(birthDate.getTime())) {
      setError("Please enter a valid date of birth")
      return
    }

    let years = current.getFullYear() - birthDate.getFullYear()
    let months = current.getMonth() - birthDate.getMonth()
    let days = current.getDate() - birthDate.getDate()

    // Adjust for negative days
    if (days < 0) {
      months--
      const lastMonth = new Date(current.getFullYear(), current.getMonth(), 0)
      days += lastMonth.getDate()
    }

    // Adjust for negative months
    if (months < 0) {
      years--
      months += 12
    }

    // Include current day if option selected
    if (includeCurrentDay) {
      days++
      if (days > new Date(current.getFullYear(), current.getMonth() + 1, 0).getDate()) {
        days = 1
        months++
        if (months >= 12) {
          months = 0
          years++
        }
      }
    }

    const totalMonths = years * 12 + months

    setResult({ years, months, days, totalMonths })
  }

  const handleReset = () => {
    setDateOfBirth("")
    setCurrentDate(new Date().toISOString().split("T")[0])
    setIncludeCurrentDay(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Age: ${result.years} years, ${result.months} months, and ${result.days} days (${result.totalMonths} total months)`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Exact Age",
          text: `I calculated my exact age using CalcHub! I'm ${result.years} years, ${result.months} months, and ${result.days} days old.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Exact Age Calculator</CardTitle>
                    <CardDescription>Calculate age in months and days</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Date of Birth Input */}
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                {/* Current Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="currentDate">Current Date</Label>
                  <Input
                    id="currentDate"
                    type="date"
                    value={currentDate}
                    onChange={(e) => setCurrentDate(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                {/* Include Current Day Checkbox */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="includeCurrentDay"
                    checked={includeCurrentDay}
                    onCheckedChange={(checked) => setIncludeCurrentDay(checked as boolean)}
                  />
                  <label
                    htmlFor="includeCurrentDay"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Include current day in calculation
                  </label>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAge} className="w-full" size="lg">
                  Calculate Age
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-cyan-200">
                        <p className="text-sm text-muted-foreground mb-2">Exact Age</p>
                        <p className="text-3xl font-bold text-cyan-600">
                          {result.years} years, {result.months} months, {result.days} days
                        </p>
                      </div>

                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-2xl font-bold text-cyan-600">{result.years}</p>
                          <p className="text-xs text-muted-foreground">Years</p>
                        </div>
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-2xl font-bold text-cyan-600">{result.months}</p>
                          <p className="text-xs text-muted-foreground">Months</p>
                        </div>
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-2xl font-bold text-cyan-600">{result.days}</p>
                          <p className="text-xs text-muted-foreground">Days</p>
                        </div>
                      </div>

                      <div className="text-center pt-2">
                        <p className="text-sm text-cyan-700">
                          Total: <span className="font-semibold">{result.totalMonths}</span> months
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Age Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <div className="flex items-start gap-2">
                      <div className="h-5 w-5 rounded-full bg-cyan-100 text-cyan-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-bold">Y</span>
                      </div>
                      <p>
                        <strong className="text-foreground">Years</strong> represent complete 12-month periods from
                        birth
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="h-5 w-5 rounded-full bg-cyan-100 text-cyan-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-bold">M</span>
                      </div>
                      <p>
                        <strong className="text-foreground">Months</strong> represent full calendar months beyond
                        complete years
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="h-5 w-5 rounded-full bg-cyan-100 text-cyan-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-bold">D</span>
                      </div>
                      <p>
                        <strong className="text-foreground">Days</strong> represent remaining days beyond full months
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>The calculator accounts for varying month lengths and leap years automatically.</p>
                  <p>Total months provides the cumulative number of complete months lived.</p>
                  <p>Enable "Include current day" to count today as part of your age.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Exact Age */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Exact Age in Months and Days?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Exact age in months and days provides a precise measurement of someone's age beyond just years. This
                  detailed breakdown is particularly useful for infant development tracking, medical applications, legal
                  documentation, and situations where precise age matters. While we commonly think of age in whole
                  years, months and days provide critical additional detail for many important purposes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculation method takes into account the varying lengths of months (28-31 days) and
                  automatically adjusts for leap years. The result gives you three components: complete years since
                  birth, remaining complete months, and leftover days. Together, these provide the most accurate
                  representation of elapsed time since birth.
                </p>
              </CardContent>
            </Card>

            {/* Common Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Common Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Infant and Child Development</h4>
                    <p className="text-cyan-700 text-sm">
                      Pediatricians track developmental milestones using exact age in months. A child who is 2 years and
                      3 months old has different expected capabilities than one who is 2 years and 11 months old, making
                      this precision crucial for health assessments.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Legal and Official Documents</h4>
                    <p className="text-cyan-700 text-sm">
                      Legal proceedings, insurance policies, and official documentation often require exact age
                      calculations. Some eligibility criteria depend on reaching specific age thresholds measured in
                      days, not just years.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Anniversary Tracking</h4>
                    <p className="text-cyan-700 text-sm">
                      Celebrating milestones becomes more meaningful with exact dates. Whether it's 1000 days since an
                      event, 100 months of a relationship, or tracking project timelines, precise duration matters.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <div className="p-4 bg-muted rounded-lg border border-border text-sm text-muted-foreground">
              <p className="font-medium text-foreground mb-2">Note:</p>
              <p>
                Exact age calculations are based on entered dates and may vary slightly due to leap years and calendar
                differences. The calculator automatically accounts for months with different numbers of days and leap
                year adjustments.
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
