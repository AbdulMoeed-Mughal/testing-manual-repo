"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Atom, Thermometer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type CalculationMethod = "mass" | "gas"

interface MolesResult {
  moles: number
  method: string
  massUsed?: number
  molarMass?: number
  pressure?: number
  volume?: number
  temperature?: number
  category: string
  color: string
  bgColor: string
}

export function MolesCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("mass")
  const [mass, setMass] = useState("")
  const [massUnit, setMassUnit] = useState("g")
  const [molarMass, setMolarMass] = useState("")
  const [pressure, setPressure] = useState("")
  const [pressureUnit, setPressureUnit] = useState("atm")
  const [volume, setVolume] = useState("")
  const [volumeUnit, setVolumeUnit] = useState("L")
  const [temperature, setTemperature] = useState("")
  const [temperatureUnit, setTemperatureUnit] = useState("K")
  const [result, setResult] = useState<MolesResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const GAS_CONSTANT = 0.0821 // L·atm/(mol·K)

  const convertMassToGrams = (value: number, unit: string): number => {
    switch (unit) {
      case "kg": return value * 1000
      case "mg": return value / 1000
      default: return value // g
    }
  }

  const convertPressureToAtm = (value: number, unit: string): number => {
    switch (unit) {
      case "kPa": return value / 101.325
      case "Pa": return value / 101325
      case "bar": return value / 1.01325
      case "mmHg": return value / 760
      case "psi": return value / 14.696
      default: return value // atm
    }
  }

  const convertVolumeToLiters = (value: number, unit: string): number => {
    switch (unit) {
      case "mL": return value / 1000
      case "m3": return value * 1000
      case "cm3": return value / 1000
      default: return value // L
    }
  }

  const convertTemperatureToKelvin = (value: number, unit: string): number => {
    switch (unit) {
      case "C": return value + 273.15
      case "F": return (value - 32) * 5/9 + 273.15
      default: return value // K
    }
  }

  const getMolesCategory = (moles: number): { category: string; color: string; bgColor: string } => {
    if (moles < 0.001) {
      return { category: "Micromolar Range", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    } else if (moles < 0.1) {
      return { category: "Millimolar Range", color: "text-cyan-600", bgColor: "bg-cyan-50 border-cyan-200" }
    } else if (moles < 1) {
      return { category: "Sub-Molar Range", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    } else if (moles < 10) {
      return { category: "Standard Range", color: "text-purple-600", bgColor: "bg-purple-50 border-purple-200" }
    } else {
      return { category: "Large Scale", color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    }
  }

  const calculateMoles = () => {
    setError("")
    setResult(null)

    if (method === "mass") {
      const massNum = Number.parseFloat(mass)
      const molarMassNum = Number.parseFloat(molarMass)

      if (isNaN(massNum) || massNum <= 0) {
        setError("Please enter a valid mass greater than 0")
        return
      }
      if (isNaN(molarMassNum) || molarMassNum <= 0) {
        setError("Please enter a valid molar mass greater than 0")
        return
      }

      const massInGrams = convertMassToGrams(massNum, massUnit)
      const moles = massInGrams / molarMassNum
      const { category, color, bgColor } = getMolesCategory(moles)

      setResult({
        moles,
        method: "Mass-based (n = m / M)",
        massUsed: massInGrams,
        molarMass: molarMassNum,
        category,
        color,
        bgColor
      })
    } else {
      const pressureNum = Number.parseFloat(pressure)
      const volumeNum = Number.parseFloat(volume)
      const temperatureNum = Number.parseFloat(temperature)

      if (isNaN(pressureNum) || pressureNum <= 0) {
        setError("Please enter a valid pressure greater than 0")
        return
      }
      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }
      if (isNaN(temperatureNum)) {
        setError("Please enter a valid temperature")
        return
      }

      const pressureInAtm = convertPressureToAtm(pressureNum, pressureUnit)
      const volumeInLiters = convertVolumeToLiters(volumeNum, volumeUnit)
      const temperatureInKelvin = convertTemperatureToKelvin(temperatureNum, temperatureUnit)

      if (temperatureInKelvin <= 0) {
        setError("Temperature must be above absolute zero (0 K)")
        return
      }

      const moles = (pressureInAtm * volumeInLiters) / (GAS_CONSTANT * temperatureInKelvin)
      const { category, color, bgColor } = getMolesCategory(moles)

      setResult({
        moles,
        method: "Ideal Gas Law (n = PV / RT)",
        pressure: pressureInAtm,
        volume: volumeInLiters,
        temperature: temperatureInKelvin,
        category,
        color,
        bgColor
      })
    }
  }

  const handleReset = () => {
    setMass("")
    setMolarMass("")
    setPressure("")
    setVolume("")
    setTemperature("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Number of moles: ${result.moles.toExponential(4)} mol (${result.method})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Moles Calculation Result",
          text: `I calculated ${result.moles.toExponential(4)} mol using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num < 0.0001 || num >= 10000) {
      return num.toExponential(4)
    }
    return num.toFixed(6).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2 bg-transparent">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Number of Moles Calculator</CardTitle>
                    <CardDescription>Calculate moles from mass or gas properties</CardDescription>
                  </div>
                </div>

                {/* Method Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Method</span>
                  <button
                    onClick={() => {
                      setMethod(method === "mass" ? "gas" : "mass")
                      handleReset()
                    }}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        method === "gas" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "mass" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Mass
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "gas" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Gas
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {method === "mass" ? (
                  <>
                    {/* Mass Input */}
                    <div className="space-y-2">
                      <Label htmlFor="mass">Mass (m)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="mass"
                          type="number"
                          placeholder="Enter mass"
                          value={mass}
                          onChange={(e) => setMass(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <Select value={massUnit} onValueChange={setMassUnit}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="g">g</SelectItem>
                            <SelectItem value="kg">kg</SelectItem>
                            <SelectItem value="mg">mg</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Molar Mass Input */}
                    <div className="space-y-2">
                      <Label htmlFor="molarMass">Molar Mass (M)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="molarMass"
                          type="number"
                          placeholder="Enter molar mass"
                          value={molarMass}
                          onChange={(e) => setMolarMass(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <div className="flex items-center justify-center w-20 bg-muted rounded-md text-sm text-muted-foreground">
                          g/mol
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Pressure Input */}
                    <div className="space-y-2">
                      <Label htmlFor="pressure">Pressure (P)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="pressure"
                          type="number"
                          placeholder="Enter pressure"
                          value={pressure}
                          onChange={(e) => setPressure(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <Select value={pressureUnit} onValueChange={setPressureUnit}>
                          <SelectTrigger className="w-24">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="atm">atm</SelectItem>
                            <SelectItem value="kPa">kPa</SelectItem>
                            <SelectItem value="Pa">Pa</SelectItem>
                            <SelectItem value="bar">bar</SelectItem>
                            <SelectItem value="mmHg">mmHg</SelectItem>
                            <SelectItem value="psi">psi</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Volume Input */}
                    <div className="space-y-2">
                      <Label htmlFor="volume">Volume (V)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="volume"
                          type="number"
                          placeholder="Enter volume"
                          value={volume}
                          onChange={(e) => setVolume(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <Select value={volumeUnit} onValueChange={setVolumeUnit}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="L">L</SelectItem>
                            <SelectItem value="mL">mL</SelectItem>
                            <SelectItem value="m3">m³</SelectItem>
                            <SelectItem value="cm3">cm³</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Temperature Input */}
                    <div className="space-y-2">
                      <Label htmlFor="temperature">Temperature (T)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="temperature"
                          type="number"
                          placeholder="Enter temperature"
                          value={temperature}
                          onChange={(e) => setTemperature(e.target.value)}
                          step="any"
                          className="flex-1"
                        />
                        <Select value={temperatureUnit} onValueChange={setTemperatureUnit}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="K">K</SelectItem>
                            <SelectItem value="C">°C</SelectItem>
                            <SelectItem value="F">°F</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Gas Constant Info */}
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200 text-purple-700 text-sm">
                      <strong>Gas Constant (R):</strong> 0.0821 L·atm/(mol·K)
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMoles} className="w-full" size="lg">
                  Calculate Moles
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Number of Moles</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {formatNumber(result.moles)}
                      </p>
                      <p className="text-lg text-muted-foreground mb-2">mol</p>
                      <p className={`text-sm font-medium ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Calculation Details */}
                    <div className="mt-4 p-3 bg-white/60 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-2">Method: {result.method}</p>
                      {result.massUsed !== undefined && (
                        <div className="text-xs text-muted-foreground space-y-1">
                          <p>Mass: {result.massUsed} g</p>
                          <p>Molar Mass: {result.molarMass} g/mol</p>
                        </div>
                      )}
                      {result.pressure !== undefined && (
                        <div className="text-xs text-muted-foreground space-y-1">
                          <p>Pressure: {result.pressure.toFixed(4)} atm</p>
                          <p>Volume: {result.volume?.toFixed(4)} L</p>
                          <p>Temperature: {result.temperature?.toFixed(2)} K</p>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset} className="bg-transparent">
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy} className="bg-transparent">
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare} className="bg-transparent">
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mole Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <h4 className="font-semibold text-purple-700 mb-2">Mass-Based</h4>
                      <p className="font-mono text-sm text-purple-800">n = m / M</p>
                      <p className="text-xs text-purple-600 mt-1">where m = mass, M = molar mass</p>
                    </div>
                    <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                      <h4 className="font-semibold text-cyan-700 mb-2">Ideal Gas Law</h4>
                      <p className="font-mono text-sm text-cyan-800">n = PV / RT</p>
                      <p className="text-xs text-cyan-600 mt-1">where P = pressure, V = volume, R = gas constant, T = temperature</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Molar Masses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Water (H₂O)</span>
                      <span className="font-mono">18.015 g/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Carbon Dioxide (CO₂)</span>
                      <span className="font-mono">44.01 g/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Oxygen (O₂)</span>
                      <span className="font-mono">32.00 g/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Nitrogen (N₂)</span>
                      <span className="font-mono">28.02 g/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Sodium Chloride (NaCl)</span>
                      <span className="font-mono">58.44 g/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Glucose (C₆H₁₂O₆)</span>
                      <span className="font-mono">180.16 g/mol</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is a Mole */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Mole in Chemistry?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The mole is one of the seven SI base units and is fundamental to chemistry. One mole contains exactly 
                  6.02214076 × 10²³ elementary entities (atoms, molecules, ions, or other particles). This number, known 
                  as Avogadro's constant (Nₐ), provides a bridge between the atomic scale and the macroscopic scale, 
                  allowing chemists to count atoms by weighing substances.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of the mole enables scientists to work with manageable numbers when dealing with atoms and 
                  molecules. For example, rather than saying a reaction requires 602,214,076,000,000,000,000,000 atoms of 
                  carbon, we simply say it requires 1 mole of carbon atoms. This makes stoichiometric calculations practical 
                  and standardized across all chemical applications.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Mole Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Mole calculations are essential in virtually every area of chemistry. In stoichiometry, moles help 
                  determine the exact amounts of reactants needed and products formed in chemical reactions. In solution 
                  chemistry, molarity (moles per liter) is the standard unit for expressing concentration. In gas 
                  calculations, the ideal gas law relates pressure, volume, and temperature to the number of moles.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Industries rely on mole calculations for manufacturing pharmaceuticals, producing fertilizers, refining 
                  petroleum, and countless other processes. Environmental scientists use them to measure pollution levels, 
                  while biochemists use them to study metabolic pathways and enzyme kinetics.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-yellow-800 mb-1">Important Note</h4>
                    <p className="text-sm text-yellow-700">
                      Results assume ideal conditions. Real substances may deviate under high pressure or extreme 
                      temperatures. The ideal gas law provides accurate results for most gases at standard conditions 
                      but may require corrections (van der Waals equation) for precise work with real gases at extreme 
                      conditions.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
