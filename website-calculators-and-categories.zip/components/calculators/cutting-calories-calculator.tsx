"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Scissors,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Target,
  Activity,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface CuttingResult {
  dailyCalories: number
  weeklyLoss: number
  timeToGoal: number
  deficit: number
  tdee: number
  bmr: number
  proteinGrams: number
  carbGrams: number
  fatGrams: number
  deficitLevel: "moderate" | "aggressive" | "extreme"
}

const activityLevels = [
  { value: "1.2", label: "Sedentary", description: "Little or no exercise" },
  { value: "1.375", label: "Lightly Active", description: "Light exercise 1-3 days/week" },
  { value: "1.55", label: "Moderately Active", description: "Moderate exercise 3-5 days/week" },
  { value: "1.725", label: "Very Active", description: "Hard exercise 6-7 days/week" },
  { value: "1.9", label: "Extra Active", description: "Very hard exercise & physical job" },
]

export function CuttingCaloriesCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [currentWeight, setCurrentWeight] = useState("")
  const [targetWeight, setTargetWeight] = useState("")
  const [age, setAge] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [activityLevel, setActivityLevel] = useState("1.55")
  const [bodyFat, setBodyFat] = useState("")
  const [timeframe, setTimeframe] = useState("")
  const [result, setResult] = useState<CuttingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateCuttingCalories = () => {
    setError("")
    setResult(null)

    const currentWeightNum = Number.parseFloat(currentWeight)
    const targetWeightNum = Number.parseFloat(targetWeight)
    const ageNum = Number.parseFloat(age)

    if (isNaN(currentWeightNum) || currentWeightNum <= 0) {
      setError("Please enter a valid current weight greater than 0")
      return
    }

    if (isNaN(targetWeightNum) || targetWeightNum <= 0) {
      setError("Please enter a valid target weight greater than 0")
      return
    }

    if (targetWeightNum >= currentWeightNum) {
      setError("Target weight must be less than current weight for a cutting plan")
      return
    }

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    // Convert weight to kg if imperial
    const currentWeightKg = unitSystem === "imperial" ? currentWeightNum * 0.453592 : currentWeightNum
    const targetWeightKg = unitSystem === "imperial" ? targetWeightNum * 0.453592 : targetWeightNum
    const weightToLose = currentWeightKg - targetWeightKg

    // Calculate BMR using Mifflin-St Jeor equation
    let bmr: number
    if (gender === "male") {
      bmr = 10 * currentWeightKg + 6.25 * heightInCm - 5 * ageNum + 5
    } else {
      bmr = 10 * currentWeightKg + 6.25 * heightInCm - 5 * ageNum - 161
    }

    // Calculate TDEE
    const activityMultiplier = Number.parseFloat(activityLevel)
    const tdee = bmr * activityMultiplier

    // Calculate deficit based on timeframe or use default
    let deficit: number
    let timeToGoal: number
    const timeframeNum = Number.parseFloat(timeframe)

    if (!isNaN(timeframeNum) && timeframeNum > 0) {
      // Calculate required deficit based on timeframe (in weeks)
      const weeklyLossNeeded = weightToLose / timeframeNum
      deficit = (weeklyLossNeeded * 7700) / 7 // 7700 calories = 1kg fat

      // Cap deficit at reasonable limits
      if (deficit > 1000) {
        deficit = 1000
        setError("Warning: The timeframe is too aggressive. Using maximum safe deficit of 1000 kcal/day.")
      } else if (deficit < 250) {
        deficit = 250
      }
      timeToGoal = timeframeNum
    } else {
      // Default moderate deficit of 500 kcal/day
      deficit = 500
      // Calculate time to goal (1kg = 7700 calories)
      const weeklyLoss = (deficit * 7) / 7700
      timeToGoal = Math.ceil(weightToLose / weeklyLoss)
    }

    const dailyCalories = Math.round(tdee - deficit)
    const weeklyLoss = (deficit * 7) / 7700

    // Ensure minimum calorie intake
    const minCalories = gender === "male" ? 1500 : 1200
    const finalCalories = Math.max(dailyCalories, minCalories)
    const actualDeficit = tdee - finalCalories

    // Determine deficit level
    let deficitLevel: "moderate" | "aggressive" | "extreme"
    if (actualDeficit <= 500) {
      deficitLevel = "moderate"
    } else if (actualDeficit <= 750) {
      deficitLevel = "aggressive"
    } else {
      deficitLevel = "extreme"
    }

    // Calculate macros (high protein for muscle preservation)
    const bodyFatNum = Number.parseFloat(bodyFat)
    let leanMass: number
    if (!isNaN(bodyFatNum) && bodyFatNum > 0 && bodyFatNum < 100) {
      leanMass = currentWeightKg * (1 - bodyFatNum / 100)
    } else {
      // Estimate lean mass based on gender
      leanMass = gender === "male" ? currentWeightKg * 0.8 : currentWeightKg * 0.75
    }

    // High protein: 2.2-2.5g per kg lean mass during cut
    const proteinGrams = Math.round(leanMass * 2.3)
    const proteinCalories = proteinGrams * 4

    // Fat: 0.8-1g per kg bodyweight
    const fatGrams = Math.round(currentWeightKg * 0.9)
    const fatCalories = fatGrams * 9

    // Remaining calories from carbs
    const carbCalories = Math.max(finalCalories - proteinCalories - fatCalories, 0)
    const carbGrams = Math.round(carbCalories / 4)

    setResult({
      dailyCalories: finalCalories,
      weeklyLoss: Math.round(weeklyLoss * 100) / 100,
      timeToGoal: Math.round(timeToGoal),
      deficit: Math.round(actualDeficit),
      tdee: Math.round(tdee),
      bmr: Math.round(bmr),
      proteinGrams,
      carbGrams,
      fatGrams,
      deficitLevel,
    })
  }

  const handleReset = () => {
    setCurrentWeight("")
    setTargetWeight("")
    setAge("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setGender("male")
    setActivityLevel("1.55")
    setBodyFat("")
    setTimeframe("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `My Cutting Calories Plan:
Daily Calories: ${result.dailyCalories} kcal
Deficit: ${result.deficit} kcal/day
Weekly Loss: ${result.weeklyLoss} kg
Time to Goal: ~${result.timeToGoal} weeks
Macros: P:${result.proteinGrams}g C:${result.carbGrams}g F:${result.fatGrams}g`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Cutting Calories Plan",
          text: `I calculated my cutting calories using CalcHub! Daily target: ${result.dailyCalories} kcal with ${result.deficit} kcal deficit.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setCurrentWeight("")
    setTargetWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  const getDeficitColor = (level: string) => {
    switch (level) {
      case "moderate":
        return { text: "text-green-600", bg: "bg-green-50 border-green-200", label: "Moderate & Sustainable" }
      case "aggressive":
        return { text: "text-yellow-600", bg: "bg-yellow-50 border-yellow-200", label: "Aggressive" }
      case "extreme":
        return { text: "text-red-600", bg: "bg-red-50 border-red-200", label: "Extreme - Use Caution" }
      default:
        return { text: "text-gray-600", bg: "bg-gray-50 border-gray-200", label: "Unknown" }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Scissors className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Cutting Calories Calculator</CardTitle>
                    <CardDescription>Calculate calories for fat loss</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Current Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="currentWeight">Current Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="currentWeight"
                    type="number"
                    placeholder={`Enter current weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={currentWeight}
                    onChange={(e) => setCurrentWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Target Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="targetWeight">Target Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="targetWeight"
                    type="number"
                    placeholder={`Enter target weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={targetWeight}
                    onChange={(e) => setTargetWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label htmlFor="activity">Activity Level</Label>
                  <Select value={activityLevel} onValueChange={setActivityLevel}>
                    <SelectTrigger id="activity">
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      {activityLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          <div className="flex flex-col">
                            <span>{level.label}</span>
                            <span className="text-xs text-muted-foreground">{level.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Optional: Body Fat Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="bodyFat">Body Fat % (optional)</Label>
                  <Input
                    id="bodyFat"
                    type="number"
                    placeholder="Enter body fat percentage for accurate macros"
                    value={bodyFat}
                    onChange={(e) => setBodyFat(e.target.value)}
                    min="1"
                    max="70"
                    step="0.1"
                  />
                </div>

                {/* Optional: Timeframe */}
                <div className="space-y-2">
                  <Label htmlFor="timeframe">Timeframe in Weeks (optional)</Label>
                  <Input
                    id="timeframe"
                    type="number"
                    placeholder="Leave empty for moderate 500 kcal deficit"
                    value={timeframe}
                    onChange={(e) => setTimeframe(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCuttingCalories} className="w-full" size="lg">
                  Calculate Cutting Calories
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getDeficitColor(result.deficitLevel).bg} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Daily Calorie Target</p>
                      <p className={`text-5xl font-bold ${getDeficitColor(result.deficitLevel).text} mb-2`}>
                        {result.dailyCalories.toLocaleString()}
                      </p>
                      <p className="text-lg text-muted-foreground">kcal/day</p>
                      <p className={`text-sm font-medium ${getDeficitColor(result.deficitLevel).text} mt-2`}>
                        {getDeficitColor(result.deficitLevel).label}
                      </p>
                    </div>

                    {/* Quick Stats */}
                    <div className="grid grid-cols-3 gap-3 mt-4 text-center">
                      <div className="p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Deficit</p>
                        <p className="font-semibold">{result.deficit} kcal</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Weekly Loss</p>
                        <p className="font-semibold">{result.weeklyLoss} kg</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Time to Goal</p>
                        <p className="font-semibold">~{result.timeToGoal} wks</p>
                      </div>
                    </div>

                    {/* Macro Breakdown */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg">
                      <p className="text-sm font-medium text-center mb-2">Recommended Macros</p>
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div>
                          <p className="text-xs text-muted-foreground">Protein</p>
                          <p className="font-bold text-blue-600">{result.proteinGrams}g</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Carbs</p>
                          <p className="font-bold text-green-600">{result.carbGrams}g</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Fat</p>
                          <p className="font-bold text-yellow-600">{result.fatGrams}g</p>
                        </div>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? "Hide" : "Show"} calculation details
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showDetails && (
                      <div className="mt-3 p-3 bg-white/70 rounded-lg text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">BMR:</span>
                          <span className="font-medium">{result.bmr} kcal/day</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">TDEE:</span>
                          <span className="font-medium">{result.tdee} kcal/day</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Caloric Deficit:</span>
                          <span className="font-medium">{result.deficit} kcal/day</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Daily Target:</span>
                          <span className="font-medium">{result.dailyCalories} kcal/day</span>
                        </div>
                        <div className="pt-2 border-t text-xs text-muted-foreground">
                          Formula: TDEE - Deficit = Daily Calories
                          <br />
                          BMR calculated using Mifflin-St Jeor equation
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Safe Deficit Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Moderate</span>
                      <span className="text-sm text-green-600">250-500 kcal/day</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Aggressive</span>
                      <span className="text-sm text-yellow-600">500-750 kcal/day</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Extreme</span>
                      <span className="text-sm text-red-600">750-1000 kcal/day</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Macro Priorities for Cutting</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="font-semibold text-blue-800">Protein: 2.0-2.5g/kg lean mass</p>
                    <p className="text-blue-700 text-xs mt-1">Crucial for preserving muscle during a caloric deficit</p>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                    <p className="font-semibold text-yellow-800">Fat: 0.8-1.0g/kg bodyweight</p>
                    <p className="text-yellow-700 text-xs mt-1">Essential for hormone production and satiety</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                    <p className="font-semibold text-green-800">Carbs: Remaining calories</p>
                    <p className="text-green-700 text-xs mt-1">Fuel for workouts and recovery</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Cutting Phase?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A cutting phase, also known as a fat loss phase or "cut," is a period of intentional caloric deficit
                  designed to reduce body fat while minimizing muscle loss. Unlike crash diets, a proper cutting
                  approach prioritizes protein intake and strength training to preserve lean muscle mass, ensuring that
                  the weight lost comes primarily from fat stores rather than hard-earned muscle tissue.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key to a successful cut lies in creating a moderate caloric deficit—typically 500 to 750 calories
                  below your Total Daily Energy Expenditure (TDEE). This allows for steady fat loss of approximately 0.5
                  to 1 kg per week while providing enough energy to maintain workout performance and support muscle
                  recovery. More aggressive deficits may lead to faster weight loss initially but often result in
                  greater muscle loss and metabolic adaptation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Calculating Your Cutting Calories</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator uses the Mifflin-St Jeor equation to estimate your Basal Metabolic Rate (BMR), which
                  is then multiplied by an activity factor to determine your TDEE. The recommended caloric deficit is
                  then subtracted to give you a daily calorie target optimized for fat loss while preserving muscle.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg font-mono text-sm">
                  <p className="font-semibold text-foreground">
                    BMR (Male) = 10 × weight(kg) + 6.25 × height(cm) - 5 × age + 5
                  </p>
                  <p className="font-semibold text-foreground mt-2">
                    BMR (Female) = 10 × weight(kg) + 6.25 × height(cm) - 5 × age - 161
                  </p>
                  <p className="font-semibold text-foreground mt-2">TDEE = BMR × Activity Multiplier</p>
                  <p className="font-semibold text-foreground mt-2">Cutting Calories = TDEE - Deficit</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for a Successful Cut</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Nutrition</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Prioritize protein at every meal</li>
                      <li>• Eat plenty of vegetables for volume</li>
                      <li>• Stay hydrated (water helps with satiety)</li>
                      <li>• Track your calories accurately</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Training</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Maintain resistance training intensity</li>
                      <li>• Reduce volume if recovery suffers</li>
                      <li>• Add moderate cardio if needed</li>
                      <li>• Prioritize sleep for recovery</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Mindset</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Be patient—sustainable loss is slow</li>
                      <li>• Focus on weekly trends, not daily weight</li>
                      <li>• Take progress photos regularly</li>
                      <li>• Plan diet breaks if cutting for long periods</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Warning Signs</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Constant fatigue or low energy</li>
                      <li>• Significant strength loss in the gym</li>
                      <li>• Excessive hunger or cravings</li>
                      <li>• Poor sleep or mood changes</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p>
                      Calorie calculations are estimates and may vary depending on individual metabolism, body
                      composition, and activity levels. Consult a healthcare or fitness professional before starting a
                      fat loss program, especially if you have any medical conditions. Never go below the minimum
                      recommended calorie intake (1500 kcal for men, 1200 kcal for women) without medical supervision.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
