"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Route, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type MaterialType = "asphalt" | "concrete" | "gravel"
type RoadType = "residential" | "commercial" | "highway"

interface RoadResult {
  volume: number
  adjustedVolume: number
  cement?: number
  cementBags?: number
  sand?: number
  aggregate?: number
  asphaltMix?: number
  gravelTons?: number
}

const roadThicknessPresets: Record<RoadType, number> = {
  residential: 0.15, // 150mm
  commercial: 0.20, // 200mm
  highway: 0.25, // 250mm
}

export function RoadQuantityCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [roadType, setRoadType] = useState<RoadType>("residential")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [thickness, setThickness] = useState("0.15")
  const [materialType, setMaterialType] = useState<MaterialType>("concrete")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<RoadResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const handleRoadTypeChange = (type: RoadType) => {
    setRoadType(type)
    setThickness(roadThicknessPresets[type].toString())
  }

  const calculateRoadQuantity = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const thicknessNum = Number.parseFloat(thickness)
    const wastageNum = Number.parseFloat(wastage)

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid road length greater than 0")
      return
    }

    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid road width greater than 0")
      return
    }

    if (isNaN(thicknessNum) || thicknessNum <= 0) {
      setError("Please enter a valid pavement thickness greater than 0")
      return
    }

    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage (0 or greater)")
      return
    }

    // Convert to metric if imperial
    const lengthM = unitSystem === "imperial" ? lengthNum * 0.3048 : lengthNum
    const widthM = unitSystem === "imperial" ? widthNum * 0.3048 : widthNum
    const thicknessM = unitSystem === "imperial" ? thicknessNum * 0.3048 : thicknessNum

    // Calculate volume
    const volume = lengthM * widthM * thicknessM
    const adjustedVolume = volume * (1 + wastageNum / 100)

    const resultData: RoadResult = {
      volume: unitSystem === "imperial" ? volume * 35.3147 : volume,
      adjustedVolume: unitSystem === "imperial" ? adjustedVolume * 35.3147 : adjustedVolume,
    }

    // Calculate material quantities based on type
    if (materialType === "concrete") {
      // Concrete calculation (M25 mix ratio 1:1:2)
      const dryVolume = adjustedVolume * 1.54 // Dry volume factor
      const totalParts = 1 + 1 + 2 // cement:sand:aggregate

      const cementVolume = (dryVolume * 1) / totalParts
      const cementKg = cementVolume * 1440 // Cement density
      const cementBags = cementKg / 50 // 50kg bags

      const sandVolume = (dryVolume * 1) / totalParts
      const aggregateVolume = (dryVolume * 2) / totalParts

      resultData.cement = cementKg
      resultData.cementBags = cementBags
      resultData.sand = sandVolume
      resultData.aggregate = aggregateVolume
    } else if (materialType === "asphalt") {
      // Asphalt density ~2400 kg/m³
      const asphaltTons = (adjustedVolume * 2400) / 1000
      resultData.asphaltMix = asphaltTons
    } else if (materialType === "gravel") {
      // Gravel density ~1600 kg/m³
      const gravelTons = (adjustedVolume * 1600) / 1000
      resultData.gravelTons = gravelTons
    }

    setResult(resultData)
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setThickness("0.15")
    setRoadType("residential")
    setMaterialType("concrete")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "m³" : "ft³"
      await navigator.clipboard.writeText(
        `Road Volume: ${result.adjustedVolume.toFixed(2)} ${unit} (with wastage)`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const unit = unitSystem === "metric" ? "m³" : "ft³"
        await navigator.share({
          title: "Road Quantity Calculation",
          text: `I calculated road materials using CalcHub! Volume: ${result.adjustedVolume.toFixed(2)} ${unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Route className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Road Quantity Calculator</CardTitle>
                    <CardDescription>Estimate road construction materials</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Road Type */}
                <div className="space-y-2">
                  <Label htmlFor="roadType">Road Type (Auto-fills thickness)</Label>
                  <Select value={roadType} onValueChange={(value: RoadType) => handleRoadTypeChange(value)}>
                    <SelectTrigger id="roadType">
                      <SelectValue placeholder="Select road type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="residential">Residential (150mm)</SelectItem>
                      <SelectItem value="commercial">Commercial (200mm)</SelectItem>
                      <SelectItem value="highway">Highway (250mm)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Road Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder="Road length"
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder="Road width"
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Pavement Thickness */}
                <div className="space-y-2">
                  <Label htmlFor="thickness">Pavement Thickness ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="thickness"
                    type="number"
                    placeholder="Pavement thickness"
                    value={thickness}
                    onChange={(e) => setThickness(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Material Type */}
                <div className="space-y-2">
                  <Label htmlFor="material">Material Type</Label>
                  <Select
                    value={materialType}
                    onValueChange={(value: MaterialType) => setMaterialType(value)}
                  >
                    <SelectTrigger id="material">
                      <SelectValue placeholder="Select material" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concrete">Concrete (M25)</SelectItem>
                      <SelectItem value="asphalt">Asphalt</SelectItem>
                      <SelectItem value="gravel">Gravel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Wastage Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="wastage">Wastage (%)</Label>
                  <Input
                    id="wastage"
                    type="number"
                    placeholder="Wastage percentage"
                    value={wastage}
                    onChange={(e) => setWastage(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRoadQuantity} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Quantity
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Road Volume (with wastage)</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {result.adjustedVolume.toFixed(2)}
                        </p>
                        <p className="text-lg font-semibold text-amber-600">
                          {unitSystem === "metric" ? "m³" : "ft³"}
                        </p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Base Volume:</span>
                          <span className="font-semibold">
                            {result.volume.toFixed(2)} {unitSystem === "metric" ? "m³" : "ft³"}
                          </span>
                        </div>

                        {materialType === "concrete" && (
                          <>
                            <div className="pt-2 border-t border-amber-200">
                              <p className="font-semibold text-amber-800 mb-2">Concrete Materials (M25 Mix):</p>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Cement:</span>
                              <span className="font-semibold">{result.cementBags?.toFixed(1)} bags</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground"></span>
                              <span className="font-semibold text-xs">({result.cement?.toFixed(0)} kg)</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Sand:</span>
                              <span className="font-semibold">{result.sand?.toFixed(2)} m³</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Aggregate:</span>
                              <span className="font-semibold">{result.aggregate?.toFixed(2)} m³</span>
                            </div>
                          </>
                        )}

                        {materialType === "asphalt" && (
                          <>
                            <div className="pt-2 border-t border-amber-200">
                              <p className="font-semibold text-amber-800 mb-2">Asphalt Materials:</p>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Asphalt Mix:</span>
                              <span className="font-semibold">{result.asphaltMix?.toFixed(2)} tons</span>
                            </div>
                          </>
                        )}

                        {materialType === "gravel" && (
                          <>
                            <div className="pt-2 border-t border-amber-200">
                              <p className="font-semibold text-amber-800 mb-2">Gravel Materials:</p>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Gravel:</span>
                              <span className="font-semibold">{result.gravelTons?.toFixed(2)} tons</span>
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Pavement Thickness</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Residential Roads</span>
                      <span className="text-sm text-amber-600">150mm (6")</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Commercial Roads</span>
                      <span className="text-sm text-amber-600">200mm (8")</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Highways</span>
                      <span className="text-sm text-amber-600">250mm (10")</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Material Properties</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p className="font-semibold text-foreground">Concrete</p>
                    <p>Durable, long-lasting. Suitable for heavy traffic. Requires curing time.</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-semibold text-foreground">Asphalt</p>
                    <p>Flexible, smooth surface. Quick installation. Requires periodic maintenance.</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-semibold text-foreground">Gravel</p>
                    <p>Cost-effective for rural roads. Good drainage. Regular grading needed.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Road Construction */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Road Construction Planning?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Road construction planning involves calculating the materials and quantities required to build
                  durable road surfaces that can withstand traffic loads and environmental conditions. The process
                  includes determining pavement thickness based on expected traffic volume, selecting appropriate
                  materials (concrete, asphalt, or gravel), and estimating quantities for procurement and budgeting.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Proper road design considers subgrade preparation, drainage requirements, material specifications,
                  compaction standards, and long-term maintenance needs. Different road types require different
                  pavement structures - residential streets typically need thinner pavements than highways carrying
                  heavy commercial traffic. Climate, soil conditions, and budget constraints also influence material
                  selection and design specifications.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Road Quantity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Road Quantity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Road quantity calculation begins with determining the pavement volume: Road Volume = Length × Width ×
                  Thickness. This base volume is then adjusted for material wastage (typically 5-10%) to account for
                  spillage, compaction, and uneven surfaces. For concrete roads, the dry volume factor (1.54) is
                  applied to convert wet concrete volume to dry material quantities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Material quantities are calculated based on mix ratios. For M25 concrete (1:1:2 ratio), cement, sand,
                  and aggregate are determined proportionally from the dry volume. Asphalt quantities use material
                  density (2400 kg/m³) to convert volume to tons. Gravel roads use gravel density (1600 kg/m³).
                  Additional considerations include base course materials, primer coats for asphalt, and curing
                  compounds for concrete.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions About Road Construction</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What factors determine pavement thickness?</h4>
                    <p className="text-muted-foreground text-sm">
                      Pavement thickness depends on expected traffic load, vehicle types, soil bearing capacity,
                      climate conditions, and design life expectancy. Heavy traffic and poor soil conditions require
                      thicker pavements. Geotechnical analysis of subgrade soil helps determine appropriate thickness.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      How long does road construction typically take?
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      Construction duration varies by road type and material. Gravel roads can be completed quickly
                      (days to weeks). Asphalt roads take 1-2 weeks per kilometer including base preparation. Concrete
                      roads require additional curing time (28 days for full strength), extending project schedules but
                      providing longer service life.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What is the importance of road drainage?</h4>
                    <p className="text-muted-foreground text-sm">
                      Proper drainage is critical for road longevity. Water infiltration weakens subgrade soil, causes
                      pavement cracking, and accelerates deterioration. Roads should have adequate camber (cross-slope)
                      for surface drainage, longitudinal gradients, and subsurface drainage systems to remove water
                      from pavement layers.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-semibold text-amber-900">Important Note</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Road quantity estimates are approximate. Actual requirements depend on pavement design, material
                      properties, and site conditions. Always consult geotechnical engineers, pavement designers, and
                      local transportation authorities for project-specific specifications. Consider subgrade
                      preparation, drainage, traffic loads, and environmental factors in final designs.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
