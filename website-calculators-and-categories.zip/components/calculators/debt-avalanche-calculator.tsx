"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  TrendingDown,
  Target,
  Plus,
  Trash2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Percent,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface Debt {
  id: string
  name: string
  balance: string
  minPayment: string
  interestRate: string
}

interface DebtPayoffResult {
  totalDebt: number
  totalInterest: number
  monthsToPayoff: number
  payoffDate: string
  payoffOrder: {
    name: string
    balance: number
    interestRate: number
    months: number
    interest: number
    payoffDate: string
  }[]
  interestSaved: number
  monthlySchedule: {
    month: number
    date: string
    payments: { name: string; payment: number; remaining: number }[]
    totalPayment: number
    totalRemaining: number
  }[]
}

export function DebtAvalancheCalculator() {
  const [debts, setDebts] = useState<Debt[]>([{ id: "1", name: "", balance: "", minPayment: "", interestRate: "" }])
  const [extraPayment, setExtraPayment] = useState("")
  const [result, setResult] = useState<DebtPayoffResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSchedule, setShowSchedule] = useState(false)

  const addDebt = () => {
    setDebts([...debts, { id: Date.now().toString(), name: "", balance: "", minPayment: "", interestRate: "" }])
  }

  const removeDebt = (id: string) => {
    if (debts.length > 1) {
      setDebts(debts.filter((d) => d.id !== id))
    }
  }

  const updateDebt = (id: string, field: keyof Debt, value: string) => {
    setDebts(debts.map((d) => (d.id === id ? { ...d, [field]: value } : d)))
  }

  const calculateAvalanche = () => {
    setError("")
    setResult(null)

    // Validate debts
    const validDebts = debts.filter((d) => d.name && d.balance && d.minPayment && d.interestRate)

    if (validDebts.length === 0) {
      setError("Please enter at least one complete debt entry")
      return
    }

    for (const debt of validDebts) {
      const balance = Number.parseFloat(debt.balance)
      const minPayment = Number.parseFloat(debt.minPayment)
      const rate = Number.parseFloat(debt.interestRate)

      if (balance <= 0 || minPayment <= 0 || rate < 0) {
        setError("Balance and minimum payment must be positive. Interest rate must be non-negative.")
        return
      }

      // Check if minimum payment can cover interest
      const monthlyInterest = (balance * (rate / 100)) / 12
      if (minPayment <= monthlyInterest && rate > 0) {
        setError(`Minimum payment for "${debt.name}" is too low to cover monthly interest`)
        return
      }
    }

    const extra = Number.parseFloat(extraPayment) || 0
    if (extra < 0) {
      setError("Extra payment must be non-negative")
      return
    }

    // Sort debts by interest rate (highest first) - Avalanche method
    const sortedDebts = validDebts
      .map((d) => ({
        name: d.name,
        balance: Number.parseFloat(d.balance),
        minPayment: Number.parseFloat(d.minPayment),
        interestRate: Number.parseFloat(d.interestRate),
        monthlyRate: Number.parseFloat(d.interestRate) / 100 / 12,
        originalBalance: Number.parseFloat(d.balance),
      }))
      .sort((a, b) => b.interestRate - a.interestRate)

    const totalDebt = sortedDebts.reduce((sum, d) => sum + d.balance, 0)
    let totalInterest = 0
    let month = 0
    const payoffOrder: DebtPayoffResult["payoffOrder"] = []
    const monthlySchedule: DebtPayoffResult["monthlySchedule"] = []
    const startDate = new Date()

    // Track each debt's progress
    const debtProgress = sortedDebts.map((d) => ({
      ...d,
      currentBalance: d.balance,
      totalInterest: 0,
      paidOff: false,
      payoffMonth: 0,
    }))

    // Calculate without extra payment for comparison
    let baselineInterest = 0
    const baselineDebts = sortedDebts.map((d) => ({ ...d, currentBalance: d.balance }))
    let baselineMonth = 0
    while (baselineDebts.some((d) => d.currentBalance > 0) && baselineMonth < 600) {
      baselineMonth++
      for (const debt of baselineDebts) {
        if (debt.currentBalance <= 0) continue
        const interest = debt.currentBalance * debt.monthlyRate
        baselineInterest += interest
        debt.currentBalance += interest
        const payment = Math.min(debt.minPayment, debt.currentBalance)
        debt.currentBalance -= payment
      }
    }

    // Calculate with avalanche method
    const availableExtra = extra
    while (debtProgress.some((d) => !d.paidOff) && month < 600) {
      month++
      const currentDate = new Date(startDate)
      currentDate.setMonth(currentDate.getMonth() + month)

      const monthPayments: { name: string; payment: number; remaining: number }[] = []
      let totalMonthPayment = 0

      // Apply interest to all unpaid debts
      for (const debt of debtProgress) {
        if (debt.paidOff) continue
        const interest = debt.currentBalance * debt.monthlyRate
        debt.totalInterest += interest
        totalInterest += interest
        debt.currentBalance += interest
      }

      // Find the highest interest rate unpaid debt
      const targetDebt = debtProgress.find((d) => !d.paidOff)

      // Pay minimum on all debts except the target
      for (const debt of debtProgress) {
        if (debt.paidOff) continue
        if (debt === targetDebt) continue

        const payment = Math.min(debt.minPayment, debt.currentBalance)
        debt.currentBalance -= payment
        totalMonthPayment += payment

        monthPayments.push({
          name: debt.name,
          payment: Math.round(payment * 100) / 100,
          remaining: Math.round(debt.currentBalance * 100) / 100,
        })

        if (debt.currentBalance <= 0.01) {
          debt.currentBalance = 0
          debt.paidOff = true
          debt.payoffMonth = month
          const payoffDate = new Date(startDate)
          payoffDate.setMonth(payoffDate.getMonth() + month)
          payoffOrder.push({
            name: debt.name,
            balance: debt.originalBalance,
            interestRate: debt.interestRate,
            months: month,
            interest: Math.round(debt.totalInterest * 100) / 100,
            payoffDate: payoffDate.toLocaleDateString("en-US", { month: "short", year: "numeric" }),
          })
        }
      }

      // Pay target debt with minimum + freed payments + extra
      if (targetDebt && !targetDebt.paidOff) {
        const freedPayments = debtProgress
          .filter((d) => d.paidOff && d.payoffMonth < month)
          .reduce((sum, d) => sum + d.minPayment, 0)

        const totalPayment = Math.min(targetDebt.minPayment + freedPayments + availableExtra, targetDebt.currentBalance)

        targetDebt.currentBalance -= totalPayment
        totalMonthPayment += totalPayment

        monthPayments.unshift({
          name: targetDebt.name,
          payment: Math.round(totalPayment * 100) / 100,
          remaining: Math.round(Math.max(0, targetDebt.currentBalance) * 100) / 100,
        })

        if (targetDebt.currentBalance <= 0.01) {
          targetDebt.currentBalance = 0
          targetDebt.paidOff = true
          targetDebt.payoffMonth = month
          const payoffDate = new Date(startDate)
          payoffDate.setMonth(payoffDate.getMonth() + month)
          payoffOrder.push({
            name: targetDebt.name,
            balance: targetDebt.originalBalance,
            interestRate: targetDebt.interestRate,
            months: month,
            interest: Math.round(targetDebt.totalInterest * 100) / 100,
            payoffDate: payoffDate.toLocaleDateString("en-US", { month: "short", year: "numeric" }),
          })
        }
      }

      monthlySchedule.push({
        month,
        date: currentDate.toLocaleDateString("en-US", { month: "short", year: "numeric" }),
        payments: monthPayments,
        totalPayment: Math.round(totalMonthPayment * 100) / 100,
        totalRemaining: Math.round(debtProgress.reduce((sum, d) => sum + d.currentBalance, 0) * 100) / 100,
      })
    }

    const payoffDate = new Date(startDate)
    payoffDate.setMonth(payoffDate.getMonth() + month)

    setResult({
      totalDebt: Math.round(totalDebt * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
      monthsToPayoff: month,
      payoffDate: payoffDate.toLocaleDateString("en-US", { month: "long", year: "numeric" }),
      payoffOrder,
      interestSaved: Math.round((baselineInterest - totalInterest) * 100) / 100,
      monthlySchedule,
    })
  }

  const handleReset = () => {
    setDebts([{ id: "1", name: "", balance: "", minPayment: "", interestRate: "" }])
    setExtraPayment("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSchedule(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Debt Avalanche Plan:\nTotal Debt: $${result.totalDebt.toLocaleString()}\nPayoff Time: ${result.monthsToPayoff} months\nTotal Interest: $${result.totalInterest.toLocaleString()}\nInterest Saved: $${result.interestSaved.toLocaleString()}\nDebt-Free Date: ${result.payoffDate}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Debt Avalanche Plan",
          text: `I'm using the Debt Avalanche method to pay off $${result.totalDebt.toLocaleString()} and save $${result.interestSaved.toLocaleString()} in interest!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Percent className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Debt Avalanche Calculator</CardTitle>
                    <CardDescription>Pay off highest interest first</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Debts List */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Your Debts</Label>
                    <Button variant="outline" size="sm" onClick={addDebt}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Debt
                    </Button>
                  </div>

                  {debts.map((debt, index) => (
                    <div key={debt.id} className="p-4 border rounded-lg space-y-3 bg-muted/30">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-muted-foreground">Debt #{index + 1}</span>
                        {debts.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeDebt(debt.id)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Input
                          placeholder="Debt name (e.g., Credit Card)"
                          value={debt.name}
                          onChange={(e) => updateDebt(debt.id, "name", e.target.value)}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs">Balance ($)</Label>
                          <Input
                            type="number"
                            placeholder="5000"
                            value={debt.balance}
                            onChange={(e) => updateDebt(debt.id, "balance", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Min Payment ($)</Label>
                          <Input
                            type="number"
                            placeholder="100"
                            value={debt.minPayment}
                            onChange={(e) => updateDebt(debt.id, "minPayment", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Interest (%)</Label>
                          <Input
                            type="number"
                            placeholder="18"
                            value={debt.interestRate}
                            onChange={(e) => updateDebt(debt.id, "interestRate", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Extra Payment */}
                <div className="space-y-2">
                  <Label htmlFor="extraPayment">Monthly Extra Payment ($)</Label>
                  <Input
                    id="extraPayment"
                    type="number"
                    placeholder="Enter extra amount you can pay monthly"
                    value={extraPayment}
                    onChange={(e) => setExtraPayment(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAvalanche} className="w-full" size="lg">
                  Calculate Payoff Plan
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Debt-Free Date</p>
                      <p className="text-3xl font-bold text-green-600 mb-1">{result.payoffDate}</p>
                      <p className="text-sm text-muted-foreground">
                        {result.monthsToPayoff} months ({Math.floor(result.monthsToPayoff / 12)} years{" "}
                        {result.monthsToPayoff % 12} months)
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Debt</p>
                        <p className="text-lg font-semibold">{formatCurrency(result.totalDebt)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Interest</p>
                        <p className="text-lg font-semibold">{formatCurrency(result.totalInterest)}</p>
                      </div>
                    </div>

                    {result.interestSaved > 0 && (
                      <div className="p-3 bg-emerald-100 border border-emerald-200 rounded-lg text-center mb-4">
                        <p className="text-xs text-emerald-700">Interest Saved with Extra Payments</p>
                        <p className="text-xl font-bold text-emerald-600">{formatCurrency(result.interestSaved)}</p>
                      </div>
                    )}

                    {/* Payoff Order */}
                    <div className="mb-4">
                      <p className="text-sm font-semibold mb-2">Payoff Order (Highest Interest First):</p>
                      <div className="space-y-2">
                        {result.payoffOrder.map((debt, index) => (
                          <div
                            key={debt.name}
                            className="flex items-center justify-between p-2 bg-white rounded-lg text-sm"
                          >
                            <div className="flex items-center gap-2">
                              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-700 text-xs font-bold">
                                {index + 1}
                              </span>
                              <div>
                                <span className="font-medium">{debt.name}</span>
                                <span className="text-xs text-red-500 ml-2">({debt.interestRate}% APR)</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="text-muted-foreground">{debt.payoffDate}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Monthly Schedule Toggle */}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowSchedule(!showSchedule)}
                      className="w-full mb-3"
                    >
                      {showSchedule ? (
                        <>
                          <ChevronUp className="h-4 w-4 mr-1" />
                          Hide Monthly Schedule
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4 mr-1" />
                          Show Monthly Schedule
                        </>
                      )}
                    </Button>

                    {showSchedule && (
                      <div className="max-h-64 overflow-y-auto border rounded-lg">
                        <table className="w-full text-xs">
                          <thead className="bg-muted sticky top-0">
                            <tr>
                              <th className="p-2 text-left">Month</th>
                              <th className="p-2 text-right">Payment</th>
                              <th className="p-2 text-right">Remaining</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.monthlySchedule.map((schedule) => (
                              <tr key={schedule.month} className="border-t">
                                <td className="p-2">{schedule.date}</td>
                                <td className="p-2 text-right">{formatCurrency(schedule.totalPayment)}</td>
                                <td className="p-2 text-right">{formatCurrency(schedule.totalRemaining)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleCopy} className="flex-1 bg-transparent">
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied!" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare} className="flex-1 bg-transparent">
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleReset} className="flex-1 bg-transparent">
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-4">
              {/* How Avalanche Works */}
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Target className="h-4 w-4 text-green-600" />
                    How the Avalanche Method Works
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-start gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-red-100 text-red-700 text-xs font-bold shrink-0">
                        1
                      </div>
                      <p className="text-sm text-muted-foreground">
                        List all debts sorted by <strong>interest rate (highest first)</strong>
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-orange-100 text-orange-700 text-xs font-bold shrink-0">
                        2
                      </div>
                      <p className="text-sm text-muted-foreground">Pay minimum payments on all debts</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-yellow-100 text-yellow-700 text-xs font-bold shrink-0">
                        3
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Put all extra money toward the <strong>highest interest</strong> debt
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-700 text-xs font-bold shrink-0">
                        4
                      </div>
                      <p className="text-sm text-muted-foreground">
                        When paid off, roll that payment to the next highest rate
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Avalanche vs Snowball */}
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <TrendingDown className="h-4 w-4 text-green-600" />
                    Avalanche vs Snowball
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-green-50 rounded-lg border border-green-100">
                      <p className="text-sm font-semibold text-green-700 mb-1">Avalanche (This Calculator)</p>
                      <p className="text-xs text-muted-foreground">
                        Targets highest interest rate first. <strong>Saves the most money</strong> on interest over
                        time.
                      </p>
                    </div>
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
                      <p className="text-sm font-semibold text-blue-700 mb-1">Snowball Method</p>
                      <p className="text-xs text-muted-foreground">
                        Targets smallest balance first. Provides <strong>quick wins</strong> for motivation.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Why Avalanche Saves More */}
              <Card className="border-0 shadow-md bg-gradient-to-br from-green-50 to-emerald-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Percent className="h-4 w-4 text-green-600" />
                    Why Avalanche Saves More
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">
                    By targeting high-interest debt first, you reduce the amount of interest accruing each month.
                  </p>
                  <div className="p-3 bg-white/60 rounded-lg">
                    <p className="text-xs font-mono text-center text-muted-foreground">
                      Higher Rate Paid First = Less Total Interest
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            <Card className="border-0 shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Info className="h-4 w-4 text-green-600" />
                  What is the Debt Avalanche?
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground space-y-2">
                <p>
                  The debt avalanche is a debt repayment strategy that prioritizes paying off debts with the highest
                  interest rates first, regardless of balance size.
                </p>
                <p>
                  This method is mathematically optimal for minimizing total interest paid over the life of your debts,
                  potentially saving you hundreds or thousands of dollars.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Target className="h-4 w-4 text-green-600" />
                  When to Use Avalanche
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground space-y-2">
                <p>The avalanche method is ideal when:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>You have debts with significantly different interest rates</li>
                  <li>Saving money is your top priority</li>
                  <li>You're disciplined and don't need quick wins for motivation</li>
                  <li>You have high-interest credit card debt</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-md sm:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                  Important Disclaimer
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>
                  Debt avalanche calculations are estimates and may vary based on interest rate changes, missed
                  payments, or additional charges. This calculator assumes fixed interest rates and consistent payments.
                  Consult a financial advisor for personalized debt management advice tailored to your situation.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
