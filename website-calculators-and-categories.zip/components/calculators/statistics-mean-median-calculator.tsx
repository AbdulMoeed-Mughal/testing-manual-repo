"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  BarChart3,
  Info,
  AlertTriangle,
  Calculator,
  TrendingUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type OperationType = "mean" | "median" | "both"

interface StatisticsResult {
  mean: number | null
  median: number | null
  sortedData: number[]
  count: number
  sum: number
  min: number
  max: number
  range: number
}

export function StatisticsMeanMedianCalculator() {
  const [dataInput, setDataInput] = useState("")
  const [operation, setOperation] = useState<OperationType>("both")
  const [result, setResult] = useState<StatisticsResult | null>(null)
  const [showSteps, setShowSteps] = useState(true)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const parseData = (input: string): number[] => {
    // Split by comma, space, newline, or tab
    const parts = input.split(/[\s,]+/).filter((part) => part.trim() !== "")
    const numbers: number[] = []

    for (const part of parts) {
      const num = Number.parseFloat(part.trim())
      if (isNaN(num)) {
        throw new Error(`Invalid number: "${part.trim()}"`)
      }
      numbers.push(num)
    }

    return numbers
  }

  const calculateMean = (data: number[]): number => {
    const sum = data.reduce((acc, val) => acc + val, 0)
    return sum / data.length
  }

  const calculateMedian = (sortedData: number[]): number => {
    const n = sortedData.length
    if (n % 2 === 0) {
      // Even count: average of two middle numbers
      return (sortedData[n / 2 - 1] + sortedData[n / 2]) / 2
    } else {
      // Odd count: middle number
      return sortedData[Math.floor(n / 2)]
    }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (!dataInput.trim()) {
      setError("Please enter a dataset")
      return
    }

    try {
      const data = parseData(dataInput)

      if (data.length === 0) {
        setError("Please enter at least one number")
        return
      }

      const sortedData = [...data].sort((a, b) => a - b)
      const sum = data.reduce((acc, val) => acc + val, 0)
      const min = sortedData[0]
      const max = sortedData[sortedData.length - 1]

      const mean = operation === "median" ? null : calculateMean(data)
      const median = operation === "mean" ? null : calculateMedian(sortedData)

      setResult({
        mean,
        median,
        sortedData,
        count: data.length,
        sum,
        min,
        max,
        range: max - min,
      })
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message)
      } else {
        setError("Invalid input. Please enter numbers separated by commas or spaces.")
      }
    }
  }

  const handleReset = () => {
    setDataInput("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const formatNumber = (num: number): string => {
    if (Number.isInteger(num)) {
      return num.toString()
    }
    return num.toFixed(4).replace(/\.?0+$/, "")
  }

  const handleCopy = async () => {
    if (result) {
      let text = `Statistics Results:\n`
      text += `Count: ${result.count}\n`
      if (result.mean !== null) text += `Mean: ${formatNumber(result.mean)}\n`
      if (result.median !== null) text += `Median: ${formatNumber(result.median)}\n`
      text += `Sum: ${formatNumber(result.sum)}\n`
      text += `Range: ${formatNumber(result.range)} (${formatNumber(result.min)} to ${formatNumber(result.max)})`

      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      let text = `Statistics Results: `
      if (result.mean !== null) text += `Mean = ${formatNumber(result.mean)}`
      if (result.mean !== null && result.median !== null) text += `, `
      if (result.median !== null) text += `Median = ${formatNumber(result.median)}`
      text += ` (n = ${result.count})`

      try {
        await navigator.share({
          title: "Statistics Results",
          text: `I calculated statistics using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <BarChart3 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Statistics Calculator</CardTitle>
                    <CardDescription>Calculate mean and median of a dataset</CardDescription>
                  </div>
                </div>

                {/* Operation Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculate</span>
                  <div className="flex rounded-full bg-muted p-1">
                    {(["mean", "median", "both"] as OperationType[]).map((op) => (
                      <button
                        key={op}
                        onClick={() => setOperation(op)}
                        className={`px-3 py-1.5 text-sm font-medium rounded-full transition-colors capitalize ${
                          operation === op
                            ? "bg-primary text-primary-foreground shadow-sm"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {op === "both" ? "Both" : op}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Data Input */}
                <div className="space-y-2">
                  <Label htmlFor="data">Dataset</Label>
                  <Textarea
                    id="data"
                    placeholder="Enter numbers separated by commas or spaces&#10;Example: 5, 10, 15, 20, 25"
                    value={dataInput}
                    onChange={(e) => setDataInput(e.target.value)}
                    rows={4}
                    className="resize-none font-mono"
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter numbers separated by commas, spaces, or new lines
                  </p>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Show step-by-step</span>
                  <button
                    onClick={() => setShowSteps(!showSteps)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      showSteps ? "bg-primary" : "bg-muted"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform ${
                        showSteps ? "translate-x-6" : "translate-x-1"
                      }`}
                    />
                  </button>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Statistics
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center space-y-4">
                      {/* Main Results */}
                      <div className="grid grid-cols-2 gap-4">
                        {result.mean !== null && (
                          <div className="p-3 bg-white rounded-lg border border-blue-100">
                            <p className="text-xs text-muted-foreground mb-1">Mean (Average)</p>
                            <p className="text-2xl font-bold text-blue-600">{formatNumber(result.mean)}</p>
                          </div>
                        )}
                        {result.median !== null && (
                          <div className="p-3 bg-white rounded-lg border border-blue-100">
                            <p className="text-xs text-muted-foreground mb-1">Median</p>
                            <p className="text-2xl font-bold text-blue-600">{formatNumber(result.median)}</p>
                          </div>
                        )}
                      </div>

                      {/* Additional Stats */}
                      <div className="grid grid-cols-4 gap-2 text-sm">
                        <div className="p-2 bg-white rounded-lg border border-blue-100">
                          <p className="text-xs text-muted-foreground">Count</p>
                          <p className="font-semibold">{result.count}</p>
                        </div>
                        <div className="p-2 bg-white rounded-lg border border-blue-100">
                          <p className="text-xs text-muted-foreground">Sum</p>
                          <p className="font-semibold">{formatNumber(result.sum)}</p>
                        </div>
                        <div className="p-2 bg-white rounded-lg border border-blue-100">
                          <p className="text-xs text-muted-foreground">Min</p>
                          <p className="font-semibold">{formatNumber(result.min)}</p>
                        </div>
                        <div className="p-2 bg-white rounded-lg border border-blue-100">
                          <p className="text-xs text-muted-foreground">Max</p>
                          <p className="font-semibold">{formatNumber(result.max)}</p>
                        </div>
                      </div>

                      {/* Sorted Data Display */}
                      {showSteps && (
                        <div className="text-left space-y-3 mt-4">
                          <div className="p-3 bg-white rounded-lg border border-blue-100">
                            <p className="text-xs font-medium text-muted-foreground mb-2">Sorted Dataset:</p>
                            <p className="font-mono text-sm text-blue-700 break-all">
                              [{result.sortedData.map((n) => formatNumber(n)).join(", ")}]
                            </p>
                          </div>

                          {/* Step by Step */}
                          {result.mean !== null && (
                            <div className="p-3 bg-white rounded-lg border border-blue-100">
                              <p className="text-xs font-medium text-muted-foreground mb-2">Mean Calculation:</p>
                              <div className="font-mono text-sm space-y-1">
                                <p>Sum = {result.sortedData.map((n) => formatNumber(n)).join(" + ")}</p>
                                <p>Sum = {formatNumber(result.sum)}</p>
                                <p>
                                  Mean = {formatNumber(result.sum)} ÷ {result.count} ={" "}
                                  <span className="text-blue-600 font-semibold">{formatNumber(result.mean)}</span>
                                </p>
                              </div>
                            </div>
                          )}

                          {result.median !== null && (
                            <div className="p-3 bg-white rounded-lg border border-blue-100">
                              <p className="text-xs font-medium text-muted-foreground mb-2">Median Calculation:</p>
                              <div className="font-mono text-sm space-y-1">
                                <p>
                                  n = {result.count} ({result.count % 2 === 0 ? "even" : "odd"})
                                </p>
                                {result.count % 2 === 0 ? (
                                  <>
                                    <p>
                                      Middle positions: {result.count / 2} and {result.count / 2 + 1}
                                    </p>
                                    <p>
                                      Middle values: {formatNumber(result.sortedData[result.count / 2 - 1])} and{" "}
                                      {formatNumber(result.sortedData[result.count / 2])}
                                    </p>
                                    <p>
                                      Median = ({formatNumber(result.sortedData[result.count / 2 - 1])} +{" "}
                                      {formatNumber(result.sortedData[result.count / 2])}) ÷ 2 ={" "}
                                      <span className="text-blue-600 font-semibold">{formatNumber(result.median)}</span>
                                    </p>
                                  </>
                                ) : (
                                  <>
                                    <p>Middle position: {Math.ceil(result.count / 2)}</p>
                                    <p>
                                      Median ={" "}
                                      <span className="text-blue-600 font-semibold">{formatNumber(result.median)}</span>
                                    </p>
                                  </>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-2">Mean (Average):</p>
                    <p className="font-mono text-sm text-center">Mean = (x₁ + x₂ + ... + xₙ) / n</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-2">Median:</p>
                    <div className="text-sm space-y-1">
                      <p>
                        <span className="font-medium">Odd n:</span> Middle value
                      </p>
                      <p>
                        <span className="font-medium">Even n:</span> Average of two middle values
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-medium text-blue-700">Dataset: 2, 4, 6, 8, 10</p>
                    <p className="text-blue-600">Mean = 6, Median = 6</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-medium text-green-700">Dataset: 1, 3, 5, 7</p>
                    <p className="text-green-600">Mean = 4, Median = 4</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-medium text-purple-700">Dataset: 10, 20, 30, 40, 100</p>
                    <p className="text-purple-600">Mean = 40, Median = 30</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    This calculator provides estimates only. Verify manually for critical calculations or statistical
                    analysis.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Mean and Median?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Mean and median are two of the most fundamental measures of central tendency in statistics. They help
                  us understand the "center" or "typical value" of a dataset, but they do so in different ways. The
                  mean, often called the average, is calculated by adding up all values and dividing by the count. The
                  median is the middle value when data is arranged in order. Understanding both measures is essential
                  for proper data analysis, as each has its strengths and appropriate use cases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  These statistical measures are used extensively across various fields including business analytics,
                  scientific research, economics, education, and healthcare. They form the foundation for more advanced
                  statistical concepts and are often the first step in understanding any dataset. Knowing when to use
                  mean versus median can significantly impact the conclusions drawn from data analysis.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Mean (Average)</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The arithmetic mean is the most commonly used measure of central tendency. To calculate it, you simply
                  add up all the values in your dataset and divide by the total number of values. For example, if you
                  have test scores of 80, 85, 90, 95, and 100, the mean would be (80 + 85 + 90 + 95 + 100) ÷ 5 = 90.
                  This gives you a single number that represents the "average" performance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The mean is particularly useful when data is symmetrically distributed without extreme outliers. It
                  takes every value into account, which can be both an advantage and a disadvantage. While it provides a
                  comprehensive summary, it can be heavily influenced by outliers. For instance, if one student scored
                  20 instead of 100, the mean would drop significantly, even though most students performed well. This
                  sensitivity to extreme values is why the mean isn't always the best choice for skewed data.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Median</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The median is the middle value in a sorted dataset. To find it, you first arrange all values from
                  smallest to largest, then identify the middle position. If you have an odd number of values, the
                  median is simply the middle number. If you have an even number of values, you take the average of the
                  two middle numbers. For example, in the dataset 2, 4, 6, 8, 10, the median is 6 (the third value in a
                  five-number set).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The median is particularly valuable when dealing with skewed data or datasets with outliers. Unlike
                  the mean, the median is resistant to extreme values because it only considers position, not magnitude.
                  This makes it ideal for situations like income analysis, where a few very high earners can
                  dramatically inflate the mean while the median better represents what a "typical" person earns. Real
                  estate prices, response times, and many other real-world measurements often use median for more
                  accurate representation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  <CardTitle>When to Use Mean vs. Median</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Choosing between mean and median depends on your data characteristics and analysis goals. Use the mean
                  when your data is roughly symmetric, has no significant outliers, and you want to include all values
                  in your calculation. The mean is ideal for normally distributed data, such as heights of adults or
                  standardized test scores in large populations.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Use Mean When:</h4>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>• Data is symmetric/normal</li>
                      <li>• No significant outliers</li>
                      <li>• All values matter equally</li>
                      <li>• Calculating totals is relevant</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Use Median When:</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Data is skewed</li>
                      <li>• Outliers are present</li>
                      <li>• Finding "typical" value</li>
                      <li>• Ordinal or ranked data</li>
                    </ul>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In practice, reporting both mean and median can provide valuable insights. When they're similar, your
                  data is likely symmetric. When they differ significantly, it suggests skewness in your data, with the
                  direction of skew indicated by which measure is larger. This comparison alone tells you important
                  information about your data's distribution.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
