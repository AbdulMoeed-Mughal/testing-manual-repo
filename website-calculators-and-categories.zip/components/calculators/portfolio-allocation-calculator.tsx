"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  PieChart,
  Info,
  AlertTriangle,
  TrendingUp,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, formatCurrency, currencySymbols, currencyOptions } from "@/lib/currency"

interface AssetClass {
  id: string
  name: string
  allocation: string
  expectedReturn: string
  risk: string
}

interface AllocationResult {
  assetAllocations: {
    name: string
    percentage: number
    amount: number
    expectedReturn: number
    risk: number
  }[]
  totalInvestment: number
  expectedPortfolioReturn: number
  portfolioRisk: number
  allocationStatus: "valid" | "under" | "over"
  totalAllocation: number
}

const defaultAssetClasses: AssetClass[] = [
  { id: "1", name: "Stocks", allocation: "50", expectedReturn: "10", risk: "18" },
  { id: "2", name: "Bonds", allocation: "30", expectedReturn: "5", risk: "6" },
  { id: "3", name: "Real Estate", allocation: "10", expectedReturn: "7", risk: "12" },
  { id: "4", name: "Cash", allocation: "10", expectedReturn: "2", risk: "1" },
]

const presetAssetClasses = [
  { name: "Stocks", expectedReturn: "10", risk: "18" },
  { name: "Bonds", expectedReturn: "5", risk: "6" },
  { name: "Real Estate", expectedReturn: "7", risk: "12" },
  { name: "Cash", expectedReturn: "2", risk: "1" },
  { name: "Commodities", expectedReturn: "6", risk: "15" },
  { name: "Cryptocurrency", expectedReturn: "15", risk: "50" },
  { name: "International Stocks", expectedReturn: "9", risk: "20" },
  { name: "Emerging Markets", expectedReturn: "11", risk: "25" },
  { name: "Gold", expectedReturn: "4", risk: "14" },
  { name: "REITs", expectedReturn: "8", risk: "16" },
]

const assetColors = [
  "bg-blue-500",
  "bg-green-500",
  "bg-yellow-500",
  "bg-purple-500",
  "bg-pink-500",
  "bg-indigo-500",
  "bg-red-500",
  "bg-orange-500",
  "bg-teal-500",
  "bg-cyan-500",
]

export function PortfolioAllocationCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [totalInvestment, setTotalInvestment] = useState("")
  const [assetClasses, setAssetClasses] = useState<AssetClass[]>(defaultAssetClasses)
  const [result, setResult] = useState<AllocationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showBreakdown, setShowBreakdown] = useState(false)

  const addAssetClass = () => {
    const newId = Date.now().toString()
    setAssetClasses([...assetClasses, { id: newId, name: "", allocation: "", expectedReturn: "", risk: "" }])
  }

  const removeAssetClass = (id: string) => {
    if (assetClasses.length > 1) {
      setAssetClasses(assetClasses.filter((asset) => asset.id !== id))
    }
  }

  const updateAssetClass = (id: string, field: keyof AssetClass, value: string) => {
    setAssetClasses(
      assetClasses.map((asset) => {
        if (asset.id === id) {
          if (field === "name") {
            const preset = presetAssetClasses.find((p) => p.name === value)
            if (preset) {
              return {
                ...asset,
                name: value,
                expectedReturn: preset.expectedReturn,
                risk: preset.risk,
              }
            }
          }
          return { ...asset, [field]: value }
        }
        return asset
      }),
    )
  }

  const calculateAllocation = () => {
    setError("")
    setResult(null)

    const investment = Number.parseFloat(totalInvestment)
    if (isNaN(investment) || investment <= 0) {
      setError("Please enter a valid total investment amount")
      return
    }

    const validAssets = assetClasses.filter(
      (asset) => asset.name && asset.allocation && Number.parseFloat(asset.allocation) > 0,
    )

    if (validAssets.length === 0) {
      setError("Please add at least one asset class with allocation")
      return
    }

    const totalAllocation = validAssets.reduce((sum, asset) => sum + Number.parseFloat(asset.allocation || "0"), 0)

    let allocationStatus: "valid" | "under" | "over" = "valid"
    if (totalAllocation < 99.9) {
      allocationStatus = "under"
    } else if (totalAllocation > 100.1) {
      allocationStatus = "over"
    }

    const assetAllocations = validAssets.map((asset) => {
      const percentage = Number.parseFloat(asset.allocation)
      const amount = (investment * percentage) / 100
      const expectedReturn = Number.parseFloat(asset.expectedReturn) || 0
      const risk = Number.parseFloat(asset.risk) || 0

      return {
        name: asset.name,
        percentage,
        amount,
        expectedReturn,
        risk,
      }
    })

    // Calculate weighted portfolio return
    const expectedPortfolioReturn = assetAllocations.reduce(
      (sum, asset) => sum + (asset.percentage / 100) * asset.expectedReturn,
      0,
    )

    // Calculate portfolio risk (simplified weighted standard deviation)
    const portfolioRisk = Math.sqrt(
      assetAllocations.reduce((sum, asset) => sum + Math.pow((asset.percentage / 100) * asset.risk, 2), 0),
    )

    setResult({
      assetAllocations,
      totalInvestment: investment,
      expectedPortfolioReturn,
      portfolioRisk,
      allocationStatus,
      totalAllocation,
    })
  }

  const handleReset = () => {
    setTotalInvestment("")
    setAssetClasses(defaultAssetClasses)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.assetAllocations
        .map((asset) => `${asset.name}: ${formatCurrency(asset.amount, currency)} (${asset.percentage}%)`)
        .join("\n")
      await navigator.clipboard.writeText(
        `Portfolio Allocation:\n${text}\nTotal: ${formatCurrency(result.totalInvestment, currency)}\nExpected Return: ${result.expectedPortfolioReturn.toFixed(2)}%\nPortfolio Risk: ${result.portfolioRisk.toFixed(2)}%`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Portfolio Allocation",
          text: `I created a portfolio allocation using CalcHub! Expected Return: ${result.expectedPortfolioReturn.toFixed(2)}%, Risk: ${result.portfolioRisk.toFixed(2)}%`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getRiskCategory = (risk: number) => {
    if (risk < 8) return { label: "Low Risk", color: "text-green-600", bg: "bg-green-50 border-green-200" }
    if (risk < 15) return { label: "Moderate Risk", color: "text-yellow-600", bg: "bg-yellow-50 border-yellow-200" }
    if (risk < 25) return { label: "High Risk", color: "text-orange-600", bg: "bg-orange-50 border-orange-200" }
    return { label: "Very High Risk", color: "text-red-600", bg: "bg-red-50 border-red-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <PieChart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Portfolio Allocation Calculator</CardTitle>
                    <CardDescription>Distribute investments across asset classes</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <Select value={currency} onValueChange={(value: Currency) => setCurrency(value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencyOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.symbol} {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Total Investment */}
                <div className="space-y-2">
                  <Label htmlFor="totalInvestment">Total Investment ({currencySymbols[currency]})</Label>
                  <Input
                    id="totalInvestment"
                    type="number"
                    placeholder="Enter total amount to invest"
                    value={totalInvestment}
                    onChange={(e) => setTotalInvestment(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Asset Classes */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Asset Classes</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addAssetClass}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Asset
                    </Button>
                  </div>

                  <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                    {assetClasses.map((asset, index) => (
                      <div key={asset.id} className="p-3 border rounded-lg bg-muted/30 space-y-2">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${assetColors[index % assetColors.length]}`} />
                          <Select
                            value={asset.name}
                            onValueChange={(value) => updateAssetClass(asset.id, "name", value)}
                          >
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Select asset class" />
                            </SelectTrigger>
                            <SelectContent>
                              {presetAssetClasses.map((preset) => (
                                <SelectItem key={preset.name} value={preset.name}>
                                  {preset.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => removeAssetClass(asset.id)}
                            disabled={assetClasses.length <= 1}
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <Label className="text-xs text-muted-foreground">Allocation %</Label>
                            <Input
                              type="number"
                              placeholder="0"
                              value={asset.allocation}
                              onChange={(e) => updateAssetClass(asset.id, "allocation", e.target.value)}
                              min="0"
                              max="100"
                              step="1"
                              className="h-8 text-sm"
                            />
                          </div>
                          <div>
                            <Label className="text-xs text-muted-foreground">Return %</Label>
                            <Input
                              type="number"
                              placeholder="0"
                              value={asset.expectedReturn}
                              onChange={(e) => updateAssetClass(asset.id, "expectedReturn", e.target.value)}
                              min="0"
                              step="0.5"
                              className="h-8 text-sm"
                            />
                          </div>
                          <div>
                            <Label className="text-xs text-muted-foreground">Risk %</Label>
                            <Input
                              type="number"
                              placeholder="0"
                              value={asset.risk}
                              onChange={(e) => updateAssetClass(asset.id, "risk", e.target.value)}
                              min="0"
                              step="1"
                              className="h-8 text-sm"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Total Allocation Indicator */}
                  {assetClasses.length > 0 && (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Total Allocation: </span>
                      <span
                        className={`font-medium ${
                          Math.abs(
                            assetClasses.reduce((sum, a) => sum + (Number.parseFloat(a.allocation) || 0), 0) - 100,
                          ) < 0.1
                            ? "text-green-600"
                            : "text-amber-600"
                        }`}
                      >
                        {assetClasses.reduce((sum, a) => sum + (Number.parseFloat(a.allocation) || 0), 0).toFixed(1)}%
                      </span>
                      {Math.abs(
                        assetClasses.reduce((sum, a) => sum + (Number.parseFloat(a.allocation) || 0), 0) - 100,
                      ) >= 0.1 && <span className="text-amber-600 text-xs ml-1">(should equal 100%)</span>}
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAllocation} className="w-full" size="lg">
                  Calculate Allocation
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    <div
                      className={`p-4 rounded-xl border-2 ${getRiskCategory(result.portfolioRisk).bg} transition-all duration-300`}
                    >
                      <div className="text-center mb-4">
                        <p className="text-sm text-muted-foreground mb-1">Portfolio Overview</p>
                        <p className="text-3xl font-bold text-foreground mb-1">
                          {formatCurrency(result.totalInvestment, currency)}
                        </p>
                        <p className={`text-sm font-medium ${getRiskCategory(result.portfolioRisk).color}`}>
                          {getRiskCategory(result.portfolioRisk).label}
                        </p>
                      </div>

                      {/* Allocation Status Warning */}
                      {result.allocationStatus !== "valid" && (
                        <div className="p-2 mb-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 text-sm text-center">
                          Total allocation is {result.totalAllocation.toFixed(1)}% (
                          {result.allocationStatus === "under" ? "under" : "over"} 100%)
                        </div>
                      )}

                      {/* Visual Allocation Bar */}
                      <div className="h-6 rounded-full overflow-hidden flex mb-4">
                        {result.assetAllocations.map((asset, index) => (
                          <div
                            key={asset.name}
                            className={`${assetColors[index % assetColors.length]} transition-all duration-300`}
                            style={{ width: `${asset.percentage}%` }}
                            title={`${asset.name}: ${asset.percentage}%`}
                          />
                        ))}
                      </div>

                      {/* Key Metrics */}
                      <div className="grid grid-cols-2 gap-3 mb-4">
                        <div className="p-3 bg-white/60 rounded-lg text-center">
                          <p className="text-xs text-muted-foreground">Expected Return</p>
                          <p className="text-lg font-bold text-green-600">
                            {result.expectedPortfolioReturn.toFixed(2)}%
                          </p>
                        </div>
                        <div className="p-3 bg-white/60 rounded-lg text-center">
                          <p className="text-xs text-muted-foreground">Portfolio Risk</p>
                          <p className={`text-lg font-bold ${getRiskCategory(result.portfolioRisk).color}`}>
                            {result.portfolioRisk.toFixed(2)}%
                          </p>
                        </div>
                      </div>

                      {/* Asset Breakdown */}
                      <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            Asset Breakdown
                            {showBreakdown ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="space-y-2">
                            {result.assetAllocations.map((asset, index) => (
                              <div
                                key={asset.name}
                                className="flex items-center justify-between p-2 bg-white/60 rounded-lg"
                              >
                                <div className="flex items-center gap-2">
                                  <div className={`w-3 h-3 rounded-full ${assetColors[index % assetColors.length]}`} />
                                  <span className="text-sm font-medium">{asset.name}</span>
                                </div>
                                <div className="text-right">
                                  <p className="text-sm font-semibold">{formatCurrency(asset.amount, currency)}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {asset.percentage}% | {asset.expectedReturn}% return
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>

                      {/* Action Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Risk Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low Risk</span>
                      <span className="text-sm text-green-600">{"< 8%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Risk</span>
                      <span className="text-sm text-yellow-600">8% – 15%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">High Risk</span>
                      <span className="text-sm text-orange-600">15% – 25%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very High Risk</span>
                      <span className="text-sm text-red-600">≥ 25%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Portfolio Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Expected Return = Σ(Weight × Asset Return)</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Risk ≈ √Σ(Weight × Asset Risk)²</p>
                  </div>
                  <p>
                    The expected portfolio return is the weighted average of individual asset returns. Portfolio risk is
                    estimated using a simplified weighted standard deviation.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Allocations</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-semibold text-foreground">Conservative (60/40)</p>
                    <p className="text-xs">60% Bonds, 40% Stocks - Lower risk, steady returns</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-semibold text-foreground">Balanced (60/40)</p>
                    <p className="text-xs">60% Stocks, 40% Bonds - Moderate risk/return</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-semibold text-foreground">Aggressive (80/20)</p>
                    <p className="text-xs">80% Stocks, 20% Bonds - Higher risk, growth focus</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Portfolio Allocation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Portfolio allocation, also known as asset allocation, is the process of dividing your investment
                  portfolio among different asset categories such as stocks, bonds, real estate, and cash. The goal is
                  to balance risk and reward according to your investment goals, risk tolerance, and time horizon.
                  Proper allocation is considered one of the most important factors in determining long-term investment
                  success.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept is based on the principle that different assets perform differently under various market
                  conditions. By spreading investments across multiple asset classes, you can potentially reduce the
                  overall volatility of your portfolio while still achieving your desired returns. This diversification
                  helps protect against significant losses in any single investment.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Start by entering your total investment amount. Then add the asset classes you want to include in your
                  portfolio. For each asset class, specify the allocation percentage (how much of your portfolio to
                  invest), expected annual return, and risk level (standard deviation). The calculator will show you how
                  your investment is distributed and estimate your portfolio's expected return and overall risk.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Make sure your allocation percentages add up to 100% for an accurate representation. You can use the
                  preset asset classes which include typical return and risk values, or customize them based on your own
                  research and expectations. Review the portfolio risk level to ensure it matches your risk tolerance.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-800 text-sm leading-relaxed">
                  Portfolio allocation calculations are estimates based on entered values and assumed returns. Actual
                  performance may vary due to market fluctuations, investment risks, fees, and other factors. Past
                  performance does not guarantee future results. This calculator is for educational purposes only and
                  should not be considered financial advice. Consult a qualified financial advisor for personalized
                  investment guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
