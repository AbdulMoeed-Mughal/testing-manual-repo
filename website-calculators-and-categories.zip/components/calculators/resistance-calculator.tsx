"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, Calculator, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type CalculationMethod = "ohms-law" | "material" | "temperature"
type ResistanceUnit = "ohms" | "milliohms" | "kilohms" | "megaohms"

interface ResistanceResult {
  resistance: number
  unit: ResistanceUnit
  steps: string[]
}

export function ResistanceCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("ohms-law")
  const [voltage, setVoltage] = useState("")
  const [current, setCurrent] = useState("")
  const [resistivity, setResistivity] = useState("")
  const [length, setLength] = useState("")
  const [area, setArea] = useState("")
  const [baseResistance, setBaseResistance] = useState("")
  const [tempCoefficient, setTempCoefficient] = useState("")
  const [baseTemp, setBaseTemp] = useState("20")
  const [finalTemp, setFinalTemp] = useState("")
  const [outputUnit, setOutputUnit] = useState<ResistanceUnit>("ohms")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<ResistanceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(false)

  const unitMultipliers: Record<ResistanceUnit, number> = {
    milliohms: 1000,
    ohms: 1,
    kilohms: 0.001,
    megaohms: 0.000001,
  }

  const unitLabels: Record<ResistanceUnit, string> = {
    milliohms: "mΩ",
    ohms: "Ω",
    kilohms: "kΩ",
    megaohms: "MΩ",
  }

  const calculate = () => {
    setError("")
    setResult(null)
    const steps: string[] = []

    let resistanceOhms = 0

    if (method === "ohms-law") {
      const V = Number.parseFloat(voltage)
      const I = Number.parseFloat(current)

      if (isNaN(V) || V < 0) {
        setError("Please enter a valid voltage (≥ 0)")
        return
      }
      if (isNaN(I) || I <= 0) {
        setError("Please enter a valid current (> 0)")
        return
      }

      resistanceOhms = V / I
      steps.push(`Using Ohm's Law: R = V / I`)
      steps.push(`R = ${V} V / ${I} A`)
      steps.push(`R = ${resistanceOhms.toFixed(6)} Ω`)
    } else if (method === "material") {
      const rho = Number.parseFloat(resistivity)
      const L = Number.parseFloat(length)
      const A = Number.parseFloat(area)

      if (isNaN(rho) || rho <= 0) {
        setError("Please enter a valid resistivity (> 0)")
        return
      }
      if (isNaN(L) || L <= 0) {
        setError("Please enter a valid length (> 0)")
        return
      }
      if (isNaN(A) || A <= 0) {
        setError("Please enter a valid area (> 0)")
        return
      }

      resistanceOhms = rho * (L / A)
      steps.push(`Using material formula: R = ρ × (L / A)`)
      steps.push(`R = ${rho} Ω·m × (${L} m / ${A} m²)`)
      steps.push(`R = ${rho} × ${(L / A).toFixed(6)}`)
      steps.push(`R = ${resistanceOhms.toFixed(6)} Ω`)
    } else if (method === "temperature") {
      const R0 = Number.parseFloat(baseResistance)
      const alpha = Number.parseFloat(tempCoefficient)
      const T0 = Number.parseFloat(baseTemp)
      const T = Number.parseFloat(finalTemp)

      if (isNaN(R0) || R0 <= 0) {
        setError("Please enter a valid base resistance (> 0)")
        return
      }
      if (isNaN(alpha)) {
        setError("Please enter a valid temperature coefficient")
        return
      }
      if (isNaN(T0)) {
        setError("Please enter a valid base temperature")
        return
      }
      if (isNaN(T)) {
        setError("Please enter a valid final temperature")
        return
      }

      const tempDiff = T - T0
      resistanceOhms = R0 * (1 + alpha * tempDiff)
      steps.push(`Using temperature formula: R = R₀ × [1 + α × (T − T₀)]`)
      steps.push(`R = ${R0} Ω × [1 + ${alpha} × (${T} − ${T0})]`)
      steps.push(`R = ${R0} × [1 + ${alpha} × ${tempDiff}]`)
      steps.push(`R = ${R0} × [1 + ${(alpha * tempDiff).toFixed(6)}]`)
      steps.push(`R = ${R0} × ${(1 + alpha * tempDiff).toFixed(6)}`)
      steps.push(`R = ${resistanceOhms.toFixed(6)} Ω`)
    }

    // Convert to output unit
    const convertedResistance = resistanceOhms * unitMultipliers[outputUnit]
    steps.push(`Converting to ${unitLabels[outputUnit]}: ${convertedResistance.toFixed(6)} ${unitLabels[outputUnit]}`)

    setResult({
      resistance: convertedResistance,
      unit: outputUnit,
      steps,
    })
  }

  const handleReset = () => {
    setVoltage("")
    setCurrent("")
    setResistivity("")
    setLength("")
    setArea("")
    setBaseResistance("")
    setTempCoefficient("")
    setBaseTemp("20")
    setFinalTemp("")
    setResult(null)
    setError("")
    setCopied(false)
    setStepsOpen(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Resistance: ${result.resistance.toFixed(4)} ${unitLabels[result.unit]}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Resistance Calculation Result",
          text: `I calculated electrical resistance using CalcHub! Result: ${result.resistance.toFixed(4)} ${unitLabels[result.unit]}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Resistance Calculator</CardTitle>
                    <CardDescription>Calculate electrical resistance</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Method */}
                <div className="space-y-2">
                  <Label>Calculation Method</Label>
                  <Select value={method} onValueChange={(v) => setMethod(v as CalculationMethod)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ohms-law">Ohm's Law (R = V/I)</SelectItem>
                      <SelectItem value="material">Material Properties (R = ρL/A)</SelectItem>
                      <SelectItem value="temperature">Temperature Adjustment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Ohm's Law Inputs */}
                {method === "ohms-law" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="voltage">Voltage (V)</Label>
                      <Input
                        id="voltage"
                        type="number"
                        placeholder="Enter voltage in volts"
                        value={voltage}
                        onChange={(e) => setVoltage(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="current">Current (A)</Label>
                      <Input
                        id="current"
                        type="number"
                        placeholder="Enter current in amperes"
                        value={current}
                        onChange={(e) => setCurrent(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                  </>
                )}

                {/* Material Properties Inputs */}
                {method === "material" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="resistivity">Resistivity ρ (Ω·m)</Label>
                      <Input
                        id="resistivity"
                        type="number"
                        placeholder="e.g., 1.68e-8 for copper"
                        value={resistivity}
                        onChange={(e) => setResistivity(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="length">Length L (m)</Label>
                      <Input
                        id="length"
                        type="number"
                        placeholder="Enter wire length in meters"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="area">Cross-sectional Area A (m²)</Label>
                      <Input
                        id="area"
                        type="number"
                        placeholder="e.g., 1e-6 for 1 mm²"
                        value={area}
                        onChange={(e) => setArea(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Temperature Adjustment Inputs */}
                {method === "temperature" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="baseResistance">Base Resistance R₀ (Ω)</Label>
                      <Input
                        id="baseResistance"
                        type="number"
                        placeholder="Enter base resistance"
                        value={baseResistance}
                        onChange={(e) => setBaseResistance(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tempCoefficient">Temperature Coefficient α (1/°C)</Label>
                      <Input
                        id="tempCoefficient"
                        type="number"
                        placeholder="e.g., 0.00393 for copper"
                        value={tempCoefficient}
                        onChange={(e) => setTempCoefficient(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="baseTemp">Base Temp T₀ (°C)</Label>
                        <Input
                          id="baseTemp"
                          type="number"
                          placeholder="e.g., 20"
                          value={baseTemp}
                          onChange={(e) => setBaseTemp(e.target.value)}
                          step="0.1"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="finalTemp">Final Temp T (°C)</Label>
                        <Input
                          id="finalTemp"
                          type="number"
                          placeholder="Enter final temperature"
                          value={finalTemp}
                          onChange={(e) => setFinalTemp(e.target.value)}
                          step="0.1"
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <Select value={outputUnit} onValueChange={(v) => setOutputUnit(v as ResistanceUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="milliohms">Milliohms (mΩ)</SelectItem>
                      <SelectItem value="ohms">Ohms (Ω)</SelectItem>
                      <SelectItem value="kilohms">Kilohms (kΩ)</SelectItem>
                      <SelectItem value="megaohms">Megaohms (MΩ)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step solution</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Resistance
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Resistance</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">
                        {result.resistance < 0.0001 || result.resistance > 1000000
                          ? result.resistance.toExponential(4)
                          : result.resistance.toFixed(4)}
                      </p>
                      <p className="text-lg font-semibold text-amber-700">{unitLabels[result.unit]}</p>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="outline" size="sm" className="w-full bg-transparent">
                            {stepsOpen ? (
                              <>
                                <ChevronUp className="h-4 w-4 mr-2" />
                                Hide Steps
                              </>
                            ) : (
                              <>
                                <ChevronDown className="h-4 w-4 mr-2" />
                                Show Steps
                              </>
                            )}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-3">
                          <div className="p-3 bg-white rounded-lg border space-y-1">
                            {result.steps.map((step, i) => (
                              <p key={i} className="text-sm font-mono text-muted-foreground">
                                {step}
                              </p>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Resistance Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-1">Ohm's Law</p>
                    <p className="font-mono text-center text-lg">R = V / I</p>
                    <p className="text-xs text-muted-foreground mt-1">V = Voltage, I = Current</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-1">Material Properties</p>
                    <p className="font-mono text-center text-lg">R = ρ × (L / A)</p>
                    <p className="text-xs text-muted-foreground mt-1">ρ = Resistivity, L = Length, A = Area</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-1">Temperature Adjustment</p>
                    <p className="font-mono text-center text-lg">R = R₀[1 + α(T−T₀)]</p>
                    <p className="text-xs text-muted-foreground mt-1">α = Temp coefficient, T = Temperature</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Material Properties</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Copper</span>
                      <span className="font-mono">ρ = 1.68×10⁻⁸ Ω·m</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Aluminum</span>
                      <span className="font-mono">ρ = 2.65×10⁻⁸ Ω·m</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Silver</span>
                      <span className="font-mono">ρ = 1.59×10⁻⁸ Ω·m</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Gold</span>
                      <span className="font-mono">ρ = 2.44×10⁻⁸ Ω·m</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Iron</span>
                      <span className="font-mono">ρ = 9.71×10⁻⁸ Ω·m</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Temperature Coefficients</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Copper</span>
                      <span className="font-mono">α = 0.00393 /°C</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Aluminum</span>
                      <span className="font-mono">α = 0.00429 /°C</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Silver</span>
                      <span className="font-mono">α = 0.00380 /°C</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Gold</span>
                      <span className="font-mono">α = 0.00340 /°C</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Electrical Resistance?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrical resistance is a measure of the opposition that a circuit presents to the flow of electric
                  current. It is measured in ohms (Ω), named after German physicist Georg Ohm. Resistance depends on the
                  material properties, dimensions (length and cross-sectional area), and temperature of the conductor.
                  Understanding resistance is fundamental to designing and analyzing electrical circuits.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Ohm's Law (R = V/I) describes the relationship between voltage (V), current (I), and resistance (R).
                  For a given voltage, a higher resistance results in lower current flow. This principle is used
                  extensively in electronics for current limiting, voltage division, and signal conditioning.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Resistance</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence the resistance of a conductor: <strong>Material</strong> - Different
                  materials have different resistivities; copper and silver are excellent conductors with low
                  resistivity, while rubber and glass are insulators. <strong>Length</strong> - Resistance increases
                  proportionally with the length of the conductor. <strong>Cross-sectional area</strong> - Resistance
                  decreases as the area increases, which is why thicker wires have lower resistance.
                  <strong>Temperature</strong> - For most metals, resistance increases with temperature due to increased
                  atomic vibrations that impede electron flow.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Resistance calculations are estimates based on ideal conditions. Actual
                  resistance may vary due to temperature, material impurities, or manufacturing tolerances. Consult
                  technical references or an electrical engineer for precise measurements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
