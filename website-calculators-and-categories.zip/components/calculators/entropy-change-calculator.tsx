"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Thermometer, Info, AlertTriangle, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMode = "heat" | "standard"

interface EntropyResult {
  deltaS: number
  unit: string
  sign: string
  color: string
  bgColor: string
}

export function EntropyChangeCalculator() {
  const [mode, setMode] = useState<CalculationMode>("heat")
  const [energyUnit, setEnergyUnit] = useState<"J" | "kJ">("J")
  const [heat, setHeat] = useState("")
  const [temperature, setTemperature] = useState("")
  const [productsEntropy, setProductsEntropy] = useState("")
  const [reactantsEntropy, setReactantsEntropy] = useState("")
  const [result, setResult] = useState<EntropyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    if (mode === "heat") {
      const q = Number.parseFloat(heat)
      const T = Number.parseFloat(temperature)

      if (isNaN(q)) {
        setError("Please enter a valid heat value")
        return
      }
      if (isNaN(T) || T <= 0) {
        setError("Temperature must be a positive value in Kelvin")
        return
      }

      // Convert kJ to J if needed for calculation
      const qInJoules = energyUnit === "kJ" ? q * 1000 : q
      const deltaS = qInJoules / T

      // Determine output unit based on magnitude
      let displayValue: number
      let displayUnit: string
      if (Math.abs(deltaS) >= 1000) {
        displayValue = deltaS / 1000
        displayUnit = "kJ/K"
      } else {
        displayValue = deltaS
        displayUnit = "J/K"
      }

      const sign = deltaS > 0 ? "Increase in disorder" : deltaS < 0 ? "Decrease in disorder" : "No change"
      const color = deltaS > 0 ? "text-green-600" : deltaS < 0 ? "text-blue-600" : "text-gray-600"
      const bgColor = deltaS > 0 ? "bg-green-50 border-green-200" : deltaS < 0 ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200"

      setResult({
        deltaS: Math.round(displayValue * 1000) / 1000,
        unit: displayUnit,
        sign,
        color,
        bgColor,
      })
    } else {
      const sProducts = Number.parseFloat(productsEntropy)
      const sReactants = Number.parseFloat(reactantsEntropy)

      if (isNaN(sProducts)) {
        setError("Please enter a valid entropy value for products")
        return
      }
      if (isNaN(sReactants)) {
        setError("Please enter a valid entropy value for reactants")
        return
      }

      const deltaS = sProducts - sReactants
      const sign = deltaS > 0 ? "Increase in disorder" : deltaS < 0 ? "Decrease in disorder" : "No change"
      const color = deltaS > 0 ? "text-green-600" : deltaS < 0 ? "text-blue-600" : "text-gray-600"
      const bgColor = deltaS > 0 ? "bg-green-50 border-green-200" : deltaS < 0 ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200"

      setResult({
        deltaS: Math.round(deltaS * 1000) / 1000,
        unit: "J/(mol·K)",
        sign,
        color,
        bgColor,
      })
    }
  }

  const handleReset = () => {
    setHeat("")
    setTemperature("")
    setProductsEntropy("")
    setReactantsEntropy("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Entropy Change (ΔS) = ${result.deltaS} ${result.unit} (${result.sign})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Entropy Change Result",
          text: `I calculated entropy change using CalcHub! ΔS = ${result.deltaS} ${result.unit} (${result.sign})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Thermometer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Entropy Change Calculator</CardTitle>
                    <CardDescription>Calculate entropy change (ΔS)</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Method</span>
                  <button
                    onClick={() => {
                      setMode(mode === "heat" ? "standard" : "heat")
                      handleReset()
                    }}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "standard" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "heat" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Heat/Temp
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "standard" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Standard
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {mode === "heat" ? (
                  <>
                    {/* Energy Unit Selection */}
                    <div className="space-y-2">
                      <Label>Energy Unit</Label>
                      <div className="flex gap-2">
                        {(["J", "kJ"] as const).map((unit) => (
                          <button
                            key={unit}
                            onClick={() => setEnergyUnit(unit)}
                            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                              energyUnit === unit
                                ? "bg-primary text-primary-foreground"
                                : "bg-muted text-muted-foreground hover:bg-muted/80"
                            }`}
                          >
                            {unit}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Heat Input */}
                    <div className="space-y-2">
                      <Label htmlFor="heat">Heat Absorbed/Released (q) in {energyUnit}</Label>
                      <Input
                        id="heat"
                        type="number"
                        placeholder={`Enter heat in ${energyUnit} (positive = absorbed)`}
                        value={heat}
                        onChange={(e) => setHeat(e.target.value)}
                        step="any"
                      />
                    </div>

                    {/* Temperature Input */}
                    <div className="space-y-2">
                      <Label htmlFor="temperature">Temperature (K)</Label>
                      <Input
                        id="temperature"
                        type="number"
                        placeholder="Enter temperature in Kelvin"
                        value={temperature}
                        onChange={(e) => setTemperature(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    {/* Products Entropy Input */}
                    <div className="space-y-2">
                      <Label htmlFor="products">Sum of Products Entropy (ΣS°products) in J/(mol·K)</Label>
                      <Input
                        id="products"
                        type="number"
                        placeholder="Enter total entropy of products"
                        value={productsEntropy}
                        onChange={(e) => setProductsEntropy(e.target.value)}
                        step="any"
                      />
                    </div>

                    {/* Reactants Entropy Input */}
                    <div className="space-y-2">
                      <Label htmlFor="reactants">Sum of Reactants Entropy (ΣS°reactants) in J/(mol·K)</Label>
                      <Input
                        id="reactants"
                        type="number"
                        placeholder="Enter total entropy of reactants"
                        value={reactantsEntropy}
                        onChange={(e) => setReactantsEntropy(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate ΔS
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Entropy Change (ΔS)</p>
                      <p className={`text-5xl font-bold ${result.color} mb-1`}>{result.deltaS}</p>
                      <p className="text-lg text-muted-foreground mb-2">{result.unit}</p>
                      <p className={`text-sm font-semibold ${result.color}`}>{result.sign}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Entropy Change Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ΔS = q<sub>rev</sub> / T</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ΔS° = ΣS°<sub>products</sub> - ΣS°<sub>reactants</sub></p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Where q is heat in Joules, T is temperature in Kelvin, and S° values are standard molar entropies.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sign Interpretation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">ΔS {">"} 0</span>
                      <span className="text-sm text-green-600">Increase in disorder</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">ΔS {"<"} 0</span>
                      <span className="text-sm text-blue-600">Decrease in disorder</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <span className="font-medium text-gray-700">ΔS = 0</span>
                      <span className="text-sm text-gray-600">No change (equilibrium)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Content Cards */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Entropy?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Entropy (S) is a fundamental thermodynamic property that measures the degree of randomness or disorder
                  in a system. It was first introduced by Rudolf Clausius in 1865 and has become one of the most important
                  concepts in chemistry, physics, and information theory. The second law of thermodynamics states that
                  the total entropy of an isolated system can never decrease over time, and will remain constant only if
                  all processes are reversible.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In practical terms, entropy helps us understand why certain processes occur spontaneously while others
                  do not. A positive entropy change (ΔS {">"} 0) indicates that the system becomes more disordered, which
                  is generally favored in nature. Examples include ice melting, gas expansion, and the dissolution of
                  solids in liquids.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Entropy and Spontaneity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Entropy change is crucial for determining whether a reaction will occur spontaneously. While a positive
                  ΔS favors spontaneity, the overall spontaneity of a process depends on both entropy and enthalpy changes.
                  This relationship is captured in the Gibbs free energy equation: ΔG = ΔH - TΔS. A reaction is spontaneous
                  when ΔG {"<"} 0.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  At high temperatures, the TΔS term becomes more significant, meaning entropy-driven processes become
                  more favorable. This explains why endothermic reactions (ΔH {">"} 0) can still be spontaneous if they
                  have a sufficiently large positive entropy change and occur at high enough temperatures.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Entropy</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence the entropy of a substance or system. Phase changes significantly affect
                  entropy: gases have higher entropy than liquids, which have higher entropy than solids. This is because
                  gas molecules have more freedom of movement and can occupy more microstates than molecules in condensed
                  phases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature also plays a crucial role - as temperature increases, molecular motion increases, leading
                  to higher entropy. Additionally, the number of particles matters: reactions that produce more moles of
                  products than reactants typically have positive entropy changes. Molecular complexity and the number
                  of atoms in a molecule also contribute to its entropy.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator assumes ideal conditions and reversible processes. In real systems, irreversible
                  processes produce additional entropy, making actual entropy changes larger than calculated values.
                  The formula ΔS = q/T is strictly valid only for reversible processes at constant temperature.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Standard molar entropy values are measured at specific conditions (typically 298 K and 1 atm) and may
                  not accurately represent entropy at different temperatures or pressures. For precise calculations in
                  non-standard conditions, temperature and pressure corrections may be necessary.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Disclaimer:</strong> Entropy calculations assume reversible processes or ideal conditions.
                    Real systems may vary due to irreversibility or non-ideal effects.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
