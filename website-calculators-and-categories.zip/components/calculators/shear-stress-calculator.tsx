"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, Wrench, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type InputMode = "direct" | "dimensions"
type CrossSection = "rectangular" | "circular"
type ForceUnit = "N" | "kN" | "lb" | "kip"
type AreaUnit = "m2" | "cm2" | "mm2" | "in2" | "ft2"
type StressUnit = "Pa" | "kPa" | "MPa" | "GPa" | "psi" | "ksi"

interface ShearStressResult {
  stress: number
  stressUnit: StressUnit
  area: number
  areaUnit: AreaUnit
  category: string
  color: string
  bgColor: string
}

export function ShearStressCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("direct")
  const [crossSection, setCrossSection] = useState<CrossSection>("rectangular")
  const [shearForce, setShearForce] = useState("")
  const [forceUnit, setForceUnit] = useState<ForceUnit>("N")
  const [area, setArea] = useState("")
  const [areaUnit, setAreaUnit] = useState<AreaUnit>("m2")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [diameter, setDiameter] = useState("")
  const [dimensionUnit, setDimensionUnit] = useState<AreaUnit>("m2")
  const [stressUnit, setStressUnit] = useState<StressUnit>("Pa")
  const [result, setResult] = useState<ShearStressResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Unit conversion factors to base units (N and m²)
  const forceToNewtons: Record<ForceUnit, number> = {
    N: 1,
    kN: 1000,
    lb: 4.44822,
    kip: 4448.22,
  }

  const areaToM2: Record<AreaUnit, number> = {
    m2: 1,
    cm2: 1e-4,
    mm2: 1e-6,
    in2: 6.4516e-4,
    ft2: 0.092903,
  }

  const stressFromPa: Record<StressUnit, number> = {
    Pa: 1,
    kPa: 1e-3,
    MPa: 1e-6,
    GPa: 1e-9,
    psi: 1.45038e-4,
    ksi: 1.45038e-7,
  }

  const dimensionToM: Record<AreaUnit, number> = {
    m2: 1,
    cm2: 0.01,
    mm2: 0.001,
    in2: 0.0254,
    ft2: 0.3048,
  }

  const calculateShearStress = () => {
    setError("")
    setResult(null)

    const V = Number.parseFloat(shearForce)
    if (isNaN(V) || V <= 0) {
      setError("Please enter a valid shear force greater than 0")
      return
    }

    let A: number

    if (inputMode === "direct") {
      const areaNum = Number.parseFloat(area)
      if (isNaN(areaNum) || areaNum <= 0) {
        setError("Please enter a valid cross-sectional area greater than 0")
        return
      }
      A = areaNum * areaToM2[areaUnit]
    } else {
      if (crossSection === "rectangular") {
        const w = Number.parseFloat(width)
        const h = Number.parseFloat(height)
        if (isNaN(w) || w <= 0 || isNaN(h) || h <= 0) {
          setError("Please enter valid width and height greater than 0")
          return
        }
        const wM = w * dimensionToM[dimensionUnit]
        const hM = h * dimensionToM[dimensionUnit]
        A = wM * hM
      } else {
        const d = Number.parseFloat(diameter)
        if (isNaN(d) || d <= 0) {
          setError("Please enter a valid diameter greater than 0")
          return
        }
        const dM = d * dimensionToM[dimensionUnit]
        A = Math.PI * Math.pow(dM / 2, 2)
      }
    }

    // Convert force to Newtons
    const forceInNewtons = V * forceToNewtons[forceUnit]

    // Calculate shear stress in Pa
    const stressInPa = forceInNewtons / A

    // Convert to selected stress unit
    const stressValue = stressInPa * stressFromPa[stressUnit]

    // Categorize stress level (based on typical structural steel yield shear ~150 MPa)
    let category: string
    let color: string
    let bgColor: string
    const stressInMPa = stressInPa * 1e-6

    if (stressInMPa < 50) {
      category = "Low Stress"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (stressInMPa < 100) {
      category = "Moderate Stress"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (stressInMPa < 150) {
      category = "High Stress"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Very High Stress"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      stress: stressValue,
      stressUnit,
      area: A / areaToM2[areaUnit],
      areaUnit,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setShearForce("")
    setArea("")
    setWidth("")
    setHeight("")
    setDiameter("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Shear Stress: ${result.stress.toExponential(4)} ${result.stressUnit} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1e6 || Math.abs(num) < 0.001) {
      return num.toExponential(4)
    }
    return num.toFixed(4)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Wrench className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Shear Stress Calculator</CardTitle>
                    <CardDescription>Calculate shear stress in structural members</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={() => {
                      setInputMode(inputMode === "direct" ? "dimensions" : "direct")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "dimensions" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "direct" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Direct
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "dimensions" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Dimensions
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Shear Force Input */}
                <div className="space-y-2">
                  <Label htmlFor="shearForce">Shear Force (V)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="shearForce"
                      type="number"
                      placeholder="Enter shear force"
                      value={shearForce}
                      onChange={(e) => setShearForce(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <select
                      value={forceUnit}
                      onChange={(e) => setForceUnit(e.target.value as ForceUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="N">N</option>
                      <option value="kN">kN</option>
                      <option value="lb">lb</option>
                      <option value="kip">kip</option>
                    </select>
                  </div>
                </div>

                {/* Area Input (Direct Mode) */}
                {inputMode === "direct" && (
                  <div className="space-y-2">
                    <Label htmlFor="area">Cross-sectional Area (A)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="area"
                        type="number"
                        placeholder="Enter area"
                        value={area}
                        onChange={(e) => setArea(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <select
                        value={areaUnit}
                        onChange={(e) => setAreaUnit(e.target.value as AreaUnit)}
                        className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                      >
                        <option value="m2">m²</option>
                        <option value="cm2">cm²</option>
                        <option value="mm2">mm²</option>
                        <option value="in2">in²</option>
                        <option value="ft2">ft²</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* Dimensions Input (Dimensions Mode) */}
                {inputMode === "dimensions" && (
                  <>
                    {/* Cross-section Type */}
                    <div className="space-y-2">
                      <Label>Cross-section Type</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => setCrossSection("rectangular")}
                          className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                            crossSection === "rectangular"
                              ? "border-primary bg-primary/5 text-primary"
                              : "border-muted hover:border-muted-foreground/50"
                          }`}
                        >
                          Rectangular
                        </button>
                        <button
                          onClick={() => setCrossSection("circular")}
                          className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                            crossSection === "circular"
                              ? "border-primary bg-primary/5 text-primary"
                              : "border-muted hover:border-muted-foreground/50"
                          }`}
                        >
                          Circular
                        </button>
                      </div>
                    </div>

                    {/* Dimension Unit */}
                    <div className="space-y-2">
                      <Label>Dimension Unit</Label>
                      <select
                        value={dimensionUnit}
                        onChange={(e) => setDimensionUnit(e.target.value as AreaUnit)}
                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      >
                        <option value="m2">meters (m)</option>
                        <option value="cm2">centimeters (cm)</option>
                        <option value="mm2">millimeters (mm)</option>
                        <option value="in2">inches (in)</option>
                        <option value="ft2">feet (ft)</option>
                      </select>
                    </div>

                    {crossSection === "rectangular" ? (
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor="width">Width (b)</Label>
                          <Input
                            id="width"
                            type="number"
                            placeholder="Width"
                            value={width}
                            onChange={(e) => setWidth(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="height">Height (h)</Label>
                          <Input
                            id="height"
                            type="number"
                            placeholder="Height"
                            value={height}
                            onChange={(e) => setHeight(e.target.value)}
                            min="0"
                            step="any"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Label htmlFor="diameter">Diameter (d)</Label>
                        <Input
                          id="diameter"
                          type="number"
                          placeholder="Enter diameter"
                          value={diameter}
                          onChange={(e) => setDiameter(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                    )}
                  </>
                )}

                {/* Output Unit */}
                <div className="space-y-2">
                  <Label>Stress Output Unit</Label>
                  <select
                    value={stressUnit}
                    onChange={(e) => setStressUnit(e.target.value as StressUnit)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="Pa">Pascal (Pa)</option>
                    <option value="kPa">Kilopascal (kPa)</option>
                    <option value="MPa">Megapascal (MPa)</option>
                    <option value="GPa">Gigapascal (GPa)</option>
                    <option value="psi">psi</option>
                    <option value="ksi">ksi</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateShearStress} className="w-full" size="lg">
                  Calculate Shear Stress
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Shear Stress (τ)</p>
                      <p className={`text-3xl font-bold ${result.color} mb-1`}>
                        {formatNumber(result.stress)} {result.stressUnit}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Toggle Steps */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-1">
                        <p>
                          <strong>Formula:</strong> τ = V / A
                        </p>
                        <p>
                          <strong>Shear Force (V):</strong> {shearForce} {forceUnit}
                        </p>
                        <p>
                          <strong>Area (A):</strong> {formatNumber(result.area)} {result.areaUnit}
                        </p>
                        <p>
                          <strong>Result:</strong> τ = {formatNumber(result.stress)} {result.stressUnit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Shear Stress Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-lg">τ = V / A</p>
                  </div>
                  <p>Where:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>
                      <strong>τ</strong> = Shear stress (Pa or psi)
                    </li>
                    <li>
                      <strong>V</strong> = Applied shear force (N or lb)
                    </li>
                    <li>
                      <strong>A</strong> = Cross-sectional area (m² or in²)
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cross-section Area Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Rectangular</span>
                      <span className="text-sm text-blue-600 font-mono">A = b × h</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Circular</span>
                      <span className="text-sm text-purple-600 font-mono">A = π(d/2)²</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Conversions</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <div className="space-y-2">
                    <p>1 MPa = 1,000,000 Pa</p>
                    <p>1 ksi = 6.895 MPa</p>
                    <p>1 psi = 6,894.76 Pa</p>
                    <p>1 kN = 1,000 N</p>
                    <p>1 kip = 4,448.22 N</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Shear Stress?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Shear stress is the stress component parallel to the cross-section of a material. It occurs when
                  forces are applied in opposite directions along parallel planes, causing the material to slide or
                  deform. Unlike normal stress (tension or compression) which acts perpendicular to the surface, shear
                  stress acts along the surface of the material.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In structural engineering, shear stress is critical in the design of beams, bolts, rivets, welds, and
                  other connections. Understanding shear stress helps engineers ensure that structural members can
                  safely resist applied loads without failure due to shearing forces.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Shear Stress</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Shear stress analysis is essential in many engineering applications including beam design where
                  vertical loads create internal shear forces, bolt and rivet connections where shear forces transfer
                  loads between connected parts, shaft design where torsional loads create shear stress, and cutting
                  operations in manufacturing processes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Engineers compare calculated shear stress values against the shear strength of materials to ensure
                  adequate safety factors. For ductile materials like steel, the shear yield strength is typically about
                  0.577 times the tensile yield strength (von Mises criterion).
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Shear stress calculations are estimates based on ideal assumptions. Actual stress may vary due to
                  material defects, load distribution, stress concentrations, and boundary conditions. This calculator
                  assumes uniform stress distribution across the cross-section. For critical applications, consult
                  engineering references and qualified professionals for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
