"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Flame, Info, ActivityIcon, Zap, Timer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type Intensity = "low" | "moderate" | "high"

interface Activity {
  id: string
  name: string
  icon: string
  met: { low: number; moderate: number; high: number }
}

const activities: Activity[] = [
  { id: "running", name: "Running", icon: "🏃", met: { low: 8, moderate: 10, high: 12 } },
  { id: "walking", name: "Walking", icon: "🚶", met: { low: 2.5, moderate: 3.5, high: 5 } },
  { id: "cycling", name: "Cycling", icon: "🚴", met: { low: 6, moderate: 8, high: 12 } },
  { id: "swimming", name: "Swimming", icon: "🏊", met: { low: 6, moderate: 8, high: 10 } },
  { id: "strength", name: "Strength Training", icon: "🏋️", met: { low: 3, moderate: 5, high: 6 } },
  { id: "hiit", name: "HIIT / Cardio", icon: "⚡", met: { low: 8, moderate: 10, high: 12 } },
  { id: "yoga", name: "Yoga", icon: "🧘", met: { low: 2, moderate: 3, high: 4 } },
  { id: "dancing", name: "Dancing", icon: "💃", met: { low: 4, moderate: 6, high: 8 } },
]

interface CaloriesResult {
  totalCalories: number
  caloriesPerMinute: number
  met: number
  activity: string
  duration: number
  weight: number
}

export function CaloriesBurnedCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [weight, setWeight] = useState("")
  const [age, setAge] = useState("")
  const [selectedActivity, setSelectedActivity] = useState<string>("running")
  const [duration, setDuration] = useState("")
  const [intensity, setIntensity] = useState<Intensity>("moderate")
  const [result, setResult] = useState<CaloriesResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCalories = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const ageNum = Number.parseFloat(age)
    const durationNum = Number.parseFloat(duration)

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(ageNum) || ageNum < 10) {
      setError("Please enter a valid age (10 years or older)")
      return
    }

    if (isNaN(durationNum) || durationNum <= 0) {
      setError("Please enter a valid duration greater than 0")
      return
    }

    // Convert weight to kg if imperial
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Get the activity and MET value
    const activity = activities.find((a) => a.id === selectedActivity)
    if (!activity) {
      setError("Please select an activity")
      return
    }

    const met = activity.met[intensity]

    // Formula: Calories burned per minute = (MET × 3.5 × weight in kg) / 200
    const caloriesPerMinute = (met * 3.5 * weightInKg) / 200
    const totalCalories = caloriesPerMinute * durationNum

    setResult({
      totalCalories: Math.round(totalCalories),
      caloriesPerMinute: Math.round(caloriesPerMinute * 10) / 10,
      met,
      activity: activity.name,
      duration: durationNum,
      weight: weightInKg,
    })
  }

  const handleReset = () => {
    setWeight("")
    setAge("")
    setDuration("")
    setSelectedActivity("running")
    setIntensity("moderate")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `I burned approximately ${result.totalCalories} calories doing ${result.activity} for ${result.duration} minutes!`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Calories Burned",
          text: `I burned approximately ${result.totalCalories} calories doing ${result.activity} for ${result.duration} minutes! Calculate yours at CalcHub.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Calories Burned Calculator</CardTitle>
                    <CardDescription>Estimate calories burned during exercise</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender (optional)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setGender("male")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        gender === "male"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted bg-background text-muted-foreground hover:border-primary/50"
                      }`}
                    >
                      Male
                    </button>
                    <button
                      onClick={() => setGender("female")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        gender === "female"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted bg-background text-muted-foreground hover:border-primary/50"
                      }`}
                    >
                      Female
                    </button>
                  </div>
                </div>

                {/* Age and Weight Inputs */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age (years)</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="e.g., 30"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="10"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder={unitSystem === "metric" ? "e.g., 70" : "e.g., 154"}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Activity Selection */}
                <div className="space-y-2">
                  <Label>Activity Type</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {activities.map((activity) => (
                      <button
                        key={activity.id}
                        onClick={() => setSelectedActivity(activity.id)}
                        className={`p-2 sm:p-3 rounded-lg border-2 text-center transition-all ${
                          selectedActivity === activity.id
                            ? "border-primary bg-primary/5 text-primary"
                            : "border-muted bg-background text-muted-foreground hover:border-primary/50"
                        }`}
                      >
                        <div className="text-lg sm:text-xl mb-1">{activity.icon}</div>
                        <div className="text-xs font-medium truncate">{activity.name}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Duration Input */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="e.g., 30"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Intensity Selection */}
                <div className="space-y-2">
                  <Label>Intensity Level</Label>
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      onClick={() => setIntensity("low")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        intensity === "low"
                          ? "border-green-500 bg-green-50 text-green-700"
                          : "border-muted bg-background text-muted-foreground hover:border-green-300"
                      }`}
                    >
                      Low
                    </button>
                    <button
                      onClick={() => setIntensity("moderate")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        intensity === "moderate"
                          ? "border-yellow-500 bg-yellow-50 text-yellow-700"
                          : "border-muted bg-background text-muted-foreground hover:border-yellow-300"
                      }`}
                    >
                      Moderate
                    </button>
                    <button
                      onClick={() => setIntensity("high")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        intensity === "high"
                          ? "border-red-500 bg-red-50 text-red-700"
                          : "border-muted bg-background text-muted-foreground hover:border-red-300"
                      }`}
                    >
                      High
                    </button>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCalories} className="w-full" size="lg">
                  Calculate Calories Burned
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Calories Burned</p>
                      <p className="text-5xl font-bold text-orange-600 mb-2">{result.totalCalories}</p>
                      <p className="text-lg font-semibold text-orange-600">calories</p>
                    </div>

                    {/* Additional Stats */}
                    <div className="grid grid-cols-3 gap-2 mt-4">
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Per Minute</p>
                        <p className="font-semibold text-foreground">{result.caloriesPerMinute}</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">MET Value</p>
                        <p className="font-semibold text-foreground">{result.met}</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Duration</p>
                        <p className="font-semibold text-foreground">{result.duration} min</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">MET Values by Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {activities.slice(0, 6).map((activity) => (
                      <div key={activity.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <span className="flex items-center gap-2">
                          <span>{activity.icon}</span>
                          <span className="font-medium">{activity.name}</span>
                        </span>
                        <span className="text-muted-foreground">
                          {activity.met.low}-{activity.met.high} MET
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calorie Burn Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs sm:text-sm">
                      Calories/min = (MET × 3.5 × Weight in kg) ÷ 200
                    </p>
                  </div>
                  <p>Total calories = Calories per minute × Duration in minutes</p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <p className="text-sm text-amber-800">
                    <strong>Note:</strong> Calories burned are estimates and may vary based on individual metabolism,
                    fitness level, and exercise conditions. Use these values as a general guide for your fitness
                    planning.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What are Calories */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Calories and Energy Expenditure</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A calorie is a unit of energy that measures the amount of energy your body uses to perform various
                  functions, from basic metabolic processes like breathing and circulation to physical activities like
                  exercise and daily movements. When we talk about "burning calories," we're referring to the energy
                  your body expends during these activities. Understanding how many calories you burn during exercise is
                  crucial for managing weight, planning nutrition, and optimizing your fitness routine.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Your body burns calories continuously throughout the day, even at rest. This baseline energy
                  expenditure is called your Basal Metabolic Rate (BMR). When you add physical activity, your total
                  daily energy expenditure increases significantly. The number of calories burned during exercise
                  depends on several factors including your body weight, the type of activity, the intensity at which
                  you perform it, and the duration of the exercise. Heavier individuals burn more calories performing
                  the same activity because their bodies require more energy to move the additional mass.
                </p>
              </CardContent>
            </Card>

            {/* Understanding MET */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ActivityIcon className="h-5 w-5 text-primary" />
                  <CardTitle>What is MET (Metabolic Equivalent of Task)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  MET, or Metabolic Equivalent of Task, is a standardized measure used to estimate the energy cost of
                  physical activities. One MET represents the energy you expend while sitting quietly at rest, which
                  equals approximately 3.5 milliliters of oxygen consumption per kilogram of body weight per minute.
                  Activities are assigned MET values based on how much more energy they require compared to this resting
                  state.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, walking at a moderate pace has a MET value of around 3.5, meaning it burns 3.5 times more
                  energy than sitting still. Running at 6 mph has a MET value of approximately 10, burning ten times
                  more calories than rest. The MET system was developed by researchers to provide a consistent way to
                  compare the intensity of different activities regardless of body size, making it an invaluable tool
                  for exercise prescription and calorie estimation.
                </p>
                <div className="mt-6 grid gap-3 sm:grid-cols-3">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Light Activities (1-3 MET)</h4>
                    <p className="text-green-700 text-sm">
                      Sitting, standing, light housework, slow walking. These activities require minimal effort above
                      resting.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Moderate Activities (3-6 MET)</h4>
                    <p className="text-yellow-700 text-sm">
                      Brisk walking, dancing, cycling at leisure pace. You can talk but not sing during these
                      activities.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Vigorous Activities (6+ MET)</h4>
                    <p className="text-red-700 text-sm">
                      Running, swimming laps, HIIT training. Breathing is rapid and conversation becomes difficult.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Factors Affecting Calorie Burn */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Factors That Affect Calorie Burn</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While this calculator provides accurate estimates based on established formulas, several individual
                  factors can influence the actual number of calories you burn during exercise. Understanding these
                  factors can help you better interpret your results and adjust your fitness expectations accordingly.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Body Weight and Composition</h4>
                    <p className="text-muted-foreground text-sm">
                      Heavier individuals burn more calories because more energy is required to move a larger mass.
                      Additionally, muscle tissue is more metabolically active than fat tissue, so people with higher
                      muscle mass tend to burn more calories even at rest and during exercise.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Fitness Level and Efficiency</h4>
                    <p className="text-muted-foreground text-sm">
                      As you become more fit, your body becomes more efficient at performing exercises. This means
                      experienced runners may burn slightly fewer calories than beginners running at the same pace
                      because their bodies have adapted to the movement patterns.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Age and Metabolism</h4>
                    <p className="text-muted-foreground text-sm">
                      Metabolic rate typically decreases with age due to loss of muscle mass and hormonal changes. Older
                      adults may burn slightly fewer calories than younger individuals performing the same activity at
                      the same intensity.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Environmental Conditions</h4>
                    <p className="text-muted-foreground text-sm">
                      Temperature extremes can affect calorie burn. Exercising in hot or cold conditions causes your
                      body to work harder to regulate temperature, potentially increasing energy expenditure. Altitude
                      also affects oxygen availability and energy requirements.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips for Maximizing Calorie Burn */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Timer className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Effective Calorie Burning</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Whether your goal is weight loss, improved fitness, or simply maintaining a healthy lifestyle,
                  understanding how to maximize your calorie burn during exercise can help you achieve better results in
                  less time. Here are evidence-based strategies to optimize your workout efficiency.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Incorporate Interval Training</h4>
                    <p className="text-blue-700 text-sm">
                      Alternating between high-intensity bursts and recovery periods burns more calories than
                      steady-state cardio and continues to burn calories after your workout through the afterburn effect
                      (EPOC).
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Build Lean Muscle Mass</h4>
                    <p className="text-green-700 text-sm">
                      Strength training builds muscle, which increases your resting metabolic rate. More muscle means
                      you burn more calories even when you're not exercising.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Increase Workout Duration</h4>
                    <p className="text-purple-700 text-sm">
                      While intensity matters, simply exercising for longer periods will increase total calorie burn.
                      Even low-intensity activities like walking add up over time.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Stay Consistent</h4>
                    <p className="text-orange-700 text-sm">
                      Regular exercise is more effective than occasional intense workouts. Aim for at least 150 minutes
                      of moderate activity or 75 minutes of vigorous activity per week.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
