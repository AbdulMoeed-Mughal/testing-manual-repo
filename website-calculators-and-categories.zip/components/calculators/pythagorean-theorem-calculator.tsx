"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Triangle, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type SolveFor = "a" | "b" | "c"

interface Result {
  value: number
  solvedFor: SolveFor
  steps: string[]
}

const units = [
  { value: "cm", label: "Centimeters (cm)" },
  { value: "m", label: "Meters (m)" },
  { value: "mm", label: "Millimeters (mm)" },
  { value: "in", label: "Inches (in)" },
  { value: "ft", label: "Feet (ft)" },
  { value: "yd", label: "Yards (yd)" },
]

export function PythagoreanTheoremCalculator() {
  const [sideA, setSideA] = useState("")
  const [sideB, setSideB] = useState("")
  const [hypotenuse, setHypotenuse] = useState("")
  const [unit, setUnit] = useState("cm")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const a = sideA ? Number.parseFloat(sideA) : null
    const b = sideB ? Number.parseFloat(sideB) : null
    const c = hypotenuse ? Number.parseFloat(hypotenuse) : null

    // Validate positive numbers
    if (
      (a !== null && (isNaN(a) || a <= 0)) ||
      (b !== null && (isNaN(b) || b <= 0)) ||
      (c !== null && (isNaN(c) || c <= 0))
    ) {
      setError("All values must be positive numbers")
      return
    }

    // Count provided values
    const providedCount = [a, b, c].filter((v) => v !== null).length

    if (providedCount !== 2) {
      setError("Please enter exactly two values to calculate the third")
      return
    }

    let calculatedValue: number
    let solvedFor: SolveFor
    let steps: string[] = []

    if (c === null && a !== null && b !== null) {
      // Solve for hypotenuse c
      solvedFor = "c"
      const aSquared = a * a
      const bSquared = b * b
      const cSquared = aSquared + bSquared
      calculatedValue = Math.sqrt(cSquared)

      steps = [
        `Using Pythagorean theorem: a² + b² = c²`,
        `Substitute values: ${a}² + ${b}² = c²`,
        `Calculate squares: ${aSquared.toFixed(4)} + ${bSquared.toFixed(4)} = c²`,
        `Add: ${cSquared.toFixed(4)} = c²`,
        `Take square root: c = √${cSquared.toFixed(4)}`,
        `Result: c = ${calculatedValue.toFixed(4)} ${unit}`,
      ]
    } else if (a === null && b !== null && c !== null) {
      // Solve for side a
      solvedFor = "a"

      if (c <= b) {
        setError("Hypotenuse (c) must be greater than side b")
        return
      }

      const cSquared = c * c
      const bSquared = b * b
      const aSquared = cSquared - bSquared
      calculatedValue = Math.sqrt(aSquared)

      steps = [
        `Using Pythagorean theorem: a² + b² = c²`,
        `Rearrange for a: a² = c² - b²`,
        `Substitute values: a² = ${c}² - ${b}²`,
        `Calculate squares: a² = ${cSquared.toFixed(4)} - ${bSquared.toFixed(4)}`,
        `Subtract: a² = ${aSquared.toFixed(4)}`,
        `Take square root: a = √${aSquared.toFixed(4)}`,
        `Result: a = ${calculatedValue.toFixed(4)} ${unit}`,
      ]
    } else if (b === null && a !== null && c !== null) {
      // Solve for side b
      solvedFor = "b"

      if (c <= a) {
        setError("Hypotenuse (c) must be greater than side a")
        return
      }

      const cSquared = c * c
      const aSquared = a * a
      const bSquared = cSquared - aSquared
      calculatedValue = Math.sqrt(bSquared)

      steps = [
        `Using Pythagorean theorem: a² + b² = c²`,
        `Rearrange for b: b² = c² - a²`,
        `Substitute values: b² = ${c}² - ${a}²`,
        `Calculate squares: b² = ${cSquared.toFixed(4)} - ${aSquared.toFixed(4)}`,
        `Subtract: b² = ${bSquared.toFixed(4)}`,
        `Take square root: b = √${bSquared.toFixed(4)}`,
        `Result: b = ${calculatedValue.toFixed(4)} ${unit}`,
      ]
    } else {
      setError("Invalid combination of inputs")
      return
    }

    setResult({
      value: Math.round(calculatedValue * 10000) / 10000,
      solvedFor,
      steps,
    })
  }

  const handleReset = () => {
    setSideA("")
    setSideB("")
    setHypotenuse("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const sideLabel = result.solvedFor === "c" ? "Hypotenuse" : `Side ${result.solvedFor}`
      await navigator.clipboard.writeText(`${sideLabel} = ${result.value} ${unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const sideLabel = result.solvedFor === "c" ? "Hypotenuse" : `Side ${result.solvedFor}`
      try {
        await navigator.share({
          title: "Pythagorean Theorem Result",
          text: `I calculated ${sideLabel} = ${result.value} ${unit} using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getSideLabel = (side: SolveFor) => {
    if (side === "c") return "Hypotenuse (c)"
    return `Side ${side}`
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Triangle className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Pythagorean Theorem Calculator</CardTitle>
                    <CardDescription>Calculate any side of a right triangle</CardDescription>
                  </div>
                </div>

                {/* Unit Selection */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit</span>
                  <Select value={unit} onValueChange={setUnit}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {units.map((u) => (
                        <SelectItem key={u.value} value={u.value}>
                          {u.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Triangle Diagram */}
                <div className="p-4 bg-muted rounded-lg flex justify-center">
                  <svg width="200" height="150" viewBox="0 0 200 150" className="text-blue-600">
                    {/* Triangle */}
                    <polygon points="20,130 180,130 20,20" fill="none" stroke="currentColor" strokeWidth="2" />
                    {/* Right angle marker */}
                    <polyline points="20,110 40,110 40,130" fill="none" stroke="currentColor" strokeWidth="1.5" />
                    {/* Labels */}
                    <text x="100" y="145" textAnchor="middle" className="text-sm font-medium fill-current">
                      a
                    </text>
                    <text x="8" y="75" textAnchor="middle" className="text-sm font-medium fill-current">
                      b
                    </text>
                    <text x="110" y="70" textAnchor="middle" className="text-sm font-medium fill-current">
                      c (hypotenuse)
                    </text>
                  </svg>
                </div>

                <p className="text-sm text-muted-foreground text-center">Enter any two values to calculate the third</p>

                {/* Side A Input */}
                <div className="space-y-2">
                  <Label htmlFor="sideA">Side a ({unit})</Label>
                  <Input
                    id="sideA"
                    type="number"
                    placeholder="Enter side a"
                    value={sideA}
                    onChange={(e) => setSideA(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Side B Input */}
                <div className="space-y-2">
                  <Label htmlFor="sideB">Side b ({unit})</Label>
                  <Input
                    id="sideB"
                    type="number"
                    placeholder="Enter side b"
                    value={sideB}
                    onChange={(e) => setSideB(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Hypotenuse Input */}
                <div className="space-y-2">
                  <Label htmlFor="hypotenuse">Hypotenuse c ({unit})</Label>
                  <Input
                    id="hypotenuse"
                    type="number"
                    placeholder="Enter hypotenuse c"
                    value={hypotenuse}
                    onChange={(e) => setHypotenuse(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{getSideLabel(result.solvedFor)}</p>
                      <p className="text-5xl font-bold text-blue-600 mb-2">
                        {result.value.toLocaleString(undefined, { maximumFractionDigits: 4 })}
                      </p>
                      <p className="text-lg font-medium text-blue-600">{unit}</p>
                    </div>

                    {/* Step-by-step breakdown */}
                    <div className="mt-4 p-3 bg-white rounded-lg border border-blue-100">
                      <p className="text-sm font-medium text-blue-800 mb-2">Step-by-step solution:</p>
                      <div className="space-y-1">
                        {result.steps.map((step, index) => (
                          <p key={index} className="text-xs text-blue-700 font-mono">
                            {index + 1}. {step}
                          </p>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pythagorean Theorem</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="font-semibold text-foreground text-lg">a² + b² = c²</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>a</strong> and <strong>b</strong> are the two legs (sides adjacent to the right angle)
                    </p>
                    <p>
                      <strong>c</strong> is the hypotenuse (the longest side, opposite the right angle)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700">Find Hypotenuse (c)</p>
                      <p className="text-sm text-blue-600 font-mono mt-1">c = √(a² + b²)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-700">Find Side a</p>
                      <p className="text-sm text-green-600 font-mono mt-1">a = √(c² − b²)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-700">Find Side b</p>
                      <p className="text-sm text-purple-600 font-mono mt-1">b = √(c² − a²)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    This calculator provides estimates only. Verify manually for critical measurements in construction,
                    engineering, or other professional applications.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Pythagorean Theorem?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Pythagorean theorem is one of the most fundamental principles in geometry, named after the ancient
                  Greek mathematician Pythagoras who lived around 570-495 BCE. Although evidence suggests that the
                  theorem was known to Babylonian and Indian mathematicians before Pythagoras, he is credited with
                  providing the first known proof. The theorem establishes a relationship between the three sides of a
                  right-angled triangle: the square of the hypotenuse (the side opposite the right angle) equals the sum
                  of the squares of the other two sides.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Mathematically expressed as a² + b² = c², this elegant equation has countless applications in
                  mathematics, physics, engineering, architecture, and everyday life. The theorem only applies to right
                  triangles—triangles that contain one 90-degree angle. The two sides that form the right angle are
                  called legs (a and b), while the longest side opposite the right angle is the hypotenuse (c).
                  Understanding this relationship allows us to calculate unknown distances when we know two of the three
                  sides.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use the Pythagorean Theorem</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Using the Pythagorean theorem is straightforward once you identify that you're working with a right
                  triangle. First, determine which side you need to find. If you know both legs (a and b), you can
                  calculate the hypotenuse by adding their squares and taking the square root: c = √(a² + b²). For
                  example, if a = 3 and b = 4, then c = √(9 + 16) = √25 = 5. This is the famous 3-4-5 right triangle,
                  one of the simplest Pythagorean triples.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  If you need to find one of the legs, rearrange the formula. To find side a when you know b and c, use
                  a = √(c² − b²). Similarly, to find side b, use b = √(c² − a²). Remember that the hypotenuse must
                  always be longer than either leg—if your calculation gives a negative number under the square root,
                  check your measurements because the hypotenuse cannot be shorter than a leg in a valid right triangle.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Triangle className="h-5 w-5 text-primary" />
                  <CardTitle>Pythagorean Triples</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pythagorean triples are sets of three positive integers (a, b, c) that satisfy the Pythagorean
                  theorem, meaning a² + b² = c² where all three values are whole numbers. The most common examples
                  include (3, 4, 5), (5, 12, 13), (8, 15, 17), and (7, 24, 25). These special number sets have been
                  studied for thousands of years and have practical applications in construction, surveying, and design
                  where whole-number measurements are desirable.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Any Pythagorean triple can be scaled to create larger triples. For instance, multiplying (3, 4, 5) by
                  2 gives (6, 8, 10), which is also a valid triple: 36 + 64 = 100. Primitive Pythagorean triples are
                  those where the three numbers share no common factor greater than 1. The 3-4-5 triple is primitive,
                  while 6-8-10 is not. These triples are invaluable for quickly checking if a corner is square or for
                  creating right angles in construction without complex calculations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Pythagorean theorem has countless practical applications. In construction, builders use it to
                  ensure walls are perpendicular and foundations are square. The 3-4-5 method is commonly used: measure
                  3 feet along one wall, 4 feet along another, and if the diagonal is exactly 5 feet, you have a perfect
                  right angle. Architects rely on the theorem for calculating roof pitches, staircase dimensions, and
                  structural support requirements.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Navigation and GPS systems use three-dimensional extensions of the theorem to calculate distances and
                  positions. Surveyors apply it to measure land and create accurate maps. In everyday life, you might
                  use it to determine if furniture will fit through a doorway diagonally, calculate the shortest path
                  across a field, or figure out the right size for a TV to fit a specific wall space. Video game
                  developers use it constantly for collision detection and character movement calculations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
