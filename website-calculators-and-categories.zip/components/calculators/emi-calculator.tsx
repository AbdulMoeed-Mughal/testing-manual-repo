"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, DollarSign, Info, AlertTriangle, CreditCard } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface EMIResult {
  emi: number
  totalPayment: number
  totalInterest: number
  principal: number
  withExtraPayment?: {
    newEMI: number
    interestSaved: number
    monthsSaved: number
    newTotalPayment: number
  }
}

export function EMICalculator() {
  const [loanAmount, setLoanAmount] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [tenureYears, setTenureYears] = useState("")
  const [tenureMonths, setTenureMonths] = useState("")
  const [extraPayment, setExtraPayment] = useState("")
  const [result, setResult] = useState<EMIResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAmortization, setShowAmortization] = useState(false)

  const calculateEMI = () => {
    setError("")
    setResult(null)

    const principal = Number.parseFloat(loanAmount)
    const rate = Number.parseFloat(interestRate)
    const years = Number.parseFloat(tenureYears) || 0
    const months = Number.parseFloat(tenureMonths) || 0
    const extra = Number.parseFloat(extraPayment) || 0

    // Validation
    if (isNaN(principal) || principal <= 0) {
      setError("Please enter a valid loan amount greater than 0")
      return
    }

    if (isNaN(rate) || rate < 0) {
      setError("Please enter a valid interest rate (0 or greater)")
      return
    }

    const totalMonths = years * 12 + months
    if (totalMonths <= 0) {
      setError("Please enter a valid loan tenure")
      return
    }

    // Calculate EMI
    if (rate === 0) {
      // Zero interest loan
      const emi = principal / totalMonths
      const totalPayment = principal
      const totalInterest = 0

      setResult({
        emi,
        totalPayment,
        totalInterest,
        principal,
      })
      return
    }

    const monthlyRate = rate / 12 / 100
    const emi =
      (principal * monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) / (Math.pow(1 + monthlyRate, totalMonths) - 1)

    const totalPayment = emi * totalMonths
    const totalInterest = totalPayment - principal

    // Calculate with extra payment
    if (extra > 0) {
      const effectiveEMI = emi + extra
      let balance = principal
      let monthsPaid = 0
      let totalPaid = 0

      while (balance > 0 && monthsPaid < totalMonths * 2) {
        const interestForMonth = balance * monthlyRate
        const principalForMonth = Math.min(effectiveEMI - interestForMonth, balance)
        balance -= principalForMonth
        totalPaid += interestForMonth + principalForMonth
        monthsPaid++
      }

      const interestSaved = totalPayment - totalPaid
      const monthsSaved = totalMonths - monthsPaid

      setResult({
        emi,
        totalPayment,
        totalInterest,
        principal,
        withExtraPayment: {
          newEMI: effectiveEMI,
          interestSaved,
          monthsSaved,
          newTotalPayment: totalPaid,
        },
      })
    } else {
      setResult({
        emi,
        totalPayment,
        totalInterest,
        principal,
      })
    }
  }

  const handleReset = () => {
    setLoanAmount("")
    setInterestRate("")
    setTenureYears("")
    setTenureMonths("")
    setExtraPayment("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowAmortization(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.withExtraPayment
        ? `EMI: $${result.emi.toFixed(2)}, With Extra Payment: $${result.withExtraPayment.newEMI.toFixed(2)}, Interest Saved: $${result.withExtraPayment.interestSaved.toFixed(2)}`
        : `EMI: $${result.emi.toFixed(2)}, Total Interest: $${result.totalInterest.toFixed(2)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My EMI Calculation",
          text: `I calculated my EMI using CalcHub! Monthly EMI: $${result.emi.toFixed(2)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getAmortizationSchedule = () => {
    if (!result) return []

    const rate = Number.parseFloat(interestRate)
    const years = Number.parseFloat(tenureYears) || 0
    const months = Number.parseFloat(tenureMonths) || 0
    const totalMonths = years * 12 + months
    const monthlyRate = rate / 12 / 100

    const schedule = []
    let balance = result.principal

    for (let i = 1; i <= Math.min(12, totalMonths); i++) {
      const interestPayment = balance * monthlyRate
      const principalPayment = result.emi - interestPayment
      balance -= principalPayment

      schedule.push({
        month: i,
        emi: result.emi,
        principal: principalPayment,
        interest: interestPayment,
        balance: Math.max(0, balance),
      })
    }

    return schedule
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <CreditCard className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">EMI Calculator</CardTitle>
                    <CardDescription>Calculate Equated Monthly Installments</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Loan Amount */}
                <div className="space-y-2">
                  <Label htmlFor="loanAmount">Loan Amount ($)</Label>
                  <Input
                    id="loanAmount"
                    type="number"
                    placeholder="Enter loan amount"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    min="0"
                    step="1000"
                  />
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Enter annual interest rate"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Loan Tenure */}
                <div className="space-y-2">
                  <Label>Loan Tenure</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder="Years"
                        value={tenureYears}
                        onChange={(e) => setTenureYears(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Months"
                        value={tenureMonths}
                        onChange={(e) => setTenureMonths(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                </div>

                {/* Extra Monthly Payment (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="extraPayment">Extra Monthly Payment (Optional)</Label>
                  <Input
                    id="extraPayment"
                    type="number"
                    placeholder="Enter extra payment amount"
                    value={extraPayment}
                    onChange={(e) => setExtraPayment(e.target.value)}
                    min="0"
                    step="10"
                  />
                  <p className="text-xs text-muted-foreground">Additional payment to reduce loan tenure</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateEMI} className="w-full" size="lg">
                  Calculate EMI
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Monthly EMI</p>
                        <p className="text-4xl font-bold text-green-600 mb-2">${result.emi.toFixed(2)}</p>
                      </div>

                      <div className="mt-4 pt-4 border-t border-green-200 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Principal Amount:</span>
                          <span className="font-semibold">${result.principal.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Total Interest:</span>
                          <span className="font-semibold text-orange-600">${result.totalInterest.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Total Payment:</span>
                          <span className="font-semibold">${result.totalPayment.toFixed(2)}</span>
                        </div>
                      </div>

                      {/* With Extra Payment */}
                      {result.withExtraPayment && (
                        <div className="mt-4 pt-4 border-t border-green-200">
                          <p className="text-sm font-semibold text-green-700 mb-2">With Extra Payment:</p>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">New Monthly Payment:</span>
                              <span className="font-semibold text-green-600">
                                ${result.withExtraPayment.newEMI.toFixed(2)}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Interest Saved:</span>
                              <span className="font-semibold text-emerald-600">
                                ${result.withExtraPayment.interestSaved.toFixed(2)}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Time Saved:</span>
                              <span className="font-semibold text-blue-600">
                                {result.withExtraPayment.monthsSaved} months
                              </span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>

                    {/* Amortization Schedule Toggle */}
                    <Button
                      variant="outline"
                      className="w-full bg-transparent"
                      onClick={() => setShowAmortization(!showAmortization)}
                    >
                      {showAmortization ? "Hide" : "Show"} Amortization Schedule (First 12 Months)
                    </Button>

                    {showAmortization && (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left p-2">Month</th>
                              <th className="text-right p-2">EMI</th>
                              <th className="text-right p-2">Principal</th>
                              <th className="text-right p-2">Interest</th>
                              <th className="text-right p-2">Balance</th>
                            </tr>
                          </thead>
                          <tbody>
                            {getAmortizationSchedule().map((row) => (
                              <tr key={row.month} className="border-b">
                                <td className="p-2">{row.month}</td>
                                <td className="text-right p-2">${row.emi.toFixed(2)}</td>
                                <td className="text-right p-2">${row.principal.toFixed(2)}</td>
                                <td className="text-right p-2">${row.interest.toFixed(2)}</td>
                                <td className="text-right p-2">${row.balance.toFixed(2)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">EMI Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-xs">
                    <p className="font-semibold text-foreground mb-2">EMI = P × r × (1 + r)^n / ((1 + r)^n - 1)</p>
                    <div className="text-left mt-3 space-y-1">
                      <p>P = Principal loan amount</p>
                      <p>r = Monthly interest rate</p>
                      <p>n = Total number of months</p>
                    </div>
                  </div>
                  <p>
                    The monthly interest rate (r) is calculated by dividing the annual interest rate by 12 and then by
                    100.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Loan Breakdown</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <span className="font-medium text-blue-700">Principal Amount</span>
                    <Info className="h-4 w-4 text-blue-600" />
                  </div>
                  <p className="text-xs px-3">The original loan amount you borrowed from the lender.</p>

                  <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <span className="font-medium text-orange-700">Interest Amount</span>
                    <Info className="h-4 w-4 text-orange-600" />
                  </div>
                  <p className="text-xs px-3">The total cost you pay to the lender for borrowing the money.</p>

                  <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                    <span className="font-medium text-green-700">Total Payment</span>
                    <Info className="h-4 w-4 text-green-600" />
                  </div>
                  <p className="text-xs px-3">Principal + Interest = Total amount you'll repay over the loan term.</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-600" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    This calculator provides estimates only. Actual EMI values may vary based on lender terms,
                    processing fees, and other charges. Please consult with your financial institution for exact
                    figures.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is EMI?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  EMI stands for Equated Monthly Installment, which is a fixed payment amount made by a borrower to a
                  lender at a specified date each calendar month. EMIs are used to pay off both interest and principal
                  each month, so that over a specified number of years, the loan is paid off in full. The concept of EMI
                  is widely used in India and other countries for home loans, car loans, personal loans, and various
                  other types of credit facilities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The beauty of EMI is that it allows borrowers to plan their finances better by knowing exactly how
                  much they need to pay every month. Unlike fluctuating payment structures, EMIs remain constant
                  throughout the loan tenure (unless you opt for a floating interest rate). This predictability makes it
                  easier to budget and manage monthly expenses. The EMI amount depends on three primary factors: the
                  principal loan amount, the interest rate charged by the lender, and the tenure of the loan.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>How is EMI Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The EMI calculation uses a mathematical formula that takes into account the loan principal, interest
                  rate, and tenure. The formula is: EMI = [P × r × (1 + r)^n] / [(1 + r)^n - 1], where P is the
                  principal loan amount, r is the monthly interest rate (annual rate divided by 12 months and 100), and
                  n is the total number of monthly payments. This formula ensures that each payment covers both the
                  interest and a portion of the principal.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In the early stages of loan repayment, a larger portion of your EMI goes toward paying the interest,
                  while a smaller portion reduces the principal. As time progresses and the principal amount decreases,
                  the interest component of your EMI reduces, and more of your payment goes toward the principal. This
                  is known as the amortization process. Understanding this breakdown helps you see how your debt is
                  being reduced over time and why making extra payments early in the loan term can save significant
                  interest costs.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting EMI</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence your EMI amount. The principal loan amount is the most obvious - the more
                  you borrow, the higher your EMI will be. The interest rate is equally crucial; even a small difference
                  in the rate can significantly impact your total payment over the loan tenure. This is why it's
                  essential to shop around and negotiate the best possible interest rate with lenders. Your credit score
                  often plays a vital role in determining the interest rate you're offered.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The loan tenure also has a substantial impact on your EMI. A longer tenure reduces your monthly EMI
                  amount but increases the total interest paid over the life of the loan. Conversely, a shorter tenure
                  means higher monthly payments but lower overall interest costs. The type of interest rate - whether
                  fixed or floating - also matters. Fixed rates remain constant throughout the loan term, while floating
                  rates can change based on market conditions. Additionally, factors like processing fees, prepayment
                  charges, and other administrative costs can affect your overall loan expense, though they don't
                  directly impact the EMI calculation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Benefits of Extra EMI Payments</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Making extra payments toward your loan principal can be one of the smartest financial decisions you
                  can make. Even small additional payments can lead to substantial savings in interest costs and reduce
                  your loan tenure significantly. When you make an extra payment, it goes directly toward reducing the
                  principal amount, which means less interest is calculated in subsequent months. This creates a
                  compounding effect where your savings accelerate over time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, adding just an extra $100 per month to your EMI on a $50,000 loan at 8% interest over 5
                  years could save you thousands in interest and help you pay off the loan months earlier. However,
                  before making extra payments, check with your lender about prepayment penalties or restrictions. Some
                  loans have clauses that charge fees for early repayment. If your loan allows penalty-free prepayments,
                  focus on making these extra payments in the early years of the loan when the interest component is
                  highest - this is when your extra payments have the maximum impact.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Managing Your EMI</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Proper EMI management is crucial for maintaining financial health. First and foremost, never commit to
                  an EMI that exceeds 40-50% of your monthly income. This leaves enough room for other expenses,
                  emergencies, and savings. Before taking a loan, create a realistic budget that accounts for all your
                  monthly expenses and ensures you can comfortably afford the EMI without strain. Remember that missing
                  EMI payments can severely damage your credit score and lead to penalties.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Consider setting up auto-debit for your EMI payments to ensure you never miss a due date. Keep an
                  emergency fund equivalent to at least 6-12 months of EMI payments - this safety net ensures you can
                  continue making payments even if you face unexpected income disruption. If you receive bonuses or
                  windfalls, consider using a portion to make prepayments on your loan. Finally, periodically review
                  your loan terms and explore refinancing options if interest rates have dropped significantly since you
                  took the loan. Refinancing to a lower rate can reduce your EMI or help you pay off the loan faster.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
