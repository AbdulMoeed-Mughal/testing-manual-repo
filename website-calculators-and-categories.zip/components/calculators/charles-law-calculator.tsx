"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Thermometer, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type SolveFor = "V2" | "T2"
type VolumeUnit = "m3" | "L" | "cm3"
type TempUnit = "C" | "K"

interface CharlesLawResult {
  solvedValue: number
  solvedValueUnit: string
  v1: number
  v2: number
  t1Kelvin: number
  t2Kelvin: number
  status: string
  statusColor: string
  statusBgColor: string
}

export function CharlesLawCalculator() {
  const [solveFor, setSolveFor] = useState<SolveFor>("V2")
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("L")
  const [tempUnit, setTempUnit] = useState<TempUnit>("C")
  const [v1, setV1] = useState("")
  const [t1, setT1] = useState("")
  const [v2, setV2] = useState("")
  const [t2, setT2] = useState("")
  const [result, setResult] = useState<CharlesLawResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const toKelvin = (temp: number, unit: TempUnit): number => {
    return unit === "C" ? temp + 273.15 : temp
  }

  const fromKelvin = (kelvin: number, unit: TempUnit): number => {
    return unit === "C" ? kelvin - 273.15 : kelvin
  }

  const getVolumeUnitLabel = (unit: VolumeUnit): string => {
    const labels: Record<VolumeUnit, string> = {
      m3: "m³",
      L: "L",
      cm3: "cm³",
    }
    return labels[unit]
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const v1Num = Number.parseFloat(v1)
    const t1Num = Number.parseFloat(t1)

    if (isNaN(v1Num) || v1Num <= 0) {
      setError("Please enter a valid initial volume greater than 0")
      return
    }

    const t1Kelvin = toKelvin(t1Num, tempUnit)
    if (isNaN(t1Kelvin) || t1Kelvin <= 0) {
      setError("Temperature must be above absolute zero (0 K or -273.15°C)")
      return
    }

    let calculatedV2: number
    let calculatedT2Kelvin: number
    let solvedValue: number
    let solvedValueUnit: string

    if (solveFor === "V2") {
      const t2Num = Number.parseFloat(t2)
      const t2Kelvin = toKelvin(t2Num, tempUnit)

      if (isNaN(t2Kelvin) || t2Kelvin <= 0) {
        setError("Final temperature must be above absolute zero (0 K or -273.15°C)")
        return
      }

      // V₁/T₁ = V₂/T₂ → V₂ = V₁ × T₂/T₁
      calculatedV2 = v1Num * (t2Kelvin / t1Kelvin)
      calculatedT2Kelvin = t2Kelvin
      solvedValue = calculatedV2
      solvedValueUnit = getVolumeUnitLabel(volumeUnit)
    } else {
      const v2Num = Number.parseFloat(v2)

      if (isNaN(v2Num) || v2Num <= 0) {
        setError("Please enter a valid final volume greater than 0")
        return
      }

      // V₁/T₁ = V₂/T₂ → T₂ = T₁ × V₂/V₁
      calculatedT2Kelvin = t1Kelvin * (v2Num / v1Num)
      calculatedV2 = v2Num
      solvedValue = fromKelvin(calculatedT2Kelvin, tempUnit)
      solvedValueUnit = tempUnit === "C" ? "°C" : "K"
    }

    // Determine expansion/contraction status
    let status: string
    let statusColor: string
    let statusBgColor: string

    const finalV2 = solveFor === "V2" ? calculatedV2 : Number.parseFloat(v2)
    if (finalV2 > v1Num) {
      status = "Gas Expands"
      statusColor = "text-orange-600"
      statusBgColor = "bg-orange-50 border-orange-200"
    } else if (finalV2 < v1Num) {
      status = "Gas Compresses"
      statusColor = "text-blue-600"
      statusBgColor = "bg-blue-50 border-blue-200"
    } else {
      status = "No Volume Change"
      statusColor = "text-green-600"
      statusBgColor = "bg-green-50 border-green-200"
    }

    setResult({
      solvedValue: Math.round(solvedValue * 1000000) / 1000000,
      solvedValueUnit,
      v1: v1Num,
      v2: solveFor === "V2" ? calculatedV2 : Number.parseFloat(v2),
      t1Kelvin,
      t2Kelvin: calculatedT2Kelvin,
      status,
      statusColor,
      statusBgColor,
    })
  }

  const handleReset = () => {
    setV1("")
    setT1("")
    setV2("")
    setT2("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        solveFor === "V2"
          ? `Charles's Law: V₂ = ${result.solvedValue.toFixed(4)} ${result.solvedValueUnit}`
          : `Charles's Law: T₂ = ${result.solvedValue.toFixed(2)} ${result.solvedValueUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Charles's Law Calculation",
          text: `Charles's Law: ${solveFor === "V2" ? `V₂ = ${result.solvedValue.toFixed(4)} ${result.solvedValueUnit}` : `T₂ = ${result.solvedValue.toFixed(2)} ${result.solvedValueUnit}`}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Thermometer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Charles's Law Calculator</CardTitle>
                    <CardDescription>V₁/T₁ = V₂/T₂ at constant pressure</CardDescription>
                  </div>
                </div>

                {/* Solve For Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Solve For</span>
                  <button
                    onClick={() => {
                      setSolveFor(solveFor === "V2" ? "T2" : "V2")
                      setResult(null)
                    }}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        solveFor === "T2" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        solveFor === "V2" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Final Volume
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        solveFor === "T2" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Final Temp
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Unit Selection */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Volume Unit</Label>
                    <select
                      value={volumeUnit}
                      onChange={(e) => setVolumeUnit(e.target.value as VolumeUnit)}
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                    >
                      <option value="L">Liters (L)</option>
                      <option value="m3">Cubic meters (m³)</option>
                      <option value="cm3">Cubic cm (cm³)</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>Temperature Unit</Label>
                    <select
                      value={tempUnit}
                      onChange={(e) => setTempUnit(e.target.value as TempUnit)}
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                    >
                      <option value="C">Celsius (°C)</option>
                      <option value="K">Kelvin (K)</option>
                    </select>
                  </div>
                </div>

                {/* Initial State */}
                <div className="p-3 bg-muted/50 rounded-lg space-y-3">
                  <h4 className="font-medium text-sm">Initial State</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label htmlFor="v1" className="text-xs">
                        Volume V₁ ({getVolumeUnitLabel(volumeUnit)})
                      </Label>
                      <Input
                        id="v1"
                        type="number"
                        placeholder="e.g., 2.0"
                        value={v1}
                        onChange={(e) => setV1(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="t1" className="text-xs">
                        Temperature T₁ ({tempUnit === "C" ? "°C" : "K"})
                      </Label>
                      <Input
                        id="t1"
                        type="number"
                        placeholder={tempUnit === "C" ? "e.g., 25" : "e.g., 298"}
                        value={t1}
                        onChange={(e) => setT1(e.target.value)}
                        step="any"
                      />
                    </div>
                  </div>
                </div>

                {/* Final State */}
                <div className="p-3 bg-muted/50 rounded-lg space-y-3">
                  <h4 className="font-medium text-sm">Final State</h4>
                  {solveFor === "V2" ? (
                    <div className="space-y-1">
                      <Label htmlFor="t2" className="text-xs">
                        Temperature T₂ ({tempUnit === "C" ? "°C" : "K"})
                      </Label>
                      <Input
                        id="t2"
                        type="number"
                        placeholder={tempUnit === "C" ? "e.g., 100" : "e.g., 373"}
                        value={t2}
                        onChange={(e) => setT2(e.target.value)}
                        step="any"
                      />
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <Label htmlFor="v2" className="text-xs">
                        Volume V₂ ({getVolumeUnitLabel(volumeUnit)})
                      </Label>
                      <Input
                        id="v2"
                        type="number"
                        placeholder="e.g., 3.0"
                        value={v2}
                        onChange={(e) => setV2(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {solveFor === "V2" ? "Final Volume" : "Final Temperature"}
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.statusBgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {solveFor === "V2" ? "Final Volume (V₂)" : "Final Temperature (T₂)"}
                      </p>
                      <p className={`text-4xl font-bold ${result.statusColor} mb-2`}>
                        {result.solvedValue.toFixed(solveFor === "V2" ? 4 : 2)} {result.solvedValueUnit}
                      </p>
                      <p className={`text-sm font-medium ${result.statusColor}`}>{result.status}</p>
                    </div>

                    {/* Show Steps Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Charles's Law:</strong> V₁/T₁ = V₂/T₂
                        </p>
                        <p>
                          <strong>Given:</strong>
                        </p>
                        <ul className="list-disc list-inside ml-2 space-y-1">
                          <li>
                            V₁ = {result.v1} {getVolumeUnitLabel(volumeUnit)}
                          </li>
                          <li>
                            T₁ = {result.t1Kelvin.toFixed(2)} K{" "}
                            {tempUnit === "C" && `(${Number.parseFloat(t1)}°C + 273.15)`}
                          </li>
                          {solveFor === "V2" ? (
                            <li>
                              T₂ = {result.t2Kelvin.toFixed(2)} K{" "}
                              {tempUnit === "C" && `(${Number.parseFloat(t2)}°C + 273.15)`}
                            </li>
                          ) : (
                            <li>
                              V₂ = {result.v2} {getVolumeUnitLabel(volumeUnit)}
                            </li>
                          )}
                        </ul>
                        <p>
                          <strong>Solution:</strong>
                        </p>
                        {solveFor === "V2" ? (
                          <p className="ml-2">
                            V₂ = V₁ × (T₂/T₁) = {result.v1} × ({result.t2Kelvin.toFixed(2)}/{result.t1Kelvin.toFixed(2)}
                            ) = {result.solvedValue.toFixed(4)} {getVolumeUnitLabel(volumeUnit)}
                          </p>
                        ) : (
                          <>
                            <p className="ml-2">
                              T₂ = T₁ × (V₂/V₁) = {result.t1Kelvin.toFixed(2)} × ({result.v2}/{result.v1}) ={" "}
                              {result.t2Kelvin.toFixed(2)} K
                            </p>
                            {tempUnit === "C" && (
                              <p className="ml-2">
                                T₂ = {result.t2Kelvin.toFixed(2)} K - 273.15 = {result.solvedValue.toFixed(2)}°C
                              </p>
                            )}
                          </>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Charles's Law Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="text-lg font-semibold">V₁ / T₁ = V₂ / T₂</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>Where:</strong>
                    </p>
                    <ul className="list-disc list-inside space-y-1 ml-2">
                      <li>V₁ = Initial volume</li>
                      <li>T₁ = Initial temperature (in Kelvin)</li>
                      <li>V₂ = Final volume</li>
                      <li>T₂ = Final temperature (in Kelvin)</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Points</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 rounded-full bg-orange-500 mt-1.5 flex-shrink-0" />
                    <p>Temperature must be in Kelvin for calculations (automatically converted)</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 rounded-full bg-orange-500 mt-1.5 flex-shrink-0" />
                    <p>Volume and temperature are directly proportional at constant pressure</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 rounded-full bg-orange-500 mt-1.5 flex-shrink-0" />
                    <p>When temperature increases, volume increases (and vice versa)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="p-2 bg-orange-50 border border-orange-200 rounded-lg">
                      <span className="text-sm font-medium text-orange-700">Hot Air Balloons</span>
                    </div>
                    <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg">
                      <span className="text-sm font-medium text-blue-700">Tire Pressure Changes</span>
                    </div>
                    <div className="p-2 bg-green-50 border border-green-200 rounded-lg">
                      <span className="text-sm font-medium text-green-700">Weather Balloons</span>
                    </div>
                    <div className="p-2 bg-purple-50 border border-purple-200 rounded-lg">
                      <span className="text-sm font-medium text-purple-700">Industrial Gas Storage</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Charles's Law?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Charles's Law, discovered by French scientist Jacques Charles in 1787, describes the relationship
                  between the volume and temperature of a gas at constant pressure. It states that when the pressure on
                  a sample of a dry gas is held constant, the volume of the gas is directly proportional to its absolute
                  temperature. This means that as temperature increases, the volume of the gas increases proportionally,
                  and as temperature decreases, the volume decreases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This law is fundamental to understanding gas behavior in thermodynamics and has numerous practical
                  applications. It explains why hot air balloons rise (heated air expands and becomes less dense), why
                  tires can become overinflated on hot days, and why weather balloons expand as they rise through the
                  atmosphere to colder regions. The law assumes ideal gas behavior, which is a good approximation for
                  most gases at normal temperatures and pressures.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When using Charles's Law, it's crucial to use absolute temperature (Kelvin) rather than Celsius or
                  Fahrenheit. This is because the proportional relationship only holds when measured from absolute zero.
                  The conversion from Celsius to Kelvin is straightforward: simply add 273.15 to the Celsius
                  temperature. Using Celsius directly would give incorrect results because the zero point of the Celsius
                  scale is arbitrary.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Charles's Law assumes ideal gas behavior and constant pressure conditions. Real gases may deviate from
                  this law at very high pressures or very low temperatures, where intermolecular forces become
                  significant. For most everyday applications and laboratory conditions, however, Charles's Law provides
                  an accurate description of gas behavior.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-yellow-800">
                <strong>Disclaimer:</strong> Charles's law calculations assume ideal gas behavior and constant pressure.
                Real gas deviations may occur at high pressures or low temperatures. Consult thermodynamics references
                for precise analysis in critical applications.
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
