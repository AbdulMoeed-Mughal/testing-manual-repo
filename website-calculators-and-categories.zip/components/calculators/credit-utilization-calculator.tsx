"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  CreditCard,
  Info,
  AlertTriangle,
  TrendingUp,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface CreditCardType {
  id: string
  name: string
  limit: string
  balance: string
}

interface UtilizationResult {
  totalLimit: number
  totalBalance: number
  utilizationPercent: number
  status: string
  statusColor: string
  statusBg: string
  recommendedPayment: number
  targetUtilization: number
}

export function CreditUtilizationCalculator() {
  const [cards, setCards] = useState<CreditCardType[]>([{ id: "1", name: "Card 1", limit: "", balance: "" }])
  const [targetUtilization, setTargetUtilization] = useState("30")
  const [result, setResult] = useState<UtilizationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)

  const addCard = () => {
    const newId = String(cards.length + 1)
    setCards([...cards, { id: newId, name: `Card ${newId}`, limit: "", balance: "" }])
  }

  const removeCard = (id: string) => {
    if (cards.length > 1) {
      setCards(cards.filter((card) => card.id !== id))
    }
  }

  const updateCard = (id: string, field: keyof CreditCardType, value: string) => {
    setCards(cards.map((card) => (card.id === id ? { ...card, [field]: value } : card)))
  }

  const calculateUtilization = () => {
    setError("")
    setResult(null)

    let totalLimit = 0
    let totalBalance = 0

    for (const card of cards) {
      const limit = Number.parseFloat(card.limit) || 0
      const balance = Number.parseFloat(card.balance) || 0

      if (balance > limit && limit > 0) {
        setError(`Balance cannot exceed limit for ${card.name}`)
        return
      }

      totalLimit += limit
      totalBalance += balance
    }

    if (totalLimit <= 0) {
      setError("Please enter at least one credit limit greater than 0")
      return
    }

    const utilizationPercent = (totalBalance / totalLimit) * 100
    const target = Number.parseFloat(targetUtilization) || 30

    let status: string
    let statusColor: string
    let statusBg: string

    if (utilizationPercent <= 10) {
      status = "Excellent"
      statusColor = "text-green-600"
      statusBg = "bg-green-50 border-green-200"
    } else if (utilizationPercent <= 30) {
      status = "Good"
      statusColor = "text-blue-600"
      statusBg = "bg-blue-50 border-blue-200"
    } else if (utilizationPercent <= 50) {
      status = "Fair"
      statusColor = "text-yellow-600"
      statusBg = "bg-yellow-50 border-yellow-200"
    } else if (utilizationPercent <= 75) {
      status = "Poor"
      statusColor = "text-orange-600"
      statusBg = "bg-orange-50 border-orange-200"
    } else {
      status = "Very Poor"
      statusColor = "text-red-600"
      statusBg = "bg-red-50 border-red-200"
    }

    const targetBalance = totalLimit * (target / 100)
    const recommendedPayment = Math.max(0, totalBalance - targetBalance)

    setResult({
      totalLimit,
      totalBalance,
      utilizationPercent: Math.round(utilizationPercent * 10) / 10,
      status,
      statusColor,
      statusBg,
      recommendedPayment: Math.round(recommendedPayment * 100) / 100,
      targetUtilization: target,
    })
  }

  const handleReset = () => {
    setCards([{ id: "1", name: "Card 1", limit: "", balance: "" }])
    setTargetUtilization("30")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Credit Utilization: ${result.utilizationPercent}% (${result.status})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Credit Utilization Result",
          text: `My credit utilization is ${result.utilizationPercent}% (${result.status})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <CreditCard className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Credit Utilization Calculator</CardTitle>
                    <CardDescription>Calculate your credit utilization ratio</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Credit Cards */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Credit Cards</Label>
                    <Button variant="outline" size="sm" onClick={addCard}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Card
                    </Button>
                  </div>

                  {cards.map((card, index) => (
                    <div key={card.id} className="p-3 rounded-lg border bg-muted/30 space-y-3">
                      <div className="flex items-center justify-between">
                        <Input
                          value={card.name}
                          onChange={(e) => updateCard(card.id, "name", e.target.value)}
                          className="w-32 h-8 text-sm"
                          placeholder="Card name"
                        />
                        {cards.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeCard(card.id)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs">Credit Limit ($)</Label>
                          <Input
                            type="number"
                            placeholder="10000"
                            value={card.limit}
                            onChange={(e) => updateCard(card.id, "limit", e.target.value)}
                            min="0"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Current Balance ($)</Label>
                          <Input
                            type="number"
                            placeholder="2500"
                            value={card.balance}
                            onChange={(e) => updateCard(card.id, "balance", e.target.value)}
                            min="0"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Target Settings</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="targetUtilization">Target Utilization (%)</Label>
                      <Input
                        id="targetUtilization"
                        type="number"
                        placeholder="30"
                        value={targetUtilization}
                        onChange={(e) => setTargetUtilization(e.target.value)}
                        min="0"
                        max="100"
                      />
                      <p className="text-xs text-muted-foreground">
                        Recommended: Keep utilization below 30% for optimal credit score
                      </p>
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateUtilization} className="w-full" size="lg">
                  Calculate Utilization
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.statusBg} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Credit Utilization</p>
                      <p className={`text-5xl font-bold ${result.statusColor}`}>{result.utilizationPercent}%</p>
                      <p className={`text-lg font-semibold ${result.statusColor}`}>{result.status}</p>
                    </div>

                    {/* Utilization Bar */}
                    <div className="mb-4">
                      <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            result.utilizationPercent <= 30
                              ? "bg-green-500"
                              : result.utilizationPercent <= 50
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                          style={{ width: `${Math.min(result.utilizationPercent, 100)}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>0%</span>
                        <span>30%</span>
                        <span>50%</span>
                        <span>100%</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Total Credit</p>
                        <p className="font-semibold">{formatCurrency(result.totalLimit)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Total Balance</p>
                        <p className="font-semibold">{formatCurrency(result.totalBalance)}</p>
                      </div>
                    </div>

                    {result.recommendedPayment > 0 && (
                      <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm text-blue-700">
                          Pay <strong>{formatCurrency(result.recommendedPayment)}</strong> to reach{" "}
                          {result.targetUtilization}% utilization
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Utilization Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-sm text-green-600">0 - 10%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-sm text-blue-600">10 - 30%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Fair</span>
                      <span className="text-sm text-yellow-600">30 - 50%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Poor</span>
                      <span className="text-sm text-orange-600">50 - 75%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very Poor</span>
                      <span className="text-sm text-red-600">{"> 75%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Utilization Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Utilization = (Balance ÷ Limit) × 100</p>
                  </div>
                  <p>
                    Credit utilization accounts for approximately <strong>30%</strong> of your credit score, making it
                    one of the most important factors.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Credit Utilization?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Credit utilization is the percentage of your available credit that you&apos;re currently using.
                  It&apos;s calculated by dividing your total credit card balances by your total credit limits. This
                  ratio is one of the most important factors in calculating your credit score, second only to payment
                  history.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Tips to Improve Credit Utilization</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground leading-relaxed space-y-2 list-disc list-inside">
                  <li>Pay down balances before statement closing dates</li>
                  <li>Request credit limit increases on existing cards</li>
                  <li>Keep old accounts open to maintain total available credit</li>
                  <li>Make multiple payments throughout the month</li>
                  <li>Set up balance alerts to monitor spending</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Credit utilization calculations are estimates and do not guarantee credit score outcomes. Your actual
                  credit score is determined by multiple factors including payment history, length of credit history,
                  and types of credit used. Consult a financial advisor or credit counselor for personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
