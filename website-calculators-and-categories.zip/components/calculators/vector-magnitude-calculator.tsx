"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, Compass, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface VectorResult {
  magnitude: number
  squaredSum: number
  components: { name: string; value: number; squared: number }[]
}

export function VectorMagnitudeCalculator() {
  const [is3D, setIs3D] = useState(false)
  const [x, setX] = useState("")
  const [y, setY] = useState("")
  const [z, setZ] = useState("")
  const [result, setResult] = useState<VectorResult | null>(null)
  const [showSteps, setShowSteps] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [stepsExpanded, setStepsExpanded] = useState(true)

  const calculate = () => {
    setError("")
    setResult(null)

    const xNum = Number.parseFloat(x)
    const yNum = Number.parseFloat(y)
    const zNum = is3D ? Number.parseFloat(z) : 0

    if (isNaN(xNum) || isNaN(yNum)) {
      setError("Please enter valid numeric values for x and y components")
      return
    }

    if (is3D && isNaN(zNum)) {
      setError("Please enter a valid numeric value for z component")
      return
    }

    if (xNum === 0 && yNum === 0 && (!is3D || zNum === 0)) {
      setError("At least one component must be non-zero")
      return
    }

    const components = [
      { name: "x", value: xNum, squared: xNum * xNum },
      { name: "y", value: yNum, squared: yNum * yNum },
    ]

    if (is3D) {
      components.push({ name: "z", value: zNum, squared: zNum * zNum })
    }

    const squaredSum = components.reduce((sum, c) => sum + c.squared, 0)
    const magnitude = Math.sqrt(squaredSum)

    setResult({ magnitude, squaredSum, components })
  }

  const handleReset = () => {
    setX("")
    setY("")
    setZ("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Vector: (${result.components.map((c) => c.value).join(", ")})\nMagnitude: |v| = ${result.magnitude.toFixed(6)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Vector Magnitude Result",
          text: `Vector: (${result.components.map((c) => c.value).join(", ")}), Magnitude: |v| = ${result.magnitude.toFixed(6)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number, decimals = 6) => {
    const rounded = Number.parseFloat(num.toFixed(decimals))
    return Number.isInteger(rounded) ? rounded.toString() : rounded.toFixed(decimals).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Compass className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Vector Magnitude Calculator</CardTitle>
                    <CardDescription>Calculate the magnitude (length) of a vector</CardDescription>
                  </div>
                </div>

                {/* Dimension Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Dimension</span>
                  <button
                    onClick={() => {
                      setIs3D(!is3D)
                      setZ("")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        is3D ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !is3D ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      2D
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        is3D ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      3D
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Vector Components */}
                <div className="space-y-2">
                  <Label>Vector Components</Label>
                  <div className={`grid gap-3 ${is3D ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Label htmlFor="x" className="text-xs text-muted-foreground">
                        x
                      </Label>
                      <Input
                        id="x"
                        type="number"
                        placeholder="x"
                        value={x}
                        onChange={(e) => setX(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="y" className="text-xs text-muted-foreground">
                        y
                      </Label>
                      <Input
                        id="y"
                        type="number"
                        placeholder="y"
                        value={y}
                        onChange={(e) => setY(e.target.value)}
                        step="any"
                      />
                    </div>
                    {is3D && (
                      <div>
                        <Label htmlFor="z" className="text-xs text-muted-foreground">
                          z
                        </Label>
                        <Input
                          id="z"
                          type="number"
                          placeholder="z"
                          value={z}
                          onChange={(e) => setZ(e.target.value)}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Options */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps" className="text-sm">
                    Show step-by-step solution
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Magnitude
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Vector</p>
                      <p className="text-lg font-mono font-medium text-blue-800 mb-3">
                        v = ({result.components.map((c) => formatNumber(c.value, 4)).join(", ")})
                      </p>
                      <p className="text-sm text-muted-foreground mb-1">Magnitude</p>
                      <p className="text-4xl font-bold text-blue-600 mb-1">|v| = {formatNumber(result.magnitude)}</p>
                      <p className="text-sm text-muted-foreground">≈ {result.magnitude.toFixed(10)}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-step Solution */}
                {result && showSteps && (
                  <Card className="border-dashed">
                    <CardHeader className="pb-2 cursor-pointer" onClick={() => setStepsExpanded(!stepsExpanded)}>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">Step-by-Step Solution</CardTitle>
                        {stepsExpanded ? (
                          <ChevronUp className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                    </CardHeader>
                    {stepsExpanded && (
                      <CardContent className="text-sm space-y-3">
                        <div className="p-3 bg-muted rounded-lg">
                          <p className="font-medium mb-1">Step 1: Identify the vector components</p>
                          <p className="font-mono text-muted-foreground">
                            v = ({result.components.map((c) => `${c.name} = ${formatNumber(c.value, 4)}`).join(", ")})
                          </p>
                        </div>

                        <div className="p-3 bg-muted rounded-lg">
                          <p className="font-medium mb-1">Step 2: Apply the magnitude formula</p>
                          <p className="font-mono text-muted-foreground">
                            |v| = √({result.components.map((c) => `${c.name}²`).join(" + ")})
                          </p>
                        </div>

                        <div className="p-3 bg-muted rounded-lg">
                          <p className="font-medium mb-1">Step 3: Square each component</p>
                          {result.components.map((c, i) => (
                            <p key={i} className="font-mono text-muted-foreground">
                              {c.name}² = ({formatNumber(c.value, 4)})² = {formatNumber(c.squared)}
                            </p>
                          ))}
                        </div>

                        <div className="p-3 bg-muted rounded-lg">
                          <p className="font-medium mb-1">Step 4: Sum the squared values</p>
                          <p className="font-mono text-muted-foreground">
                            {result.components.map((c) => formatNumber(c.squared)).join(" + ")} ={" "}
                            {formatNumber(result.squaredSum)}
                          </p>
                        </div>

                        <div className="p-3 bg-muted rounded-lg">
                          <p className="font-medium mb-1">Step 5: Take the square root</p>
                          <p className="font-mono text-muted-foreground">
                            |v| = √{formatNumber(result.squaredSum)} = {formatNumber(result.magnitude)}
                          </p>
                        </div>
                      </CardContent>
                    )}
                  </Card>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Magnitude Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-medium text-blue-800 mb-1">2D Vector</p>
                    <p className="font-mono text-sm text-blue-700">|v| = √(x² + y²)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-medium text-purple-800 mb-1">3D Vector</p>
                    <p className="font-mono text-sm text-purple-700">|v| = √(x² + y² + z²)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">v = (3, 4)</span>
                      <span className="text-muted-foreground">|v| = 5</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">v = (1, 1)</span>
                      <span className="text-muted-foreground">|v| ≈ 1.414</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">v = (1, 2, 2)</span>
                      <span className="text-muted-foreground">|v| = 3</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">v = (1, 1, 1)</span>
                      <span className="text-muted-foreground">|v| ≈ 1.732</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Applications</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Physics:</strong> Calculating velocity, force, and acceleration magnitudes
                  </p>
                  <p>
                    <strong>Computer Graphics:</strong> Normalizing vectors, calculating distances
                  </p>
                  <p>
                    <strong>Engineering:</strong> Structural analysis, signal processing
                  </p>
                  <p>
                    <strong>Navigation:</strong> Distance and displacement calculations
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Vector Magnitude?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The magnitude of a vector, also known as its length or norm, is a measure of how long the vector is.
                  It represents the distance from the origin to the point defined by the vector's components. In physics
                  and engineering, vector magnitude is essential for understanding quantities like speed (magnitude of
                  velocity), force strength, and displacement.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The magnitude is always a non-negative scalar value, regardless of the direction of the vector. It is
                  calculated using the Euclidean distance formula, which is derived from the Pythagorean theorem. For a
                  2D vector v = (x, y), the magnitude is √(x² + y²), and for a 3D vector v = (x, y, z), it extends to
                  √(x² + y² + z²).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Compass className="h-5 w-5 text-primary" />
                  <CardTitle>Properties of Vector Magnitude</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Non-negativity</h4>
                    <p className="text-sm text-muted-foreground">
                      |v| ≥ 0 for all vectors, and |v| = 0 only when v is the zero vector.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Scalar Multiplication</h4>
                    <p className="text-sm text-muted-foreground">|cv| = |c| × |v| for any scalar c and vector v.</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Triangle Inequality</h4>
                    <p className="text-sm text-muted-foreground">|u + v| ≤ |u| + |v| for any vectors u and v.</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Unit Vectors</h4>
                    <p className="text-sm text-muted-foreground">
                      A unit vector has magnitude 1 and is found by dividing v by |v|.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex gap-3">
              <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800">
                <p className="font-medium mb-1">Disclaimer</p>
                <p>
                  Vector magnitude calculations follow standard Euclidean formulas. Results depend on correct component
                  input and selected dimension. For complex applications, verify results with appropriate
                  domain-specific tools.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
