"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, TrendingUp, Info, AlertTriangle, Plus, Trash2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface Transaction {
  id: number
  shares: string
  price: string
}

interface StockResult {
  totalShares: number
  totalInvestment: number
  averagePrice: number
  currentValue: number | null
  profitLoss: number | null
  profitLossPercent: number | null
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
]

export function StockAverageCalculator() {
  const [currency, setCurrency] = useState("USD")
  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: 1, shares: "", price: "" },
    { id: 2, shares: "", price: "" },
  ])
  const [currentPrice, setCurrentPrice] = useState("")
  const [result, setResult] = useState<StockResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const currencySymbol = currencies.find((c) => c.code === currency)?.symbol || "$"

  const formatCurrency = (value: number): string => {
    if (currency === "INR") {
      if (value >= 10000000) return `${currencySymbol}${(value / 10000000).toFixed(2)} Cr`
      if (value >= 100000) return `${currencySymbol}${(value / 100000).toFixed(2)} L`
      return `${currencySymbol}${value.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`
    }
    if (value >= 1000000) return `${currencySymbol}${(value / 1000000).toFixed(2)}M`
    if (value >= 1000) return `${currencySymbol}${(value / 1000).toFixed(2)}K`
    return `${currencySymbol}${value.toLocaleString("en-US", { maximumFractionDigits: 2 })}`
  }

  const addTransaction = () => {
    const newId = Math.max(...transactions.map((t) => t.id)) + 1
    setTransactions([...transactions, { id: newId, shares: "", price: "" }])
  }

  const removeTransaction = (id: number) => {
    if (transactions.length > 1) {
      setTransactions(transactions.filter((t) => t.id !== id))
    }
  }

  const updateTransaction = (id: number, field: "shares" | "price", value: string) => {
    setTransactions(transactions.map((t) => (t.id === id ? { ...t, [field]: value } : t)))
  }

  const calculateAverage = () => {
    setError("")
    setResult(null)

    const validTransactions = transactions.filter((t) => {
      const shares = Number.parseFloat(t.shares)
      const price = Number.parseFloat(t.price)
      return !isNaN(shares) && shares > 0 && !isNaN(price) && price > 0
    })

    if (validTransactions.length === 0) {
      setError("Please enter at least one valid transaction with shares and price greater than 0")
      return
    }

    let totalShares = 0
    let totalInvestment = 0

    validTransactions.forEach((t) => {
      const shares = Number.parseFloat(t.shares)
      const price = Number.parseFloat(t.price)
      totalShares += shares
      totalInvestment += shares * price
    })

    if (totalShares === 0) {
      setError("Total shares cannot be zero")
      return
    }

    const averagePrice = totalInvestment / totalShares

    let currentValue: number | null = null
    let profitLoss: number | null = null
    let profitLossPercent: number | null = null

    const currentPriceNum = Number.parseFloat(currentPrice)
    if (!isNaN(currentPriceNum) && currentPriceNum >= 0) {
      currentValue = totalShares * currentPriceNum
      profitLoss = currentValue - totalInvestment
      profitLossPercent = (profitLoss / totalInvestment) * 100
    }

    setResult({
      totalShares,
      totalInvestment,
      averagePrice,
      currentValue,
      profitLoss,
      profitLossPercent,
    })
  }

  const handleReset = () => {
    setTransactions([
      { id: 1, shares: "", price: "" },
      { id: 2, shares: "", price: "" },
    ])
    setCurrentPrice("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = `Stock Average: ${currencySymbol}${result.averagePrice.toFixed(2)}\nTotal Shares: ${result.totalShares.toLocaleString()}\nTotal Investment: ${formatCurrency(result.totalInvestment)}`
      if (result.currentValue !== null && result.profitLoss !== null) {
        text += `\nCurrent Value: ${formatCurrency(result.currentValue)}\nProfit/Loss: ${result.profitLoss >= 0 ? "+" : ""}${formatCurrency(result.profitLoss)} (${result.profitLossPercent?.toFixed(2)}%)`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        let text = `I calculated my stock average using CalcHub!\nAverage Price: ${currencySymbol}${result.averagePrice.toFixed(2)}\nTotal Shares: ${result.totalShares.toLocaleString()}`
        if (result.profitLossPercent !== null) {
          text += `\nReturn: ${result.profitLossPercent >= 0 ? "+" : ""}${result.profitLossPercent.toFixed(2)}%`
        }
        await navigator.share({
          title: "My Stock Average",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Stock Average Calculator</CardTitle>
                    <CardDescription>Calculate average price per share</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {currencies.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.symbol})
                      </option>
                    ))}
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Transactions */}
                <div className="space-y-3">
                  <Label>Stock Purchases</Label>
                  {transactions.map((transaction, index) => (
                    <div key={transaction.id} className="flex gap-2 items-start">
                      <div className="flex-1">
                        <Input
                          type="number"
                          placeholder="Shares"
                          value={transaction.shares}
                          onChange={(e) => updateTransaction(transaction.id, "shares", e.target.value)}
                          min="0"
                          step="1"
                        />
                      </div>
                      <div className="flex-1">
                        <Input
                          type="number"
                          placeholder={`Price (${currencySymbol})`}
                          value={transaction.price}
                          onChange={(e) => updateTransaction(transaction.id, "price", e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeTransaction(transaction.id)}
                        disabled={transactions.length === 1}
                        className="text-muted-foreground hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" onClick={addTransaction} className="w-full bg-transparent">
                    <Plus className="h-4 w-4 mr-1" />
                    Add Transaction
                  </Button>
                </div>

                {/* Current Price (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="currentPrice">Current Price per Share (Optional)</Label>
                  <Input
                    id="currentPrice"
                    type="number"
                    placeholder={`Enter current price in ${currencySymbol}`}
                    value={currentPrice}
                    onChange={(e) => setCurrentPrice(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">Enter current market price to calculate profit/loss</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAverage} className="w-full" size="lg">
                  Calculate Average
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.profitLoss !== null
                        ? result.profitLoss >= 0
                          ? "bg-green-50 border-green-200"
                          : "bg-red-50 border-red-200"
                        : "bg-blue-50 border-blue-200"
                    }`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Average Price per Share</p>
                      <p className="text-4xl font-bold text-foreground mb-4">
                        {currencySymbol}
                        {result.averagePrice.toFixed(2)}
                      </p>

                      <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                        <div className="p-2 bg-white/50 rounded-lg">
                          <p className="text-muted-foreground">Total Shares</p>
                          <p className="font-semibold">{result.totalShares.toLocaleString()}</p>
                        </div>
                        <div className="p-2 bg-white/50 rounded-lg">
                          <p className="text-muted-foreground">Total Invested</p>
                          <p className="font-semibold">{formatCurrency(result.totalInvestment)}</p>
                        </div>
                      </div>

                      {result.currentValue !== null && result.profitLoss !== null && (
                        <div className="border-t border-current/10 pt-3 mt-3">
                          <div className="grid grid-cols-2 gap-3 text-sm">
                            <div className="p-2 bg-white/50 rounded-lg">
                              <p className="text-muted-foreground">Current Value</p>
                              <p className="font-semibold">{formatCurrency(result.currentValue)}</p>
                            </div>
                            <div className="p-2 bg-white/50 rounded-lg">
                              <p className="text-muted-foreground">Profit/Loss</p>
                              <p
                                className={`font-semibold ${result.profitLoss >= 0 ? "text-green-600" : "text-red-600"}`}
                              >
                                {result.profitLoss >= 0 ? "+" : ""}
                                {formatCurrency(result.profitLoss)} ({result.profitLossPercent?.toFixed(2)}%)
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground mb-1">Average Price Formula</p>
                    <p className="font-mono text-xs">Avg = Total Investment ÷ Total Shares</p>
                  </div>
                  <p>
                    The stock average calculator helps you find the weighted average price of your stock purchases
                    across multiple transactions.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Why Calculate Average?</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-green-600 text-xs font-bold">1</span>
                    </div>
                    <p className="text-muted-foreground">Track your true cost basis for tax purposes</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-green-600 text-xs font-bold">2</span>
                    </div>
                    <p className="text-muted-foreground">Evaluate your dollar-cost averaging strategy</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-green-600 text-xs font-bold">3</span>
                    </div>
                    <p className="text-muted-foreground">Make informed buy/sell decisions</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-green-600 text-xs font-bold">4</span>
                    </div>
                    <p className="text-muted-foreground">Compare performance across different stocks</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Actual stock values may vary. Always verify with your
                        brokerage for official cost basis information.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Stock Averaging?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Stock averaging, also known as dollar-cost averaging (DCA), is an investment strategy where you
                  purchase shares of a stock at different prices over time. Instead of investing a lump sum all at once,
                  you spread your investments across multiple purchases. The average price per share is calculated by
                  dividing your total investment by the total number of shares you own. This strategy helps reduce the
                  impact of market volatility on your overall investment, as you buy more shares when prices are low and
                  fewer shares when prices are high.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding your average cost basis is crucial for evaluating investment performance and making
                  informed decisions. Your average price serves as a benchmark—if the current market price is above your
                  average, you're in profit; if below, you're at a loss. This metric is particularly important for
                  long-term investors who accumulate positions over time and need to track their true cost basis for
                  both strategic planning and tax reporting purposes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Benefits of Dollar-Cost Averaging</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Dollar-cost averaging offers several advantages for investors. First, it removes the emotional aspect
                  of trying to "time the market"—a notoriously difficult task even for professional investors. By
                  investing regularly regardless of market conditions, you avoid the stress and potential regret of
                  making large investments at inopportune times. Second, DCA can lower your average cost per share over
                  time in volatile markets, as your fixed investment amount buys more shares when prices drop.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This strategy is particularly beneficial for new investors or those with regular income who can commit
                  to systematic investing. It builds discipline and creates a habit of consistent investing, which is
                  one of the most important factors in building long-term wealth. Additionally, DCA makes investing more
                  accessible by allowing you to start with smaller amounts rather than waiting to accumulate a large sum
                  for a single purchase.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Cost Basis</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Your cost basis is the original value of an asset for tax purposes, typically the purchase price
                  adjusted for stock splits, dividends, and return of capital distributions. When you sell shares, the
                  difference between your selling price and cost basis determines your capital gain or loss. For
                  investors who purchase shares at different times and prices, the average cost method is commonly used
                  to calculate cost basis, especially for mutual funds and stocks held in taxable accounts.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  It's important to maintain accurate records of all your stock purchases, including dates, quantities,
                  and prices. While brokerages track this information, verifying your cost basis ensures accurate tax
                  reporting and helps you make better investment decisions. Remember that different cost basis methods
                  (FIFO, LIFO, specific identification, average cost) can result in different tax implications when
                  selling shares, so consult with a tax professional for personalized advice.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations and Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While stock averaging is a popular strategy, it has limitations. In consistently rising markets, lump
                  sum investing may outperform DCA since you would benefit from having more capital invested earlier.
                  Additionally, frequent small purchases can incur higher transaction costs, though many modern
                  brokerages now offer commission-free trading. The strategy also requires discipline to continue
                  investing during market downturns, which can be emotionally challenging.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When using this calculator, remember that it calculates a simple weighted average and doesn't account
                  for factors like dividends reinvested, stock splits, or transaction fees. For official cost basis
                  calculations, especially for tax purposes, always refer to your brokerage statements. The calculator
                  is best used as a quick reference tool for understanding your approximate average cost and potential
                  profit or loss position.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
