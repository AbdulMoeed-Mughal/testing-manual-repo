"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Cake, Info, Calendar, PartyPopper } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface BirthdayResult {
  daysRemaining: number
  nextBirthday: string
  weeks: number
  months: number
  isToday: boolean
  age: number
}

export function DaysUntilBirthdayCalculator() {
  const [birthDate, setBirthDate] = useState("")
  const [includeToday, setIncludeToday] = useState(true)
  const [result, setResult] = useState<BirthdayResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBirthday = () => {
    setError("")
    setResult(null)

    if (!birthDate) {
      setError("Please select your date of birth")
      return
    }

    const birth = new Date(birthDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (birth >= today) {
      setError("Date of birth must be in the past")
      return
    }

    // Calculate next birthday
    const nextBirthday = new Date(birth)
    nextBirthday.setFullYear(today.getFullYear())

    // If birthday has passed this year, set to next year
    if (nextBirthday < today) {
      nextBirthday.setFullYear(today.getFullYear() + 1)
    }

    // Handle leap year birthdays (Feb 29)
    if (birth.getMonth() === 1 && birth.getDate() === 29) {
      // If next year is not a leap year, celebrate on Feb 28
      const nextYear = nextBirthday.getFullYear()
      const isLeapYear = (nextYear % 4 === 0 && nextYear % 100 !== 0) || nextYear % 400 === 0
      if (!isLeapYear) {
        nextBirthday.setMonth(1, 28)
      }
    }

    // Calculate days remaining
    let daysRemaining = Math.floor((nextBirthday.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    
    if (!includeToday) {
      daysRemaining += 1
    }

    const isToday = daysRemaining === 0

    // Calculate age at next birthday
    const age = nextBirthday.getFullYear() - birth.getFullYear()

    // Calculate breakdown
    const weeks = Math.floor(daysRemaining / 7)
    const months = Math.floor(daysRemaining / 30)

    setResult({
      daysRemaining,
      nextBirthday: nextBirthday.toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      weeks,
      months,
      isToday,
      age,
    })
  }

  const handleReset = () => {
    setBirthDate("")
    setIncludeToday(true)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.isToday
        ? `Today is my birthday! 🎉`
        : `${result.daysRemaining} days until my birthday on ${result.nextBirthday}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = result.isToday
          ? "Today is my birthday! 🎉"
          : `I have ${result.daysRemaining} days until my birthday on ${result.nextBirthday}!`
        await navigator.share({
          title: "Days Until Birthday",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Cake className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Days Until Birthday</CardTitle>
                    <CardDescription>Calculate days remaining until your birthday</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Birth Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="birthDate">Date of Birth</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                {/* Include Today Checkbox */}
                <div className="flex items-center space-x-2">
                  <Checkbox id="includeToday" checked={includeToday} onCheckedChange={(checked) => setIncludeToday(checked === true)} />
                  <Label htmlFor="includeToday" className="text-sm font-normal cursor-pointer">
                    Include current day in calculation
                  </Label>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBirthday} className="w-full" size="lg">
                  Calculate Days
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.isToday ? "bg-gradient-to-br from-cyan-50 to-blue-50 border-cyan-200" : "bg-cyan-50 border-cyan-200"} transition-all duration-300`}>
                    <div className="text-center">
                      {result.isToday ? (
                        <>
                          <p className="text-3xl font-bold text-cyan-600 mb-2">🎉 Happy Birthday! 🎉</p>
                          <p className="text-lg font-semibold text-cyan-600 mb-1">You are {result.age} years old today!</p>
                          <p className="text-sm text-muted-foreground">Wishing you a wonderful celebration!</p>
                        </>
                      ) : (
                        <>
                          <p className="text-sm text-muted-foreground mb-1">Days Until Birthday</p>
                          <p className="text-5xl font-bold text-cyan-600 mb-2">{result.daysRemaining}</p>
                          <p className="text-sm text-muted-foreground mb-3">
                            Approximately {result.weeks} weeks or {result.months} months
                          </p>
                          <div className="p-3 bg-white rounded-lg mb-2">
                            <p className="text-sm text-muted-foreground">Next Birthday</p>
                            <p className="text-base font-semibold text-cyan-600">{result.nextBirthday}</p>
                          </div>
                          <p className="text-sm text-cyan-600 font-medium">You'll be {result.age} years old</p>
                        </>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Birthday Facts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Most Common Birthday</p>
                      <p className="text-xs text-muted-foreground">September 9th in the US</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Least Common Birthday</p>
                      <p className="text-xs text-muted-foreground">February 29th (Leap Day)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Birthday Paradox</p>
                      <p className="text-xs text-muted-foreground">In a group of 23 people, 50% chance two share a birthday</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    The calculator determines your next birthday and counts the days from today's date.
                  </p>
                  <div className="p-4 bg-muted rounded-lg font-mono text-xs">
                    <p className="font-semibold text-foreground">Next Birthday = Birth Month & Day in Current/Next Year</p>
                    <p className="mt-2 font-semibold text-foreground">Days = Next Birthday − Current Date</p>
                  </div>
                  <p className="text-xs">
                    For leap year birthdays (Feb 29), the calculator adjusts to Feb 28 in non-leap years.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Birthday Planning */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Why Track Your Birthday Countdown?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Knowing how many days remain until your birthday serves multiple purposes beyond simple curiosity. For event planners and party organizers, having an exact day count helps with scheduling venues, sending invitations, and coordinating with guests. Many people begin planning birthday celebrations weeks or even months in advance, especially for milestone birthdays.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Birthday countdowns can also be meaningful for personal goal-setting. Some people use their birthday as a natural checkpoint to reflect on achievements and set new goals for the coming year. Children particularly enjoy counting down to their birthdays, building anticipation and excitement for their special day.
                </p>
              </CardContent>
            </Card>

            {/* Leap Year Birthdays */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Special Case: Leap Year Birthdays</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  People born on February 29th have unique birthday situations. Since leap years only occur every four years, "leaplings" technically only have a birthday every four years. However, in non-leap years, they typically celebrate on February 28th or March 1st. This calculator recognizes leap year birthdays and adjusts accordingly, showing February 28th for non-leap years.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Being born on a leap day is quite rare, occurring in only about 1 in 1,461 births. Despite the rarity, there are approximately 5 million people worldwide who were born on February 29th. Many leaplings embrace their unique birthday status and celebrate in creative ways, including large celebrations every four years when their actual birth date occurs.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PartyPopper className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What if I was born on February 29th?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The calculator automatically handles leap year birthdays. In non-leap years, it will show February 28th as your next birthday, though you can choose to celebrate on either February 28th or March 1st.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Why use a birthday countdown?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Birthday countdowns help with party planning, build excitement, set personal goals, and provide a fun way to track time. They're especially popular for milestone birthdays and children's celebrations.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Can I calculate multiple birthdays?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      While this calculator focuses on one birthday at a time, you can easily calculate different birthdays by changing the date of birth and recalculating. This is useful for tracking family members' birthdays.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground">
                  <strong>Disclaimer:</strong> Birthday countdown is based on the entered date and current date. Results may vary due to time zones and calendar adjustments. This calculator is for informational and planning purposes only.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
