"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Dumbbell,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Target,
  Flame,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityLevel = "sedentary" | "light" | "moderate" | "very" | "extra"

interface MuscleGainResult {
  dailyCalories: number
  proteinGrams: number
  proteinRange: { min: number; max: number }
  totalWeeks: number
  weeklyGain: number
  surplusCalories: number
  tdee: number
  bmr: number
  carbsGrams: number
  fatGrams: number
  status: "safe" | "moderate" | "aggressive"
  statusColor: string
  statusBgColor: string
}

const activityMultipliers: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  very: 1.725,
  extra: 1.9,
}

const activityLabels: Record<ActivityLevel, string> = {
  sedentary: "Sedentary (little or no exercise)",
  light: "Lightly Active (1-3 days/week)",
  moderate: "Moderately Active (3-5 days/week)",
  very: "Very Active (6-7 days/week)",
  extra: "Extra Active (athlete/physical job)",
}

export function MuscleGainCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [targetGain, setTargetGain] = useState("")
  const [age, setAge] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [gender, setGender] = useState<Gender>("male")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")
  const [bodyFat, setBodyFat] = useState("")
  const [result, setResult] = useState<MuscleGainResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateMuscleGain = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const targetGainNum = Number.parseFloat(targetGain)
    const ageNum = Number.parseFloat(age)

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(targetGainNum) || targetGainNum <= 0) {
      setError("Please enter a valid target muscle gain greater than 0")
      return
    }

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    let heightInCm: number
    if (unitSystem === "metric") {
      heightInCm = Number.parseFloat(heightCm)
      if (isNaN(heightInCm) || heightInCm <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = feet * 30.48 + inches * 2.54
    }

    // Convert to metric if needed
    const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum
    const targetGainKg = unitSystem === "imperial" ? targetGainNum * 0.453592 : targetGainNum

    // Calculate BMR using Mifflin-St Jeor
    let bmr: number
    if (gender === "male") {
      bmr = 10 * weightKg + 6.25 * heightInCm - 5 * ageNum + 5
    } else {
      bmr = 10 * weightKg + 6.25 * heightInCm - 5 * ageNum - 161
    }

    // Calculate TDEE
    const tdee = bmr * activityMultipliers[activityLevel]

    // Calculate expected weekly gain (0.25-0.5 kg/week for muscle)
    // More conservative for females and beginners
    let weeklyGainKg = gender === "male" ? 0.35 : 0.25 // Average expected gain

    // Adjust based on body fat if provided
    const bodyFatNum = Number.parseFloat(bodyFat)
    if (!isNaN(bodyFatNum) && bodyFatNum > 0) {
      // Higher body fat = slower muscle gain potential
      if (bodyFatNum > 25) weeklyGainKg *= 0.8
      else if (bodyFatNum < 15) weeklyGainKg *= 1.1
    }

    // Calculate timeframe
    const totalWeeks = Math.ceil(targetGainKg / weeklyGainKg)

    // Calculate caloric surplus (250-500 kcal/day for lean gains)
    // More conservative surplus for better lean mass ratio
    const surplusCalories = gender === "male" ? 350 : 300
    const dailyCalories = Math.round(tdee + surplusCalories)

    // Calculate protein requirements (1.6-2.2 g/kg for muscle building)
    const proteinMin = Math.round(weightKg * 1.6)
    const proteinMax = Math.round(weightKg * 2.2)
    const proteinGrams = Math.round(weightKg * 1.8) // Middle ground

    // Calculate macros (protein calories = 4 kcal/g)
    const proteinCalories = proteinGrams * 4
    const fatCalories = dailyCalories * 0.25 // 25% from fat
    const fatGrams = Math.round(fatCalories / 9)
    const carbCalories = dailyCalories - proteinCalories - fatCalories
    const carbsGrams = Math.round(carbCalories / 4)

    // Determine status based on weekly gain rate
    let status: "safe" | "moderate" | "aggressive"
    let statusColor: string
    let statusBgColor: string

    const weeklyGainDisplay = unitSystem === "imperial" ? weeklyGainKg * 2.205 : weeklyGainKg

    if (weeklyGainKg <= 0.25) {
      status = "safe"
      statusColor = "text-green-600"
      statusBgColor = "bg-green-50 border-green-200"
    } else if (weeklyGainKg <= 0.4) {
      status = "moderate"
      statusColor = "text-yellow-600"
      statusBgColor = "bg-yellow-50 border-yellow-200"
    } else {
      status = "aggressive"
      statusColor = "text-orange-600"
      statusBgColor = "bg-orange-50 border-orange-200"
    }

    setResult({
      dailyCalories,
      proteinGrams,
      proteinRange: { min: proteinMin, max: proteinMax },
      totalWeeks,
      weeklyGain: unitSystem === "imperial" ? weeklyGainKg * 2.205 : weeklyGainKg,
      surplusCalories,
      tdee: Math.round(tdee),
      bmr: Math.round(bmr),
      carbsGrams,
      fatGrams,
      status,
      statusColor,
      statusBgColor,
    })
  }

  const handleReset = () => {
    setWeight("")
    setTargetGain("")
    setAge("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setBodyFat("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Muscle Gain Plan:
Daily Calories: ${result.dailyCalories} kcal
Daily Protein: ${result.proteinGrams}g
Estimated Timeframe: ${result.totalWeeks} weeks
Weekly Gain: ${result.weeklyGain.toFixed(2)} ${unitSystem === "metric" ? "kg" : "lb"}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Muscle Gain Plan",
          text: `I'm planning to build muscle with ${result.dailyCalories} kcal/day and ${result.proteinGrams}g protein. Estimated timeframe: ${result.totalWeeks} weeks!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setTargetGain("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Dumbbell className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Muscle Gain Calculator</CardTitle>
                    <CardDescription>Plan your muscle building journey</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Current Weight */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Current Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Target Muscle Gain */}
                <div className="space-y-2">
                  <Label htmlFor="targetGain">Target Muscle Gain ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="targetGain"
                    type="number"
                    placeholder={`Enter target gain in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={targetGain}
                    onChange={(e) => setTargetGain(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Age */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Height */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="Feet"
                        value={heightFeet}
                        onChange={(e) => setHeightFeet(e.target.value)}
                        min="0"
                      />
                      <Input
                        type="number"
                        placeholder="Inches"
                        value={heightInches}
                        onChange={(e) => setHeightInches(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                )}

                {/* Gender */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <Select value={activityLevel} onValueChange={(v) => setActivityLevel(v as ActivityLevel)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(activityLabels).map(([key, label]) => (
                        <SelectItem key={key} value={key}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Optional Body Fat */}
                <div className="space-y-2">
                  <Label htmlFor="bodyFat">Body Fat % (optional)</Label>
                  <Input
                    id="bodyFat"
                    type="number"
                    placeholder="Enter body fat percentage"
                    value={bodyFat}
                    onChange={(e) => setBodyFat(e.target.value)}
                    min="0"
                    max="60"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMuscleGain} className="w-full" size="lg">
                  Calculate Muscle Gain Plan
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.statusBgColor} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Daily Calorie Target</p>
                      <p className={`text-4xl font-bold ${result.statusColor}`}>
                        {result.dailyCalories.toLocaleString()}
                      </p>
                      <p className="text-sm text-muted-foreground">kcal/day</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="text-center p-3 bg-white/50 rounded-lg">
                        <p className="text-2xl font-bold text-foreground">{result.proteinGrams}g</p>
                        <p className="text-xs text-muted-foreground">Daily Protein</p>
                      </div>
                      <div className="text-center p-3 bg-white/50 rounded-lg">
                        <p className="text-2xl font-bold text-foreground">{result.totalWeeks}</p>
                        <p className="text-xs text-muted-foreground">Weeks to Goal</p>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors py-2"
                    >
                      {showDetails ? (
                        <>
                          Hide Details <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Details <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">BMR:</span>
                          <span className="font-medium">{result.bmr} kcal</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">TDEE:</span>
                          <span className="font-medium">{result.tdee} kcal</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Caloric Surplus:</span>
                          <span className="font-medium">+{result.surplusCalories} kcal</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Weekly Gain:</span>
                          <span className="font-medium">
                            {result.weeklyGain.toFixed(2)} {unitSystem === "metric" ? "kg" : "lb"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Protein Range:</span>
                          <span className="font-medium">
                            {result.proteinRange.min}-{result.proteinRange.max}g
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Daily Carbs:</span>
                          <span className="font-medium">{result.carbsGrams}g</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Daily Fat:</span>
                          <span className="font-medium">{result.fatGrams}g</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Protein Requirements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Maintenance</span>
                      <span className="text-sm text-blue-600">0.8g/kg body weight</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Muscle Building</span>
                      <span className="text-sm text-green-600">1.6-2.2g/kg body weight</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Athletes</span>
                      <span className="text-sm text-yellow-600">1.4-2.0g/kg body weight</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Safe Weekly Gain Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Beginners</span>
                      <span className="text-sm text-green-600">0.5-1 kg/month</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Intermediate</span>
                      <span className="text-sm text-yellow-600">0.25-0.5 kg/month</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Advanced</span>
                      <span className="text-sm text-orange-600">0.1-0.25 kg/month</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      Daily Calories = TDEE + Surplus (250-500 kcal)
                    </p>
                  </div>
                  <p>
                    TDEE is calculated using the <strong>Mifflin-St Jeor</strong> equation multiplied by your activity
                    factor.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Muscle Gain?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Muscle gain, also known as muscle hypertrophy, refers to the process of increasing the size and mass
                  of your skeletal muscles through a combination of resistance training and proper nutrition. Building
                  muscle requires your body to be in a caloric surplus, meaning you consume more calories than you burn,
                  while also providing adequate protein to support muscle protein synthesis.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The rate at which you can gain muscle depends on several factors including your training experience,
                  genetics, age, gender, and consistency with both training and nutrition. Beginners typically
                  experience faster initial gains, while advanced lifters see slower progress due to their proximity to
                  their genetic potential.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Keys to Successful Muscle Building</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Progressive Overload</h4>
                    <p className="text-sm text-muted-foreground">
                      Gradually increase the weight, reps, or sets over time to continuously challenge your muscles and
                      stimulate growth.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Adequate Protein</h4>
                    <p className="text-sm text-muted-foreground">
                      Consume 1.6-2.2g of protein per kg of body weight daily, spread across 4-5 meals for optimal
                      muscle protein synthesis.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Caloric Surplus</h4>
                    <p className="text-sm text-muted-foreground">
                      Maintain a moderate surplus of 250-500 calories above your TDEE to support muscle growth while
                      minimizing fat gain.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Rest & Recovery</h4>
                    <p className="text-sm text-muted-foreground">
                      Get 7-9 hours of quality sleep and allow 48-72 hours of recovery between training the same muscle
                      groups.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Nutrition Tips for Muscle Gain</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="space-y-2 text-muted-foreground">
                  <li>
                    <strong>Prioritize protein timing:</strong> Consume protein within 2 hours post-workout and spread
                    intake evenly throughout the day.
                  </li>
                  <li>
                    <strong>Don't fear carbs:</strong> Carbohydrates fuel intense workouts and help replenish muscle
                    glycogen stores.
                  </li>
                  <li>
                    <strong>Include healthy fats:</strong> Essential for hormone production, including testosterone
                    which supports muscle growth.
                  </li>
                  <li>
                    <strong>Stay hydrated:</strong> Adequate water intake supports nutrient transport and muscle
                    function.
                  </li>
                  <li>
                    <strong>Consider creatine:</strong> One of the most researched and effective supplements for
                    increasing strength and muscle mass.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700 leading-relaxed">
                  Muscle gain calculations are estimates and may vary depending on individual metabolism, genetics,
                  training program, and adherence. Actual results will differ based on your specific circumstances,
                  including training intensity, sleep quality, stress levels, and overall lifestyle factors. Consult a
                  healthcare professional or certified fitness expert before starting any new diet or exercise program,
                  especially if you have underlying health conditions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
