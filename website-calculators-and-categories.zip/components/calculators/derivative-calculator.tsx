"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

interface DerivativeResult {
  original: string
  derivative: string
  variable: string
  order: number
  steps: string[]
  simplified: string
}

type RuleType = "power" | "sum" | "product" | "quotient" | "chain" | "trig" | "exp" | "log"

export function DerivativeCalculator() {
  const [functionInput, setFunctionInput] = useState("")
  const [variable, setVariable] = useState("x")
  const [order, setOrder] = useState("1")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<DerivativeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showStepsPanel, setShowStepsPanel] = useState(false)

  // Parse and differentiate a function
  const differentiate = (expr: string, varName: string, steps: string[]): string => {
    expr = expr.trim()

    // Handle empty or invalid input
    if (!expr) return "0"

    // Remove outer parentheses if they wrap the entire expression
    while (expr.startsWith("(") && expr.endsWith(")")) {
      let depth = 0
      let isWrapped = true
      for (let i = 0; i < expr.length - 1; i++) {
        if (expr[i] === "(") depth++
        else if (expr[i] === ")") depth--
        if (depth === 0 && i < expr.length - 1) {
          isWrapped = false
          break
        }
      }
      if (isWrapped) expr = expr.slice(1, -1).trim()
      else break
    }

    // Handle constants (numbers without the variable)
    if (!expr.includes(varName) && !isNaN(Number(expr))) {
      steps.push(`d/d${varName}(${expr}) = 0 (constant rule)`)
      return "0"
    }

    // Handle just the variable
    if (expr === varName) {
      steps.push(`d/d${varName}(${varName}) = 1`)
      return "1"
    }

    // Handle addition/subtraction (lowest precedence, parse from right)
    let depth = 0
    for (let i = expr.length - 1; i >= 0; i--) {
      const char = expr[i]
      if (char === ")") depth++
      else if (char === "(") depth--
      else if (depth === 0 && (char === "+" || (char === "-" && i > 0))) {
        const left = expr.slice(0, i).trim()
        const right = expr.slice(i + 1).trim()
        if (left && right) {
          steps.push(`d/d${varName}(${expr}) using sum/difference rule`)
          const leftDeriv = differentiate(left, varName, steps)
          const rightDeriv = differentiate(right, varName, steps)
          const op = char === "+" ? "+" : "-"
          return simplifyExpression(`${leftDeriv} ${op} ${rightDeriv}`)
        }
      }
    }

    // Handle multiplication (look for *)
    depth = 0
    for (let i = expr.length - 1; i >= 0; i--) {
      const char = expr[i]
      if (char === ")") depth++
      else if (char === "(") depth--
      else if (depth === 0 && char === "*") {
        const left = expr.slice(0, i).trim()
        const right = expr.slice(i + 1).trim()
        if (left && right) {
          steps.push(`d/d${varName}(${expr}) using product rule: d(uv) = u'v + uv'`)
          const leftDeriv = differentiate(left, varName, [])
          const rightDeriv = differentiate(right, varName, [])
          steps.push(`u = ${left}, u' = ${leftDeriv}`)
          steps.push(`v = ${right}, v' = ${rightDeriv}`)
          return simplifyExpression(`(${leftDeriv}) * (${right}) + (${left}) * (${rightDeriv})`)
        }
      }
    }

    // Handle division (look for /)
    depth = 0
    for (let i = expr.length - 1; i >= 0; i--) {
      const char = expr[i]
      if (char === ")") depth++
      else if (char === "(") depth--
      else if (depth === 0 && char === "/") {
        const left = expr.slice(0, i).trim()
        const right = expr.slice(i + 1).trim()
        if (left && right) {
          steps.push(`d/d${varName}(${expr}) using quotient rule: d(u/v) = (u'v - uv')/v²`)
          const leftDeriv = differentiate(left, varName, [])
          const rightDeriv = differentiate(right, varName, [])
          steps.push(`u = ${left}, u' = ${leftDeriv}`)
          steps.push(`v = ${right}, v' = ${rightDeriv}`)
          return simplifyExpression(`((${leftDeriv}) * (${right}) - (${left}) * (${rightDeriv})) / (${right})^2`)
        }
      }
    }

    // Handle power (look for ^ or **)
    depth = 0
    for (let i = expr.length - 1; i >= 0; i--) {
      const char = expr[i]
      if (char === ")") depth++
      else if (char === "(") depth--
      else if (depth === 0 && char === "^") {
        const base = expr.slice(0, i).trim()
        const exponent = expr.slice(i + 1).trim()
        if (base && exponent) {
          const expNum = Number.parseFloat(exponent)

          // Simple power rule: x^n -> n*x^(n-1)
          if (base === varName && !isNaN(expNum)) {
            steps.push(`d/d${varName}(${varName}^${exponent}) using power rule: n*x^(n-1)`)
            if (expNum === 1) return "1"
            if (expNum === 2) return `2 * ${varName}`
            return simplifyExpression(`${expNum} * ${varName}^${expNum - 1}`)
          }

          // Chain rule for (f(x))^n
          if (!isNaN(expNum)) {
            steps.push(`d/d${varName}(${expr}) using chain rule with power rule`)
            const innerDeriv = differentiate(base, varName, [])
            steps.push(`Inner function: ${base}, derivative: ${innerDeriv}`)
            return simplifyExpression(`${expNum} * (${base})^${expNum - 1} * (${innerDeriv})`)
          }

          // Exponential rule: a^x -> a^x * ln(a)
          if (!base.includes(varName) && exponent.includes(varName)) {
            steps.push(`d/d${varName}(${expr}) using exponential rule: a^x -> a^x * ln(a)`)
            const expDeriv = differentiate(exponent, varName, [])
            return simplifyExpression(`(${base})^(${exponent}) * ln(${base}) * (${expDeriv})`)
          }
        }
      }
    }

    // Handle common functions
    const funcMatch = expr.match(
      /^(sin|cos|tan|cot|sec|csc|arcsin|arccos|arctan|sinh|cosh|tanh|ln|log|exp|sqrt)$$(.*)$$$/i,
    )
    if (funcMatch) {
      const func = funcMatch[1].toLowerCase()
      const inner = funcMatch[2]
      const innerDeriv = differentiate(inner, varName, [])

      let outerDeriv = ""
      switch (func) {
        case "sin":
          steps.push(`d/d${varName}(sin(${inner})) = cos(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `cos(${inner})`
          break
        case "cos":
          steps.push(`d/d${varName}(cos(${inner})) = -sin(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `-sin(${inner})`
          break
        case "tan":
          steps.push(`d/d${varName}(tan(${inner})) = sec²(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `sec(${inner})^2`
          break
        case "cot":
          steps.push(`d/d${varName}(cot(${inner})) = -csc²(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `-csc(${inner})^2`
          break
        case "sec":
          steps.push(`d/d${varName}(sec(${inner})) = sec(${inner})*tan(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `sec(${inner}) * tan(${inner})`
          break
        case "csc":
          steps.push(`d/d${varName}(csc(${inner})) = -csc(${inner})*cot(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `-csc(${inner}) * cot(${inner})`
          break
        case "arcsin":
          steps.push(`d/d${varName}(arcsin(${inner})) = 1/√(1-${inner}²) * d/d${varName}(${inner})`)
          outerDeriv = `1 / sqrt(1 - (${inner})^2)`
          break
        case "arccos":
          steps.push(`d/d${varName}(arccos(${inner})) = -1/√(1-${inner}²) * d/d${varName}(${inner})`)
          outerDeriv = `-1 / sqrt(1 - (${inner})^2)`
          break
        case "arctan":
          steps.push(`d/d${varName}(arctan(${inner})) = 1/(1+${inner}²) * d/d${varName}(${inner})`)
          outerDeriv = `1 / (1 + (${inner})^2)`
          break
        case "sinh":
          steps.push(`d/d${varName}(sinh(${inner})) = cosh(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `cosh(${inner})`
          break
        case "cosh":
          steps.push(`d/d${varName}(cosh(${inner})) = sinh(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `sinh(${inner})`
          break
        case "tanh":
          steps.push(`d/d${varName}(tanh(${inner})) = sech²(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `sech(${inner})^2`
          break
        case "ln":
          steps.push(`d/d${varName}(ln(${inner})) = (1/${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `1 / (${inner})`
          break
        case "log":
          steps.push(`d/d${varName}(log(${inner})) = (1/(${inner} * ln(10))) * d/d${varName}(${inner})`)
          outerDeriv = `1 / ((${inner}) * ln(10))`
          break
        case "exp":
          steps.push(`d/d${varName}(exp(${inner})) = exp(${inner}) * d/d${varName}(${inner})`)
          outerDeriv = `exp(${inner})`
          break
        case "sqrt":
          steps.push(`d/d${varName}(√${inner}) = (1/(2√${inner})) * d/d${varName}(${inner})`)
          outerDeriv = `1 / (2 * sqrt(${inner}))`
          break
        default:
          return "undefined"
      }

      if (innerDeriv === "1") {
        return outerDeriv
      }
      return simplifyExpression(`(${outerDeriv}) * (${innerDeriv})`)
    }

    // Handle e^x
    if (expr.toLowerCase() === "e^" + varName || expr.toLowerCase() === "exp(" + varName + ")") {
      steps.push(`d/d${varName}(e^${varName}) = e^${varName}`)
      return `e^${varName}`
    }

    // Handle coefficient * variable (like 3x, 5x)
    const coeffMatch = expr.match(/^(-?\d*\.?\d*)\*?([a-z])$/i)
    if (coeffMatch) {
      const coeff = coeffMatch[1] || "1"
      const v = coeffMatch[2]
      if (v === varName) {
        steps.push(`d/d${varName}(${expr}) = ${coeff} (constant multiple rule)`)
        return coeff === "1" ? "1" : coeff
      }
    }

    // Handle variable with coefficient (like 3x^2)
    const termMatch = expr.match(/^(-?\d*\.?\d*)\*?([a-z])\^(-?\d*\.?\d*)$/i)
    if (termMatch) {
      const coeff = Number.parseFloat(termMatch[1] || "1")
      const v = termMatch[2]
      const exp = Number.parseFloat(termMatch[3])
      if (v === varName) {
        const newCoeff = coeff * exp
        const newExp = exp - 1
        steps.push(`d/d${varName}(${expr}) using power rule: ${coeff} * ${exp} * ${varName}^(${exp}-1)`)
        if (newExp === 0) return `${newCoeff}`
        if (newExp === 1) return `${newCoeff} * ${varName}`
        return `${newCoeff} * ${varName}^${newExp}`
      }
    }

    // If expression doesn't contain the variable, it's a constant
    if (!expr.includes(varName)) {
      steps.push(`d/d${varName}(${expr}) = 0 (constant)`)
      return "0"
    }

    // Default: try to handle as polynomial term
    steps.push(`Unable to fully parse: ${expr}`)
    return `d/d${varName}(${expr})`
  }

  // Simplify expression (basic)
  const simplifyExpression = (expr: string): string => {
    return expr
      .replace(/\+ -/g, "- ")
      .replace(/- -/g, "+ ")
      .replace(/\* 1([^0-9])/g, "$1")
      .replace(/1 \*/g, "")
      .replace(/\+ 0/g, "")
      .replace(/0 \+/g, "")
      .replace(/- 0/g, "")
      .replace(/\* 0/g, "0")
      .replace(/0 \*/g, "0")
      .replace(/\^1([^0-9]|$)/g, "$1")
      .replace(/\s+/g, " ")
      .trim()
  }

  const calculateDerivative = () => {
    setError("")
    setResult(null)

    if (!functionInput.trim()) {
      setError("Please enter a function")
      return
    }

    const orderNum = Number.parseInt(order)
    if (isNaN(orderNum) || orderNum < 1) {
      setError("Please enter a valid derivative order (1 or higher)")
      return
    }

    try {
      const steps: string[] = []
      let currentExpr = functionInput.trim()

      for (let i = 1; i <= orderNum; i++) {
        if (i > 1) {
          steps.push(`--- Taking ${i}${i === 2 ? "nd" : i === 3 ? "rd" : "th"} derivative ---`)
        }
        currentExpr = differentiate(currentExpr, variable, steps)
      }

      const simplified = simplifyExpression(currentExpr)

      setResult({
        original: functionInput.trim(),
        derivative: currentExpr,
        variable,
        order: orderNum,
        steps,
        simplified,
      })
    } catch (err) {
      setError("Error calculating derivative. Please check your function format.")
    }
  }

  const handleReset = () => {
    setFunctionInput("")
    setVariable("x")
    setOrder("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowStepsPanel(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `f(${result.variable}) = ${result.original}\nf${"'".repeat(result.order)}(${result.variable}) = ${result.simplified}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Derivative Calculation",
          text: `f(${result.variable}) = ${result.original}\nf${"'".repeat(result.order)}(${result.variable}) = ${result.simplified}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getOrdinalSuffix = (n: number): string => {
    if (n === 1) return "st"
    if (n === 2) return "nd"
    if (n === 3) return "rd"
    return "th"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Derivative Calculator</CardTitle>
                    <CardDescription>Calculate derivatives with step-by-step solutions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Function Input */}
                <div className="space-y-2">
                  <Label htmlFor="function">Function f(x)</Label>
                  <Input
                    id="function"
                    type="text"
                    placeholder="e.g., x^2 + 3*x + 5, sin(x), ln(x)"
                    value={functionInput}
                    onChange={(e) => setFunctionInput(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Use ^ for powers, * for multiplication, sin(), cos(), tan(), ln(), exp(), sqrt()
                  </p>
                </div>

                {/* Variable and Order */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="variable">Variable</Label>
                    <Select value={variable} onValueChange={setVariable}>
                      <SelectTrigger>
                        <SelectValue placeholder="Variable" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="x">x</SelectItem>
                        <SelectItem value="y">y</SelectItem>
                        <SelectItem value="t">t</SelectItem>
                        <SelectItem value="z">z</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="order">Derivative Order</Label>
                    <Select value={order} onValueChange={setOrder}>
                      <SelectTrigger>
                        <SelectValue placeholder="Order" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1st (f')</SelectItem>
                        <SelectItem value="2">2nd (f'')</SelectItem>
                        <SelectItem value="3">3rd (f''')</SelectItem>
                        <SelectItem value="4">4th</SelectItem>
                        <SelectItem value="5">5th</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step solution</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDerivative} className="w-full" size="lg">
                  Calculate Derivative
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Original Function</p>
                        <p className="text-lg font-mono">
                          f({result.variable}) = {result.original}
                        </p>
                      </div>
                      <div className="border-t border-blue-200 pt-3">
                        <p className="text-sm text-muted-foreground mb-1">
                          {result.order}
                          {getOrdinalSuffix(result.order)} Derivative
                        </p>
                        <p className="text-2xl font-bold text-blue-600 font-mono">
                          f{"'".repeat(result.order)}({result.variable}) = {result.simplified}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step Panel */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-blue-200">
                        <button
                          onClick={() => setShowStepsPanel(!showStepsPanel)}
                          className="flex items-center justify-between w-full text-sm font-medium text-blue-700"
                        >
                          <span>Step-by-step Solution</span>
                          {showStepsPanel ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>
                        {showStepsPanel && (
                          <div className="mt-3 space-y-2 text-sm">
                            {result.steps.map((step, index) => (
                              <div
                                key={index}
                                className="p-2 bg-white rounded border border-blue-100 font-mono text-xs"
                              >
                                {step.startsWith("---") ? (
                                  <p className="font-semibold text-blue-600">{step}</p>
                                ) : (
                                  <p>{step}</p>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Differentiation Rules</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Power Rule</p>
                      <p className="font-mono text-muted-foreground">d/dx(x^n) = n·x^(n-1)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Product Rule</p>
                      <p className="font-mono text-muted-foreground">d/dx(u·v) = u'v + uv'</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Quotient Rule</p>
                      <p className="font-mono text-muted-foreground">d/dx(u/v) = (u'v - uv')/v²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Chain Rule</p>
                      <p className="font-mono text-muted-foreground">d/dx(f(g(x))) = f'(g(x))·g'(x)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Derivatives</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm font-mono">
                    <div className="p-2 bg-muted rounded">sin(x) → cos(x)</div>
                    <div className="p-2 bg-muted rounded">cos(x) → -sin(x)</div>
                    <div className="p-2 bg-muted rounded">tan(x) → sec²(x)</div>
                    <div className="p-2 bg-muted rounded">e^x → e^x</div>
                    <div className="p-2 bg-muted rounded">ln(x) → 1/x</div>
                    <div className="p-2 bg-muted rounded">√x → 1/(2√x)</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Powers:</strong> x^2, x^3, (x+1)^2
                  </p>
                  <p>
                    <strong>Multiplication:</strong> 3*x, 2*x^2
                  </p>
                  <p>
                    <strong>Functions:</strong> sin(x), cos(x), tan(x), ln(x), exp(x), sqrt(x)
                  </p>
                  <p>
                    <strong>Examples:</strong>
                  </p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>x^3 + 2*x^2 - 5*x + 1</li>
                    <li>sin(x) + cos(x)</li>
                    <li>x^2 * exp(x)</li>
                    <li>ln(x^2 + 1)</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Derivative?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A derivative represents the instantaneous rate of change of a function with respect to one of its
                  variables. In geometric terms, the derivative at a point gives the slope of the tangent line to the
                  function's graph at that point. The derivative is a fundamental concept in calculus and is used
                  extensively in physics, engineering, economics, and many other fields to model rates of change and
                  optimize functions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The notation f'(x) or df/dx represents the first derivative, f''(x) or d²f/dx² represents the second
                  derivative (rate of change of the rate of change), and so on. Higher-order derivatives are useful for
                  understanding acceleration, concavity, and other properties of functions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Derivatives</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Physics</h4>
                    <p className="text-sm text-muted-foreground">
                      Velocity is the derivative of position, and acceleration is the derivative of velocity.
                      Derivatives help describe motion, forces, and energy transformations.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Economics</h4>
                    <p className="text-sm text-muted-foreground">
                      Marginal cost, marginal revenue, and elasticity are all calculated using derivatives to analyze
                      how quantities change with respect to price or output.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Optimization</h4>
                    <p className="text-sm text-muted-foreground">
                      Finding maximum and minimum values of functions by setting the derivative equal to zero is
                      essential in engineering design and resource allocation.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Machine Learning</h4>
                    <p className="text-sm text-muted-foreground">
                      Gradient descent algorithms use derivatives to minimize loss functions and train neural networks
                      by iteratively adjusting parameters.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Derivative calculations follow standard calculus rules. Results depend on correct function input and
                  selected derivative order. This calculator handles common functions and may not support all
                  mathematical expressions. For complex or specialized functions, please verify results with additional
                  resources.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
