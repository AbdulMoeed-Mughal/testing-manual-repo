"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

interface TaylorResult {
  series: string
  terms: string[]
  derivatives: { order: number; derivative: string; valueAtA: string }[]
  expansionPoint: number
  numTerms: number
  isMaclaurin: boolean
}

export function TaylorSeriesCalculator() {
  const [func, setFunc] = useState("")
  const [variable, setVariable] = useState("x")
  const [expansionPoint, setExpansionPoint] = useState("0")
  const [numTerms, setNumTerms] = useState("5")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<TaylorResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [stepsExpanded, setStepsExpanded] = useState(true)

  const factorial = (n: number): number => {
    if (n <= 1) return 1
    let result = 1
    for (let i = 2; i <= n; i++) result *= i
    return result
  }

  const evaluateFunction = (expression: string, varName: string, value: number): number => {
    const normalized = expression
      .toLowerCase()
      .replace(/\^/g, "**")
      .replace(/sin/g, "Math.sin")
      .replace(/cos/g, "Math.cos")
      .replace(/tan/g, "Math.tan")
      .replace(/exp/g, "Math.exp")
      .replace(/ln/g, "Math.log")
      .replace(/log/g, "Math.log10")
      .replace(/sqrt/g, "Math.sqrt")
      .replace(/abs/g, "Math.abs")
      .replace(/pi/g, "Math.PI")
      .replace(/e(?![a-z])/g, "Math.E")
      .replace(new RegExp(`\\b${varName}\\b`, "g"), `(${value})`)

    try {
      return Function(`"use strict"; return (${normalized})`)()
    } catch {
      return Number.NaN
    }
  }

  const numericalDerivative = (
    expression: string,
    varName: string,
    point: number,
    order: number,
    h = 0.0001,
  ): number => {
    if (order === 0) {
      return evaluateFunction(expression, varName, point)
    }
    if (order === 1) {
      const fPlus = evaluateFunction(expression, varName, point + h)
      const fMinus = evaluateFunction(expression, varName, point - h)
      return (fPlus - fMinus) / (2 * h)
    }
    const fPlus = numericalDerivative(expression, varName, point + h, order - 1, h)
    const fMinus = numericalDerivative(expression, varName, point - h, order - 1, h)
    return (fPlus - fMinus) / (2 * h)
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) < 1e-10) return "0"
    if (Math.abs(num - Math.round(num)) < 1e-10) return Math.round(num).toString()
    return num.toFixed(6).replace(/\.?0+$/, "")
  }

  const formatTerm = (coeff: number, power: number, varName: string, a: number): string => {
    if (Math.abs(coeff) < 1e-10) return ""

    const coeffStr = formatNumber(coeff)

    if (power === 0) {
      return coeffStr
    }

    const varPart = a === 0 ? varName : `(${varName} - ${formatNumber(a)})`
    const powerPart = power === 1 ? varPart : `${varPart}^${power}`

    if (Math.abs(coeff - 1) < 1e-10) {
      return powerPart
    }
    if (Math.abs(coeff + 1) < 1e-10) {
      return `-${powerPart}`
    }

    return `${coeffStr}${powerPart}`
  }

  const calculateTaylorSeries = () => {
    setError("")
    setResult(null)

    if (!func.trim()) {
      setError("Please enter a function")
      return
    }

    const a = Number.parseFloat(expansionPoint)
    if (isNaN(a)) {
      setError("Please enter a valid expansion point")
      return
    }

    const n = Number.parseInt(numTerms)
    if (isNaN(n) || n < 1 || n > 20) {
      setError("Number of terms must be between 1 and 20")
      return
    }

    const testValue = evaluateFunction(func, variable, a)
    if (isNaN(testValue)) {
      setError("Invalid function or function is undefined at the expansion point")
      return
    }

    const derivatives: { order: number; derivative: string; valueAtA: string }[] = []
    const terms: string[] = []
    const coefficients: number[] = []

    for (let k = 0; k < n; k++) {
      const derivValue = numericalDerivative(func, variable, a, k)
      const coeff = derivValue / factorial(k)
      coefficients.push(coeff)

      derivatives.push({
        order: k,
        derivative: k === 0 ? `f(${variable})` : `f${"'".repeat(Math.min(k, 3))}${k > 3 ? `^(${k})` : ""}(${variable})`,
        valueAtA: formatNumber(derivValue),
      })

      const term = formatTerm(coeff, k, variable, a)
      if (term) {
        terms.push(term)
      }
    }

    let series = terms.length > 0 ? terms[0] : "0"
    for (let i = 1; i < terms.length; i++) {
      const term = terms[i]
      if (term.startsWith("-")) {
        series += ` - ${term.slice(1)}`
      } else {
        series += ` + ${term}`
      }
    }

    if (terms.length < n) {
      series += " + ..."
    }

    setResult({
      series,
      terms,
      derivatives,
      expansionPoint: a,
      numTerms: n,
      isMaclaurin: a === 0,
    })
  }

  const handleReset = () => {
    setFunc("")
    setVariable("x")
    setExpansionPoint("0")
    setNumTerms("5")
    setShowSteps(false)
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(result.series)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getLatexOutput = (): string => {
    if (!result) return ""
    const a = result.expansionPoint
    const varPart = a === 0 ? variable : `(${variable} - ${formatNumber(a)})`

    let latex = ""
    result.derivatives.forEach((d, k) => {
      const coeff = Number.parseFloat(d.valueAtA) / factorial(k)
      if (Math.abs(coeff) < 1e-10) return

      const coeffStr = formatNumber(coeff)
      const powerPart = k === 0 ? "" : k === 1 ? varPart : `${varPart}^{${k}}`

      if (latex.length > 0) {
        if (coeff >= 0) latex += " + "
        else latex += " - "
        latex += Math.abs(coeff) === 1 && k > 0 ? powerPart : `${formatNumber(Math.abs(coeff))}${powerPart}`
      } else {
        latex += coeff === 1 && k > 0 ? powerPart : `${coeffStr}${powerPart}`
      }
    })

    return latex || "0"
  }

  const handleCopyLatex = async () => {
    const latex = getLatexOutput()
    await navigator.clipboard.writeText(latex)
    setCopiedLatex(true)
    setTimeout(() => setCopiedLatex(false), 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Taylor Series Calculator</CardTitle>
                    <CardDescription>Compute Taylor/Maclaurin series expansions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="func">Function f({variable})</Label>
                  <Input
                    id="func"
                    type="text"
                    placeholder="e.g., sin(x), e^x, ln(1+x), x^2 + 3x"
                    value={func}
                    onChange={(e) => setFunc(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="variable">Variable</Label>
                    <Select value={variable} onValueChange={setVariable}>
                      <SelectTrigger id="variable">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="x">x</SelectItem>
                        <SelectItem value="t">t</SelectItem>
                        <SelectItem value="y">y</SelectItem>
                        <SelectItem value="z">z</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="expansionPoint">Expansion Point (a)</Label>
                    <Input
                      id="expansionPoint"
                      type="number"
                      placeholder="0 for Maclaurin"
                      value={expansionPoint}
                      onChange={(e) => setExpansionPoint(e.target.value)}
                      step="any"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="numTerms">Number of Terms (n)</Label>
                  <Input
                    id="numTerms"
                    type="number"
                    placeholder="1-20"
                    value={numTerms}
                    onChange={(e) => setNumTerms(e.target.value)}
                    min="1"
                    max="20"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show Step-by-Step Solution</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateTaylorSeries} className="w-full" size="lg">
                  Calculate Taylor Series
                </Button>

                {result && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">
                          {result.isMaclaurin
                            ? "Maclaurin Series"
                            : `Taylor Series (a = ${formatNumber(result.expansionPoint)})`}
                        </p>
                        <p className="text-lg font-mono font-semibold text-blue-700 break-all">{result.series}</p>
                      </div>

                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                          {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copiedLatex ? "Copied" : "LaTeX"}
                        </Button>
                      </div>
                    </div>

                    {showSteps && (
                      <Card>
                        <CardHeader className="cursor-pointer" onClick={() => setStepsExpanded(!stepsExpanded)}>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-base">Step-by-Step Solution</CardTitle>
                            {stepsExpanded ? (
                              <ChevronUp className="h-5 w-5 text-muted-foreground" />
                            ) : (
                              <ChevronDown className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                        </CardHeader>
                        {stepsExpanded && (
                          <CardContent className="space-y-3">
                            <div className="p-3 bg-muted rounded-lg">
                              <p className="text-sm font-medium mb-2">Taylor Series Formula:</p>
                              <p className="text-sm font-mono">T(x) = Σ [f⁽ⁿ⁾(a)/n!] × (x - a)ⁿ, n = 0 to ∞</p>
                            </div>

                            <div className="space-y-2">
                              <p className="text-sm font-medium">
                                Derivatives at a = {formatNumber(result.expansionPoint)}:
                              </p>
                              {result.derivatives.map((d, idx) => (
                                <div
                                  key={idx}
                                  className="flex items-center justify-between p-2 bg-muted/50 rounded text-sm"
                                >
                                  <span className="font-mono">{d.derivative}</span>
                                  <span className="font-mono text-blue-600">{d.valueAtA}</span>
                                </div>
                              ))}
                            </div>

                            <div className="space-y-2">
                              <p className="text-sm font-medium">Term Calculation:</p>
                              {result.derivatives.map((d, k) => {
                                const coeff = Number.parseFloat(d.valueAtA) / factorial(k)
                                if (Math.abs(coeff) < 1e-10) return null
                                return (
                                  <div key={k} className="p-2 bg-muted/50 rounded text-sm font-mono">
                                    <span>Term {k}: </span>
                                    <span className="text-muted-foreground">
                                      {d.valueAtA}/{k}! × ({variable} - {formatNumber(result.expansionPoint)})^{k}
                                    </span>
                                    <span className="text-blue-600">
                                      {" "}
                                      = {formatNumber(coeff)}
                                      {k > 0 &&
                                        (result.expansionPoint === 0
                                          ? `${variable}`
                                          : `(${variable} - ${formatNumber(result.expansionPoint)})`)}
                                      {k > 1 && `^${k}`}
                                    </span>
                                  </div>
                                )
                              })}
                            </div>
                          </CardContent>
                        )}
                      </Card>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Taylor Series Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">T(x) = f(a) + f'(a)(x-a) + f''(a)(x-a)²/2! + ...</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>f(a)</strong> = function value at expansion point
                    </p>
                    <p>
                      <strong>f⁽ⁿ⁾(a)</strong> = nth derivative at point a
                    </p>
                    <p>
                      <strong>n!</strong> = factorial of n
                    </p>
                    <p>
                      <strong>a = 0</strong> → Maclaurin series
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Series</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">eˣ</span>
                      <span className="font-mono text-blue-600">1 + x + x²/2! + x³/3! + ...</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">sin(x)</span>
                      <span className="font-mono text-blue-600">x - x³/3! + x⁵/5! - ...</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">cos(x)</span>
                      <span className="font-mono text-blue-600">1 - x²/2! + x⁴/4! - ...</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">ln(1+x)</span>
                      <span className="font-mono text-blue-600">x - x²/2 + x³/3 - ...</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">1/(1-x)</span>
                      <span className="font-mono text-blue-600">1 + x + x² + x³ + ...</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Supported operations:</strong>
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>Basic: +, -, *, /, ^ (power)</li>
                    <li>Trig: sin, cos, tan</li>
                    <li>Exp/Log: exp, ln, log</li>
                    <li>Other: sqrt, abs, pi, e</li>
                  </ul>
                  <p className="mt-2">
                    <strong>Examples:</strong>
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>sin(x), cos(x), tan(x)</li>
                    <li>exp(x), e^x, ln(x)</li>
                    <li>x^2 + 3*x - 1</li>
                    <li>1/(1-x), sqrt(1+x)</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Taylor Series?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A Taylor series is a representation of a function as an infinite sum of terms calculated from the
                  values of the function's derivatives at a single point. Named after British mathematician Brook
                  Taylor, this powerful tool allows us to approximate complex functions using polynomials, making
                  calculations and analysis significantly easier. When the expansion point is zero, the series is called
                  a Maclaurin series.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Taylor series are fundamental in calculus, physics, and engineering for approximating functions,
                  solving differential equations, and understanding function behavior near specific points. The more
                  terms included in the series, the more accurate the approximation becomes within the radius of
                  convergence.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Taylor Series</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Taylor series have numerous practical applications across mathematics and science. In numerical
                  computing, they're used to calculate values of trigonometric, exponential, and logarithmic functions.
                  Scientific calculators and computers use Taylor polynomial approximations for these calculations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In physics, Taylor series help linearize complex equations for easier analysis, approximate solutions
                  to differential equations, and study small oscillations and perturbations. Engineers use them for
                  signal processing, control systems, and error analysis in measurements.
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-8">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
                <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Taylor series calculations follow standard calculus formulas. Results depend on correct function input,
                expansion point, and number of terms. This calculator uses numerical differentiation for general
                functions, which may introduce small approximation errors. For educational and reference purposes only.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
