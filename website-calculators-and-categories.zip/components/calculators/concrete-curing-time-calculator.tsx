"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Clock, Info, AlertTriangle, Building2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type ConcreteGrade = "M10" | "M15" | "M20" | "M25" | "M30" | "M35"
type CementType = "OPC" | "PPC" | "PSC"
type TemperatureUnit = "celsius" | "fahrenheit"

interface CuringResult {
  recommendedDays: number
  minimumDays: number
  maximumDays: number
  category: string
  curingMethod: string
  color: string
  bgColor: string
}

export function ConcreteCuringTimeCalculator() {
  const [concreteGrade, setConcreteGrade] = useState<ConcreteGrade>("M20")
  const [temperature, setTemperature] = useState("")
  const [temperatureUnit, setTemperatureUnit] = useState<TemperatureUnit>("celsius")
  const [humidity, setHumidity] = useState("")
  const [cementType, setCementType] = useState<CementType>("OPC")
  const [result, setResult] = useState<CuringResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCuringTime = () => {
    setError("")
    setResult(null)

    const tempNum = Number.parseFloat(temperature)
    if (isNaN(tempNum)) {
      setError("Please enter a valid temperature")
      return
    }

    // Convert to Celsius if needed
    const tempCelsius = temperatureUnit === "fahrenheit" ? ((tempNum - 32) * 5) / 9 : tempNum

    if (tempCelsius < -10 || tempCelsius > 60) {
      setError("Temperature must be between -10°C and 60°C (14°F and 140°F)")
      return
    }

    const humidityNum = humidity ? Number.parseFloat(humidity) : 70
    if (humidityNum < 0 || humidityNum > 100) {
      setError("Humidity must be between 0% and 100%")
      return
    }

    // Base curing time for different grades
    const baseCuringDays: Record<ConcreteGrade, number> = {
      M10: 7,
      M15: 10,
      M20: 14,
      M25: 21,
      M30: 28,
      M35: 28,
    }

    let recommendedDays = baseCuringDays[concreteGrade]

    // Adjust for temperature
    if (tempCelsius < 10) {
      recommendedDays += 7 // Cold weather requires longer curing
    } else if (tempCelsius > 35) {
      recommendedDays += 3 // Hot weather needs extended curing
    }

    // Adjust for humidity
    if (humidityNum < 50) {
      recommendedDays += 3 // Low humidity requires longer curing
    }

    // Adjust for cement type
    if (cementType === "PPC" || cementType === "PSC") {
      recommendedDays += 3 // Blended cements need more time
    }

    const minimumDays = Math.max(7, recommendedDays - 7)
    const maximumDays = recommendedDays + 7

    // Determine curing category and method
    let category: string
    let curingMethod: string
    let color: string
    let bgColor: string

    if (tempCelsius < 10) {
      category = "Cold Weather Curing"
      curingMethod = "Use heated enclosures, insulating blankets, or accelerators. Maintain concrete temperature above 10°C."
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (tempCelsius > 35) {
      category = "Hot Weather Curing"
      curingMethod =
        "Increase water curing frequency, use wet burlap or plastic sheets, apply curing compounds, and provide shade."
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else if (humidityNum < 50) {
      category = "Low Humidity Curing"
      curingMethod = "Apply continuous water curing, use curing membranes or plastic sheets to prevent moisture loss."
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Standard Curing"
      curingMethod = "Apply standard water curing by ponding, spraying, or wet covering at regular intervals."
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    }

    setResult({
      recommendedDays,
      minimumDays,
      maximumDays,
      category,
      curingMethod,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setConcreteGrade("M20")
    setTemperature("")
    setHumidity("")
    setCementType("OPC")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Concrete Curing Time: ${result.recommendedDays} days (${result.category}) for ${concreteGrade} grade`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Concrete Curing Time Result",
          text: `Recommended curing time: ${result.recommendedDays} days for ${concreteGrade} grade concrete`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleTemperatureUnit = () => {
    setTemperatureUnit((prev) => (prev === "celsius" ? "fahrenheit" : "celsius"))
    setTemperature("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Clock className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Concrete Curing Time Calculator</CardTitle>
                    <CardDescription>Estimate required curing duration</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Concrete Grade */}
                <div className="space-y-2">
                  <Label htmlFor="grade">Concrete Grade</Label>
                  <Select value={concreteGrade} onValueChange={(value: ConcreteGrade) => setConcreteGrade(value)}>
                    <SelectTrigger id="grade">
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M10">M10</SelectItem>
                      <SelectItem value="M15">M15</SelectItem>
                      <SelectItem value="M20">M20</SelectItem>
                      <SelectItem value="M25">M25</SelectItem>
                      <SelectItem value="M30">M30</SelectItem>
                      <SelectItem value="M35">M35</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Temperature */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="temperature">Ambient Temperature</Label>
                    <button
                      onClick={toggleTemperatureUnit}
                      className="text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
                    >
                      Switch to {temperatureUnit === "celsius" ? "°F" : "°C"}
                    </button>
                  </div>
                  <Input
                    id="temperature"
                    type="number"
                    placeholder={`Enter temperature in ${temperatureUnit === "celsius" ? "°C" : "°F"}`}
                    value={temperature}
                    onChange={(e) => setTemperature(e.target.value)}
                    step="0.1"
                  />
                </div>

                {/* Humidity (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="humidity">Humidity (%) - Optional</Label>
                  <Input
                    id="humidity"
                    type="number"
                    placeholder="Enter humidity (default: 70%)"
                    value={humidity}
                    onChange={(e) => setHumidity(e.target.value)}
                    min="0"
                    max="100"
                    step="1"
                  />
                </div>

                {/* Cement Type */}
                <div className="space-y-2">
                  <Label htmlFor="cement">Cement Type</Label>
                  <Select value={cementType} onValueChange={(value: CementType) => setCementType(value)}>
                    <SelectTrigger id="cement">
                      <SelectValue placeholder="Select cement type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="OPC">OPC (Ordinary Portland Cement)</SelectItem>
                      <SelectItem value="PPC">PPC (Portland Pozzolana Cement)</SelectItem>
                      <SelectItem value="PSC">PSC (Portland Slag Cement)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCuringTime} className="w-full" size="lg">
                  Calculate Curing Time
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Recommended Curing Time</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.recommendedDays}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>days</p>
                      <p className="text-sm text-muted-foreground mt-2">{result.category}</p>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between p-2 bg-background/50 rounded">
                        <span className="text-muted-foreground">Minimum:</span>
                        <span className="font-medium">{result.minimumDays} days</span>
                      </div>
                      <div className="flex justify-between p-2 bg-background/50 rounded">
                        <span className="text-muted-foreground">Maximum:</span>
                        <span className="font-medium">{result.maximumDays} days</span>
                      </div>
                      <div className="p-3 bg-background/50 rounded mt-3">
                        <p className="font-medium mb-1">Curing Method:</p>
                        <p className="text-muted-foreground text-xs leading-relaxed">{result.curingMethod}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Curing Periods</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M10-M15</span>
                      <span className="text-sm text-amber-600">7-10 days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M20</span>
                      <span className="text-sm text-amber-600">14 days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M25</span>
                      <span className="text-sm text-amber-600">21 days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M30-M35</span>
                      <span className="text-sm text-amber-600">28 days</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Curing Methods</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div>
                    <h4 className="font-semibold mb-1">Water Curing</h4>
                    <p className="text-muted-foreground text-xs">
                      Ponding, spraying, or wet burlap covering to maintain moisture
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Membrane Curing</h4>
                    <p className="text-muted-foreground text-xs">
                      Application of liquid curing compounds to seal moisture
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Steam Curing</h4>
                    <p className="text-muted-foreground text-xs">
                      Accelerated curing using steam for precast elements
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Concrete Curing */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Concrete Curing?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Concrete curing is the process of maintaining adequate moisture, temperature, and time to allow
                  concrete to achieve its desired properties and strength. Proper curing is critical because concrete
                  continues to gain strength long after it's placed, with the hydration process requiring sufficient
                  water to proceed effectively. Without proper curing, concrete can develop surface cracks, have
                  reduced durability, and fail to reach its design strength.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The curing period typically ranges from 7 to 28 days depending on the concrete grade, cement type,
                  and environmental conditions. During this time, the concrete must be kept moist and at an appropriate
                  temperature. Higher-grade concrete generally requires longer curing periods to fully develop its
                  strength characteristics, while environmental factors like temperature and humidity can significantly
                  affect the rate of strength gain.
                </p>
              </CardContent>
            </Card>

            {/* Why Curing Duration Matters */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Why Curing Duration Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The duration of curing directly impacts the final strength and durability of concrete. Research shows
                  that concrete that's cured for only 3 days reaches approximately 50% of its 28-day strength, while
                  concrete cured for 7 days achieves about 70% of its design strength. Proper curing for the full
                  recommended period ensures that the concrete develops its full potential strength, resistance to
                  weathering, and long-term durability.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature and humidity play crucial roles in determining the optimal curing duration. Cold weather
                  slows the hydration process, requiring extended curing periods and sometimes heated enclosures to
                  maintain appropriate temperatures. Hot weather accelerates evaporation and can lead to surface
                  cracking if moisture isn't adequately maintained. Low humidity environments demand more frequent water
                  application or the use of curing membranes to prevent premature drying.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions About Concrete Curing</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">When should curing begin?</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Curing should begin as soon as the concrete surface is firm enough to resist damage from the curing
                    method, typically within a few hours after finishing. Early curing is crucial to prevent plastic
                    shrinkage cracks.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Can I over-cure concrete?</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    While you can't technically "over-cure" concrete in terms of strength, extended curing beyond 28
                    days provides diminishing returns. Most concrete achieves 90-95% of its design strength by 28 days.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">What happens if curing is inadequate?</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Inadequate curing leads to reduced strength (up to 50% loss), increased permeability, surface
                    dusting, crazing, and reduced resistance to freeze-thaw cycles and chemical attack.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Does the type of cement affect curing time?</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Yes. Blended cements like PPC and PSC have slower hydration rates and generally require longer
                    curing periods compared to OPC to achieve their full strength potential.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-amber-900 mb-2">Important Note</h3>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Curing time estimates are indicative and based on standard conditions. Actual curing requirements
                      may vary based on specific environmental conditions, concrete mix design, project specifications,
                      and site practices. Always consult with a structural engineer or follow project specifications
                      for critical applications.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
