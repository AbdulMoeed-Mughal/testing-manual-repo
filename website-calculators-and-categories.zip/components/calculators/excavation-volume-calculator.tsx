"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Shovel, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type ExcavationType = "rectangular" | "trench" | "circular"
type UnitSystem = "metric" | "imperial"

interface ExcavationResult {
  volume: number
  looseVolume: number
  unit: string
}

export function ExcavationVolumeCalculator() {
  const [excavationType, setExcavationType] = useState<ExcavationType>("rectangular")
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [depth, setDepth] = useState("")
  const [diameter, setDiameter] = useState("")
  const [numberOfExcavations, setNumberOfExcavations] = useState("1")
  const [slopeAllowance, setSlopeAllowance] = useState("")
  const [result, setResult] = useState<ExcavationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateVolume = () => {
    setError("")
    setResult(null)

    const depthNum = Number.parseFloat(depth)
    const numExcavations = Number.parseInt(numberOfExcavations) || 1
    const slopeNum = Number.parseFloat(slopeAllowance) || 0

    if (isNaN(depthNum) || depthNum <= 0) {
      setError("Please enter a valid depth greater than 0")
      return
    }

    if (numExcavations <= 0) {
      setError("Number of excavations must be at least 1")
      return
    }

    let volume = 0
    const unit = unitSystem === "metric" ? "m³" : "ft³"

    if (excavationType === "rectangular") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)

      if (isNaN(lengthNum) || lengthNum <= 0 || isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter valid length and width greater than 0")
        return
      }

      // Basic volume
      volume = lengthNum * widthNum * depthNum

      // Apply slope allowance if provided
      if (slopeNum > 0) {
        const topLength = lengthNum + (2 * depthNum * slopeNum)
        const topWidth = widthNum + (2 * depthNum * slopeNum)
        const bottomLength = lengthNum
        const bottomWidth = widthNum
        // Trapezoidal prism volume
        volume = (depthNum / 3) * ((topLength * topWidth) + (bottomLength * bottomWidth) + 
                  Math.sqrt((topLength * topWidth) * (bottomLength * bottomWidth)))
      }
    } else if (excavationType === "trench") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)

      if (isNaN(lengthNum) || lengthNum <= 0 || isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter valid length and width greater than 0")
        return
      }

      volume = lengthNum * widthNum * depthNum

      // Apply slope allowance
      if (slopeNum > 0) {
        const topWidth = widthNum + (2 * depthNum * slopeNum)
        const avgWidth = (topWidth + widthNum) / 2
        volume = lengthNum * avgWidth * depthNum
      }
    } else if (excavationType === "circular") {
      const diameterNum = Number.parseFloat(diameter)

      if (isNaN(diameterNum) || diameterNum <= 0) {
        setError("Please enter a valid diameter greater than 0")
        return
      }

      const radius = diameterNum / 2
      volume = Math.PI * radius * radius * depthNum

      // Apply slope allowance
      if (slopeNum > 0) {
        const topRadius = radius + (depthNum * slopeNum)
        // Truncated cone volume
        volume = (Math.PI * depthNum / 3) * (radius * radius + radius * topRadius + topRadius * topRadius)
      }
    }

    const totalVolume = volume * numExcavations
    const looseVolume = totalVolume * 1.25 // 25% swell factor

    setResult({
      volume: Math.round(totalVolume * 100) / 100,
      looseVolume: Math.round(looseVolume * 100) / 100,
      unit,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setDepth("")
    setDiameter("")
    setNumberOfExcavations("1")
    setSlopeAllowance("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Excavation Volume: ${result.volume} ${result.unit}\nLoose Soil Volume: ${result.looseVolume} ${result.unit}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Excavation Volume Result",
          text: `Excavation Volume: ${result.volume} ${result.unit}, Loose Soil: ${result.looseVolume} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setDepth("")
    setDiameter("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Shovel className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Excavation Volume Calculator</CardTitle>
                    <CardDescription>Calculate earthwork excavation volume</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Excavation Type Selector */}
                <div className="space-y-2">
                  <Label>Excavation Type</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setExcavationType("rectangular")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        excavationType === "rectangular"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-border hover:border-amber-200"
                      }`}
                    >
                      Rectangular
                    </button>
                    <button
                      onClick={() => setExcavationType("trench")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        excavationType === "trench"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-border hover:border-amber-200"
                      }`}
                    >
                      Trench
                    </button>
                    <button
                      onClick={() => setExcavationType("circular")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        excavationType === "circular"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-border hover:border-amber-200"
                      }`}
                    >
                      Circular
                    </button>
                  </div>
                </div>

                {/* Dimension Inputs */}
                {excavationType === "circular" ? (
                  <div className="space-y-2">
                    <Label htmlFor="diameter">Diameter ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="diameter"
                      type="number"
                      placeholder="Enter diameter"
                      value={diameter}
                      onChange={(e) => setDiameter(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                      <Input
                        id="length"
                        type="number"
                        placeholder="Enter length"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                      <Input
                        id="width"
                        type="number"
                        placeholder="Enter width"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="depth">Depth ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="depth"
                    type="number"
                    placeholder="Enter depth"
                    value={depth}
                    onChange={(e) => setDepth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="number">Number of Excavations</Label>
                  <Input
                    id="number"
                    type="number"
                    placeholder="Enter number"
                    value={numberOfExcavations}
                    onChange={(e) => setNumberOfExcavations(e.target.value)}
                    min="1"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="slope">Side Slope Allowance (H:V ratio, optional)</Label>
                  <Input
                    id="slope"
                    type="number"
                    placeholder="e.g., 1 for 1:1 slope"
                    value={slopeAllowance}
                    onChange={(e) => setSlopeAllowance(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateVolume} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Volume
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total Excavation Volume</p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">{result.volume}</p>
                        <p className="text-lg font-semibold text-amber-700">{result.unit}</p>
                      </div>

                      <div className="pt-3 border-t border-amber-200">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Loose Soil Volume (25% swell):</span>
                          <span className="font-semibold text-amber-700">
                            {result.looseVolume} {result.unit}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Excavation Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Rectangular Pit</h4>
                      <p className="text-sm text-amber-700">For foundations, basements, and building excavations</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Trench</h4>
                      <p className="text-sm text-amber-700">For pipelines, drainage, and utility installations</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Circular Pit</h4>
                      <p className="text-sm text-amber-700">For wells, pillars, and cylindrical structures</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Slope Ratios</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Stable soil:</span>
                    <span className="font-semibold">1:1 (45°)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Sandy soil:</span>
                    <span className="font-semibold">1.5:1 (33.7°)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Soft clay:</span>
                    <span className="font-semibold">2:1 (26.6°)</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Excavation Volume?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Excavation volume refers to the amount of earth or material that needs to be removed from the ground
                  for construction purposes. This includes digging for foundations, trenches for utilities, basements,
                  and other earthwork activities. Accurate volume calculation is essential for estimating costs, planning
                  equipment needs, and managing disposal or reuse of excavated material.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The excavation process involves removing soil, rock, or other materials from their natural position.
                  The volume calculation must account for the type of excavation (rectangular pit, trench, or circular
                  pit), dimensions, and factors like side slopes for safety and stability. Proper excavation planning
                  ensures structural integrity and compliance with safety regulations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Excavation Volume</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation method depends on the excavation type. For rectangular pits, multiply length, width,
                  and depth. For trenches, use the same formula but typically with a longer length. For circular pits,
                  use the formula: Volume = π × (diameter/2)² × depth. When side slopes are required for safety, the
                  volume increases as the excavation widens toward the top.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The loose soil volume (also called bank measure) accounts for the 20-30% volume increase when soil is
                  excavated and disturbed. This is crucial for planning hauling capacity and disposal site requirements.
                  Most soils swell by approximately 25% when excavated, which means more volume to transport than the
                  original in-ground measurement.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shovel className="h-5 w-5 text-primary" />
                  <CardTitle>Excavation Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Foundation excavation creates space for building footings and basement construction. Trench excavation
                  is used for underground utilities including water, sewer, gas lines, and electrical conduits. Pit
                  excavation supports structures like elevator shafts, septic systems, and deep foundations. Each
                  application requires specific depth, width, and safety considerations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Side slopes prevent cave-ins and ensure worker safety during excavation. The slope ratio depends on
                  soil type, depth, and moisture content. OSHA regulations require proper sloping or shoring for
                  excavations deeper than 5 feet. Understanding these requirements helps create safe, compliant
                  excavation plans while accurately estimating material quantities.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Excavation volumes are approximate. Actual quantities may vary due to soil conditions, side slopes,
                  over-excavation, and site-specific factors. Always consult with qualified engineers and follow local
                  building codes and safety regulations. Professional soil testing and engineering analysis are
                  recommended for large or complex excavation projects.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
