"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Zap,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Calculator,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMethod = "ohms-law" | "power-voltage" | "power-resistance"
type OutputUnit = "A" | "mA" | "μA"
type CircuitType = "single" | "series" | "parallel"

interface CurrentResult {
  current: number
  displayCurrent: string
  unit: string
  method: string
  steps: string[]
}

export function CurrentCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("ohms-law")
  const [voltage, setVoltage] = useState("")
  const [resistance, setResistance] = useState("")
  const [power, setPower] = useState("")
  const [outputUnit, setOutputUnit] = useState<OutputUnit>("A")
  const [circuitType, setCircuitType] = useState<CircuitType>("single")
  const [resistances, setResistances] = useState<string[]>(["", ""])
  const [result, setResult] = useState<CurrentResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const convertCurrent = (currentInAmps: number, toUnit: OutputUnit): number => {
    switch (toUnit) {
      case "mA":
        return currentInAmps * 1000
      case "μA":
        return currentInAmps * 1000000
      default:
        return currentInAmps
    }
  }

  const formatCurrent = (current: number, unit: OutputUnit): string => {
    const converted = convertCurrent(current, unit)
    if (Math.abs(converted) >= 1000) {
      return converted.toExponential(4)
    }
    return converted.toFixed(6).replace(/\.?0+$/, "")
  }

  const getUnitLabel = (unit: OutputUnit): string => {
    switch (unit) {
      case "mA":
        return "Milliamps"
      case "μA":
        return "Microamps"
      default:
        return "Amps"
    }
  }

  const calculateTotalResistance = (): { total: number; steps: string[] } => {
    const validResistances = resistances
      .filter((r) => r && !isNaN(Number.parseFloat(r)) && Number.parseFloat(r) > 0)
      .map((r) => Number.parseFloat(r))

    if (validResistances.length === 0) {
      return { total: 0, steps: [] }
    }

    if (circuitType === "series") {
      const total = validResistances.reduce((sum, r) => sum + r, 0)
      const steps = [
        `Series Circuit: R_total = R₁ + R₂ + ... + Rₙ`,
        `R_total = ${validResistances.join(" + ")} Ω`,
        `R_total = ${total.toFixed(4)} Ω`,
      ]
      return { total, steps }
    } else if (circuitType === "parallel") {
      const reciprocalSum = validResistances.reduce((sum, r) => sum + 1 / r, 0)
      const total = 1 / reciprocalSum
      const steps = [
        `Parallel Circuit: 1/R_total = 1/R₁ + 1/R₂ + ... + 1/Rₙ`,
        `1/R_total = ${validResistances.map((r) => `1/${r}`).join(" + ")}`,
        `1/R_total = ${reciprocalSum.toFixed(6)}`,
        `R_total = ${total.toFixed(4)} Ω`,
      ]
      return { total, steps }
    }

    return { total: validResistances[0] || 0, steps: [] }
  }

  const calculateCurrent = () => {
    setError("")
    setResult(null)

    let currentInAmps: number
    let steps: string[] = []
    let methodUsed: string

    if (method === "ohms-law") {
      const V = Number.parseFloat(voltage)

      if (isNaN(V) || V < 0) {
        setError("Please enter a valid voltage (≥ 0)")
        return
      }

      let R: number
      let resistanceSteps: string[] = []

      if (circuitType === "single") {
        R = Number.parseFloat(resistance)
        if (isNaN(R) || R <= 0) {
          setError("Please enter a valid resistance (> 0)")
          return
        }
      } else {
        const { total, steps: rSteps } = calculateTotalResistance()
        if (total <= 0) {
          setError("Please enter at least one valid resistance (> 0)")
          return
        }
        R = total
        resistanceSteps = rSteps
      }

      if (R === 0) {
        setError("Resistance cannot be zero (would cause infinite current)")
        return
      }

      currentInAmps = V / R
      methodUsed = "Ohm's Law"
      steps = [
        "Using Ohm's Law: I = V / R",
        ...resistanceSteps,
        `I = ${V} V / ${R.toFixed(4)} Ω`,
        `I = ${currentInAmps.toFixed(6)} A`,
      ]
    } else if (method === "power-voltage") {
      const P = Number.parseFloat(power)
      const V = Number.parseFloat(voltage)

      if (isNaN(P) || P < 0) {
        setError("Please enter a valid power (≥ 0)")
        return
      }
      if (isNaN(V) || V <= 0) {
        setError("Please enter a valid voltage (> 0)")
        return
      }

      currentInAmps = P / V
      methodUsed = "Power & Voltage"
      steps = [
        "Using Power Formula: P = I × V",
        "Rearranging: I = P / V",
        `I = ${P} W / ${V} V`,
        `I = ${currentInAmps.toFixed(6)} A`,
      ]
    } else {
      const P = Number.parseFloat(power)

      if (isNaN(P) || P < 0) {
        setError("Please enter a valid power (≥ 0)")
        return
      }

      let R: number
      let resistanceSteps: string[] = []

      if (circuitType === "single") {
        R = Number.parseFloat(resistance)
        if (isNaN(R) || R <= 0) {
          setError("Please enter a valid resistance (> 0)")
          return
        }
      } else {
        const { total, steps: rSteps } = calculateTotalResistance()
        if (total <= 0) {
          setError("Please enter at least one valid resistance (> 0)")
          return
        }
        R = total
        resistanceSteps = rSteps
      }

      currentInAmps = Math.sqrt(P / R)
      methodUsed = "Power & Resistance"
      steps = [
        "Using Power Formula: P = I² × R",
        "Rearranging: I = √(P / R)",
        ...resistanceSteps,
        `I = √(${P} W / ${R.toFixed(4)} Ω)`,
        `I = √${(P / R).toFixed(6)}`,
        `I = ${currentInAmps.toFixed(6)} A`,
      ]
    }

    if (outputUnit !== "A") {
      const converted = convertCurrent(currentInAmps, outputUnit)
      steps.push(`Converting to ${getUnitLabel(outputUnit)}: ${converted.toFixed(6)} ${outputUnit}`)
    }

    setResult({
      current: currentInAmps,
      displayCurrent: formatCurrent(currentInAmps, outputUnit),
      unit: outputUnit,
      method: methodUsed,
      steps,
    })
  }

  const handleReset = () => {
    setVoltage("")
    setResistance("")
    setPower("")
    setResistances(["", ""])
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Current: ${result.displayCurrent} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Current Calculation Result",
          text: `I calculated electric current using CalcHub! Current: ${result.displayCurrent} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const addResistance = () => {
    if (resistances.length < 10) {
      setResistances([...resistances, ""])
    }
  }

  const removeResistance = (index: number) => {
    if (resistances.length > 2) {
      setResistances(resistances.filter((_, i) => i !== index))
    }
  }

  const updateResistance = (index: number, value: string) => {
    const newResistances = [...resistances]
    newResistances[index] = value
    setResistances(newResistances)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Current Calculator</CardTitle>
                    <CardDescription>Calculate electric current in a circuit</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Method */}
                <div className="space-y-2">
                  <Label>Calculation Method</Label>
                  <Select value={method} onValueChange={(v) => setMethod(v as CalculationMethod)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ohms-law">Ohm's Law (I = V/R)</SelectItem>
                      <SelectItem value="power-voltage">Power & Voltage (I = P/V)</SelectItem>
                      <SelectItem value="power-resistance">Power & Resistance (I = √(P/R))</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Circuit Type - Only for methods using resistance */}
                {(method === "ohms-law" || method === "power-resistance") && (
                  <div className="space-y-2">
                    <Label>Circuit Type</Label>
                    <Select value={circuitType} onValueChange={(v) => setCircuitType(v as CircuitType)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="single">Single Resistor</SelectItem>
                        <SelectItem value="series">Series Circuit</SelectItem>
                        <SelectItem value="parallel">Parallel Circuit</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Voltage Input */}
                {(method === "ohms-law" || method === "power-voltage") && (
                  <div className="space-y-2">
                    <Label htmlFor="voltage">Voltage (V)</Label>
                    <Input
                      id="voltage"
                      type="number"
                      placeholder="Enter voltage in volts"
                      value={voltage}
                      onChange={(e) => setVoltage(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Resistance Input(s) */}
                {(method === "ohms-law" || method === "power-resistance") && (
                  <>
                    {circuitType === "single" ? (
                      <div className="space-y-2">
                        <Label htmlFor="resistance">Resistance (Ω)</Label>
                        <Input
                          id="resistance"
                          type="number"
                          placeholder="Enter resistance in ohms"
                          value={resistance}
                          onChange={(e) => setResistance(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Label>Resistances (Ω)</Label>
                        <div className="space-y-2">
                          {resistances.map((r, index) => (
                            <div key={index} className="flex gap-2">
                              <Input
                                type="number"
                                placeholder={`R${index + 1} in ohms`}
                                value={r}
                                onChange={(e) => updateResistance(index, e.target.value)}
                                min="0"
                                step="any"
                              />
                              {resistances.length > 2 && (
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => removeResistance(index)}
                                  className="shrink-0"
                                >
                                  ×
                                </Button>
                              )}
                            </div>
                          ))}
                          {resistances.length < 10 && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={addResistance}
                              className="w-full bg-transparent"
                            >
                              + Add Resistor
                            </Button>
                          )}
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* Power Input */}
                {(method === "power-voltage" || method === "power-resistance") && (
                  <div className="space-y-2">
                    <Label htmlFor="power">Power (W)</Label>
                    <Input
                      id="power"
                      type="number"
                      placeholder="Enter power in watts"
                      value={power}
                      onChange={(e) => setPower(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Output Unit */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <Select value={outputUnit} onValueChange={(v) => setOutputUnit(v as OutputUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A">Amps (A)</SelectItem>
                      <SelectItem value="mA">Milliamps (mA)</SelectItem>
                      <SelectItem value="μA">Microamps (μA)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCurrent} className="w-full" size="lg">
                  Calculate Current
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-yellow-50 border-yellow-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Electric Current</p>
                      <p className="text-4xl font-bold text-yellow-600 mb-1">
                        {result.displayCurrent} <span className="text-2xl">{result.unit}</span>
                      </p>
                      <p className="text-sm text-muted-foreground">Calculated using {result.method}</p>
                    </div>

                    {/* Step-by-step Toggle */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-yellow-700"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4 mr-1" /> : <ChevronDown className="h-4 w-4 mr-1" />}
                      {showSteps ? "Hide Steps" : "Show Steps"}
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg border border-yellow-200">
                        <p className="text-sm font-medium mb-2">Step-by-Step Calculation:</p>
                        <ol className="text-sm text-muted-foreground space-y-1">
                          {result.steps.map((step, index) => (
                            <li key={index} className="font-mono text-xs">
                              {step}
                            </li>
                          ))}
                        </ol>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Current Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <p className="font-medium text-yellow-700">Ohm's Law</p>
                      <p className="text-sm text-yellow-600 font-mono mt-1">I = V / R</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700">Power & Voltage</p>
                      <p className="text-sm text-blue-600 font-mono mt-1">I = P / V</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-700">Power & Resistance</p>
                      <p className="text-sm text-green-600 font-mono mt-1">I = √(P / R)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Circuit Configurations</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Series Circuit</p>
                    <p className="font-mono mt-1">R_total = R₁ + R₂ + ... + Rₙ</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Parallel Circuit</p>
                    <p className="font-mono mt-1">1/R_total = 1/R₁ + 1/R₂ + ... + 1/Rₙ</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Current Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>LED</span>
                      <span className="font-mono">10-20 mA</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>USB Port</span>
                      <span className="font-mono">500 mA - 3 A</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Household Outlet</span>
                      <span className="font-mono">15-20 A</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Electric Vehicle</span>
                      <span className="font-mono">32-400 A</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Electric Current?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electric current is the rate of flow of electric charge through a conductor. It is measured in amperes
                  (A), where one ampere equals one coulomb of charge passing a point per second. Current flows from
                  higher potential (positive) to lower potential (negative) in conventional current notation, though
                  electrons actually flow in the opposite direction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding current is fundamental to electrical engineering and electronics. It helps in designing
                  circuits, selecting appropriate components, and ensuring safety. The relationship between current,
                  voltage, and resistance is described by Ohm's Law, one of the most important principles in electrical
                  science.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Ohm's Law</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ohm's Law states that the current through a conductor between two points is directly proportional to
                  the voltage across the two points and inversely proportional to the resistance. This relationship is
                  expressed as I = V/R, where I is current in amperes, V is voltage in volts, and R is resistance in
                  ohms.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This law forms the foundation for analyzing and designing electrical circuits. By knowing any two of
                  the three values (current, voltage, resistance), you can calculate the third. This is invaluable for
                  troubleshooting circuits, selecting components, and understanding how changes in one parameter affect
                  the others.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Current calculations are estimates based on ideal conditions. Actual circuit conditions may vary due
                  to temperature, wire resistance, or other factors. Consult a qualified electrician for precise
                  measurements. Always follow proper safety procedures when working with electrical circuits.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
