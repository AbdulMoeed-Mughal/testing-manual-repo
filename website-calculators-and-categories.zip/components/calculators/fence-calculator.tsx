"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Fence,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface FenceResult {
  totalPanels: number
  panelsWithWaste: number
  totalPosts: number
  fenceArea: number
  panelLength: number
  perimeter: number
}

export function FenceCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [perimeter, setPerimeter] = useState("")
  const [height, setHeight] = useState("")
  const [panelWidth, setPanelWidth] = useState("")
  const [postSpacing, setPostSpacing] = useState("")
  const [gates, setGates] = useState("")
  const [wastePercentage, setWastePercentage] = useState("5")
  const [result, setResult] = useState<FenceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const perimeterNum = Number.parseFloat(perimeter)
    const heightNum = Number.parseFloat(height)
    const panelWidthNum = Number.parseFloat(panelWidth)
    const postSpacingNum = Number.parseFloat(postSpacing) || panelWidthNum
    const gatesNum = Number.parseInt(gates) || 0
    const wasteNum = Number.parseFloat(wastePercentage) || 0

    if (isNaN(perimeterNum) || perimeterNum <= 0) {
      setError("Please enter a valid fence perimeter/length greater than 0")
      return
    }

    if (isNaN(heightNum) || heightNum <= 0) {
      setError("Please enter a valid fence height greater than 0")
      return
    }

    if (isNaN(panelWidthNum) || panelWidthNum <= 0) {
      setError("Please enter a valid panel width greater than 0")
      return
    }

    // Calculate number of panels
    let totalPanels = Math.ceil(perimeterNum / panelWidthNum)

    // Adjust for gates
    if (gatesNum > totalPanels) {
      setError("Number of gates cannot exceed total number of panels")
      return
    }
    totalPanels = totalPanels - gatesNum

    // Add waste percentage
    const panelsWithWaste = Math.ceil(totalPanels * (1 + wasteNum / 100))

    // Calculate posts (one more than panels, or based on spacing)
    const totalPosts = postSpacingNum ? Math.ceil(perimeterNum / postSpacingNum) + 1 : totalPanels + gatesNum + 1

    // Calculate fence area
    const fenceArea = perimeterNum * heightNum

    setResult({
      totalPanels,
      panelsWithWaste,
      totalPosts,
      fenceArea,
      panelLength: perimeterNum,
      perimeter: perimeterNum,
    })
  }

  const handleReset = () => {
    setPerimeter("")
    setHeight("")
    setPanelWidth("")
    setPostSpacing("")
    setGates("")
    setWastePercentage("5")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Fence Materials: ${result.panelsWithWaste} panels, ${result.totalPosts} posts, ${result.fenceArea.toFixed(2)} ${unitSystem === "metric" ? "m²" : "ft²"} area`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Fence Calculator Result",
          text: `Fence Materials: ${result.panelsWithWaste} panels, ${result.totalPosts} posts`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    handleReset()
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"
  const areaUnit = unitSystem === "metric" ? "m²" : "ft²"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Fence className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Fence Calculator</CardTitle>
                    <CardDescription>Calculate fencing materials needed</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Perimeter Input */}
                <div className="space-y-2">
                  <Label htmlFor="perimeter">Fence Perimeter / Total Length ({lengthUnit})</Label>
                  <Input
                    id="perimeter"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "30" : "100"}`}
                    value={perimeter}
                    onChange={(e) => setPerimeter(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                <div className="space-y-2">
                  <Label htmlFor="height">Fence Height ({lengthUnit})</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "1.8" : "6"}`}
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Panel Width Input */}
                <div className="space-y-2">
                  <Label htmlFor="panelWidth">Panel Width ({lengthUnit})</Label>
                  <Input
                    id="panelWidth"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "2.4" : "8"}`}
                    value={panelWidth}
                    onChange={(e) => setPanelWidth(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Post Spacing Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="postSpacing">
                    Post Spacing ({lengthUnit}) <span className="text-muted-foreground">(optional)</span>
                  </Label>
                  <Input
                    id="postSpacing"
                    type="number"
                    placeholder={`Default: same as panel width`}
                    value={postSpacing}
                    onChange={(e) => setPostSpacing(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Gates Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="gates">
                    Number of Gates <span className="text-muted-foreground">(optional)</span>
                  </Label>
                  <Input
                    id="gates"
                    type="number"
                    placeholder="e.g., 1"
                    value={gates}
                    onChange={(e) => setGates(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Waste Percentage Input */}
                <div className="space-y-2">
                  <Label htmlFor="waste">Waste Allowance (%)</Label>
                  <Input
                    id="waste"
                    type="number"
                    placeholder="5"
                    value={wastePercentage}
                    onChange={(e) => setWastePercentage(e.target.value)}
                    min="0"
                    max="50"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Materials
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Panels Needed</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">{result.panelsWithWaste}</p>
                      <p className="text-sm text-muted-foreground">
                        ({result.totalPanels} panels + {Number.parseFloat(wastePercentage) || 0}% waste)
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Posts</p>
                        <p className="text-xl font-bold text-foreground">{result.totalPosts}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Fence Area</p>
                        <p className="text-xl font-bold text-foreground">
                          {result.fenceArea.toFixed(2)} {areaUnit}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-Step Breakdown */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full flex items-center justify-between p-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <span>Step-by-step calculation</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-2 p-3 bg-white rounded-lg text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fence Perimeter:</span>
                          <span className="font-medium">
                            {perimeter} {lengthUnit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Panel Width:</span>
                          <span className="font-medium">
                            {panelWidth} {lengthUnit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Base Panels:</span>
                          <span className="font-medium">
                            ⌈{perimeter} ÷ {panelWidth}⌉ ={" "}
                            {Math.ceil(Number.parseFloat(perimeter) / Number.parseFloat(panelWidth))}
                          </span>
                        </div>
                        {Number.parseInt(gates) > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Minus Gates:</span>
                            <span className="font-medium">
                              {Math.ceil(Number.parseFloat(perimeter) / Number.parseFloat(panelWidth))} - {gates} ={" "}
                              {result.totalPanels}
                            </span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">With {wastePercentage}% Waste:</span>
                          <span className="font-medium">
                            {result.totalPanels} × {(1 + (Number.parseFloat(wastePercentage) || 0) / 100).toFixed(2)} ≈{" "}
                            {result.panelsWithWaste}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Posts Needed:</span>
                          <span className="font-medium">{result.totalPosts}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fence Area:</span>
                          <span className="font-medium">
                            {perimeter} × {height} = {result.fenceArea.toFixed(2)} {areaUnit}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas Used</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Number of Panels</p>
                    <p className="font-mono text-sm font-semibold">Panels = ⌈Perimeter ÷ Panel Width⌉ - Gates</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Panels with Waste</p>
                    <p className="font-mono text-sm font-semibold">Total = Panels × (1 + Waste%)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Number of Posts</p>
                    <p className="font-mono text-sm font-semibold">Posts = ⌈Perimeter ÷ Spacing⌉ + 1</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Fence Area</p>
                    <p className="font-mono text-sm font-semibold">Area = Perimeter × Height</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Fence Panel Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Standard Wood Panel</span>
                      <span className="font-medium">1.83m × 1.83m (6ft × 6ft)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Closeboard Panel</span>
                      <span className="font-medium">1.83m × 1.2m (6ft × 4ft)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Picket Fence</span>
                      <span className="font-medium">2.4m × 0.9m (8ft × 3ft)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Chain Link</span>
                      <span className="font-medium">3m × 1.2m (10ft × 4ft)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual fencing requirements may vary due to gate sizes, post placement,
                        terrain variations, and site conditions. Always consult a professional for final measurements.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Fence Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Proper planning is essential for any fencing project. Accurate material calculations help prevent
                  costly overruns and delays. This calculator determines the number of fence panels and posts needed
                  based on your total fence perimeter, panel dimensions, and accounts for gates and waste.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The perimeter measurement should include all sides where fencing is required. For irregularly shaped
                  areas, measure each straight section separately and add them together. Remember to account for any
                  gates or openings that won't need panels but will still require posts on either side.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Fence className="h-5 w-5 text-primary" />
                  <CardTitle>Key Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Panel Selection</h4>
                    <p className="text-sm text-muted-foreground">
                      Choose panel width based on material type and aesthetic preference. Standard wood panels are
                      typically 1.8m (6ft) wide, while metal panels may vary. Wider panels mean fewer posts but may be
                      harder to install on uneven ground.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Post Spacing</h4>
                    <p className="text-sm text-muted-foreground">
                      Posts are typically spaced to match panel width, but may need to be closer together for high-wind
                      areas or specific fence types. Corner posts and gate posts should be set deeper and may need to be
                      larger diameter for added strength.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Waste Allowance</h4>
                    <p className="text-sm text-muted-foreground">
                      A 5-10% waste allowance accounts for cutting, damage during installation, and any measurement
                      discrepancies. For DIY projects or complex layouts with many corners, consider using the higher
                      end of this range.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Gates Planning</h4>
                    <p className="text-sm text-muted-foreground">
                      Gates reduce the number of panels needed but require additional hardware. Standard pedestrian
                      gates are typically 0.9-1.2m (3-4ft) wide, while driveway gates can be 3-4m (10-13ft) or more.
                      Always allow extra clearance for swing.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="space-y-2 text-muted-foreground">
                  <li>
                    <strong>Measure twice:</strong> Always double-check your perimeter measurements before ordering
                    materials.
                  </li>
                  <li>
                    <strong>Check property lines:</strong> Verify boundary lines with neighbors and local regulations
                    before installation.
                  </li>
                  <li>
                    <strong>Account for terrain:</strong> Sloped ground may require stepped panels or racked (angled)
                    installation.
                  </li>
                  <li>
                    <strong>Post depth:</strong> Posts should be set 1/3 of their length in concrete for stability.
                  </li>
                  <li>
                    <strong>Local codes:</strong> Check local building codes for height restrictions and setback
                    requirements.
                  </li>
                  <li>
                    <strong>Underground utilities:</strong> Call utility locating services before digging post holes.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
