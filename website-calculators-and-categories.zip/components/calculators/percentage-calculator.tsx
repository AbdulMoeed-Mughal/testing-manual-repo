"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Percent,
  Info,
  AlertTriangle,
  Calculator,
  TrendingUp,
  TrendingDown,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationType = "percentage-of" | "what-percent" | "increase-decrease"

interface Result {
  value: number
  label: string
  description: string
  color: string
  bgColor: string
  absoluteChange?: number
  isIncrease?: boolean
}

export function PercentageCalculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>("percentage-of")
  const [baseValue, setBaseValue] = useState("")
  const [percentageValue, setPercentageValue] = useState("")
  const [comparisonValue, setComparisonValue] = useState("")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    if (calculationType === "percentage-of") {
      const base = Number.parseFloat(baseValue)
      const percent = Number.parseFloat(percentageValue)

      if (isNaN(base) || isNaN(percent)) {
        setError("Please enter valid numbers for both fields")
        return
      }

      const resultValue = base * (percent / 100)
      setResult({
        value: Math.round(resultValue * 10000) / 10000,
        label: `${percent}% of ${base}`,
        description: `${percent}% of ${base} is ${Math.round(resultValue * 10000) / 10000}`,
        color: "text-blue-600",
        bgColor: "bg-blue-50 border-blue-200",
      })
    } else if (calculationType === "what-percent") {
      const part = Number.parseFloat(baseValue)
      const whole = Number.parseFloat(comparisonValue)

      if (isNaN(part) || isNaN(whole)) {
        setError("Please enter valid numbers for both fields")
        return
      }

      if (whole === 0) {
        setError("The whole value cannot be zero")
        return
      }

      const resultValue = (part / whole) * 100
      setResult({
        value: Math.round(resultValue * 100) / 100,
        label: `${Math.round(resultValue * 100) / 100}%`,
        description: `${part} is ${Math.round(resultValue * 100) / 100}% of ${whole}`,
        color: "text-purple-600",
        bgColor: "bg-purple-50 border-purple-200",
      })
    } else if (calculationType === "increase-decrease") {
      const oldValue = Number.parseFloat(baseValue)
      const newValue = Number.parseFloat(comparisonValue)

      if (isNaN(oldValue) || isNaN(newValue)) {
        setError("Please enter valid numbers for both fields")
        return
      }

      if (oldValue === 0) {
        setError("The original value cannot be zero")
        return
      }

      const change = newValue - oldValue
      const percentChange = (change / Math.abs(oldValue)) * 100
      const isIncrease = change >= 0

      setResult({
        value: Math.round(Math.abs(percentChange) * 100) / 100,
        label: `${isIncrease ? "+" : "-"}${Math.round(Math.abs(percentChange) * 100) / 100}%`,
        description: `${isIncrease ? "Increase" : "Decrease"} of ${Math.round(Math.abs(percentChange) * 100) / 100}% from ${oldValue} to ${newValue}`,
        color: isIncrease ? "text-green-600" : "text-red-600",
        bgColor: isIncrease ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200",
        absoluteChange: Math.round(Math.abs(change) * 10000) / 10000,
        isIncrease,
      })
    }
  }

  const handleReset = () => {
    setBaseValue("")
    setPercentageValue("")
    setComparisonValue("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(result.description)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Percentage Calculation",
          text: `I calculated: ${result.description}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const handleTypeChange = (type: CalculationType) => {
    setCalculationType(type)
    setBaseValue("")
    setPercentageValue("")
    setComparisonValue("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Percent className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Percentage Calculator</CardTitle>
                    <CardDescription>Calculate percentages easily</CardDescription>
                  </div>
                </div>

                {/* Calculation Type Toggle */}
                <div className="pt-2">
                  <span className="text-sm font-medium mb-2 block">Calculation Type</span>
                  <div className="grid grid-cols-1 gap-2">
                    <button
                      onClick={() => handleTypeChange("percentage-of")}
                      className={`p-3 rounded-lg border-2 text-left transition-all ${
                        calculationType === "percentage-of"
                          ? "border-blue-500 bg-blue-50 text-blue-700"
                          : "border-muted bg-background hover:border-muted-foreground/30"
                      }`}
                    >
                      <span className="font-medium text-sm">Find % of a number</span>
                      <span className="text-xs block text-muted-foreground">What is X% of Y?</span>
                    </button>
                    <button
                      onClick={() => handleTypeChange("what-percent")}
                      className={`p-3 rounded-lg border-2 text-left transition-all ${
                        calculationType === "what-percent"
                          ? "border-purple-500 bg-purple-50 text-purple-700"
                          : "border-muted bg-background hover:border-muted-foreground/30"
                      }`}
                    >
                      <span className="font-medium text-sm">Find what % one is of another</span>
                      <span className="text-xs block text-muted-foreground">X is what % of Y?</span>
                    </button>
                    <button
                      onClick={() => handleTypeChange("increase-decrease")}
                      className={`p-3 rounded-lg border-2 text-left transition-all ${
                        calculationType === "increase-decrease"
                          ? "border-green-500 bg-green-50 text-green-700"
                          : "border-muted bg-background hover:border-muted-foreground/30"
                      }`}
                    >
                      <span className="font-medium text-sm">Calculate % increase/decrease</span>
                      <span className="text-xs block text-muted-foreground">% change from X to Y</span>
                    </button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Dynamic Inputs based on calculation type */}
                {calculationType === "percentage-of" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="baseValue">Base Number</Label>
                      <Input
                        id="baseValue"
                        type="number"
                        placeholder="Enter the base number"
                        value={baseValue}
                        onChange={(e) => setBaseValue(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="percentageValue">Percentage (%)</Label>
                      <Input
                        id="percentageValue"
                        type="number"
                        placeholder="Enter the percentage"
                        value={percentageValue}
                        onChange={(e) => setPercentageValue(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {calculationType === "what-percent" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="baseValue">Part (Numerator)</Label>
                      <Input
                        id="baseValue"
                        type="number"
                        placeholder="Enter the part value"
                        value={baseValue}
                        onChange={(e) => setBaseValue(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="comparisonValue">Whole (Denominator)</Label>
                      <Input
                        id="comparisonValue"
                        type="number"
                        placeholder="Enter the whole value"
                        value={comparisonValue}
                        onChange={(e) => setComparisonValue(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {calculationType === "increase-decrease" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="baseValue">Original Value</Label>
                      <Input
                        id="baseValue"
                        type="number"
                        placeholder="Enter the original value"
                        value={baseValue}
                        onChange={(e) => setBaseValue(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="comparisonValue">New Value</Label>
                      <Input
                        id="comparisonValue"
                        type="number"
                        placeholder="Enter the new value"
                        value={comparisonValue}
                        onChange={(e) => setComparisonValue(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>
                        {calculationType === "percentage-of" ? result.value : result.label}
                      </p>
                      <p className="text-sm text-muted-foreground">{result.description}</p>
                      {result.absoluteChange !== undefined && (
                        <p className="text-sm mt-2 flex items-center justify-center gap-1">
                          {result.isIncrease ? (
                            <TrendingUp className="h-4 w-4 text-green-600" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-red-600" />
                          )}
                          <span className={result.isIncrease ? "text-green-600" : "text-red-600"}>
                            Absolute change: {result.absoluteChange}
                          </span>
                        </p>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas Used</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700 text-sm">Percentage of a Number</span>
                      <p className="text-xs text-blue-600 font-mono mt-1">Result = Base × (Percentage ÷ 100)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700 text-sm">What Percent</span>
                      <p className="text-xs text-purple-600 font-mono mt-1">Result (%) = (Part ÷ Whole) × 100</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700 text-sm">Percentage Change</span>
                      <p className="text-xs text-green-600 font-mono mt-1">Change (%) = ((New - Old) ÷ |Old|) × 100</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">20% of 150 = 30</p>
                    <p className="text-xs">150 × (20 ÷ 100) = 30</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">30 is 25% of 120</p>
                    <p className="text-xs">(30 ÷ 120) × 100 = 25%</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">50 to 75 = +50% increase</p>
                    <p className="text-xs">((75 - 50) ÷ 50) × 100 = 50%</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Disclaimer</p>
                      <p className="text-sm text-amber-700 mt-1">
                        This calculator provides estimates only. Use actual values for financial or official
                        calculations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Percentages?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A percentage is a mathematical way of expressing a number as a fraction of 100. The word "percent"
                  comes from the Latin "per centum," meaning "by the hundred." Percentages are one of the most commonly
                  used mathematical concepts in everyday life, appearing in contexts ranging from shopping discounts and
                  tax rates to exam scores and statistical data. Understanding how to work with percentages is an
                  essential skill that helps us compare quantities, analyze changes, and make informed decisions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of percentages provides a standardized way to compare different quantities by expressing
                  them on a common scale of 100. For example, saying "25%" is equivalent to saying "25 out of 100" or
                  "one quarter." This standardization makes it easy to compare values that might otherwise be difficult
                  to relate, such as comparing test scores from exams with different total points or understanding
                  interest rates on various financial products.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Percentage Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  There are three fundamental types of percentage calculations that cover most practical applications.
                  The first type involves finding a percentage of a given number, such as calculating a 15% tip on a
                  restaurant bill or determining the sale price when an item is discounted by 30%. This calculation
                  multiplies the base number by the percentage expressed as a decimal (percentage divided by 100).
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Finding a Percentage of a Number</h4>
                    <p className="text-blue-700 text-sm">
                      This is perhaps the most common percentage calculation. When you want to find 20% of 150, you
                      multiply 150 by 0.20 (which is 20 ÷ 100) to get 30. This type of calculation is used for computing
                      tips, discounts, taxes, commissions, and many other real-world applications where you need to find
                      a portion of a whole.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">
                      Finding What Percentage One Number is of Another
                    </h4>
                    <p className="text-purple-700 text-sm">
                      This calculation determines the ratio between two numbers expressed as a percentage. For instance,
                      if you scored 45 points out of 60 on a test, you would divide 45 by 60 and multiply by 100 to find
                      that you scored 75%. This is useful for calculating grades, success rates, conversion rates, and
                      proportional comparisons.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Calculating Percentage Change</h4>
                    <p className="text-green-700 text-sm">
                      Percentage change measures how much a value has increased or decreased relative to its original
                      amount. If a stock price rises from $50 to $65, the percentage increase is ((65-50) ÷ 50) × 100 =
                      30%. This calculation is essential for tracking growth, analyzing trends, comparing performance
                      over time, and understanding relative changes in any measurable quantity.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications of Percentages</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Percentages are ubiquitous in daily life and professional contexts. In finance, interest rates,
                  investment returns, and loan APRs are all expressed as percentages. Retailers use percentages for
                  discounts and markups. Nutritional information shows daily value percentages. Statistics use
                  percentages to express probabilities, survey results, and demographic data. Understanding percentage
                  calculations empowers you to make better financial decisions, interpret data accurately, and
                  communicate numerical information clearly.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In business, percentages are crucial for calculating profit margins, market share, growth rates, and
                  employee performance metrics. Scientists and researchers use percentages to report experimental
                  results, error margins, and confidence intervals. Even in sports, percentages like batting averages,
                  shooting percentages, and win rates help evaluate player and team performance. The ability to quickly
                  and accurately calculate percentages is a fundamental skill that applies across virtually every field
                  and aspect of life.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Common Mistakes and Tips</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  One common mistake is confusing percentage points with percentages. If an interest rate increases from
                  5% to 7%, it has increased by 2 percentage points, but the percentage increase is actually 40%
                  (because 2 is 40% of 5). Another frequent error is adding or subtracting percentages directly when
                  they have different bases. For example, a 50% increase followed by a 50% decrease does not return to
                  the original value - it actually results in 75% of the original (100 × 1.5 × 0.5 = 75).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When calculating percentage change, always use the original value as the base. For percentage
                  increase, the formula is ((New - Original) ÷ Original) × 100. Some people mistakenly use the new value
                  as the denominator, which gives incorrect results. Additionally, remember that percentages can exceed
                  100% - a 200% increase means the new value is three times the original. Being aware of these nuances
                  helps avoid errors and misinterpretations when working with percentages.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
