"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, Clock } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface AgeResult {
  years: number
  months: number
  days: number
  totalDays: number
  totalMonths: number
}

export function ChronologicalAgeCalculator() {
  const [birthDate, setBirthDate] = useState("")
  const [currentDate, setCurrentDate] = useState(new Date().toISOString().split("T")[0])
  const [result, setResult] = useState<AgeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateAge = () => {
    setError("")
    setResult(null)

    if (!birthDate) {
      setError("Please enter a date of birth")
      return
    }

    const birth = new Date(birthDate)
    const current = new Date(currentDate)

    if (isNaN(birth.getTime())) {
      setError("Invalid date of birth")
      return
    }

    if (birth > current) {
      setError("Date of birth cannot be in the future")
      return
    }

    // Calculate age
    let years = current.getFullYear() - birth.getFullYear()
    let months = current.getMonth() - birth.getMonth()
    let days = current.getDate() - birth.getDate()

    if (days < 0) {
      months--
      const prevMonth = new Date(current.getFullYear(), current.getMonth(), 0)
      days += prevMonth.getDate()
    }

    if (months < 0) {
      years--
      months += 12
    }

    // Calculate total days
    const timeDiff = current.getTime() - birth.getTime()
    const totalDays = Math.floor(timeDiff / (1000 * 60 * 60 * 24))

    // Calculate total months
    const totalMonths = years * 12 + months

    setResult({
      years,
      months,
      days,
      totalDays,
      totalMonths,
    })
  }

  const handleReset = () => {
    setBirthDate("")
    setCurrentDate(new Date().toISOString().split("T")[0])
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Age: ${result.years} years, ${result.months} months, ${result.days} days (Total: ${result.totalDays} days)`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Chronological Age",
          text: `Calculated chronological age: ${result.years} years, ${result.months} months, ${result.days} days`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Chronological Age Calculator</CardTitle>
                    <CardDescription>Calculate exact age from date of birth</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="birthDate">Date of Birth</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currentDate">Calculate Age On</Label>
                  <Input
                    id="currentDate"
                    type="date"
                    value={currentDate}
                    onChange={(e) => setCurrentDate(e.target.value)}
                    max="2100-12-31"
                  />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateAge} className="w-full" size="lg">
                  Calculate Age
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-2">Chronological Age</p>
                      <div className="flex items-center justify-center gap-2 flex-wrap">
                        <div className="text-center">
                          <p className="text-4xl font-bold text-cyan-600">{result.years}</p>
                          <p className="text-sm text-cyan-600">years</p>
                        </div>
                        <span className="text-2xl text-cyan-600">·</span>
                        <div className="text-center">
                          <p className="text-4xl font-bold text-cyan-600">{result.months}</p>
                          <p className="text-sm text-cyan-600">months</p>
                        </div>
                        <span className="text-2xl text-cyan-600">·</span>
                        <div className="text-center">
                          <p className="text-4xl font-bold text-cyan-600">{result.days}</p>
                          <p className="text-sm text-cyan-600">days</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 pt-3 border-t border-cyan-200">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Total Months:</span>
                        <span className="font-medium text-cyan-700">{result.totalMonths} months</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Total Days:</span>
                        <span className="font-medium text-cyan-700">{result.totalDays.toLocaleString()} days</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Age Components</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-700 mb-1">Years</p>
                    <p className="text-sm text-cyan-600">Complete years between dates</p>
                  </div>
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-700 mb-1">Months</p>
                    <p className="text-sm text-cyan-600">Remaining months after full years</p>
                  </div>
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-700 mb-1">Days</p>
                    <p className="text-sm text-cyan-600">Remaining days after full months</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Facts</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Age is calculated based on calendar dates</p>
                  <p>• Accounts for leap years automatically</p>
                  <p>• Total days include all days lived</p>
                  <p>• Useful for legal age verification</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Chronological Age?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Chronological age is the measure of time that has passed since a person's birth until a specific date,
                  typically the current date. It is the most common and straightforward way to measure age, expressed in
                  years, months, and days. Unlike biological age or developmental age, chronological age is purely based
                  on calendar time and provides a universal standard for tracking the passage of time in a person's life.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This measurement is fundamental in many aspects of life, from determining legal rights and
                  responsibilities to calculating insurance premiums, retirement benefits, and educational placement. It
                  serves as a baseline for comparing individuals across populations and is essential for demographic
                  studies, medical research, and social planning.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>How is Chronological Age Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Chronological age is calculated by determining the difference between the date of birth and the current
                  date (or any specified date). The calculation takes into account years, months, and days, adjusting for
                  the varying lengths of months and leap years. For example, if someone was born on March 15, 1990, and
                  today is October 20, 2024, their age would be calculated by first finding the complete years (34),
                  then the remaining months (7), and finally the remaining days (5).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The calculation must properly handle edge cases such as leap years, where February has 29 days instead
                  of 28, and months with different numbers of days. This ensures accuracy regardless of when in the year
                  someone was born. Modern calculators automatically account for these complexities, providing precise
                  age measurements down to the day.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Common Uses of Chronological Age</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Chronological age serves numerous practical purposes in daily life and professional contexts. In legal
                  matters, it determines eligibility for driving licenses, voting rights, marriage, alcohol consumption,
                  and retirement benefits. Educational systems use chronological age to determine grade placement and
                  school readiness. Healthcare providers rely on chronological age to assess developmental milestones,
                  determine appropriate medical treatments, and calculate medication dosages.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In the business world, chronological age impacts employment decisions, insurance premiums, and
                  financial planning. It's also crucial for demographic research, helping governments and organizations
                  understand population trends, plan for services, and allocate resources. Sports organizations use age
                  to determine competition categories, ensuring fair play among participants of similar maturity levels.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <div className="mt-8 p-4 bg-muted rounded-lg border">
            <p className="text-sm text-muted-foreground text-center">
              <strong>Note:</strong> Chronological age calculations are based on entered dates and may vary slightly due
              to leap years and calendar differences. For legal or official purposes, always verify age calculations with
              relevant authorities.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
