"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Flame,
  Info,
  AlertTriangle,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
  Thermometer,
  Zap,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "bond" | "formation"

interface BondEntry {
  id: string
  name: string
  energy: string
  count: string
}

interface SubstanceEntry {
  id: string
  name: string
  moles: string
  enthalpy: string
}

interface ThermochemistryResult {
  deltaH: number
  reactionType: "exothermic" | "endothermic" | "neutral"
  steps: string[]
}

// Common bond energies (kJ/mol)
const commonBondEnergies: { [key: string]: number } = {
  "C-H": 413,
  "C-C": 347,
  "C=C": 614,
  "C≡C": 839,
  "C-O": 358,
  "C=O": 799,
  "C-N": 305,
  "C=N": 615,
  "C≡N": 891,
  "C-Cl": 339,
  "C-Br": 276,
  "O-H": 463,
  "O-O": 146,
  "O=O": 495,
  "N-H": 391,
  "N-N": 163,
  "N=N": 418,
  "N≡N": 941,
  "H-H": 436,
  "H-Cl": 431,
  "H-Br": 366,
  "H-F": 567,
  "Cl-Cl": 242,
  "Br-Br": 193,
  "F-F": 155,
  "S-H": 363,
  "S=O": 523,
}

// Common standard enthalpies of formation (kJ/mol)
const commonEnthalpies: { [key: string]: number } = {
  "H₂O(l)": -285.8,
  "H₂O(g)": -241.8,
  "CO₂(g)": -393.5,
  "CO(g)": -110.5,
  "CH₄(g)": -74.8,
  "C₂H₆(g)": -84.7,
  "C₂H₄(g)": 52.3,
  "C₂H₂(g)": 226.7,
  "NH₃(g)": -45.9,
  "NO(g)": 90.3,
  "NO₂(g)": 33.2,
  "N₂O(g)": 82.1,
  "SO₂(g)": -296.8,
  "SO₃(g)": -395.7,
  "HCl(g)": -92.3,
  "HBr(g)": -36.4,
  "HF(g)": -271.1,
  "NaCl(s)": -411.2,
  "CaCO₃(s)": -1206.9,
  "Fe₂O₃(s)": -824.2,
  "Al₂O₃(s)": -1675.7,
  "C₆H₁₂O₆(s)": -1273.3,
  "C₂H₅OH(l)": -277.7,
  "CH₃OH(l)": -238.7,
}

export function ThermochemistryCalculator() {
  const [mode, setMode] = useState<CalculationMode>("bond")
  const [bondsBroken, setBondsBroken] = useState<BondEntry[]>([{ id: "1", name: "", energy: "", count: "1" }])
  const [bondsFormed, setBondsFormed] = useState<BondEntry[]>([{ id: "1", name: "", energy: "", count: "1" }])
  const [reactants, setReactants] = useState<SubstanceEntry[]>([{ id: "1", name: "", moles: "1", enthalpy: "" }])
  const [products, setProducts] = useState<SubstanceEntry[]>([{ id: "1", name: "", moles: "1", enthalpy: "" }])
  const [result, setResult] = useState<ThermochemistryResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const generateId = () => Math.random().toString(36).substring(2, 9)

  const addBondEntry = (type: "broken" | "formed") => {
    const newEntry: BondEntry = { id: generateId(), name: "", energy: "", count: "1" }
    if (type === "broken") {
      setBondsBroken([...bondsBroken, newEntry])
    } else {
      setBondsFormed([...bondsFormed, newEntry])
    }
  }

  const removeBondEntry = (type: "broken" | "formed", id: string) => {
    if (type === "broken") {
      if (bondsBroken.length > 1) {
        setBondsBroken(bondsBroken.filter((b) => b.id !== id))
      }
    } else {
      if (bondsFormed.length > 1) {
        setBondsFormed(bondsFormed.filter((b) => b.id !== id))
      }
    }
  }

  const updateBondEntry = (type: "broken" | "formed", id: string, field: keyof BondEntry, value: string) => {
    const updateFn = (entries: BondEntry[]) =>
      entries.map((e) => {
        if (e.id === id) {
          const updated = { ...e, [field]: value }
          // Auto-fill energy if a common bond is selected
          if (field === "name" && commonBondEnergies[value]) {
            updated.energy = commonBondEnergies[value].toString()
          }
          return updated
        }
        return e
      })

    if (type === "broken") {
      setBondsBroken(updateFn(bondsBroken))
    } else {
      setBondsFormed(updateFn(bondsFormed))
    }
  }

  const addSubstanceEntry = (type: "reactant" | "product") => {
    const newEntry: SubstanceEntry = { id: generateId(), name: "", moles: "1", enthalpy: "" }
    if (type === "reactant") {
      setReactants([...reactants, newEntry])
    } else {
      setProducts([...products, newEntry])
    }
  }

  const removeSubstanceEntry = (type: "reactant" | "product", id: string) => {
    if (type === "reactant") {
      if (reactants.length > 1) {
        setReactants(reactants.filter((r) => r.id !== id))
      }
    } else {
      if (products.length > 1) {
        setProducts(products.filter((p) => p.id !== id))
      }
    }
  }

  const updateSubstanceEntry = (
    type: "reactant" | "product",
    id: string,
    field: keyof SubstanceEntry,
    value: string,
  ) => {
    const updateFn = (entries: SubstanceEntry[]) =>
      entries.map((e) => {
        if (e.id === id) {
          const updated = { ...e, [field]: value }
          // Auto-fill enthalpy if a common substance is selected
          if (field === "name" && commonEnthalpies[value]) {
            updated.enthalpy = commonEnthalpies[value].toString()
          }
          return updated
        }
        return e
      })

    if (type === "reactant") {
      setReactants(updateFn(reactants))
    } else {
      setProducts(updateFn(products))
    }
  }

  const calculateDeltaH = () => {
    setError("")
    setResult(null)

    const steps: string[] = []

    if (mode === "bond") {
      // Validate bond entries
      const validBroken = bondsBroken.filter((b) => b.energy && b.count)
      const validFormed = bondsFormed.filter((b) => b.energy && b.count)

      if (validBroken.length === 0 && validFormed.length === 0) {
        setError("Please enter at least one bond broken or formed")
        return
      }

      // Calculate sum of bonds broken
      let sumBroken = 0
      steps.push("Step 1: Calculate energy of bonds broken (endothermic)")
      validBroken.forEach((b) => {
        const energy = Number.parseFloat(b.energy)
        const count = Number.parseFloat(b.count) || 1
        if (!isNaN(energy)) {
          const contribution = energy * count
          sumBroken += contribution
          steps.push(`  ${b.name || "Bond"}: ${count} × ${energy} kJ/mol = +${contribution.toFixed(1)} kJ`)
        }
      })
      steps.push(`  Total bonds broken = +${sumBroken.toFixed(1)} kJ`)

      // Calculate sum of bonds formed
      let sumFormed = 0
      steps.push("")
      steps.push("Step 2: Calculate energy of bonds formed (exothermic)")
      validFormed.forEach((b) => {
        const energy = Number.parseFloat(b.energy)
        const count = Number.parseFloat(b.count) || 1
        if (!isNaN(energy)) {
          const contribution = energy * count
          sumFormed += contribution
          steps.push(`  ${b.name || "Bond"}: ${count} × ${energy} kJ/mol = -${contribution.toFixed(1)} kJ`)
        }
      })
      steps.push(`  Total bonds formed = -${sumFormed.toFixed(1)} kJ`)

      // Calculate ΔH
      const deltaH = sumBroken - sumFormed
      steps.push("")
      steps.push("Step 3: Calculate ΔH")
      steps.push(`  ΔH = Σ(Bonds broken) - Σ(Bonds formed)`)
      steps.push(`  ΔH = ${sumBroken.toFixed(1)} - ${sumFormed.toFixed(1)}`)
      steps.push(`  ΔH = ${deltaH > 0 ? "+" : ""}${deltaH.toFixed(1)} kJ`)

      const reactionType = deltaH < 0 ? "exothermic" : deltaH > 0 ? "endothermic" : "neutral"
      setResult({ deltaH, reactionType, steps })
    } else {
      // Formation enthalpy mode
      const validReactants = reactants.filter((r) => r.enthalpy && r.moles)
      const validProducts = products.filter((p) => p.enthalpy && p.moles)

      if (validReactants.length === 0 && validProducts.length === 0) {
        setError("Please enter at least one reactant or product")
        return
      }

      // Calculate sum of reactants
      let sumReactants = 0
      steps.push("Step 1: Calculate Σ(ΔHf° × moles) for reactants")
      validReactants.forEach((r) => {
        const enthalpy = Number.parseFloat(r.enthalpy)
        const moles = Number.parseFloat(r.moles) || 1
        if (!isNaN(enthalpy)) {
          const contribution = enthalpy * moles
          sumReactants += contribution
          steps.push(
            `  ${r.name || "Reactant"}: ${moles} mol × ${enthalpy} kJ/mol = ${contribution > 0 ? "+" : ""}${contribution.toFixed(1)} kJ`,
          )
        }
      })
      steps.push(`  Σ(Reactants) = ${sumReactants > 0 ? "+" : ""}${sumReactants.toFixed(1)} kJ`)

      // Calculate sum of products
      let sumProducts = 0
      steps.push("")
      steps.push("Step 2: Calculate Σ(ΔHf° × moles) for products")
      validProducts.forEach((p) => {
        const enthalpy = Number.parseFloat(p.enthalpy)
        const moles = Number.parseFloat(p.moles) || 1
        if (!isNaN(enthalpy)) {
          const contribution = enthalpy * moles
          sumProducts += contribution
          steps.push(
            `  ${p.name || "Product"}: ${moles} mol × ${enthalpy} kJ/mol = ${contribution > 0 ? "+" : ""}${contribution.toFixed(1)} kJ`,
          )
        }
      })
      steps.push(`  Σ(Products) = ${sumProducts > 0 ? "+" : ""}${sumProducts.toFixed(1)} kJ`)

      // Calculate ΔH
      const deltaH = sumProducts - sumReactants
      steps.push("")
      steps.push("Step 3: Calculate ΔH using Hess's Law")
      steps.push(`  ΔH = Σ(ΔHf° products) - Σ(ΔHf° reactants)`)
      steps.push(`  ΔH = (${sumProducts.toFixed(1)}) - (${sumReactants.toFixed(1)})`)
      steps.push(`  ΔH = ${deltaH > 0 ? "+" : ""}${deltaH.toFixed(1)} kJ`)

      const reactionType = deltaH < 0 ? "exothermic" : deltaH > 0 ? "endothermic" : "neutral"
      setResult({ deltaH, reactionType, steps })
    }
  }

  const handleReset = () => {
    setBondsBroken([{ id: "1", name: "", energy: "", count: "1" }])
    setBondsFormed([{ id: "1", name: "", energy: "", count: "1" }])
    setReactants([{ id: "1", name: "", moles: "1", enthalpy: "" }])
    setProducts([{ id: "1", name: "", moles: "1", enthalpy: "" }])
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `ΔH = ${result.deltaH > 0 ? "+" : ""}${result.deltaH.toFixed(1)} kJ (${result.reactionType})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Thermochemistry Calculation",
          text: `I calculated ΔH using CalcHub! ΔH = ${result.deltaH > 0 ? "+" : ""}${result.deltaH.toFixed(1)} kJ (${result.reactionType})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getResultColor = () => {
    if (!result) return ""
    if (result.reactionType === "exothermic") return "text-blue-600"
    if (result.reactionType === "endothermic") return "text-red-600"
    return "text-gray-600"
  }

  const getResultBg = () => {
    if (!result) return ""
    if (result.reactionType === "exothermic") return "bg-blue-50 border-blue-200"
    if (result.reactionType === "endothermic") return "bg-red-50 border-red-200"
    return "bg-gray-50 border-gray-200"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Thermochemistry Calculator</CardTitle>
                    <CardDescription>Calculate enthalpy change (ΔH)</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Method</span>
                  <button
                    onClick={() => {
                      setMode(mode === "bond" ? "formation" : "bond")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "formation" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "bond" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Bond Energy
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "formation" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      ΔHf°
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {mode === "bond" ? (
                  <>
                    {/* Bonds Broken */}
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <span className="text-red-500">↑</span> Bonds Broken (Energy absorbed)
                      </Label>
                      <div className="space-y-2">
                        {bondsBroken.map((bond) => (
                          <div key={bond.id} className="flex gap-2 items-center">
                            <Select
                              value={bond.name}
                              onValueChange={(v) => updateBondEntry("broken", bond.id, "name", v)}
                            >
                              <SelectTrigger className="w-24">
                                <SelectValue placeholder="Bond" />
                              </SelectTrigger>
                              <SelectContent>
                                {Object.keys(commonBondEnergies).map((b) => (
                                  <SelectItem key={b} value={b}>
                                    {b}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Input
                              type="number"
                              placeholder="Energy"
                              value={bond.energy}
                              onChange={(e) => updateBondEntry("broken", bond.id, "energy", e.target.value)}
                              className="flex-1"
                            />
                            <span className="text-xs text-muted-foreground whitespace-nowrap">kJ/mol</span>
                            <Input
                              type="number"
                              placeholder="×"
                              value={bond.count}
                              onChange={(e) => updateBondEntry("broken", bond.id, "count", e.target.value)}
                              className="w-16"
                              min="1"
                            />
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeBondEntry("broken", bond.id)}
                              disabled={bondsBroken.length === 1}
                              className="shrink-0"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                        <Button variant="outline" size="sm" onClick={() => addBondEntry("broken")} className="w-full">
                          <Plus className="h-4 w-4 mr-1" /> Add Bond
                        </Button>
                      </div>
                    </div>

                    {/* Bonds Formed */}
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <span className="text-blue-500">↓</span> Bonds Formed (Energy released)
                      </Label>
                      <div className="space-y-2">
                        {bondsFormed.map((bond) => (
                          <div key={bond.id} className="flex gap-2 items-center">
                            <Select
                              value={bond.name}
                              onValueChange={(v) => updateBondEntry("formed", bond.id, "name", v)}
                            >
                              <SelectTrigger className="w-24">
                                <SelectValue placeholder="Bond" />
                              </SelectTrigger>
                              <SelectContent>
                                {Object.keys(commonBondEnergies).map((b) => (
                                  <SelectItem key={b} value={b}>
                                    {b}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Input
                              type="number"
                              placeholder="Energy"
                              value={bond.energy}
                              onChange={(e) => updateBondEntry("formed", bond.id, "energy", e.target.value)}
                              className="flex-1"
                            />
                            <span className="text-xs text-muted-foreground whitespace-nowrap">kJ/mol</span>
                            <Input
                              type="number"
                              placeholder="×"
                              value={bond.count}
                              onChange={(e) => updateBondEntry("formed", bond.id, "count", e.target.value)}
                              className="w-16"
                              min="1"
                            />
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeBondEntry("formed", bond.id)}
                              disabled={bondsFormed.length === 1}
                              className="shrink-0"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                        <Button variant="outline" size="sm" onClick={() => addBondEntry("formed")} className="w-full">
                          <Plus className="h-4 w-4 mr-1" /> Add Bond
                        </Button>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Reactants */}
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">Reactants (ΔHf° values)</Label>
                      <div className="space-y-2">
                        {reactants.map((r) => (
                          <div key={r.id} className="flex gap-2 items-center">
                            <Select
                              value={r.name}
                              onValueChange={(v) => updateSubstanceEntry("reactant", r.id, "name", v)}
                            >
                              <SelectTrigger className="w-28">
                                <SelectValue placeholder="Substance" />
                              </SelectTrigger>
                              <SelectContent>
                                {Object.keys(commonEnthalpies).map((s) => (
                                  <SelectItem key={s} value={s}>
                                    {s}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Input
                              type="number"
                              placeholder="Moles"
                              value={r.moles}
                              onChange={(e) => updateSubstanceEntry("reactant", r.id, "moles", e.target.value)}
                              className="w-20"
                              min="0"
                              step="0.1"
                            />
                            <Input
                              type="number"
                              placeholder="ΔHf°"
                              value={r.enthalpy}
                              onChange={(e) => updateSubstanceEntry("reactant", r.id, "enthalpy", e.target.value)}
                              className="flex-1"
                            />
                            <span className="text-xs text-muted-foreground whitespace-nowrap">kJ/mol</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeSubstanceEntry("reactant", r.id)}
                              disabled={reactants.length === 1}
                              className="shrink-0"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => addSubstanceEntry("reactant")}
                          className="w-full"
                        >
                          <Plus className="h-4 w-4 mr-1" /> Add Reactant
                        </Button>
                      </div>
                    </div>

                    {/* Products */}
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">Products (ΔHf° values)</Label>
                      <div className="space-y-2">
                        {products.map((p) => (
                          <div key={p.id} className="flex gap-2 items-center">
                            <Select
                              value={p.name}
                              onValueChange={(v) => updateSubstanceEntry("product", p.id, "name", v)}
                            >
                              <SelectTrigger className="w-28">
                                <SelectValue placeholder="Substance" />
                              </SelectTrigger>
                              <SelectContent>
                                {Object.keys(commonEnthalpies).map((s) => (
                                  <SelectItem key={s} value={s}>
                                    {s}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Input
                              type="number"
                              placeholder="Moles"
                              value={p.moles}
                              onChange={(e) => updateSubstanceEntry("product", p.id, "moles", e.target.value)}
                              className="w-20"
                              min="0"
                              step="0.1"
                            />
                            <Input
                              type="number"
                              placeholder="ΔHf°"
                              value={p.enthalpy}
                              onChange={(e) => updateSubstanceEntry("product", p.id, "enthalpy", e.target.value)}
                              className="flex-1"
                            />
                            <span className="text-xs text-muted-foreground whitespace-nowrap">kJ/mol</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeSubstanceEntry("product", p.id)}
                              disabled={products.length === 1}
                              className="shrink-0"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => addSubstanceEntry("product")}
                          className="w-full"
                        >
                          <Plus className="h-4 w-4 mr-1" /> Add Product
                        </Button>
                      </div>
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDeltaH} className="w-full" size="lg">
                  Calculate ΔH
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getResultBg()} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Enthalpy Change (ΔH)</p>
                      <p className={`text-4xl font-bold ${getResultColor()} mb-2`}>
                        {result.deltaH > 0 ? "+" : ""}
                        {result.deltaH.toFixed(1)} kJ
                      </p>
                      <div
                        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${
                          result.reactionType === "exothermic"
                            ? "bg-blue-100 text-blue-700"
                            : result.reactionType === "endothermic"
                              ? "bg-red-100 text-red-700"
                              : "bg-gray-100 text-gray-700"
                        }`}
                      >
                        {result.reactionType === "exothermic" ? (
                          <>
                            <Thermometer className="h-4 w-4" />
                            Exothermic (releases heat)
                          </>
                        ) : result.reactionType === "endothermic" ? (
                          <>
                            <Zap className="h-4 w-4" />
                            Endothermic (absorbs heat)
                          </>
                        ) : (
                          "Neutral"
                        )}
                      </div>
                    </div>

                    {/* Step-by-step Toggle */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? (
                        <>
                          <ChevronUp className="h-4 w-4 mr-1" /> Hide Steps
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4 mr-1" /> Show Steps
                        </>
                      )}
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm font-mono whitespace-pre-wrap">
                        {result.steps.join("\n")}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Bond Energy Method</p>
                    <p className="font-mono text-sm font-semibold">ΔH = Σ(Bonds broken) − Σ(Bonds formed)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Enthalpy of Formation Method</p>
                    <p className="font-mono text-sm font-semibold">ΔH = Σ(ΔHf° products) − Σ(ΔHf° reactants)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Reaction Types</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <div className="flex items-center gap-2">
                      <Thermometer className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-blue-700">Exothermic</span>
                    </div>
                    <span className="text-sm text-blue-600">ΔH {"<"} 0</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-red-600" />
                      <span className="font-medium text-red-700">Endothermic</span>
                    </div>
                    <span className="text-sm text-red-600">ΔH {">"} 0</span>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-yellow-200 bg-yellow-50/50">
                <CardContent className="pt-4">
                  <div className="flex gap-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-medium">Disclaimer</p>
                      <p className="mt-1">
                        Results assume standard conditions and ideal measurements for ΔH calculations. Actual values may
                        vary.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Enthalpy Change (ΔH)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enthalpy change (ΔH) represents the heat energy absorbed or released during a chemical reaction at
                  constant pressure. It is one of the most important concepts in thermochemistry, helping scientists
                  understand energy flow in chemical processes. The symbol Δ (delta) indicates a change, and H
                  represents enthalpy, a thermodynamic quantity that accounts for the internal energy of a system plus
                  the product of its pressure and volume.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When ΔH is negative, the reaction releases heat to its surroundings and is called exothermic. Common
                  examples include combustion reactions, neutralization of acids and bases, and the formation of ionic
                  bonds. When ΔH is positive, the reaction absorbs heat from its surroundings and is called endothermic.
                  Examples include photosynthesis, melting ice, and the decomposition of calcium carbonate.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Bond Energy Method</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The bond energy method calculates ΔH by considering the energy required to break bonds in reactants
                  and the energy released when new bonds form in products. Bond dissociation energy is the energy needed
                  to break one mole of a particular bond in gaseous molecules. This method provides a straightforward
                  way to estimate reaction enthalpies when direct measurements are unavailable.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The formula ΔH = Σ(Bonds broken) − Σ(Bonds formed) reflects that breaking bonds requires energy input
                  (positive contribution), while forming bonds releases energy (negative contribution). If more energy
                  is released in forming new bonds than was needed to break old bonds, the overall reaction is
                  exothermic (negative ΔH). This method is particularly useful for organic reactions and estimating
                  reaction feasibility.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Standard Enthalpy of Formation (ΔHf°)</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Standard enthalpy of formation (ΔHf°) is the enthalpy change when one mole of a compound forms from
                  its elements in their standard states at 25°C and 1 atm pressure. By convention, ΔHf° for elements in
                  their standard states (like O₂ gas, N₂ gas, or solid carbon as graphite) is defined as zero. This
                  provides a reference point for calculating reaction enthalpies.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Using Hess's Law, we can calculate the enthalpy of any reaction by: ΔH = Σ(ΔHf° products) − Σ(ΔHf°
                  reactants). This powerful approach allows us to determine reaction enthalpies using tabulated
                  formation values without needing to measure each reaction directly. The method is exact (unlike bond
                  energies which are averages) and is widely used in chemistry for thermodynamic calculations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Thermochemistry calculations have numerous real-world applications. In the chemical industry,
                  understanding ΔH helps design efficient processes and manage heat in large-scale reactions. Combustion
                  enthalpies determine fuel efficiency and energy content. In biochemistry, metabolic pathways are
                  analyzed using enthalpy changes to understand how organisms extract energy from food.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Environmental scientists use enthalpy data to model climate processes and assess the energy impact of
                  chemical changes in the atmosphere. Engineers apply thermochemistry principles in designing heating
                  and cooling systems, batteries, and propulsion systems. Understanding whether a reaction is exothermic
                  or endothermic is crucial for safety considerations in laboratories and industrial settings.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
