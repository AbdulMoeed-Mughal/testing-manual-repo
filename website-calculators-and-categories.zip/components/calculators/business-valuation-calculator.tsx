"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Building2,
  Info,
  AlertTriangle,
  TrendingUp,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { CurrencySelector } from "@/components/ui/currency-selector"
import { formatCurrency, type Currency, currencySymbols } from "@/lib/currency"

interface ValuationResult {
  revenueMultiple: number
  ebitdaMultiple: number
  dcfValuation: number
  assetBased: number
  weightedAverage: number
  dcfBreakdown: { year: number; cashFlow: number; discountedCF: number }[]
}

export function BusinessValuationCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [annualRevenue, setAnnualRevenue] = useState("")
  const [ebitda, setEbitda] = useState("")
  const [revenueMultiplier, setRevenueMultiplier] = useState("2")
  const [ebitdaMultiplier, setEbitdaMultiplier] = useState("6")
  const [growthRate, setGrowthRate] = useState("")
  const [yearsProjected, setYearsProjected] = useState("5")
  const [totalAssets, setTotalAssets] = useState("")
  const [totalLiabilities, setTotalLiabilities] = useState("")
  const [discountRate, setDiscountRate] = useState("10")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<ValuationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateValuation = () => {
    setError("")
    setResult(null)

    const revenue = Number.parseFloat(annualRevenue)
    const ebitdaValue = Number.parseFloat(ebitda)
    const revMultiple = Number.parseFloat(revenueMultiplier)
    const ebitdaMultiple = Number.parseFloat(ebitdaMultiplier)

    if (isNaN(revenue) || revenue <= 0) {
      setError("Please enter a valid annual revenue greater than 0")
      return
    }

    if (isNaN(ebitdaValue) || ebitdaValue <= 0) {
      setError("Please enter a valid EBITDA greater than 0")
      return
    }

    if (isNaN(revMultiple) || revMultiple <= 0) {
      setError("Please enter a valid revenue multiple greater than 0")
      return
    }

    if (isNaN(ebitdaMultiple) || ebitdaMultiple <= 0) {
      setError("Please enter a valid EBITDA multiple greater than 0")
      return
    }

    // Revenue Multiple Valuation
    const revenueMultipleValuation = revenue * revMultiple

    // EBITDA Multiple Valuation
    const ebitdaMultipleValuation = ebitdaValue * ebitdaMultiple

    // Asset-Based Valuation
    const assets = Number.parseFloat(totalAssets) || 0
    const liabilities = Number.parseFloat(totalLiabilities) || 0
    const assetBasedValuation = assets - liabilities

    // DCF Valuation
    const growth = Number.parseFloat(growthRate) || 0
    const years = Number.parseInt(yearsProjected) || 5
    const discount = Number.parseFloat(discountRate) || 10
    const discountRateDecimal = discount / 100
    const growthRateDecimal = growth / 100

    let dcfTotal = 0
    const dcfBreakdown: { year: number; cashFlow: number; discountedCF: number }[] = []
    let currentCashFlow = ebitdaValue

    for (let year = 1; year <= years; year++) {
      currentCashFlow = year === 1 ? ebitdaValue : currentCashFlow * (1 + growthRateDecimal)
      const discountedCF = currentCashFlow / Math.pow(1 + discountRateDecimal, year)
      dcfTotal += discountedCF
      dcfBreakdown.push({
        year,
        cashFlow: currentCashFlow,
        discountedCF,
      })
    }

    // Terminal Value (Gordon Growth Model)
    const terminalGrowth = Math.min(growthRateDecimal, 0.03) // Cap terminal growth at 3%
    const terminalValue = (currentCashFlow * (1 + terminalGrowth)) / (discountRateDecimal - terminalGrowth)
    const discountedTerminalValue = terminalValue / Math.pow(1 + discountRateDecimal, years)
    const dcfValuation = dcfTotal + discountedTerminalValue

    // Weighted Average (equal weights for simplicity, only include methods with valid values)
    const valuations = [revenueMultipleValuation, ebitdaMultipleValuation]
    if (dcfValuation > 0 && !isNaN(dcfValuation) && isFinite(dcfValuation)) {
      valuations.push(dcfValuation)
    }
    if (assetBasedValuation > 0) {
      valuations.push(assetBasedValuation)
    }
    const weightedAverage = valuations.reduce((a, b) => a + b, 0) / valuations.length

    setResult({
      revenueMultiple: revenueMultipleValuation,
      ebitdaMultiple: ebitdaMultipleValuation,
      dcfValuation: dcfValuation > 0 && isFinite(dcfValuation) ? dcfValuation : 0,
      assetBased: assetBasedValuation,
      weightedAverage,
      dcfBreakdown,
    })
  }

  const handleReset = () => {
    setAnnualRevenue("")
    setEbitda("")
    setRevenueMultiplier("2")
    setEbitdaMultiplier("6")
    setGrowthRate("")
    setYearsProjected("5")
    setTotalAssets("")
    setTotalLiabilities("")
    setDiscountRate("10")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Business Valuation Results:
Revenue Multiple: ${formatCurrency(result.revenueMultiple, currency)}
EBITDA Multiple: ${formatCurrency(result.ebitdaMultiple, currency)}
DCF Valuation: ${formatCurrency(result.dcfValuation, currency)}
Asset-Based: ${formatCurrency(result.assetBased, currency)}
Weighted Average: ${formatCurrency(result.weightedAverage, currency)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Business Valuation Result",
          text: `My business valuation estimate is ${formatCurrency(result.weightedAverage, currency)} (weighted average)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Business Valuation Calculator</CardTitle>
                    <CardDescription>Estimate business value using multiple methods</CardDescription>
                  </div>
                </div>
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Annual Revenue Input */}
                <div className="space-y-2">
                  <Label htmlFor="revenue">Annual Revenue ({symbol})</Label>
                  <Input
                    id="revenue"
                    type="number"
                    placeholder="Enter annual revenue"
                    value={annualRevenue}
                    onChange={(e) => setAnnualRevenue(e.target.value)}
                    min="0"
                    step="1000"
                  />
                </div>

                {/* EBITDA Input */}
                <div className="space-y-2">
                  <Label htmlFor="ebitda">Net Profit / EBITDA ({symbol})</Label>
                  <Input
                    id="ebitda"
                    type="number"
                    placeholder="Enter EBITDA or net profit"
                    value={ebitda}
                    onChange={(e) => setEbitda(e.target.value)}
                    min="0"
                    step="1000"
                  />
                </div>

                {/* Multiples */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="revMultiple">Revenue Multiple</Label>
                    <Input
                      id="revMultiple"
                      type="number"
                      placeholder="e.g., 2"
                      value={revenueMultiplier}
                      onChange={(e) => setRevenueMultiplier(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ebitdaMultiple">EBITDA Multiple</Label>
                    <Input
                      id="ebitdaMultiple"
                      type="number"
                      placeholder="e.g., 6"
                      value={ebitdaMultiplier}
                      onChange={(e) => setEbitdaMultiplier(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options (DCF & Asset-Based)</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="growthRate">Growth Rate (%)</Label>
                        <Input
                          id="growthRate"
                          type="number"
                          placeholder="e.g., 10"
                          value={growthRate}
                          onChange={(e) => setGrowthRate(e.target.value)}
                          min="0"
                          max="100"
                          step="0.1"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="yearsProjected">Years Projected</Label>
                        <Select value={yearsProjected} onValueChange={setYearsProjected}>
                          <SelectTrigger id="yearsProjected">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="3">3 years</SelectItem>
                            <SelectItem value="5">5 years</SelectItem>
                            <SelectItem value="7">7 years</SelectItem>
                            <SelectItem value="10">10 years</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="discountRate">Discount Rate (%)</Label>
                      <Input
                        id="discountRate"
                        type="number"
                        placeholder="e.g., 10"
                        value={discountRate}
                        onChange={(e) => setDiscountRate(e.target.value)}
                        min="1"
                        max="50"
                        step="0.5"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="assets">Total Assets ({symbol})</Label>
                        <Input
                          id="assets"
                          type="number"
                          placeholder="Optional"
                          value={totalAssets}
                          onChange={(e) => setTotalAssets(e.target.value)}
                          min="0"
                          step="1000"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="liabilities">Total Liabilities ({symbol})</Label>
                        <Input
                          id="liabilities"
                          type="number"
                          placeholder="Optional"
                          value={totalLiabilities}
                          onChange={(e) => setTotalLiabilities(e.target.value)}
                          min="0"
                          step="1000"
                        />
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateValuation} className="w-full" size="lg">
                  Calculate Valuation
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Weighted Average Valuation</p>
                      <p className="text-4xl font-bold text-green-600">
                        {formatCurrency(result.weightedAverage, currency)}
                      </p>
                    </div>

                    {/* Valuation Methods Breakdown */}
                    <div className="space-y-2 mt-4">
                      <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                        <span className="text-sm font-medium">Revenue Multiple</span>
                        <span className="text-sm font-bold text-green-600">
                          {formatCurrency(result.revenueMultiple, currency)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                        <span className="text-sm font-medium">EBITDA Multiple</span>
                        <span className="text-sm font-bold text-green-600">
                          {formatCurrency(result.ebitdaMultiple, currency)}
                        </span>
                      </div>
                      {result.dcfValuation > 0 && (
                        <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                          <span className="text-sm font-medium">DCF Valuation</span>
                          <span className="text-sm font-bold text-green-600">
                            {formatCurrency(result.dcfValuation, currency)}
                          </span>
                        </div>
                      )}
                      {result.assetBased !== 0 && (
                        <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                          <span className="text-sm font-medium">Asset-Based</span>
                          <span
                            className={`text-sm font-bold ${result.assetBased >= 0 ? "text-green-600" : "text-red-600"}`}
                          >
                            {formatCurrency(result.assetBased, currency)}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* DCF Breakdown */}
                    {result.dcfValuation > 0 && result.dcfBreakdown.length > 0 && (
                      <Collapsible open={showDetails} onOpenChange={setShowDetails}>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full mt-3">
                            {showDetails ? "Hide" : "Show"} DCF Breakdown
                            {showDetails ? (
                              <ChevronUp className="ml-2 h-4 w-4" />
                            ) : (
                              <ChevronDown className="ml-2 h-4 w-4" />
                            )}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-3 overflow-x-auto">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="border-b">
                                  <th className="text-left py-2 px-2">Year</th>
                                  <th className="text-right py-2 px-2">Cash Flow</th>
                                  <th className="text-right py-2 px-2">Discounted</th>
                                </tr>
                              </thead>
                              <tbody>
                                {result.dcfBreakdown.map((row) => (
                                  <tr key={row.year} className="border-b border-dashed">
                                    <td className="py-2 px-2">{row.year}</td>
                                    <td className="text-right py-2 px-2">{formatCurrency(row.cashFlow, currency)}</td>
                                    <td className="text-right py-2 px-2">
                                      {formatCurrency(row.discountedCF, currency)}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Valuation Methods</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700 block">Revenue Multiple</span>
                      <span className="text-sm text-blue-600">Value = Revenue × Multiple</span>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700 block">EBITDA Multiple</span>
                      <span className="text-sm text-green-600">Value = EBITDA × Multiple</span>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700 block">DCF (Discounted Cash Flow)</span>
                      <span className="text-sm text-purple-600">Sum of discounted future cash flows</span>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700 block">Asset-Based</span>
                      <span className="text-sm text-orange-600">Value = Assets − Liabilities</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Industry Multiples Guide</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>SaaS / Tech</span>
                      <span className="font-medium">5-15x Revenue</span>
                    </div>
                    <div className="flex justify-between">
                      <span>E-commerce</span>
                      <span className="font-medium">2-4x Revenue</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Manufacturing</span>
                      <span className="font-medium">4-8x EBITDA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Professional Services</span>
                      <span className="font-medium">3-6x EBITDA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Retail</span>
                      <span className="font-medium">3-5x EBITDA</span>
                    </div>
                  </div>
                  <p className="text-xs italic mt-2">
                    Note: Multiples vary significantly based on growth rate, profitability, and market conditions.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Business Valuation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Business valuation is the process of determining the economic value of a company or business unit.
                  It's used in various situations including mergers and acquisitions, selling a business, raising
                  capital, tax reporting, and shareholder disputes. Multiple valuation methods are often used together
                  to arrive at a reasonable range of values, as each method has its strengths and limitations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The most common approaches include market-based methods (using multiples from comparable companies),
                  income-based methods (like DCF analysis), and asset-based methods. Professional valuators typically
                  use a combination of these approaches and apply judgment based on the specific circumstances of the
                  business being valued.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Valuation Methods</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground">Revenue Multiple Method</h4>
                    <p className="text-muted-foreground text-sm">
                      This method multiplies annual revenue by an industry-specific multiple. It's commonly used for
                      high-growth companies or those not yet profitable. SaaS companies, for example, often trade at
                      5-15x annual recurring revenue depending on growth rate and market conditions.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">EBITDA Multiple Method</h4>
                    <p className="text-muted-foreground text-sm">
                      EBITDA (Earnings Before Interest, Taxes, Depreciation, and Amortization) multiples are widely used
                      for established businesses. This method focuses on operational profitability and is less affected
                      by capital structure or accounting decisions.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Discounted Cash Flow (DCF)</h4>
                    <p className="text-muted-foreground text-sm">
                      DCF analysis projects future cash flows and discounts them to present value using a required rate
                      of return. This method is theoretically robust but sensitive to assumptions about growth rates and
                      discount rates. It includes a terminal value to account for cash flows beyond the projection
                      period.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Asset-Based Method</h4>
                    <p className="text-muted-foreground text-sm">
                      This approach values a business based on its net assets (total assets minus total liabilities).
                      It's most appropriate for asset-heavy businesses, holding companies, or as a floor value. For
                      operating businesses, it often undervalues the company as it doesn't capture intangible value.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Business valuation calculations are estimates based on entered values and assumed multiples or growth
                  rates. Actual business value may vary due to market conditions, industry trends, competitive
                  landscape, management quality, customer concentration, and many other factors. This calculator is for
                  educational and informational purposes only. For actual business transactions, please consult with
                  qualified financial advisors, valuation experts, or investment bankers who can perform comprehensive
                  analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
