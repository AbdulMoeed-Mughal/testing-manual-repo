"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Layers,
  Info,
  AlertTriangle,
  Calculator,
  BookOpen,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface CombinationResult {
  combinations: string
  nFactorial: string
  rFactorial: string
  nMinusRFactorial: string
  steps: string[]
}

export function CombinationCalculator() {
  const [allowRepetition, setAllowRepetition] = useState(false)
  const [n, setN] = useState("")
  const [r, setR] = useState("")
  const [result, setResult] = useState<CombinationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // BigInt factorial for large numbers
  const factorial = (num: number): bigint => {
    if (num < 0) return BigInt(0)
    if (num === 0 || num === 1) return BigInt(1)
    let result = BigInt(1)
    for (let i = 2; i <= num; i++) {
      result *= BigInt(i)
    }
    return result
  }

  // Format large numbers
  const formatBigInt = (num: bigint): string => {
    const str = num.toString()
    if (str.length <= 15) {
      return str.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }
    const exp = str.length - 1
    const mantissa = str[0] + "." + str.slice(1, 5)
    return `${mantissa} × 10^${exp}`
  }

  // Expand factorial for display (small numbers only)
  const expandFactorial = (num: number): string => {
    if (num <= 1) return num.toString()
    if (num > 10) return `${num}!`
    const parts: string[] = []
    for (let i = num; i >= 1; i--) {
      parts.push(i.toString())
    }
    return parts.join(" × ")
  }

  const calculateCombination = () => {
    setError("")
    setResult(null)

    const nNum = Number.parseInt(n)
    const rNum = Number.parseInt(r)

    if (isNaN(nNum) || nNum < 0) {
      setError("Please enter a valid non-negative integer for total items (n)")
      return
    }

    if (isNaN(rNum) || rNum < 0) {
      setError("Please enter a valid non-negative integer for items to choose (r)")
      return
    }

    if (!allowRepetition && rNum > nNum) {
      setError("When repetition is not allowed, r cannot be greater than n")
      return
    }

    if (nNum > 170) {
      setError("n cannot exceed 170 due to calculation limits")
      return
    }

    const steps: string[] = []
    let combinations: bigint

    if (allowRepetition) {
      // With repetition: C(n+r-1, r) = (n+r-1)! / [r! × (n-1)!]
      const nPlusRMinus1 = nNum + rNum - 1
      const nMinus1 = nNum - 1

      steps.push(`Formula: C(n+r-1, r) = (n+r-1)! / [r! × (n-1)!]`)
      steps.push(`Substituting: C(${nNum}+${rNum}-1, ${rNum}) = C(${nPlusRMinus1}, ${rNum})`)
      steps.push(`= ${nPlusRMinus1}! / [${rNum}! × ${nMinus1}!]`)

      const numerator = factorial(nPlusRMinus1)
      const denominator = factorial(rNum) * factorial(nMinus1)
      combinations = numerator / denominator

      if (nPlusRMinus1 <= 10) {
        steps.push(
          `= (${expandFactorial(nPlusRMinus1)}) / [(${expandFactorial(rNum)}) × (${expandFactorial(nMinus1)})]`,
        )
      }
      steps.push(`= ${formatBigInt(numerator)} / ${formatBigInt(denominator)}`)
      steps.push(`= ${formatBigInt(combinations)}`)

      setResult({
        combinations: formatBigInt(combinations),
        nFactorial: formatBigInt(factorial(nPlusRMinus1)),
        rFactorial: formatBigInt(factorial(rNum)),
        nMinusRFactorial: formatBigInt(factorial(nMinus1)),
        steps,
      })
    } else {
      // Without repetition: C(n, r) = n! / [r! × (n-r)!]
      steps.push(`Formula: C(n, r) = n! / [r! × (n-r)!]`)
      steps.push(`Substituting: C(${nNum}, ${rNum}) = ${nNum}! / [${rNum}! × ${nNum - rNum}!]`)

      const nFact = factorial(nNum)
      const rFact = factorial(rNum)
      const nMinusRFact = factorial(nNum - rNum)
      combinations = nFact / (rFact * nMinusRFact)

      if (nNum <= 10) {
        steps.push(`= (${expandFactorial(nNum)}) / [(${expandFactorial(rNum)}) × (${expandFactorial(nNum - rNum)})]`)
      }
      steps.push(`= ${formatBigInt(nFact)} / [${formatBigInt(rFact)} × ${formatBigInt(nMinusRFact)}]`)
      steps.push(`= ${formatBigInt(combinations)}`)

      setResult({
        combinations: formatBigInt(combinations),
        nFactorial: formatBigInt(nFact),
        rFactorial: formatBigInt(rFact),
        nMinusRFactorial: formatBigInt(nMinusRFact),
        steps,
      })
    }
  }

  const handleReset = () => {
    setN("")
    setR("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = allowRepetition
        ? `C(${n}+${r}-1, ${r}) with repetition = ${result.combinations}`
        : `C(${n}, ${r}) = ${result.combinations}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = allowRepetition
          ? `C(${n}+${r}-1, ${r}) with repetition = ${result.combinations}`
          : `C(${n}, ${r}) = ${result.combinations}`
        await navigator.share({
          title: "Combination Calculator Result",
          text: `I calculated combinations using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleRepetition = () => {
    setAllowRepetition((prev) => !prev)
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Combination Calculator</CardTitle>
                    <CardDescription>Calculate ways to choose items (order doesn't matter)</CardDescription>
                  </div>
                </div>

                {/* Repetition Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Allow Repetition</span>
                  <button
                    onClick={toggleRepetition}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        allowRepetition ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !allowRepetition ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      No
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        allowRepetition ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Yes
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Total Items (n) */}
                <div className="space-y-2">
                  <Label htmlFor="n">Total Items (n)</Label>
                  <Input
                    id="n"
                    type="number"
                    placeholder="Enter total number of items"
                    value={n}
                    onChange={(e) => setN(e.target.value)}
                    min="0"
                    max="170"
                  />
                </div>

                {/* Items to Choose (r) */}
                <div className="space-y-2">
                  <Label htmlFor="r">Items to Choose (r)</Label>
                  <Input
                    id="r"
                    type="number"
                    placeholder="Enter number of items to choose"
                    value={r}
                    onChange={(e) => setR(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCombination} className="w-full" size="lg">
                  Calculate Combinations
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {allowRepetition ? `C(${Number.parseInt(n) + Number.parseInt(r) - 1}, ${r})` : `C(${n}, ${r})`}
                      </p>
                      <p className="text-4xl sm:text-5xl font-bold text-blue-600 mb-2 break-all">
                        {result.combinations}
                      </p>
                      <p className="text-sm text-blue-700">
                        {allowRepetition ? "combinations with repetition" : "combinations without repetition"}
                      </p>
                    </div>

                    {/* Show Steps Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-4 text-sm text-blue-600 hover:text-blue-800 font-medium"
                    >
                      {showSteps ? "Hide Steps" : "Show Step-by-Step Solution"}
                    </button>

                    {/* Steps */}
                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-1">
                        {result.steps.map((step, index) => (
                          <p key={index} className="text-muted-foreground font-mono text-xs break-all">
                            {step}
                          </p>
                        ))}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Combination Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-medium text-foreground mb-2">Without Repetition:</p>
                    <p className="font-mono text-sm text-center">C(n, r) = n! / [r! × (n - r)!]</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-medium text-foreground mb-2">With Repetition:</p>
                    <p className="font-mono text-sm text-center">C(n+r-1, r) = (n+r-1)! / [r! × (n-1)!]</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>C(5, 2)</span>
                      <span className="font-semibold">10</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>C(10, 3)</span>
                      <span className="font-semibold">120</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>C(52, 5)</span>
                      <span className="font-semibold">2,598,960</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>C(20, 10)</span>
                      <span className="font-semibold">184,756</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>This calculator provides estimates only. Verify manually for critical calculations.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What Are Combinations?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Combinations are a fundamental concept in combinatorics, the branch of mathematics dealing with
                  counting and arrangements. Unlike permutations where order matters, combinations count the number of
                  ways to select items from a larger set where the order of selection is irrelevant. For example,
                  choosing 3 fruits from a bowl of 5 different fruits results in the same combination regardless of
                  which fruit you pick first.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The combination formula, often written as C(n, r), nCr, or "n choose r," calculates how many different
                  groups of r items can be formed from n total items. This is calculated by dividing the number of
                  permutations by r! (r factorial) to eliminate the duplicate arrangements that would be counted
                  separately in permutations but represent the same group in combinations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Formula</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The standard combination formula without repetition is C(n, r) = n! / [r! × (n-r)!]. The numerator,
                  n!, represents all possible arrangements of n items. We divide by r! to account for the fact that the
                  order within our selection doesn't matter, and by (n-r)! to account for the items we didn't select.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When repetition is allowed (also called combinations with replacement or multisets), the formula
                  changes to C(n+r-1, r). This accounts for the possibility of selecting the same item multiple times.
                  For example, choosing 3 scoops of ice cream from 5 flavors where you can repeat flavors would use this
                  formula.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Combinations vs Permutations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The key difference between combinations and permutations lies in whether order matters. Permutations
                  count arrangements where order is significant (like a password or ranking), while combinations count
                  selections where order is irrelevant (like a committee or lottery numbers). The relationship is: P(n,
                  r) = C(n, r) × r!
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To determine which to use, ask yourself: "Does rearranging the selected items create a different
                  outcome?" If yes, use permutations. If no, use combinations. For instance, selecting 3 people for a
                  committee uses combinations (same people = same committee), but assigning them as President, VP, and
                  Secretary uses permutations (same people, different roles = different outcome).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Combinations have countless practical applications across various fields. In probability and
                  statistics, they're essential for calculating odds in lotteries, card games, and other scenarios. The
                  probability of winning a lottery that requires choosing 6 numbers from 49 is 1 in C(49, 6) = 1 in
                  13,983,816.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In computer science, combinations are used in algorithm design, particularly for generating all
                  possible subsets of a set or analyzing the complexity of certain problems. In genetics, combinations
                  help calculate possible gene combinations. In business, they're used for market research sampling,
                  quality control, and analyzing different product combinations. Understanding combinations enables
                  better decision-making in scenarios involving selection without regard to order.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
