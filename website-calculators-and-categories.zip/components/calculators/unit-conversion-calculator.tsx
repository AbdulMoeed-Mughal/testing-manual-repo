"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, ArrowRightLeft, Info, AlertTriangle, Ruler } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Category = "length" | "mass" | "volume" | "temperature" | "time" | "speed" | "area" | "data"

interface UnitInfo {
  name: string
  symbol: string
  toBase: (value: number) => number
  fromBase: (value: number) => number
}

const unitCategories: Record<Category, { name: string; units: Record<string, UnitInfo> }> = {
  length: {
    name: "Length",
    units: {
      meter: { name: "Meter", symbol: "m", toBase: (v) => v, fromBase: (v) => v },
      kilometer: { name: "Kilometer", symbol: "km", toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
      centimeter: { name: "Centimeter", symbol: "cm", toBase: (v) => v / 100, fromBase: (v) => v * 100 },
      millimeter: { name: "Millimeter", symbol: "mm", toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
      mile: { name: "Mile", symbol: "mi", toBase: (v) => v * 1609.344, fromBase: (v) => v / 1609.344 },
      yard: { name: "Yard", symbol: "yd", toBase: (v) => v * 0.9144, fromBase: (v) => v / 0.9144 },
      foot: { name: "Foot", symbol: "ft", toBase: (v) => v * 0.3048, fromBase: (v) => v / 0.3048 },
      inch: { name: "Inch", symbol: "in", toBase: (v) => v * 0.0254, fromBase: (v) => v / 0.0254 },
      nauticalMile: { name: "Nautical Mile", symbol: "nmi", toBase: (v) => v * 1852, fromBase: (v) => v / 1852 },
      micrometer: { name: "Micrometer", symbol: "μm", toBase: (v) => v / 1000000, fromBase: (v) => v * 1000000 },
    },
  },
  mass: {
    name: "Mass",
    units: {
      kilogram: { name: "Kilogram", symbol: "kg", toBase: (v) => v, fromBase: (v) => v },
      gram: { name: "Gram", symbol: "g", toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
      milligram: { name: "Milligram", symbol: "mg", toBase: (v) => v / 1000000, fromBase: (v) => v * 1000000 },
      metricTon: { name: "Metric Ton", symbol: "t", toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
      pound: { name: "Pound", symbol: "lb", toBase: (v) => v * 0.453592, fromBase: (v) => v / 0.453592 },
      ounce: { name: "Ounce", symbol: "oz", toBase: (v) => v * 0.0283495, fromBase: (v) => v / 0.0283495 },
      stone: { name: "Stone", symbol: "st", toBase: (v) => v * 6.35029, fromBase: (v) => v / 6.35029 },
      usTon: { name: "US Ton", symbol: "ton", toBase: (v) => v * 907.185, fromBase: (v) => v / 907.185 },
    },
  },
  volume: {
    name: "Volume",
    units: {
      liter: { name: "Liter", symbol: "L", toBase: (v) => v, fromBase: (v) => v },
      milliliter: { name: "Milliliter", symbol: "mL", toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
      cubicMeter: { name: "Cubic Meter", symbol: "m³", toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
      cubicCentimeter: { name: "Cubic Centimeter", symbol: "cm³", toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
      gallon: { name: "US Gallon", symbol: "gal", toBase: (v) => v * 3.78541, fromBase: (v) => v / 3.78541 },
      quart: { name: "US Quart", symbol: "qt", toBase: (v) => v * 0.946353, fromBase: (v) => v / 0.946353 },
      pint: { name: "US Pint", symbol: "pt", toBase: (v) => v * 0.473176, fromBase: (v) => v / 0.473176 },
      cup: { name: "US Cup", symbol: "cup", toBase: (v) => v * 0.236588, fromBase: (v) => v / 0.236588 },
      fluidOunce: {
        name: "US Fluid Ounce",
        symbol: "fl oz",
        toBase: (v) => v * 0.0295735,
        fromBase: (v) => v / 0.0295735,
      },
      imperialGallon: {
        name: "Imperial Gallon",
        symbol: "imp gal",
        toBase: (v) => v * 4.54609,
        fromBase: (v) => v / 4.54609,
      },
    },
  },
  temperature: {
    name: "Temperature",
    units: {
      celsius: {
        name: "Celsius",
        symbol: "°C",
        toBase: (v) => v,
        fromBase: (v) => v,
      },
      fahrenheit: {
        name: "Fahrenheit",
        symbol: "°F",
        toBase: (v) => (v - 32) * (5 / 9),
        fromBase: (v) => v * (9 / 5) + 32,
      },
      kelvin: {
        name: "Kelvin",
        symbol: "K",
        toBase: (v) => v - 273.15,
        fromBase: (v) => v + 273.15,
      },
      rankine: {
        name: "Rankine",
        symbol: "°R",
        toBase: (v) => (v - 491.67) * (5 / 9),
        fromBase: (v) => v * (9 / 5) + 491.67,
      },
    },
  },
  time: {
    name: "Time",
    units: {
      second: { name: "Second", symbol: "s", toBase: (v) => v, fromBase: (v) => v },
      millisecond: { name: "Millisecond", symbol: "ms", toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
      microsecond: { name: "Microsecond", symbol: "μs", toBase: (v) => v / 1000000, fromBase: (v) => v * 1000000 },
      minute: { name: "Minute", symbol: "min", toBase: (v) => v * 60, fromBase: (v) => v / 60 },
      hour: { name: "Hour", symbol: "h", toBase: (v) => v * 3600, fromBase: (v) => v / 3600 },
      day: { name: "Day", symbol: "d", toBase: (v) => v * 86400, fromBase: (v) => v / 86400 },
      week: { name: "Week", symbol: "wk", toBase: (v) => v * 604800, fromBase: (v) => v / 604800 },
      month: { name: "Month (30 days)", symbol: "mo", toBase: (v) => v * 2592000, fromBase: (v) => v / 2592000 },
      year: { name: "Year (365 days)", symbol: "yr", toBase: (v) => v * 31536000, fromBase: (v) => v / 31536000 },
    },
  },
  speed: {
    name: "Speed",
    units: {
      meterPerSecond: { name: "Meter/Second", symbol: "m/s", toBase: (v) => v, fromBase: (v) => v },
      kilometerPerHour: { name: "Kilometer/Hour", symbol: "km/h", toBase: (v) => v / 3.6, fromBase: (v) => v * 3.6 },
      milePerHour: { name: "Mile/Hour", symbol: "mph", toBase: (v) => v * 0.44704, fromBase: (v) => v / 0.44704 },
      footPerSecond: { name: "Foot/Second", symbol: "ft/s", toBase: (v) => v * 0.3048, fromBase: (v) => v / 0.3048 },
      knot: { name: "Knot", symbol: "kn", toBase: (v) => v * 0.514444, fromBase: (v) => v / 0.514444 },
      mach: { name: "Mach (at sea level)", symbol: "Ma", toBase: (v) => v * 343, fromBase: (v) => v / 343 },
    },
  },
  area: {
    name: "Area",
    units: {
      squareMeter: { name: "Square Meter", symbol: "m²", toBase: (v) => v, fromBase: (v) => v },
      squareKilometer: {
        name: "Square Kilometer",
        symbol: "km²",
        toBase: (v) => v * 1000000,
        fromBase: (v) => v / 1000000,
      },
      squareCentimeter: {
        name: "Square Centimeter",
        symbol: "cm²",
        toBase: (v) => v / 10000,
        fromBase: (v) => v * 10000,
      },
      squareMillimeter: {
        name: "Square Millimeter",
        symbol: "mm²",
        toBase: (v) => v / 1000000,
        fromBase: (v) => v * 1000000,
      },
      hectare: { name: "Hectare", symbol: "ha", toBase: (v) => v * 10000, fromBase: (v) => v / 10000 },
      acre: { name: "Acre", symbol: "ac", toBase: (v) => v * 4046.86, fromBase: (v) => v / 4046.86 },
      squareMile: {
        name: "Square Mile",
        symbol: "mi²",
        toBase: (v) => v * 2589988.11,
        fromBase: (v) => v / 2589988.11,
      },
      squareYard: { name: "Square Yard", symbol: "yd²", toBase: (v) => v * 0.836127, fromBase: (v) => v / 0.836127 },
      squareFoot: { name: "Square Foot", symbol: "ft²", toBase: (v) => v * 0.092903, fromBase: (v) => v / 0.092903 },
      squareInch: {
        name: "Square Inch",
        symbol: "in²",
        toBase: (v) => v * 0.00064516,
        fromBase: (v) => v / 0.00064516,
      },
    },
  },
  data: {
    name: "Digital Storage",
    units: {
      byte: { name: "Byte", symbol: "B", toBase: (v) => v, fromBase: (v) => v },
      kilobyte: { name: "Kilobyte", symbol: "KB", toBase: (v) => v * 1024, fromBase: (v) => v / 1024 },
      megabyte: { name: "Megabyte", symbol: "MB", toBase: (v) => v * 1048576, fromBase: (v) => v / 1048576 },
      gigabyte: { name: "Gigabyte", symbol: "GB", toBase: (v) => v * 1073741824, fromBase: (v) => v / 1073741824 },
      terabyte: {
        name: "Terabyte",
        symbol: "TB",
        toBase: (v) => v * 1099511627776,
        fromBase: (v) => v / 1099511627776,
      },
      petabyte: {
        name: "Petabyte",
        symbol: "PB",
        toBase: (v) => v * 1125899906842624,
        fromBase: (v) => v / 1125899906842624,
      },
      bit: { name: "Bit", symbol: "b", toBase: (v) => v / 8, fromBase: (v) => v * 8 },
      kilobit: { name: "Kilobit", symbol: "Kb", toBase: (v) => v * 128, fromBase: (v) => v / 128 },
      megabit: { name: "Megabit", symbol: "Mb", toBase: (v) => v * 131072, fromBase: (v) => v / 131072 },
      gigabit: { name: "Gigabit", symbol: "Gb", toBase: (v) => v * 134217728, fromBase: (v) => v / 134217728 },
    },
  },
}

interface ConversionResult {
  value: number
  fromUnit: string
  toUnit: string
  fromSymbol: string
  toSymbol: string
  steps: string[]
}

export function UnitConversionCalculator() {
  const [category, setCategory] = useState<Category>("length")
  const [fromUnit, setFromUnit] = useState("meter")
  const [toUnit, setToUnit] = useState("kilometer")
  const [inputValue, setInputValue] = useState("")
  const [result, setResult] = useState<ConversionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const handleCategoryChange = (newCategory: Category) => {
    setCategory(newCategory)
    const units = Object.keys(unitCategories[newCategory].units)
    setFromUnit(units[0])
    setToUnit(units[1] || units[0])
    setResult(null)
    setError("")
  }

  const swapUnits = () => {
    const temp = fromUnit
    setFromUnit(toUnit)
    setToUnit(temp)
    setResult(null)
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1e10 || (Math.abs(num) < 1e-6 && num !== 0)) {
      return num.toExponential(6)
    }
    if (Number.isInteger(num)) {
      return num.toLocaleString()
    }
    const rounded = Math.round(num * 1e10) / 1e10
    return rounded.toLocaleString(undefined, { maximumFractionDigits: 10 })
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const value = Number.parseFloat(inputValue)
    if (isNaN(value)) {
      setError("Please enter a valid number")
      return
    }

    const categoryUnits = unitCategories[category].units
    const from = categoryUnits[fromUnit]
    const to = categoryUnits[toUnit]

    if (!from || !to) {
      setError("Invalid unit selection")
      return
    }

    const baseValue = from.toBase(value)
    const convertedValue = to.fromBase(baseValue)

    const steps: string[] = []
    steps.push(`Starting value: ${formatNumber(value)} ${from.symbol}`)

    if (category === "temperature") {
      if (fromUnit === "celsius" && toUnit === "fahrenheit") {
        steps.push(`Formula: °F = (°C × 9/5) + 32`)
        steps.push(`Calculation: (${value} × 9/5) + 32 = ${formatNumber(convertedValue)}`)
      } else if (fromUnit === "fahrenheit" && toUnit === "celsius") {
        steps.push(`Formula: °C = (°F - 32) × 5/9`)
        steps.push(`Calculation: (${value} - 32) × 5/9 = ${formatNumber(convertedValue)}`)
      } else if (fromUnit === "celsius" && toUnit === "kelvin") {
        steps.push(`Formula: K = °C + 273.15`)
        steps.push(`Calculation: ${value} + 273.15 = ${formatNumber(convertedValue)}`)
      } else if (fromUnit === "kelvin" && toUnit === "celsius") {
        steps.push(`Formula: °C = K - 273.15`)
        steps.push(`Calculation: ${value} - 273.15 = ${formatNumber(convertedValue)}`)
      } else {
        steps.push(`Convert to base unit (Celsius): ${formatNumber(baseValue)} °C`)
        steps.push(`Convert to ${to.name}: ${formatNumber(convertedValue)} ${to.symbol}`)
      }
    } else {
      if (fromUnit !== toUnit) {
        steps.push(`Convert to base unit: ${formatNumber(baseValue)} ${getBaseUnitSymbol(category)}`)
        steps.push(`Convert to ${to.name}: ${formatNumber(convertedValue)} ${to.symbol}`)
      }
    }

    steps.push(`Result: ${formatNumber(value)} ${from.symbol} = ${formatNumber(convertedValue)} ${to.symbol}`)

    setResult({
      value: convertedValue,
      fromUnit: from.name,
      toUnit: to.name,
      fromSymbol: from.symbol,
      toSymbol: to.symbol,
      steps,
    })
  }

  const getBaseUnitSymbol = (cat: Category): string => {
    const baseUnits: Record<Category, string> = {
      length: "m",
      mass: "kg",
      volume: "L",
      temperature: "°C",
      time: "s",
      speed: "m/s",
      area: "m²",
      data: "B",
    }
    return baseUnits[cat]
  }

  const handleReset = () => {
    setInputValue("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `${inputValue} ${result.fromSymbol} = ${formatNumber(result.value)} ${result.toSymbol}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const currentUnits = unitCategories[category].units

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <ArrowRightLeft className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Unit Conversion Calculator</CardTitle>
                    <CardDescription>Convert between different units of measurement</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Category Selection */}
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={category} onValueChange={(v) => handleCategoryChange(v as Category)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(unitCategories).map(([key, cat]) => (
                        <SelectItem key={key} value={key}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Input Value */}
                <div className="space-y-2">
                  <Label htmlFor="value">Value</Label>
                  <Input
                    id="value"
                    type="number"
                    placeholder="Enter value to convert"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Unit Selection */}
                <div className="grid grid-cols-[1fr,auto,1fr] gap-2 items-end">
                  <div className="space-y-2">
                    <Label>From</Label>
                    <Select value={fromUnit} onValueChange={setFromUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(currentUnits).map(([key, unit]) => (
                          <SelectItem key={key} value={key}>
                            {unit.name} ({unit.symbol})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button variant="outline" size="icon" onClick={swapUnits} className="mb-0.5 bg-transparent">
                    <ArrowRightLeft className="h-4 w-4" />
                  </Button>

                  <div className="space-y-2">
                    <Label>To</Label>
                    <Select value={toUnit} onValueChange={setToUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(currentUnits).map(([key, unit]) => (
                          <SelectItem key={key} value={key}>
                            {unit.name} ({unit.symbol})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Convert
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <p className="text-3xl sm:text-4xl font-bold text-blue-600 mb-2 break-all">
                        {formatNumber(result.value)} {result.toSymbol}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {inputValue} {result.fromSymbol} = {formatNumber(result.value)} {result.toSymbol}
                      </p>
                    </div>

                    {/* Step-by-Step Toggle */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="text-sm text-blue-600 hover:text-blue-800 underline"
                      >
                        {showSteps ? "Hide" : "Show"} conversion steps
                      </button>

                      {showSteps && (
                        <div className="mt-3 p-3 bg-white/80 rounded-lg text-sm space-y-1">
                          {result.steps.map((step, index) => (
                            <p key={index} className="text-muted-foreground">
                              {index + 1}. {step}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Available Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(unitCategories).map(([key, cat]) => (
                      <div
                        key={key}
                        className={`flex items-center justify-between p-2 rounded-lg text-sm ${
                          category === key ? "bg-blue-50 border border-blue-200" : "bg-muted/50"
                        }`}
                      >
                        <span className={category === key ? "font-medium text-blue-700" : "text-muted-foreground"}>
                          {cat.name}
                        </span>
                        <span className="text-xs text-muted-foreground">{Object.keys(cat.units).length} units</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Reference</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Common Conversions</p>
                    <ul className="space-y-1 text-xs">
                      <li>1 mile = 1.609 km</li>
                      <li>1 kg = 2.205 lb</li>
                      <li>1 gallon = 3.785 L</li>
                      <li>0°C = 32°F = 273.15 K</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>This calculator provides estimates only. Verify manually for critical conversions.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Unit Conversion?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Unit conversion is the process of expressing a measurement in different units while maintaining the
                  same quantity. It is a fundamental skill in science, engineering, cooking, travel, and everyday life.
                  Understanding how to convert between units allows you to communicate measurements universally and work
                  with data from different sources that may use varying measurement systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The two main measurement systems used worldwide are the metric system (International System of Units
                  or SI) and the imperial system. The metric system is used by most countries and is based on powers of
                  10, making conversions straightforward. The imperial system is primarily used in the United States and
                  includes units like feet, pounds, and gallons. Being able to convert between these systems is
                  essential for international communication and commerce.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Measurement Categories</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Length</strong> measures the distance between two points. Common metric units include meters,
                  kilometers, and centimeters, while imperial units include feet, inches, and miles. Length conversions
                  are used in construction, mapping, sports, and countless other applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Mass</strong> measures the amount of matter in an object. Kilograms and grams are standard
                  metric units, while pounds and ounces are common imperial units. Mass is crucial in cooking, shipping,
                  medicine, and scientific research.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Temperature</strong> is unique because different scales have different zero points. Celsius
                  sets 0° at water's freezing point, Fahrenheit sets 32° as freezing, and Kelvin sets 0 at absolute
                  zero. Temperature conversions require formulas rather than simple multiplication factors.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Volume</strong> measures three-dimensional space. Liters and milliliters are metric standards,
                  while gallons, quarts, and cups are imperial measurements commonly used in cooking and fuel
                  consumption.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Conversions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Know your conversion factors:</strong> Memorizing common conversion factors like 1 inch = 2.54
                  cm or 1 kg = 2.2 lb can help you make quick estimates without a calculator. These approximations are
                  useful for everyday situations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Use dimensional analysis:</strong> This method involves multiplying by conversion factors
                  written as fractions where the numerator and denominator are equivalent quantities. Units cancel out
                  until you're left with the desired unit.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Check for reasonableness:</strong> After converting, ask yourself if the answer makes sense.
                  For example, when converting kilometers to miles, the number should get smaller since miles are longer
                  than kilometers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Be aware of significant figures:</strong> In scientific contexts, pay attention to significant
                  figures to maintain appropriate precision in your converted values. The result should not imply more
                  precision than your original measurement.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
