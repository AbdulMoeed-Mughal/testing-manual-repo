"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Gauge, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMode = "mechanical" | "hydrostatic"
type ForceUnit = "N" | "kN" | "lb" | "kip"
type AreaUnit = "m2" | "cm2" | "mm2" | "in2" | "ft2"
type PressureUnit = "Pa" | "kPa" | "MPa" | "psi" | "bar"
type LengthUnit = "m" | "cm" | "mm" | "ft" | "in"

interface PressureResult {
  pressure: number
  category: string
  color: string
  bgColor: string
}

const forceConversions: Record<ForceUnit, number> = {
  N: 1,
  kN: 1000,
  lb: 4.44822,
  kip: 4448.22,
}

const areaConversions: Record<AreaUnit, number> = {
  m2: 1,
  cm2: 0.0001,
  mm2: 0.000001,
  in2: 0.00064516,
  ft2: 0.092903,
}

const pressureConversions: Record<PressureUnit, number> = {
  Pa: 1,
  kPa: 0.001,
  MPa: 0.000001,
  psi: 0.000145038,
  bar: 0.00001,
}

const lengthConversions: Record<LengthUnit, number> = {
  m: 1,
  cm: 0.01,
  mm: 0.001,
  ft: 0.3048,
  in: 0.0254,
}

export function HydraulicPressureCalculator() {
  const [mode, setMode] = useState<CalculationMode>("mechanical")
  const [force, setForce] = useState("")
  const [forceUnit, setForceUnit] = useState<ForceUnit>("N")
  const [area, setArea] = useState("")
  const [areaUnit, setAreaUnit] = useState<AreaUnit>("m2")
  const [pressureUnit, setPressureUnit] = useState<PressureUnit>("Pa")
  const [density, setDensity] = useState("1000")
  const [height, setHeight] = useState("")
  const [heightUnit, setHeightUnit] = useState<LengthUnit>("m")
  const [gravity, setGravity] = useState("9.81")
  const [result, setResult] = useState<PressureResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculatePressure = () => {
    setError("")
    setResult(null)

    let pressurePa: number

    if (mode === "mechanical") {
      const forceNum = Number.parseFloat(force)
      const areaNum = Number.parseFloat(area)

      if (isNaN(forceNum) || forceNum < 0) {
        setError("Please enter a valid force value")
        return
      }
      if (isNaN(areaNum) || areaNum <= 0) {
        setError("Please enter a valid area greater than 0")
        return
      }

      const forceN = forceNum * forceConversions[forceUnit]
      const areaM2 = areaNum * areaConversions[areaUnit]
      pressurePa = forceN / areaM2
    } else {
      const densityNum = Number.parseFloat(density)
      const heightNum = Number.parseFloat(height)
      const gravityNum = Number.parseFloat(gravity)

      if (isNaN(densityNum) || densityNum <= 0) {
        setError("Please enter a valid density greater than 0")
        return
      }
      if (isNaN(heightNum) || heightNum < 0) {
        setError("Please enter a valid height")
        return
      }
      if (isNaN(gravityNum) || gravityNum <= 0) {
        setError("Please enter a valid gravitational acceleration")
        return
      }

      const heightM = heightNum * lengthConversions[heightUnit]
      pressurePa = densityNum * gravityNum * heightM
    }

    const pressureConverted = pressurePa * pressureConversions[pressureUnit]

    let category: string
    let color: string
    let bgColor: string

    const pressureKPa = pressurePa / 1000
    if (pressureKPa < 100) {
      category = "Low Pressure"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (pressureKPa < 1000) {
      category = "Moderate Pressure"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (pressureKPa < 10000) {
      category = "High Pressure"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Pressure"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      pressure: pressureConverted,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setForce("")
    setArea("")
    setDensity("1000")
    setHeight("")
    setGravity("9.81")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Hydraulic Pressure: ${result.pressure.toExponential(4)} ${pressureUnit} (${result.category})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Hydraulic Pressure Calculation",
          text: `Hydraulic Pressure: ${result.pressure.toExponential(4)} ${pressureUnit} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1000000 || (Math.abs(num) < 0.001 && num !== 0)) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 4 })
  }

  const selectFluid = (fluidDensity: string) => {
    setDensity(fluidDensity)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Hydraulic Pressure Calculator</CardTitle>
                    <CardDescription>Calculate pressure in hydraulic systems</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Mode</span>
                  <button
                    onClick={() => {
                      setMode(mode === "mechanical" ? "hydrostatic" : "mechanical")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "hydrostatic" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "mechanical" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Mechanical
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "hydrostatic" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Hydrostatic
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {mode === "mechanical" ? (
                  <>
                    {/* Force Input */}
                    <div className="space-y-2">
                      <Label htmlFor="force">Applied Force (F)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="force"
                          type="number"
                          placeholder="Enter force"
                          value={force}
                          onChange={(e) => setForce(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <select
                          value={forceUnit}
                          onChange={(e) => setForceUnit(e.target.value as ForceUnit)}
                          className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                        >
                          <option value="N">N</option>
                          <option value="kN">kN</option>
                          <option value="lb">lb</option>
                          <option value="kip">kip</option>
                        </select>
                      </div>
                    </div>

                    {/* Area Input */}
                    <div className="space-y-2">
                      <Label htmlFor="area">Cross-sectional Area (A)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="area"
                          type="number"
                          placeholder="Enter area"
                          value={area}
                          onChange={(e) => setArea(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <select
                          value={areaUnit}
                          onChange={(e) => setAreaUnit(e.target.value as AreaUnit)}
                          className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                        >
                          <option value="m2">m²</option>
                          <option value="cm2">cm²</option>
                          <option value="mm2">mm²</option>
                          <option value="in2">in²</option>
                          <option value="ft2">ft²</option>
                        </select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Quick Fluid Selection */}
                    <div className="space-y-2">
                      <Label>Quick Fluid Selection</Label>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { name: "Water", density: "1000" },
                          { name: "Oil", density: "900" },
                          { name: "Mercury", density: "13600" },
                          { name: "Sea Water", density: "1025" },
                        ].map((fluid) => (
                          <Button
                            key={fluid.name}
                            variant={density === fluid.density ? "default" : "outline"}
                            size="sm"
                            onClick={() => selectFluid(fluid.density)}
                          >
                            {fluid.name}
                          </Button>
                        ))}
                      </div>
                    </div>

                    {/* Density Input */}
                    <div className="space-y-2">
                      <Label htmlFor="density">Fluid Density (ρ) in kg/m³</Label>
                      <Input
                        id="density"
                        type="number"
                        placeholder="Enter density"
                        value={density}
                        onChange={(e) => setDensity(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>

                    {/* Height Input */}
                    <div className="space-y-2">
                      <Label htmlFor="height">Fluid Height/Depth (h)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="height"
                          type="number"
                          placeholder="Enter height"
                          value={height}
                          onChange={(e) => setHeight(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <select
                          value={heightUnit}
                          onChange={(e) => setHeightUnit(e.target.value as LengthUnit)}
                          className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                        >
                          <option value="m">m</option>
                          <option value="cm">cm</option>
                          <option value="mm">mm</option>
                          <option value="ft">ft</option>
                          <option value="in">in</option>
                        </select>
                      </div>
                    </div>

                    {/* Gravity Input */}
                    <div className="space-y-2">
                      <Label htmlFor="gravity">Gravitational Acceleration (g) in m/s²</Label>
                      <Input
                        id="gravity"
                        type="number"
                        placeholder="Enter gravity"
                        value={gravity}
                        onChange={(e) => setGravity(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Pressure Unit</Label>
                  <select
                    value={pressureUnit}
                    onChange={(e) => setPressureUnit(e.target.value as PressureUnit)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="Pa">Pascal (Pa)</option>
                    <option value="kPa">Kilopascal (kPa)</option>
                    <option value="MPa">Megapascal (MPa)</option>
                    <option value="psi">Pounds per sq inch (psi)</option>
                    <option value="bar">Bar</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePressure} className="w-full" size="lg">
                  Calculate Pressure
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Hydraulic Pressure</p>
                      <p className={`text-3xl font-bold ${result.color} mb-1`}>{formatNumber(result.pressure)}</p>
                      <p className="text-lg text-muted-foreground mb-2">{pressureUnit}</p>
                      <p className={`text-sm font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Step-by-step breakdown toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        {mode === "mechanical" ? (
                          <>
                            <p>
                              <strong>Formula:</strong> P = F / A
                            </p>
                            <p>
                              <strong>Force:</strong> {force} {forceUnit} ={" "}
                              {formatNumber(Number.parseFloat(force) * forceConversions[forceUnit])} N
                            </p>
                            <p>
                              <strong>Area:</strong> {area} {areaUnit} ={" "}
                              {formatNumber(Number.parseFloat(area) * areaConversions[areaUnit])} m²
                            </p>
                            <p>
                              <strong>Pressure:</strong>{" "}
                              {formatNumber(Number.parseFloat(force) * forceConversions[forceUnit])} N /{" "}
                              {formatNumber(Number.parseFloat(area) * areaConversions[areaUnit])} m² ={" "}
                              {formatNumber(result.pressure)} {pressureUnit}
                            </p>
                          </>
                        ) : (
                          <>
                            <p>
                              <strong>Formula:</strong> P = ρ × g × h
                            </p>
                            <p>
                              <strong>Density (ρ):</strong> {density} kg/m³
                            </p>
                            <p>
                              <strong>Gravity (g):</strong> {gravity} m/s²
                            </p>
                            <p>
                              <strong>Height (h):</strong> {height} {heightUnit} ={" "}
                              {formatNumber(Number.parseFloat(height) * lengthConversions[heightUnit])} m
                            </p>
                            <p>
                              <strong>Pressure:</strong> {density} × {gravity} ×{" "}
                              {formatNumber(Number.parseFloat(height) * lengthConversions[heightUnit])} ={" "}
                              {formatNumber(result.pressure)} {pressureUnit}
                            </p>
                          </>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Hydraulic Pressure Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Mechanical Pressure (Pascal's Law)</p>
                    <p className="font-mono text-center text-lg">P = F / A</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Where P = pressure, F = force, A = cross-sectional area
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Hydrostatic Pressure</p>
                    <p className="font-mono text-center text-lg">P = ρ × g × h</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Where P = pressure, ρ = fluid density, g = gravity, h = depth
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Fluid Densities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {[
                      { name: "Water (20°C)", density: "998 kg/m³" },
                      { name: "Sea Water", density: "1,025 kg/m³" },
                      { name: "Hydraulic Oil", density: "870-920 kg/m³" },
                      { name: "Mercury", density: "13,600 kg/m³" },
                      { name: "Gasoline", density: "720-780 kg/m³" },
                    ].map((item) => (
                      <div key={item.name} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <span className="text-sm font-medium">{item.name}</span>
                        <span className="text-sm text-muted-foreground">{item.density}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Hydraulic Pressure?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Hydraulic pressure refers to the force per unit area exerted by a fluid within a confined system. It
                  is a fundamental concept in fluid mechanics and is the basis for hydraulic systems used in machinery,
                  vehicles, aircraft, and industrial equipment. Understanding hydraulic pressure is essential for
                  designing and analyzing systems that transmit power through fluids.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  There are two main types of hydraulic pressure calculations: mechanical pressure based on Pascal's Law
                  (P = F/A), which describes how pressure is transmitted equally in all directions in a confined fluid,
                  and hydrostatic pressure (P = ρgh), which describes the pressure exerted by a fluid at rest due to the
                  weight of the fluid above it.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Hydraulic Systems</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Hydraulic systems are used extensively across many industries due to their ability to transmit large
                  forces with precise control. Common applications include:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Construction Equipment:</strong> Excavators, bulldozers, and cranes use hydraulic systems to
                    lift and move heavy loads.
                  </li>
                  <li>
                    <strong>Automotive:</strong> Brake systems, power steering, and suspension systems rely on hydraulic
                    pressure for operation.
                  </li>
                  <li>
                    <strong>Manufacturing:</strong> Hydraulic presses, injection molding machines, and metal forming
                    equipment use hydraulic power.
                  </li>
                  <li>
                    <strong>Aviation:</strong> Aircraft use hydraulic systems for landing gear, flight controls, and
                    braking systems.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Hydraulic pressure calculations are estimates based on ideal conditions.
                  Actual pressure may vary due to friction, leakage, temperature changes, and system configuration.
                  Consult hydraulic system references and engineering standards for precise analysis in critical
                  applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
