"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Layers, Info, Calculator, HelpCircle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface MixResult {
  cementBags: number
  cementKg: number
  sandM3: number
  sandKg: number
  aggregateM3: number
  aggregateKg: number
}

const mixPresets: Record<string, { cement: string; sand: string; aggregate: string; label: string }> = {
  "1:1.5:3": { cement: "1", sand: "1.5", aggregate: "3", label: "M20 Grade (1:1.5:3)" },
  "1:2:4": { cement: "1", sand: "2", aggregate: "4", label: "M15 Grade (1:2:4)" },
  "1:1:2": { cement: "1", sand: "1", aggregate: "2", label: "M25 Grade (1:1:2)" },
  "1:3:6": { cement: "1", sand: "3", aggregate: "6", label: "M10 Grade (1:3:6)" },
  custom: { cement: "", sand: "", aggregate: "", label: "Custom Mix" },
}

export function ConcreteMixRatioCalculator() {
  const [volume, setVolume] = useState("")
  const [mixPreset, setMixPreset] = useState("1:2:4")
  const [cementRatio, setCementRatio] = useState("1")
  const [sandRatio, setSandRatio] = useState("2")
  const [aggregateRatio, setAggregateRatio] = useState("4")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [cementBagSize, setCementBagSize] = useState("50")
  const [cementDensity, setCementDensity] = useState("1440")
  const [sandDensity, setSandDensity] = useState("1600")
  const [aggregateDensity, setAggregateDensity] = useState("1500")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<MixResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const handleMixPresetChange = (value: string) => {
    setMixPreset(value)
    const preset = mixPresets[value]
    setCementRatio(preset.cement)
    setSandRatio(preset.sand)
    setAggregateRatio(preset.aggregate)
  }

  const calculateMix = () => {
    setError("")
    setResult(null)

    const volumeNum = Number.parseFloat(volume)
    if (isNaN(volumeNum) || volumeNum <= 0) {
      setError("Please enter a valid volume greater than 0")
      return
    }

    const dryFactorNum = Number.parseFloat(dryVolumeFactor)
    const cementDensityNum = Number.parseFloat(cementDensity)
    const sandDensityNum = Number.parseFloat(sandDensity)
    const aggregateDensityNum = Number.parseFloat(aggregateDensity)
    const wastageNum = Number.parseFloat(wastage)
    const bagSizeNum = Number.parseFloat(cementBagSize)
    const cement = Number.parseFloat(cementRatio)
    const sand = Number.parseFloat(sandRatio)
    const aggregate = Number.parseFloat(aggregateRatio)

    if (isNaN(dryFactorNum) || dryFactorNum <= 0) {
      setError("Please enter a valid dry volume factor")
      return
    }
    if (
      isNaN(cementDensityNum) ||
      isNaN(sandDensityNum) ||
      isNaN(aggregateDensityNum) ||
      cementDensityNum <= 0 ||
      sandDensityNum <= 0 ||
      aggregateDensityNum <= 0
    ) {
      setError("Please enter valid density values")
      return
    }
    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }
    if (isNaN(bagSizeNum) || bagSizeNum <= 0) {
      setError("Please enter a valid cement bag size")
      return
    }
    if (isNaN(cement) || isNaN(sand) || isNaN(aggregate) || cement <= 0 || sand <= 0 || aggregate <= 0) {
      setError("Please enter valid mix ratio values")
      return
    }

    const dryVolume = volumeNum * dryFactorNum
    const totalRatio = cement + sand + aggregate

    const cementVolume = (dryVolume * (cement / totalRatio)) * (1 + wastageNum / 100)
    const sandVolume = (dryVolume * (sand / totalRatio)) * (1 + wastageNum / 100)
    const aggregateVolume = (dryVolume * (aggregate / totalRatio)) * (1 + wastageNum / 100)

    const cementKg = cementVolume * cementDensityNum
    const sandKg = sandVolume * sandDensityNum
    const aggregateKg = aggregateVolume * aggregateDensityNum

    const cementBags = Math.ceil(cementKg / bagSizeNum)

    setResult({
      cementBags,
      cementKg: Math.round(cementKg * 10) / 10,
      sandM3: Math.round(sandVolume * 1000) / 1000,
      sandKg: Math.round(sandKg * 10) / 10,
      aggregateM3: Math.round(aggregateVolume * 1000) / 1000,
      aggregateKg: Math.round(aggregateKg * 10) / 10,
    })
  }

  const handleReset = () => {
    setVolume("")
    setMixPreset("1:2:4")
    setCementRatio("1")
    setSandRatio("2")
    setAggregateRatio("4")
    setDryVolumeFactor("1.54")
    setCementBagSize("50")
    setCementDensity("1440")
    setSandDensity("1600")
    setAggregateDensity("1500")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Concrete Mix:\nCement: ${result.cementBags} bags (${result.cementKg} kg)\nSand: ${result.sandM3} m³ (${result.sandKg} kg)\nAggregate: ${result.aggregateM3} m³ (${result.aggregateKg} kg)`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Concrete Mix Ratio Result",
          text: `I calculated concrete mix using CalcHub! Cement: ${result.cementBags} bags, Sand: ${result.sandM3} m³, Aggregate: ${result.aggregateM3} m³`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Concrete Mix Ratio Calculator</CardTitle>
                    <CardDescription>Calculate cement, sand, and aggregate quantities</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Volume Input */}
                <div className="space-y-2">
                  <Label htmlFor="volume">Wet Concrete Volume (m³)</Label>
                  <Input
                    id="volume"
                    type="number"
                    placeholder="Enter volume in cubic meters"
                    value={volume}
                    onChange={(e) => setVolume(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Mix Ratio Preset */}
                <div className="space-y-2">
                  <Label htmlFor="mixPreset">Mix Ratio Preset</Label>
                  <Select value={mixPreset} onValueChange={handleMixPresetChange}>
                    <SelectTrigger id="mixPreset">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1:1.5:3">M20 Grade (1:1.5:3)</SelectItem>
                      <SelectItem value="1:2:4">M15 Grade (1:2:4)</SelectItem>
                      <SelectItem value="1:1:2">M25 Grade (1:1:2)</SelectItem>
                      <SelectItem value="1:3:6">M10 Grade (1:3:6)</SelectItem>
                      <SelectItem value="custom">Custom Mix</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Mix Ratio */}
                <div className="space-y-2">
                  <Label>Mix Ratio (Cement : Sand : Aggregate)</Label>
                  <div className="grid grid-cols-5 gap-2 items-center">
                    <Input
                      type="number"
                      placeholder="C"
                      value={cementRatio}
                      onChange={(e) => {
                        setCementRatio(e.target.value)
                        setMixPreset("custom")
                      }}
                      min="0"
                      step="0.1"
                    />
                    <span className="text-center text-muted-foreground">:</span>
                    <Input
                      type="number"
                      placeholder="S"
                      value={sandRatio}
                      onChange={(e) => {
                        setSandRatio(e.target.value)
                        setMixPreset("custom")
                      }}
                      min="0"
                      step="0.1"
                    />
                    <span className="text-center text-muted-foreground">:</span>
                    <Input
                      type="number"
                      placeholder="A"
                      value={aggregateRatio}
                      onChange={(e) => {
                        setAggregateRatio(e.target.value)
                        setMixPreset("custom")
                      }}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Advanced Parameters */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="dryFactor">Dry Volume Factor</Label>
                    <Input
                      id="dryFactor"
                      type="number"
                      value={dryVolumeFactor}
                      onChange={(e) => setDryVolumeFactor(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bagSize">Cement Bag (kg)</Label>
                    <Input
                      id="bagSize"
                      type="number"
                      value={cementBagSize}
                      onChange={(e) => setCementBagSize(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="wastage">Wastage (%)</Label>
                  <Input
                    id="wastage"
                    type="number"
                    placeholder="Enter wastage percentage"
                    value={wastage}
                    onChange={(e) => setWastage(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMix} className="w-full" size="lg">
                  Calculate Materials
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="p-3 bg-white/60 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">Cement Required</p>
                        <p className="text-3xl font-bold text-amber-600">{result.cementBags} bags</p>
                        <p className="text-sm font-medium text-amber-700 mt-1">({result.cementKg} kg)</p>
                      </div>

                      <div className="p-3 bg-white/60 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">Sand Required</p>
                        <p className="text-2xl font-bold text-amber-600">{result.sandM3} m³</p>
                        <p className="text-sm font-medium text-amber-700 mt-1">({result.sandKg} kg)</p>
                      </div>

                      <div className="p-3 bg-white/60 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">Aggregate Required</p>
                        <p className="text-2xl font-bold text-amber-600">{result.aggregateM3} m³</p>
                        <p className="text-sm font-medium text-amber-700 mt-1">({result.aggregateKg} kg)</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Concrete Grades</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M10</span>
                      <span className="text-sm text-amber-600">1:3:6 (Non-structural)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M15</span>
                      <span className="text-sm text-amber-600">1:2:4 (Moderate strength)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M20</span>
                      <span className="text-sm text-amber-600">1:1.5:3 (Standard structural)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">M25</span>
                      <span className="text-sm text-amber-600">1:1:2 (High strength)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Material Densities</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="flex justify-between">
                    <span className="font-semibold text-foreground">Cement:</span>
                    <span>1440 kg/m³</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold text-foreground">Sand:</span>
                    <span>1600 kg/m³</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold text-foreground">Aggregate:</span>
                    <span>1500 kg/m³</span>
                  </div>
                  <p className="text-xs pt-2">Values may vary based on material source and moisture content.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Concrete Mix Ratio */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Concrete Mix Ratio?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A concrete mix ratio defines the proportions of cement, sand (fine aggregate), and coarse aggregate used
                  to create concrete of a specific strength grade. The ratio is typically expressed as three numbers
                  separated by colons, such as 1:2:4, where the first number represents cement, the second represents
                  sand, and the third represents coarse aggregate by volume.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Different concrete grades require different mix ratios to achieve the desired compressive strength. For
                  example, M20 concrete (which can withstand 20 N/mm² pressure after 28 days) typically uses a 1:1.5:3
                  ratio, while M15 concrete uses a 1:2:4 ratio. The mix ratio directly affects the concrete's strength,
                  workability, durability, and cost.
                </p>
              </CardContent>
            </Card>

            {/* How is Concrete Mix Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How is Concrete Mix Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation begins with the wet concrete volume required for your project. This is then multiplied by
                  the dry volume factor (typically 1.54) to account for air voids in the dry materials. The dry volume is
                  then divided among cement, sand, and aggregate according to the mix ratio proportions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, with a 1:2:4 mix ratio, the total parts are 7 (1+2+4). If you have 10.78 m³ of dry volume,
                  cement gets 1/7th (1.54 m³), sand gets 2/7th (3.08 m³), and aggregate gets 4/7th (6.16 m³). Each volume
                  is then multiplied by its respective density to get the weight. Cement is typically measured in bags
                  (usually 50kg each), so the cement weight is divided by the bag size to determine how many bags you need
                  to purchase.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <HelpCircle className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions About Concrete Mix</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Which concrete grade should I use?</h4>
                    <p className="text-muted-foreground text-sm">
                      M10 is suitable for leveling courses and non-structural work. M15 works for pathways and light-duty
                      slabs. M20 is the standard for residential structural elements like beams, columns, and slabs. M25
                      and above are used for heavy-duty structures and commercial buildings.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Can I adjust the mix ratio?</h4>
                    <p className="text-muted-foreground text-sm">
                      While you can create custom mix ratios, it's recommended to follow standard grades for structural
                      work. Deviating from proven ratios can compromise concrete strength, durability, and may violate
                      building codes. Always consult with a structural engineer for critical applications.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How much water should I add?</h4>
                    <p className="text-muted-foreground text-sm">
                      The water-cement ratio is crucial for concrete strength. Typically, use 0.4 to 0.6 liters of water
                      per kilogram of cement (40-60% by weight). Too much water weakens concrete, while too little makes
                      it difficult to work with. The exact amount depends on aggregate moisture content and desired
                      workability.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Why include wastage in calculations?</h4>
                    <p className="text-muted-foreground text-sm">
                      Wastage accounts for material loss during transportation, handling, spillage, and over-excavation. A
                      5-10% wastage factor ensures you have sufficient materials to complete your project without running
                      short, which could delay construction and create cold joints in the concrete.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50/50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  <strong className="text-foreground">Disclaimer:</strong> Dry volume factor and material densities may
                  vary based on material source, moisture content, and site conditions. The concrete grades mentioned are
                  nominal mixes and may not achieve specified strength without proper quality control. Results provided by
                  this calculator are approximate and intended for estimation purposes only. Always consult with structural
                  engineers, conduct material testing, and follow local building codes for accurate material requirements
                  in construction projects.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
