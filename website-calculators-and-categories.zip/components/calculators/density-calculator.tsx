"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Share2, Layers, Info, AlertTriangle, Beaker } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "density" | "mass" | "volume"

interface DensityResult {
  density: number
  mass: number
  volume: number
  densityUnit: string
  massUnit: string
  volumeUnit: string
  comparison: string[]
}

const massUnits = [
  { value: "kg", label: "Kilograms (kg)", toKg: 1 },
  { value: "g", label: "Grams (g)", toKg: 0.001 },
  { value: "lb", label: "Pounds (lb)", toKg: 0.453592 },
]

const volumeUnits = [
  { value: "m3", label: "Cubic Meters (m³)", toM3: 1 },
  { value: "L", label: "Liters (L)", toM3: 0.001 },
  { value: "cm3", label: "Cubic Centimeters (cm³)", toM3: 0.000001 },
  { value: "ft3", label: "Cubic Feet (ft³)", toM3: 0.0283168 },
]

const densityUnits = [
  { value: "kg/m3", label: "kg/m³", factor: 1 },
  { value: "g/cm3", label: "g/cm³", factor: 1000 },
  { value: "lb/ft3", label: "lb/ft³", factor: 16.0185 },
]

const materialDensities = [
  { name: "Air (at sea level)", density: 1.225 },
  { name: "Water", density: 1000 },
  { name: "Ice", density: 917 },
  { name: "Wood (Oak)", density: 750 },
  { name: "Aluminum", density: 2700 },
  { name: "Steel", density: 7850 },
  { name: "Copper", density: 8960 },
  { name: "Lead", density: 11340 },
  { name: "Gold", density: 19320 },
]

export function DensityCalculator() {
  const [mode, setMode] = useState<CalculationMode>("density")
  const [mass, setMass] = useState("")
  const [massUnit, setMassUnit] = useState("kg")
  const [volume, setVolume] = useState("")
  const [volumeUnit, setVolumeUnit] = useState("m3")
  const [density, setDensity] = useState("")
  const [densityUnit, setDensityUnit] = useState("kg/m3")
  const [result, setResult] = useState<DensityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const massConversion = massUnits.find((u) => u.value === massUnit)?.toKg || 1
    const volumeConversion = volumeUnits.find((u) => u.value === volumeUnit)?.toM3 || 1
    const densityConversion = densityUnits.find((u) => u.value === densityUnit)?.factor || 1

    let calculatedDensity: number
    let calculatedMass: number
    let calculatedVolume: number

    if (mode === "density") {
      const massNum = Number.parseFloat(mass)
      const volumeNum = Number.parseFloat(volume)

      if (isNaN(massNum) || massNum <= 0) {
        setError("Please enter a valid mass greater than 0")
        return
      }
      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }

      const massInKg = massNum * massConversion
      const volumeInM3 = volumeNum * volumeConversion
      calculatedDensity = massInKg / volumeInM3
      calculatedMass = massNum
      calculatedVolume = volumeNum
    } else if (mode === "mass") {
      const densityNum = Number.parseFloat(density)
      const volumeNum = Number.parseFloat(volume)

      if (isNaN(densityNum) || densityNum <= 0) {
        setError("Please enter a valid density greater than 0")
        return
      }
      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }

      const densityInKgM3 = densityNum * densityConversion
      const volumeInM3 = volumeNum * volumeConversion
      calculatedMass = (densityInKgM3 * volumeInM3) / massConversion
      calculatedDensity = densityInKgM3
      calculatedVolume = volumeNum
    } else {
      const densityNum = Number.parseFloat(density)
      const massNum = Number.parseFloat(mass)

      if (isNaN(densityNum) || densityNum <= 0) {
        setError("Please enter a valid density greater than 0")
        return
      }
      if (isNaN(massNum) || massNum <= 0) {
        setError("Please enter a valid mass greater than 0")
        return
      }

      const densityInKgM3 = densityNum * densityConversion
      const massInKg = massNum * massConversion
      calculatedVolume = massInKg / densityInKgM3 / volumeConversion
      calculatedDensity = densityInKgM3
      calculatedMass = massNum
    }

    // Find similar materials
    const comparison: string[] = []
    for (const material of materialDensities) {
      const ratio = calculatedDensity / material.density
      if (ratio >= 0.8 && ratio <= 1.2) {
        comparison.push(`Similar to ${material.name} (${material.density.toLocaleString()} kg/m³)`)
      }
    }

    if (comparison.length === 0) {
      if (calculatedDensity < 1.225) {
        comparison.push("Less dense than air")
      } else if (calculatedDensity < 1000) {
        comparison.push("Would float on water")
      } else if (calculatedDensity > 19320) {
        comparison.push("Denser than gold")
      } else {
        comparison.push("Would sink in water")
      }
    }

    setResult({
      density: calculatedDensity,
      mass: calculatedMass,
      volume: calculatedVolume,
      densityUnit: "kg/m³",
      massUnit,
      volumeUnit,
      comparison,
    })
  }

  const handleReset = () => {
    setMass("")
    setVolume("")
    setDensity("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        mode === "density"
          ? `Density: ${result.density.toFixed(4)} kg/m³`
          : mode === "mass"
            ? `Mass: ${result.mass.toFixed(4)} ${result.massUnit}`
            : `Volume: ${result.volume.toFixed(6)} ${result.volumeUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Density Calculation Result",
          text: `Density: ${result.density.toFixed(4)} kg/m³`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const formatNumber = (num: number, decimals = 4) => {
    if (num >= 1e6 || num < 1e-4) {
      return num.toExponential(decimals)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: decimals })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Density Calculator</CardTitle>
                    <CardDescription>Calculate density, mass, or volume</CardDescription>
                  </div>
                </div>

                {/* Mode Selection */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Calculate</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "density", label: "Density" },
                      { value: "mass", label: "Mass" },
                      { value: "volume", label: "Volume" },
                    ].map((m) => (
                      <button
                        key={m.value}
                        onClick={() => {
                          setMode(m.value as CalculationMode)
                          setResult(null)
                          setError("")
                        }}
                        className={`py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                          mode === m.value ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Mass Input - shown for density and volume modes */}
                {(mode === "density" || mode === "volume") && (
                  <div className="space-y-2">
                    <Label>Mass</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter mass"
                        value={mass}
                        onChange={(e) => setMass(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={massUnit} onValueChange={setMassUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {massUnits.map((u) => (
                            <SelectItem key={u.value} value={u.value}>
                              {u.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Volume Input - shown for density and mass modes */}
                {(mode === "density" || mode === "mass") && (
                  <div className="space-y-2">
                    <Label>Volume</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter volume"
                        value={volume}
                        onChange={(e) => setVolume(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={volumeUnit} onValueChange={setVolumeUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {volumeUnits.map((u) => (
                            <SelectItem key={u.value} value={u.value}>
                              {u.value === "m3"
                                ? "m³"
                                : u.value === "cm3"
                                  ? "cm³"
                                  : u.value === "ft3"
                                    ? "ft³"
                                    : u.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Density Input - shown for mass and volume modes */}
                {(mode === "mass" || mode === "volume") && (
                  <div className="space-y-2">
                    <Label>Density</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter density"
                        value={density}
                        onChange={(e) => setDensity(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={densityUnit} onValueChange={setDensityUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {densityUnits.map((u) => (
                            <SelectItem key={u.value} value={u.value}>
                              {u.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Error */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {mode.charAt(0).toUpperCase() + mode.slice(1)}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "density" ? "Density" : mode === "mass" ? "Mass" : "Volume"}
                      </p>
                      <p className="text-4xl font-bold text-orange-600 mb-1">
                        {mode === "density"
                          ? formatNumber(result.density)
                          : mode === "mass"
                            ? formatNumber(result.mass)
                            : formatNumber(result.volume, 6)}
                      </p>
                      <p className="text-lg text-orange-500">
                        {mode === "density"
                          ? "kg/m³"
                          : mode === "mass"
                            ? result.massUnit
                            : result.volumeUnit === "m3"
                              ? "m³"
                              : result.volumeUnit === "cm3"
                                ? "cm³"
                                : result.volumeUnit === "ft3"
                                  ? "ft³"
                                  : result.volumeUnit}
                      </p>
                    </div>

                    {/* Material Comparison */}
                    {result.comparison.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-orange-200">
                        <p className="text-sm text-orange-700 text-center">{result.comparison[0]}</p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Density Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold">ρ = m ÷ V</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold">m = ρ × V</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold">V = m ÷ ρ</p>
                  </div>
                  <p className="text-sm text-muted-foreground">Where ρ = density, m = mass, V = volume</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Material Densities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {materialDensities.map((material) => (
                      <div key={material.name} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <span className="text-sm font-medium">{material.name}</span>
                        <span className="text-sm text-muted-foreground">{material.density.toLocaleString()} kg/m³</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800 mb-1">Disclaimer</p>
                      <p className="text-sm text-amber-700">
                        Results are based on ideal conditions and standard unit conversions. Actual densities may vary
                        with temperature and pressure.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Density?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Density is a fundamental physical property that describes how much mass is contained within a given
                  volume of a substance. It is one of the most important characteristics used to identify and classify
                  materials in physics, chemistry, and engineering. The concept of density helps explain why some
                  objects float while others sink, why certain materials feel heavier than others of the same size, and
                  how different substances behave under various conditions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The SI unit for density is kilograms per cubic meter (kg/m³), though other common units include grams
                  per cubic centimeter (g/cm³) and pounds per cubic foot (lb/ft³). Water at 4°C has a density of exactly
                  1000 kg/m³ or 1 g/cm³, which serves as a convenient reference point for comparing the densities of
                  other substances.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Density Formula</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The density formula, ρ = m/V, expresses the relationship between three interconnected quantities:
                  density (ρ, the Greek letter rho), mass (m), and volume (V). This simple equation can be rearranged to
                  solve for any of the three variables when the other two are known. To find mass, multiply density by
                  volume (m = ρ × V). To find volume, divide mass by density (V = m/ρ).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding this relationship is crucial in many practical applications. Engineers use density
                  calculations to determine material requirements for construction projects. Scientists rely on density
                  measurements to identify unknown substances and verify the purity of samples. Even everyday decisions,
                  like choosing between different cooking oils or understanding why ice floats on water, involve the
                  concept of density.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Density</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While density is often treated as a constant property of a material, it can actually vary depending on
                  several factors. Temperature is the most common influence: as most materials heat up, they expand,
                  increasing their volume while the mass remains constant, thus decreasing density. This is why hot air
                  rises – it becomes less dense than the cooler air around it.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Pressure also affects density, particularly in gases and liquids. Increasing pressure compresses a
                  substance into a smaller volume, increasing its density. This principle is essential in understanding
                  atmospheric pressure changes, deep-sea conditions, and industrial processes. Additionally, the
                  composition and purity of materials affect their density – alloys, mixtures, and solutions have
                  densities that depend on the proportions of their components.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications of Density</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Density calculations have countless real-world applications across various fields. In shipping and
                  logistics, understanding density helps determine whether cargo will float or sink, and how much a
                  container ship can safely carry. Geologists use density measurements to identify minerals and
                  understand the structure of Earth's interior. In the food industry, density is used to assess the
                  quality and composition of products like milk, honey, and beverages.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Medical applications include using bone density measurements to diagnose osteoporosis and measuring
                  blood density for various diagnostic purposes. In manufacturing, density testing ensures material
                  quality and consistency. Even in everyday life, we rely on density principles when cooking (separating
                  fats from liquids), driving (understanding fuel efficiency), and swimming (knowing why we float better
                  in salt water than fresh water).
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
