"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Layers, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type ExcavationType = "rectangular" | "circular"
type UnitSystem = "metric" | "imperial"
type MaterialType = "sand" | "soil" | "gravel" | "custom"

interface BackfillResult {
  backfillVolume: number
  weight: number
  volumePerExcavation: number
  unit: string
  weightUnit: string
}

const materialDensities = {
  sand: 1600, // kg/m³
  soil: 1800, // kg/m³
  gravel: 1700, // kg/m³
  custom: 1600,
}

export function BackfillCalculator() {
  const [excavationType, setExcavationType] = useState<ExcavationType>("rectangular")
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [materialType, setMaterialType] = useState<MaterialType>("sand")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [depth, setDepth] = useState("")
  const [diameter, setDiameter] = useState("")
  const [numberOfExcavations, setNumberOfExcavations] = useState("1")
  const [compactionFactor, setCompactionFactor] = useState("1.2")
  const [wastage, setWastage] = useState("5")
  const [customDensity, setCustomDensity] = useState("")
  const [result, setResult] = useState<BackfillResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBackfill = () => {
    setError("")
    setResult(null)

    const depthNum = Number.parseFloat(depth)
    const numExcavations = Number.parseInt(numberOfExcavations) || 1
    const compactionNum = Number.parseFloat(compactionFactor)
    const wastageNum = Number.parseFloat(wastage) || 0

    if (isNaN(depthNum) || depthNum <= 0) {
      setError("Please enter a valid depth greater than 0")
      return
    }

    if (numExcavations <= 0) {
      setError("Number of excavations must be at least 1")
      return
    }

    if (isNaN(compactionNum) || compactionNum < 1) {
      setError("Compaction factor must be at least 1")
      return
    }

    let excavationVolume = 0
    const unit = unitSystem === "metric" ? "m³" : "ft³"

    if (excavationType === "rectangular") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)

      if (isNaN(lengthNum) || lengthNum <= 0 || isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter valid length and width greater than 0")
        return
      }

      excavationVolume = lengthNum * widthNum * depthNum
    } else if (excavationType === "circular") {
      const diameterNum = Number.parseFloat(diameter)

      if (isNaN(diameterNum) || diameterNum <= 0) {
        setError("Please enter a valid diameter greater than 0")
        return
      }

      const radius = diameterNum / 2
      excavationVolume = Math.PI * radius * radius * depthNum
    }

    const totalExcavationVolume = excavationVolume * numExcavations
    const backfillVolume = totalExcavationVolume * compactionNum
    const backfillWithWastage = backfillVolume * (1 + wastageNum / 100)

    // Calculate weight
    let density = materialDensities[materialType]
    if (materialType === "custom") {
      const customDensityNum = Number.parseFloat(customDensity)
      if (!isNaN(customDensityNum) && customDensityNum > 0) {
        density = customDensityNum
      }
    }

    // Convert density if imperial
    if (unitSystem === "imperial") {
      density = density * 0.0624279606 // Convert kg/m³ to lb/ft³
    }

    const weight = backfillWithWastage * density
    const weightUnit = unitSystem === "metric" ? "kg" : "lb"

    setResult({
      backfillVolume: Math.round(backfillWithWastage * 100) / 100,
      weight: Math.round(weight * 100) / 100,
      volumePerExcavation: Math.round((backfillWithWastage / numExcavations) * 100) / 100,
      unit,
      weightUnit,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setDepth("")
    setDiameter("")
    setNumberOfExcavations("1")
    setCompactionFactor("1.2")
    setWastage("5")
    setCustomDensity("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Backfill Volume: ${result.backfillVolume} ${result.unit}\nWeight: ${result.weight} ${result.weightUnit}\nPer Excavation: ${result.volumePerExcavation} ${result.unit}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Backfill Calculator Result",
          text: `Backfill Volume: ${result.backfillVolume} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setDepth("")
    setDiameter("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Backfill Calculator</CardTitle>
                    <CardDescription>Calculate backfill material quantity</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Excavation Type Selector */}
                <div className="space-y-2">
                  <Label>Excavation Type</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setExcavationType("rectangular")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        excavationType === "rectangular"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-border hover:border-amber-200"
                      }`}
                    >
                      Rectangular
                    </button>
                    <button
                      onClick={() => setExcavationType("circular")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        excavationType === "circular"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-border hover:border-amber-200"
                      }`}
                    >
                      Circular
                    </button>
                  </div>
                </div>

                {/* Material Type Selector */}
                <div className="space-y-2">
                  <Label>Backfill Material</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["sand", "soil", "gravel", "custom"] as MaterialType[]).map((type) => (
                      <button
                        key={type}
                        onClick={() => setMaterialType(type)}
                        className={`p-2 rounded-lg border-2 text-sm font-medium transition-colors capitalize ${
                          materialType === type
                            ? "border-amber-500 bg-amber-50 text-amber-700"
                            : "border-border hover:border-amber-200"
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom Density Input */}
                {materialType === "custom" && (
                  <div className="space-y-2">
                    <Label htmlFor="customDensity">
                      Custom Density ({unitSystem === "metric" ? "kg/m³" : "lb/ft³"})
                    </Label>
                    <Input
                      id="customDensity"
                      type="number"
                      placeholder="Enter material density"
                      value={customDensity}
                      onChange={(e) => setCustomDensity(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                )}

                {/* Dimension Inputs */}
                {excavationType === "circular" ? (
                  <div className="space-y-2">
                    <Label htmlFor="diameter">Diameter ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="diameter"
                      type="number"
                      placeholder="Enter diameter"
                      value={diameter}
                      onChange={(e) => setDiameter(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                      <Input
                        id="length"
                        type="number"
                        placeholder="Enter length"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                      <Input
                        id="width"
                        type="number"
                        placeholder="Enter width"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="depth">Depth ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="depth"
                    type="number"
                    placeholder="Enter depth"
                    value={depth}
                    onChange={(e) => setDepth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="number">Number of Excavations</Label>
                  <Input
                    id="number"
                    type="number"
                    placeholder="Enter number"
                    value={numberOfExcavations}
                    onChange={(e) => setNumberOfExcavations(e.target.value)}
                    min="1"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="compaction">Compaction Factor</Label>
                  <Input
                    id="compaction"
                    type="number"
                    placeholder="Default: 1.2"
                    value={compactionFactor}
                    onChange={(e) => setCompactionFactor(e.target.value)}
                    min="1"
                    step="0.1"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="wastage">Wastage (%)</Label>
                  <Input
                    id="wastage"
                    type="number"
                    placeholder="Default: 5%"
                    value={wastage}
                    onChange={(e) => setWastage(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBackfill} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Backfill
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total Backfill Volume</p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">{result.backfillVolume}</p>
                        <p className="text-lg font-semibold text-amber-700">{result.unit}</p>
                      </div>

                      <div className="pt-3 border-t border-amber-200 space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Total Weight:</span>
                          <span className="font-semibold text-amber-700">
                            {result.weight > 1000 && unitSystem === "metric"
                              ? `${(result.weight / 1000).toFixed(2)} tons`
                              : `${result.weight} ${result.weightUnit}`}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Per Excavation:</span>
                          <span className="font-semibold text-amber-700">
                            {result.volumePerExcavation} {result.unit}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Material Densities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-amber-50">
                      <span className="text-muted-foreground">Sand:</span>
                      <span className="font-semibold">1600 kg/m³</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-amber-50">
                      <span className="text-muted-foreground">Soil:</span>
                      <span className="font-semibold">1800 kg/m³</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-amber-50">
                      <span className="text-muted-foreground">Gravel:</span>
                      <span className="font-semibold">1700 kg/m³</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Compaction Factors</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Light compaction:</span>
                    <span className="font-semibold">1.1 - 1.15</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Standard compaction:</span>
                    <span className="font-semibold">1.2 - 1.25</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Heavy compaction:</span>
                    <span className="font-semibold">1.3 - 1.4</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Backfilling?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Backfilling is the process of refilling an excavation or trench with soil or other material after
                  construction work is complete. This is essential for foundations, utility trenches, and underground
                  structures. Proper backfilling provides structural support, prevents settlement, and restores the
                  site to its original grade or better.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The backfill material must be carefully selected and properly compacted to achieve the required
                  density and stability. Common backfill materials include native soil, sand, gravel, or engineered
                  fill depending on the application. The compaction factor accounts for the densification required to
                  achieve proper load-bearing capacity and prevent future settlement.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Backfill Quantity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Backfill quantity is calculated by determining the excavation volume and multiplying by the
                  compaction factor. The compaction factor (typically 1.2 to 1.4) accounts for the densification needed
                  to achieve proper compaction. For example, filling a 10 m³ excavation with a 1.2 compaction factor
                  requires 12 m³ of loose backfill material.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Additional wastage percentage (typically 5-10%) accounts for material loss during handling,
                  spreading, and compaction. The weight calculation helps determine hauling requirements and costs.
                  Different materials have different densities, affecting both the weight to transport and the
                  compaction characteristics on site.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Backfill Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Foundation backfilling supports basement walls and provides drainage around structures. Trench
                  backfilling protects underground utilities and restores surface stability. Engineered fill is used
                  where specific compaction and load-bearing requirements must be met. Each application requires
                  appropriate material selection and compaction methods.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Proper backfilling techniques include placing material in layers (lifts) of 6-12 inches, compacting
                  each layer before adding the next, and ensuring proper moisture content for optimal compaction.
                  Quality control testing verifies that the required density is achieved, preventing future settlement
                  and structural problems.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Backfill volumes are approximate. Actual quantities may vary due to soil type, compaction
                  requirements, moisture content, and site-specific conditions. Always consult with qualified engineers
                  and follow local building codes. Professional compaction testing ensures proper density and
                  load-bearing capacity for structural applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
