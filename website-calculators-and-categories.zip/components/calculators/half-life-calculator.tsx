"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Atom, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type CalculationMode = "remaining" | "time" | "halflife"
type TimeUnit = "seconds" | "minutes" | "hours" | "days" | "years"
type ProcessType = "radioactive" | "chemical" | "biological"

interface HalfLifeResult {
  calculatedValue: number
  unit: string
  halfLivesElapsed: number
  decayConstant: number
  remainingPercentage: number
  decayedPercentage: number
}

export function HalfLifeCalculator() {
  const [mode, setMode] = useState<CalculationMode>("remaining")
  const [initialQuantity, setInitialQuantity] = useState("")
  const [finalQuantity, setFinalQuantity] = useState("")
  const [timeElapsed, setTimeElapsed] = useState("")
  const [halfLife, setHalfLife] = useState("")
  const [timeUnit, setTimeUnit] = useState<TimeUnit>("years")
  const [processType, setProcessType] = useState<ProcessType>("radioactive")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<HalfLifeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDecayTable, setShowDecayTable] = useState(false)

  const timeUnitLabels: Record<TimeUnit, string> = {
    seconds: "Seconds",
    minutes: "Minutes",
    hours: "Hours",
    days: "Days",
    years: "Years",
  }

  const processTypeLabels: Record<ProcessType, string> = {
    radioactive: "Radioactive Decay",
    chemical: "Chemical Reaction",
    biological: "Biological Process",
  }

  const calculateHalfLife = () => {
    setError("")
    setResult(null)

    const N0 = Number.parseFloat(initialQuantity)
    const N = Number.parseFloat(finalQuantity)
    const t = Number.parseFloat(timeElapsed)
    const t_half = Number.parseFloat(halfLife)

    // Validation based on mode
    if (mode === "remaining") {
      if (isNaN(N0) || N0 <= 0) {
        setError("Please enter a valid initial quantity greater than 0")
        return
      }
      if (isNaN(t) || t < 0) {
        setError("Please enter a valid time elapsed (0 or greater)")
        return
      }
      if (isNaN(t_half) || t_half <= 0) {
        setError("Please enter a valid half-life greater than 0")
        return
      }

      // N = N₀ × (1/2)^(t / t₁/₂)
      const halfLivesElapsed = t / t_half
      const remainingQuantity = N0 * Math.pow(0.5, halfLivesElapsed)
      const decayConstant = Math.LN2 / t_half
      const remainingPercentage = (remainingQuantity / N0) * 100

      setResult({
        calculatedValue: remainingQuantity,
        unit: "quantity",
        halfLivesElapsed,
        decayConstant,
        remainingPercentage,
        decayedPercentage: 100 - remainingPercentage,
      })
    } else if (mode === "time") {
      if (isNaN(N0) || N0 <= 0) {
        setError("Please enter a valid initial quantity greater than 0")
        return
      }
      if (isNaN(N) || N <= 0) {
        setError("Please enter a valid final quantity greater than 0")
        return
      }
      if (N >= N0) {
        setError("Final quantity must be less than initial quantity")
        return
      }
      if (isNaN(t_half) || t_half <= 0) {
        setError("Please enter a valid half-life greater than 0")
        return
      }

      // t = t₁/₂ × ln(N₀/N) / ln(2)
      const timeRequired = t_half * Math.log(N0 / N) / Math.LN2
      const halfLivesElapsed = timeRequired / t_half
      const decayConstant = Math.LN2 / t_half
      const remainingPercentage = (N / N0) * 100

      setResult({
        calculatedValue: timeRequired,
        unit: timeUnitLabels[timeUnit],
        halfLivesElapsed,
        decayConstant,
        remainingPercentage,
        decayedPercentage: 100 - remainingPercentage,
      })
    } else if (mode === "halflife") {
      if (isNaN(N0) || N0 <= 0) {
        setError("Please enter a valid initial quantity greater than 0")
        return
      }
      if (isNaN(N) || N <= 0) {
        setError("Please enter a valid final quantity greater than 0")
        return
      }
      if (N >= N0) {
        setError("Final quantity must be less than initial quantity")
        return
      }
      if (isNaN(t) || t <= 0) {
        setError("Please enter a valid time elapsed greater than 0")
        return
      }

      // t₁/₂ = t × ln(2) / ln(N₀/N)
      const calculatedHalfLife = t * Math.LN2 / Math.log(N0 / N)
      const halfLivesElapsed = t / calculatedHalfLife
      const decayConstant = Math.LN2 / calculatedHalfLife
      const remainingPercentage = (N / N0) * 100

      setResult({
        calculatedValue: calculatedHalfLife,
        unit: timeUnitLabels[timeUnit],
        halfLivesElapsed,
        decayConstant,
        remainingPercentage,
        decayedPercentage: 100 - remainingPercentage,
      })
    }
  }

  const handleReset = () => {
    setInitialQuantity("")
    setFinalQuantity("")
    setTimeElapsed("")
    setHalfLife("")
    setTimeUnit("years")
    setProcessType("radioactive")
    setShowSteps(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDecayTable(false)
  }

  const handleCopy = async () => {
    if (result) {
      const modeLabels = {
        remaining: "Remaining Quantity",
        time: "Time Elapsed",
        halflife: "Half-Life",
      }
      const text = `Half-Life Calculation Result:
Mode: ${modeLabels[mode]}
Initial Quantity: ${initialQuantity}
${mode === "remaining" ? `Time Elapsed: ${timeElapsed} ${timeUnitLabels[timeUnit]}` : ""}
${mode === "remaining" ? `Half-Life: ${halfLife} ${timeUnitLabels[timeUnit]}` : ""}
${mode === "time" || mode === "halflife" ? `Final Quantity: ${finalQuantity}` : ""}
${mode === "time" ? `Half-Life: ${halfLife} ${timeUnitLabels[timeUnit]}` : ""}
${mode === "halflife" ? `Time Elapsed: ${timeElapsed} ${timeUnitLabels[timeUnit]}` : ""}
Result: ${formatNumber(result.calculatedValue)} ${mode === "remaining" ? "" : result.unit}
Half-Lives Elapsed: ${formatNumber(result.halfLivesElapsed)}
Remaining: ${formatNumber(result.remainingPercentage)}%`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Half-Life Calculation",
          text: `Half-Life Result: ${formatNumber(result.calculatedValue)} ${mode === "remaining" ? "" : result.unit} | Half-Lives: ${formatNumber(result.halfLivesElapsed)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const formatNumber = (num: number, decimals = 6) => {
    if (Math.abs(num) < 0.000001 && num !== 0) {
      return num.toExponential(4)
    }
    if (Math.abs(num) > 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: decimals })
  }

  const generateDecayTable = () => {
    const N0 = Number.parseFloat(initialQuantity)
    const t_half = mode === "halflife" && result ? result.calculatedValue : Number.parseFloat(halfLife)
    
    if (isNaN(N0) || isNaN(t_half) || t_half <= 0) return []

    const table = []
    for (let i = 0; i <= 10; i++) {
      const remaining = N0 * Math.pow(0.5, i)
      table.push({
        halfLives: i,
        time: i * t_half,
        remaining,
        percentage: (remaining / N0) * 100,
      })
    }
    return table
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Atom className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Half-Life Calculator</CardTitle>
                    <CardDescription>Calculate radioactive decay and kinetics</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Mode */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select value={mode} onValueChange={(v) => setMode(v as CalculationMode)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select calculation mode" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="remaining">Remaining Amount</SelectItem>
                      <SelectItem value="time">Time Elapsed</SelectItem>
                      <SelectItem value="halflife">Half-Life</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Process Type */}
                <div className="space-y-2">
                  <Label>Process Type</Label>
                  <Select value={processType} onValueChange={(v) => setProcessType(v as ProcessType)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select process type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="radioactive">Radioactive Decay</SelectItem>
                      <SelectItem value="chemical">Chemical Reaction</SelectItem>
                      <SelectItem value="biological">Biological Process</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Time Unit */}
                <div className="space-y-2">
                  <Label>Time Unit</Label>
                  <Select value={timeUnit} onValueChange={(v) => setTimeUnit(v as TimeUnit)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select time unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="seconds">Seconds</SelectItem>
                      <SelectItem value="minutes">Minutes</SelectItem>
                      <SelectItem value="hours">Hours</SelectItem>
                      <SelectItem value="days">Days</SelectItem>
                      <SelectItem value="years">Years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Initial Quantity */}
                <div className="space-y-2">
                  <Label htmlFor="initialQuantity">Initial Quantity (N₀)</Label>
                  <Input
                    id="initialQuantity"
                    type="number"
                    placeholder="Enter initial quantity"
                    value={initialQuantity}
                    onChange={(e) => setInitialQuantity(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Final Quantity - only for time and halflife modes */}
                {(mode === "time" || mode === "halflife") && (
                  <div className="space-y-2">
                    <Label htmlFor="finalQuantity">Final Quantity (N)</Label>
                    <Input
                      id="finalQuantity"
                      type="number"
                      placeholder="Enter final quantity"
                      value={finalQuantity}
                      onChange={(e) => setFinalQuantity(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Time Elapsed - only for remaining and halflife modes */}
                {(mode === "remaining" || mode === "halflife") && (
                  <div className="space-y-2">
                    <Label htmlFor="timeElapsed">Time Elapsed (t) in {timeUnitLabels[timeUnit]}</Label>
                    <Input
                      id="timeElapsed"
                      type="number"
                      placeholder={`Enter time in ${timeUnit}`}
                      value={timeElapsed}
                      onChange={(e) => setTimeElapsed(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Half-Life - only for remaining and time modes */}
                {(mode === "remaining" || mode === "time") && (
                  <div className="space-y-2">
                    <Label htmlFor="halfLife">Half-Life (t₁/₂) in {timeUnitLabels[timeUnit]}</Label>
                    <Input
                      id="halfLife"
                      type="number"
                      placeholder={`Enter half-life in ${timeUnit}`}
                      value={halfLife}
                      onChange={(e) => setHalfLife(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show Step-by-Step</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateHalfLife} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "remaining" ? "Remaining Quantity" : mode === "time" ? "Time Required" : "Half-Life"}
                      </p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">
                        {formatNumber(result.calculatedValue)}
                        {mode !== "remaining" && <span className="text-lg ml-1">{result.unit}</span>}
                      </p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Half-Lives Elapsed</p>
                        <p className="font-semibold text-purple-600">{formatNumber(result.halfLivesElapsed, 3)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Decay Constant (λ)</p>
                        <p className="font-semibold text-purple-600">{formatNumber(result.decayConstant)}</p>
                      </div>
                    </div>

                    {/* Visual Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Remaining</span>
                        <span>Decayed</span>
                      </div>
                      <div className="h-3 bg-red-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-purple-500 rounded-full transition-all duration-500"
                          style={{ width: `${Math.min(result.remainingPercentage, 100)}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span className="text-purple-600 font-medium">{formatNumber(result.remainingPercentage, 2)}%</span>
                        <span className="text-red-600 font-medium">{formatNumber(result.decayedPercentage, 2)}%</span>
                      </div>
                    </div>

                    {/* Step-by-Step Breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg">
                        <p className="font-medium text-sm mb-2">Calculation Steps:</p>
                        <div className="text-xs space-y-1 text-muted-foreground font-mono">
                          <p>N₀ = {initialQuantity}</p>
                          {mode === "remaining" && (
                            <>
                              <p>t = {timeElapsed} {timeUnit}</p>
                              <p>t₁/₂ = {halfLife} {timeUnit}</p>
                              <p className="pt-2 text-foreground font-semibold">Exponential Decay Formula:</p>
                              <p>N = N₀ × (1/2)^(t / t₁/₂)</p>
                              <p>N = {initialQuantity} × (1/2)^({timeElapsed} / {halfLife})</p>
                              <p>N = {initialQuantity} × (1/2)^({formatNumber(result.halfLivesElapsed, 4)})</p>
                              <p>N = {initialQuantity} × {formatNumber(Math.pow(0.5, result.halfLivesElapsed), 6)}</p>
                              <p className="text-purple-600 font-semibold">N = {formatNumber(result.calculatedValue)}</p>
                            </>
                          )}
                          {mode === "time" && (
                            <>
                              <p>N = {finalQuantity}</p>
                              <p>t₁/₂ = {halfLife} {timeUnit}</p>
                              <p className="pt-2 text-foreground font-semibold">Time Calculation:</p>
                              <p>t = t₁/₂ × ln(N₀/N) / ln(2)</p>
                              <p>t = {halfLife} × ln({initialQuantity}/{finalQuantity}) / ln(2)</p>
                              <p>t = {halfLife} × {formatNumber(Math.log(Number.parseFloat(initialQuantity) / Number.parseFloat(finalQuantity)), 4)} / 0.693</p>
                              <p className="text-purple-600 font-semibold">t = {formatNumber(result.calculatedValue)} {result.unit}</p>
                            </>
                          )}
                          {mode === "halflife" && (
                            <>
                              <p>N = {finalQuantity}</p>
                              <p>t = {timeElapsed} {timeUnit}</p>
                              <p className="pt-2 text-foreground font-semibold">Half-Life Calculation:</p>
                              <p>t₁/₂ = t × ln(2) / ln(N₀/N)</p>
                              <p>t₁/₂ = {timeElapsed} × ln(2) / ln({initialQuantity}/{finalQuantity})</p>
                              <p>t₁/₂ = {timeElapsed} × 0.693 / {formatNumber(Math.log(Number.parseFloat(initialQuantity) / Number.parseFloat(finalQuantity)), 4)}</p>
                              <p className="text-purple-600 font-semibold">t₁/₂ = {formatNumber(result.calculatedValue)} {result.unit}</p>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Decay Table */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowDecayTable(!showDecayTable)}
                        className="flex items-center justify-between w-full p-2 bg-white rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <span className="font-medium text-sm">Decay Schedule</span>
                        {showDecayTable ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                      {showDecayTable && (
                        <div className="mt-2 max-h-60 overflow-y-auto">
                          <table className="w-full text-xs">
                            <thead className="bg-gray-100 sticky top-0">
                              <tr>
                                <th className="p-2 text-left">Half-Lives</th>
                                <th className="p-2 text-right">Time</th>
                                <th className="p-2 text-right">Remaining</th>
                                <th className="p-2 text-right">%</th>
                              </tr>
                            </thead>
                            <tbody>
                              {generateDecayTable().map((row, idx) => (
                                <tr key={idx} className="border-b border-gray-100">
                                  <td className="p-2">{row.halfLives}</td>
                                  <td className="p-2 text-right font-mono">{formatNumber(row.time, 2)}</td>
                                  <td className="p-2 text-right font-mono">{formatNumber(row.remaining, 4)}</td>
                                  <td className="p-2 text-right font-mono text-purple-600">
                                    {formatNumber(row.percentage, 2)}%
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Half-Life Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-semibold text-purple-800 mb-1">Exponential Decay Law</p>
                    <p className="font-mono text-sm text-purple-700">N = N₀ × (1/2)^(t / t₁/₂)</p>
                    <p className="text-xs text-purple-600 mt-1">Or equivalently: N = N₀ × e^(-λt)</p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-semibold text-blue-800 mb-1">Decay Constant Relation</p>
                    <p className="font-mono text-sm text-blue-700">λ = ln(2) / t₁/₂ ≈ 0.693 / t₁/₂</p>
                    <p className="text-xs text-blue-600 mt-1">Links half-life to decay constant</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>N</strong> = Remaining quantity
                    </p>
                    <p>
                      <strong>N₀</strong> = Initial quantity
                    </p>
                    <p>
                      <strong>t</strong> = Time elapsed
                    </p>
                    <p>
                      <strong>t₁/₂</strong> = Half-life
                    </p>
                    <p>
                      <strong>λ</strong> = Decay constant
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Half-Lives</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Carbon-14</span>
                      <span className="font-mono text-purple-600">5,730 years</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Uranium-238</span>
                      <span className="font-mono text-purple-600">4.5 billion years</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Iodine-131</span>
                      <span className="font-mono text-purple-600">8.02 days</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Radon-222</span>
                      <span className="font-mono text-purple-600">3.82 days</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Technetium-99m</span>
                      <span className="font-mono text-purple-600">6 hours</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Caffeine (body)</span>
                      <span className="font-mono text-purple-600">5-6 hours</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Info className="h-4 w-4" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Half-life calculations assume ideal exponential decay. Actual decay behavior may vary due to
                    environmental or system-specific factors. For medical or safety-critical applications, consult
                    professional resources.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
