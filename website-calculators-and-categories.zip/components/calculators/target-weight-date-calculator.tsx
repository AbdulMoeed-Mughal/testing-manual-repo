"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Target,
  Info,
  Calendar,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type UnitSystem = "metric" | "imperial"

interface TargetWeightResult {
  targetDate: Date
  weeksRequired: number
  daysRequired: number
  totalWeightChange: number
  weeklyChange: number
  dailyChange: number
  isWeightLoss: boolean
  isSafe: boolean
  safetyMessage: string
}

export function TargetWeightDateCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [currentWeight, setCurrentWeight] = useState("")
  const [targetWeight, setTargetWeight] = useState("")
  const [weeklyChange, setWeeklyChange] = useState("")
  const [startDate, setStartDate] = useState(new Date().toISOString().split("T")[0])
  const [result, setResult] = useState<TargetWeightResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateTargetDate = () => {
    setError("")
    setResult(null)

    const currentWeightNum = Number.parseFloat(currentWeight)
    const targetWeightNum = Number.parseFloat(targetWeight)
    const weeklyChangeNum = Number.parseFloat(weeklyChange)

    if (isNaN(currentWeightNum) || currentWeightNum <= 0) {
      setError("Please enter a valid current weight greater than 0")
      return
    }

    if (isNaN(targetWeightNum) || targetWeightNum <= 0) {
      setError("Please enter a valid target weight greater than 0")
      return
    }

    if (isNaN(weeklyChangeNum) || weeklyChangeNum <= 0) {
      setError("Please enter a valid weekly weight change greater than 0")
      return
    }

    if (currentWeightNum === targetWeightNum) {
      setError("Current weight and target weight cannot be the same")
      return
    }

    const totalWeightChange = Math.abs(targetWeightNum - currentWeightNum)
    const isWeightLoss = targetWeightNum < currentWeightNum

    // Calculate weeks required
    const weeksRequired = totalWeightChange / weeklyChangeNum
    const daysRequired = Math.ceil(weeksRequired * 7)

    // Calculate target date
    const start = new Date(startDate)
    const targetDate = new Date(start)
    targetDate.setDate(targetDate.getDate() + daysRequired)

    // Calculate daily change
    const dailyChange = totalWeightChange / daysRequired

    // Check if the rate is safe
    // Safe limits: 0.5-1 kg/week for metric, 1-2 lb/week for imperial
    const safeMinMetric = 0.25
    const safeMaxMetric = 1.0
    const safeMinImperial = 0.5
    const safeMaxImperial = 2.0

    let isSafe = true
    let safetyMessage = ""

    if (unitSystem === "metric") {
      if (weeklyChangeNum > safeMaxMetric) {
        isSafe = false
        safetyMessage = `Weekly change of ${weeklyChangeNum} kg exceeds recommended safe limit of ${safeMaxMetric} kg/week`
      } else if (weeklyChangeNum < safeMinMetric) {
        safetyMessage = `Very gradual progress at ${weeklyChangeNum} kg/week - sustainable but slow`
      } else {
        safetyMessage = `${weeklyChangeNum} kg/week is within the recommended safe range`
      }
    } else {
      if (weeklyChangeNum > safeMaxImperial) {
        isSafe = false
        safetyMessage = `Weekly change of ${weeklyChangeNum} lb exceeds recommended safe limit of ${safeMaxImperial} lb/week`
      } else if (weeklyChangeNum < safeMinImperial) {
        safetyMessage = `Very gradual progress at ${weeklyChangeNum} lb/week - sustainable but slow`
      } else {
        safetyMessage = `${weeklyChangeNum} lb/week is within the recommended safe range`
      }
    }

    setResult({
      targetDate,
      weeksRequired: Math.round(weeksRequired * 10) / 10,
      daysRequired,
      totalWeightChange: Math.round(totalWeightChange * 10) / 10,
      weeklyChange: weeklyChangeNum,
      dailyChange: Math.round(dailyChange * 100) / 100,
      isWeightLoss,
      isSafe,
      safetyMessage,
    })
  }

  const handleReset = () => {
    setCurrentWeight("")
    setTargetWeight("")
    setWeeklyChange("")
    setStartDate(new Date().toISOString().split("T")[0])
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Target Weight Goal: ${result.isWeightLoss ? "Lose" : "Gain"} ${result.totalWeightChange} ${unitSystem === "metric" ? "kg" : "lb"} by ${result.targetDate.toLocaleDateString()} (${result.weeksRequired} weeks at ${result.weeklyChange} ${unitSystem === "metric" ? "kg" : "lb"}/week)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Target Weight Goal",
          text: `I'm planning to ${result.isWeightLoss ? "lose" : "gain"} ${result.totalWeightChange} ${unitSystem === "metric" ? "kg" : "lb"} by ${result.targetDate.toLocaleDateString()}!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setCurrentWeight("")
    setTargetWeight("")
    setWeeklyChange("")
    setResult(null)
    setError("")
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Target className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Target Weight Date Calculator</CardTitle>
                    <CardDescription>Estimate when you'll reach your goal weight</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Current Weight */}
                <div className="space-y-2">
                  <Label htmlFor="currentWeight">Current Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="currentWeight"
                    type="number"
                    placeholder={`Enter current weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={currentWeight}
                    onChange={(e) => setCurrentWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Target Weight */}
                <div className="space-y-2">
                  <Label htmlFor="targetWeight">Target Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="targetWeight"
                    type="number"
                    placeholder={`Enter target weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={targetWeight}
                    onChange={(e) => setTargetWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Weekly Change */}
                <div className="space-y-2">
                  <Label htmlFor="weeklyChange">
                    Weekly Weight Change ({unitSystem === "metric" ? "kg" : "lb"}/week)
                  </Label>
                  <Input
                    id="weeklyChange"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "0.5" : "1"}`}
                    value={weeklyChange}
                    onChange={(e) => setWeeklyChange(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">
                    Safe range: {unitSystem === "metric" ? "0.5-1 kg/week" : "1-2 lb/week"}
                  </p>
                </div>

                {/* Start Date */}
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date (optional)</Label>
                  <Input id="startDate" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTargetDate} className="w-full" size="lg">
                  Calculate Target Date
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.isSafe ? "bg-green-50 border-green-200" : "bg-yellow-50 border-yellow-200"
                    }`}
                  >
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        {result.isWeightLoss ? (
                          <TrendingDown className="h-5 w-5 text-blue-600" />
                        ) : (
                          <TrendingUp className="h-5 w-5 text-green-600" />
                        )}
                        <p className="text-sm text-muted-foreground">
                          {result.isWeightLoss ? "Weight Loss" : "Weight Gain"} Goal
                        </p>
                      </div>
                      <div className="flex items-center justify-center gap-2 mb-1">
                        <Calendar className="h-6 w-6 text-primary" />
                        <p className="text-2xl sm:text-3xl font-bold text-primary">{formatDate(result.targetDate)}</p>
                      </div>
                      <p className="text-lg font-semibold text-muted-foreground">
                        {result.weeksRequired} weeks ({result.daysRequired} days)
                      </p>
                    </div>

                    {/* Safety Message */}
                    <div
                      className={`mt-3 p-2 rounded-lg text-sm ${
                        result.isSafe ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {!result.isSafe && <AlertTriangle className="h-4 w-4 flex-shrink-0" />}
                        {result.safetyMessage}
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          {showDetails ? (
                            <>
                              <ChevronUp className="h-4 w-4 mr-1" /> Hide Details
                            </>
                          ) : (
                            <>
                              <ChevronDown className="h-4 w-4 mr-1" /> Show Details
                            </>
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="p-2 bg-background rounded-lg">
                            <p className="text-muted-foreground">Total Change</p>
                            <p className="font-semibold">
                              {result.totalWeightChange} {unitSystem === "metric" ? "kg" : "lb"}
                            </p>
                          </div>
                          <div className="p-2 bg-background rounded-lg">
                            <p className="text-muted-foreground">Weekly Rate</p>
                            <p className="font-semibold">
                              {result.weeklyChange} {unitSystem === "metric" ? "kg" : "lb"}/week
                            </p>
                          </div>
                          <div className="p-2 bg-background rounded-lg">
                            <p className="text-muted-foreground">Daily Rate</p>
                            <p className="font-semibold">
                              ~{result.dailyChange} {unitSystem === "metric" ? "kg" : "lb"}/day
                            </p>
                          </div>
                          <div className="p-2 bg-background rounded-lg">
                            <p className="text-muted-foreground">Months</p>
                            <p className="font-semibold">
                              ~{Math.round((result.weeksRequired / 4.33) * 10) / 10} months
                            </p>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Safe Weight Change Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-green-700">Recommended</span>
                        <span className="text-sm text-green-600">
                          {unitSystem === "metric" ? "0.5-1 kg/week" : "1-2 lb/week"}
                        </span>
                      </div>
                      <p className="text-xs text-green-600 mt-1">Sustainable and healthy pace</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-blue-700">Gradual</span>
                        <span className="text-sm text-blue-600">
                          {unitSystem === "metric" ? "0.25-0.5 kg/week" : "0.5-1 lb/week"}
                        </span>
                      </div>
                      <p className="text-xs text-blue-600 mt-1">Very sustainable, slower results</p>
                    </div>
                    <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-yellow-700">Aggressive</span>
                        <span className="text-sm text-yellow-600">
                          {unitSystem === "metric" ? ">1 kg/week" : ">2 lb/week"}
                        </span>
                      </div>
                      <p className="text-xs text-yellow-600 mt-1">Not recommended long-term</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Weeks = |Target - Current| ÷ Weekly Rate</p>
                    <p className="font-semibold text-foreground">Target Date = Start + (Weeks × 7 days)</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Target Weight Planning</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Setting a realistic target weight date is crucial for successful weight management. This calculator
                  helps you estimate when you'll reach your goal weight based on your current weight, target weight, and
                  desired weekly rate of change. By understanding the timeline, you can set achievable milestones and
                  maintain motivation throughout your journey.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key to sustainable weight change is choosing a realistic weekly rate. Health experts generally
                  recommend losing or gaining {unitSystem === "metric" ? "0.5 to 1 kg" : "1 to 2 pounds"} per week. This
                  pace allows your body to adjust gradually, helps preserve muscle mass during weight loss, and makes it
                  easier to maintain your new weight long-term.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Reaching Your Target Weight</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">For Weight Loss</h4>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                      <li>Create a moderate calorie deficit (500-750 cal/day)</li>
                      <li>Prioritize protein to preserve muscle</li>
                      <li>Include strength training exercises</li>
                      <li>Stay hydrated and get enough sleep</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">For Weight Gain</h4>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                      <li>Create a moderate calorie surplus (300-500 cal/day)</li>
                      <li>Focus on nutrient-dense foods</li>
                      <li>Incorporate resistance training</li>
                      <li>Eat frequent, balanced meals</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Weight change predictions are estimates and may vary based on individual metabolism, activity
                      level, adherence to plan, and other factors. This calculator provides general guidance only.
                      Consult a healthcare professional or registered dietitian before starting any weight management
                      program, especially if you have underlying health conditions.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
