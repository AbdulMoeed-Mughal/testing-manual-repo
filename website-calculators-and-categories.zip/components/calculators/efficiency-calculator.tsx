"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Gauge, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type EnergyUnit = "J" | "kJ" | "cal" | "BTU"

interface EfficiencyResult {
  efficiency: number
  efficiencyDecimal: number
  outputEnergy: number
  inputEnergy: number
  energyLoss: number
  category: string
  color: string
  bgColor: string
}

export function EfficiencyCalculator() {
  const [outputEnergy, setOutputEnergy] = useState("")
  const [inputEnergy, setInputEnergy] = useState("")
  const [energyUnit, setEnergyUnit] = useState<EnergyUnit>("J")
  const [result, setResult] = useState<EfficiencyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const energyUnits: { value: EnergyUnit; label: string }[] = [
    { value: "J", label: "Joules (J)" },
    { value: "kJ", label: "Kilojoules (kJ)" },
    { value: "cal", label: "Calories (cal)" },
    { value: "BTU", label: "BTU" },
  ]

  const calculateEfficiency = () => {
    setError("")
    setResult(null)

    const eOut = Number.parseFloat(outputEnergy)
    const eIn = Number.parseFloat(inputEnergy)

    if (isNaN(eOut) || eOut < 0) {
      setError("Please enter a valid output energy (must be non-negative)")
      return
    }

    if (isNaN(eIn) || eIn <= 0) {
      setError("Please enter a valid input energy (must be greater than 0)")
      return
    }

    if (eOut > eIn) {
      setError("Output energy cannot exceed input energy (violates conservation of energy)")
      return
    }

    const efficiencyDecimal = eOut / eIn
    const efficiency = efficiencyDecimal * 100
    const energyLoss = eIn - eOut

    let category: string
    let color: string
    let bgColor: string

    if (efficiency >= 90) {
      category = "Excellent"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (efficiency >= 70) {
      category = "Good"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (efficiency >= 50) {
      category = "Moderate"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (efficiency >= 30) {
      category = "Low"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Poor"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      efficiency: Math.round(efficiency * 100) / 100,
      efficiencyDecimal: Math.round(efficiencyDecimal * 10000) / 10000,
      outputEnergy: eOut,
      inputEnergy: eIn,
      energyLoss,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setOutputEnergy("")
    setInputEnergy("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Efficiency: ${result.efficiency}% (${result.category})\nInput: ${result.inputEnergy} ${energyUnit}\nOutput: ${result.outputEnergy} ${energyUnit}\nLoss: ${result.energyLoss} ${energyUnit}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Efficiency Calculator Result",
          text: `Efficiency: ${result.efficiency}% (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Efficiency Calculator</CardTitle>
                    <CardDescription>Calculate machine or process efficiency</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Energy Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="energyUnit">Energy Unit</Label>
                  <select
                    id="energyUnit"
                    value={energyUnit}
                    onChange={(e) => setEnergyUnit(e.target.value as EnergyUnit)}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                  >
                    {energyUnits.map((unit) => (
                      <option key={unit.value} value={unit.value}>
                        {unit.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Input Energy */}
                <div className="space-y-2">
                  <Label htmlFor="inputEnergy">Input Energy (E_in) [{energyUnit}]</Label>
                  <Input
                    id="inputEnergy"
                    type="number"
                    placeholder="Enter input energy"
                    value={inputEnergy}
                    onChange={(e) => setInputEnergy(e.target.value)}
                    min="0"
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">Total energy supplied to the system</p>
                </div>

                {/* Output Energy */}
                <div className="space-y-2">
                  <Label htmlFor="outputEnergy">Useful Output Energy (E_out) [{energyUnit}]</Label>
                  <Input
                    id="outputEnergy"
                    type="number"
                    placeholder="Enter output energy"
                    value={outputEnergy}
                    onChange={(e) => setOutputEnergy(e.target.value)}
                    min="0"
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">Useful work or energy produced</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateEfficiency} className="w-full" size="lg">
                  Calculate Efficiency
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Efficiency</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.efficiency}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-sm text-muted-foreground mt-2">Decimal: {result.efficiencyDecimal}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 pt-4 border-t border-current/10 grid grid-cols-2 gap-4 text-sm">
                      <div className="text-center">
                        <p className="text-muted-foreground">Energy Loss</p>
                        <p className="font-semibold">
                          {result.energyLoss.toFixed(2)} {energyUnit}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground">Loss Percentage</p>
                        <p className="font-semibold">{(100 - result.efficiency).toFixed(2)}%</p>
                      </div>
                    </div>

                    {/* Step-by-step breakdown toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p className="font-medium">Step-by-step:</p>
                        <p>1. Formula: η = (E_out / E_in) × 100%</p>
                        <p>2. Substituting values:</p>
                        <p className="pl-4">
                          η = ({result.outputEnergy} / {result.inputEnergy}) × 100%
                        </p>
                        <p>3. Calculate ratio:</p>
                        <p className="pl-4">η = {result.efficiencyDecimal} × 100%</p>
                        <p>
                          4. Result: <strong>η = {result.efficiency}%</strong>
                        </p>
                        <p className="mt-2">
                          5. Energy Loss = E_in − E_out = {result.inputEnergy} − {result.outputEnergy} ={" "}
                          <strong>
                            {result.energyLoss.toFixed(2)} {energyUnit}
                          </strong>
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Efficiency Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-sm text-green-600">≥ 90%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-sm text-blue-600">70% – 89%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate</span>
                      <span className="text-sm text-yellow-600">50% – 69%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Low</span>
                      <span className="text-sm text-orange-600">30% – 49%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Poor</span>
                      <span className="text-sm text-red-600">{"< 30%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Efficiency Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">η = (E_out / E_in) × 100%</p>
                  </div>
                  <p>Where:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>
                      <strong>η</strong> = Efficiency (percentage)
                    </li>
                    <li>
                      <strong>E_out</strong> = Useful output energy or work
                    </li>
                    <li>
                      <strong>E_in</strong> = Total input energy
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Efficiencies</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Electric Motor</span>
                      <span className="font-medium">85-95%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>LED Light Bulb</span>
                      <span className="font-medium">80-90%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Gas Turbine</span>
                      <span className="font-medium">30-40%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Car Engine</span>
                      <span className="font-medium">20-30%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Incandescent Bulb</span>
                      <span className="font-medium">5-10%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Efficiency?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Efficiency is a measure of how effectively a machine, engine, or process converts input energy into
                  useful output energy or work. It is expressed as a percentage or decimal value between 0 and 1 (or 0%
                  and 100%). A higher efficiency means less energy is wasted as heat, sound, friction, or other unusable
                  forms.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  No real machine can achieve 100% efficiency due to the second law of thermodynamics. Some energy is
                  always lost to the environment, primarily as waste heat. Understanding efficiency helps engineers
                  design better systems, reduce energy consumption, and minimize environmental impact.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Efficiency Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Efficiency calculations are fundamental in various engineering and scientific fields:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Power Generation:</strong> Evaluating thermal power plants, hydroelectric dams, and
                    renewable energy systems
                  </li>
                  <li>
                    <strong>Transportation:</strong> Comparing fuel efficiency of vehicles and engines
                  </li>
                  <li>
                    <strong>HVAC Systems:</strong> Rating heating and cooling equipment performance
                  </li>
                  <li>
                    <strong>Manufacturing:</strong> Optimizing industrial processes and machinery
                  </li>
                  <li>
                    <strong>Electronics:</strong> Designing power supplies and energy conversion circuits
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Efficiency calculations are based on ideal or measured energy values.
                  Actual performance may vary due to losses, friction, or system imperfections. Consult engineering
                  references for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
