"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Activity, Info, Dumbbell, Scale } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type FormulaType = "james" | "boer" | "hume"

interface LBMResult {
  lbm: number
  fatMass: number
  lbmPercentage: number
  formula: string
}

export function LeanBodyMassCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [formula, setFormula] = useState<FormulaType>("james")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [bodyFatPercentage, setBodyFatPercentage] = useState("")
  const [useBodyFat, setUseBodyFat] = useState(false)
  const [result, setResult] = useState<LBMResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateLBM = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    let lbm: number
    let formulaName: string

    if (useBodyFat && bodyFatPercentage) {
      const bf = Number.parseFloat(bodyFatPercentage)
      if (isNaN(bf) || bf < 0 || bf > 100) {
        setError("Body fat percentage must be between 0 and 100")
        return
      }
      lbm = weightInKg * (1 - bf / 100)
      formulaName = "Body Fat Method"
    } else {
      const heightInM = heightInCm / 100

      switch (formula) {
        case "james":
          if (gender === "male") {
            lbm = 1.1 * weightInKg - 128 * Math.pow(weightInKg / heightInCm, 2)
          } else {
            lbm = 1.07 * weightInKg - 148 * Math.pow(weightInKg / heightInCm, 2)
          }
          formulaName = "James Formula"
          break
        case "boer":
          if (gender === "male") {
            lbm = 0.407 * weightInKg + 0.267 * heightInCm - 19.2
          } else {
            lbm = 0.252 * weightInKg + 0.473 * heightInCm - 48.3
          }
          formulaName = "Boer Formula"
          break
        case "hume":
          if (gender === "male") {
            lbm = 0.3281 * weightInKg + 0.33929 * heightInCm - 29.5336
          } else {
            lbm = 0.29569 * weightInKg + 0.41813 * heightInCm - 43.2933
          }
          formulaName = "Hume Formula"
          break
        default:
          lbm = 0
          formulaName = ""
      }
    }

    const fatMass = weightInKg - lbm
    const lbmPercentage = (lbm / weightInKg) * 100

    const displayLBM = unitSystem === "imperial" ? lbm * 2.20462 : lbm
    const displayFatMass = unitSystem === "imperial" ? fatMass * 2.20462 : fatMass

    setResult({
      lbm: Math.round(displayLBM * 10) / 10,
      fatMass: Math.round(displayFatMass * 10) / 10,
      lbmPercentage: Math.round(lbmPercentage * 10) / 10,
      formula: formulaName,
    })
  }

  const handleReset = () => {
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setBodyFatPercentage("")
    setUseBodyFat(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "kg" : "lb"
      await navigator.clipboard.writeText(
        `My Lean Body Mass is ${result.lbm} ${unit} (${result.lbmPercentage}%) using ${result.formula}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const unit = unitSystem === "metric" ? "kg" : "lb"
      try {
        await navigator.share({
          title: "My Lean Body Mass Result",
          text: `I calculated my Lean Body Mass using CalcHub! My LBM is ${result.lbm} ${unit} (${result.lbmPercentage}%)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  const getLBMCategory = (percentage: number, gender: Gender) => {
    if (gender === "male") {
      if (percentage >= 85)
        return { label: "Athletic", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
      if (percentage >= 80) return { label: "Fit", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
      if (percentage >= 75)
        return { label: "Average", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
      return { label: "Below Average", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    } else {
      if (percentage >= 80)
        return { label: "Athletic", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
      if (percentage >= 75) return { label: "Fit", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
      if (percentage >= 68)
        return { label: "Average", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
      return { label: "Below Average", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    }
  }

  const category = result ? getLBMCategory(result.lbmPercentage, gender) : null

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Dumbbell className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Lean Body Mass Calculator</CardTitle>
                    <CardDescription>Calculate your lean body mass</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Formula Selection */}
                <div className="space-y-2">
                  <Label>Calculation Method</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "james", label: "James" },
                      { value: "boer", label: "Boer" },
                      { value: "hume", label: "Hume" },
                    ].map((f) => (
                      <Button
                        key={f.value}
                        type="button"
                        variant={formula === f.value && !useBodyFat ? "default" : "outline"}
                        onClick={() => {
                          setFormula(f.value as FormulaType)
                          setUseBodyFat(false)
                        }}
                        className="w-full text-xs sm:text-sm"
                        disabled={useBodyFat}
                      >
                        {f.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Body Fat Percentage (Optional) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="bodyFat">Body Fat % (optional)</Label>
                    <button
                      type="button"
                      onClick={() => setUseBodyFat(!useBodyFat)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        useBodyFat ? "bg-primary" : "bg-muted"
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform ${
                          useBodyFat ? "translate-x-6" : "translate-x-1"
                        }`}
                      />
                    </button>
                  </div>
                  {useBodyFat && (
                    <Input
                      id="bodyFat"
                      type="number"
                      placeholder="Enter body fat percentage"
                      value={bodyFatPercentage}
                      onChange={(e) => setBodyFatPercentage(e.target.value)}
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  )}
                  <p className="text-xs text-muted-foreground">
                    {useBodyFat
                      ? "Using your body fat percentage for direct calculation"
                      : "Enable to use body fat percentage instead of formula"}
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLBM} className="w-full" size="lg">
                  Calculate Lean Body Mass
                </Button>

                {/* Result */}
                {result && category && (
                  <div className={`p-4 rounded-xl border-2 ${category.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Lean Body Mass</p>
                      <p className={`text-5xl font-bold ${category.color} mb-2`}>
                        {result.lbm} <span className="text-2xl">{unitSystem === "metric" ? "kg" : "lb"}</span>
                      </p>
                      <p className={`text-lg font-semibold ${category.color}`}>
                        {result.lbmPercentage}% of body weight
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">{category.label}</p>
                    </div>

                    {/* Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          {showBreakdown ? "Hide" : "Show"} Breakdown
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2 text-sm">
                        <div className="flex justify-between p-2 bg-background/50 rounded">
                          <span>Formula Used:</span>
                          <span className="font-medium">{result.formula}</span>
                        </div>
                        <div className="flex justify-between p-2 bg-background/50 rounded">
                          <span>Lean Body Mass:</span>
                          <span className="font-medium">
                            {result.lbm} {unitSystem === "metric" ? "kg" : "lb"}
                          </span>
                        </div>
                        <div className="flex justify-between p-2 bg-background/50 rounded">
                          <span>Fat Mass:</span>
                          <span className="font-medium">
                            {result.fatMass} {unitSystem === "metric" ? "kg" : "lb"}
                          </span>
                        </div>
                        <div className="flex justify-between p-2 bg-background/50 rounded">
                          <span>LBM Percentage:</span>
                          <span className="font-medium">{result.lbmPercentage}%</span>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">LBM Categories</CardTitle>
                  <CardDescription>
                    Based on lean body mass percentage ({gender === "male" ? "Male" : "Female"})
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {gender === "male" ? (
                      <>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                          <span className="font-medium text-green-700">Athletic</span>
                          <span className="text-sm text-green-600">≥ 85%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                          <span className="font-medium text-blue-700">Fit</span>
                          <span className="text-sm text-blue-600">80% – 84%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                          <span className="font-medium text-yellow-700">Average</span>
                          <span className="text-sm text-yellow-600">75% – 79%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                          <span className="font-medium text-red-700">Below Average</span>
                          <span className="text-sm text-red-600">{"< 75%"}</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                          <span className="font-medium text-green-700">Athletic</span>
                          <span className="text-sm text-green-600">≥ 80%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                          <span className="font-medium text-blue-700">Fit</span>
                          <span className="text-sm text-blue-600">75% – 79%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                          <span className="font-medium text-yellow-700">Average</span>
                          <span className="text-sm text-yellow-600">68% – 74%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                          <span className="font-medium text-red-700">Below Average</span>
                          <span className="text-sm text-red-600">{"< 68%"}</span>
                        </div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">LBM Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">James Formula</p>
                    <p className="text-xs font-mono">
                      Male: 1.1×W − 128×(W/H)²
                      <br />
                      Female: 1.07×W − 148×(W/H)²
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Boer Formula</p>
                    <p className="text-xs font-mono">
                      Male: 0.407×W + 0.267×H − 19.2
                      <br />
                      Female: 0.252×W + 0.473×H − 48.3
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Hume Formula</p>
                    <p className="text-xs font-mono">
                      Male: 0.328×W + 0.339×H − 29.5
                      <br />
                      Female: 0.296×W + 0.418×H − 43.3
                    </p>
                  </div>
                  <p className="text-xs">W = Weight (kg), H = Height (cm)</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Lean Body Mass (LBM)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Lean Body Mass (LBM), also known as Fat-Free Mass (FFM), represents the total weight of your body
                  minus all the weight due to fat mass. This includes the weight of your bones, muscles, organs, skin,
                  blood, and water. LBM is an important metric for understanding your body composition and is
                  particularly useful for athletes, fitness enthusiasts, and those monitoring their health.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Unlike total body weight, which can fluctuate due to water retention and other factors, lean body mass
                  provides a clearer picture of your muscle mass and overall metabolic health. Higher lean body mass is
                  generally associated with a higher basal metabolic rate, meaning your body burns more calories at
                  rest.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Formulas</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several validated formulas exist for estimating lean body mass, each developed through different
                  research methodologies. The <strong>James Formula</strong> is widely used and considers the
                  relationship between weight and height squared. The <strong>Boer Formula</strong> uses a linear
                  combination of weight and height with gender-specific constants. The <strong>Hume Formula</strong>
                  was derived from regression analysis and provides another validated approach.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Each formula may give slightly different results, which is normal as they were developed using
                  different study populations. For the most accurate assessment, consider comparing results from
                  multiple formulas or using direct measurement methods like DEXA scans or bioelectrical impedance.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Why Lean Body Mass Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Tracking lean body mass is valuable for several reasons. It helps you understand whether weight
                  changes are due to muscle gain or fat loss, which is crucial for effective fitness planning. Athletes
                  often monitor LBM to optimize performance and ensure they&apos;re building muscle rather than just
                  losing weight.
                </p>
                <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-amber-800 text-sm">
                    <strong>Disclaimer:</strong> Lean body mass calculations are estimates and may vary based on
                    individual body composition and measurement method. For precise measurements, consult a healthcare
                    professional or use clinical assessment methods like DEXA scans.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
