"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Binary,
  Info,
  AlertTriangle,
  Calculator,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type Operation =
  | "add"
  | "subtract"
  | "multiply"
  | "divide"
  | "modulo"
  | "and"
  | "or"
  | "xor"
  | "not"
  | "left-shift"
  | "right-shift"

interface BinaryResult {
  binary: string
  decimal: number
  hexadecimal: string
  octal: string
  steps: string[]
  overflow: boolean
  underflow: boolean
}

export function BinaryCalculator() {
  const [inputA, setInputA] = useState("")
  const [inputB, setInputB] = useState("")
  const [operation, setOperation] = useState<Operation>("add")
  const [inputMode, setInputMode] = useState<"binary" | "decimal">("binary")
  const [bitWidth, setBitWidth] = useState<string>("32")
  const [showSteps, setShowSteps] = useState(false)
  const [useTwosComplement, setUseTwosComplement] = useState(true)
  const [result, setResult] = useState<BinaryResult | null>(null)
  const [copied, setCopied] = useState<string | null>(null)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(false)

  const isUnaryOperation = operation === "not"
  const isShiftOperation = operation === "left-shift" || operation === "right-shift"

  const validateBinary = (str: string): boolean => {
    return /^-?[01]+$/.test(str)
  }

  const toBinary = (num: number, bits: number): string => {
    if (num >= 0) {
      return num.toString(2).padStart(bits, "0")
    } else {
      // Two's complement for negative numbers
      const positive = Math.abs(num)
      const binary = positive.toString(2).padStart(bits, "0")
      // Invert bits
      let inverted = ""
      for (const bit of binary) {
        inverted += bit === "0" ? "1" : "0"
      }
      // Add 1
      let carry = 1
      let result = ""
      for (let i = inverted.length - 1; i >= 0; i--) {
        const sum = Number.parseInt(inverted[i]) + carry
        result = (sum % 2).toString() + result
        carry = Math.floor(sum / 2)
      }
      return result
    }
  }

  const fromBinary = (binary: string, bits: number, signed: boolean): number => {
    if (!signed || binary[0] === "0") {
      return Number.parseInt(binary, 2)
    }
    // Two's complement negative number
    let inverted = ""
    for (const bit of binary) {
      inverted += bit === "0" ? "1" : "0"
    }
    return -(Number.parseInt(inverted, 2) + 1)
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const bits = Number.parseInt(bitWidth)
    let numA: number
    let numB: number
    const steps: string[] = []

    // Parse input A
    if (inputMode === "binary") {
      if (!validateBinary(inputA)) {
        setError("Input A must be a valid binary number (0s and 1s only)")
        return
      }
      const isNegative = inputA.startsWith("-")
      const binaryA = isNegative ? inputA.slice(1) : inputA
      numA = isNegative ? -Number.parseInt(binaryA, 2) : Number.parseInt(binaryA, 2)
      steps.push(`Input A: ${inputA} (binary) = ${numA} (decimal)`)
    } else {
      numA = Number.parseInt(inputA)
      if (isNaN(numA)) {
        setError("Input A must be a valid decimal number")
        return
      }
      steps.push(`Input A: ${numA} (decimal) = ${toBinary(numA, bits)} (binary)`)
    }

    // Parse input B for binary operations
    if (!isUnaryOperation) {
      if (inputMode === "binary") {
        if (!validateBinary(inputB)) {
          setError("Input B must be a valid binary number (0s and 1s only)")
          return
        }
        const isNegative = inputB.startsWith("-")
        const binaryB = isNegative ? inputB.slice(1) : inputB
        numB = isNegative ? -Number.parseInt(binaryB, 2) : Number.parseInt(binaryB, 2)
        steps.push(`Input B: ${inputB} (binary) = ${numB} (decimal)`)
      } else {
        numB = Number.parseInt(inputB)
        if (isNaN(numB)) {
          setError("Input B must be a valid decimal number")
          return
        }
        steps.push(`Input B: ${numB} (decimal) = ${toBinary(numB, bits)} (binary)`)
      }
    } else {
      numB = 0
    }

    let resultNum: number
    let overflow = false
    let underflow = false
    const maxVal = Math.pow(2, bits - 1) - 1
    const minVal = -Math.pow(2, bits - 1)

    // Perform operation
    switch (operation) {
      case "add":
        resultNum = numA + numB
        steps.push(`Operation: ${numA} + ${numB} = ${resultNum}`)
        break
      case "subtract":
        resultNum = numA - numB
        steps.push(`Operation: ${numA} - ${numB} = ${resultNum}`)
        break
      case "multiply":
        resultNum = numA * numB
        steps.push(`Operation: ${numA} × ${numB} = ${resultNum}`)
        break
      case "divide":
        if (numB === 0) {
          setError("Cannot divide by zero")
          return
        }
        resultNum = Math.trunc(numA / numB)
        steps.push(`Operation: ${numA} ÷ ${numB} = ${resultNum} (integer division)`)
        break
      case "modulo":
        if (numB === 0) {
          setError("Cannot perform modulo by zero")
          return
        }
        resultNum = numA % numB
        steps.push(`Operation: ${numA} mod ${numB} = ${resultNum}`)
        break
      case "and":
        resultNum = numA & numB
        steps.push(`Operation: ${numA} AND ${numB}`)
        steps.push(`Binary: ${toBinary(numA, bits)} AND ${toBinary(numB, bits)}`)
        steps.push(`Result: ${toBinary(resultNum, bits)} = ${resultNum}`)
        break
      case "or":
        resultNum = numA | numB
        steps.push(`Operation: ${numA} OR ${numB}`)
        steps.push(`Binary: ${toBinary(numA, bits)} OR ${toBinary(numB, bits)}`)
        steps.push(`Result: ${toBinary(resultNum, bits)} = ${resultNum}`)
        break
      case "xor":
        resultNum = numA ^ numB
        steps.push(`Operation: ${numA} XOR ${numB}`)
        steps.push(`Binary: ${toBinary(numA, bits)} XOR ${toBinary(numB, bits)}`)
        steps.push(`Result: ${toBinary(resultNum, bits)} = ${resultNum}`)
        break
      case "not":
        resultNum = ~numA
        steps.push(`Operation: NOT ${numA}`)
        steps.push(`Binary: NOT ${toBinary(numA, bits)}`)
        steps.push(`Result: ${toBinary(resultNum, bits)} = ${resultNum}`)
        break
      case "left-shift":
        resultNum = numA << numB
        steps.push(`Operation: ${numA} << ${numB}`)
        steps.push(`Binary: ${toBinary(numA, bits)} shifted left by ${numB} positions`)
        steps.push(`Result: ${toBinary(resultNum, bits)} = ${resultNum}`)
        break
      case "right-shift":
        resultNum = numA >> numB
        steps.push(`Operation: ${numA} >> ${numB}`)
        steps.push(`Binary: ${toBinary(numA, bits)} shifted right by ${numB} positions`)
        steps.push(`Result: ${toBinary(resultNum, bits)} = ${resultNum}`)
        break
      default:
        resultNum = 0
    }

    // Check overflow/underflow
    if (useTwosComplement) {
      if (resultNum > maxVal) {
        overflow = true
        steps.push(`⚠️ Overflow detected: ${resultNum} exceeds max value ${maxVal} for ${bits}-bit signed`)
      }
      if (resultNum < minVal) {
        underflow = true
        steps.push(`⚠️ Underflow detected: ${resultNum} is below min value ${minVal} for ${bits}-bit signed`)
      }
    }

    // Format result
    const resultBinary = toBinary(resultNum, bits)
    const resultHex = (resultNum >>> 0)
      .toString(16)
      .toUpperCase()
      .padStart(Math.ceil(bits / 4), "0")
    const resultOctal = (resultNum >>> 0).toString(8)

    setResult({
      binary: resultBinary,
      decimal: resultNum,
      hexadecimal: resultHex,
      octal: resultOctal,
      steps,
      overflow,
      underflow,
    })
  }

  const handleReset = () => {
    setInputA("")
    setInputB("")
    setOperation("add")
    setResult(null)
    setError("")
    setCopied(null)
    setStepsOpen(false)
  }

  const handleCopy = async (value: string, type: string) => {
    await navigator.clipboard.writeText(value)
    setCopied(type)
    setTimeout(() => setCopied(null), 2000)
  }

  const getOperationLabel = (op: Operation): string => {
    const labels: Record<Operation, string> = {
      add: "Addition (+)",
      subtract: "Subtraction (−)",
      multiply: "Multiplication (×)",
      divide: "Division (÷)",
      modulo: "Modulo (%)",
      and: "Bitwise AND (&)",
      or: "Bitwise OR (|)",
      xor: "Bitwise XOR (^)",
      not: "Bitwise NOT (~)",
      "left-shift": "Left Shift (<<)",
      "right-shift": "Right Shift (>>)",
    }
    return labels[op]
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Binary className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Binary Calculator</CardTitle>
                    <CardDescription>Binary arithmetic and bitwise operations</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between">
                  <Label>Input Mode</Label>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm ${inputMode === "binary" ? "font-medium" : "text-muted-foreground"}`}>
                      Binary
                    </span>
                    <Switch
                      checked={inputMode === "decimal"}
                      onCheckedChange={(checked) => setInputMode(checked ? "decimal" : "binary")}
                    />
                    <span className={`text-sm ${inputMode === "decimal" ? "font-medium" : "text-muted-foreground"}`}>
                      Decimal
                    </span>
                  </div>
                </div>

                {/* Operation Selection */}
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <Select value={operation} onValueChange={(v) => setOperation(v as Operation)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="add">Addition (+)</SelectItem>
                      <SelectItem value="subtract">Subtraction (−)</SelectItem>
                      <SelectItem value="multiply">Multiplication (×)</SelectItem>
                      <SelectItem value="divide">Division (÷)</SelectItem>
                      <SelectItem value="modulo">Modulo (%)</SelectItem>
                      <SelectItem value="and">Bitwise AND (&)</SelectItem>
                      <SelectItem value="or">Bitwise OR (|)</SelectItem>
                      <SelectItem value="xor">Bitwise XOR (^)</SelectItem>
                      <SelectItem value="not">Bitwise NOT (~)</SelectItem>
                      <SelectItem value="left-shift">Left Shift ({"<<"})</SelectItem>
                      <SelectItem value="right-shift">Right Shift ({">>"})</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Input A */}
                <div className="space-y-2">
                  <Label htmlFor="inputA">
                    {isUnaryOperation ? "Input" : "Input A"} ({inputMode === "binary" ? "Binary" : "Decimal"})
                  </Label>
                  <Input
                    id="inputA"
                    type="text"
                    placeholder={inputMode === "binary" ? "e.g., 1010 or -1010" : "e.g., 10 or -10"}
                    value={inputA}
                    onChange={(e) => setInputA(e.target.value)}
                  />
                </div>

                {/* Input B (for binary operations) */}
                {!isUnaryOperation && (
                  <div className="space-y-2">
                    <Label htmlFor="inputB">
                      {isShiftOperation ? "Shift Amount" : "Input B"} (
                      {inputMode === "binary" && !isShiftOperation ? "Binary" : "Decimal"})
                    </Label>
                    <Input
                      id="inputB"
                      type="text"
                      placeholder={
                        isShiftOperation
                          ? "e.g., 2"
                          : inputMode === "binary"
                            ? "e.g., 1100 or -1100"
                            : "e.g., 12 or -12"
                      }
                      value={inputB}
                      onChange={(e) => setInputB(e.target.value)}
                    />
                  </div>
                )}

                {/* Advanced Options */}
                <Collapsible>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="w-full justify-between">
                      Advanced Options
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    {/* Bit Width */}
                    <div className="space-y-2">
                      <Label>Bit Width</Label>
                      <Select value={bitWidth} onValueChange={setBitWidth}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="8">8-bit</SelectItem>
                          <SelectItem value="16">16-bit</SelectItem>
                          <SelectItem value="32">32-bit</SelectItem>
                          <SelectItem value="64">64-bit</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Two's Complement */}
                    <div className="flex items-center justify-between">
                      <Label>Two's Complement (signed)</Label>
                      <Switch checked={useTwosComplement} onCheckedChange={setUseTwosComplement} />
                    </div>

                    {/* Show Steps */}
                    <div className="flex items-center justify-between">
                      <Label>Show Step-by-Step</Label>
                      <Switch checked={showSteps} onCheckedChange={setShowSteps} />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    <div
                      className={`p-4 rounded-xl border-2 ${
                        result.overflow || result.underflow
                          ? "bg-yellow-50 border-yellow-200"
                          : "bg-green-50 border-green-200"
                      } transition-all duration-300`}
                    >
                      <div className="text-center space-y-3">
                        <p className="text-sm text-muted-foreground">Result (Binary)</p>
                        <p className="text-2xl font-mono font-bold text-foreground break-all">{result.binary}</p>

                        {(result.overflow || result.underflow) && (
                          <div className="flex items-center justify-center gap-2 text-yellow-600 text-sm">
                            <AlertTriangle className="h-4 w-4" />
                            <span>{result.overflow ? "Overflow" : "Underflow"} detected</span>
                          </div>
                        )}
                      </div>

                      {/* Copy Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleCopy(result.binary, "binary")}>
                          {copied === "binary" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          Binary
                        </Button>
                      </div>
                    </div>

                    {/* Additional Formats */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-3 bg-muted rounded-lg text-center">
                        <p className="text-xs text-muted-foreground mb-1">Decimal</p>
                        <p className="font-mono font-semibold text-sm">{result.decimal}</p>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 px-2 mt-1"
                          onClick={() => handleCopy(result.decimal.toString(), "decimal")}
                        >
                          {copied === "decimal" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                        </Button>
                      </div>
                      <div className="p-3 bg-muted rounded-lg text-center">
                        <p className="text-xs text-muted-foreground mb-1">Hexadecimal</p>
                        <p className="font-mono font-semibold text-sm">0x{result.hexadecimal}</p>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 px-2 mt-1"
                          onClick={() => handleCopy(`0x${result.hexadecimal}`, "hex")}
                        >
                          {copied === "hex" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                        </Button>
                      </div>
                      <div className="p-3 bg-muted rounded-lg text-center">
                        <p className="text-xs text-muted-foreground mb-1">Octal</p>
                        <p className="font-mono font-semibold text-sm">0o{result.octal}</p>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 px-2 mt-1"
                          onClick={() => handleCopy(`0o${result.octal}`, "octal")}
                        >
                          {copied === "octal" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                        </Button>
                      </div>
                    </div>

                    {/* Step-by-Step */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen}>
                        <CollapsibleTrigger asChild>
                          <Button variant="outline" className="w-full justify-between bg-transparent">
                            Step-by-Step Solution
                            {stepsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="p-4 bg-muted rounded-lg space-y-2">
                            {result.steps.map((step, index) => (
                              <div key={index} className="flex gap-3">
                                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                                  {index + 1}
                                </span>
                                <p className="text-sm font-mono">{step}</p>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bitwise Operations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-blue-700">AND (&)</span>
                        <span className="text-blue-600 font-mono">1 & 1 = 1</span>
                      </div>
                      <p className="text-blue-600 text-xs mt-1">Both bits must be 1</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-green-700">OR (|)</span>
                        <span className="text-green-600 font-mono">1 | 0 = 1</span>
                      </div>
                      <p className="text-green-600 text-xs mt-1">At least one bit must be 1</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-purple-700">XOR (^)</span>
                        <span className="text-purple-600 font-mono">1 ^ 0 = 1</span>
                      </div>
                      <p className="text-purple-600 text-xs mt-1">Bits must be different</p>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-orange-700">NOT (~)</span>
                        <span className="text-orange-600 font-mono">~1 = 0</span>
                      </div>
                      <p className="text-orange-600 text-xs mt-1">Inverts all bits</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Binary Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">1010 (bin)</span>
                        <span className="font-mono font-medium">= 10 (dec)</span>
                      </div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">11111111 (bin)</span>
                        <span className="font-mono font-medium">= 255 (dec)</span>
                      </div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">10000000 (bin)</span>
                        <span className="font-mono font-medium">= 128 (dec)</span>
                      </div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">1111 (bin)</span>
                        <span className="font-mono font-medium">= F (hex)</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bit Width Ranges</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-3 bg-muted rounded-lg font-mono">
                    <p>
                      <strong>8-bit signed:</strong> -128 to 127
                    </p>
                    <p>
                      <strong>16-bit signed:</strong> -32,768 to 32,767
                    </p>
                    <p>
                      <strong>32-bit signed:</strong> ±2.1 billion
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Binary?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Binary is a base-2 numeral system that uses only two digits: 0 and 1. It is the fundamental language
                  of computers and digital electronics. Each digit in a binary number is called a "bit" (binary digit),
                  and groups of 8 bits form a "byte". Binary numbers can represent any value that decimal numbers can,
                  just using a different notation. For example, the decimal number 10 is represented as 1010 in binary.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter binary numbers directly (like 1010) or switch to decimal input mode. Select an operation from
                  arithmetic (add, subtract, multiply, divide, modulo) or bitwise operations (AND, OR, XOR, NOT,
                  shifts). Use the advanced options to set bit width for overflow detection and enable two's complement
                  for signed number representation. The calculator will show results in binary, decimal, hexadecimal,
                  and octal formats.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Binary calculations are based on standard binary arithmetic and bitwise rules. Results may be limited
                  by selected bit-width and signed/unsigned settings. For critical applications, verify results with
                  professional tools.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
