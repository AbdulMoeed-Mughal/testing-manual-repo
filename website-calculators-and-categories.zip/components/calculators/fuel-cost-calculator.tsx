"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Fuel,
  Info,
  ChevronDown,
  ChevronUp,
  Car,
  MapPin,
  DollarSign,
  Gauge,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type UnitSystem = "metric" | "imperial"

interface FuelResult {
  fuelRequired: number
  totalCost: number
  costPerDistance: number
  distance: number
  isRoundTrip: boolean
}

export function FuelCostCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [distance, setDistance] = useState("")
  const [fuelEfficiency, setFuelEfficiency] = useState("")
  const [fuelPrice, setFuelPrice] = useState("")
  const [roundTrip, setRoundTrip] = useState(false)
  const [currency, setCurrency] = useState("$")
  const [result, setResult] = useState<FuelResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateFuelCost = () => {
    setError("")
    setResult(null)

    const distanceNum = Number.parseFloat(distance)
    const efficiencyNum = Number.parseFloat(fuelEfficiency)
    const priceNum = Number.parseFloat(fuelPrice)

    if (isNaN(distanceNum) || distanceNum <= 0) {
      setError("Please enter a valid distance greater than 0")
      return
    }

    if (isNaN(efficiencyNum) || efficiencyNum <= 0) {
      setError("Please enter a valid fuel efficiency greater than 0")
      return
    }

    if (isNaN(priceNum) || priceNum < 0) {
      setError("Please enter a valid fuel price (0 or greater)")
      return
    }

    // Calculate total distance (double for round trip)
    const totalDistance = roundTrip ? distanceNum * 2 : distanceNum

    // Calculate fuel required
    let fuelRequired: number
    if (unitSystem === "metric") {
      // km/L: Fuel = Distance / Efficiency
      fuelRequired = totalDistance / efficiencyNum
    } else {
      // MPG: Fuel = Distance / Efficiency
      fuelRequired = totalDistance / efficiencyNum
    }

    // Calculate total cost
    const totalCost = fuelRequired * priceNum

    // Calculate cost per distance unit
    const costPerDistance = totalCost / totalDistance

    setResult({
      fuelRequired: Math.round(fuelRequired * 100) / 100,
      totalCost: Math.round(totalCost * 100) / 100,
      costPerDistance: Math.round(costPerDistance * 100) / 100,
      distance: totalDistance,
      isRoundTrip: roundTrip,
    })
  }

  const handleReset = () => {
    setDistance("")
    setFuelEfficiency("")
    setFuelPrice("")
    setRoundTrip(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Fuel Cost Estimate: ${currency}${result.totalCost.toFixed(2)} for ${result.distance} ${unitSystem === "metric" ? "km" : "miles"} (${result.fuelRequired.toFixed(2)} ${unitSystem === "metric" ? "liters" : "gallons"} needed)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Fuel Cost Estimate",
          text: `I calculated my fuel cost using CalcHub! ${currency}${result.totalCost.toFixed(2)} for ${result.distance} ${unitSystem === "metric" ? "km" : "miles"}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setDistance("")
    setFuelEfficiency("")
    setFuelPrice("")
    setResult(null)
    setError("")
  }

  const distanceUnit = unitSystem === "metric" ? "km" : "miles"
  const efficiencyUnit = unitSystem === "metric" ? "km/L" : "MPG"
  const volumeUnit = unitSystem === "metric" ? "liter" : "gallon"
  const volumeUnitPlural = unitSystem === "metric" ? "liters" : "gallons"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/lifestyle-daily">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Lifestyle & Daily Use
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Fuel className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Fuel Cost Calculator</CardTitle>
                    <CardDescription>Calculate trip fuel costs</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Distance Input */}
                <div className="space-y-2">
                  <Label htmlFor="distance">Trip Distance ({distanceUnit})</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="distance"
                      type="number"
                      placeholder={`Enter distance in ${distanceUnit}`}
                      value={distance}
                      onChange={(e) => setDistance(e.target.value)}
                      min="0"
                      step="0.1"
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Fuel Efficiency Input */}
                <div className="space-y-2">
                  <Label htmlFor="efficiency">Fuel Efficiency ({efficiencyUnit})</Label>
                  <div className="relative">
                    <Gauge className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="efficiency"
                      type="number"
                      placeholder={`Enter fuel efficiency in ${efficiencyUnit}`}
                      value={fuelEfficiency}
                      onChange={(e) => setFuelEfficiency(e.target.value)}
                      min="0"
                      step="0.1"
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Fuel Price Input */}
                <div className="space-y-2">
                  <Label htmlFor="price">Fuel Price (per {volumeUnit})</Label>
                  <div className="flex gap-2">
                    <select
                      value={currency}
                      onChange={(e) => setCurrency(e.target.value)}
                      className="h-10 rounded-md border border-input bg-background px-3 text-sm"
                    >
                      <option value="$">$</option>
                      <option value="€">€</option>
                      <option value="£">£</option>
                      <option value="¥">¥</option>
                      <option value="₹">₹</option>
                      <option value="₽">₽</option>
                      <option value="A$">A$</option>
                      <option value="C$">C$</option>
                    </select>
                    <div className="relative flex-1">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="price"
                        type="number"
                        placeholder={`Price per ${volumeUnit}`}
                        value={fuelPrice}
                        onChange={(e) => setFuelPrice(e.target.value)}
                        min="0"
                        step="0.01"
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>

                {/* Round Trip Toggle */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2">
                    <Car className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Round Trip</span>
                  </div>
                  <button
                    onClick={() => setRoundTrip(!roundTrip)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      roundTrip ? "bg-primary" : "bg-muted-foreground/30"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        roundTrip ? "translate-x-6" : "translate-x-1"
                      }`}
                    />
                  </button>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFuelCost} className="w-full" size="lg">
                  Calculate Fuel Cost
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Fuel Cost</p>
                      <p className="text-5xl font-bold text-amber-600 mb-2">
                        {currency}
                        {result.totalCost.toFixed(2)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        for {result.distance} {distanceUnit}
                        {result.isRoundTrip && " (round trip)"}
                      </p>
                    </div>

                    {/* Additional Results */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 rounded-lg bg-white/60 text-center">
                        <p className="text-xs text-muted-foreground">Fuel Needed</p>
                        <p className="text-lg font-semibold text-amber-700">
                          {result.fuelRequired.toFixed(2)} {volumeUnitPlural}
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-white/60 text-center">
                        <p className="text-xs text-muted-foreground">Cost per {distanceUnit}</p>
                        <p className="text-lg font-semibold text-amber-700">
                          {currency}
                          {result.costPerDistance.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    {/* Calculation Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-between">
                          <span>View Calculation</span>
                          {showBreakdown ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="p-3 rounded-lg bg-white/60 text-sm space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Distance:</span>
                            <span className="font-mono">
                              {distance} {distanceUnit}
                              {result.isRoundTrip ? " × 2" : ""}
                              {result.isRoundTrip ? ` = ${result.distance} ${distanceUnit}` : ""}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Fuel Efficiency:</span>
                            <span className="font-mono">
                              {fuelEfficiency} {efficiencyUnit}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Fuel Required:</span>
                            <span className="font-mono">
                              {result.distance} ÷ {fuelEfficiency} = {result.fuelRequired.toFixed(2)} {volumeUnitPlural}
                            </span>
                          </div>
                          <div className="flex justify-between border-t pt-2">
                            <span className="text-muted-foreground">Total Cost:</span>
                            <span className="font-mono">
                              {result.fuelRequired.toFixed(2)} × {currency}
                              {fuelPrice} = {currency}
                              {result.totalCost.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fuel Cost Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Fuel = Distance ÷ Efficiency</p>
                    <p className="font-semibold text-foreground">Cost = Fuel × Price</p>
                  </div>
                  <p>
                    For <strong>metric</strong>: Distance in km, Efficiency in km/L, Price per liter
                  </p>
                  <p>
                    For <strong>imperial</strong>: Distance in miles, Efficiency in MPG, Price per gallon
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Fuel Efficiency</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                      <span className="text-sm text-green-700">Compact Car</span>
                      <span className="text-xs font-mono text-green-600">15-18 km/L | 35-42 MPG</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="text-sm text-blue-700">Sedan</span>
                      <span className="text-xs font-mono text-blue-600">12-15 km/L | 28-35 MPG</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="text-sm text-amber-700">SUV</span>
                      <span className="text-xs font-mono text-amber-600">8-12 km/L | 19-28 MPG</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                      <span className="text-sm text-red-700">Truck / Large SUV</span>
                      <span className="text-xs font-mono text-red-600">6-10 km/L | 14-23 MPG</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fuel Saving Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-0.5">•</span>
                      Maintain steady speeds and avoid rapid acceleration
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-0.5">•</span>
                      Keep tires properly inflated
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-0.5">•</span>
                      Remove unnecessary weight from your vehicle
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-0.5">•</span>
                      Use cruise control on highways
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-0.5">•</span>
                      Plan routes to avoid traffic congestion
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Fuel Costs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating fuel costs before a trip helps you budget effectively and make informed decisions about
                  travel. Whether you're planning a daily commute, a road trip, or comparing the cost-effectiveness of
                  different vehicles, understanding how fuel costs work is essential for smart transportation planning.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The basic calculation involves three key factors: the distance you'll travel, your vehicle's fuel
                  efficiency, and the current fuel price. By dividing the distance by fuel efficiency, you get the
                  amount of fuel needed. Multiplying this by the fuel price gives you the total cost.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Fuel Efficiency</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Your actual fuel consumption can vary significantly from manufacturer estimates. Several factors
                  influence real-world fuel efficiency:
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Driving Conditions</h4>
                    <p className="text-sm text-muted-foreground">
                      City driving with frequent stops uses more fuel than highway driving. Traffic congestion, hills,
                      and rough roads also increase consumption.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Driving Habits</h4>
                    <p className="text-sm text-muted-foreground">
                      Aggressive acceleration, high speeds, and frequent braking reduce fuel efficiency. Smooth,
                      consistent driving improves mileage.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Vehicle Condition</h4>
                    <p className="text-sm text-muted-foreground">
                      Regular maintenance, proper tire pressure, and clean air filters help maintain optimal fuel
                      efficiency.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Weather & Climate</h4>
                    <p className="text-sm text-muted-foreground">
                      Cold weather, strong headwinds, and using AC or heating all impact fuel consumption.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm">
                  Fuel cost estimates may vary due to driving conditions, traffic, weather, vehicle condition, and fuel
                  price fluctuations. This calculator provides estimates based on the values you enter. Actual fuel
                  consumption and costs may differ. Always budget some extra for unexpected variations in fuel prices or
                  consumption.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
