"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Beaker,
  Target,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "percent" | "actual" | "theoretical"
type YieldUnit = "g" | "mol"

interface YieldResult {
  percentYield: number
  actualYield: number
  theoreticalYield: number
  interpretation: string
  color: string
  bgColor: string
  steps: string[]
}

export function ReactionYieldCalculator() {
  const [mode, setMode] = useState<CalculationMode>("percent")
  const [actualYield, setActualYield] = useState("")
  const [theoreticalYield, setTheoreticalYield] = useState("")
  const [percentYield, setPercentYield] = useState("")
  const [unit, setUnit] = useState<YieldUnit>("g")
  const [result, setResult] = useState<YieldResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const steps: string[] = []
    let calcPercentYield: number
    let calcActualYield: number
    let calcTheoreticalYield: number
    let interpretation: string
    let color: string
    let bgColor: string

    if (mode === "percent") {
      const actual = Number.parseFloat(actualYield)
      const theoretical = Number.parseFloat(theoreticalYield)

      if (isNaN(actual) || actual < 0) {
        setError("Please enter a valid actual yield (≥ 0)")
        return
      }
      if (isNaN(theoretical) || theoretical <= 0) {
        setError("Please enter a valid theoretical yield (> 0)")
        return
      }

      calcActualYield = actual
      calcTheoreticalYield = theoretical
      calcPercentYield = (actual / theoretical) * 100

      steps.push(`Formula: %Yield = (Actual Yield ÷ Theoretical Yield) × 100`)
      steps.push(`%Yield = (${actual} ${unit} ÷ ${theoretical} ${unit}) × 100`)
      steps.push(`%Yield = ${(actual / theoretical).toFixed(6)} × 100`)
      steps.push(`%Yield = ${calcPercentYield.toFixed(2)}%`)
    } else if (mode === "actual") {
      const percent = Number.parseFloat(percentYield)
      const theoretical = Number.parseFloat(theoreticalYield)

      if (isNaN(percent) || percent < 0 || percent > 100) {
        setError("Please enter a valid percent yield (0-100)")
        return
      }
      if (isNaN(theoretical) || theoretical <= 0) {
        setError("Please enter a valid theoretical yield (> 0)")
        return
      }

      calcPercentYield = percent
      calcTheoreticalYield = theoretical
      calcActualYield = (percent / 100) * theoretical

      steps.push(`Formula: Actual Yield = (Percent Yield ÷ 100) × Theoretical Yield`)
      steps.push(`Actual = (${percent}% ÷ 100) × ${theoretical} ${unit}`)
      steps.push(`Actual = ${(percent / 100).toFixed(4)} × ${theoretical} ${unit}`)
      steps.push(`Actual = ${calcActualYield.toFixed(4)} ${unit}`)
    } else {
      const percent = Number.parseFloat(percentYield)
      const actual = Number.parseFloat(actualYield)

      if (isNaN(percent) || percent <= 0 || percent > 100) {
        setError("Please enter a valid percent yield (0-100, > 0)")
        return
      }
      if (isNaN(actual) || actual < 0) {
        setError("Please enter a valid actual yield (≥ 0)")
        return
      }

      calcPercentYield = percent
      calcActualYield = actual
      calcTheoreticalYield = actual / (percent / 100)

      steps.push(`Formula: Theoretical Yield = Actual Yield ÷ (Percent Yield ÷ 100)`)
      steps.push(`Theoretical = ${actual} ${unit} ÷ (${percent}% ÷ 100)`)
      steps.push(`Theoretical = ${actual} ${unit} ÷ ${(percent / 100).toFixed(4)}`)
      steps.push(`Theoretical = ${calcTheoreticalYield.toFixed(4)} ${unit}`)
    }

    // Interpret the yield
    if (calcPercentYield >= 90) {
      interpretation = "Excellent Yield"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (calcPercentYield >= 70) {
      interpretation = "Good Yield"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (calcPercentYield >= 50) {
      interpretation = "Moderate Yield"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (calcPercentYield >= 20) {
      interpretation = "Low Yield"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      interpretation = "Very Low Yield"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      percentYield: calcPercentYield,
      actualYield: calcActualYield,
      theoreticalYield: calcTheoreticalYield,
      interpretation,
      color,
      bgColor,
      steps,
    })
  }

  const handleReset = () => {
    setActualYield("")
    setTheoreticalYield("")
    setPercentYield("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Reaction Yield: ${result.percentYield.toFixed(2)}% (${result.interpretation})\nActual: ${result.actualYield.toFixed(4)} ${unit}\nTheoretical: ${result.theoreticalYield.toFixed(4)} ${unit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Reaction Yield Result",
          text: `I calculated a reaction yield using CalcHub! Percent Yield: ${result.percentYield.toFixed(2)}% (${result.interpretation})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const getModeLabel = (m: CalculationMode) => {
    switch (m) {
      case "percent":
        return "Percent Yield"
      case "actual":
        return "Actual Yield"
      case "theoretical":
        return "Theoretical Yield"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Target className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Reaction Yield Calculator</CardTitle>
                    <CardDescription>Calculate percent, actual, or theoretical yield</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Mode Selection */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["percent", "actual", "theoretical"] as CalculationMode[]).map((m) => (
                      <button
                        key={m}
                        onClick={() => {
                          setMode(m)
                          setResult(null)
                          setError("")
                        }}
                        className={`p-2 text-xs sm:text-sm font-medium rounded-lg border-2 transition-all ${
                          mode === m
                            ? "border-purple-500 bg-purple-50 text-purple-700"
                            : "border-muted bg-background hover:border-purple-200"
                        }`}
                      >
                        {getModeLabel(m)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Unit Selection */}
                <div className="space-y-2">
                  <Label>Yield Unit</Label>
                  <Select value={unit} onValueChange={(v) => setUnit(v as YieldUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="g">Grams (g)</SelectItem>
                      <SelectItem value="mol">Moles (mol)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dynamic Inputs based on Mode */}
                {mode === "percent" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="actual">Actual Yield ({unit})</Label>
                      <Input
                        id="actual"
                        type="number"
                        placeholder={`Enter actual yield in ${unit}`}
                        value={actualYield}
                        onChange={(e) => setActualYield(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="theoretical">Theoretical Yield ({unit})</Label>
                      <Input
                        id="theoretical"
                        type="number"
                        placeholder={`Enter theoretical yield in ${unit}`}
                        value={theoreticalYield}
                        onChange={(e) => setTheoreticalYield(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {mode === "actual" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="percent">Percent Yield (%)</Label>
                      <Input
                        id="percent"
                        type="number"
                        placeholder="Enter percent yield (0-100)"
                        value={percentYield}
                        onChange={(e) => setPercentYield(e.target.value)}
                        min="0"
                        max="100"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="theoretical">Theoretical Yield ({unit})</Label>
                      <Input
                        id="theoretical"
                        type="number"
                        placeholder={`Enter theoretical yield in ${unit}`}
                        value={theoreticalYield}
                        onChange={(e) => setTheoreticalYield(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {mode === "theoretical" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="actual">Actual Yield ({unit})</Label>
                      <Input
                        id="actual"
                        type="number"
                        placeholder={`Enter actual yield in ${unit}`}
                        value={actualYield}
                        onChange={(e) => setActualYield(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="percent">Percent Yield (%)</Label>
                      <Input
                        id="percent"
                        type="number"
                        placeholder="Enter percent yield (0-100)"
                        value={percentYield}
                        onChange={(e) => setPercentYield(e.target.value)}
                        min="0"
                        max="100"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {getModeLabel(mode)}
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Percent Yield</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{result.percentYield.toFixed(2)}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.interpretation}</p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-background/50 rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Actual Yield</p>
                        <p className="font-semibold">
                          {result.actualYield.toFixed(4)} {unit}
                        </p>
                      </div>
                      <div className="p-2 bg-background/50 rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Theoretical Yield</p>
                        <p className="font-semibold">
                          {result.theoreticalYield.toFixed(4)} {unit}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step */}
                    <div className="mt-4 p-3 bg-background/50 rounded-lg">
                      <p className="text-xs font-medium text-muted-foreground mb-2">Calculation Steps:</p>
                      <div className="space-y-1">
                        {result.steps.map((step, i) => (
                          <p key={i} className="text-xs font-mono">
                            {step}
                          </p>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Yield Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-medium text-purple-800 text-sm">Percent Yield</p>
                    <p className="font-mono text-xs mt-1 text-purple-700">%Yield = (Actual ÷ Theoretical) × 100</p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-800 text-sm">Actual Yield</p>
                    <p className="font-mono text-xs mt-1 text-blue-700">Actual = (%Yield ÷ 100) × Theoretical</p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-800 text-sm">Theoretical Yield</p>
                    <p className="font-mono text-xs mt-1 text-green-700">Theoretical = Actual ÷ (%Yield ÷ 100)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Yield Interpretation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700 text-sm">Excellent</span>
                      <span className="text-xs text-green-600">≥ 90%</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700 text-sm">Good</span>
                      <span className="text-xs text-blue-600">70 – 89%</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700 text-sm">Moderate</span>
                      <span className="text-xs text-yellow-600">50 – 69%</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700 text-sm">Low</span>
                      <span className="text-xs text-orange-600">20 – 49%</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700 text-sm">Very Low</span>
                      <span className="text-xs text-red-600">{"< 20%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800 text-sm">Disclaimer</p>
                      <p className="text-amber-700 text-xs mt-1">
                        Results assume accurate experimental and theoretical data. Always verify measurements and
                        calculations for critical applications.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Reaction Yield?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Reaction yield is a measure of the efficiency of a chemical reaction, expressed as the ratio of the
                  actual amount of product obtained to the theoretical amount that could be obtained under ideal
                  conditions. Understanding yield is fundamental to chemistry because it helps scientists and engineers
                  evaluate the success of their reactions, optimize processes, and make informed decisions about
                  resource allocation in both laboratory and industrial settings.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The percent yield specifically tells us what fraction of the theoretical maximum was actually
                  achieved. A 100% yield means that every reactant molecule was converted to product with no losses
                  whatsoever - a theoretical ideal that is rarely achieved in practice. Real-world reactions typically
                  have yields less than 100% due to various factors such as incomplete reactions, side reactions,
                  product loss during purification, and measurement uncertainties.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Yield</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Theoretical Yield</h4>
                    <p className="text-purple-700 text-sm">
                      The maximum amount of product that can be formed from the given amounts of reactants, assuming the
                      reaction goes to completion with no losses. It is calculated using stoichiometry from the balanced
                      chemical equation and the amounts of limiting and excess reagents.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Actual Yield</h4>
                    <p className="text-blue-700 text-sm">
                      The amount of product actually obtained from a chemical reaction, measured experimentally. This is
                      always less than or equal to the theoretical yield due to practical limitations such as incomplete
                      reactions, competing side reactions, and product loss during isolation and purification.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Percent Yield</h4>
                    <p className="text-green-700 text-sm">
                      The ratio of actual yield to theoretical yield, expressed as a percentage. It provides a
                      standardized way to compare the efficiency of different reactions or the same reaction under
                      different conditions. A higher percent yield indicates a more efficient process.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Yield</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors can influence the yield of a chemical reaction. Understanding these factors is crucial
                  for optimizing reaction conditions and improving efficiency in both laboratory and industrial
                  settings.
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <h4 className="font-semibold text-sm mb-1">Reaction Conditions</h4>
                    <p className="text-xs text-muted-foreground">
                      Temperature, pressure, concentration, and reaction time all affect how completely a reaction
                      proceeds.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <h4 className="font-semibold text-sm mb-1">Side Reactions</h4>
                    <p className="text-xs text-muted-foreground">
                      Competing reactions can consume reactants and produce unwanted byproducts, reducing the yield of
                      the desired product.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <h4 className="font-semibold text-sm mb-1">Equilibrium Limitations</h4>
                    <p className="text-xs text-muted-foreground">
                      Reversible reactions may not go to completion, limiting the maximum achievable yield without
                      additional techniques.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <h4 className="font-semibold text-sm mb-1">Purification Losses</h4>
                    <p className="text-xs text-muted-foreground">
                      Product may be lost during separation, washing, filtering, recrystallization, or other
                      purification steps.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Reaction yield calculations are essential in many areas of chemistry and related fields:
                </p>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>
                    <strong>Pharmaceutical Manufacturing:</strong> High yields are critical for cost-effective drug
                    production and ensuring sufficient supply of medications.
                  </li>
                  <li>
                    <strong>Research & Development:</strong> Scientists use yield data to compare reaction conditions
                    and optimize synthetic routes.
                  </li>
                  <li>
                    <strong>Quality Control:</strong> Monitoring yields helps identify process issues and maintain
                    consistent product quality.
                  </li>
                  <li>
                    <strong>Environmental Chemistry:</strong> Understanding yields helps minimize waste and improve the
                    sustainability of chemical processes.
                  </li>
                  <li>
                    <strong>Academic Studies:</strong> Students learn yield calculations as a fundamental skill in
                    chemistry courses.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
