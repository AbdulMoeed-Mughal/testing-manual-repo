"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Target, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface MidpointResult {
  midpoint: number[]
  steps: string[]
}

export function MidpointCalculator() {
  const [is3D, setIs3D] = useState(false)
  const [x1, setX1] = useState("")
  const [y1, setY1] = useState("")
  const [z1, setZ1] = useState("")
  const [x2, setX2] = useState("")
  const [y2, setY2] = useState("")
  const [z2, setZ2] = useState("")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<MidpointResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateMidpoint = () => {
    setError("")
    setResult(null)

    const x1Num = Number.parseFloat(x1)
    const y1Num = Number.parseFloat(y1)
    const x2Num = Number.parseFloat(x2)
    const y2Num = Number.parseFloat(y2)

    if (isNaN(x1Num) || isNaN(y1Num) || isNaN(x2Num) || isNaN(y2Num)) {
      setError("Please enter valid numeric coordinates for both points")
      return
    }

    const steps: string[] = []
    let midpoint: number[]

    if (is3D) {
      const z1Num = Number.parseFloat(z1)
      const z2Num = Number.parseFloat(z2)

      if (isNaN(z1Num) || isNaN(z2Num)) {
        setError("Please enter valid z-coordinates for 3D calculation")
        return
      }

      steps.push(`Point 1: (${x1Num}, ${y1Num}, ${z1Num})`)
      steps.push(`Point 2: (${x2Num}, ${y2Num}, ${z2Num})`)
      steps.push(``)
      steps.push(`Using the 3D midpoint formula:`)
      steps.push(`M = ((x₁ + x₂)/2, (y₁ + y₂)/2, (z₁ + z₂)/2)`)
      steps.push(``)
      steps.push(`Calculating x-coordinate:`)
      steps.push(`Mx = (${x1Num} + ${x2Num}) / 2 = ${x1Num + x2Num} / 2 = ${(x1Num + x2Num) / 2}`)
      steps.push(``)
      steps.push(`Calculating y-coordinate:`)
      steps.push(`My = (${y1Num} + ${y2Num}) / 2 = ${y1Num + y2Num} / 2 = ${(y1Num + y2Num) / 2}`)
      steps.push(``)
      steps.push(`Calculating z-coordinate:`)
      steps.push(`Mz = (${z1Num} + ${z2Num}) / 2 = ${z1Num + z2Num} / 2 = ${(z1Num + z2Num) / 2}`)

      midpoint = [(x1Num + x2Num) / 2, (y1Num + y2Num) / 2, (z1Num + z2Num) / 2]
    } else {
      steps.push(`Point 1: (${x1Num}, ${y1Num})`)
      steps.push(`Point 2: (${x2Num}, ${y2Num})`)
      steps.push(``)
      steps.push(`Using the 2D midpoint formula:`)
      steps.push(`M = ((x₁ + x₂)/2, (y₁ + y₂)/2)`)
      steps.push(``)
      steps.push(`Calculating x-coordinate:`)
      steps.push(`Mx = (${x1Num} + ${x2Num}) / 2 = ${x1Num + x2Num} / 2 = ${(x1Num + x2Num) / 2}`)
      steps.push(``)
      steps.push(`Calculating y-coordinate:`)
      steps.push(`My = (${y1Num} + ${y2Num}) / 2 = ${y1Num + y2Num} / 2 = ${(y1Num + y2Num) / 2}`)

      midpoint = [(x1Num + x2Num) / 2, (y1Num + y2Num) / 2]
    }

    setResult({ midpoint, steps })
  }

  const handleReset = () => {
    setX1("")
    setY1("")
    setZ1("")
    setX2("")
    setY2("")
    setZ2("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const formatMidpoint = () => {
    if (!result) return ""
    if (is3D) {
      return `(${result.midpoint[0]}, ${result.midpoint[1]}, ${result.midpoint[2]})`
    }
    return `(${result.midpoint[0]}, ${result.midpoint[1]})`
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Midpoint: ${formatMidpoint()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Midpoint Calculation Result",
          text: `I calculated the midpoint using CalcHub! Midpoint: ${formatMidpoint()}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Target className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Midpoint Calculator</CardTitle>
                    <CardDescription>Calculate the midpoint between two points</CardDescription>
                  </div>
                </div>

                {/* 2D/3D Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Coordinate System</span>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm ${!is3D ? "font-medium" : "text-muted-foreground"}`}>2D</span>
                    <Switch checked={is3D} onCheckedChange={setIs3D} />
                    <span className={`text-sm ${is3D ? "font-medium" : "text-muted-foreground"}`}>3D</span>
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Show Steps</span>
                  <Switch checked={showSteps} onCheckedChange={setShowSteps} />
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Point 1 */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Point 1</Label>
                  <div className={`grid gap-3 ${is3D ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Label htmlFor="x1" className="text-xs text-muted-foreground">
                        x₁
                      </Label>
                      <Input
                        id="x1"
                        type="number"
                        placeholder="x₁"
                        value={x1}
                        onChange={(e) => setX1(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="y1" className="text-xs text-muted-foreground">
                        y₁
                      </Label>
                      <Input
                        id="y1"
                        type="number"
                        placeholder="y₁"
                        value={y1}
                        onChange={(e) => setY1(e.target.value)}
                        step="any"
                      />
                    </div>
                    {is3D && (
                      <div>
                        <Label htmlFor="z1" className="text-xs text-muted-foreground">
                          z₁
                        </Label>
                        <Input
                          id="z1"
                          type="number"
                          placeholder="z₁"
                          value={z1}
                          onChange={(e) => setZ1(e.target.value)}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Point 2 */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Point 2</Label>
                  <div className={`grid gap-3 ${is3D ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Label htmlFor="x2" className="text-xs text-muted-foreground">
                        x₂
                      </Label>
                      <Input
                        id="x2"
                        type="number"
                        placeholder="x₂"
                        value={x2}
                        onChange={(e) => setX2(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="y2" className="text-xs text-muted-foreground">
                        y₂
                      </Label>
                      <Input
                        id="y2"
                        type="number"
                        placeholder="y₂"
                        value={y2}
                        onChange={(e) => setY2(e.target.value)}
                        step="any"
                      />
                    </div>
                    {is3D && (
                      <div>
                        <Label htmlFor="z2" className="text-xs text-muted-foreground">
                          z₂
                        </Label>
                        <Input
                          id="z2"
                          type="number"
                          placeholder="z₂"
                          value={z2}
                          onChange={(e) => setZ2(e.target.value)}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMidpoint} className="w-full" size="lg">
                  Calculate Midpoint
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Midpoint</p>
                      <p className="text-3xl font-bold text-blue-600 mb-2 font-mono">{formatMidpoint()}</p>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && (
                      <Collapsible defaultOpen className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            Step-by-Step Solution
                            <span className="text-xs text-muted-foreground">Click to toggle</span>
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-2 p-3 bg-white rounded-lg border text-sm font-mono space-y-1">
                            {result.steps.map((step, i) => (
                              <p key={i} className={step === "" ? "h-2" : ""}>
                                {step}
                              </p>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Midpoint Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">2D: M = ((x₁+x₂)/2, (y₁+y₂)/2)</p>
                    <p className="font-semibold text-foreground">3D: M = ((x₁+x₂)/2, (y₁+y₂)/2, (z₁+z₂)/2)</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    The midpoint formula finds the point exactly halfway between two given points by averaging their
                    coordinates.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(0, 0) and (4, 6)</span>
                      <span className="font-mono text-sm font-medium">(2, 3)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(-2, 3) and (4, -1)</span>
                      <span className="font-mono text-sm font-medium">(1, 1)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(1, 2, 3) and (5, 6, 7)</span>
                      <span className="font-mono text-sm font-medium">(3, 4, 5)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Applications</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Geometry:</strong> Finding the center of a line segment
                  </p>
                  <p>
                    <strong>Computer Graphics:</strong> Calculating center points for shapes and animations
                  </p>
                  <p>
                    <strong>Navigation:</strong> Finding the halfway point between two locations
                  </p>
                  <p>
                    <strong>Physics:</strong> Locating the center of mass for uniform distributions
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Midpoint?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The midpoint is the point that lies exactly halfway between two given points. In coordinate geometry,
                  it is found by averaging the x-coordinates and y-coordinates (and z-coordinates in 3D) of the two
                  points. The midpoint divides the line segment connecting the two points into two equal parts.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This concept is fundamental in geometry and has numerous applications in real-world scenarios, from
                  finding the center of a line segment to determining meeting points between two locations. In computer
                  graphics, midpoints are used extensively for animations, collision detection, and rendering
                  algorithms.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Midpoint calculations follow standard Euclidean formulas. Results depend on correct coordinate input
                  and selected dimension. This calculator is intended for educational purposes and general calculations.
                  For specialized applications, please verify results with appropriate professional tools.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
