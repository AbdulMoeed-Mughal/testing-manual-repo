"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Shield,
  Info,
  AlertTriangle,
  TrendingUp,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface ScoreResult {
  estimatedScore: number
  category: string
  categoryColor: string
  categoryBg: string
  breakdown: {
    paymentHistory: number
    creditUtilization: number
    creditAge: number
    accountMix: number
    recentInquiries: number
  }
  recommendations: string[]
}

export function CreditScoreEstimator() {
  const [paymentHistory, setPaymentHistory] = useState<"excellent" | "good" | "fair" | "poor">("good")
  const [totalBalance, setTotalBalance] = useState("")
  const [totalLimit, setTotalLimit] = useState("")
  const [openAccounts, setOpenAccounts] = useState("")
  const [creditAge, setCreditAge] = useState("")
  const [recentInquiries, setRecentInquiries] = useState("")
  const [hasInstallmentLoans, setHasInstallmentLoans] = useState<"yes" | "no">("no")
  const [hasMortgage, setHasMortgage] = useState<"yes" | "no">("no")
  const [result, setResult] = useState<ScoreResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  const calculateScore = () => {
    setError("")
    setResult(null)

    const balance = Number.parseFloat(totalBalance) || 0
    const limit = Number.parseFloat(totalLimit) || 0
    const accounts = Number.parseInt(openAccounts) || 0
    const age = Number.parseFloat(creditAge) || 0
    const inquiries = Number.parseInt(recentInquiries) || 0

    if (limit <= 0) {
      setError("Please enter a valid credit limit greater than 0")
      return
    }

    if (balance < 0 || accounts < 0 || age < 0 || inquiries < 0) {
      setError("Please enter valid positive values")
      return
    }

    // Payment History Score (35% weight, max 297.5 points)
    let paymentScore = 0
    switch (paymentHistory) {
      case "excellent":
        paymentScore = 297.5
        break
      case "good":
        paymentScore = 250
        break
      case "fair":
        paymentScore = 180
        break
      case "poor":
        paymentScore = 105
        break
    }

    // Credit Utilization Score (30% weight, max 255 points)
    const utilizationPercent = (balance / limit) * 100
    let utilizationScore = 0
    if (utilizationPercent <= 10) utilizationScore = 255
    else if (utilizationPercent <= 20) utilizationScore = 230
    else if (utilizationPercent <= 30) utilizationScore = 200
    else if (utilizationPercent <= 50) utilizationScore = 150
    else if (utilizationPercent <= 75) utilizationScore = 100
    else utilizationScore = 50

    // Credit Age Score (15% weight, max 127.5 points)
    let ageScore = 0
    if (age >= 10) ageScore = 127.5
    else if (age >= 7) ageScore = 110
    else if (age >= 5) ageScore = 90
    else if (age >= 3) ageScore = 70
    else if (age >= 1) ageScore = 50
    else ageScore = 30

    // Account Mix Score (10% weight, max 85 points)
    let mixScore = 45 // Base for having credit cards
    if (hasInstallmentLoans === "yes") mixScore += 20
    if (hasMortgage === "yes") mixScore += 20
    if (accounts >= 3) mixScore = Math.min(85, mixScore + 10)

    // Recent Inquiries Score (10% weight, max 85 points)
    let inquiryScore = 0
    if (inquiries === 0) inquiryScore = 85
    else if (inquiries <= 2) inquiryScore = 70
    else if (inquiries <= 4) inquiryScore = 50
    else if (inquiries <= 6) inquiryScore = 30
    else inquiryScore = 15

    // Calculate total score
    const totalScore = Math.round(300 + paymentScore + utilizationScore + ageScore + mixScore + inquiryScore)
    const clampedScore = Math.min(850, Math.max(300, totalScore))

    // Determine category
    let category: string
    let categoryColor: string
    let categoryBg: string

    if (clampedScore >= 800) {
      category = "Excellent"
      categoryColor = "text-green-600"
      categoryBg = "bg-green-50 border-green-200"
    } else if (clampedScore >= 740) {
      category = "Very Good"
      categoryColor = "text-blue-600"
      categoryBg = "bg-blue-50 border-blue-200"
    } else if (clampedScore >= 670) {
      category = "Good"
      categoryColor = "text-cyan-600"
      categoryBg = "bg-cyan-50 border-cyan-200"
    } else if (clampedScore >= 580) {
      category = "Fair"
      categoryColor = "text-yellow-600"
      categoryBg = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Poor"
      categoryColor = "text-red-600"
      categoryBg = "bg-red-50 border-red-200"
    }

    // Generate recommendations
    const recommendations: string[] = []
    if (paymentHistory !== "excellent") {
      recommendations.push("Make all payments on time to improve payment history")
    }
    if (utilizationPercent > 30) {
      recommendations.push("Reduce credit utilization below 30%")
    }
    if (age < 5) {
      recommendations.push("Keep old accounts open to increase credit age")
    }
    if (hasInstallmentLoans === "no" && hasMortgage === "no") {
      recommendations.push("Consider diversifying your credit mix")
    }
    if (inquiries > 2) {
      recommendations.push("Limit new credit applications")
    }

    setResult({
      estimatedScore: clampedScore,
      category,
      categoryColor,
      categoryBg,
      breakdown: {
        paymentHistory: Math.round((paymentScore / 297.5) * 100),
        creditUtilization: Math.round((utilizationScore / 255) * 100),
        creditAge: Math.round((ageScore / 127.5) * 100),
        accountMix: Math.round((mixScore / 85) * 100),
        recentInquiries: Math.round((inquiryScore / 85) * 100),
      },
      recommendations,
    })
  }

  const handleReset = () => {
    setPaymentHistory("good")
    setTotalBalance("")
    setTotalLimit("")
    setOpenAccounts("")
    setCreditAge("")
    setRecentInquiries("")
    setHasInstallmentLoans("no")
    setHasMortgage("no")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Estimated Credit Score: ${result.estimatedScore} (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Credit Score Estimate",
          text: `My estimated credit score is ${result.estimatedScore} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Shield className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Credit Score Estimator</CardTitle>
                    <CardDescription>Estimate your credit score based on key factors</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Payment History */}
                <div className="space-y-2">
                  <Label htmlFor="paymentHistory">Payment History</Label>
                  <Select
                    value={paymentHistory}
                    onValueChange={(v) => setPaymentHistory(v as "excellent" | "good" | "fair" | "poor")}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excellent">Excellent (No late payments)</SelectItem>
                      <SelectItem value="good">Good (1-2 late payments)</SelectItem>
                      <SelectItem value="fair">Fair (Some late payments)</SelectItem>
                      <SelectItem value="poor">Poor (Frequent late payments)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Credit Balances and Limits */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="totalBalance">Total Balance ($)</Label>
                    <Input
                      id="totalBalance"
                      type="number"
                      placeholder="5000"
                      value={totalBalance}
                      onChange={(e) => setTotalBalance(e.target.value)}
                      min="0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="totalLimit">Total Credit Limit ($)</Label>
                    <Input
                      id="totalLimit"
                      type="number"
                      placeholder="20000"
                      value={totalLimit}
                      onChange={(e) => setTotalLimit(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>

                {/* Credit Age and Inquiries */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="creditAge">Credit History (years)</Label>
                    <Input
                      id="creditAge"
                      type="number"
                      placeholder="5"
                      value={creditAge}
                      onChange={(e) => setCreditAge(e.target.value)}
                      min="0"
                      step="0.5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="recentInquiries">Recent Inquiries (12 mo)</Label>
                    <Input
                      id="recentInquiries"
                      type="number"
                      placeholder="2"
                      value={recentInquiries}
                      onChange={(e) => setRecentInquiries(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Credit Mix Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="openAccounts">Number of Open Accounts</Label>
                      <Input
                        id="openAccounts"
                        type="number"
                        placeholder="5"
                        value={openAccounts}
                        onChange={(e) => setOpenAccounts(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Installment Loans</Label>
                        <Select
                          value={hasInstallmentLoans}
                          onValueChange={(v) => setHasInstallmentLoans(v as "yes" | "no")}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="yes">Yes</SelectItem>
                            <SelectItem value="no">No</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Mortgage</Label>
                        <Select value={hasMortgage} onValueChange={(v) => setHasMortgage(v as "yes" | "no")}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="yes">Yes</SelectItem>
                            <SelectItem value="no">No</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateScore} className="w-full" size="lg">
                  Estimate Credit Score
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.categoryBg} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Credit Score</p>
                      <p className={`text-5xl font-bold ${result.categoryColor}`}>{result.estimatedScore}</p>
                      <p className={`text-lg font-semibold ${result.categoryColor}`}>{result.category}</p>
                    </div>

                    {/* Score Bar */}
                    <div className="mb-4">
                      <div className="h-4 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 rounded-full overflow-hidden relative">
                        <div
                          className="absolute top-0 h-full w-1 bg-black"
                          style={{ left: `${((result.estimatedScore - 300) / 550) * 100}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>300</span>
                        <span>580</span>
                        <span>670</span>
                        <span>740</span>
                        <span>850</span>
                      </div>
                    </div>

                    {/* Factor Breakdown */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full bg-transparent">
                          {showDetails ? "Hide" : "Show"} Factor Breakdown
                          {showDetails ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2">
                        <div className="p-3 bg-white rounded-lg space-y-3">
                          {[
                            { label: "Payment History (35%)", value: result.breakdown.paymentHistory },
                            { label: "Credit Utilization (30%)", value: result.breakdown.creditUtilization },
                            { label: "Credit Age (15%)", value: result.breakdown.creditAge },
                            { label: "Account Mix (10%)", value: result.breakdown.accountMix },
                            { label: "Recent Inquiries (10%)", value: result.breakdown.recentInquiries },
                          ].map((factor) => (
                            <div key={factor.label}>
                              <div className="flex justify-between text-sm mb-1">
                                <span>{factor.label}</span>
                                <span className="font-medium">{factor.value}%</span>
                              </div>
                              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div
                                  className={`h-full transition-all duration-500 ${
                                    factor.value >= 80
                                      ? "bg-green-500"
                                      : factor.value >= 50
                                        ? "bg-yellow-500"
                                        : "bg-red-500"
                                  }`}
                                  style={{ width: `${factor.value}%` }}
                                />
                              </div>
                            </div>
                          ))}
                        </div>

                        {result.recommendations.length > 0 && (
                          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                            <p className="font-medium text-blue-700 mb-2">Recommendations:</p>
                            <ul className="text-sm text-blue-600 space-y-1">
                              {result.recommendations.map((rec, index) => (
                                <li key={index}>• {rec}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Credit Score Ranges</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-sm text-green-600">800 - 850</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Very Good</span>
                      <span className="text-sm text-blue-600">740 - 799</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Good</span>
                      <span className="text-sm text-cyan-600">670 - 739</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Fair</span>
                      <span className="text-sm text-yellow-600">580 - 669</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Poor</span>
                      <span className="text-sm text-red-600">300 - 579</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Score Factor Weights</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Payment History</span>
                    <span className="font-semibold">35%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Credit Utilization</span>
                    <span className="font-semibold">30%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Credit Age</span>
                    <span className="font-semibold">15%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Account Mix</span>
                    <span className="font-semibold">10%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Recent Inquiries</span>
                    <span className="font-semibold">10%</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Credit Scores</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Credit scores are three-digit numbers that represent your creditworthiness based on your credit
                  history. Lenders use these scores to determine the likelihood that you&apos;ll repay borrowed money.
                  The most common scoring models range from 300 to 850, with higher scores indicating better
                  creditworthiness and potentially better loan terms and interest rates.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>How to Improve Your Credit Score</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground leading-relaxed space-y-2 list-disc list-inside">
                  <li>Always pay bills on time - set up automatic payments if needed</li>
                  <li>Keep credit utilization below 30% of your total credit limit</li>
                  <li>Avoid closing old credit accounts to maintain credit history length</li>
                  <li>Limit applications for new credit to avoid hard inquiries</li>
                  <li>Regularly check your credit reports for errors and dispute inaccuracies</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Credit score estimates are approximate and may not reflect your actual credit score. Real credit
                  scores are calculated using proprietary algorithms by credit bureaus (Equifax, Experian, TransUnion)
                  and may differ from this estimate. Consult a credit bureau or financial advisor for accurate
                  information and personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
