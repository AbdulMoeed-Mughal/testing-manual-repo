"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, CalendarCheck, Info, Calendar } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface LeapYearResult {
  year: number
  isLeapYear: boolean
  nextLeapYear: number
  previousLeapYear: number
}

export function LeapYearChecker() {
  const [year, setYear] = useState("")
  const [result, setResult] = useState<LeapYearResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const isLeapYear = (yr: number): boolean => {
    return (yr % 4 === 0 && yr % 100 !== 0) || yr % 400 === 0
  }

  const findNextLeapYear = (yr: number): number => {
    let next = yr + 1
    while (!isLeapYear(next)) {
      next++
    }
    return next
  }

  const findPreviousLeapYear = (yr: number): number => {
    let prev = yr - 1
    while (!isLeapYear(prev) && prev > 0) {
      prev--
    }
    return prev
  }

  const checkLeapYear = () => {
    setError("")
    setResult(null)

    const yearNum = Number.parseInt(year)
    if (isNaN(yearNum) || yearNum <= 0) {
      setError("Please enter a valid positive year")
      return
    }

    if (yearNum < 1 || yearNum > 9999) {
      setError("Please enter a year between 1 and 9999")
      return
    }

    const leapYearStatus = isLeapYear(yearNum)
    const nextLeapYear = findNextLeapYear(yearNum)
    const previousLeapYear = findPreviousLeapYear(yearNum)

    setResult({
      year: yearNum,
      isLeapYear: leapYearStatus,
      nextLeapYear,
      previousLeapYear,
    })
  }

  const handleReset = () => {
    setYear("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.isLeapYear ? `${result.year} is a leap year` : `${result.year} is not a leap year`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = result.isLeapYear
          ? `${result.year} is a leap year with 366 days!`
          : `${result.year} is not a leap year (365 days)`
        await navigator.share({
          title: "Leap Year Check",
          text: text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <CalendarCheck className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Leap Year Checker</CardTitle>
                    <CardDescription>Check if a year is a leap year</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Year Input */}
                <div className="space-y-2">
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    type="number"
                    placeholder="Enter year (e.g., 2024)"
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    min="1"
                    max="9999"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={checkLeapYear} className="w-full" size="lg">
                  Check Leap Year
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.isLeapYear
                        ? "bg-green-50 border-green-200"
                        : "bg-gray-50 border-gray-200"
                    }`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Leap Year Status</p>
                      <p className={`text-4xl font-bold mb-2 ${result.isLeapYear ? "text-green-600" : "text-gray-600"}`}>
                        {result.isLeapYear ? "Yes" : "No"}
                      </p>
                      <p className={`text-lg font-semibold ${result.isLeapYear ? "text-green-600" : "text-gray-600"}`}>
                        {result.year} {result.isLeapYear ? "is" : "is not"} a leap year
                      </p>
                      <p className="text-sm text-muted-foreground mt-2">
                        {result.isLeapYear ? "366 days" : "365 days"} in {result.year}
                      </p>
                    </div>

                    {/* Next/Previous Leap Years */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-cyan-50 border border-cyan-200 rounded-lg text-center">
                        <p className="text-xs text-cyan-600 mb-1">Previous</p>
                        <p className="text-lg font-bold text-cyan-700">{result.previousLeapYear}</p>
                      </div>
                      <div className="p-3 bg-cyan-50 border border-cyan-200 rounded-lg text-center">
                        <p className="text-xs text-cyan-600 mb-1">Next</p>
                        <p className="text-lg font-bold text-cyan-700">{result.nextLeapYear}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Leap Year Rules</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <p className="font-semibold text-cyan-700 mb-1">Divisible by 4</p>
                    <p className="text-cyan-600">Year must be evenly divisible by 4</p>
                  </div>
                  <div className="p-3 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <p className="font-semibold text-cyan-700 mb-1">Century Exception</p>
                    <p className="text-cyan-600">If divisible by 100, must also be divisible by 400</p>
                  </div>
                  <p className="text-xs">Examples: 2024 (yes), 1900 (no), 2000 (yes)</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Facts</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    Leap years have <strong>366 days</strong> instead of the usual 365, with February having 29 days.
                  </p>
                  <p>
                    Leap years occur approximately every <strong>4 years</strong> to keep our calendar synchronized
                    with Earth's orbit around the sun.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is a Leap Year */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Leap Year?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A leap year is a calendar year that contains an additional day added to keep the calendar year
                  synchronized with the astronomical year or seasonal year. In the Gregorian calendar, the most
                  widely used calendar system today, a leap year has 366 days instead of the usual 365 days. This
                  extra day is added as February 29th, making February 29 days long instead of its usual 28 days.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of leap years was introduced because Earth's orbital period around the Sun (a tropical
                  year) is approximately 365.2422 days. Without the occasional addition of a leap day, our calendar
                  would gradually drift out of alignment with the seasons. Over time, this would cause significant
                  discrepancies, with summer months eventually occurring in what we now consider winter months.
                </p>
              </CardContent>
            </Card>

            {/* How to Determine a Leap Year */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>How to Determine a Leap Year</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Gregorian calendar uses three simple rules to determine if a year is a leap year. First, if the
                  year is evenly divisible by 4, it is a potential leap year. Second, if the year is evenly divisible
                  by 100, it is NOT a leap year, unless it also meets the third rule. Third, if the year is evenly
                  divisible by 400, then it IS a leap year regardless of the second rule.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, the year 2024 is divisible by 4 and not by 100, so it's a leap year. The year 1900 was
                  divisible by 4 and by 100 but not by 400, so it was not a leap year. However, the year 2000 was
                  divisible by 4, by 100, and by 400, making it a leap year. This system ensures that our calendar
                  remains accurate over centuries, with an average year length very close to the actual tropical year.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-cyan-200 bg-cyan-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-cyan-900">
                  <strong>Note:</strong> Leap year determination is based on standard Gregorian calendar rules.
                  Results may vary for historical calendars and calendar system adjustments. The Julian calendar used
                  before 1582 had different leap year rules.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
