"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  DollarSign,
  Percent,
  Calendar,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Currency = "USD" | "EUR" | "GBP" | "INR" | "CAD" | "AUD" | "JPY"

interface InvestmentResult {
  totalInvested: number
  finalValue: number
  profit: number
  absoluteReturn: number
  cagr: number
  isProfit: boolean
  duration: string
}

const currencySymbols: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  INR: "₹",
  CAD: "C$",
  AUD: "A$",
  JPY: "¥",
}

export function InvestmentReturnCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [initialInvestment, setInitialInvestment] = useState("")
  const [finalValue, setFinalValue] = useState("")
  const [years, setYears] = useState("")
  const [months, setMonths] = useState("")
  const [additionalContributions, setAdditionalContributions] = useState("")
  const [result, setResult] = useState<InvestmentResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateReturn = () => {
    setError("")
    setResult(null)

    const initial = Number.parseFloat(initialInvestment)
    const final = Number.parseFloat(finalValue)
    const yrs = Number.parseFloat(years) || 0
    const mos = Number.parseFloat(months) || 0
    const additional = Number.parseFloat(additionalContributions) || 0

    if (isNaN(initial) || initial <= 0) {
      setError("Please enter a valid initial investment amount greater than 0")
      return
    }

    if (isNaN(final) || final <= 0) {
      setError("Please enter a valid final value greater than 0")
      return
    }

    if (yrs <= 0 && mos <= 0) {
      setError("Please enter a valid investment duration greater than 0")
      return
    }

    const totalInvested = initial + additional
    const profit = final - totalInvested
    const absoluteReturn = (profit / totalInvested) * 100
    const timeInYears = yrs + mos / 12

    // CAGR calculation
    let cagr = 0
    if (timeInYears > 0 && totalInvested > 0) {
      cagr = (Math.pow(final / totalInvested, 1 / timeInYears) - 1) * 100
    }

    // Format duration string
    let duration = ""
    if (yrs > 0 && mos > 0) {
      duration = `${yrs} year${yrs !== 1 ? "s" : ""} and ${mos} month${mos !== 1 ? "s" : ""}`
    } else if (yrs > 0) {
      duration = `${yrs} year${yrs !== 1 ? "s" : ""}`
    } else {
      duration = `${mos} month${mos !== 1 ? "s" : ""}`
    }

    setResult({
      totalInvested,
      finalValue: final,
      profit,
      absoluteReturn,
      cagr,
      isProfit: profit >= 0,
      duration,
    })
  }

  const handleReset = () => {
    setInitialInvestment("")
    setFinalValue("")
    setYears("")
    setMonths("")
    setAdditionalContributions("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Investment Return Summary:
Total Invested: ${currencySymbols[currency]}${result.totalInvested.toLocaleString()}
Final Value: ${currencySymbols[currency]}${result.finalValue.toLocaleString()}
Profit/Loss: ${result.isProfit ? "+" : ""}${currencySymbols[currency]}${result.profit.toLocaleString()}
Absolute Return: ${result.absoluteReturn >= 0 ? "+" : ""}${result.absoluteReturn.toFixed(2)}%
CAGR: ${result.cagr >= 0 ? "+" : ""}${result.cagr.toFixed(2)}%
Duration: ${result.duration}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Investment Return Calculator Result",
          text: `My investment of ${currencySymbols[currency]}${result.totalInvested.toLocaleString()} grew to ${currencySymbols[currency]}${result.finalValue.toLocaleString()} over ${result.duration}. CAGR: ${result.cagr.toFixed(2)}%`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return `${currencySymbols[currency]}${Math.abs(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Investment Return Calculator</CardTitle>
                    <CardDescription>Calculate your investment performance</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="INR">INR (₹)</option>
                    <option value="CAD">CAD (C$)</option>
                    <option value="AUD">AUD (A$)</option>
                    <option value="JPY">JPY (¥)</option>
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Investment */}
                <div className="space-y-2">
                  <Label htmlFor="initial">Initial Investment ({currencySymbols[currency]})</Label>
                  <Input
                    id="initial"
                    type="number"
                    placeholder="e.g., 10000"
                    value={initialInvestment}
                    onChange={(e) => setInitialInvestment(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Additional Contributions (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="additional">
                    Additional Contributions ({currencySymbols[currency]})
                    <span className="text-muted-foreground font-normal ml-1">(optional)</span>
                  </Label>
                  <Input
                    id="additional"
                    type="number"
                    placeholder="e.g., 5000"
                    value={additionalContributions}
                    onChange={(e) => setAdditionalContributions(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Final Value */}
                <div className="space-y-2">
                  <Label htmlFor="final">Final Investment Value ({currencySymbols[currency]})</Label>
                  <Input
                    id="final"
                    type="number"
                    placeholder="e.g., 15000"
                    value={finalValue}
                    onChange={(e) => setFinalValue(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Investment Duration */}
                <div className="space-y-2">
                  <Label>Investment Duration</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder="Years"
                        value={years}
                        onChange={(e) => setYears(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Months"
                        value={months}
                        onChange={(e) => setMonths(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateReturn} className="w-full" size="lg">
                  Calculate Return
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.isProfit ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                    }`}
                  >
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.isProfit ? "Total Profit" : "Total Loss"}
                      </p>
                      <p className={`text-4xl font-bold ${result.isProfit ? "text-green-600" : "text-red-600"}`}>
                        {result.isProfit ? "+" : "-"}
                        {formatCurrency(result.profit)}
                      </p>
                      <p className={`text-lg font-semibold ${result.isProfit ? "text-green-600" : "text-red-600"}`}>
                        {result.absoluteReturn >= 0 ? "+" : ""}
                        {result.absoluteReturn.toFixed(2)}% Return
                      </p>
                    </div>

                    {/* Detailed Results */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white/60 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Invested</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.totalInvested)}</p>
                      </div>
                      <div className="p-3 bg-white/60 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Final Value</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.finalValue)}</p>
                      </div>
                      <div className="p-3 bg-white/60 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">CAGR</p>
                        <p className={`font-semibold ${result.cagr >= 0 ? "text-green-600" : "text-red-600"}`}>
                          {result.cagr >= 0 ? "+" : ""}
                          {result.cagr.toFixed(2)}%
                        </p>
                      </div>
                      <div className="p-3 bg-white/60 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Duration</p>
                        <p className="font-semibold text-foreground">{result.duration}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Metrics Explained</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                      <Percent className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <span className="font-medium text-green-700">Absolute Return</span>
                        <p className="text-sm text-green-600">Total percentage gain or loss on your investment</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <TrendingUp className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <span className="font-medium text-blue-700">CAGR</span>
                        <p className="text-sm text-blue-600">
                          Compound Annual Growth Rate - annualized return percentage
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <Calendar className="h-5 w-5 text-purple-600 mt-0.5" />
                      <div>
                        <span className="font-medium text-purple-700">Time Factor</span>
                        <p className="text-sm text-purple-600">Longer periods compound returns significantly</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas Used</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Absolute Return</p>
                    <p className="text-foreground mt-1">((Final - Invested) ÷ Invested) × 100</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">CAGR</p>
                    <p className="text-foreground mt-1">((Final ÷ Invested)^(1/years) - 1) × 100</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Disclaimer</p>
                      <p className="text-sm text-amber-700 mt-1">
                        Investment returns are estimates and subject to market risk. Past performance does not guarantee
                        future results. Always consult a financial advisor.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Investment Return */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Investment Return?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Investment return is a measure of the gain or loss generated by an investment over a specific period
                  of time, expressed as a percentage of the original investment or in absolute monetary terms.
                  Understanding your investment returns is crucial for evaluating the performance of your portfolio,
                  comparing different investment opportunities, and making informed financial decisions for the future.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Returns can be calculated in various ways, with the most common being absolute return (total gain or
                  loss) and annualized return (CAGR - Compound Annual Growth Rate). While absolute return shows the
                  total percentage change in value, CAGR provides a smoothed annual growth rate that accounts for the
                  compounding effect, making it easier to compare investments of different durations and to project
                  future growth based on historical performance.
                </p>
              </CardContent>
            </Card>

            {/* Understanding CAGR */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding CAGR (Compound Annual Growth Rate)</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  CAGR represents the rate of return that would be required for an investment to grow from its beginning
                  balance to its ending balance, assuming the profits were reinvested at the end of each period of the
                  investment's life span. It is one of the most accurate ways to calculate and determine returns for
                  assets, portfolios, and investments that can rise and fall in value over time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Unlike simple average returns, CAGR smooths out the volatility and provides a single growth rate that,
                  if applied consistently year after year, would take you from your initial investment to your final
                  value. For example, if an investment grows 100% in the first year and then loses 50% in the second
                  year, the simple average return would be 25%, but the actual ending value equals the starting value,
                  meaning the true annualized return is 0%. CAGR accounts for this mathematical reality.
                </p>
              </CardContent>
            </Card>

            {/* Why Returns Matter */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Why Understanding Returns Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating investment returns helps you make better financial decisions in several important ways.
                  First, it allows you to evaluate whether your investments are meeting your expectations and financial
                  goals. If your portfolio's CAGR falls short of inflation rates, you're actually losing purchasing
                  power over time, even if your nominal balance has increased.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Portfolio Evaluation</h4>
                    <p className="text-green-700 text-sm">
                      Compare your portfolio's performance against benchmarks like the S&P 500 index or other relevant
                      indices. A fund manager claiming superior returns should consistently beat these benchmarks after
                      fees to justify their management costs.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Goal Planning</h4>
                    <p className="text-blue-700 text-sm">
                      Use historical CAGR to project future portfolio values and determine if you're on track for
                      retirement, education funding, or other financial goals. Be conservative in projections—past
                      performance doesn't guarantee future results.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Investment Comparison</h4>
                    <p className="text-purple-700 text-sm">
                      CAGR enables fair comparison between investments of different types and holding periods. A 5-year
                      investment returning 50% total (8.45% CAGR) can be fairly compared to a 3-year investment
                      returning 30% total (9.14% CAGR).
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips for Better Returns */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Improving Investment Returns</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While market returns are largely out of your control, several strategies can help improve your overall
                  investment performance over the long term. These focus on factors you can control: costs, behavior,
                  and time in the market.
                </p>
                <ul className="mt-4 space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Minimize fees:</strong> High expense ratios and trading costs erode returns over time. A
                      1% difference in annual fees can cost tens of thousands over a 30-year investment horizon due to
                      compounding.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Stay invested:</strong> Time in the market beats timing the market. Missing just the 10
                      best trading days over 20 years can cut your returns in half. Consistent investing through market
                      cycles tends to outperform market timing.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Diversify wisely:</strong> Spread investments across asset classes, geographies, and
                      sectors. Diversification reduces risk without necessarily sacrificing returns, protecting against
                      catastrophic losses in any single investment.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Reinvest dividends:</strong> Dividend reinvestment harnesses the power of compounding.
                      Historically, reinvested dividends have contributed significantly to total stock market returns
                      over long periods.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Review regularly:</strong> Periodically assess your portfolio's performance against your
                      goals and rebalance as needed, but avoid overtrading in response to short-term market movements.
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
