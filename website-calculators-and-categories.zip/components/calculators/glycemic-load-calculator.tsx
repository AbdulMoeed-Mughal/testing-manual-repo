"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Apple,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface FoodItem {
  id: number
  name: string
  carbs: string
  gi: string
  servings: string
}

interface GLResult {
  totalGL: number
  category: string
  color: string
  bgColor: string
  foods: {
    name: string
    gl: number
    carbs: number
    gi: number
    servings: number
  }[]
}

export function GlycemicLoadCalculator() {
  const [foods, setFoods] = useState<FoodItem[]>([{ id: 1, name: "", carbs: "", gi: "", servings: "1" }])
  const [result, setResult] = useState<GLResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const addFood = () => {
    const newId = Math.max(...foods.map((f) => f.id), 0) + 1
    setFoods([...foods, { id: newId, name: "", carbs: "", gi: "", servings: "1" }])
  }

  const removeFood = (id: number) => {
    if (foods.length > 1) {
      setFoods(foods.filter((f) => f.id !== id))
    }
  }

  const updateFood = (id: number, field: keyof FoodItem, value: string) => {
    setFoods(foods.map((f) => (f.id === id ? { ...f, [field]: value } : f)))
  }

  const calculateGL = () => {
    setError("")
    setResult(null)

    const calculatedFoods: GLResult["foods"] = []
    let totalGL = 0

    for (const food of foods) {
      const carbs = Number.parseFloat(food.carbs)
      const gi = Number.parseFloat(food.gi)
      const servings = Number.parseFloat(food.servings) || 1

      if (isNaN(carbs) || carbs < 0) {
        setError("Please enter valid carbohydrate values (must be positive)")
        return
      }

      if (isNaN(gi) || gi < 0 || gi > 100) {
        setError("Please enter valid glycemic index values (must be between 0 and 100)")
        return
      }

      if (servings <= 0) {
        setError("Number of servings must be greater than 0")
        return
      }

      const glPerServing = (carbs * gi) / 100
      const foodGL = glPerServing * servings
      totalGL += foodGL

      calculatedFoods.push({
        name: food.name || `Food ${calculatedFoods.length + 1}`,
        gl: Math.round(foodGL * 10) / 10,
        carbs,
        gi,
        servings,
      })
    }

    const roundedGL = Math.round(totalGL * 10) / 10

    let category: string
    let color: string
    let bgColor: string

    if (roundedGL <= 10) {
      category = "Low"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (roundedGL <= 19) {
      category = "Medium"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "High"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      totalGL: roundedGL,
      category,
      color,
      bgColor,
      foods: calculatedFoods,
    })
  }

  const handleReset = () => {
    setFoods([{ id: 1, name: "", carbs: "", gi: "", servings: "1" }])
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `My meal's Glycemic Load is ${result.totalGL} (${result.category})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Glycemic Load Result",
          text: `I calculated my meal's Glycemic Load using CalcHub! Total GL: ${result.totalGL} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Apple className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Glycemic Load Calculator</CardTitle>
                    <CardDescription>Calculate the blood sugar impact of your meal</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Food Items */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-medium">Food Items</Label>
                    <Button variant="outline" size="sm" onClick={addFood}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Food
                    </Button>
                  </div>

                  {foods.map((food, index) => (
                    <div key={food.id} className="p-4 border rounded-lg bg-muted/30 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-muted-foreground">Food {index + 1}</span>
                        {foods.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFood(food.id)}
                            className="h-8 w-8 p-0 text-muted-foreground hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`name-${food.id}`}>Food Name (optional)</Label>
                        <Input
                          id={`name-${food.id}`}
                          type="text"
                          placeholder="e.g., White rice"
                          value={food.name}
                          onChange={(e) => updateFood(food.id, "name", e.target.value)}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor={`carbs-${food.id}`}>Carbs (g)</Label>
                          <Input
                            id={`carbs-${food.id}`}
                            type="number"
                            placeholder="0"
                            value={food.carbs}
                            onChange={(e) => updateFood(food.id, "carbs", e.target.value)}
                            min="0"
                            step="0.1"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`gi-${food.id}`}>GI (0-100)</Label>
                          <Input
                            id={`gi-${food.id}`}
                            type="number"
                            placeholder="0"
                            value={food.gi}
                            onChange={(e) => updateFood(food.id, "gi", e.target.value)}
                            min="0"
                            max="100"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`servings-${food.id}`}>Servings</Label>
                          <Input
                            id={`servings-${food.id}`}
                            type="number"
                            placeholder="1"
                            value={food.servings}
                            onChange={(e) => updateFood(food.id, "servings", e.target.value)}
                            min="0.1"
                            step="0.1"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateGL} className="w-full" size="lg">
                  Calculate Glycemic Load
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Glycemic Load</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.totalGL}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category} GL</p>
                    </div>

                    {/* Expandable Details */}
                    {result.foods.length > 0 && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="flex items-center justify-center w-full text-sm text-muted-foreground hover:text-foreground transition-colors"
                        >
                          {showDetails ? (
                            <>
                              <ChevronUp className="h-4 w-4 mr-1" />
                              Hide Details
                            </>
                          ) : (
                            <>
                              <ChevronDown className="h-4 w-4 mr-1" />
                              Show Food Breakdown
                            </>
                          )}
                        </button>

                        {showDetails && (
                          <div className="mt-3 space-y-2 pt-3 border-t border-current/10">
                            {result.foods.map((food, index) => (
                              <div
                                key={index}
                                className="flex items-center justify-between text-sm p-2 rounded bg-white/50"
                              >
                                <span className="font-medium">{food.name}</span>
                                <div className="text-right text-muted-foreground">
                                  <span>
                                    {food.carbs}g × GI {food.gi} × {food.servings} =
                                  </span>
                                  <span className={`ml-2 font-semibold ${result.color}`}>{food.gl} GL</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Glycemic Load Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low GL</span>
                      <span className="text-sm text-green-600">≤ 10</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Medium GL</span>
                      <span className="text-sm text-yellow-600">11 – 19</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">High GL</span>
                      <span className="text-sm text-red-600">≥ 20</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">GL Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">GL = (Carbs × GI) ÷ 100</p>
                  </div>
                  <p>
                    Total Meal GL is the sum of individual food GL values multiplied by the number of servings consumed.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Food GI Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>White bread</span>
                      <span className="font-medium">75</span>
                    </div>
                    <div className="flex justify-between p-2">
                      <span>White rice</span>
                      <span className="font-medium">73</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Brown rice</span>
                      <span className="font-medium">68</span>
                    </div>
                    <div className="flex justify-between p-2">
                      <span>Banana (ripe)</span>
                      <span className="font-medium">62</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Apple</span>
                      <span className="font-medium">36</span>
                    </div>
                    <div className="flex justify-between p-2">
                      <span>Lentils</span>
                      <span className="font-medium">32</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Chickpeas</span>
                      <span className="font-medium">28</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Glycemic Load?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Glycemic Load (GL) is a measure that takes into account both the quality (Glycemic Index) and quantity
                  (carbohydrate content) of carbohydrates in a food or meal. While the Glycemic Index (GI) tells you how
                  quickly a food raises blood sugar, GL provides a more complete picture by factoring in how much
                  carbohydrate you actually consume.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, watermelon has a high GI of 72, but because it contains relatively few carbohydrates per
                  serving (about 6g), its GL is only about 4 per serving—making it a low GL food despite its high GI.
                  This demonstrates why GL is often more useful for meal planning than GI alone.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Apple className="h-5 w-5 text-primary" />
                  <CardTitle>GI vs. GL: Understanding the Difference</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Glycemic Index (GI) ranks carbohydrates on a scale of 0-100 based on how quickly they raise blood
                  sugar levels. Foods with a high GI are rapidly digested and absorbed, causing a quick spike in blood
                  sugar. Low GI foods are digested more slowly, providing a gradual rise in blood sugar levels.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Glycemic Load combines this information with the actual amount of carbohydrates in a typical serving.
                  This makes GL a more practical tool for managing blood sugar because it reflects real-world eating
                  patterns. A daily GL of 80 or less is considered low, 80-120 is moderate, and above 120 is high.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  Glycemic Load calculations are estimates and may vary based on food preparation methods, ripeness of
                  fruits and vegetables, food combinations, and individual metabolism. Actual blood sugar response can
                  differ between individuals. This calculator is for educational purposes only and should not replace
                  professional medical or nutritional advice. If you have diabetes or other metabolic conditions,
                  consult a healthcare provider or registered dietitian for personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
