"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Divide, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface ConversionResult {
  numerator: number
  denominator: number
  simplified: { numerator: number; denominator: number }
  mixedNumber: { whole: number; numerator: number; denominator: number } | null
  steps: string[]
  verification: number
  isExact: boolean
}

export function DecimalToFractionCalculator() {
  const [decimal, setDecimal] = useState("")
  const [maxDenominator, setMaxDenominator] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<ConversionResult | null>(null)
  const [copied, setCopied] = useState<"plain" | "latex" | null>(null)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(false)

  const gcd = (a: number, b: number): number => {
    a = Math.abs(a)
    b = Math.abs(b)
    while (b) {
      const t = b
      b = a % b
      a = t
    }
    return a
  }

  const decimalToFraction = (
    dec: number,
    maxDenom?: number,
  ): { numerator: number; denominator: number; steps: string[]; isExact: boolean } => {
    const steps: string[] = []
    const isNegative = dec < 0
    dec = Math.abs(dec)

    steps.push(`Starting with decimal: ${isNegative ? "-" : ""}${dec}`)

    // Check if it's a whole number
    if (Number.isInteger(dec)) {
      steps.push(`${dec} is a whole number`)
      steps.push(`Result: ${dec}/1`)
      return {
        numerator: isNegative ? -dec : dec,
        denominator: 1,
        steps,
        isExact: true,
      }
    }

    // Count decimal places
    const decStr = dec.toString()
    const decimalIndex = decStr.indexOf(".")
    const decimalPlaces = decimalIndex >= 0 ? decStr.length - decimalIndex - 1 : 0

    steps.push(`Number of decimal places: ${decimalPlaces}`)

    // Convert to fraction
    const denominator = Math.pow(10, decimalPlaces)
    const numerator = Math.round(dec * denominator)

    steps.push(`Multiply by 10^${decimalPlaces} = ${denominator}`)
    steps.push(`Numerator: ${dec} × ${denominator} = ${numerator}`)
    steps.push(`Initial fraction: ${numerator}/${denominator}`)

    // If max denominator is specified, use continued fractions for approximation
    if (maxDenom && maxDenom < denominator) {
      steps.push(`Approximating with max denominator of ${maxDenom}...`)

      // Continued fraction approximation
      let h1 = 1,
        h2 = 0,
        k1 = 0,
        k2 = 1
      let b = dec

      do {
        const a = Math.floor(b)
        let aux = h1
        h1 = a * h1 + h2
        h2 = aux
        aux = k1
        k1 = a * k1 + k2
        k2 = aux
        b = 1 / (b - a)
      } while (k1 <= maxDenom && Math.abs(dec - h1 / k1) > 1e-10)

      // Check if last convergent is within limit
      if (k1 > maxDenom) {
        h1 = h2
        k1 = k2
      }

      steps.push(`Best approximation: ${h1}/${k1}`)

      return {
        numerator: isNegative ? -h1 : h1,
        denominator: k1,
        steps,
        isExact: Math.abs(dec - h1 / k1) < 1e-10,
      }
    }

    return {
      numerator: isNegative ? -numerator : numerator,
      denominator,
      steps,
      isExact: true,
    }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const decimalNum = Number.parseFloat(decimal)
    if (isNaN(decimalNum)) {
      setError("Please enter a valid decimal number")
      return
    }

    const maxDenom = maxDenominator ? Number.parseInt(maxDenominator) : undefined
    if (maxDenominator && (isNaN(maxDenom!) || maxDenom! <= 0)) {
      setError("Maximum denominator must be a positive integer")
      return
    }

    const { numerator, denominator, steps, isExact } = decimalToFraction(decimalNum, maxDenom)

    // Simplify
    const divisor = gcd(Math.abs(numerator), denominator)
    const simplifiedNum = numerator / divisor
    const simplifiedDen = denominator / divisor

    if (divisor > 1) {
      steps.push(`GCD(${Math.abs(numerator)}, ${denominator}) = ${divisor}`)
      steps.push(`Simplified: ${simplifiedNum}/${simplifiedDen}`)
    } else {
      steps.push(`Fraction is already in lowest terms`)
    }

    // Mixed number (only if |numerator| >= denominator)
    let mixedNumber = null
    if (Math.abs(simplifiedNum) >= simplifiedDen && simplifiedDen !== 1) {
      const whole = Math.trunc(simplifiedNum / simplifiedDen)
      const remainder = Math.abs(simplifiedNum) % simplifiedDen
      if (remainder !== 0) {
        mixedNumber = { whole, numerator: remainder, denominator: simplifiedDen }
        steps.push(`Mixed number: ${whole} ${remainder}/${simplifiedDen}`)
      }
    }

    // Verification
    const verification = simplifiedNum / simplifiedDen

    setResult({
      numerator,
      denominator,
      simplified: { numerator: simplifiedNum, denominator: simplifiedDen },
      mixedNumber,
      steps,
      verification,
      isExact,
    })
    setStepsOpen(showSteps)
  }

  const handleReset = () => {
    setDecimal("")
    setMaxDenominator("")
    setResult(null)
    setError("")
    setCopied(null)
    setStepsOpen(false)
  }

  const formatFraction = (num: number, den: number): string => {
    if (den === 1) return num.toString()
    return `${num}/${den}`
  }

  const formatMixedNumber = (mixed: { whole: number; numerator: number; denominator: number }): string => {
    return `${mixed.whole} ${mixed.numerator}/${mixed.denominator}`
  }

  const handleCopy = async (type: "plain" | "latex") => {
    if (!result) return

    let text = ""
    if (type === "plain") {
      text = formatFraction(result.simplified.numerator, result.simplified.denominator)
      if (result.mixedNumber) {
        text += ` or ${formatMixedNumber(result.mixedNumber)}`
      }
    } else {
      if (result.simplified.denominator === 1) {
        text = result.simplified.numerator.toString()
      } else {
        text = `\\frac{${result.simplified.numerator}}{${result.simplified.denominator}}`
      }
    }

    await navigator.clipboard.writeText(text)
    setCopied(type)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Divide className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Decimal to Fraction Calculator</CardTitle>
                    <CardDescription>Convert decimals to exact or simplified fractions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Decimal Input */}
                <div className="space-y-2">
                  <Label htmlFor="decimal">Decimal Number</Label>
                  <Input
                    id="decimal"
                    type="text"
                    placeholder="e.g., 0.75, -3.14159, 0.333"
                    value={decimal}
                    onChange={(e) => setDecimal(e.target.value)}
                  />
                </div>

                {/* Max Denominator (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="maxDenominator">Maximum Denominator (Optional)</Label>
                  <Input
                    id="maxDenominator"
                    type="number"
                    placeholder="e.g., 100"
                    value={maxDenominator}
                    onChange={(e) => setMaxDenominator(e.target.value)}
                    min="1"
                  />
                  <p className="text-xs text-muted-foreground">Limits the denominator for approximate fractions</p>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <Label htmlFor="showSteps" className="cursor-pointer">
                    Show step-by-step solution
                  </Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Convert to Fraction
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.isExact ? "Exact Fraction" : "Approximate Fraction"}
                      </p>
                      <p className="text-4xl font-bold text-blue-600 mb-2">
                        {formatFraction(result.simplified.numerator, result.simplified.denominator)}
                      </p>
                      {result.mixedNumber && (
                        <p className="text-lg text-blue-500">= {formatMixedNumber(result.mixedNumber)}</p>
                      )}
                      <p className="text-sm text-muted-foreground mt-2">
                        Verification: {result.verification.toPrecision(10)}
                      </p>
                      {!result.isExact && (
                        <p className="text-xs text-amber-600 mt-1">(Approximation due to denominator limit)</p>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleCopy("plain")}>
                        {copied === "plain" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied === "plain" ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleCopy("latex")}>
                        {copied === "latex" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied === "latex" ? "Copied" : "LaTeX"}
                      </Button>
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" className="w-full justify-between">
                            Step-by-step Solution
                            <span className="text-xs">{stepsOpen ? "Hide" : "Show"}</span>
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="bg-white rounded-lg p-3 space-y-2">
                            {result.steps.map((step, index) => (
                              <div key={index} className="flex gap-2 text-sm">
                                <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-medium">
                                  {index + 1}
                                </span>
                                <span className="text-muted-foreground">{step}</span>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">0.5</span>
                      <span className="font-medium">1/2</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">0.25</span>
                      <span className="font-medium">1/4</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">0.333...</span>
                      <span className="font-medium">1/3</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">0.125</span>
                      <span className="font-medium">1/8</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">0.2</span>
                      <span className="font-medium">1/5</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">0.75</span>
                      <span className="font-medium">3/4</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">0.666...</span>
                      <span className="font-medium">2/3</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">0.875</span>
                      <span className="font-medium">7/8</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conversion Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">For Terminating Decimals:</p>
                    <ol className="list-decimal list-inside space-y-1 text-xs">
                      <li>Count decimal places (n)</li>
                      <li>Multiply by 10^n to get numerator</li>
                      <li>Use 10^n as denominator</li>
                      <li>Simplify using GCD</li>
                    </ol>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Example: 0.75</p>
                    <p className="font-mono text-xs">0.75 = 75/100 = 3/4</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Decimal to Fraction Conversion?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Decimal to fraction conversion is the process of expressing a decimal number as a ratio of two
                  integers (a fraction). Every terminating decimal can be converted to an exact fraction, while
                  repeating decimals can also be expressed as fractions using algebraic methods. For example, 0.75
                  equals 3/4, and 0.333... (repeating) equals 1/3.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This conversion is useful in many contexts, including cooking measurements, construction calculations,
                  and mathematical problem-solving where fractions provide more precise or intuitive representations
                  than decimals. Understanding both forms helps in choosing the most appropriate representation for any
                  given situation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter any decimal number (positive, negative, or zero) into the input field. The calculator will
                  automatically convert it to a fraction in lowest terms. You can also see the mixed number
                  representation when applicable (e.g., 7/4 = 1 3/4).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For very long decimals or irrational approximations like pi (3.14159...), you can set a maximum
                  denominator to get a practical approximation. For example, limiting the denominator to 100 for pi
                  gives you 22/7, a famous approximation used throughout history.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm">
                  Decimal to fraction conversions are approximate for repeating decimals within the specified tolerance.
                  Results depend on input accuracy and selected options. For exact representations of repeating
                  decimals, algebraic methods should be used to derive the precise fraction.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
