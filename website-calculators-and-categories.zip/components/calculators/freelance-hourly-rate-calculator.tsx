"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  DollarSign,
  Info,
  Clock,
  Target,
  Briefcase,
  Calculator,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Currency = "USD" | "EUR" | "GBP" | "INR" | "JPY" | "CAD" | "AUD"

interface FreelanceResult {
  hourlyRate: number
  totalBillableHours: number
  annualExpenses: number
  estimatedTaxes: number
  finalIncomeTarget: number
  monthlyIncome: number
  grossIncome: number
  totalWorkingDays: number
}

const currencySymbols: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  INR: "₹",
  JPY: "¥",
  CAD: "C$",
  AUD: "A$",
}

export function FreelanceHourlyRateCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [desiredIncome, setDesiredIncome] = useState("")
  const [workingWeeks, setWorkingWeeks] = useState("48")
  const [workingDays, setWorkingDays] = useState("5")
  const [billableHours, setBillableHours] = useState("6")
  const [annualExpenses, setAnnualExpenses] = useState("")
  const [taxRate, setTaxRate] = useState("25")
  const [bufferMargin, setBufferMargin] = useState("10")
  const [result, setResult] = useState<FreelanceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatCurrency = (value: number): string => {
    const symbol = currencySymbols[currency]
    if (currency === "INR") {
      if (value >= 10000000) return `${symbol}${(value / 10000000).toFixed(2)} Cr`
      if (value >= 100000) return `${symbol}${(value / 100000).toFixed(2)} L`
      return `${symbol}${value.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`
    }
    if (value >= 1000000) return `${symbol}${(value / 1000000).toFixed(2)}M`
    if (value >= 1000) return `${symbol}${(value / 1000).toFixed(1)}K`
    return `${symbol}${value.toLocaleString("en-US", { maximumFractionDigits: 2 })}`
  }

  const formatFullCurrency = (value: number): string => {
    const symbol = currencySymbols[currency]
    return `${symbol}${value.toLocaleString("en-US", { maximumFractionDigits: 2 })}`
  }

  const calculateRate = () => {
    setError("")
    setResult(null)

    const income = Number.parseFloat(desiredIncome)
    const weeks = Number.parseFloat(workingWeeks)
    const days = Number.parseFloat(workingDays)
    const hours = Number.parseFloat(billableHours)
    const expenses = Number.parseFloat(annualExpenses) || 0
    const tax = Number.parseFloat(taxRate) || 0
    const buffer = Number.parseFloat(bufferMargin) || 0

    if (isNaN(income) || income <= 0) {
      setError("Please enter a valid desired annual income")
      return
    }
    if (isNaN(weeks) || weeks <= 0 || weeks > 52) {
      setError("Working weeks must be between 1 and 52")
      return
    }
    if (isNaN(days) || days <= 0 || days > 7) {
      setError("Working days must be between 1 and 7")
      return
    }
    if (isNaN(hours) || hours <= 0 || hours > 24) {
      setError("Billable hours must be between 1 and 24")
      return
    }
    if (tax < 0 || tax > 100) {
      setError("Tax rate must be between 0 and 100")
      return
    }
    if (buffer < 0 || buffer > 100) {
      setError("Buffer margin must be between 0 and 100")
      return
    }

    // Calculations
    const totalWorkingDays = weeks * days
    const totalBillableHours = totalWorkingDays * hours
    const grossIncome = income + expenses
    const estimatedTaxes = grossIncome * (tax / 100)
    const totalIncomeNeeded = grossIncome + estimatedTaxes
    const finalIncomeTarget = totalIncomeNeeded * (1 + buffer / 100)
    const hourlyRate = finalIncomeTarget / totalBillableHours
    const monthlyIncome = finalIncomeTarget / 12

    setResult({
      hourlyRate,
      totalBillableHours,
      annualExpenses: expenses,
      estimatedTaxes,
      finalIncomeTarget,
      monthlyIncome,
      grossIncome,
      totalWorkingDays,
    })
  }

  const handleReset = () => {
    setDesiredIncome("")
    setWorkingWeeks("48")
    setWorkingDays("5")
    setBillableHours("6")
    setAnnualExpenses("")
    setTaxRate("25")
    setBufferMargin("10")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const symbol = currencySymbols[currency]
      await navigator.clipboard.writeText(
        `My recommended freelance hourly rate is ${symbol}${result.hourlyRate.toFixed(2)}/hour (Annual target: ${formatFullCurrency(result.finalIncomeTarget)})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const symbol = currencySymbols[currency]
      try {
        await navigator.share({
          title: "My Freelance Hourly Rate",
          text: `I calculated my ideal freelance rate using CalcHub! ${symbol}${result.hourlyRate.toFixed(2)}/hour`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Freelance Hourly Rate</CardTitle>
                    <CardDescription>Calculate your ideal hourly rate</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="INR">INR (₹)</option>
                    <option value="JPY">JPY (¥)</option>
                    <option value="CAD">CAD (C$)</option>
                    <option value="AUD">AUD (A$)</option>
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Desired Annual Income */}
                <div className="space-y-2">
                  <Label htmlFor="desiredIncome">Desired Annual Income ({currencySymbols[currency]})</Label>
                  <Input
                    id="desiredIncome"
                    type="number"
                    placeholder="e.g., 80000"
                    value={desiredIncome}
                    onChange={(e) => setDesiredIncome(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Working Schedule */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="workingWeeks">Weeks/Year</Label>
                    <Input
                      id="workingWeeks"
                      type="number"
                      placeholder="48"
                      value={workingWeeks}
                      onChange={(e) => setWorkingWeeks(e.target.value)}
                      min="1"
                      max="52"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="workingDays">Days/Week</Label>
                    <Input
                      id="workingDays"
                      type="number"
                      placeholder="5"
                      value={workingDays}
                      onChange={(e) => setWorkingDays(e.target.value)}
                      min="1"
                      max="7"
                    />
                  </div>
                </div>

                {/* Billable Hours */}
                <div className="space-y-2">
                  <Label htmlFor="billableHours">Billable Hours/Day</Label>
                  <Input
                    id="billableHours"
                    type="number"
                    placeholder="6"
                    value={billableHours}
                    onChange={(e) => setBillableHours(e.target.value)}
                    min="1"
                    max="24"
                    step="0.5"
                  />
                </div>

                {/* Annual Business Expenses */}
                <div className="space-y-2">
                  <Label htmlFor="annualExpenses">Annual Business Expenses ({currencySymbols[currency]})</Label>
                  <Input
                    id="annualExpenses"
                    type="number"
                    placeholder="e.g., 5000"
                    value={annualExpenses}
                    onChange={(e) => setAnnualExpenses(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Tax Rate and Buffer */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="taxRate">Tax Rate (%)</Label>
                    <Input
                      id="taxRate"
                      type="number"
                      placeholder="25"
                      value={taxRate}
                      onChange={(e) => setTaxRate(e.target.value)}
                      min="0"
                      max="100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bufferMargin">Buffer/Profit (%)</Label>
                    <Input
                      id="bufferMargin"
                      type="number"
                      placeholder="10"
                      value={bufferMargin}
                      onChange={(e) => setBufferMargin(e.target.value)}
                      min="0"
                      max="100"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRate} className="w-full" size="lg">
                  Calculate Hourly Rate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Recommended Hourly Rate</p>
                      <p className="text-5xl font-bold text-green-600 mb-2">
                        {currencySymbols[currency]}
                        {result.hourlyRate.toFixed(2)}
                      </p>
                      <p className="text-lg font-semibold text-green-600">per hour</p>
                    </div>

                    {/* Breakdown */}
                    <div className="mt-4 pt-4 border-t border-green-200 space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Annual Income Target:</span>
                        <span className="font-medium">{formatCurrency(result.finalIncomeTarget)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Monthly Income:</span>
                        <span className="font-medium">{formatCurrency(result.monthlyIncome)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Estimated Taxes:</span>
                        <span className="font-medium">{formatCurrency(result.estimatedTaxes)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Business Expenses:</span>
                        <span className="font-medium">{formatCurrency(result.annualExpenses)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Total Billable Hours:</span>
                        <span className="font-medium">{result.totalBillableHours.toLocaleString()} hrs/year</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Working Days:</span>
                        <span className="font-medium">{result.totalWorkingDays} days/year</span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rate Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-xs space-y-1">
                    <p>Gross = Income + Expenses</p>
                    <p>Tax = Gross × Tax Rate</p>
                    <p>Total = (Gross + Tax) × (1 + Buffer)</p>
                    <p className="font-semibold text-foreground pt-1">Rate = Total ÷ Billable Hours</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Billable Hours</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Part-time</span>
                      <span className="text-sm text-blue-600">3-4 hrs/day</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Standard</span>
                      <span className="text-sm text-green-600">5-6 hrs/day</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Intensive</span>
                      <span className="text-sm text-amber-600">7-8 hrs/day</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    Note: Not all working hours are billable. Account for admin, marketing, and unpaid tasks.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Actual rates may vary based on market conditions,
                        experience level, industry standards, and geographic location.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Freelance Hourly Rates</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Setting the right hourly rate is one of the most critical decisions for freelancers. Unlike
                  traditional employees who receive a fixed salary with benefits, freelancers must account for numerous
                  additional costs including taxes, healthcare, retirement savings, equipment, software subscriptions,
                  and the inevitable gaps between projects. A well-calculated hourly rate ensures you can maintain a
                  sustainable business while achieving your financial goals.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Many freelancers make the mistake of simply converting a desired salary to an hourly rate by dividing
                  by 2,080 hours (40 hours × 52 weeks). However, this approach fails to account for the realities of
                  freelance work: you won't bill for every hour you work, you'll have business expenses, and you need to
                  cover your own taxes and benefits. A proper freelance rate typically needs to be 40-100% higher than
                  an equivalent employee wage to achieve the same take-home pay.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Billable vs. Non-Billable Hours</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  One of the biggest revelations for new freelancers is discovering that not all working hours can be
                  billed to clients. Industry research suggests that freelancers typically only bill 60-70% of their
                  working hours. The remaining time goes to essential but non-billable activities such as marketing and
                  business development, administrative tasks, invoicing and accounting, client communication,
                  professional development, and project setup and transition time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator accounts for this reality by asking you to specify your actual billable hours per day.
                  If you plan to work 8 hours daily, realistically only 5-6 of those hours may be directly billable.
                  Being honest about your billable hours prevents underpricing your services and ensures you can sustain
                  your freelance business long-term without burning out from overwork.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>The Importance of Buffer and Profit Margin</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The buffer or profit margin is often overlooked by freelancers focused on covering immediate expenses.
                  However, this cushion serves several critical purposes. First, it provides emergency funds for
                  unexpected expenses like equipment failures, health issues, or economic downturns. Second, it enables
                  business investment for courses, conferences, better tools, or marketing initiatives that can grow
                  your income.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A 10-20% buffer is considered standard for established freelancers, while those building their
                  business or saving for specific goals might aim for 20-30%. Remember that freelance income is
                  inherently variable, so having financial cushion isn't luxury—it's a business necessity. The buffer
                  also allows you to occasionally take on passion projects at reduced rates without jeopardizing your
                  financial stability.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5 text-primary" />
                  <CardTitle>Business Expenses to Consider</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When calculating your business expenses, be thorough in accounting for all costs associated with
                  running your freelance business. Common expenses include software and subscriptions (design tools,
                  project management, accounting software, cloud storage), hardware and equipment (computer,
                  peripherals, office furniture), professional services (accountant, lawyer, virtual assistant),
                  marketing costs (website hosting, advertising, portfolio platforms), and education (courses, books,
                  conference attendance).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Don't forget about home office expenses if you work from home, including a portion of rent/mortgage,
                  utilities, and internet. Health insurance is another major expense for freelancers in countries
                  without universal healthcare. Many freelancers underestimate these costs initially, only to find
                  themselves struggling financially. Track your expenses carefully for at least a year to get accurate
                  numbers for your rate calculations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Setting and Negotiating Your Rate</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Research market rates for your skill set and experience level in your geographic area and industry.
                  Websites like Glassdoor, PayScale, and industry-specific surveys can provide valuable benchmarks.
                  Remember that rates vary significantly by specialization, with niche expertise commanding premium
                  prices. Consider value-based pricing for experienced freelancers—if your work generates significant
                  value for clients, your rate should reflect that impact, not just your time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When negotiating, never apologize for your rates or immediately offer discounts. Present your rate
                  confidently and be prepared to explain the value you provide. If a client's budget is genuinely
                  limited, consider reducing scope rather than rate. Periodically review and increase your rates as you
                  gain experience and skills. Finally, remember that saying no to low-paying work creates space for
                  better opportunities—your time is your most valuable and limited resource as a freelancer.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
