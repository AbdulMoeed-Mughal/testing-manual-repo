"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Thermometer, Info, Plus, Trash2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type TransferMode = "conduction" | "convection"
type CombineMode = "single" | "series" | "parallel"

interface Layer {
  id: number
  mode: TransferMode
  thickness: string
  conductivity: string
  heatTransferCoeff: string
  area: string
}

interface ThermalResistanceResult {
  resistance: number
  category: string
  color: string
  bgColor: string
  layers?: { name: string; resistance: number }[]
}

export function ThermalResistanceCalculator() {
  const [mode, setMode] = useState<TransferMode>("conduction")
  const [combineMode, setCombineMode] = useState<CombineMode>("single")
  const [thickness, setThickness] = useState("")
  const [conductivity, setConductivity] = useState("")
  const [heatTransferCoeff, setHeatTransferCoeff] = useState("")
  const [area, setArea] = useState("")
  const [outputUnit, setOutputUnit] = useState<"K/W" | "°C/W">("K/W")
  const [layers, setLayers] = useState<Layer[]>([
    { id: 1, mode: "conduction", thickness: "", conductivity: "", heatTransferCoeff: "", area: "" },
  ])
  const [result, setResult] = useState<ThermalResistanceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateSingleResistance = (
    layerMode: TransferMode,
    L: number,
    k: number,
    h: number,
    A: number,
  ): number | null => {
    if (A <= 0) return null
    if (layerMode === "conduction") {
      if (k <= 0 || L <= 0) return null
      return L / (k * A)
    } else {
      if (h <= 0) return null
      return 1 / (h * A)
    }
  }

  const calculateThermalResistance = () => {
    setError("")
    setResult(null)

    if (combineMode === "single") {
      const areaNum = Number.parseFloat(area)
      if (isNaN(areaNum) || areaNum <= 0) {
        setError("Please enter a valid area greater than 0")
        return
      }

      let resistance: number | null = null

      if (mode === "conduction") {
        const thicknessNum = Number.parseFloat(thickness)
        const conductivityNum = Number.parseFloat(conductivity)
        if (isNaN(thicknessNum) || thicknessNum <= 0) {
          setError("Please enter a valid thickness greater than 0")
          return
        }
        if (isNaN(conductivityNum) || conductivityNum <= 0) {
          setError("Please enter a valid thermal conductivity greater than 0")
          return
        }
        resistance = calculateSingleResistance("conduction", thicknessNum, conductivityNum, 0, areaNum)
      } else {
        const hNum = Number.parseFloat(heatTransferCoeff)
        if (isNaN(hNum) || hNum <= 0) {
          setError("Please enter a valid heat transfer coefficient greater than 0")
          return
        }
        resistance = calculateSingleResistance("convection", 0, 0, hNum, areaNum)
      }

      if (resistance === null) {
        setError("Invalid calculation. Check your inputs.")
        return
      }

      const { category, color, bgColor } = categorizeResistance(resistance)
      setResult({ resistance, category, color, bgColor })
    } else {
      // Multi-layer calculation
      const layerResults: { name: string; resistance: number }[] = []

      for (let i = 0; i < layers.length; i++) {
        const layer = layers[i]
        const areaNum = Number.parseFloat(layer.area)
        if (isNaN(areaNum) || areaNum <= 0) {
          setError(`Layer ${i + 1}: Please enter a valid area greater than 0`)
          return
        }

        let resistance: number | null = null

        if (layer.mode === "conduction") {
          const thicknessNum = Number.parseFloat(layer.thickness)
          const conductivityNum = Number.parseFloat(layer.conductivity)
          if (isNaN(thicknessNum) || thicknessNum <= 0) {
            setError(`Layer ${i + 1}: Please enter a valid thickness greater than 0`)
            return
          }
          if (isNaN(conductivityNum) || conductivityNum <= 0) {
            setError(`Layer ${i + 1}: Please enter a valid thermal conductivity greater than 0`)
            return
          }
          resistance = calculateSingleResistance("conduction", thicknessNum, conductivityNum, 0, areaNum)
        } else {
          const hNum = Number.parseFloat(layer.heatTransferCoeff)
          if (isNaN(hNum) || hNum <= 0) {
            setError(`Layer ${i + 1}: Please enter a valid heat transfer coefficient greater than 0`)
            return
          }
          resistance = calculateSingleResistance("convection", 0, 0, hNum, areaNum)
        }

        if (resistance === null) {
          setError(`Layer ${i + 1}: Invalid calculation. Check your inputs.`)
          return
        }

        layerResults.push({ name: `Layer ${i + 1} (${layer.mode})`, resistance })
      }

      let totalResistance: number

      if (combineMode === "series") {
        totalResistance = layerResults.reduce((sum, layer) => sum + layer.resistance, 0)
      } else {
        // Parallel
        const sumInverse = layerResults.reduce((sum, layer) => sum + 1 / layer.resistance, 0)
        totalResistance = 1 / sumInverse
      }

      const { category, color, bgColor } = categorizeResistance(totalResistance)
      setResult({ resistance: totalResistance, category, color, bgColor, layers: layerResults })
    }
  }

  const categorizeResistance = (r: number): { category: string; color: string; bgColor: string } => {
    if (r < 0.01) {
      return { category: "Very Low (Good Conductor)", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    } else if (r < 0.1) {
      return { category: "Low", color: "text-cyan-600", bgColor: "bg-cyan-50 border-cyan-200" }
    } else if (r < 1) {
      return { category: "Moderate", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    } else if (r < 10) {
      return { category: "High", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    } else {
      return { category: "Very High (Good Insulator)", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    }
  }

  const handleReset = () => {
    setMode("conduction")
    setCombineMode("single")
    setThickness("")
    setConductivity("")
    setHeatTransferCoeff("")
    setArea("")
    setLayers([{ id: 1, mode: "conduction", thickness: "", conductivity: "", heatTransferCoeff: "", area: "" }])
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = outputUnit
      await navigator.clipboard.writeText(
        `Thermal Resistance: ${result.resistance.toExponential(4)} ${unit} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Thermal Resistance Result",
          text: `I calculated thermal resistance using CalcHub! R_th = ${result.resistance.toExponential(4)} ${outputUnit} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const addLayer = () => {
    const newId = Math.max(...layers.map((l) => l.id)) + 1
    setLayers([
      ...layers,
      { id: newId, mode: "conduction", thickness: "", conductivity: "", heatTransferCoeff: "", area: "" },
    ])
  }

  const removeLayer = (id: number) => {
    if (layers.length > 1) {
      setLayers(layers.filter((l) => l.id !== id))
    }
  }

  const updateLayer = (id: number, field: keyof Layer, value: string) => {
    setLayers(layers.map((l) => (l.id === id ? { ...l, [field]: value } : l)))
  }

  const formatResult = (value: number): string => {
    if (value < 0.001 || value >= 1000) {
      return value.toExponential(4)
    }
    return value.toFixed(6)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Thermometer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Thermal Resistance Calculator</CardTitle>
                    <CardDescription>Calculate R_th for heat flow analysis</CardDescription>
                  </div>
                </div>

                {/* Combine Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Mode</span>
                  <div className="flex gap-1 bg-muted rounded-full p-1">
                    {(["single", "series", "parallel"] as CombineMode[]).map((m) => (
                      <button
                        key={m}
                        onClick={() => setCombineMode(m)}
                        className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${
                          combineMode === m
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {m === "single" ? "Single" : m === "series" ? "Series" : "Parallel"}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {combineMode === "single" ? (
                  <>
                    {/* Transfer Mode Toggle */}
                    <div className="space-y-2">
                      <Label>Transfer Mode</Label>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setMode("conduction")}
                          className={`flex-1 py-2 px-3 text-sm font-medium rounded-lg border transition-colors ${
                            mode === "conduction"
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-background border-input hover:bg-muted"
                          }`}
                        >
                          Conduction
                        </button>
                        <button
                          onClick={() => setMode("convection")}
                          className={`flex-1 py-2 px-3 text-sm font-medium rounded-lg border transition-colors ${
                            mode === "convection"
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-background border-input hover:bg-muted"
                          }`}
                        >
                          Convection
                        </button>
                      </div>
                    </div>

                    {mode === "conduction" ? (
                      <>
                        <div className="space-y-2">
                          <Label htmlFor="thickness">Material Thickness (L) in meters</Label>
                          <Input
                            id="thickness"
                            type="number"
                            placeholder="e.g., 0.05"
                            value={thickness}
                            onChange={(e) => setThickness(e.target.value)}
                            min="0"
                            step="0.001"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="conductivity">Thermal Conductivity (k) in W/m·K</Label>
                          <Input
                            id="conductivity"
                            type="number"
                            placeholder="e.g., 0.04"
                            value={conductivity}
                            onChange={(e) => setConductivity(e.target.value)}
                            min="0"
                            step="0.001"
                          />
                        </div>
                      </>
                    ) : (
                      <div className="space-y-2">
                        <Label htmlFor="heatTransferCoeff">Heat Transfer Coefficient (h) in W/m²·K</Label>
                        <Input
                          id="heatTransferCoeff"
                          type="number"
                          placeholder="e.g., 25"
                          value={heatTransferCoeff}
                          onChange={(e) => setHeatTransferCoeff(e.target.value)}
                          min="0"
                          step="0.1"
                        />
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label htmlFor="area">Cross-sectional Area (A) in m²</Label>
                      <Input
                        id="area"
                        type="number"
                        placeholder="e.g., 1"
                        value={area}
                        onChange={(e) => setArea(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    {/* Multi-layer inputs */}
                    <div className="space-y-4">
                      {layers.map((layer, index) => (
                        <div key={layer.id} className="p-4 border rounded-lg bg-muted/30 space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-sm">Layer {index + 1}</span>
                            {layers.length > 1 && (
                              <Button variant="ghost" size="sm" onClick={() => removeLayer(layer.id)}>
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => updateLayer(layer.id, "mode", "conduction")}
                              className={`flex-1 py-1.5 px-2 text-xs font-medium rounded border transition-colors ${
                                layer.mode === "conduction"
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-background border-input hover:bg-muted"
                              }`}
                            >
                              Conduction
                            </button>
                            <button
                              onClick={() => updateLayer(layer.id, "mode", "convection")}
                              className={`flex-1 py-1.5 px-2 text-xs font-medium rounded border transition-colors ${
                                layer.mode === "convection"
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-background border-input hover:bg-muted"
                              }`}
                            >
                              Convection
                            </button>
                          </div>
                          {layer.mode === "conduction" ? (
                            <div className="grid grid-cols-2 gap-2">
                              <Input
                                type="number"
                                placeholder="L (m)"
                                value={layer.thickness}
                                onChange={(e) => updateLayer(layer.id, "thickness", e.target.value)}
                                min="0"
                                step="0.001"
                              />
                              <Input
                                type="number"
                                placeholder="k (W/m·K)"
                                value={layer.conductivity}
                                onChange={(e) => updateLayer(layer.id, "conductivity", e.target.value)}
                                min="0"
                                step="0.001"
                              />
                            </div>
                          ) : (
                            <Input
                              type="number"
                              placeholder="h (W/m²·K)"
                              value={layer.heatTransferCoeff}
                              onChange={(e) => updateLayer(layer.id, "heatTransferCoeff", e.target.value)}
                              min="0"
                              step="0.1"
                            />
                          )}
                          <Input
                            type="number"
                            placeholder="Area A (m²)"
                            value={layer.area}
                            onChange={(e) => updateLayer(layer.id, "area", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                      ))}
                      <Button variant="outline" size="sm" onClick={addLayer} className="w-full bg-transparent">
                        <Plus className="h-4 w-4 mr-1" />
                        Add Layer
                      </Button>
                    </div>
                  </>
                )}

                {/* Output Unit */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <div className="flex gap-2">
                    {(["K/W", "°C/W"] as const).map((unit) => (
                      <button
                        key={unit}
                        onClick={() => setOutputUnit(unit)}
                        className={`flex-1 py-2 px-3 text-sm font-medium rounded-lg border transition-colors ${
                          outputUnit === unit
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background border-input hover:bg-muted"
                        }`}
                      >
                        {unit}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateThermalResistance} className="w-full" size="lg">
                  Calculate Thermal Resistance
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Thermal Resistance (R_th)</p>
                      <p className={`text-3xl font-bold ${result.color} mb-1`}>
                        {formatResult(result.resistance)} {outputUnit}
                      </p>
                      <p className={`text-sm font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Layer Breakdown for Multi-layer */}
                    {result.layers && result.layers.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-current/10">
                        <button
                          onClick={() => setShowSteps(!showSteps)}
                          className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                        >
                          {showSteps ? "Hide" : "Show"} Layer Breakdown
                        </button>
                        {showSteps && (
                          <div className="mt-3 space-y-2 text-sm">
                            {result.layers.map((layer, i) => (
                              <div key={i} className="flex justify-between">
                                <span>{layer.name}:</span>
                                <span className="font-mono">
                                  {formatResult(layer.resistance)} {outputUnit}
                                </span>
                              </div>
                            ))}
                            <div className="pt-2 border-t flex justify-between font-semibold">
                              <span>Total ({combineMode}):</span>
                              <span className="font-mono">
                                {formatResult(result.resistance)} {outputUnit}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Thermal Resistance Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-semibold mb-2">Conduction:</p>
                    <p className="font-mono text-center text-lg">R_th = L / (k × A)</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-semibold mb-2">Convection:</p>
                    <p className="font-mono text-center text-lg">R_th = 1 / (h × A)</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>L</strong> = Material thickness (m)
                    </p>
                    <p>
                      <strong>k</strong> = Thermal conductivity (W/m·K)
                    </p>
                    <p>
                      <strong>h</strong> = Heat transfer coefficient (W/m²·K)
                    </p>
                    <p>
                      <strong>A</strong> = Cross-sectional area (m²)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Material Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Copper</span>
                      <span className="font-mono">k ≈ 400 W/m·K</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Aluminum</span>
                      <span className="font-mono">k ≈ 205 W/m·K</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Steel</span>
                      <span className="font-mono">k ≈ 50 W/m·K</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Glass</span>
                      <span className="font-mono">k ≈ 1.0 W/m·K</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Fiberglass Insulation</span>
                      <span className="font-mono">k ≈ 0.04 W/m·K</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Air (still)</span>
                      <span className="font-mono">k ≈ 0.026 W/m·K</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Thermal Resistance */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Thermal Resistance?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Thermal resistance is a measure of a material's or system's ability to resist the flow of heat. It is
                  the temperature difference across a material or component divided by the heat transfer rate through
                  it. Higher thermal resistance means better insulation and less heat flow, while lower thermal
                  resistance indicates a material that conducts heat more readily.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept is analogous to electrical resistance in circuits, where thermal resistance opposes heat
                  flow just as electrical resistance opposes current flow. This analogy allows engineers to analyze
                  complex thermal systems using circuit analysis techniques, making it invaluable in electronics
                  cooling, building insulation design, and thermal management applications.
                </p>
              </CardContent>
            </Card>

            {/* Multi-layer Systems */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Multi-layer Thermal Resistance</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When heat flows through multiple layers in series (one after another), the total thermal resistance is
                  the sum of individual resistances: <strong>R_total = R₁ + R₂ + R₃ + ...</strong>
                  This is similar to resistors in series in an electrical circuit.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For parallel heat flow paths (side by side), the equivalent resistance is calculated as:
                  <strong> 1/R_total = 1/R₁ + 1/R₂ + 1/R₃ + ...</strong> This configuration allows heat to flow through
                  multiple paths simultaneously, reducing the overall thermal resistance of the system.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Thermal resistance calculations are estimates based on ideal conditions.
                  Actual heat transfer may vary due to material imperfections, contact resistance, and environmental
                  factors. Consult engineering references for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
