"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Percent, Info, AlertTriangle, Plus, Trash2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationType = "simple" | "complementary" | "compound"
type CompoundType = "independent" | "dependent" | "mutually-exclusive" | "union-independent"

interface ProbabilityResult {
  probability: number
  fraction: string
  percentage: string
  steps: string[]
}

interface EventInput {
  id: string
  favorable: string
  total: string
  probability?: string
  conditionalProbability?: string
}

export function ProbabilityCalculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>("simple")
  const [compoundType, setCompoundType] = useState<CompoundType>("independent")
  const [favorable, setFavorable] = useState("")
  const [total, setTotal] = useState("")
  const [events, setEvents] = useState<EventInput[]>([
    { id: "1", favorable: "", total: "", probability: "", conditionalProbability: "" },
    { id: "2", favorable: "", total: "", probability: "", conditionalProbability: "" },
  ])
  const [inputMode, setInputMode] = useState<"outcomes" | "probability">("outcomes")
  const [result, setResult] = useState<ProbabilityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const gcd = (a: number, b: number): number => {
    a = Math.abs(Math.round(a))
    b = Math.abs(Math.round(b))
    while (b) {
      const t = b
      b = a % b
      a = t
    }
    return a
  }

  const toFraction = (probability: number): string => {
    if (probability === 0) return "0/1"
    if (probability === 1) return "1/1"

    const precision = 1000000
    let numerator = Math.round(probability * precision)
    let denominator = precision
    const divisor = gcd(numerator, denominator)
    numerator = numerator / divisor
    denominator = denominator / divisor

    return `${numerator}/${denominator}`
  }

  const calculateProbability = () => {
    setError("")
    setResult(null)

    const steps: string[] = []
    let probability: number

    if (calculationType === "simple") {
      const f = Number.parseFloat(favorable)
      const n = Number.parseFloat(total)

      if (isNaN(f) || isNaN(n)) {
        setError("Please enter valid numbers for both fields")
        return
      }

      if (f < 0 || n <= 0) {
        setError("Values must be positive, and total outcomes must be greater than 0")
        return
      }

      if (f > n) {
        setError("Favorable outcomes cannot exceed total outcomes")
        return
      }

      probability = f / n
      steps.push(`Simple Probability Formula: P(E) = Favorable Outcomes / Total Outcomes`)
      steps.push(`P(E) = ${f} / ${n}`)
      steps.push(`P(E) = ${probability.toFixed(6)}`)
    } else if (calculationType === "complementary") {
      const f = Number.parseFloat(favorable)
      const n = Number.parseFloat(total)

      if (isNaN(f) || isNaN(n)) {
        setError("Please enter valid numbers for both fields")
        return
      }

      if (f < 0 || n <= 0) {
        setError("Values must be positive, and total outcomes must be greater than 0")
        return
      }

      if (f > n) {
        setError("Favorable outcomes cannot exceed total outcomes")
        return
      }

      const pEvent = f / n
      probability = 1 - pEvent
      steps.push(`First, calculate P(E): ${f} / ${n} = ${pEvent.toFixed(6)}`)
      steps.push(`Complementary Probability Formula: P(not E) = 1 - P(E)`)
      steps.push(`P(not E) = 1 - ${pEvent.toFixed(6)}`)
      steps.push(`P(not E) = ${probability.toFixed(6)}`)
    } else {
      // Compound probability
      const validEvents: { p: number; conditional?: number }[] = []

      for (let i = 0; i < events.length; i++) {
        const event = events[i]
        let p: number

        if (inputMode === "outcomes") {
          const f = Number.parseFloat(event.favorable)
          const n = Number.parseFloat(event.total)

          if (isNaN(f) || isNaN(n)) {
            setError(`Event ${i + 1}: Please enter valid numbers`)
            return
          }

          if (f < 0 || n <= 0) {
            setError(`Event ${i + 1}: Values must be positive`)
            return
          }

          if (f > n) {
            setError(`Event ${i + 1}: Favorable outcomes cannot exceed total outcomes`)
            return
          }

          p = f / n
        } else {
          p = Number.parseFloat(event.probability || "0")

          if (isNaN(p)) {
            setError(`Event ${i + 1}: Please enter a valid probability`)
            return
          }

          if (p < 0 || p > 1) {
            setError(`Event ${i + 1}: Probability must be between 0 and 1`)
            return
          }
        }

        let conditional: number | undefined
        if (compoundType === "dependent" && i > 0) {
          conditional = Number.parseFloat(event.conditionalProbability || "0")
          if (isNaN(conditional) || conditional < 0 || conditional > 1) {
            setError(`Event ${i + 1}: Please enter a valid conditional probability between 0 and 1`)
            return
          }
        }

        validEvents.push({ p, conditional })
      }

      if (compoundType === "independent") {
        // P(A ∩ B) = P(A) × P(B)
        probability = validEvents.reduce((acc, e) => acc * e.p, 1)
        steps.push(`Independent Events Formula: P(A ∩ B) = P(A) × P(B)`)
        steps.push(`Events: ${validEvents.map((e, i) => `P(E${i + 1}) = ${e.p.toFixed(4)}`).join(", ")}`)
        steps.push(`P(A ∩ B) = ${validEvents.map((e) => e.p.toFixed(4)).join(" × ")}`)
        steps.push(`P(A ∩ B) = ${probability.toFixed(6)}`)
      } else if (compoundType === "dependent") {
        // P(A ∩ B) = P(A) × P(B|A)
        probability = validEvents[0].p
        steps.push(`Dependent Events Formula: P(A ∩ B) = P(A) × P(B|A)`)
        steps.push(`P(E1) = ${validEvents[0].p.toFixed(4)}`)

        for (let i = 1; i < validEvents.length; i++) {
          const conditional = validEvents[i].conditional || validEvents[i].p
          probability *= conditional
          steps.push(`P(E${i + 1}|previous) = ${conditional.toFixed(4)}`)
        }

        steps.push(`Result: ${probability.toFixed(6)}`)
      } else if (compoundType === "mutually-exclusive") {
        // P(A ∪ B) = P(A) + P(B)
        probability = validEvents.reduce((acc, e) => acc + e.p, 0)
        if (probability > 1) {
          setError("Sum of probabilities exceeds 1. Events may not be mutually exclusive.")
          return
        }
        steps.push(`Mutually Exclusive Events Formula: P(A ∪ B) = P(A) + P(B)`)
        steps.push(`Events: ${validEvents.map((e, i) => `P(E${i + 1}) = ${e.p.toFixed(4)}`).join(", ")}`)
        steps.push(`P(A ∪ B) = ${validEvents.map((e) => e.p.toFixed(4)).join(" + ")}`)
        steps.push(`P(A ∪ B) = ${probability.toFixed(6)}`)
      } else {
        // Union of independent events: P(A ∪ B) = P(A) + P(B) - P(A)P(B)
        if (validEvents.length === 2) {
          const pA = validEvents[0].p
          const pB = validEvents[1].p
          probability = pA + pB - pA * pB
          steps.push(`Union of Independent Events Formula: P(A ∪ B) = P(A) + P(B) - P(A)×P(B)`)
          steps.push(`P(A) = ${pA.toFixed(4)}, P(B) = ${pB.toFixed(4)}`)
          steps.push(`P(A ∪ B) = ${pA.toFixed(4)} + ${pB.toFixed(4)} - (${pA.toFixed(4)} × ${pB.toFixed(4)})`)
          steps.push(`P(A ∪ B) = ${probability.toFixed(6)}`)
        } else {
          // General inclusion-exclusion for multiple events
          probability = 0
          for (let i = 0; i < validEvents.length; i++) {
            probability += validEvents[i].p
          }
          let product = 1
          for (const e of validEvents) {
            product *= e.p
          }
          probability = probability - product * (validEvents.length - 1)
          probability = Math.min(1, Math.max(0, probability))
          steps.push(`Union calculated using inclusion-exclusion principle`)
          steps.push(`P(Union) ≈ ${probability.toFixed(6)}`)
        }
      }
    }

    setResult({
      probability,
      fraction: toFraction(probability),
      percentage: (probability * 100).toFixed(2) + "%",
      steps,
    })
  }

  const handleReset = () => {
    setFavorable("")
    setTotal("")
    setEvents([
      { id: "1", favorable: "", total: "", probability: "", conditionalProbability: "" },
      { id: "2", favorable: "", total: "", probability: "", conditionalProbability: "" },
    ])
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Probability: ${result.probability.toFixed(6)} (${result.percentage}, ${result.fraction})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Probability Result",
          text: `Calculated probability: ${result.percentage} (${result.fraction})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const addEvent = () => {
    if (events.length < 6) {
      setEvents([
        ...events,
        { id: Date.now().toString(), favorable: "", total: "", probability: "", conditionalProbability: "" },
      ])
    }
  }

  const removeEvent = (id: string) => {
    if (events.length > 2) {
      setEvents(events.filter((e) => e.id !== id))
    }
  }

  const updateEvent = (id: string, field: keyof EventInput, value: string) => {
    setEvents(events.map((e) => (e.id === id ? { ...e, [field]: value } : e)))
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Percent className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Probability Calculator</CardTitle>
                    <CardDescription>Calculate event probabilities</CardDescription>
                  </div>
                </div>

                {/* Calculation Type Toggle */}
                <div className="space-y-3 pt-2">
                  <Label className="text-sm font-medium">Calculation Type</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "simple", label: "Simple" },
                      { value: "complementary", label: "Complement" },
                      { value: "compound", label: "Compound" },
                    ].map((type) => (
                      <button
                        key={type.value}
                        onClick={() => {
                          setCalculationType(type.value as CalculationType)
                          setResult(null)
                          setError("")
                        }}
                        className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                          calculationType === type.value
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted hover:bg-muted/80 text-muted-foreground"
                        }`}
                      >
                        {type.label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {(calculationType === "simple" || calculationType === "complementary") && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="favorable">Favorable Outcomes (f)</Label>
                      <Input
                        id="favorable"
                        type="number"
                        placeholder="e.g., 3"
                        value={favorable}
                        onChange={(e) => setFavorable(e.target.value)}
                        min="0"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="total">Total Possible Outcomes (n)</Label>
                      <Input
                        id="total"
                        type="number"
                        placeholder="e.g., 6"
                        value={total}
                        onChange={(e) => setTotal(e.target.value)}
                        min="1"
                      />
                    </div>
                  </>
                )}

                {calculationType === "compound" && (
                  <>
                    {/* Compound Type Selection */}
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Event Type</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { value: "independent", label: "Independent (A ∩ B)" },
                          { value: "dependent", label: "Dependent" },
                          { value: "mutually-exclusive", label: "Mutually Exclusive" },
                          { value: "union-independent", label: "Union (A ∪ B)" },
                        ].map((type) => (
                          <button
                            key={type.value}
                            onClick={() => {
                              setCompoundType(type.value as CompoundType)
                              setResult(null)
                              setError("")
                            }}
                            className={`px-3 py-2 text-xs font-medium rounded-lg transition-colors ${
                              compoundType === type.value
                                ? "bg-blue-100 text-blue-700 border-2 border-blue-300"
                                : "bg-muted hover:bg-muted/80 text-muted-foreground border-2 border-transparent"
                            }`}
                          >
                            {type.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Input Mode Toggle */}
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Input Mode</Label>
                      <button
                        onClick={() => setInputMode(inputMode === "outcomes" ? "probability" : "outcomes")}
                        className="relative inline-flex h-8 w-36 items-center rounded-full bg-muted p-1 transition-colors"
                      >
                        <span
                          className={`absolute h-6 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                            inputMode === "probability" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                          }`}
                        />
                        <span
                          className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                            inputMode === "outcomes" ? "text-primary-foreground" : "text-muted-foreground"
                          }`}
                        >
                          Outcomes
                        </span>
                        <span
                          className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                            inputMode === "probability" ? "text-primary-foreground" : "text-muted-foreground"
                          }`}
                        >
                          Probability
                        </span>
                      </button>
                    </div>

                    {/* Event Inputs */}
                    <div className="space-y-3">
                      {events.map((event, index) => (
                        <div key={event.id} className="p-3 bg-muted/50 rounded-lg space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Event {index + 1}</span>
                            {events.length > 2 && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeEvent(event.id)}
                                className="h-6 w-6 p-0 text-muted-foreground hover:text-red-500"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>

                          {inputMode === "outcomes" ? (
                            <div className="grid grid-cols-2 gap-2">
                              <Input
                                type="number"
                                placeholder="Favorable"
                                value={event.favorable}
                                onChange={(e) => updateEvent(event.id, "favorable", e.target.value)}
                                min="0"
                              />
                              <Input
                                type="number"
                                placeholder="Total"
                                value={event.total}
                                onChange={(e) => updateEvent(event.id, "total", e.target.value)}
                                min="1"
                              />
                            </div>
                          ) : (
                            <Input
                              type="number"
                              placeholder="Probability (0 to 1)"
                              value={event.probability}
                              onChange={(e) => updateEvent(event.id, "probability", e.target.value)}
                              min="0"
                              max="1"
                              step="0.01"
                            />
                          )}

                          {compoundType === "dependent" && index > 0 && (
                            <div className="pt-1">
                              <Label className="text-xs text-muted-foreground">P(E{index + 1} | previous events)</Label>
                              <Input
                                type="number"
                                placeholder="Conditional probability (0 to 1)"
                                value={event.conditionalProbability}
                                onChange={(e) => updateEvent(event.id, "conditionalProbability", e.target.value)}
                                min="0"
                                max="1"
                                step="0.01"
                                className="mt-1"
                              />
                            </div>
                          )}
                        </div>
                      ))}

                      {events.length < 6 && (
                        <Button variant="outline" size="sm" onClick={addEvent} className="w-full bg-transparent">
                          <Plus className="h-4 w-4 mr-1" />
                          Add Event
                        </Button>
                      )}
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateProbability} className="w-full" size="lg">
                  Calculate Probability
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {calculationType === "complementary" ? "Complementary Probability" : "Probability"}
                      </p>
                      <p className="text-4xl font-bold text-blue-600 mb-2">{result.percentage}</p>
                      <div className="flex justify-center gap-4 text-sm">
                        <span className="text-muted-foreground">
                          Decimal: <strong className="text-foreground">{result.probability.toFixed(6)}</strong>
                        </span>
                        <span className="text-muted-foreground">
                          Fraction: <strong className="text-foreground">{result.fraction}</strong>
                        </span>
                      </div>
                    </div>

                    {/* Step-by-step Toggle */}
                    {result.steps.length > 0 && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowSteps(!showSteps)}
                          className="text-sm text-blue-600 hover:underline w-full text-center"
                        >
                          {showSteps ? "Hide Steps" : "Show Step-by-Step Solution"}
                        </button>

                        {showSteps && (
                          <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-1">
                            {result.steps.map((step, i) => (
                              <p key={i} className="text-muted-foreground">
                                {step}
                              </p>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Probability Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-800 text-sm">Simple Probability</p>
                    <p className="text-blue-700 font-mono text-sm mt-1">P(E) = f / n</p>
                  </div>
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-medium text-purple-800 text-sm">Complementary</p>
                    <p className="text-purple-700 font-mono text-sm mt-1">P(not E) = 1 - P(E)</p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-800 text-sm">Independent Events</p>
                    <p className="text-green-700 font-mono text-sm mt-1">P(A ∩ B) = P(A) × P(B)</p>
                  </div>
                  <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                    <p className="font-medium text-orange-800 text-sm">Mutually Exclusive</p>
                    <p className="text-orange-700 font-mono text-sm mt-1">P(A ∪ B) = P(A) + P(B)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Coin flip:</strong> P(heads) = 1/2 = 50%
                  </p>
                  <p>
                    <strong>Dice roll (6):</strong> P(6) = 1/6 ≈ 16.67%
                  </p>
                  <p>
                    <strong>Card draw (Ace):</strong> P(Ace) = 4/52 ≈ 7.69%
                  </p>
                  <p>
                    <strong>Two heads:</strong> P = 1/2 × 1/2 = 25%
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-yellow-50 border-yellow-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Verify manually for critical calculations involving
                        risk assessment or statistical analysis.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Probability?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Probability is a branch of mathematics that deals with the likelihood of events occurring. It provides
                  a numerical measure of how likely an event is to happen, expressed as a value between 0 and 1, where 0
                  means the event is impossible and 1 means it is certain. Probability theory forms the foundation for
                  statistics, risk assessment, decision-making, and many scientific disciplines.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of probability has its roots in games of chance and gambling, dating back to the 16th
                  century. Mathematicians like Blaise Pascal and Pierre de Fermat laid the groundwork for probability
                  theory through their correspondence about dice games. Today, probability is essential in fields
                  ranging from quantum physics to finance, weather forecasting to machine learning.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Percent className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Probability</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Simple (Classical) Probability:</strong> This is the most basic form of probability,
                  calculated by dividing the number of favorable outcomes by the total number of possible outcomes. It
                  assumes all outcomes are equally likely. For example, the probability of rolling a 4 on a fair die is
                  1/6, since there is one favorable outcome out of six possible outcomes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Complementary Probability:</strong> The complement of an event E, written as P(not E) or
                  P(E'), is the probability that the event does not occur. It is calculated as 1 minus the probability
                  of the event. This is useful when it's easier to calculate the probability of something not happening.
                  For instance, the probability of NOT rolling a 6 is 1 - 1/6 = 5/6.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Compound Probability:</strong> This involves calculating the probability of two or more events
                  occurring together. Independent events don't affect each other (like separate coin flips), while
                  dependent events do affect each other (like drawing cards without replacement). Mutually exclusive
                  events cannot occur simultaneously (like rolling both a 3 and a 4 on a single die roll).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Insurance and Risk Assessment:</strong> Insurance companies use probability to calculate
                  premiums and assess risk. By analyzing historical data, they estimate the likelihood of claims and set
                  prices accordingly. Actuaries rely heavily on probability theory to ensure companies remain profitable
                  while providing coverage.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Medicine and Clinical Trials:</strong> Probability plays a crucial role in medical research.
                  Clinical trials use statistical probability to determine whether treatments are effective. Doctors use
                  probability when diagnosing diseases, considering the likelihood of various conditions based on
                  symptoms and test results.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Weather Forecasting:</strong> Meteorologists use probability to communicate uncertainty in
                  weather predictions. When you hear there's a 70% chance of rain, it means that under similar
                  atmospheric conditions, it rained 70% of the time historically. This probabilistic approach helps
                  people make informed decisions about their activities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Machine Learning and AI:</strong> Modern artificial intelligence systems are built on
                  probability theory. Machine learning algorithms use probabilistic models to make predictions, classify
                  data, and learn from experience. Bayesian probability, in particular, is fundamental to many AI
                  applications, from spam filters to recommendation systems.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
