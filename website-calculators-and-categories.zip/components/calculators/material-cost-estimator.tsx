"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Package, Info, Calculator, Trash2, Plus } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface Material {
  id: string
  name: string
  quantity: string
  unitCost: string
  wastage: string
}

export function MaterialCostEstimator() {
  const [materials, setMaterials] = useState<Material[]>([
    { id: "1", name: "Cement", quantity: "", unitCost: "", wastage: "5" },
    { id: "2", name: "Sand", quantity: "", unitCost: "", wastage: "10" },
    { id: "3", name: "Aggregate", quantity: "", unitCost: "", wastage: "10" },
  ])
  const [bulkDiscount, setBulkDiscount] = useState("0")
  const [currency, setCurrency] = useState<"USD" | "INR">("USD")
  const [result, setResult] = useState<{
    materialCosts: { name: string; cost: number }[]
    totalCost: number
    finalCost: number
  } | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const addMaterial = () => {
    setMaterials([
      ...materials,
      { id: Date.now().toString(), name: "", quantity: "", unitCost: "", wastage: "5" },
    ])
  }

  const removeMaterial = (id: string) => {
    if (materials.length > 1) {
      setMaterials(materials.filter((m) => m.id !== id))
    }
  }

  const updateMaterial = (id: string, field: keyof Material, value: string) => {
    setMaterials(materials.map((m) => (m.id === id ? { ...m, [field]: value } : m)))
  }

  const calculateCost = () => {
    setError("")
    setResult(null)

    // Validate all materials
    for (const material of materials) {
      if (!material.name.trim()) {
        setError("Please enter a name for all materials")
        return
      }
      const qty = Number.parseFloat(material.quantity)
      const cost = Number.parseFloat(material.unitCost)
      const wastage = Number.parseFloat(material.wastage)

      if (isNaN(qty) || qty <= 0) {
        setError(`Please enter a valid quantity for ${material.name}`)
        return
      }
      if (isNaN(cost) || cost <= 0) {
        setError(`Please enter a valid unit cost for ${material.name}`)
        return
      }
      if (isNaN(wastage) || wastage < 0) {
        setError(`Please enter a valid wastage percentage for ${material.name}`)
        return
      }
    }

    const discount = Number.parseFloat(bulkDiscount) || 0
    if (discount < 0 || discount > 100) {
      setError("Bulk discount must be between 0 and 100%")
      return
    }

    // Calculate costs
    const materialCosts = materials.map((material) => {
      const qty = Number.parseFloat(material.quantity)
      const cost = Number.parseFloat(material.unitCost)
      const wastage = Number.parseFloat(material.wastage) / 100

      const totalCost = qty * cost * (1 + wastage)
      return { name: material.name, cost: totalCost }
    })

    const totalCost = materialCosts.reduce((sum, m) => sum + m.cost, 0)
    const finalCost = totalCost * (1 - discount / 100)

    setResult({ materialCosts, totalCost, finalCost })
  }

  const handleReset = () => {
    setMaterials([
      { id: "1", name: "Cement", quantity: "", unitCost: "", wastage: "5" },
      { id: "2", name: "Sand", quantity: "", unitCost: "", wastage: "10" },
      { id: "3", name: "Aggregate", quantity: "", unitCost: "", wastage: "10" },
    ])
    setBulkDiscount("0")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Material Cost Estimate:\nTotal: ${currency === "USD" ? "$" : "₹"}${result.finalCost.toFixed(2)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Material Cost Estimate",
          text: `My material cost estimate is ${currency === "USD" ? "$" : "₹"}${result.finalCost.toFixed(2)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleCurrency = () => {
    setCurrency((prev) => (prev === "USD" ? "INR" : "USD"))
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Package className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Material Cost Estimator</CardTitle>
                    <CardDescription>Calculate total material costs for construction</CardDescription>
                  </div>
                </div>

                {/* Currency Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <button
                    onClick={toggleCurrency}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        currency === "INR" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        currency === "USD" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      USD
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        currency === "INR" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      INR
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4 max-h-[600px] overflow-y-auto">
                {/* Materials List */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Materials</Label>
                    <Button variant="outline" size="sm" onClick={addMaterial}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {materials.map((material, index) => (
                    <div key={material.id} className="p-3 border rounded-lg bg-muted/30 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Material {index + 1}</span>
                        {materials.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeMaterial(material.id)}
                            className="h-7 w-7 p-0"
                          >
                            <Trash2 className="h-4 w-4 text-muted-foreground" />
                          </Button>
                        )}
                      </div>

                      <Input
                        placeholder="Material name (e.g., Cement)"
                        value={material.name}
                        onChange={(e) => updateMaterial(material.id, "name", e.target.value)}
                      />

                      <div className="grid grid-cols-3 gap-2">
                        <Input
                          type="number"
                          placeholder="Quantity"
                          value={material.quantity}
                          onChange={(e) => updateMaterial(material.id, "quantity", e.target.value)}
                          min="0"
                          step="0.01"
                        />
                        <Input
                          type="number"
                          placeholder={`Cost/${currency === "USD" ? "$" : "₹"}`}
                          value={material.unitCost}
                          onChange={(e) => updateMaterial(material.id, "unitCost", e.target.value)}
                          min="0"
                          step="0.01"
                        />
                        <Input
                          type="number"
                          placeholder="Wastage%"
                          value={material.wastage}
                          onChange={(e) => updateMaterial(material.id, "wastage", e.target.value)}
                          min="0"
                          max="100"
                          step="0.1"
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Bulk Discount */}
                <div className="space-y-2">
                  <Label htmlFor="discount">Bulk Purchase Discount (%)</Label>
                  <Input
                    id="discount"
                    type="number"
                    placeholder="Enter discount percentage"
                    value={bulkDiscount}
                    onChange={(e) => setBulkDiscount(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCost} className="w-full" size="lg">
                  Calculate Cost
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Material Cost</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {currency === "USD" ? "$" : "₹"}
                          {result.finalCost.toFixed(2)}
                        </p>
                      </div>

                      {/* Breakdown */}
                      <div className="space-y-2">
                        {result.materialCosts.map((m, i) => (
                          <div key={i} className="flex justify-between text-sm">
                            <span className="text-muted-foreground">{m.name}</span>
                            <span className="font-medium">
                              {currency === "USD" ? "$" : "₹"}
                              {m.cost.toFixed(2)}
                            </span>
                          </div>
                        ))}
                        {result.totalCost !== result.finalCost && (
                          <>
                            <div className="border-t border-amber-200 pt-2 flex justify-between text-sm">
                              <span className="text-muted-foreground">Subtotal</span>
                              <span className="font-medium">
                                {currency === "USD" ? "$" : "₹"}
                                {result.totalCost.toFixed(2)}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-green-600">Discount ({bulkDiscount}%)</span>
                              <span className="font-medium text-green-600">
                                -{currency === "USD" ? "$" : "₹"}
                                {(result.totalCost - result.finalCost).toFixed(2)}
                              </span>
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Materials</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Cement</p>
                      <p className="text-muted-foreground">Typical wastage: 5-8%</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Sand & Aggregate</p>
                      <p className="text-muted-foreground">Typical wastage: 10-15%</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Bricks/Blocks</p>
                      <p className="text-muted-foreground">Typical wastage: 5-10%</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Steel Reinforcement</p>
                      <p className="text-muted-foreground">Typical wastage: 2-5%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Wastage Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>Wastage percentage accounts for material loss during:</p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>Transportation and handling</li>
                    <li>Cutting and fitting</li>
                    <li>Breakage and damage</li>
                    <li>Storage losses</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Material Cost Estimation */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Material Cost Estimation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Material cost estimation is a crucial component of construction project planning that involves
                  calculating the total cost of all materials required for a building project. This process helps
                  contractors, builders, and homeowners budget accurately and ensure sufficient funds are available to
                  complete the project. A comprehensive material cost estimate includes not only the base cost of
                  materials but also factors like wastage, transportation, and bulk purchase discounts.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Accurate material cost estimation is essential for project success. It helps prevent budget overruns,
                  ensures timely procurement of materials, and allows for better financial planning. Professional
                  estimators consider various factors including material quality, supplier pricing, market fluctuations,
                  and project-specific requirements to provide realistic cost projections.
                </p>
              </CardContent>
            </Card>

            {/* How to Estimate Material Costs */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Estimate Material Costs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The material cost estimation process begins with a detailed quantity takeoff from construction
                  drawings and specifications. For each material type, you need to determine the required quantity based
                  on the project scope. Then multiply the quantity by the current unit cost from suppliers. It's
                  important to add wastage percentages appropriate for each material type - for example, cement
                  typically has 5-8% wastage, while sand and aggregate may have 10-15% wastage due to handling and
                  moisture content.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  After calculating individual material costs, sum them to get the total material cost. If you're
                  purchasing in bulk, suppliers often offer discounts of 5-20% depending on order volume. Consider also
                  factors like delivery charges, storage costs, and price escalation for long-duration projects. Regular
                  market surveys and maintaining relationships with multiple suppliers help ensure competitive pricing
                  and accurate estimates.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions About Material Costs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How do I reduce material wastage?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Proper planning, accurate measurements, careful handling, and good site management significantly
                      reduce wastage. Order materials in standard sizes when possible, store them properly to prevent
                      damage, and use quality materials that are less prone to breakage. Training workers in proper
                      handling techniques also helps minimize waste.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What affects material prices?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Material prices fluctuate based on raw material availability, fuel costs, seasonal demand,
                      manufacturing costs, transportation expenses, and market conditions. Local factors like proximity
                      to manufacturing units, regional demand, and availability of alternatives also impact pricing.
                      Regular market monitoring helps anticipate price changes.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Should I buy all materials at once?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      This depends on storage capacity, project timeline, and price trends. Buying in bulk often gets
                      discounts but requires adequate storage space and upfront capital. For materials prone to damage
                      or deterioration, phased purchasing is better. Consider price volatility - buy materials likely
                      to increase in price early, but wait on stable-priced items.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How accurate are material cost estimates?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Professional estimates are typically 85-95% accurate when based on detailed plans and current
                      market rates. Accuracy improves with experience and comprehensive quantity takeoffs. However,
                      actual costs may vary due to price fluctuations, design changes, or unforeseen requirements. Most
                      projects include a 5-10% contingency to account for these variations.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Material cost estimates are approximate and for planning purposes only.
                  Actual costs depend on material quality, supplier pricing, market conditions, location, quantity
                  discounts, and delivery charges. Always obtain quotes from multiple suppliers and add appropriate
                  contingency for price fluctuations and unforeseen requirements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
