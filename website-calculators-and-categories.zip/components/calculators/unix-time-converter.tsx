"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Clock, Info, AlertTriangle, RefreshCw, ArrowRightLeft } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type ConversionMode = "timestamp-to-date" | "date-to-timestamp"

interface ConversionResult {
  timestamp: number
  milliseconds: number
  dateString: string
  dateISO: string
  dateUTC: string
  timeZone: string
}

const timeZones = [
  { value: "UTC", label: "UTC (Coordinated Universal Time)", offset: 0 },
  { value: "America/New_York", label: "Eastern Time (ET)", offset: -5 },
  { value: "America/Chicago", label: "Central Time (CT)", offset: -6 },
  { value: "America/Denver", label: "Mountain Time (MT)", offset: -7 },
  { value: "America/Los_Angeles", label: "Pacific Time (PT)", offset: -8 },
  { value: "Europe/London", label: "London (GMT/BST)", offset: 0 },
  { value: "Europe/Paris", label: "Paris (CET/CEST)", offset: 1 },
  { value: "Europe/Berlin", label: "Berlin (CET/CEST)", offset: 1 },
  { value: "Asia/Tokyo", label: "Tokyo (JST)", offset: 9 },
  { value: "Asia/Shanghai", label: "Shanghai (CST)", offset: 8 },
  { value: "Asia/Kolkata", label: "India (IST)", offset: 5.5 },
  { value: "Asia/Dubai", label: "Dubai (GST)", offset: 4 },
  { value: "Australia/Sydney", label: "Sydney (AEST/AEDT)", offset: 10 },
  { value: "Pacific/Auckland", label: "Auckland (NZST/NZDT)", offset: 12 },
]

export function UnixTimeConverter() {
  const [mode, setMode] = useState<ConversionMode>("timestamp-to-date")
  const [timestamp, setTimestamp] = useState("")
  const [dateInput, setDateInput] = useState("")
  const [timeInput, setTimeInput] = useState("")
  const [useMilliseconds, setUseMilliseconds] = useState(false)
  const [allowNegative, setAllowNegative] = useState(false)
  const [selectedTimeZone, setSelectedTimeZone] = useState("UTC")
  const [result, setResult] = useState<ConversionResult | null>(null)
  const [currentUnixTime, setCurrentUnixTime] = useState<number>(0)
  const [copied, setCopied] = useState<string | null>(null)
  const [error, setError] = useState("")

  // Update current UNIX time every second
  useEffect(() => {
    const updateTime = () => {
      setCurrentUnixTime(Math.floor(Date.now() / 1000))
    }
    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  const formatDateForTimeZone = (date: Date, timeZone: string): string => {
    try {
      return date.toLocaleString("en-US", {
        timeZone,
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      })
    } catch {
      return date.toLocaleString()
    }
  }

  const convertTimestampToDate = () => {
    setError("")
    setResult(null)

    const timestampNum = Number(timestamp)
    if (isNaN(timestampNum)) {
      setError("Please enter a valid numeric timestamp")
      return
    }

    if (!allowNegative && timestampNum < 0) {
      setError("Negative timestamps are disabled. Enable 'Allow pre-1970 dates' to use negative values.")
      return
    }

    // Check for reasonable range (year -10000 to 10000)
    const maxTimestamp = 253402300799 // Dec 31, 9999
    const minTimestamp = allowNegative ? -62135596800 : 0 // Jan 1, 0001 or Jan 1, 1970

    let actualTimestamp = timestampNum
    if (useMilliseconds) {
      actualTimestamp = Math.floor(timestampNum / 1000)
      if (Math.abs(timestampNum) > maxTimestamp * 1000) {
        setError("Timestamp is out of valid date range")
        return
      }
    } else {
      if (timestampNum > maxTimestamp || timestampNum < minTimestamp) {
        setError("Timestamp is out of valid date range")
        return
      }
    }

    const date = new Date(useMilliseconds ? timestampNum : timestampNum * 1000)

    if (isNaN(date.getTime())) {
      setError("Invalid timestamp value")
      return
    }

    setResult({
      timestamp: actualTimestamp,
      milliseconds: useMilliseconds ? timestampNum : timestampNum * 1000,
      dateString: formatDateForTimeZone(date, selectedTimeZone),
      dateISO: date.toISOString(),
      dateUTC: date.toUTCString(),
      timeZone: selectedTimeZone,
    })
  }

  const convertDateToTimestamp = () => {
    setError("")
    setResult(null)

    if (!dateInput) {
      setError("Please select a date")
      return
    }

    const timeValue = timeInput || "00:00:00"
    const dateTimeString = `${dateInput}T${timeValue}`

    let date: Date
    if (selectedTimeZone === "UTC") {
      date = new Date(dateTimeString + "Z")
    } else {
      // Create date in local time then adjust
      date = new Date(dateTimeString)
    }

    if (isNaN(date.getTime())) {
      setError("Invalid date or time value")
      return
    }

    const timestampSeconds = Math.floor(date.getTime() / 1000)

    if (!allowNegative && timestampSeconds < 0) {
      setError("Date is before January 1, 1970. Enable 'Allow pre-1970 dates' to convert.")
      return
    }

    setResult({
      timestamp: timestampSeconds,
      milliseconds: date.getTime(),
      dateString: formatDateForTimeZone(date, selectedTimeZone),
      dateISO: date.toISOString(),
      dateUTC: date.toUTCString(),
      timeZone: selectedTimeZone,
    })
  }

  const handleConvert = () => {
    if (mode === "timestamp-to-date") {
      convertTimestampToDate()
    } else {
      convertDateToTimestamp()
    }
  }

  const handleReset = () => {
    setTimestamp("")
    setDateInput("")
    setTimeInput("")
    setResult(null)
    setError("")
    setCopied(null)
  }

  const handleCopy = async (value: string, type: string) => {
    await navigator.clipboard.writeText(value)
    setCopied(type)
    setTimeout(() => setCopied(null), 2000)
  }

  const useCurrentTime = () => {
    if (mode === "timestamp-to-date") {
      setTimestamp(useMilliseconds ? Date.now().toString() : currentUnixTime.toString())
    } else {
      const now = new Date()
      setDateInput(now.toISOString().split("T")[0])
      setTimeInput(now.toTimeString().split(" ")[0])
    }
  }

  const toggleMode = () => {
    setMode(mode === "timestamp-to-date" ? "date-to-timestamp" : "timestamp-to-date")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Clock className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">UNIX Time Converter</CardTitle>
                    <CardDescription>Convert between epoch time and dates</CardDescription>
                  </div>
                </div>

                {/* Live UNIX Time */}
                <div className="p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Current UNIX Time:</span>
                    <div className="flex items-center gap-2">
                      <code className="font-mono text-lg font-semibold text-primary">{currentUnixTime}</code>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 w-7 p-0"
                        onClick={() => handleCopy(currentUnixTime.toString(), "current")}
                      >
                        {copied === "current" ? (
                          <Check className="h-3 w-3 text-green-600" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Conversion Mode</span>
                  <button
                    onClick={toggleMode}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "date-to-timestamp" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        mode === "timestamp-to-date" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Timestamp → Date
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        mode === "date-to-timestamp" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Date → Timestamp
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Options */}
                <div className="flex flex-wrap gap-4">
                  <div className="flex items-center gap-2">
                    <Switch id="milliseconds" checked={useMilliseconds} onCheckedChange={setUseMilliseconds} />
                    <Label htmlFor="milliseconds" className="text-sm">
                      Milliseconds
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch id="negative" checked={allowNegative} onCheckedChange={setAllowNegative} />
                    <Label htmlFor="negative" className="text-sm">
                      Allow pre-1970
                    </Label>
                  </div>
                </div>

                {/* Time Zone Selection */}
                <div className="space-y-2">
                  <Label>Time Zone</Label>
                  <Select value={selectedTimeZone} onValueChange={setSelectedTimeZone}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select time zone" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeZones.map((tz) => (
                        <SelectItem key={tz.value} value={tz.value}>
                          {tz.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Input Fields */}
                {mode === "timestamp-to-date" ? (
                  <div className="space-y-2">
                    <Label htmlFor="timestamp">UNIX Timestamp ({useMilliseconds ? "milliseconds" : "seconds"})</Label>
                    <div className="flex gap-2">
                      <Input
                        id="timestamp"
                        type="text"
                        placeholder={useMilliseconds ? "e.g., 1703462400000" : "e.g., 1703462400"}
                        value={timestamp}
                        onChange={(e) => setTimestamp(e.target.value)}
                        className="font-mono"
                      />
                      <Button variant="outline" size="icon" onClick={useCurrentTime} title="Use current time">
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="date">Date</Label>
                      <div className="flex gap-2">
                        <Input id="date" type="date" value={dateInput} onChange={(e) => setDateInput(e.target.value)} />
                        <Button variant="outline" size="icon" onClick={useCurrentTime} title="Use current time">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="time">Time (optional)</Label>
                      <Input
                        id="time"
                        type="time"
                        step="1"
                        value={timeInput}
                        onChange={(e) => setTimeInput(e.target.value)}
                        placeholder="HH:MM:SS"
                      />
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                    {error}
                  </div>
                )}

                {/* Convert Button */}
                <Button onClick={handleConvert} className="w-full" size="lg">
                  <ArrowRightLeft className="mr-2 h-4 w-4" />
                  Convert
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="space-y-3">
                      {/* Timestamp Result */}
                      <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <div>
                          <p className="text-xs text-muted-foreground">UNIX Timestamp (seconds)</p>
                          <p className="font-mono text-lg font-semibold">{result.timestamp}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopy(result.timestamp.toString(), "timestamp")}
                        >
                          {copied === "timestamp" ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>

                      {/* Milliseconds Result */}
                      <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <div>
                          <p className="text-xs text-muted-foreground">UNIX Timestamp (milliseconds)</p>
                          <p className="font-mono text-lg font-semibold">{result.milliseconds}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopy(result.milliseconds.toString(), "milliseconds")}
                        >
                          {copied === "milliseconds" ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>

                      {/* Human Readable Date */}
                      <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <div>
                          <p className="text-xs text-muted-foreground">Human Readable ({result.timeZone})</p>
                          <p className="font-medium">{result.dateString}</p>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => handleCopy(result.dateString, "readable")}>
                          {copied === "readable" ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>

                      {/* ISO 8601 */}
                      <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <div>
                          <p className="text-xs text-muted-foreground">ISO 8601</p>
                          <p className="font-mono text-sm">{result.dateISO}</p>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => handleCopy(result.dateISO, "iso")}>
                          {copied === "iso" ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>

                      {/* UTC String */}
                      <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <div>
                          <p className="text-xs text-muted-foreground">UTC String</p>
                          <p className="font-mono text-sm">{result.dateUTC}</p>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => handleCopy(result.dateUTC, "utc")}>
                          {copied === "utc" ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t border-cyan-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Timestamps</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {[
                      { label: "UNIX Epoch", timestamp: 0, date: "Jan 1, 1970 00:00:00 UTC" },
                      { label: "Y2K", timestamp: 946684800, date: "Jan 1, 2000 00:00:00 UTC" },
                      { label: "Y2K38 Problem", timestamp: 2147483647, date: "Jan 19, 2038 03:14:07 UTC" },
                      { label: "Year 3000", timestamp: 32503680000, date: "Jan 1, 3000 00:00:00 UTC" },
                    ].map((item) => (
                      <div
                        key={item.label}
                        className="flex items-center justify-between p-2 rounded-lg bg-muted/50 text-sm"
                      >
                        <div>
                          <p className="font-medium">{item.label}</p>
                          <p className="text-xs text-muted-foreground">{item.date}</p>
                        </div>
                        <code className="font-mono text-xs bg-background px-2 py-1 rounded">{item.timestamp}</code>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">UNIX Time Info</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">What is UNIX Time?</p>
                    <p>
                      UNIX time (also known as Epoch time or POSIX time) is the number of seconds that have elapsed
                      since January 1, 1970, at 00:00:00 UTC, not counting leap seconds.
                    </p>
                  </div>
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-yellow-800 text-xs">
                      <strong>Note:</strong> UNIX time is based on UTC and does not account for leap seconds.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding UNIX Timestamps</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  UNIX time, also known as Epoch time or POSIX time, is a system for tracking time as a running total of
                  seconds. This count started at the "UNIX Epoch" on January 1st, 1970 at UTC. Therefore, the UNIX time
                  is merely the number of seconds between a particular date and the UNIX Epoch. This system is widely
                  used in computing because it provides a simple, unambiguous way to represent any point in time as a
                  single number.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The beauty of UNIX timestamps lies in their simplicity and universality. Unlike human-readable date
                  formats that vary by locale and can be ambiguous (is 01/02/03 January 2nd or February 1st?), UNIX
                  timestamps are unambiguous. They also make date arithmetic trivially easy - to find the time 24 hours
                  from now, simply add 86,400 (the number of seconds in a day) to the current timestamp.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Seconds vs Milliseconds</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Traditional UNIX timestamps are measured in seconds since the epoch. However, many modern programming
                  languages and systems use milliseconds for greater precision. JavaScript's Date.now() function, for
                  example, returns the time in milliseconds. When working with timestamps, it's crucial to know which
                  unit you're dealing with.
                </p>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Seconds (10 digits)</h4>
                    <p className="text-blue-700 text-sm">
                      Used by: UNIX/Linux systems, PHP, Python, most databases, and traditional UNIX tools. Example:
                      1703462400
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Milliseconds (13 digits)</h4>
                    <p className="text-purple-700 text-sm">
                      Used by: JavaScript, Java, and many modern APIs. Example: 1703462400000
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>The Year 2038 Problem</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Many older systems store UNIX timestamps as 32-bit signed integers, which can represent values up to
                  2,147,483,647. This corresponds to Tuesday, January 19, 2038, at 03:14:07 UTC. After this moment, the
                  timestamp will overflow and wrap around to a negative number, potentially causing software to
                  interpret dates as being in 1901.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Modern systems have largely migrated to 64-bit timestamps, which can represent dates billions of years
                  into the future. However, legacy systems and embedded devices may still be vulnerable. This is why
                  it's important to use appropriate data types when working with timestamps in your applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Database Storage</h4>
                    <p className="text-sm text-muted-foreground">
                      Timestamps are often stored as integers in databases, making them efficient to store, index, and
                      compare. They're timezone-agnostic, preventing issues when data is accessed from different
                      locations.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">API Communication</h4>
                    <p className="text-sm text-muted-foreground">
                      Many REST APIs use UNIX timestamps to communicate dates between systems. This ensures consistency
                      regardless of the client's locale or timezone settings.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Logging & Debugging</h4>
                    <p className="text-sm text-muted-foreground">
                      Log files often use UNIX timestamps for event timing. They're easy to sort and make it simple to
                      calculate elapsed time between events.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Caching & Expiration</h4>
                    <p className="text-sm text-muted-foreground">
                      Cache systems use timestamps to determine when cached data expires. Comparing the current
                      timestamp to the expiration timestamp is a simple integer comparison.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
