"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Building2, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface BuiltUpResult {
  plinthArea: number
  wallArea: number
  balconyArea: number
  utilityArea: number
  totalBuiltUpArea: number
  superBuiltUpArea: number | null
  unit: string
}

export function BuiltUpAreaCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [plinthArea, setPlinthArea] = useState("")
  const [wallThickness, setWallThickness] = useState("")
  const [balconyArea, setBalconyArea] = useState("")
  const [utilityArea, setUtilityArea] = useState("")
  const [floors, setFloors] = useState("1")
  const [superFactor, setSuperFactor] = useState("")
  const [result, setResult] = useState<BuiltUpResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBuiltUpArea = () => {
    setError("")
    setResult(null)

    const plinthAreaNum = Number.parseFloat(plinthArea)
    const wallThicknessNum = wallThickness ? Number.parseFloat(wallThickness) : 0
    const balconyAreaNum = balconyArea ? Number.parseFloat(balconyArea) : 0
    const utilityAreaNum = utilityArea ? Number.parseFloat(utilityArea) : 0
    const floorsNum = Number.parseInt(floors)
    const superFactorNum = superFactor ? Number.parseFloat(superFactor) : 0

    if (isNaN(plinthAreaNum) || plinthAreaNum <= 0) {
      setError("Please enter a valid plinth area greater than 0")
      return
    }

    if (balconyAreaNum < 0 || utilityAreaNum < 0) {
      setError("Areas cannot be negative")
      return
    }

    if (isNaN(floorsNum) || floorsNum < 1) {
      setError("Number of floors must be at least 1")
      return
    }

    if (superFactorNum > 0 && superFactorNum <= 1) {
      setError("Super built-up factor must be greater than 1")
      return
    }

    // Estimate wall area if wall thickness is provided
    // Simplified: assume square root for approximate perimeter calculation
    const sideLength = Math.sqrt(plinthAreaNum)
    const perimeter = 4 * sideLength
    const wallArea = wallThicknessNum > 0 ? perimeter * wallThicknessNum : 0

    const singleFloorBuiltUp = plinthAreaNum + wallArea + balconyAreaNum + utilityAreaNum
    const totalBuiltUpArea = singleFloorBuiltUp * floorsNum

    const superBuiltUpArea = superFactorNum > 1 ? totalBuiltUpArea * superFactorNum : null

    const unit = unitSystem === "metric" ? "m²" : "ft²"

    setResult({
      plinthArea: Math.round(plinthAreaNum * 100) / 100,
      wallArea: Math.round(wallArea * 100) / 100,
      balconyArea: balconyAreaNum,
      utilityArea: utilityAreaNum,
      totalBuiltUpArea: Math.round(totalBuiltUpArea * 100) / 100,
      superBuiltUpArea: superBuiltUpArea ? Math.round(superBuiltUpArea * 100) / 100 : null,
      unit,
    })
  }

  const handleReset = () => {
    setPlinthArea("")
    setWallThickness("")
    setBalconyArea("")
    setUtilityArea("")
    setFloors("1")
    setSuperFactor("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.superBuiltUpArea
        ? `Built-Up Area: ${result.totalBuiltUpArea} ${result.unit}, Super Built-Up Area: ${result.superBuiltUpArea} ${result.unit}`
        : `Built-Up Area: ${result.totalBuiltUpArea} ${result.unit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Built-Up Area Calculation",
          text: `Built-Up Area: ${result.totalBuiltUpArea} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setPlinthArea("")
    setWallThickness("")
    setBalconyArea("")
    setUtilityArea("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Built-Up Area Calculator</CardTitle>
                    <CardDescription>Calculate total built-up area</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Plinth Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="plinthArea">Plinth Area ({unitSystem === "metric" ? "m²" : "ft²"})</Label>
                  <Input
                    id="plinthArea"
                    type="number"
                    placeholder="Enter plinth area"
                    value={plinthArea}
                    onChange={(e) => setPlinthArea(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Wall Thickness Input */}
                <div className="space-y-2">
                  <Label htmlFor="wallThickness">
                    Wall Thickness (Optional, {unitSystem === "metric" ? "m" : "ft"})
                  </Label>
                  <Input
                    id="wallThickness"
                    type="number"
                    placeholder="Enter wall thickness"
                    value={wallThickness}
                    onChange={(e) => setWallThickness(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Balcony Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="balconyArea">
                    Balcony Area (Optional, {unitSystem === "metric" ? "m²" : "ft²"})
                  </Label>
                  <Input
                    id="balconyArea"
                    type="number"
                    placeholder="Enter balcony area"
                    value={balconyArea}
                    onChange={(e) => setBalconyArea(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Utility Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="utilityArea">
                    Utility/Other Area (Optional, {unitSystem === "metric" ? "m²" : "ft²"})
                  </Label>
                  <Input
                    id="utilityArea"
                    type="number"
                    placeholder="Enter utility area"
                    value={utilityArea}
                    onChange={(e) => setUtilityArea(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Number of Floors */}
                <div className="space-y-2">
                  <Label htmlFor="floors">Number of Floors</Label>
                  <Input
                    id="floors"
                    type="number"
                    placeholder="Enter number of floors"
                    value={floors}
                    onChange={(e) => setFloors(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Super Built-Up Factor */}
                <div className="space-y-2">
                  <Label htmlFor="superFactor">Super Built-Up Factor (Optional, {"> 1"})</Label>
                  <Input
                    id="superFactor"
                    type="number"
                    placeholder="E.g., 1.2 or 1.25"
                    value={superFactor}
                    onChange={(e) => setSuperFactor(e.target.value)}
                    min="1"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">
                    Common factors: 1.15-1.3 (includes common areas)
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBuiltUpArea} className="w-full" size="lg">
                  Calculate Built-Up Area
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Built-Up Area</p>
                        <p className="text-4xl font-bold text-amber-600">{result.totalBuiltUpArea}</p>
                        <p className="text-lg font-semibold text-amber-600">{result.unit}</p>
                      </div>

                      {result.superBuiltUpArea && (
                        <div className="text-center pb-3 border-b border-amber-200">
                          <p className="text-sm text-muted-foreground mb-1">Super Built-Up Area</p>
                          <p className="text-3xl font-bold text-amber-600">{result.superBuiltUpArea}</p>
                          <p className="text-base font-semibold text-amber-600">{result.unit}</p>
                        </div>
                      )}

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Plinth Area:</span>
                          <span className="font-medium">
                            {result.plinthArea} {result.unit}
                          </span>
                        </div>
                        {result.wallArea > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Wall Area (est.):</span>
                            <span className="font-medium">
                              {result.wallArea} {result.unit}
                            </span>
                          </div>
                        )}
                        {result.balconyArea > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Balcony Area:</span>
                            <span className="font-medium">
                              {result.balconyArea} {result.unit}
                            </span>
                          </div>
                        )}
                        {result.utilityArea > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Utility Area:</span>
                            <span className="font-medium">
                              {result.utilityArea} {result.unit}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Built-Up Area Components</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-muted-foreground">
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <p className="font-semibold text-amber-800 mb-1">Plinth Area</p>
                    <p className="text-amber-700">Covered area at floor level including internal walls</p>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <p className="font-semibold text-amber-800 mb-1">Wall Area</p>
                    <p className="text-amber-700">Area occupied by external walls</p>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <p className="font-semibold text-amber-800 mb-1">Balcony & Utility</p>
                    <p className="text-amber-700">Covered balconies and utility spaces</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Area Comparison</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Carpet Area: 70-75% of Built-Up Area</p>
                  <p>• Built-Up Area: Plinth + Walls + Balconies</p>
                  <p>• Super Built-Up: Built-Up × Factor (1.15-1.3)</p>
                  <p>• Factor includes common areas & amenities</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Built-Up Area */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Built-Up Area?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Built-up area is the total floor area of a building including the area covered by walls, balconies, and
                  other covered spaces. It represents the complete constructed area of a property and is larger than the
                  carpet area (usable floor space) but typically smaller than the super built-up area. The built-up area is a
                  crucial metric in real estate transactions, construction planning, and property valuation as it directly
                  affects the cost of construction and the selling price of properties.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding built-up area is essential for both property buyers and developers. For buyers, it helps in
                  comparing properties on an equal basis and understanding what they're paying for. For developers and
                  contractors, it's fundamental for cost estimation, material procurement, and project planning. The built-up
                  area includes all the components that make up the physical structure of the building, providing a
                  comprehensive view of the total constructed space.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Built-Up Area */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Built-Up Area</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating built-up area involves adding several components together. Start with the plinth area (the
                  covered area at floor level), then add the area occupied by external walls. The wall area can be estimated
                  by multiplying the building's perimeter by the wall thickness. Next, add any covered balconies,
                  terraces, or utility areas that are enclosed or covered. For multi-story buildings, calculate the built-up
                  area for each floor separately and sum them to get the total built-up area.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, if a single-floor building has a plinth area of 100 m², wall area of 15 m² (based on wall
                  thickness and perimeter), balcony area of 10 m², and utility area of 5 m², the total built-up area would
                  be 100 + 15 + 10 + 5 = 130 m². If this is a 3-story building with identical floors, the total built-up
                  area would be 130 × 3 = 390 m². Super built-up area adds a factor (typically 1.15 to 1.3) to account for
                  common areas like hallways, elevators, and shared amenities in multi-unit developments.
                </p>
              </CardContent>
            </Card>

            {/* Importance in Real Estate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  <CardTitle>Importance in Real Estate and Construction</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Built-up area plays a vital role in real estate pricing and legal documentation. In many markets,
                  developers price properties based on super built-up area (which is derived from built-up area), making it
                  crucial for buyers to understand what they're paying for. The built-up area is often used for property
                  registration, stamp duty calculation, and determining building approval charges from municipal authorities.
                  It's also the basis for calculating construction costs, as contractors typically quote rates per square foot
                  or square meter of built-up area.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For property tax assessment, many municipalities use built-up area as one of the primary factors. Banks and
                  financial institutions also consider built-up area when evaluating property for loans and mortgages. In
                  commercial real estate, built-up area determines rental rates, insurance premiums, and maintenance charges.
                  Understanding the precise built-up area helps avoid disputes between buyers and sellers, ensures fair
                  pricing, and provides transparency in real estate transactions. Always verify the built-up area through
                  official building plans and approved architectural drawings before finalizing any property deal.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2 text-sm text-amber-800">
                    <p className="font-semibold">Important Note:</p>
                    <p className="leading-relaxed">
                      Built-up area calculations are approximate. Actual measurements may vary depending on wall thickness,
                      projections, and architectural features. Always consult with a licensed architect or surveyor for
                      precise measurements and official documentation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
