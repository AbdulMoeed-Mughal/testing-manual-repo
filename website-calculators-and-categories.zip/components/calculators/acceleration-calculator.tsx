"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Gauge, Info, AlertTriangle, Zap, Timer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "acceleration" | "final-velocity" | "time"

interface AccelerationResult {
  acceleration: number
  initialVelocity: number
  finalVelocity: number
  time: number
  velocityChange: number
}

const velocityUnits = [
  { value: "ms", label: "m/s", factor: 1 },
  { value: "kmh", label: "km/h", factor: 1 / 3.6 },
  { value: "mph", label: "mph", factor: 0.44704 },
]

const timeUnits = [
  { value: "s", label: "seconds", factor: 1 },
  { value: "min", label: "minutes", factor: 60 },
]

const presets = [
  { name: "Free Fall", initialV: 0, finalV: 9.81, time: 1, description: "1 second of free fall" },
  { name: "Car 0-60 mph", initialV: 0, finalV: 26.82, time: 6, description: "Sports car acceleration" },
  { name: "Bicycle Stop", initialV: 5, finalV: 0, time: 3, description: "Braking from 5 m/s" },
  { name: "Rocket Launch", initialV: 0, finalV: 100, time: 5, description: "Initial rocket acceleration" },
]

export function AccelerationCalculator() {
  const [mode, setMode] = useState<CalculationMode>("acceleration")
  const [initialVelocity, setInitialVelocity] = useState("")
  const [finalVelocity, setFinalVelocity] = useState("")
  const [time, setTime] = useState("")
  const [acceleration, setAcceleration] = useState("")
  const [velocityUnit, setVelocityUnit] = useState("ms")
  const [timeUnit, setTimeUnit] = useState("s")
  const [result, setResult] = useState<AccelerationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const convertToBaseUnits = (value: number, unit: string, type: "velocity" | "time"): number => {
    if (type === "velocity") {
      const unitData = velocityUnits.find((u) => u.value === unit)
      return value * (unitData?.factor || 1)
    } else {
      const unitData = timeUnits.find((u) => u.value === unit)
      return value * (unitData?.factor || 1)
    }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (mode === "acceleration") {
      const u = Number.parseFloat(initialVelocity)
      const v = Number.parseFloat(finalVelocity)
      const t = Number.parseFloat(time)

      if (isNaN(u) || isNaN(v) || isNaN(t)) {
        setError("Please enter valid numbers for all fields")
        return
      }

      const uMs = convertToBaseUnits(u, velocityUnit, "velocity")
      const vMs = convertToBaseUnits(v, velocityUnit, "velocity")
      const tS = convertToBaseUnits(t, timeUnit, "time")

      if (tS === 0) {
        setError("Time cannot be zero")
        return
      }

      const a = (vMs - uMs) / tS
      const deltaV = vMs - uMs

      setResult({
        acceleration: a,
        initialVelocity: uMs,
        finalVelocity: vMs,
        time: tS,
        velocityChange: deltaV,
      })
    } else if (mode === "final-velocity") {
      const u = Number.parseFloat(initialVelocity)
      const a = Number.parseFloat(acceleration)
      const t = Number.parseFloat(time)

      if (isNaN(u) || isNaN(a) || isNaN(t)) {
        setError("Please enter valid numbers for all fields")
        return
      }

      const uMs = convertToBaseUnits(u, velocityUnit, "velocity")
      const tS = convertToBaseUnits(t, timeUnit, "time")

      const v = uMs + a * tS
      const deltaV = v - uMs

      setResult({
        acceleration: a,
        initialVelocity: uMs,
        finalVelocity: v,
        time: tS,
        velocityChange: deltaV,
      })
    } else if (mode === "time") {
      const u = Number.parseFloat(initialVelocity)
      const v = Number.parseFloat(finalVelocity)
      const a = Number.parseFloat(acceleration)

      if (isNaN(u) || isNaN(v) || isNaN(a)) {
        setError("Please enter valid numbers for all fields")
        return
      }

      if (a === 0) {
        setError("Acceleration cannot be zero when solving for time")
        return
      }

      const uMs = convertToBaseUnits(u, velocityUnit, "velocity")
      const vMs = convertToBaseUnits(v, velocityUnit, "velocity")

      const t = (vMs - uMs) / a
      const deltaV = vMs - uMs

      if (t < 0) {
        setError("Negative time result - check if acceleration direction matches velocity change")
        return
      }

      setResult({
        acceleration: a,
        initialVelocity: uMs,
        finalVelocity: vMs,
        time: t,
        velocityChange: deltaV,
      })
    }
  }

  const handleReset = () => {
    setInitialVelocity("")
    setFinalVelocity("")
    setTime("")
    setAcceleration("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = ""
      if (mode === "acceleration") {
        text = `Acceleration: ${result.acceleration.toFixed(4)} m/s²`
      } else if (mode === "final-velocity") {
        text = `Final Velocity: ${result.finalVelocity.toFixed(4)} m/s`
      } else {
        text = `Time: ${result.time.toFixed(4)} seconds`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Acceleration Calculation",
          text: `Calculated using CalcHub Acceleration Calculator`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const applyPreset = (preset: (typeof presets)[0]) => {
    setMode("acceleration")
    setVelocityUnit("ms")
    setTimeUnit("s")
    setInitialVelocity(preset.initialV.toString())
    setFinalVelocity(preset.finalV.toString())
    setTime(preset.time.toString())
    setResult(null)
    setError("")
  }

  const formatNumber = (num: number, decimals = 4): string => {
    if (Math.abs(num) < 0.0001 && num !== 0) {
      return num.toExponential(2)
    }
    return num.toFixed(decimals).replace(/\.?0+$/, "") || "0"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Acceleration Calculator</CardTitle>
                    <CardDescription>Calculate acceleration, velocity, or time</CardDescription>
                  </div>
                </div>

                {/* Mode Selector */}
                <div className="space-y-2 pt-2">
                  <Label>Calculate</Label>
                  <Select
                    value={mode}
                    onValueChange={(v) => {
                      setMode(v as CalculationMode)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="acceleration">Acceleration from Velocity & Time</SelectItem>
                      <SelectItem value="final-velocity">Final Velocity from Acceleration & Time</SelectItem>
                      <SelectItem value="time">Time from Velocity & Acceleration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Unit Selectors */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Velocity Unit</Label>
                    <Select value={velocityUnit} onValueChange={setVelocityUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {velocityUnits.map((unit) => (
                          <SelectItem key={unit.value} value={unit.value}>
                            {unit.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Time Unit</Label>
                    <Select value={timeUnit} onValueChange={setTimeUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {timeUnits.map((unit) => (
                          <SelectItem key={unit.value} value={unit.value}>
                            {unit.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Initial Velocity - always shown */}
                <div className="space-y-2">
                  <Label htmlFor="initialVelocity">
                    Initial Velocity (u) [{velocityUnits.find((u) => u.value === velocityUnit)?.label}]
                  </Label>
                  <Input
                    id="initialVelocity"
                    type="number"
                    placeholder="Enter initial velocity"
                    value={initialVelocity}
                    onChange={(e) => setInitialVelocity(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Final Velocity - shown for acceleration and time modes */}
                {(mode === "acceleration" || mode === "time") && (
                  <div className="space-y-2">
                    <Label htmlFor="finalVelocity">
                      Final Velocity (v) [{velocityUnits.find((u) => u.value === velocityUnit)?.label}]
                    </Label>
                    <Input
                      id="finalVelocity"
                      type="number"
                      placeholder="Enter final velocity"
                      value={finalVelocity}
                      onChange={(e) => setFinalVelocity(e.target.value)}
                      step="any"
                    />
                  </div>
                )}

                {/* Time - shown for acceleration and final-velocity modes */}
                {(mode === "acceleration" || mode === "final-velocity") && (
                  <div className="space-y-2">
                    <Label htmlFor="time">Time (t) [{timeUnits.find((u) => u.value === timeUnit)?.label}]</Label>
                    <Input
                      id="time"
                      type="number"
                      placeholder="Enter time"
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Acceleration - shown for final-velocity and time modes */}
                {(mode === "final-velocity" || mode === "time") && (
                  <div className="space-y-2">
                    <Label htmlFor="acceleration">Acceleration (a) [m/s²]</Label>
                    <Input
                      id="acceleration"
                      type="number"
                      placeholder="Enter acceleration"
                      value={acceleration}
                      onChange={(e) => setAcceleration(e.target.value)}
                      step="any"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "acceleration" && "Acceleration"}
                        {mode === "final-velocity" && "Final Velocity"}
                        {mode === "time" && "Time"}
                      </p>
                      <p className="text-4xl font-bold text-orange-600 mb-2">
                        {mode === "acceleration" && `${formatNumber(result.acceleration)} m/s²`}
                        {mode === "final-velocity" && `${formatNumber(result.finalVelocity)} m/s`}
                        {mode === "time" && `${formatNumber(result.time)} s`}
                      </p>
                    </div>

                    {/* Additional Results */}
                    <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                      <div className="p-2 bg-white/60 rounded-lg text-center">
                        <p className="text-muted-foreground">Initial Velocity</p>
                        <p className="font-semibold">{formatNumber(result.initialVelocity)} m/s</p>
                      </div>
                      <div className="p-2 bg-white/60 rounded-lg text-center">
                        <p className="text-muted-foreground">Final Velocity</p>
                        <p className="font-semibold">{formatNumber(result.finalVelocity)} m/s</p>
                      </div>
                      <div className="p-2 bg-white/60 rounded-lg text-center">
                        <p className="text-muted-foreground">Velocity Change (Δv)</p>
                        <p
                          className={`font-semibold ${result.velocityChange >= 0 ? "text-green-600" : "text-red-600"}`}
                        >
                          {result.velocityChange >= 0 ? "+" : ""}
                          {formatNumber(result.velocityChange)} m/s
                        </p>
                      </div>
                      <div className="p-2 bg-white/60 rounded-lg text-center">
                        <p className="text-muted-foreground">Time</p>
                        <p className="font-semibold">{formatNumber(result.time)} s</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <p className="font-medium text-orange-800 mb-1">Acceleration</p>
                    <p className="font-mono text-sm text-orange-700">a = (v − u) ÷ t</p>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-medium text-blue-800 mb-1">Final Velocity</p>
                    <p className="font-mono text-sm text-blue-700">v = u + (a × t)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-medium text-green-800 mb-1">Time</p>
                    <p className="font-mono text-sm text-green-700">t = (v − u) ÷ a</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Presets</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {presets.map((preset, index) => (
                    <button
                      key={index}
                      onClick={() => applyPreset(preset)}
                      className="w-full p-3 text-left rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <p className="font-medium">{preset.name}</p>
                      <p className="text-xs text-muted-foreground">{preset.description}</p>
                    </button>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Note</p>
                      <p>Results assume uniform acceleration and straight-line motion.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Acceleration?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Acceleration is a fundamental concept in physics that describes how quickly an object's velocity
                  changes over time. It is a vector quantity, meaning it has both magnitude and direction. When an
                  object speeds up, slows down, or changes direction, it is experiencing acceleration. The SI unit for
                  acceleration is meters per second squared (m/s²), which tells us how much the velocity changes each
                  second.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In everyday language, we often use "acceleration" to mean speeding up, but in physics, acceleration
                  can be positive (speeding up in the direction of motion) or negative (slowing down, also called
                  deceleration). Understanding acceleration is crucial for analyzing motion in everything from vehicles
                  and sports to space exploration and particle physics.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Kinematic Equations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The equations used in this calculator are part of the kinematic equations of motion, which describe
                  the relationships between displacement, velocity, acceleration, and time for objects moving with
                  constant acceleration. The primary equation used here, v = u + at, is the first equation of motion and
                  directly relates initial velocity (u), final velocity (v), acceleration (a), and time (t).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  These equations assume uniform (constant) acceleration, which is a simplification that works well for
                  many real-world scenarios like cars accelerating on straight roads, objects in free fall (ignoring air
                  resistance), and basic projectile motion. For situations involving non-uniform acceleration,
                  calculus-based methods are required.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Timer className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Acceleration calculations are essential in numerous fields and everyday applications. In automotive
                  engineering, understanding acceleration helps design safer vehicles with appropriate braking systems
                  and determine 0-60 mph times that consumers care about. In aerospace, acceleration calculations are
                  critical for rocket launches, aircraft takeoffs, and orbital maneuvers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Sports science uses acceleration data to analyze athlete performance, from sprinters' explosive starts
                  to the deceleration of a car in racing. In physics education, acceleration problems form the
                  foundation for understanding Newton's laws of motion. Even roller coaster designers use acceleration
                  calculations to ensure thrilling yet safe rides, carefully managing the g-forces experienced by
                  riders.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding G-Forces</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Acceleration is often expressed in terms of "g" or g-force, where 1g equals the acceleration due to
                  Earth's gravity (approximately 9.81 m/s²). This measurement is particularly useful when discussing
                  forces experienced by humans or sensitive equipment. For example, a car accelerating from 0 to 60 mph
                  in 3 seconds experiences about 0.9g, while astronauts during launch can experience 3-4g.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The human body can tolerate different levels of g-force depending on direction and duration. Trained
                  pilots and astronauts use special suits and techniques to withstand higher g-forces. Understanding
                  these limits is crucial for designing safe vehicles, aircraft, and spacecraft that protect occupants
                  while achieving necessary performance levels.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
