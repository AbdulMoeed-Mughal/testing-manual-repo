"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Clock, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Period = "daily" | "weekly" | "monthly"

interface OvertimeResult {
  regularHours: number
  overtimeHours: number
  totalHours: number
  overtimePay?: number
  totalPay?: number
}

export function OvertimeHoursCalculator() {
  const [period, setPeriod] = useState<Period>("weekly")
  const [standardHours, setStandardHours] = useState("")
  const [actualHours, setActualHours] = useState("")
  const [hourlyRate, setHourlyRate] = useState("")
  const [overtimeMultiplier, setOvertimeMultiplier] = useState("1.5")
  const [calculatePay, setCalculatePay] = useState(false)
  const [result, setResult] = useState<OvertimeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateOvertime = () => {
    setError("")
    setResult(null)

    const standardNum = Number.parseFloat(standardHours)
    const actualNum = Number.parseFloat(actualHours)

    if (isNaN(standardNum) || standardNum < 0) {
      setError("Please enter valid standard hours (0 or greater)")
      return
    }

    if (isNaN(actualNum) || actualNum < 0) {
      setError("Please enter valid actual hours (0 or greater)")
      return
    }

    const overtimeHrs = Math.max(0, actualNum - standardNum)
    const regularHrs = actualNum - overtimeHrs

    let overtimePay: number | undefined
    let totalPay: number | undefined

    if (calculatePay) {
      const rate = Number.parseFloat(hourlyRate)
      const multiplier = Number.parseFloat(overtimeMultiplier)

      if (isNaN(rate) || rate < 0) {
        setError("Please enter a valid hourly rate")
        return
      }

      if (isNaN(multiplier) || multiplier < 1) {
        setError("Please enter a valid overtime multiplier (1 or greater)")
        return
      }

      overtimePay = overtimeHrs * rate * multiplier
      totalPay = regularHrs * rate + overtimePay
    }

    setResult({
      regularHours: Math.round(regularHrs * 100) / 100,
      overtimeHours: Math.round(overtimeHrs * 100) / 100,
      totalHours: Math.round(actualNum * 100) / 100,
      overtimePay: overtimePay !== undefined ? Math.round(overtimePay * 100) / 100 : undefined,
      totalPay: totalPay !== undefined ? Math.round(totalPay * 100) / 100 : undefined,
    })
  }

  const handleReset = () => {
    setStandardHours("")
    setActualHours("")
    setHourlyRate("")
    setOvertimeMultiplier("1.5")
    setCalculatePay(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = calculatePay
        ? `Overtime: ${result.overtimeHours} hours | Regular: ${result.regularHours} hours | Total Pay: $${result.totalPay}`
        : `Overtime: ${result.overtimeHours} hours | Regular: ${result.regularHours} hours`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Overtime Hours Result",
          text: `I calculated my overtime hours using CalcHub! Overtime: ${result.overtimeHours} hours`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Clock className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Overtime Hours Calculator</CardTitle>
                    <CardDescription>Calculate overtime hours and pay</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="period">Time Period</Label>
                  <Select value={period} onValueChange={(v) => setPeriod(v as Period)}>
                    <SelectTrigger id="period">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="standard">Standard Hours ({period})</Label>
                  <Input
                    id="standard"
                    type="number"
                    placeholder="Enter standard hours"
                    value={standardHours}
                    onChange={(e) => setStandardHours(e.target.value)}
                    min="0"
                    step="0.5"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="actual">Actual Hours Worked</Label>
                  <Input
                    id="actual"
                    type="number"
                    placeholder="Enter actual hours worked"
                    value={actualHours}
                    onChange={(e) => setActualHours(e.target.value)}
                    min="0"
                    step="0.5"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="calculatePay"
                    checked={calculatePay}
                    onChange={(e) => setCalculatePay(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300"
                  />
                  <Label htmlFor="calculatePay" className="cursor-pointer">
                    Calculate pay
                  </Label>
                </div>

                {calculatePay && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="rate">Hourly Rate ($)</Label>
                      <Input
                        id="rate"
                        type="number"
                        placeholder="Enter hourly rate"
                        value={hourlyRate}
                        onChange={(e) => setHourlyRate(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="multiplier">Overtime Multiplier</Label>
                      <Input
                        id="multiplier"
                        type="number"
                        placeholder="Enter overtime multiplier"
                        value={overtimeMultiplier}
                        onChange={(e) => setOvertimeMultiplier(e.target.value)}
                        min="1"
                        step="0.1"
                      />
                      <p className="text-xs text-muted-foreground">Common: 1.5× (time-and-a-half) or 2.0× (double time)</p>
                    </div>
                  </>
                )}

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateOvertime} className="w-full" size="lg">
                  Calculate Overtime
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center pb-2 border-b border-cyan-200">
                        <span className="text-sm text-cyan-700">Regular Hours</span>
                        <span className="text-lg font-bold text-cyan-900">{result.regularHours}h</span>
                      </div>
                      <div className="flex justify-between items-center pb-2 border-b border-cyan-200">
                        <span className="text-sm text-cyan-700">Overtime Hours</span>
                        <span className="text-lg font-bold text-cyan-900">{result.overtimeHours}h</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-cyan-700">Total Hours</span>
                        <span className="text-lg font-bold text-cyan-900">{result.totalHours}h</span>
                      </div>

                      {result.overtimePay !== undefined && result.totalPay !== undefined && (
                        <>
                          <div className="border-t border-cyan-300 pt-3 mt-3">
                            <div className="flex justify-between items-center pb-2">
                              <span className="text-sm text-cyan-700">Overtime Pay</span>
                              <span className="text-lg font-bold text-cyan-900">${result.overtimePay.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between items-center pt-2 border-t border-cyan-200">
                              <span className="text-sm font-semibold text-cyan-800">Total Pay</span>
                              <span className="text-2xl font-bold text-cyan-900">${result.totalPay.toFixed(2)}</span>
                            </div>
                          </div>
                        </>
                      )}
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Standards</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-900">Full-time (USA)</div>
                      <div className="text-sm text-cyan-700 mt-1">40 hours/week (8 hours/day)</div>
                    </div>
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-900">Part-time</div>
                      <div className="text-sm text-cyan-700 mt-1">20-30 hours/week typically</div>
                    </div>
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <div className="font-medium text-cyan-900">Overtime Rate</div>
                      <div className="text-sm text-cyan-700 mt-1">1.5× is standard in most countries</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Overtime = Actual − Standard</p>
                  </div>
                  <p>
                    If actual hours exceed standard hours, the difference is overtime. Overtime pay is calculated by
                    multiplying overtime hours by the hourly rate and the overtime multiplier (typically 1.5× or 2.0×).
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Overtime?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Overtime refers to the hours worked beyond the standard or contracted working hours. In most countries
                  and industries, overtime hours are compensated at a higher rate than regular hours to reflect the
                  additional effort and time commitment required from employees. The standard overtime multiplier is 1.5×
                  (time-and-a-half), though some situations may warrant double time (2.0×) or other rates.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding overtime is crucial for both employers and employees to ensure fair compensation, accurate
                  payroll processing, and compliance with labor regulations. Many jurisdictions have specific laws
                  governing overtime pay, maximum working hours, and rest periods to protect worker rights and well-being.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Overtime</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating overtime is straightforward once you know your standard hours and actual hours worked. Simply
                  subtract the standard hours from the actual hours worked. For example, if your standard workweek is 40
                  hours and you worked 48 hours, you have 8 hours of overtime (48 − 40 = 8).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To calculate overtime pay, multiply the overtime hours by your hourly rate and then by the overtime
                  multiplier. For instance, if you earn $20/hour with a 1.5× multiplier, your overtime rate is $30/hour.
                  Those 8 overtime hours would be worth $240 ($30 × 8), in addition to your regular pay for the first 40
                  hours.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Legal Requirements</h4>
                    <p className="text-amber-700 text-sm">
                      Overtime regulations vary by country, state, and industry. Some workers are classified as "exempt"
                      from overtime pay, while others are "non-exempt" and must receive overtime compensation. Always
                      check your local labor laws and employment contract.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Breaks and Unpaid Time</h4>
                    <p className="text-amber-700 text-sm">
                      When calculating actual hours worked, remember to subtract unpaid break time. Most jurisdictions do
                      not count meal breaks or rest periods as hours worked unless the employee is required to remain on
                      duty during those times.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Holiday and Weekend Rates</h4>
                    <p className="text-amber-700 text-sm">
                      Some employment agreements specify higher overtime multipliers for work performed on holidays,
                      weekends, or night shifts. These premium rates (such as double time or even triple time) are meant
                      to compensate for the inconvenience and disruption to personal time.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-amber-800 leading-relaxed">
                    <strong>Disclaimer:</strong> Overtime calculations are estimates based on entered values. Verify with
                    company policies and labor regulations for accurate payroll. This calculator is for informational
                    purposes only and does not constitute legal or financial advice.
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
