"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Timer, Info, Calculator, Clock } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface DurationResult {
  totalDays: number
  totalHours: number
  totalMinutes: number
  totalSeconds: number
  breakdown: {
    days: number
    hours: number
    minutes: number
    seconds: number
  }
}

export function TimeDurationCalculator() {
  const [startDate, setStartDate] = useState("")
  const [startTime, setStartTime] = useState("")
  const [endDate, setEndDate] = useState("")
  const [endTime, setEndTime] = useState("")
  const [excludeWeekends, setExcludeWeekends] = useState(false)
  const [result, setResult] = useState<DurationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDuration = () => {
    setError("")
    setResult(null)

    if (!startDate || !endDate) {
      setError("Please enter both start and end dates")
      return
    }

    const startDateTime = new Date(`${startDate}T${startTime || "00:00:00"}`)
    const endDateTime = new Date(`${endDate}T${endTime || "00:00:00"}`)

    if (isNaN(startDateTime.getTime()) || isNaN(endDateTime.getTime())) {
      setError("Please enter valid dates and times")
      return
    }

    if (endDateTime <= startDateTime) {
      setError("End date/time must be after start date/time")
      return
    }

    let totalMilliseconds = endDateTime.getTime() - startDateTime.getTime()

    // Adjust for weekends if excluded
    if (excludeWeekends) {
      let currentDate = new Date(startDateTime)
      let weekendDays = 0

      while (currentDate < endDateTime) {
        const dayOfWeek = currentDate.getDay()
        if (dayOfWeek === 0 || dayOfWeek === 6) {
          weekendDays++
        }
        currentDate.setDate(currentDate.getDate() + 1)
      }

      totalMilliseconds -= weekendDays * 24 * 60 * 60 * 1000
    }

    const totalSeconds = Math.floor(totalMilliseconds / 1000)
    const totalMinutes = Math.floor(totalSeconds / 60)
    const totalHours = Math.floor(totalMinutes / 60)
    const totalDays = Math.floor(totalHours / 24)

    const days = Math.floor(totalHours / 24)
    const hours = totalHours % 24
    const minutes = totalMinutes % 60
    const seconds = totalSeconds % 60

    setResult({
      totalDays,
      totalHours,
      totalMinutes,
      totalSeconds,
      breakdown: { days, hours, minutes, seconds },
    })
  }

  const handleReset = () => {
    setStartDate("")
    setStartTime("")
    setEndDate("")
    setEndTime("")
    setExcludeWeekends(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Duration: ${result.breakdown.days} days, ${result.breakdown.hours} hours, ${result.breakdown.minutes} minutes, ${result.breakdown.seconds} seconds`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Time Duration Result",
          text: `Duration: ${result.breakdown.days} days, ${result.breakdown.hours} hours, ${result.breakdown.minutes} minutes, ${result.breakdown.seconds} seconds`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Timer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Time Duration Calculator</CardTitle>
                    <CardDescription>Calculate time difference between two dates</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Start Date & Time */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Start Date & Time</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="startDate" className="text-sm">
                        Date
                      </Label>
                      <Input
                        id="startDate"
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="startTime" className="text-sm">
                        Time
                      </Label>
                      <Input
                        id="startTime"
                        type="time"
                        value={startTime}
                        onChange={(e) => setStartTime(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                {/* End Date & Time */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold">End Date & Time</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="endDate" className="text-sm">
                        Date
                      </Label>
                      <Input id="endDate" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="endTime" className="text-sm">
                        Time
                      </Label>
                      <Input id="endTime" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
                    </div>
                  </div>
                </div>

                {/* Exclude Weekends */}
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
                  <input
                    type="checkbox"
                    id="excludeWeekends"
                    checked={excludeWeekends}
                    onChange={(e) => setExcludeWeekends(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300"
                  />
                  <Label htmlFor="excludeWeekends" className="cursor-pointer text-sm">
                    Exclude weekends from calculation
                  </Label>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDuration} className="w-full" size="lg">
                  Calculate Duration
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Duration</p>
                      <p className="text-4xl font-bold text-cyan-600">
                        {result.breakdown.days}d {result.breakdown.hours}h {result.breakdown.minutes}m
                      </p>
                      <p className="text-sm text-cyan-600 mt-1">{result.breakdown.seconds} seconds</p>
                    </div>

                    {/* Breakdown */}
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Total Days</p>
                        <p className="text-lg font-semibold text-cyan-600">{result.totalDays.toLocaleString()}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Total Hours</p>
                        <p className="text-lg font-semibold text-cyan-600">{result.totalHours.toLocaleString()}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Total Minutes</p>
                        <p className="text-lg font-semibold text-cyan-600">{result.totalMinutes.toLocaleString()}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Total Seconds</p>
                        <p className="text-lg font-semibold text-cyan-600">{result.totalSeconds.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Duration Units</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Days</span>
                      <span className="text-sm text-cyan-600">24 hours</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Hours</span>
                      <span className="text-sm text-cyan-600">60 minutes</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Minutes</span>
                      <span className="text-sm text-cyan-600">60 seconds</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Seconds</span>
                      <span className="text-sm text-cyan-600">1000 milliseconds</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>The duration is calculated by subtracting the start date/time from the end date/time.</p>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-center">Duration = End - Start</p>
                  </div>
                  <p>Results are displayed in multiple formats including total days, hours, minutes, and a breakdown.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Time Duration */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Time Duration?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Time duration represents the amount of time that passes between two specific points in time. It is a
                  fundamental concept used in scheduling, project management, event planning, and countless other
                  applications where understanding the elapsed time is crucial. Duration can be measured in various units
                  including days, hours, minutes, and seconds, depending on the scale and precision needed for your
                  specific use case.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding time duration is essential for effective time management and planning. Whether you're
                  calculating project timelines, planning events, tracking work hours, or managing schedules, knowing the
                  exact duration between two dates and times helps you make informed decisions and allocate resources
                  efficiently. This calculator provides precise measurements that account for all time units and optional
                  exclusions like weekends.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Duration */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Time Duration</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating time duration involves finding the difference between two timestamps. The process starts by
                  converting both the start and end dates/times into a common format (typically milliseconds since a
                  reference point), then subtracting the start from the end. The resulting value represents the total
                  elapsed time in milliseconds, which can then be converted into more readable units like days, hours,
                  minutes, and seconds.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When excluding weekends, the calculator identifies all Saturday and Sunday dates within the time range
                  and subtracts them from the total duration. This is particularly useful for business calculations where
                  only working days matter. The breakdown display shows both the total time in each unit (e.g., total
                  hours) and a human-readable format (e.g., X days, Y hours, Z minutes) for easier interpretation.
                </p>
              </CardContent>
            </Card>

            {/* Common Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Common Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Time duration calculations have numerous practical applications across various fields. In project
                  management, they help determine project timelines and milestones. Event planners use duration
                  calculations to schedule activities and allocate time for different segments. HR departments track
                  employee work hours and calculate time-off balances. In education, teachers plan curriculum timing and
                  assignment deadlines.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Business & Project Management</h4>
                    <p className="text-cyan-700 text-sm">
                      Calculate project durations, track milestones, estimate delivery times, and manage team schedules.
                      Essential for accurate planning and resource allocation in business environments.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Event Planning</h4>
                    <p className="text-cyan-700 text-sm">
                      Determine countdown timers for upcoming events, calculate preparation time needed, and schedule
                      activities. Helps ensure events run smoothly and on time.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Personal Time Tracking</h4>
                    <p className="text-cyan-700 text-sm">
                      Track workout durations, study time, travel time, or any personal activity. Helps with time
                      management and understanding how you spend your time.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Service Level Agreements (SLAs)</h4>
                    <p className="text-cyan-700 text-sm">
                      Calculate response times and resolution times for support tickets. Essential for maintaining SLA
                      compliance and measuring service quality in customer support operations.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-cyan-200 bg-cyan-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-cyan-800 leading-relaxed">
                  <strong>Note:</strong> Time duration calculations are estimates based on entered dates and times.
                  Results may vary depending on time zones, daylight saving time changes, or calendar differences. For
                  critical applications, always verify calculations and consider consulting with relevant professionals.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
