"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  FileText,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type SimplificationLevel = "basic" | "standard" | "advanced"

interface SimplificationStep {
  step: number
  description: string
  result: string
}

interface SimplificationResult {
  simplified: string
  steps: SimplificationStep[]
  factored?: string
  expanded?: string
  latex: string
}

export function AlgebraSimplifier() {
  const [expression, setExpression] = useState("")
  const [level, setLevel] = useState<SimplificationLevel>("standard")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<SimplificationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  // Token types for parsing
  type TokenType = "number" | "variable" | "operator" | "paren" | "power"

  interface Token {
    type: TokenType
    value: string
  }

  // Tokenize the expression
  const tokenize = (expr: string): Token[] => {
    const tokens: Token[] = []
    let i = 0
    const cleanExpr = expr.replace(/\s+/g, "")

    while (i < cleanExpr.length) {
      const char = cleanExpr[i]

      // Numbers (including decimals)
      if (/\d/.test(char)) {
        let num = ""
        while (i < cleanExpr.length && /[\d.]/.test(cleanExpr[i])) {
          num += cleanExpr[i]
          i++
        }
        tokens.push({ type: "number", value: num })
        continue
      }

      // Variables
      if (/[a-zA-Z]/.test(char)) {
        tokens.push({ type: "variable", value: char })
        i++
        continue
      }

      // Operators
      if (["+", "-", "*", "/"].includes(char)) {
        tokens.push({ type: "operator", value: char })
        i++
        continue
      }

      // Parentheses
      if (["(", ")"].includes(char)) {
        tokens.push({ type: "paren", value: char })
        i++
        continue
      }

      // Power (^ or **)
      if (char === "^") {
        tokens.push({ type: "power", value: "^" })
        i++
        continue
      }

      if (char === "²") {
        tokens.push({ type: "power", value: "^" })
        tokens.push({ type: "number", value: "2" })
        i++
        continue
      }

      if (char === "³") {
        tokens.push({ type: "power", value: "^" })
        tokens.push({ type: "number", value: "3" })
        i++
        continue
      }

      i++
    }

    return tokens
  }

  // Parse and represent terms
  interface Term {
    coefficient: number
    variables: { [key: string]: number } // variable name -> power
  }

  // Parse expression into terms
  const parseToTerms = (expr: string): Term[] => {
    const terms: Term[] = []
    const tokens = tokenize(expr)

    let currentCoef = 1
    let currentVars: { [key: string]: number } = {}
    let sign = 1
    let expectingTerm = true
    let hasExplicitCoef = false

    for (let i = 0; i < tokens.length; i++) {
      const token = tokens[i]
      const nextToken = tokens[i + 1]

      if (token.type === "operator") {
        if (token.value === "+" || token.value === "-") {
          // Save current term if we have one
          if (!expectingTerm || hasExplicitCoef || Object.keys(currentVars).length > 0) {
            terms.push({
              coefficient: currentCoef * sign,
              variables: { ...currentVars },
            })
          }
          sign = token.value === "-" ? -1 : 1
          currentCoef = 1
          currentVars = {}
          expectingTerm = true
          hasExplicitCoef = false
        } else if (token.value === "*") {
          // Multiplication - continue building term
        } else if (token.value === "/") {
          // Division - simplified handling
          if (nextToken && nextToken.type === "number") {
            currentCoef /= Number.parseFloat(nextToken.value)
            i++
            hasExplicitCoef = true
          }
        }
      } else if (token.type === "number") {
        if (expectingTerm || !hasExplicitCoef) {
          currentCoef *= Number.parseFloat(token.value)
          hasExplicitCoef = true
          expectingTerm = false
        }
      } else if (token.type === "variable") {
        let power = 1
        if (nextToken && nextToken.type === "power") {
          const powerToken = tokens[i + 2]
          if (powerToken && powerToken.type === "number") {
            power = Number.parseFloat(powerToken.value)
            i += 2
          }
        }
        currentVars[token.value] = (currentVars[token.value] || 0) + power
        expectingTerm = false
      } else if (token.type === "paren") {
        // Handle parentheses with distributive property
        if (token.value === "(") {
          // Find matching closing paren
          let depth = 1
          let j = i + 1
          while (j < tokens.length && depth > 0) {
            if (tokens[j].value === "(") depth++
            if (tokens[j].value === ")") depth--
            j++
          }
          // For now, skip parentheses handling in basic mode
        }
      }
    }

    // Don't forget the last term
    if (hasExplicitCoef || Object.keys(currentVars).length > 0) {
      terms.push({
        coefficient: currentCoef * sign,
        variables: { ...currentVars },
      })
    } else if (expectingTerm && terms.length === 0) {
      // Handle case where expression is just a number
      terms.push({
        coefficient: currentCoef * sign,
        variables: {},
      })
    }

    return terms
  }

  // Get variable signature for combining like terms
  const getVarSignature = (vars: { [key: string]: number }): string => {
    return Object.entries(vars)
      .filter(([_, power]) => power !== 0)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([v, p]) => `${v}^${p}`)
      .join("")
  }

  // Combine like terms
  const combineTerms = (terms: Term[]): Term[] => {
    const combined: { [signature: string]: Term } = {}

    for (const term of terms) {
      const sig = getVarSignature(term.variables)
      if (combined[sig]) {
        combined[sig].coefficient += term.coefficient
      } else {
        combined[sig] = { ...term, variables: { ...term.variables } }
      }
    }

    return Object.values(combined).filter((t) => t.coefficient !== 0)
  }

  // Format term to string
  const formatTerm = (term: Term, isFirst: boolean): string => {
    let result = ""
    const coef = term.coefficient
    const vars = Object.entries(term.variables)
      .filter(([_, p]) => p !== 0)
      .sort(([a], [b]) => a.localeCompare(b))

    if (vars.length === 0) {
      // Constant term
      if (isFirst) {
        result = coef.toString()
      } else {
        result = coef >= 0 ? ` + ${coef}` : ` - ${Math.abs(coef)}`
      }
    } else {
      // Variable term
      const absCoef = Math.abs(coef)
      const coefStr = absCoef === 1 ? "" : absCoef.toString()

      const varStr = vars
        .map(([v, p]) => {
          if (p === 1) return v
          if (p === 2) return `${v}²`
          if (p === 3) return `${v}³`
          return `${v}^${p}`
        })
        .join("")

      if (isFirst) {
        result = coef < 0 ? `-${coefStr}${varStr}` : `${coefStr}${varStr}`
      } else {
        result = coef >= 0 ? ` + ${coefStr}${varStr}` : ` - ${absCoef === 1 ? "" : absCoef}${varStr}`
      }
    }

    return result
  }

  // Format terms to expression string
  const formatTerms = (terms: Term[]): string => {
    if (terms.length === 0) return "0"

    // Sort terms: by total degree (descending), then alphabetically
    const sorted = [...terms].sort((a, b) => {
      const degA = Object.values(a.variables).reduce((sum, p) => sum + p, 0)
      const degB = Object.values(b.variables).reduce((sum, p) => sum + p, 0)
      if (degB !== degA) return degB - degA
      return getVarSignature(a.variables).localeCompare(getVarSignature(b.variables))
    })

    return sorted
      .map((t, i) => formatTerm(t, i === 0))
      .join("")
      .trim()
  }

  // Convert to LaTeX
  const toLatex = (expr: string): string => {
    return expr
      .replace(/\^(\d+)/g, "^{$1}")
      .replace(/²/g, "^{2}")
      .replace(/³/g, "^{3}")
      .replace(/\*/g, " \\cdot ")
      .replace(/\//g, " \\div ")
  }

  // Simplify the expression
  const simplify = () => {
    setError("")
    setResult(null)

    if (!expression.trim()) {
      setError("Please enter an algebraic expression")
      return
    }

    // Validate expression
    const validChars = /^[\d\w\s+\-*/()^²³.]+$/
    if (!validChars.test(expression)) {
      setError("Expression contains invalid characters")
      return
    }

    // Check for balanced parentheses
    let parenCount = 0
    for (const char of expression) {
      if (char === "(") parenCount++
      if (char === ")") parenCount--
      if (parenCount < 0) {
        setError("Unbalanced parentheses")
        return
      }
    }
    if (parenCount !== 0) {
      setError("Unbalanced parentheses")
      return
    }

    try {
      const steps: SimplificationStep[] = []
      let stepNum = 1

      // Step 1: Parse original expression
      steps.push({
        step: stepNum++,
        description: "Original expression",
        result: expression.trim(),
      })

      // Step 2: Parse into terms
      const terms = parseToTerms(expression)

      if (terms.length > 1) {
        steps.push({
          step: stepNum++,
          description: "Identify individual terms",
          result: terms
            .map((t, i) => formatTerm(t, i === 0))
            .join("")
            .trim(),
        })
      }

      // Step 3: Combine like terms
      const combined = combineTerms(terms)

      if (terms.length !== combined.length) {
        steps.push({
          step: stepNum++,
          description: "Combine like terms",
          result: formatTerms(combined),
        })
      }

      // Final result
      const simplified = formatTerms(combined)

      steps.push({
        step: stepNum++,
        description: "Simplified result",
        result: simplified,
      })

      // Generate factored form for simple cases (level: advanced)
      let factored: string | undefined
      let expanded: string | undefined

      if (level === "advanced" && combined.length >= 2) {
        // Try to find GCF
        const coeffs = combined.map((t) => Math.abs(t.coefficient))
        const gcd = coeffs.reduce((a, b) => {
          while (b) {
            const t = b
            b = a % b
            a = t
          }
          return a
        })

        if (gcd > 1) {
          const factoredTerms = combined.map((t) => ({
            coefficient: t.coefficient / gcd,
            variables: t.variables,
          }))
          factored = `${gcd}(${formatTerms(factoredTerms)})`
        }
      }

      setResult({
        simplified,
        steps,
        factored,
        expanded,
        latex: toLatex(simplified),
      })
    } catch (err) {
      setError("Unable to simplify this expression. Please check the syntax.")
    }
  }

  const handleReset = () => {
    setExpression("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(result.simplified)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      await navigator.clipboard.writeText(result.latex)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Algebra Simplifier</CardTitle>
                    <CardDescription>Simplify algebraic expressions step by step</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Expression Input */}
                <div className="space-y-2">
                  <Label htmlFor="expression">Algebraic Expression</Label>
                  <Input
                    id="expression"
                    type="text"
                    placeholder="e.g., 2x + 3x - 4 or 3(x - 2) + 5"
                    value={expression}
                    onChange={(e) => setExpression(e.target.value)}
                    className="font-mono text-lg"
                  />
                  <p className="text-xs text-muted-foreground">
                    Use ^ for powers (e.g., x^2), * for multiplication, / for division
                  </p>
                </div>

                {/* Simplification Level */}
                <div className="space-y-2">
                  <Label htmlFor="level">Simplification Level</Label>
                  <Select value={level} onValueChange={(v) => setLevel(v as SimplificationLevel)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic - Combine like terms</SelectItem>
                      <SelectItem value="standard">Standard - Full simplification</SelectItem>
                      <SelectItem value="advanced">Advanced - Include factoring</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show step-by-step solution</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={simplify} className="w-full" size="lg">
                  Simplify Expression
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Simplified Expression</p>
                      <p className="text-3xl font-bold text-blue-600 font-mono mb-2">{result.simplified}</p>
                    </div>

                    {/* Factored/Expanded Forms */}
                    {(result.factored || result.expanded) && (
                      <div className="mt-3 pt-3 border-t border-blue-200 space-y-2">
                        {result.factored && (
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-muted-foreground">Factored:</span>
                            <span className="font-mono font-medium">{result.factored}</span>
                          </div>
                        )}
                        {result.expanded && (
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-muted-foreground">Expanded:</span>
                            <span className="font-mono font-medium">{result.expanded}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 1 && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="flex items-center gap-2 text-sm font-medium text-blue-700 hover:text-blue-800 w-full justify-center"
                        >
                          {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          {showDetails ? "Hide Steps" : "Show Steps"}
                        </button>

                        {showDetails && (
                          <div className="mt-3 space-y-2">
                            {result.steps.map((step) => (
                              <div key={step.step} className="p-3 bg-white rounded-lg border border-blue-100">
                                <div className="flex items-start gap-3">
                                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-blue-600 text-xs font-bold flex-shrink-0">
                                    {step.step}
                                  </span>
                                  <div>
                                    <p className="text-sm text-muted-foreground">{step.description}</p>
                                    <p className="font-mono font-medium mt-1">{step.result}</p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <FileText className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Simplification Rules</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700 block mb-1">Combine Like Terms</span>
                      <span className="text-sm text-blue-600">2x + 3x = 5x</span>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700 block mb-1">Distributive Property</span>
                      <span className="text-sm text-green-600">{"a(b + c) = ab + ac"}</span>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700 block mb-1">Power Rules</span>
                      <span className="text-sm text-purple-600">{"x^a · x^b = x^(a+b)"}</span>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700 block mb-1">Factor Common Terms</span>
                      <span className="text-sm text-orange-600">{"6x + 9 = 3(2x + 3)"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">Supported operators:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>
                        <code className="bg-muted px-1 rounded">+</code> Addition
                      </li>
                      <li>
                        <code className="bg-muted px-1 rounded">-</code> Subtraction
                      </li>
                      <li>
                        <code className="bg-muted px-1 rounded">*</code> Multiplication
                      </li>
                      <li>
                        <code className="bg-muted px-1 rounded">/</code> Division
                      </li>
                      <li>
                        <code className="bg-muted px-1 rounded">^</code> or{" "}
                        <code className="bg-muted px-1 rounded">²³</code> Powers
                      </li>
                    </ul>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground mb-2">Examples:</p>
                    <ul className="space-y-1 font-mono text-xs">
                      <li>2x + 3x - 4</li>
                      <li>3(x - 2) + 5</li>
                      <li>x^2 + 2x + x^2</li>
                      <li>4ab - 2ab + 3a</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Algebraic Simplification?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Algebraic simplification is the process of reducing complex algebraic expressions to their simplest
                  form while maintaining their mathematical equivalence. This involves combining like terms, applying
                  the distributive property, simplifying fractions, and organizing terms in standard form.
                  Simplification makes expressions easier to understand, compare, and use in further calculations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Like terms are terms that have the same variables raised to the same powers. For example, 2x and 3x
                  are like terms because they both contain the variable x to the first power. Similarly, 4x² and -2x²
                  are like terms. However, 2x and 2x² are not like terms because the powers of x are different.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter your algebraic expression using standard mathematical notation. Use letters for variables (x, y,
                  z, a, b, etc.), numbers for coefficients and constants, and operators for mathematical operations. The
                  calculator will automatically identify like terms, apply algebraic rules, and present the simplified
                  result.
                </p>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Basic Level</h4>
                    <p className="text-blue-700 text-sm">
                      Combines like terms only. Best for simple expressions like 2x + 3x or 4a - a.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Standard Level</h4>
                    <p className="text-green-700 text-sm">
                      Full simplification including distribution and combining. Handles most expressions.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg md:col-span-2">
                    <h4 className="font-semibold text-purple-800 mb-2">Advanced Level</h4>
                    <p className="text-purple-700 text-sm">
                      Includes factoring and provides both factored and expanded forms when applicable.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  This algebra simplifier provides symbolic simplifications based on standard algebraic rules. Results
                  may vary depending on expression structure and selected options. For complex expressions involving
                  advanced operations like logarithms, trigonometric functions, or limits, please consult a specialized
                  computer algebra system or mathematical software.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
