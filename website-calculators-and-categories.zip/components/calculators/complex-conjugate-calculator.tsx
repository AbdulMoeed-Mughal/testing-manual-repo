"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calculator, Info, AlertTriangle, Plus, Trash2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface ComplexNumber {
  real: number
  imaginary: number
}

interface ConjugateResult {
  original: ComplexNumber
  conjugate: ComplexNumber
  magnitude: number
  argument: number // in radians
  argumentDegrees: number
}

export function ComplexConjugateCalculator() {
  const [inputs, setInputs] = useState<{ real: string; imaginary: string }[]>([{ real: "", imaginary: "" }])
  const [results, setResults] = useState<ConjugateResult[]>([])
  const [showSteps, setShowSteps] = useState(true)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const addInput = () => {
    if (inputs.length < 10) {
      setInputs([...inputs, { real: "", imaginary: "" }])
    }
  }

  const removeInput = (index: number) => {
    if (inputs.length > 1) {
      const newInputs = inputs.filter((_, i) => i !== index)
      setInputs(newInputs)
    }
  }

  const updateInput = (index: number, field: "real" | "imaginary", value: string) => {
    const newInputs = [...inputs]
    newInputs[index][field] = value
    setInputs(newInputs)
  }

  const formatComplex = (z: ComplexNumber, includeParens = false): string => {
    const { real: a, imaginary: b } = z
    if (a === 0 && b === 0) return "0"
    if (a === 0) return b === 1 ? "i" : b === -1 ? "-i" : `${b}i`
    if (b === 0) return `${a}`
    const sign = b >= 0 ? "+" : "-"
    const absB = Math.abs(b)
    const imagPart = absB === 1 ? "i" : `${absB}i`
    const result = `${a} ${sign} ${imagPart}`
    return includeParens ? `(${result})` : result
  }

  const calculate = () => {
    setError("")
    setResults([])

    const newResults: ConjugateResult[] = []

    for (let i = 0; i < inputs.length; i++) {
      const { real, imaginary } = inputs[i]
      const a = Number.parseFloat(real)
      const b = Number.parseFloat(imaginary)

      if (isNaN(a)) {
        setError(`Input ${i + 1}: Please enter a valid real part`)
        return
      }
      if (isNaN(b)) {
        setError(`Input ${i + 1}: Please enter a valid imaginary part`)
        return
      }

      const original: ComplexNumber = { real: a, imaginary: b }
      const conjugate: ComplexNumber = { real: a, imaginary: -b }
      const magnitude = Math.sqrt(a * a + b * b)
      const argument = Math.atan2(b, a)
      const argumentDegrees = (argument * 180) / Math.PI

      newResults.push({
        original,
        conjugate,
        magnitude,
        argument,
        argumentDegrees,
      })
    }

    setResults(newResults)
  }

  const handleReset = () => {
    setInputs([{ real: "", imaginary: "" }])
    setResults([])
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (results.length > 0) {
      const text = results
        .map((r, i) => `z${i + 1} = ${formatComplex(r.original)} → z̄${i + 1} = ${formatComplex(r.conjugate)}`)
        .join("\n")
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (results.length > 0 && navigator.share) {
      const text = results
        .map((r, i) => `z${i + 1} = ${formatComplex(r.original)} → z̄${i + 1} = ${formatComplex(r.conjugate)}`)
        .join("\n")
      try {
        await navigator.share({
          title: "Complex Conjugate Results",
          text: `Complex Conjugate Calculator Results:\n${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Complex Conjugate Calculator</CardTitle>
                    <CardDescription>Calculate conjugates of complex numbers</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Inputs */}
                {inputs.map((input, index) => (
                  <div key={index} className="space-y-2 p-3 rounded-lg bg-muted/50 border">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">z{inputs.length > 1 ? index + 1 : ""} = a + bi</Label>
                      {inputs.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeInput(index)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-red-500"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label htmlFor={`real-${index}`} className="text-xs text-muted-foreground">
                          Real part (a)
                        </Label>
                        <Input
                          id={`real-${index}`}
                          type="number"
                          placeholder="e.g., 3"
                          value={input.real}
                          onChange={(e) => updateInput(index, "real", e.target.value)}
                          step="any"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`imaginary-${index}`} className="text-xs text-muted-foreground">
                          Imaginary part (b)
                        </Label>
                        <Input
                          id={`imaginary-${index}`}
                          type="number"
                          placeholder="e.g., 4"
                          value={input.imaginary}
                          onChange={(e) => updateInput(index, "imaginary", e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                  </div>
                ))}

                {/* Add Button */}
                {inputs.length < 10 && (
                  <Button variant="outline" size="sm" onClick={addInput} className="w-full bg-transparent">
                    <Plus className="h-4 w-4 mr-1" />
                    Add Another Complex Number
                  </Button>
                )}

                {/* Options */}
                <div className="flex items-center justify-between py-2">
                  <Label htmlFor="show-steps" className="text-sm">
                    Show step-by-step
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Conjugate
                </Button>

                {/* Results */}
                {results.length > 0 && (
                  <div className="space-y-4">
                    {results.map((result, index) => (
                      <div
                        key={index}
                        className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300"
                      >
                        <div className="text-center mb-3">
                          <p className="text-sm text-muted-foreground mb-1">
                            Original: z{results.length > 1 ? index + 1 : ""} = {formatComplex(result.original)}
                          </p>
                          <p className="text-2xl font-bold text-blue-600 mb-1">
                            z̄{results.length > 1 ? index + 1 : ""} = {formatComplex(result.conjugate)}
                          </p>
                        </div>

                        {/* Additional Properties */}
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="p-2 bg-white rounded-lg text-center">
                            <p className="text-xs text-muted-foreground">Magnitude |z|</p>
                            <p className="font-semibold">{result.magnitude.toFixed(4)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-lg text-center">
                            <p className="text-xs text-muted-foreground">Argument θ</p>
                            <p className="font-semibold">{result.argumentDegrees.toFixed(2)}°</p>
                          </div>
                        </div>

                        {/* Step-by-step */}
                        {showSteps && (
                          <div className="mt-3 p-3 bg-white rounded-lg border">
                            <p className="text-xs font-medium text-muted-foreground mb-2">Step-by-Step:</p>
                            <div className="space-y-1 text-xs text-muted-foreground">
                              <p>
                                1. Given: z = {result.original.real} + {result.original.imaginary}i
                              </p>
                              <p>2. To find the conjugate, negate the imaginary part</p>
                              <p>
                                3. z̄ = {result.conjugate.real} + ({result.conjugate.imaginary})i ={" "}
                                {formatComplex(result.conjugate)}
                              </p>
                              <p className="pt-1 border-t mt-2">
                                4. |z| = √({result.original.real}² + {result.original.imaginary}²) = √
                                {result.original.real * result.original.real +
                                  result.original.imaginary * result.original.imaginary}{" "}
                                ≈ {result.magnitude.toFixed(4)}
                              </p>
                              <p>
                                5. θ = arctan({result.original.imaginary}/{result.original.real}) ≈{" "}
                                {result.argument.toFixed(4)} rad ≈ {result.argumentDegrees.toFixed(2)}°
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conjugate Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">If z = a + bi, then z̄ = a − bi</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    The complex conjugate is obtained by changing the sign of the imaginary part while keeping the real
                    part unchanged.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>z = 3 + 4i</span>
                      <span className="font-medium">z̄ = 3 − 4i</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>z = −2 + 5i</span>
                      <span className="font-medium">z̄ = −2 − 5i</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>z = 7 − 2i</span>
                      <span className="font-medium">z̄ = 7 + 2i</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>z = 4i</span>
                      <span className="font-medium">z̄ = −4i</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>z = 5 (real)</span>
                      <span className="font-medium">z̄ = 5</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Properties</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">z · z̄ = |z|²</span> — Product equals magnitude squared
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">(z̄)̄ = z</span> — Double conjugate returns original
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">z + z̄ = 2·Re(z)</span> — Sum is twice real part
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">z − z̄ = 2i·Im(z)</span> — Difference is 2i times imaginary
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono">|z̄| = |z|</span> — Equal magnitudes
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Complex Conjugate?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The complex conjugate of a complex number z = a + bi is the number z̄ = a − bi, obtained by negating
                  the imaginary part while keeping the real part unchanged. Geometrically, the conjugate reflects the
                  complex number across the real axis in the complex plane (Argand diagram). This operation is
                  fundamental in complex analysis and has many applications in mathematics, physics, and engineering.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Complex conjugates are used extensively in signal processing, quantum mechanics, and electrical
                  engineering. One of the most important properties is that multiplying a complex number by its
                  conjugate always produces a non-negative real number equal to the square of the magnitude: z · z̄ =
                  |z|². This property is crucial for dividing complex numbers and simplifying complex expressions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Complex Conjugates</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Complex conjugates play a vital role in many areas of science and engineering. In electrical
                  engineering, they are used to calculate power in AC circuits, where the complex conjugate of current
                  is multiplied by voltage to find apparent power. In signal processing, the Fourier transform uses
                  conjugates to analyze frequency components of signals.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In quantum mechanics, the probability density of a wave function is found by multiplying the wave
                  function by its complex conjugate. This ensures the result is always a real, non-negative value
                  representing probability. Conjugates are also essential for finding roots of polynomials, as complex
                  roots of real polynomials always occur in conjugate pairs.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Complex conjugate calculations follow standard mathematical formulas. Results depend on correct input
                  values. This calculator is intended for educational and reference purposes. Always verify critical
                  calculations independently.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
