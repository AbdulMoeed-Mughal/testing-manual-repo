"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Users,
  Info,
  DollarSign,
  Receipt,
  ChevronDown,
  ChevronUp,
  Percent,
  Plus,
  Trash2,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type TipType = "percentage" | "fixed"
type SplitType = "equal" | "custom"

interface PersonSplit {
  id: string
  name: string
  amount: string
}

interface SplitResult {
  billAmount: number
  tipAmount: number
  taxAmount: number
  totalBill: number
  perPersonAmount: number
  customSplits: { name: string; amount: number }[]
}

export function SplitBillCalculator() {
  const [billAmount, setBillAmount] = useState("")
  const [numberOfPeople, setNumberOfPeople] = useState("2")
  const [tipType, setTipType] = useState<TipType>("percentage")
  const [tipPercentage, setTipPercentage] = useState("")
  const [tipFixed, setTipFixed] = useState("")
  const [taxPercentage, setTaxPercentage] = useState("")
  const [splitType, setSplitType] = useState<SplitType>("equal")
  const [customSplits, setCustomSplits] = useState<PersonSplit[]>([
    { id: "1", name: "Person 1", amount: "" },
    { id: "2", name: "Person 2", amount: "" },
  ])
  const [roundUp, setRoundUp] = useState(false)
  const [result, setResult] = useState<SplitResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const tipPresets = [5, 10, 15, 18, 20, 25]

  const calculateSplit = () => {
    setError("")
    setResult(null)

    const bill = Number.parseFloat(billAmount)
    if (isNaN(bill) || bill <= 0) {
      setError("Please enter a valid bill amount greater than 0")
      return
    }

    const people = Number.parseInt(numberOfPeople)
    if (splitType === "equal" && (isNaN(people) || people < 1)) {
      setError("Please enter at least 1 person")
      return
    }

    // Calculate tip
    let tipAmount = 0
    if (tipType === "percentage" && tipPercentage) {
      const tipPct = Number.parseFloat(tipPercentage)
      if (tipPct < 0) {
        setError("Tip percentage cannot be negative")
        return
      }
      tipAmount = bill * (tipPct / 100)
    } else if (tipType === "fixed" && tipFixed) {
      tipAmount = Number.parseFloat(tipFixed)
      if (tipAmount < 0) {
        setError("Tip amount cannot be negative")
        return
      }
    }

    // Calculate tax
    let taxAmount = 0
    if (taxPercentage) {
      const taxPct = Number.parseFloat(taxPercentage)
      if (taxPct < 0) {
        setError("Tax percentage cannot be negative")
        return
      }
      taxAmount = bill * (taxPct / 100)
    }

    const totalBill = bill + tipAmount + taxAmount

    if (splitType === "equal") {
      let perPerson = totalBill / people
      if (roundUp) {
        perPerson = Math.ceil(perPerson)
      }

      setResult({
        billAmount: bill,
        tipAmount,
        taxAmount,
        totalBill,
        perPersonAmount: perPerson,
        customSplits: [],
      })
    } else {
      // Custom split
      const splits = customSplits.map((person) => ({
        name: person.name || `Person ${person.id}`,
        amount: Number.parseFloat(person.amount) || 0,
      }))

      const totalCustom = splits.reduce((sum, p) => sum + p.amount, 0)
      if (totalCustom <= 0) {
        setError("Please enter amounts for custom split")
        return
      }

      // Calculate proportional amounts
      const proportionalSplits = splits.map((person) => {
        let amount = (person.amount / totalCustom) * totalBill
        if (roundUp) {
          amount = Math.ceil(amount)
        }
        return { name: person.name, amount }
      })

      setResult({
        billAmount: bill,
        tipAmount,
        taxAmount,
        totalBill,
        perPersonAmount: 0,
        customSplits: proportionalSplits,
      })
    }
  }

  const handleReset = () => {
    setBillAmount("")
    setNumberOfPeople("2")
    setTipType("percentage")
    setTipPercentage("")
    setTipFixed("")
    setTaxPercentage("")
    setSplitType("equal")
    setCustomSplits([
      { id: "1", name: "Person 1", amount: "" },
      { id: "2", name: "Person 2", amount: "" },
    ])
    setRoundUp(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = `Bill Split:\nBill: $${result.billAmount.toFixed(2)}\nTip: $${result.tipAmount.toFixed(2)}\nTax: $${result.taxAmount.toFixed(2)}\nTotal: $${result.totalBill.toFixed(2)}\n`
      if (splitType === "equal") {
        text += `Per Person: $${result.perPersonAmount.toFixed(2)}`
      } else {
        text += result.customSplits.map((p) => `${p.name}: $${p.amount.toFixed(2)}`).join("\n")
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        let text = `Bill Split from CalcHub!\nTotal: $${result.totalBill.toFixed(2)}\n`
        if (splitType === "equal") {
          text += `Per Person: $${result.perPersonAmount.toFixed(2)}`
        } else {
          text += result.customSplits.map((p) => `${p.name}: $${p.amount.toFixed(2)}`).join("\n")
        }
        await navigator.share({
          title: "Bill Split Result",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const addPerson = () => {
    const newId = String(customSplits.length + 1)
    setCustomSplits([...customSplits, { id: newId, name: `Person ${newId}`, amount: "" }])
  }

  const removePerson = (id: string) => {
    if (customSplits.length > 2) {
      setCustomSplits(customSplits.filter((p) => p.id !== id))
    }
  }

  const updatePersonName = (id: string, name: string) => {
    setCustomSplits(customSplits.map((p) => (p.id === id ? { ...p, name } : p)))
  }

  const updatePersonAmount = (id: string, amount: string) => {
    setCustomSplits(customSplits.map((p) => (p.id === id ? { ...p, amount } : p)))
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/lifestyle-daily">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Lifestyle & Daily Use
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Users className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Split Bill Calculator</CardTitle>
                    <CardDescription>Split bills fairly among friends</CardDescription>
                  </div>
                </div>

                {/* Split Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Split Type</span>
                  <button
                    onClick={() => setSplitType(splitType === "equal" ? "custom" : "equal")}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        splitType === "custom" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        splitType === "equal" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Equal
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        splitType === "custom" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Custom
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Bill Amount */}
                <div className="space-y-2">
                  <Label htmlFor="billAmount">Bill Amount</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="billAmount"
                      type="number"
                      placeholder="0.00"
                      value={billAmount}
                      onChange={(e) => setBillAmount(e.target.value)}
                      className="pl-9"
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Number of People (Equal Split) */}
                {splitType === "equal" && (
                  <div className="space-y-2">
                    <Label htmlFor="numberOfPeople">Number of People</Label>
                    <Input
                      id="numberOfPeople"
                      type="number"
                      placeholder="2"
                      value={numberOfPeople}
                      onChange={(e) => setNumberOfPeople(e.target.value)}
                      min="1"
                    />
                  </div>
                )}

                {/* Custom Split */}
                {splitType === "custom" && (
                  <div className="space-y-3">
                    <Label>Custom Split (by amount or ratio)</Label>
                    {customSplits.map((person, index) => (
                      <div key={person.id} className="flex items-center gap-2">
                        <Input
                          placeholder={`Person ${index + 1}`}
                          value={person.name}
                          onChange={(e) => updatePersonName(person.id, e.target.value)}
                          className="flex-1"
                        />
                        <div className="relative w-28">
                          <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            type="number"
                            placeholder="0"
                            value={person.amount}
                            onChange={(e) => updatePersonAmount(person.id, e.target.value)}
                            className="pl-9"
                            min="0"
                            step="0.01"
                          />
                        </div>
                        {customSplits.length > 2 && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removePerson(person.id)}
                            className="h-9 w-9 text-red-500 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                    <Button variant="outline" size="sm" onClick={addPerson} className="w-full bg-transparent">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Person
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Enter relative amounts - the total will be split proportionally
                    </p>
                  </div>
                )}

                {/* Tip Section */}
                <div className="space-y-3 pt-2 border-t">
                  <div className="flex items-center justify-between">
                    <Label>Tip</Label>
                    <button
                      onClick={() => setTipType(tipType === "percentage" ? "fixed" : "percentage")}
                      className="text-xs text-primary hover:underline"
                    >
                      {tipType === "percentage" ? "Use fixed amount" : "Use percentage"}
                    </button>
                  </div>

                  {tipType === "percentage" ? (
                    <>
                      <div className="flex flex-wrap gap-2">
                        {tipPresets.map((preset) => (
                          <Button
                            key={preset}
                            variant={tipPercentage === String(preset) ? "default" : "outline"}
                            size="sm"
                            onClick={() => setTipPercentage(String(preset))}
                            className="flex-1 min-w-[60px]"
                          >
                            {preset}%
                          </Button>
                        ))}
                      </div>
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="Custom %"
                          value={tipPercentage}
                          onChange={(e) => setTipPercentage(e.target.value)}
                          min="0"
                          step="0.1"
                        />
                        <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      </div>
                    </>
                  ) : (
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={tipFixed}
                        onChange={(e) => setTipFixed(e.target.value)}
                        className="pl-9"
                        min="0"
                        step="0.01"
                      />
                    </div>
                  )}
                </div>

                {/* Tax Section */}
                <div className="space-y-2">
                  <Label htmlFor="tax">Tax Percentage (optional)</Label>
                  <div className="relative">
                    <Input
                      id="tax"
                      type="number"
                      placeholder="0"
                      value={taxPercentage}
                      onChange={(e) => setTaxPercentage(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                    <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                </div>

                {/* Round Up Toggle */}
                <div className="flex items-center justify-between py-2">
                  <Label htmlFor="roundUp" className="cursor-pointer">
                    Round up per-person amount
                  </Label>
                  <Switch id="roundUp" checked={roundUp} onCheckedChange={setRoundUp} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSplit} className="w-full" size="lg">
                  Calculate Split
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      {splitType === "equal" ? (
                        <>
                          <p className="text-sm text-muted-foreground mb-1">Per Person</p>
                          <p className="text-5xl font-bold text-amber-600 mb-2">${result.perPersonAmount.toFixed(2)}</p>
                          <p className="text-sm text-muted-foreground">
                            Total: ${result.totalBill.toFixed(2)} ÷ {numberOfPeople} people
                          </p>
                        </>
                      ) : (
                        <>
                          <p className="text-sm text-muted-foreground mb-3">Custom Split</p>
                          <div className="space-y-2">
                            {result.customSplits.map((person, index) => (
                              <div
                                key={index}
                                className="flex items-center justify-between p-2 bg-white rounded-lg border border-amber-200"
                              >
                                <span className="font-medium">{person.name}</span>
                                <span className="text-lg font-bold text-amber-600">${person.amount.toFixed(2)}</span>
                              </div>
                            ))}
                          </div>
                          <p className="text-sm text-muted-foreground mt-3">Total: ${result.totalBill.toFixed(2)}</p>
                        </>
                      )}
                    </div>

                    {/* Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          {showBreakdown ? (
                            <ChevronUp className="h-4 w-4 mr-2" />
                          ) : (
                            <ChevronDown className="h-4 w-4 mr-2" />
                          )}
                          {showBreakdown ? "Hide" : "Show"} Breakdown
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2 text-sm">
                        <div className="flex justify-between p-2 bg-white rounded border">
                          <span>Bill Amount</span>
                          <span className="font-medium">${result.billAmount.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between p-2 bg-white rounded border">
                          <span>Tip</span>
                          <span className="font-medium">${result.tipAmount.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between p-2 bg-white rounded border">
                          <span>Tax</span>
                          <span className="font-medium">${result.taxAmount.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between p-2 bg-amber-100 rounded border border-amber-300 font-semibold">
                          <span>Total</span>
                          <span>${result.totalBill.toFixed(2)}</span>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Split Bill Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Tip = Bill × (Tip % ÷ 100)</p>
                    <p className="font-semibold text-foreground">Tax = Bill × (Tax % ÷ 100)</p>
                    <p className="font-semibold text-foreground">Total = Bill + Tip + Tax</p>
                    <p className="font-semibold text-foreground">Per Person = Total ÷ People</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tipping Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Poor Service</span>
                      <span className="text-sm text-muted-foreground">10%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Average Service</span>
                      <span className="text-sm text-muted-foreground">15%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Good Service</span>
                      <span className="text-sm text-green-600">18-20%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Excellent Service</span>
                      <span className="text-sm text-muted-foreground">25%+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Tax Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-muted rounded text-center">
                      <div className="font-medium">US Average</div>
                      <div className="text-muted-foreground">7-10%</div>
                    </div>
                    <div className="p-2 bg-muted rounded text-center">
                      <div className="font-medium">Canada GST</div>
                      <div className="text-muted-foreground">5%</div>
                    </div>
                    <div className="p-2 bg-muted rounded text-center">
                      <div className="font-medium">UK VAT</div>
                      <div className="text-muted-foreground">20%</div>
                    </div>
                    <div className="p-2 bg-muted rounded text-center">
                      <div className="font-medium">Australia GST</div>
                      <div className="text-muted-foreground">10%</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Bill Splitting</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bill splitting is a common practice when dining out or sharing expenses with friends, family, or
                  colleagues. While the concept seems simple, it can become complicated when factoring in tips, taxes,
                  and individual orders of varying prices. A good split bill calculator takes all these factors into
                  account to ensure everyone pays their fair share.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The most common method is equal splitting, where the total bill (including tip and tax) is divided
                  equally among all participants. However, this may not always be fair if some people ordered
                  significantly more or less than others. In such cases, a custom or proportional split based on
                  individual orders is more appropriate.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Receipt className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Fair Bill Splitting</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Before the Meal</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Agree on splitting method upfront</li>
                      <li>• Decide who will handle the calculation</li>
                      <li>• Consider dietary restrictions or preferences</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">During Ordering</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Keep mental note of your items</li>
                      <li>• Ask about shared dishes</li>
                      <li>• Note any drinks or extras separately</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">At Payment Time</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Review the bill for errors</li>
                      <li>• Calculate tip on pre-tax amount</li>
                      <li>• Round up for easier math</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Special Situations</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Cover for friends who forgot wallets</li>
                      <li>• Handle birthday dinners gracefully</li>
                      <li>• Use payment apps for easy transfers</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Note:</strong> Split calculations are estimates and rounding may cause slight differences.
                  Always verify the final amounts with your group before making payments.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
