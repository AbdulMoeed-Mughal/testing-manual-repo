"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Ruler, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "m" | "ft"
type ElementType = "beam" | "slab" | "column" | "footing"
type BendType = "none" | "hook" | "90deg" | "135deg"

interface BBSResult {
  totalLength: number
  weight: number
  lengthPerBar: number
}

export function BarBendingScheduleCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("m")
  const [elementType, setElementType] = useState<ElementType>("beam")
  const [barDiameter, setBarDiameter] = useState("")
  const [numberOfBars, setNumberOfBars] = useState("")
  const [straightLength, setStraightLength] = useState("")
  const [bendType, setBendType] = useState<BendType>("none")
  const [bendAllowance, setBendAllowance] = useState("")
  const [wastage, setWastage] = useState("5")
  const [steelDensity] = useState("7850")
  const [result, setResult] = useState<BBSResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const getBendAllowanceDefault = (type: BendType, diameter: number): number => {
    switch (type) {
      case "hook":
        return diameter * 10
      case "90deg":
        return diameter * 2
      case "135deg":
        return diameter * 3
      default:
        return 0
    }
  }

  const calculateBBS = () => {
    setError("")
    setResult(null)

    const diameterNum = Number.parseFloat(barDiameter)
    const barsNum = Number.parseInt(numberOfBars, 10)
    const lengthNum = Number.parseFloat(straightLength)
    const wastageNum = Number.parseFloat(wastage)
    const densityNum = Number.parseFloat(steelDensity)

    if (isNaN(diameterNum) || diameterNum <= 0) {
      setError("Please enter a valid bar diameter greater than 0")
      return
    }

    if (isNaN(barsNum) || barsNum < 1) {
      setError("Number of bars must be at least 1")
      return
    }

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid bar length greater than 0")
      return
    }

    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }

    // Convert length to meters if needed
    const lengthInMeters = unitSystem === "ft" ? lengthNum * 0.3048 : lengthNum

    // Get bend allowance
    let bendAllowanceValue = 0
    if (bendType !== "none") {
      if (bendAllowance && !isNaN(Number.parseFloat(bendAllowance))) {
        bendAllowanceValue = Number.parseFloat(bendAllowance)
        if (unitSystem === "ft") {
          bendAllowanceValue *= 0.3048
        }
      } else {
        bendAllowanceValue = getBendAllowanceDefault(bendType, diameterNum) / 1000 // Convert mm to m
      }
    }

    // Calculate length per bar
    const lengthPerBar = lengthInMeters + bendAllowanceValue

    // Calculate total length
    const totalLengthBase = lengthPerBar * barsNum

    // Apply wastage
    const totalLength = totalLengthBase * (1 + wastageNum / 100)

    // Calculate weight: Weight = Volume × Density
    // Volume = π × (diameter²/4) × length
    // Convert diameter from mm to m
    const diameterInMeters = diameterNum / 1000
    const volume = Math.PI * Math.pow(diameterInMeters / 2, 2) * totalLength
    const weight = volume * densityNum

    setResult({
      totalLength,
      weight,
      lengthPerBar,
    })
  }

  const handleReset = () => {
    setBarDiameter("")
    setNumberOfBars("")
    setStraightLength("")
    setBendType("none")
    setBendAllowance("")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Bar Bending Schedule:\nTotal Length: ${result.totalLength.toFixed(2)} m\nTotal Weight: ${result.weight.toFixed(2)} kg\nLength per Bar: ${result.lengthPerBar.toFixed(2)} m`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Bar Bending Schedule Result",
          text: `Bar Bending Schedule calculated using CalcHub!\nTotal Length: ${result.totalLength.toFixed(2)} m\nTotal Weight: ${result.weight.toFixed(2)} kg`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "m" ? "ft" : "m"))
    setStraightLength("")
    setBendAllowance("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Ruler className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Bar Bending Schedule Calculator</CardTitle>
                    <CardDescription>Calculate steel reinforcement quantities</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "ft" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "m" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Meters
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "ft" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Feet
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Element Type */}
                <div className="space-y-2">
                  <Label htmlFor="elementType">Structural Element</Label>
                  <Select value={elementType} onValueChange={(value: ElementType) => setElementType(value)}>
                    <SelectTrigger id="elementType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beam">Beam</SelectItem>
                      <SelectItem value="slab">Slab</SelectItem>
                      <SelectItem value="column">Column</SelectItem>
                      <SelectItem value="footing">Footing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Bar Diameter */}
                <div className="space-y-2">
                  <Label htmlFor="barDiameter">Bar Diameter (mm)</Label>
                  <Input
                    id="barDiameter"
                    type="number"
                    placeholder="e.g., 12, 16, 20"
                    value={barDiameter}
                    onChange={(e) => setBarDiameter(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Number of Bars */}
                <div className="space-y-2">
                  <Label htmlFor="numberOfBars">Number of Bars</Label>
                  <Input
                    id="numberOfBars"
                    type="number"
                    placeholder="Enter number of bars"
                    value={numberOfBars}
                    onChange={(e) => setNumberOfBars(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Straight Length */}
                <div className="space-y-2">
                  <Label htmlFor="straightLength">Bar Length ({unitSystem})</Label>
                  <Input
                    id="straightLength"
                    type="number"
                    placeholder={`Enter length in ${unitSystem === "m" ? "meters" : "feet"}`}
                    value={straightLength}
                    onChange={(e) => setStraightLength(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Bend Type */}
                <div className="space-y-2">
                  <Label htmlFor="bendType">Bend Type</Label>
                  <Select value={bendType} onValueChange={(value: BendType) => setBendType(value)}>
                    <SelectTrigger id="bendType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Bend</SelectItem>
                      <SelectItem value="hook">Hook (10d)</SelectItem>
                      <SelectItem value="90deg">90° Bend (2d)</SelectItem>
                      <SelectItem value="135deg">135° Bend (3d)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Bend Allowance (Optional) */}
                {bendType !== "none" && (
                  <div className="space-y-2">
                    <Label htmlFor="bendAllowance">
                      Custom Bend Allowance ({unitSystem}) <span className="text-muted-foreground">(Optional)</span>
                    </Label>
                    <Input
                      id="bendAllowance"
                      type="number"
                      placeholder="Leave empty for default"
                      value={bendAllowance}
                      onChange={(e) => setBendAllowance(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                {/* Wastage Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="wastage">Wastage (%)</Label>
                  <Input
                    id="wastage"
                    type="number"
                    placeholder="Enter wastage percentage"
                    value={wastage}
                    onChange={(e) => setWastage(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBBS} className="w-full" size="lg">
                  Calculate BBS
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Steel Weight</p>
                        <p className="text-4xl font-bold text-amber-600">{result.weight.toFixed(2)}</p>
                        <p className="text-sm font-medium text-amber-700">kg</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Total Length:</span>
                          <span className="font-semibold text-amber-700">{result.totalLength.toFixed(2)} m</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Length per Bar:</span>
                          <span className="font-semibold text-amber-700">{result.lengthPerBar.toFixed(2)} m</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Bar Diameters</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <span className="font-medium">6mm, 8mm</span>
                      <span className="text-muted-foreground">Light reinforcement</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <span className="font-medium">10mm, 12mm</span>
                      <span className="text-muted-foreground">Slabs, small beams</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <span className="font-medium">16mm, 20mm</span>
                      <span className="text-muted-foreground">Main beams, columns</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <span className="font-medium">25mm, 32mm</span>
                      <span className="text-muted-foreground">Heavy structures</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bend Allowance Guide</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong className="text-foreground">Hook:</strong> 10 × diameter (e.g., 120mm for 12mm bar)
                  </p>
                  <p>
                    <strong className="text-foreground">90° Bend:</strong> 2 × diameter (e.g., 24mm for 12mm bar)
                  </p>
                  <p>
                    <strong className="text-foreground">135° Bend:</strong> 3 × diameter (e.g., 36mm for 12mm bar)
                  </p>
                  <p className="pt-2 border-t">
                    These are standard allowances. Custom values can be entered based on structural drawings.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is BBS */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Bar Bending Schedule (BBS)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A Bar Bending Schedule (BBS) is a comprehensive document that lists all the reinforcement bars required
                  for a construction project. It includes detailed information about each bar's diameter, length, shape,
                  location, and total quantity. The BBS is essential for accurate estimation of steel quantities, ordering
                  materials, and ensuring proper placement of reinforcement during construction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The schedule helps in organizing the cutting and bending of reinforcement bars at the fabrication yard
                  before they reach the construction site. This preparation reduces wastage, improves efficiency, and
                  ensures that the bars conform to the structural drawings. BBS is a critical document for quantity
                  surveyors, contractors, and site engineers in managing construction costs and maintaining quality
                  standards.
                </p>
              </CardContent>
            </Card>

            {/* How BBS is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How is Bar Bending Schedule Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation of BBS involves determining the cutting length of each bar, which includes the straight
                  length plus additional lengths for bends, hooks, and anchorage. The total length is then multiplied by
                  the number of bars to get the total steel requirement. The weight is calculated using the formula: Weight
                  = (D²/162) × L, where D is the diameter in mm and L is the length in meters. This formula is derived from
                  the volume of steel (π × D²/4 × L) multiplied by steel density (7850 kg/m³).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For bends and hooks, standard deductions are applied based on the bar diameter and bend angle. A typical
                  hook requires about 10 times the bar diameter in additional length, while 90° and 135° bends require 2-3
                  times the diameter. Wastage allowance of 2-5% is added to account for cutting losses, overlaps, and site
                  conditions. Accurate BBS calculation ensures optimal material usage and cost control in construction
                  projects.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Bar Bending Schedule</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  BBS is used extensively in all types of RCC construction including residential buildings, commercial
                  complexes, bridges, dams, and infrastructure projects. It helps in preparing accurate cost estimates
                  during the tendering stage and serves as a reference for ordering steel from suppliers. The schedule is
                  also used for quality control, ensuring that the correct size and number of bars are placed at the right
                  locations as per structural design.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Construction managers use BBS to track steel consumption on site, compare actual usage against estimated
                  quantities, and identify any discrepancies or wastage. The document also facilitates communication
                  between designers, contractors, and fabricators, reducing errors and rework. Modern construction projects
                  often use software tools to generate BBS automatically from structural drawings, improving accuracy and
                  efficiency in steel detailing and estimation.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p className="font-semibold text-amber-900">Important Note</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      BBS calculations provided by this calculator are indicative and based on standard practices. The
                      final bar bending schedule must be prepared in accordance with structural drawings, design
                      specifications, and relevant building codes (such as IS 2502, ACI 315, or BS 8666). Always consult
                      with a qualified structural engineer for critical construction projects.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
