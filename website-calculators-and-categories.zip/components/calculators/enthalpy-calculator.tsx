"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, Flame, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type EnergyUnit = "J" | "kJ" | "cal"
type PressureUnit = "Pa" | "kPa" | "atm" | "psi"
type VolumeUnit = "m3" | "L" | "ft3"
type EnthalpyUnit = "J" | "kJ" | "cal"

interface EnthalpyResult {
  enthalpy: number
  enthalpyUnit: string
  category: string
  color: string
  bgColor: string
}

export function EnthalpyCalculator() {
  const [internalEnergy, setInternalEnergy] = useState("")
  const [energyUnit, setEnergyUnit] = useState<EnergyUnit>("J")
  const [pressure, setPressure] = useState("")
  const [pressureUnit, setPressureUnit] = useState<PressureUnit>("Pa")
  const [volume, setVolume] = useState("")
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("m3")
  const [outputUnit, setOutputUnit] = useState<EnthalpyUnit>("J")
  const [result, setResult] = useState<EnthalpyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Conversion factors to base SI units
  const energyToJoules: Record<EnergyUnit, number> = {
    J: 1,
    kJ: 1000,
    cal: 4.184,
  }

  const pressureToPascals: Record<PressureUnit, number> = {
    Pa: 1,
    kPa: 1000,
    atm: 101325,
    psi: 6894.76,
  }

  const volumeToCubicMeters: Record<VolumeUnit, number> = {
    m3: 1,
    L: 0.001,
    ft3: 0.0283168,
  }

  const joulesFromOutput: Record<EnthalpyUnit, number> = {
    J: 1,
    kJ: 1000,
    cal: 4.184,
  }

  const calculateEnthalpy = () => {
    setError("")
    setResult(null)

    const U = Number.parseFloat(internalEnergy)
    const P = Number.parseFloat(pressure)
    const V = Number.parseFloat(volume)

    if (isNaN(U)) {
      setError("Please enter a valid internal energy value")
      return
    }

    if (isNaN(P) || P < 0) {
      setError("Please enter a valid pressure (must be non-negative)")
      return
    }

    if (isNaN(V) || V < 0) {
      setError("Please enter a valid volume (must be non-negative)")
      return
    }

    // Convert to SI units
    const U_joules = U * energyToJoules[energyUnit]
    const P_pascals = P * pressureToPascals[pressureUnit]
    const V_m3 = V * volumeToCubicMeters[volumeUnit]

    // Calculate enthalpy: H = U + P × V
    const H_joules = U_joules + P_pascals * V_m3

    // Convert to output unit
    const H_output = H_joules / joulesFromOutput[outputUnit]

    // Categorize the enthalpy magnitude
    let category: string
    let color: string
    let bgColor: string

    const absH = Math.abs(H_joules)
    if (absH < 1000) {
      category = "Low Energy"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (absH < 100000) {
      category = "Moderate Energy"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (absH < 1000000) {
      category = "High Energy"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Energy"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      enthalpy: H_output,
      enthalpyUnit: outputUnit,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setInternalEnergy("")
    setPressure("")
    setVolume("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unitLabel = result.enthalpyUnit === "m3" ? "m³" : result.enthalpyUnit
      await navigator.clipboard.writeText(`Enthalpy: ${result.enthalpy.toExponential(4)} ${unitLabel}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1e6 || (Math.abs(num) < 0.001 && num !== 0)) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 4 })
  }

  const getUnitLabel = (unit: string): string => {
    if (unit === "m3") return "m³"
    if (unit === "ft3") return "ft³"
    return unit
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Enthalpy Calculator</CardTitle>
                    <CardDescription>Calculate system enthalpy (H = U + PV)</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Internal Energy Input */}
                <div className="space-y-2">
                  <Label htmlFor="internalEnergy">Internal Energy (U)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="internalEnergy"
                      type="number"
                      placeholder="Enter internal energy"
                      value={internalEnergy}
                      onChange={(e) => setInternalEnergy(e.target.value)}
                      className="flex-1"
                    />
                    <select
                      value={energyUnit}
                      onChange={(e) => setEnergyUnit(e.target.value as EnergyUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="J">J</option>
                      <option value="kJ">kJ</option>
                      <option value="cal">cal</option>
                    </select>
                  </div>
                </div>

                {/* Pressure Input */}
                <div className="space-y-2">
                  <Label htmlFor="pressure">Pressure (P)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="pressure"
                      type="number"
                      placeholder="Enter pressure"
                      value={pressure}
                      onChange={(e) => setPressure(e.target.value)}
                      min="0"
                      className="flex-1"
                    />
                    <select
                      value={pressureUnit}
                      onChange={(e) => setPressureUnit(e.target.value as PressureUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="Pa">Pa</option>
                      <option value="kPa">kPa</option>
                      <option value="atm">atm</option>
                      <option value="psi">psi</option>
                    </select>
                  </div>
                </div>

                {/* Volume Input */}
                <div className="space-y-2">
                  <Label htmlFor="volume">Volume (V)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="volume"
                      type="number"
                      placeholder="Enter volume"
                      value={volume}
                      onChange={(e) => setVolume(e.target.value)}
                      min="0"
                      className="flex-1"
                    />
                    <select
                      value={volumeUnit}
                      onChange={(e) => setVolumeUnit(e.target.value as VolumeUnit)}
                      className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="m3">m³</option>
                      <option value="L">L</option>
                      <option value="ft3">ft³</option>
                    </select>
                  </div>
                </div>

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <select
                    value={outputUnit}
                    onChange={(e) => setOutputUnit(e.target.value as EnthalpyUnit)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="J">Joules (J)</option>
                    <option value="kJ">Kilojoules (kJ)</option>
                    <option value="cal">Calories (cal)</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateEnthalpy} className="w-full" size="lg">
                  Calculate Enthalpy
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Enthalpy (H)</p>
                      <p className={`text-3xl font-bold ${result.color} mb-1`}>
                        {formatNumber(result.enthalpy)} {getUnitLabel(result.enthalpyUnit)}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Step-by-step breakdown toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-center gap-1 w-full mt-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p className="font-medium">Step-by-step calculation:</p>
                        <p>1. Convert internal energy to Joules:</p>
                        <p className="pl-4 font-mono text-xs">
                          U = {internalEnergy} {getUnitLabel(energyUnit)} × {energyToJoules[energyUnit]} ={" "}
                          {formatNumber(Number.parseFloat(internalEnergy) * energyToJoules[energyUnit])} J
                        </p>
                        <p>2. Convert pressure to Pascals:</p>
                        <p className="pl-4 font-mono text-xs">
                          P = {pressure} {getUnitLabel(pressureUnit)} × {pressureToPascals[pressureUnit]} ={" "}
                          {formatNumber(Number.parseFloat(pressure) * pressureToPascals[pressureUnit])} Pa
                        </p>
                        <p>3. Convert volume to cubic meters:</p>
                        <p className="pl-4 font-mono text-xs">
                          V = {volume} {getUnitLabel(volumeUnit)} × {volumeToCubicMeters[volumeUnit]} ={" "}
                          {formatNumber(Number.parseFloat(volume) * volumeToCubicMeters[volumeUnit])} m³
                        </p>
                        <p>4. Apply enthalpy formula:</p>
                        <p className="pl-4 font-mono text-xs">H = U + P × V</p>
                        <p className="pl-4 font-mono text-xs">
                          H = {formatNumber(Number.parseFloat(internalEnergy) * energyToJoules[energyUnit])} +{" "}
                          {formatNumber(Number.parseFloat(pressure) * pressureToPascals[pressureUnit])} ×{" "}
                          {formatNumber(Number.parseFloat(volume) * volumeToCubicMeters[volumeUnit])}
                        </p>
                        <p className="pl-4 font-mono text-xs font-semibold">
                          H = {formatNumber(result.enthalpy * joulesFromOutput[outputUnit])} J ={" "}
                          {formatNumber(result.enthalpy)} {getUnitLabel(result.enthalpyUnit)}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Enthalpy Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="font-semibold text-foreground text-lg">H = U + P × V</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>H</strong> = Enthalpy (total heat content)
                    </p>
                    <p>
                      <strong>U</strong> = Internal energy
                    </p>
                    <p>
                      <strong>P</strong> = Pressure
                    </p>
                    <p>
                      <strong>V</strong> = Volume
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Standard atmosphere</span>
                      <span className="font-mono">101,325 Pa</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 liter</span>
                      <span className="font-mono">0.001 m³</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 kJ</span>
                      <span className="font-mono">1,000 J</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 calorie</span>
                      <span className="font-mono">4.184 J</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Enthalpy?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enthalpy (H) is a thermodynamic property that represents the total heat content of a system. It
                  combines the internal energy (U) of a system with the product of its pressure (P) and volume (V).
                  Enthalpy is particularly useful in analyzing processes that occur at constant pressure, such as many
                  chemical reactions and industrial processes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The enthalpy change (ΔH) during a process indicates whether heat is absorbed (endothermic, ΔH
                  positive) or released (exothermic, ΔH negative). This makes enthalpy essential for understanding
                  energy transfers in power plants, refrigeration systems, chemical manufacturing, and many other
                  applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Enthalpy</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Chemical Reactions</h4>
                    <p className="text-orange-700 text-sm">
                      Enthalpy changes determine whether reactions release or absorb heat, crucial for industrial
                      chemistry and process design.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">HVAC Systems</h4>
                    <p className="text-blue-700 text-sm">
                      Heating, ventilation, and air conditioning systems use enthalpy to calculate energy requirements
                      for temperature control.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Power Generation</h4>
                    <p className="text-green-700 text-sm">
                      Steam turbines and gas turbines rely on enthalpy calculations to maximize efficiency and power
                      output.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Refrigeration</h4>
                    <p className="text-purple-700 text-sm">
                      Refrigeration cycles use enthalpy diagrams to analyze heat absorption and rejection in cooling
                      systems.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Enthalpy calculations are estimates based on ideal thermodynamic behavior. Actual values may vary
                      due to system losses, phase changes, and material properties. Consult thermodynamics references
                      for precise analysis.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
