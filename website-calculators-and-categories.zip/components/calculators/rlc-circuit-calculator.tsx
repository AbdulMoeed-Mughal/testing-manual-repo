"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CircuitType = "series" | "parallel"

interface RLCResult {
  impedance: number
  impedanceUnit: string
  resonanceFreq: number
  current: number
  currentUnit: string
  vR: number
  vL: number
  vC: number
  phaseAngle: number
  xL: number
  xC: number
  omega: number
  atResonance: boolean
}

export function RLCCircuitCalculator() {
  const [circuitType, setCircuitType] = useState<CircuitType>("series")
  const [resistance, setResistance] = useState("")
  const [resistanceUnit, setResistanceUnit] = useState("Ω")
  const [inductance, setInductance] = useState("")
  const [inductanceUnit, setInductanceUnit] = useState("mH")
  const [capacitance, setCapacitance] = useState("")
  const [capacitanceUnit, setCapacitanceUnit] = useState("µF")
  const [voltage, setVoltage] = useState("")
  const [frequency, setFrequency] = useState("")
  const [frequencyUnit, setFrequencyUnit] = useState("Hz")
  const [result, setResult] = useState<RLCResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const convertResistance = (value: number, unit: string): number => {
    switch (unit) {
      case "mΩ":
        return value / 1000
      case "Ω":
        return value
      case "kΩ":
        return value * 1000
      case "MΩ":
        return value * 1000000
      default:
        return value
    }
  }

  const convertInductance = (value: number, unit: string): number => {
    switch (unit) {
      case "H":
        return value
      case "mH":
        return value / 1000
      case "µH":
        return value / 1000000
      case "nH":
        return value / 1000000000
      default:
        return value
    }
  }

  const convertCapacitance = (value: number, unit: string): number => {
    switch (unit) {
      case "F":
        return value
      case "mF":
        return value / 1000
      case "µF":
        return value / 1000000
      case "nF":
        return value / 1000000000
      case "pF":
        return value / 1000000000000
      default:
        return value
    }
  }

  const convertFrequency = (value: number, unit: string): number => {
    switch (unit) {
      case "Hz":
        return value
      case "kHz":
        return value * 1000
      case "MHz":
        return value * 1000000
      default:
        return value
    }
  }

  const formatNumber = (num: number, decimals = 4): string => {
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 1000000) {
      return num.toExponential(decimals)
    }
    return num.toFixed(decimals)
  }

  const calculateRLC = () => {
    setError("")
    setResult(null)

    const R = convertResistance(Number.parseFloat(resistance), resistanceUnit)
    const L = convertInductance(Number.parseFloat(inductance), inductanceUnit)
    const C = convertCapacitance(Number.parseFloat(capacitance), capacitanceUnit)
    const V = Number.parseFloat(voltage)
    const f = convertFrequency(Number.parseFloat(frequency), frequencyUnit)

    if (isNaN(R) || R <= 0) {
      setError("Please enter a valid resistance greater than 0")
      return
    }
    if (isNaN(L) || L <= 0) {
      setError("Please enter a valid inductance greater than 0")
      return
    }
    if (isNaN(C) || C <= 0) {
      setError("Please enter a valid capacitance greater than 0")
      return
    }
    if (isNaN(V) || V <= 0) {
      setError("Please enter a valid voltage greater than 0")
      return
    }
    if (isNaN(f) || f <= 0) {
      setError("Please enter a valid frequency greater than 0")
      return
    }

    // Angular frequency
    const omega = 2 * Math.PI * f

    // Reactances
    const xL = omega * L
    const xC = 1 / (omega * C)

    // Resonance frequency
    const f0 = 1 / (2 * Math.PI * Math.sqrt(L * C))

    // Check if at resonance (within 1%)
    const atResonance = Math.abs(f - f0) / f0 < 0.01

    let Z: number
    let phaseAngle: number

    if (circuitType === "series") {
      // Series RLC: Z = √(R² + (XL - XC)²)
      Z = Math.sqrt(R * R + Math.pow(xL - xC, 2))
      phaseAngle = Math.atan((xL - xC) / R) * (180 / Math.PI)
    } else {
      // Parallel RLC: Z = 1 / √((1/R)² + (1/XL - 1/XC)²)
      const invR = 1 / R
      const invXL = 1 / xL
      const invXC = 1 / xC
      Z = 1 / Math.sqrt(invR * invR + Math.pow(invXL - invXC, 2))
      phaseAngle = -Math.atan((invXL - invXC) / invR) * (180 / Math.PI)
    }

    // Current
    const I = V / Z

    // Voltage drops (series circuit)
    const vR = I * R
    const vL = I * xL
    const vC = I * xC

    // Format impedance unit
    let impedanceUnit = "Ω"
    let impedanceValue = Z
    if (Z >= 1000000) {
      impedanceValue = Z / 1000000
      impedanceUnit = "MΩ"
    } else if (Z >= 1000) {
      impedanceValue = Z / 1000
      impedanceUnit = "kΩ"
    } else if (Z < 1) {
      impedanceValue = Z * 1000
      impedanceUnit = "mΩ"
    }

    // Format current unit
    let currentUnit = "A"
    let currentValue = I
    if (I < 0.001) {
      currentValue = I * 1000000
      currentUnit = "µA"
    } else if (I < 1) {
      currentValue = I * 1000
      currentUnit = "mA"
    }

    setResult({
      impedance: impedanceValue,
      impedanceUnit,
      resonanceFreq: f0,
      current: currentValue,
      currentUnit,
      vR,
      vL,
      vC,
      phaseAngle,
      xL,
      xC,
      omega,
      atResonance,
    })
  }

  const handleReset = () => {
    setResistance("")
    setInductance("")
    setCapacitance("")
    setVoltage("")
    setFrequency("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `RLC Circuit Analysis (${circuitType}):
Impedance: ${formatNumber(result.impedance)} ${result.impedanceUnit}
Current: ${formatNumber(result.current)} ${result.currentUnit}
Resonance Frequency: ${formatNumber(result.resonanceFreq)} Hz
Phase Angle: ${formatNumber(result.phaseAngle)}°
V_R: ${formatNumber(result.vR)} V
V_L: ${formatNumber(result.vL)} V
V_C: ${formatNumber(result.vC)} V`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "RLC Circuit Analysis",
          text: `RLC Circuit (${circuitType}): Z = ${formatNumber(result.impedance)} ${result.impedanceUnit}, I = ${formatNumber(result.current)} ${result.currentUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">RLC Circuit Calculator</CardTitle>
                    <CardDescription>Analyze series or parallel RLC circuits</CardDescription>
                  </div>
                </div>

                {/* Circuit Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Circuit Type</span>
                  <button
                    onClick={() => setCircuitType(circuitType === "series" ? "parallel" : "series")}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        circuitType === "parallel" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        circuitType === "series" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Series
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        circuitType === "parallel" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Parallel
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Resistance Input */}
                <div className="space-y-2">
                  <Label>Resistance (R)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder="Enter resistance"
                      value={resistance}
                      onChange={(e) => setResistance(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={resistanceUnit} onValueChange={setResistanceUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mΩ">mΩ</SelectItem>
                        <SelectItem value="Ω">Ω</SelectItem>
                        <SelectItem value="kΩ">kΩ</SelectItem>
                        <SelectItem value="MΩ">MΩ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Inductance Input */}
                <div className="space-y-2">
                  <Label>Inductance (L)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder="Enter inductance"
                      value={inductance}
                      onChange={(e) => setInductance(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={inductanceUnit} onValueChange={setInductanceUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="H">H</SelectItem>
                        <SelectItem value="mH">mH</SelectItem>
                        <SelectItem value="µH">µH</SelectItem>
                        <SelectItem value="nH">nH</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Capacitance Input */}
                <div className="space-y-2">
                  <Label>Capacitance (C)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder="Enter capacitance"
                      value={capacitance}
                      onChange={(e) => setCapacitance(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={capacitanceUnit} onValueChange={setCapacitanceUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="F">F</SelectItem>
                        <SelectItem value="mF">mF</SelectItem>
                        <SelectItem value="µF">µF</SelectItem>
                        <SelectItem value="nF">nF</SelectItem>
                        <SelectItem value="pF">pF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Voltage Input */}
                <div className="space-y-2">
                  <Label>Source Voltage (V)</Label>
                  <Input
                    type="number"
                    placeholder="Enter voltage in volts"
                    value={voltage}
                    onChange={(e) => setVoltage(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Frequency Input */}
                <div className="space-y-2">
                  <Label>Frequency (f)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder="Enter frequency"
                      value={frequency}
                      onChange={(e) => setFrequency(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={frequencyUnit} onValueChange={setFrequencyUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Hz">Hz</SelectItem>
                        <SelectItem value="kHz">kHz</SelectItem>
                        <SelectItem value="MHz">MHz</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateRLC} className="w-full" size="lg">
                  Calculate
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Impedance (Z)</p>
                      <p className="text-4xl font-bold text-purple-600">
                        {formatNumber(result.impedance)} {result.impedanceUnit}
                      </p>
                      {result.atResonance && (
                        <span className="inline-block mt-2 px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                          At Resonance
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Current (I)</p>
                        <p className="font-semibold text-purple-600">
                          {formatNumber(result.current)} {result.currentUnit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Resonance (f₀)</p>
                        <p className="font-semibold text-purple-600">{formatNumber(result.resonanceFreq)} Hz</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Phase Angle (φ)</p>
                        <p className="font-semibold text-purple-600">{formatNumber(result.phaseAngle)}°</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">X_L - X_C</p>
                        <p className="font-semibold text-purple-600">{formatNumber(result.xL - result.xC)} Ω</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-sm mb-4">
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">V_R</p>
                        <p className="font-semibold text-purple-600">{formatNumber(result.vR)} V</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">V_L</p>
                        <p className="font-semibold text-purple-600">{formatNumber(result.vL)} V</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">V_C</p>
                        <p className="font-semibold text-purple-600">{formatNumber(result.vC)} V</p>
                      </div>
                    </div>

                    {/* Step-by-step toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full text-sm text-purple-600 hover:text-purple-700 font-medium mb-3"
                    >
                      {showSteps ? "Hide Steps" : "Show Steps"}
                    </button>

                    {showSteps && (
                      <div className="p-3 bg-white rounded-lg text-sm space-y-2 mb-4">
                        <p>
                          <strong>Step 1:</strong> Calculate angular frequency
                        </p>
                        <p className="text-muted-foreground pl-4">ω = 2πf = {formatNumber(result.omega)} rad/s</p>
                        <p>
                          <strong>Step 2:</strong> Calculate reactances
                        </p>
                        <p className="text-muted-foreground pl-4">X_L = ωL = {formatNumber(result.xL)} Ω</p>
                        <p className="text-muted-foreground pl-4">X_C = 1/(ωC) = {formatNumber(result.xC)} Ω</p>
                        <p>
                          <strong>Step 3:</strong> Calculate impedance
                        </p>
                        {circuitType === "series" ? (
                          <p className="text-muted-foreground pl-4">
                            Z = √(R² + (X_L − X_C)²) = {formatNumber(result.impedance)} {result.impedanceUnit}
                          </p>
                        ) : (
                          <p className="text-muted-foreground pl-4">
                            Z = 1/√((1/R)² + (1/X_L − 1/X_C)²) = {formatNumber(result.impedance)} {result.impedanceUnit}
                          </p>
                        )}
                        <p>
                          <strong>Step 4:</strong> Calculate current
                        </p>
                        <p className="text-muted-foreground pl-4">
                          I = V/Z = {formatNumber(result.current)} {result.currentUnit}
                        </p>
                        <p>
                          <strong>Step 5:</strong> Calculate phase angle
                        </p>
                        <p className="text-muted-foreground pl-4">
                          φ = arctan((X_L − X_C)/R) = {formatNumber(result.phaseAngle)}°
                        </p>
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">RLC Circuit Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-2">Series RLC</p>
                    <p className="font-mono text-sm">Z = √(R² + (X_L − X_C)²)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-2">Parallel RLC</p>
                    <p className="font-mono text-sm">Z = 1/√((1/R)² + (1/X_L − 1/X_C)²)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-2">Resonance Frequency</p>
                    <p className="font-mono text-sm">f₀ = 1/(2π√(LC))</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Reactance Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium text-blue-700">Inductive Reactance</span>
                      <span className="font-mono text-blue-600">X_L = ωL</span>
                    </div>
                    <div className="flex justify-between p-3 bg-green-50 rounded-lg">
                      <span className="font-medium text-green-700">Capacitive Reactance</span>
                      <span className="font-mono text-green-600">X_C = 1/(ωC)</span>
                    </div>
                    <div className="flex justify-between p-3 bg-purple-50 rounded-lg">
                      <span className="font-medium text-purple-700">Angular Frequency</span>
                      <span className="font-mono text-purple-600">ω = 2πf</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Phase Relationships</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>X_L {">"} X_C:</strong> Circuit is inductive, current lags voltage
                  </p>
                  <p>
                    <strong>X_C {">"} X_L:</strong> Circuit is capacitive, current leads voltage
                  </p>
                  <p>
                    <strong>X_L = X_C:</strong> At resonance, purely resistive behavior
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding RLC Circuits</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An RLC circuit is an electrical circuit consisting of a resistor (R), inductor (L), and capacitor (C)
                  connected in series or parallel. These circuits are fundamental in electronics and are used in
                  filters, oscillators, tuning circuits, and many signal processing applications. The behavior of an RLC
                  circuit depends heavily on the frequency of the applied AC voltage.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  At the resonance frequency, the inductive reactance equals the capacitive reactance, causing the
                  impedance to reach its minimum value in series circuits (equal to R) or maximum in parallel circuits.
                  This property makes RLC circuits ideal for frequency selection and tuning applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-500" />
                  <CardTitle>Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  RLC circuit calculations are estimates based on ideal AC circuit conditions. Actual behavior may vary
                  due to parasitic elements, component tolerance, temperature effects, or non-ideal behavior. Always
                  consult datasheets and consider real-world factors when designing circuits. For critical applications,
                  verify results with proper instrumentation or consult an electrical engineer.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
