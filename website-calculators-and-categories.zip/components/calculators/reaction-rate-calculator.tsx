"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Activity,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type ConcentrationUnit = "M" | "mM" | "mol/L"
type TimeUnit = "s" | "min" | "h"
type RateType = "reactant" | "product"

interface ReactionRateResult {
  rate: number
  concentrationChange: number
  timeInterval: number
  coefficient: number
  rateType: RateType
  concentrationUnit: ConcentrationUnit
  timeUnit: TimeUnit
  direction: string
}

export function ReactionRateCalculator() {
  const [concentrationChange, setConcentrationChange] = useState("")
  const [timeInterval, setTimeInterval] = useState("")
  const [coefficient, setCoefficient] = useState("1")
  const [concentrationUnit, setConcentrationUnit] = useState<ConcentrationUnit>("M")
  const [timeUnit, setTimeUnit] = useState<TimeUnit>("s")
  const [rateType, setRateType] = useState<RateType>("reactant")
  const [result, setResult] = useState<ReactionRateResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  const calculate = () => {
    setError("")
    setResult(null)

    const concentrationChangeNum = Number.parseFloat(concentrationChange)
    const timeIntervalNum = Number.parseFloat(timeInterval)
    const coefficientNum = Number.parseFloat(coefficient)

    // Validation
    if (isNaN(concentrationChangeNum) || concentrationChangeNum < 0) {
      setError("Please enter a valid concentration change (≥ 0)")
      return
    }

    if (isNaN(timeIntervalNum) || timeIntervalNum <= 0) {
      setError("Please enter a valid time interval (> 0)")
      return
    }

    if (isNaN(coefficientNum) || coefficientNum <= 0) {
      setError("Please enter a valid stoichiometric coefficient (> 0)")
      return
    }

    // Calculate reaction rate
    // For reactants: Rate = -(1/coefficient) × (Δ[Reactant]/Δt)
    // For products: Rate = (1/coefficient) × (Δ[Product]/Δt)
    const rawRate = concentrationChangeNum / timeIntervalNum
    const rate = rateType === "reactant" ? rawRate / coefficientNum : rawRate / coefficientNum

    const direction = rateType === "reactant" ? "Reactant consumed" : "Product formed"

    setResult({
      rate,
      concentrationChange: concentrationChangeNum,
      timeInterval: timeIntervalNum,
      coefficient: coefficientNum,
      rateType,
      concentrationUnit,
      timeUnit,
      direction,
    })
  }

  const handleReset = () => {
    setConcentrationChange("")
    setTimeInterval("")
    setCoefficient("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(true)
  }

  const handleCopy = async () => {
    if (result) {
      const rateUnit = `${result.concentrationUnit}/${result.timeUnit}`
      const text = `Reaction Rate: ${formatNumber(result.rate)} ${rateUnit} (${result.direction})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const rateUnit = `${result.concentrationUnit}/${result.timeUnit}`
        await navigator.share({
          title: "Reaction Rate Calculator Result",
          text: `I calculated a reaction rate of ${formatNumber(result.rate)} ${rateUnit} using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 6 })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Reaction Rate Calculator</CardTitle>
                    <CardDescription>Calculate chemical reaction kinetics</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Rate Type Selector */}
                <div className="space-y-2">
                  <Label>Measuring</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant={rateType === "reactant" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setRateType("reactant")
                        setResult(null)
                        setError("")
                      }}
                    >
                      Reactant (Consumed)
                    </Button>
                    <Button
                      variant={rateType === "product" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setRateType("product")
                        setResult(null)
                        setError("")
                      }}
                    >
                      Product (Formed)
                    </Button>
                  </div>
                </div>

                {/* Concentration Change Input */}
                <div className="space-y-2">
                  <Label htmlFor="concentrationChange">
                    Change in Concentration (Δ[{rateType === "reactant" ? "Reactant" : "Product"}])
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="concentrationChange"
                      type="number"
                      placeholder="Enter concentration change"
                      value={concentrationChange}
                      onChange={(e) => setConcentrationChange(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select
                      value={concentrationUnit}
                      onValueChange={(v) => setConcentrationUnit(v as ConcentrationUnit)}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="M">M</SelectItem>
                        <SelectItem value="mM">mM</SelectItem>
                        <SelectItem value="mol/L">mol/L</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Time Interval Input */}
                <div className="space-y-2">
                  <Label htmlFor="timeInterval">Time Interval (Δt)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="timeInterval"
                      type="number"
                      placeholder="Enter time interval"
                      value={timeInterval}
                      onChange={(e) => setTimeInterval(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={timeUnit} onValueChange={(v) => setTimeUnit(v as TimeUnit)}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="s">s</SelectItem>
                        <SelectItem value="min">min</SelectItem>
                        <SelectItem value="h">h</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Stoichiometric Coefficient Input */}
                <div className="space-y-2">
                  <Label htmlFor="coefficient">Stoichiometric Coefficient</Label>
                  <Input
                    id="coefficient"
                    type="number"
                    placeholder="Enter coefficient"
                    value={coefficient}
                    onChange={(e) => setCoefficient(e.target.value)}
                    min="1"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">
                    The number in front of the species in the balanced equation (default: 1)
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Reaction Rate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Reaction Rate</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">{formatNumber(result.rate)}</p>
                      <p className="text-lg font-medium text-purple-500">
                        {result.concentrationUnit}/{result.timeUnit}
                      </p>
                      <p className="text-sm text-purple-600 mt-2 flex items-center justify-center gap-1">
                        <Activity className="h-4 w-4" />
                        {result.direction}
                      </p>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-purple-100">
                        <p className="text-sm font-medium text-purple-700 mb-2">Step-by-step Solution:</p>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          {result.rateType === "reactant" ? (
                            <>
                              <p className="font-mono">Formula: Rate = -(1/n) × (Δ[Reactant]/Δt)</p>
                              <p>
                                n (coefficient) = {result.coefficient}
                              </p>
                              <p>
                                Δ[Reactant] = {formatNumber(result.concentrationChange)} {result.concentrationUnit}
                              </p>
                              <p>
                                Δt = {formatNumber(result.timeInterval)} {result.timeUnit}
                              </p>
                              <p className="font-medium text-purple-600 mt-2">
                                Rate = (1/{result.coefficient}) × ({formatNumber(result.concentrationChange)} ÷{" "}
                                {formatNumber(result.timeInterval)})
                              </p>
                              <p className="font-medium text-purple-600">
                                Rate = {formatNumber(result.rate)} {result.concentrationUnit}/{result.timeUnit}
                              </p>
                            </>
                          ) : (
                            <>
                              <p className="font-mono">Formula: Rate = (1/n) × (Δ[Product]/Δt)</p>
                              <p>
                                n (coefficient) = {result.coefficient}
                              </p>
                              <p>
                                Δ[Product] = {formatNumber(result.concentrationChange)} {result.concentrationUnit}
                              </p>
                              <p>
                                Δt = {formatNumber(result.timeInterval)} {result.timeUnit}
                              </p>
                              <p className="font-medium text-purple-600 mt-2">
                                Rate = (1/{result.coefficient}) × ({formatNumber(result.concentrationChange)} ÷{" "}
                                {formatNumber(result.timeInterval)})
                              </p>
                              <p className="font-medium text-purple-600">
                                Rate = {formatNumber(result.rate)} {result.concentrationUnit}/{result.timeUnit}
                              </p>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Reaction Rate Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-mono font-semibold text-purple-700 text-center text-sm">
                      Rate = -(1/n) × (Δ[Reactant]/Δt)
                    </p>
                    <p className="text-xs text-purple-600 text-center mt-1">For reactants (consumed)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-mono font-semibold text-blue-700 text-center text-sm">
                      Rate = (1/n) × (Δ[Product]/Δt)
                    </p>
                    <p className="text-xs text-blue-600 text-center mt-1">For products (formed)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Info className="h-5 w-5" />
                    Understanding Reaction Rates
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div>
                    <p className="font-medium text-foreground mb-1">What is Reaction Rate?</p>
                    <p>
                      The reaction rate measures how quickly reactants are consumed or products are formed during a
                      chemical reaction over time.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Stoichiometric Coefficient</p>
                    <p>
                      The coefficient accounts for the balanced equation. If 2 mol of reactant produce 1 mol of
                      product, their rate relationship differs by their coefficients.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Average vs Instantaneous</p>
                    <p>
                      This calculator computes average rate over a time interval. Instantaneous rate requires
                      calculus (derivative at a specific time).
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Reaction Rate Units</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between">
                    <span>Molarity per second</span>
                    <span className="font-mono">M/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Millimolar per second</span>
                    <span className="font-mono">mM/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Molarity per minute</span>
                    <span className="font-mono">M/min</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Molarity per hour</span>
                    <span className="font-mono">M/h</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="space-y-2 text-sm text-amber-900">
                      <p className="font-medium">Important Note</p>
                      <p>
                        Reaction rate calculations represent average behavior over a time interval. Actual rates may
                        vary during the course of a reaction. Factors such as temperature, concentration, catalysts,
                        and surface area affect reaction kinetics.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
