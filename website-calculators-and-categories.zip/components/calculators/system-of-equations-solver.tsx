"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Grid3X3,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type SolutionMethod = "elimination" | "substitution" | "matrix"
type SolutionType = "unique" | "infinite" | "none"

interface Solution {
  type: SolutionType
  values: Record<string, number | string>
  steps: string[]
  matrix?: number[][]
  rref?: number[][]
}

export function SystemOfEquationsSolver() {
  const [numEquations, setNumEquations] = useState(2)
  const [numVariables, setNumVariables] = useState(2)
  const [variableNames, setVariableNames] = useState(["x", "y", "z", "w", "v"])
  const [equations, setEquations] = useState<string[]>(["", ""])
  const [method, setMethod] = useState<SolutionMethod>("matrix")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<Solution | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const parseEquation = (eq: string, vars: string[]): { coeffs: number[]; constant: number } | null => {
    try {
      // Normalize equation
      let normalized = eq.replace(/\s+/g, "").toLowerCase()

      // Split by equals sign
      const parts = normalized.split("=")
      if (parts.length !== 2) return null

      const leftSide = parts[0]
      let rightSide = parts[1]

      // Move right side to left (subtract)
      const rightValue = Number.parseFloat(rightSide)
      if (isNaN(rightValue)) {
        // Right side has variables, move them to left
        normalized = `${leftSide}-(${rightSide})`
        rightSide = "0"
      }

      const coeffs: number[] = new Array(vars.length).fill(0)
      let constant = -Number.parseFloat(rightSide) || 0

      // Parse left side for coefficients
      let currentTerm = ""
      let sign = 1

      for (let i = 0; i <= leftSide.length; i++) {
        const char = leftSide[i]

        if (char === "+" || char === "-" || i === leftSide.length) {
          if (currentTerm) {
            // Find variable in term
            let foundVar = false
            for (let v = 0; v < vars.length; v++) {
              const varName = vars[v].toLowerCase()
              if (currentTerm.includes(varName)) {
                foundVar = true
                const coeffStr = currentTerm.replace(varName, "")
                let coeff = 1
                if (coeffStr === "" || coeffStr === "+") coeff = 1
                else if (coeffStr === "-") coeff = -1
                else coeff = Number.parseFloat(coeffStr)
                coeffs[v] += sign * coeff
                break
              }
            }
            if (!foundVar) {
              // It's a constant
              constant += sign * Number.parseFloat(currentTerm)
            }
          }
          currentTerm = ""
          sign = char === "-" ? -1 : 1
        } else {
          currentTerm += char
        }
      }

      return { coeffs, constant }
    } catch {
      return null
    }
  }

  const solveSystem = () => {
    setError("")
    setResult(null)

    // Validate equations
    const validEquations = equations.slice(0, numEquations).filter((eq) => eq.trim() !== "")
    if (validEquations.length < numEquations) {
      setError(`Please enter all ${numEquations} equations`)
      return
    }

    const vars = variableNames.slice(0, numVariables)
    const matrix: number[][] = []
    const constants: number[] = []
    const steps: string[] = []

    steps.push(`System of ${numEquations} equations with ${numVariables} variables: ${vars.join(", ")}`)
    steps.push("")
    steps.push("Original equations:")

    // Parse all equations
    for (let i = 0; i < numEquations; i++) {
      const parsed = parseEquation(equations[i], vars)
      if (!parsed) {
        setError(`Invalid equation format in equation ${i + 1}`)
        return
      }
      matrix.push([...parsed.coeffs, parsed.constant])
      constants.push(parsed.constant)
      steps.push(`  ${i + 1}. ${equations[i]}`)
    }

    steps.push("")
    steps.push("Augmented matrix:")
    steps.push(formatMatrix(matrix))

    // Gaussian elimination with partial pivoting
    const rref = matrix.map((row) => [...row])
    const n = numEquations
    const m = numVariables

    steps.push("")
    steps.push("Applying Gaussian elimination (RREF):")

    for (let col = 0; col < Math.min(n, m); col++) {
      // Find pivot
      let maxRow = col
      for (let row = col + 1; row < n; row++) {
        if (Math.abs(rref[row][col]) > Math.abs(rref[maxRow][col])) {
          maxRow = row
        }
      }

      // Swap rows if needed
      if (maxRow !== col) {
        ;[rref[col], rref[maxRow]] = [rref[maxRow], rref[col]]
        steps.push(`  Swap R${col + 1} ↔ R${maxRow + 1}`)
      }

      // Check for zero pivot
      if (Math.abs(rref[col][col]) < 1e-10) {
        continue
      }

      // Scale pivot row
      const pivot = rref[col][col]
      for (let j = 0; j <= m; j++) {
        rref[col][j] /= pivot
      }
      if (Math.abs(pivot - 1) > 1e-10) {
        steps.push(`  R${col + 1} = R${col + 1} / ${formatNumber(pivot)}`)
      }

      // Eliminate column
      for (let row = 0; row < n; row++) {
        if (row !== col && Math.abs(rref[row][col]) > 1e-10) {
          const factor = rref[row][col]
          for (let j = 0; j <= m; j++) {
            rref[row][j] -= factor * rref[col][j]
          }
          steps.push(`  R${row + 1} = R${row + 1} - ${formatNumber(factor)} × R${col + 1}`)
        }
      }
    }

    steps.push("")
    steps.push("Reduced Row Echelon Form (RREF):")
    steps.push(formatMatrix(rref))

    // Analyze solution
    const solution = analyzeSolution(rref, vars, steps)

    setResult({
      ...solution,
      matrix: matrix,
      rref: rref,
    })
  }

  const analyzeSolution = (rref: number[][], vars: string[], steps: string[]): Solution => {
    const n = rref.length
    const m = vars.length
    const values: Record<string, number | string> = {}

    // Check for inconsistency (0 = non-zero)
    for (let i = 0; i < n; i++) {
      let allZero = true
      for (let j = 0; j < m; j++) {
        if (Math.abs(rref[i][j]) > 1e-10) {
          allZero = false
          break
        }
      }
      if (allZero && Math.abs(rref[i][m]) > 1e-10) {
        steps.push("")
        steps.push("Result: No solution (inconsistent system)")
        steps.push(`Row ${i + 1} indicates 0 = ${formatNumber(rref[i][m])}, which is impossible.`)
        return { type: "none", values: {}, steps }
      }
    }

    // Count pivots
    let pivotCount = 0
    const pivotCols: number[] = []
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < m; j++) {
        if (Math.abs(rref[i][j] - 1) < 1e-10) {
          // Check if it's a leading 1
          let isLeading = true
          for (let k = 0; k < j; k++) {
            if (Math.abs(rref[i][k]) > 1e-10) {
              isLeading = false
              break
            }
          }
          if (isLeading) {
            pivotCount++
            pivotCols.push(j)
            break
          }
        }
      }
    }

    // Check for infinite solutions
    if (pivotCount < m) {
      steps.push("")
      steps.push("Result: Infinite solutions")
      steps.push(`The system has ${m - pivotCount} free variable(s).`)

      const freeVars = vars.filter((_, i) => !pivotCols.includes(i))
      steps.push(`Free variable(s): ${freeVars.join(", ")}`)

      for (let i = 0; i < pivotCols.length; i++) {
        const varIdx = pivotCols[i]
        let expression = formatNumber(rref[i][m])
        for (let j = 0; j < m; j++) {
          if (j !== varIdx && Math.abs(rref[i][j]) > 1e-10) {
            const coeff = -rref[i][j]
            expression += ` ${coeff >= 0 ? "+" : "-"} ${formatNumber(Math.abs(coeff))}${vars[j]}`
          }
        }
        values[vars[varIdx]] = expression
      }

      freeVars.forEach((v) => {
        values[v] = `${v} (free)`
      })

      return { type: "infinite", values, steps }
    }

    // Unique solution
    steps.push("")
    steps.push("Result: Unique solution")

    for (let i = 0; i < Math.min(n, m); i++) {
      const varIdx = pivotCols[i]
      if (varIdx !== undefined) {
        values[vars[varIdx]] = roundToSignificant(rref[i][m])
        steps.push(`  ${vars[varIdx]} = ${formatNumber(rref[i][m])}`)
      }
    }

    return { type: "unique", values, steps }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num - Math.round(num)) < 1e-10) {
      return Math.round(num).toString()
    }
    return num.toFixed(4).replace(/\.?0+$/, "")
  }

  const roundToSignificant = (num: number): number => {
    if (Math.abs(num - Math.round(num)) < 1e-10) {
      return Math.round(num)
    }
    return Math.round(num * 10000) / 10000
  }

  const formatMatrix = (matrix: number[][]): string => {
    const rows = matrix.map((row) => "  [ " + row.map((v) => formatNumber(v).padStart(8)).join(" ") + " ]")
    return rows.join("\n")
  }

  const handleReset = () => {
    setEquations(new Array(numEquations).fill(""))
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = `System of Equations Solution\n`
      text += `Type: ${result.type === "unique" ? "Unique Solution" : result.type === "infinite" ? "Infinite Solutions" : "No Solution"}\n`
      if (result.type !== "none") {
        text += `Solutions:\n`
        Object.entries(result.values).forEach(([v, val]) => {
          text += `  ${v} = ${val}\n`
        })
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      let latex = "\\begin{cases}\n"
      equations.slice(0, numEquations).forEach((eq) => {
        latex += `  ${eq} \\\\\n`
      })
      latex += "\\end{cases}\n\n"

      if (result.type === "unique") {
        latex += "\\text{Solution: }\n"
        Object.entries(result.values).forEach(([v, val]) => {
          latex += `${v} = ${val}, \\quad `
        })
      }

      await navigator.clipboard.writeText(latex.trim())
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const updateEquationCount = (count: number) => {
    setNumEquations(count)
    setEquations((prev) => {
      const newEqs = [...prev]
      while (newEqs.length < count) newEqs.push("")
      return newEqs.slice(0, count)
    })
    setResult(null)
  }

  const updateVariableCount = (count: number) => {
    setNumVariables(count)
    setResult(null)
  }

  const getResultColor = () => {
    if (!result) return { color: "", bg: "" }
    switch (result.type) {
      case "unique":
        return { color: "text-green-600", bg: "bg-green-50 border-green-200" }
      case "infinite":
        return { color: "text-blue-600", bg: "bg-blue-50 border-blue-200" }
      case "none":
        return { color: "text-red-600", bg: "bg-red-50 border-red-200" }
    }
  }

  const colors = getResultColor()

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Grid3X3 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">System of Equations Solver</CardTitle>
                    <CardDescription>Solve systems of linear equations</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* System Configuration */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Number of Equations</Label>
                    <Select
                      value={numEquations.toString()}
                      onValueChange={(v) => updateEquationCount(Number.parseInt(v))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[2, 3, 4, 5].map((n) => (
                          <SelectItem key={n} value={n.toString()}>
                            {n} equations
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Number of Variables</Label>
                    <Select
                      value={numVariables.toString()}
                      onValueChange={(v) => updateVariableCount(Number.parseInt(v))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[2, 3, 4, 5].map((n) => (
                          <SelectItem key={n} value={n.toString()}>
                            {n} variables
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Variable Names */}
                <div className="space-y-2">
                  <Label>Variables: {variableNames.slice(0, numVariables).join(", ")}</Label>
                </div>

                {/* Equations Input */}
                <div className="space-y-3">
                  <Label>Enter Equations</Label>
                  {Array.from({ length: numEquations }).map((_, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground w-6">{i + 1}.</span>
                      <Input
                        placeholder={`e.g., 2x + 3y ${numVariables > 2 ? "+ z " : ""}= 10`}
                        value={equations[i] || ""}
                        onChange={(e) => {
                          const newEqs = [...equations]
                          newEqs[i] = e.target.value
                          setEquations(newEqs)
                        }}
                        className="font-mono"
                      />
                    </div>
                  ))}
                </div>

                {/* Method Selection */}
                <div className="space-y-2">
                  <Label>Solution Method</Label>
                  <Select value={method} onValueChange={(v) => setMethod(v as SolutionMethod)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="matrix">Matrix / Gaussian Elimination</SelectItem>
                      <SelectItem value="elimination">Elimination Method</SelectItem>
                      <SelectItem value="substitution">Substitution Method</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step solution</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={solveSystem} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Solve System
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${colors.bg} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Solution Type</p>
                      <p className={`text-2xl font-bold ${colors.color}`}>
                        {result.type === "unique"
                          ? "Unique Solution"
                          : result.type === "infinite"
                            ? "Infinite Solutions"
                            : "No Solution"}
                      </p>
                    </div>

                    {result.type !== "none" && (
                      <div className="space-y-2 mb-4">
                        <p className="text-sm font-medium text-center">Solution Values:</p>
                        <div className="grid gap-2">
                          {Object.entries(result.values).map(([v, val]) => (
                            <div key={v} className="flex justify-between items-center p-2 bg-white/50 rounded-lg">
                              <span className="font-mono font-medium">{v}</span>
                              <span className="font-mono">{val}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={showDetails} onOpenChange={setShowDetails}>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full">
                            {showDetails ? (
                              <ChevronUp className="h-4 w-4 mr-2" />
                            ) : (
                              <ChevronDown className="h-4 w-4 mr-2" />
                            )}
                            {showDetails ? "Hide" : "Show"} Step-by-Step Solution
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-3 p-3 bg-white/50 rounded-lg">
                            <pre className="text-xs font-mono whitespace-pre-wrap overflow-x-auto">
                              {result.steps.join("\n")}
                            </pre>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Solution Methods</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Matrix / Gaussian</span>
                      <p className="text-sm text-blue-600 mt-1">
                        Uses row operations to convert to RREF. Most efficient for larger systems.
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Elimination</span>
                      <p className="text-sm text-green-600 mt-1">
                        Eliminates variables by adding/subtracting equations.
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Substitution</span>
                      <p className="text-sm text-purple-600 mt-1">
                        Solves for one variable and substitutes into other equations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Solution Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Unique Solution</span>
                      <p className="text-sm text-green-600 mt-1">
                        Exactly one solution exists. System is consistent and independent.
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Infinite Solutions</span>
                      <p className="text-sm text-blue-600 mt-1">
                        Multiple solutions exist. System is consistent but dependent.
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">No Solution</span>
                      <p className="text-sm text-red-600 mt-1">
                        System is inconsistent. Equations contradict each other.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>Enter equations in standard form:</p>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center space-y-1">
                    <p>2x + 3y = 10</p>
                    <p>x - y + 2z = 5</p>
                    <p>3x + 2y - z = 8</p>
                  </div>
                  <p className="mt-2">Supported operators: +, -, =</p>
                  <p>Use decimal or integer coefficients</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a System of Linear Equations?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A system of linear equations is a collection of two or more linear equations involving the same set of
                  variables. The solution to a system is the set of values that satisfy all equations simultaneously.
                  Systems appear everywhere in mathematics, science, engineering, economics, and computer graphics. For
                  example, finding the intersection point of two lines, balancing chemical equations, or solving network
                  flow problems all involve systems of equations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A system can have exactly one solution (unique), infinitely many solutions (dependent), or no solution
                  at all (inconsistent). The geometric interpretation helps understand these cases: two lines can
                  intersect at one point, overlap completely, or be parallel. Similarly, three planes in 3D space can
                  meet at a point, along a line, or not at all.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Solve Systems of Equations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Gaussian Elimination:</strong> The most powerful method, especially for larger systems. It
                  converts the augmented matrix to Reduced Row Echelon Form (RREF) through elementary row operations:
                  swapping rows, multiplying a row by a non-zero constant, and adding a multiple of one row to another.
                  The final matrix directly reveals the solution.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Substitution:</strong> Solve one equation for a variable, then substitute that expression into
                  other equations. This reduces the number of variables step by step until you can solve for one
                  variable directly.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Elimination:</strong> Add or subtract equations to eliminate variables. Multiply equations by
                  constants if needed to make coefficients equal before elimination. This method works well for 2-3
                  variable systems.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    <p className="font-medium text-foreground mb-1">Disclaimer</p>
                    <p>
                      This system of equations solver uses standard algebraic and matrix methods. Results depend on the
                      accuracy and structure of the input equations. Numerical precision may vary for very large
                      coefficients or near-singular systems.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
