"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, BookOpen, Lightbulb, Plus, Minus } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "concentration" | "pressure"

interface Species {
  name: string
  coefficient: number
  initial: string
}

interface ICEResult {
  x: number
  equilibriumConcentrations: { name: string; value: number }[]
  Q: number
  valid: boolean
}

export function ICETableCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("concentration")
  const [reactants, setReactants] = useState<Species[]>([
    { name: "A", coefficient: 1, initial: "" }
  ])
  const [products, setProducts] = useState<Species[]>([
    { name: "B", coefficient: 1, initial: "0" }
  ])
  const [equilibriumConstant, setEquilibriumConstant] = useState("")
  const [result, setResult] = useState<ICEResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const addReactant = () => {
    if (reactants.length < 4) {
      const newName = String.fromCharCode(65 + reactants.length)
      setReactants([...reactants, { name: newName, coefficient: 1, initial: "" }])
    }
  }

  const removeReactant = (index: number) => {
    if (reactants.length > 1) {
      setReactants(reactants.filter((_, i) => i !== index))
    }
  }

  const addProduct = () => {
    if (products.length < 4) {
      const newName = String.fromCharCode(65 + reactants.length + products.length)
      setProducts([...products, { name: newName, coefficient: 1, initial: "0" }])
    }
  }

  const removeProduct = (index: number) => {
    if (products.length > 1) {
      setProducts(products.filter((_, i) => i !== index))
    }
  }

  const updateReactant = (index: number, field: keyof Species, value: string | number) => {
    const updated = [...reactants]
    updated[index] = { ...updated[index], [field]: value }
    setReactants(updated)
  }

  const updateProduct = (index: number, field: keyof Species, value: string | number) => {
    const updated = [...products]
    updated[index] = { ...updated[index], [field]: value }
    setProducts(updated)
  }

  const solveQuadratic = (a: number, b: number, c: number): number[] => {
    const discriminant = b * b - 4 * a * c
    if (discriminant < 0) return []
    if (discriminant === 0) return [-b / (2 * a)]
    const sqrtD = Math.sqrt(discriminant)
    return [(-b + sqrtD) / (2 * a), (-b - sqrtD) / (2 * a)]
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const K = Number.parseFloat(equilibriumConstant)
    if (isNaN(K) || K <= 0) {
      setError("Please enter a valid equilibrium constant (K > 0)")
      return
    }

    for (const r of reactants) {
      const initial = Number.parseFloat(r.initial)
      if (isNaN(initial) || initial < 0) {
        setError(`Please enter a valid initial ${unitSystem === "concentration" ? "concentration" : "pressure"} for ${r.name}`)
        return
      }
      if (r.coefficient <= 0 || !Number.isInteger(r.coefficient)) {
        setError(`Please enter a valid coefficient for ${r.name}`)
        return
      }
    }

    for (const p of products) {
      const initial = Number.parseFloat(p.initial)
      if (isNaN(initial) || initial < 0) {
        setError(`Please enter a valid initial ${unitSystem === "concentration" ? "concentration" : "pressure"} for ${p.name}`)
        return
      }
      if (p.coefficient <= 0 || !Number.isInteger(p.coefficient)) {
        setError(`Please enter a valid coefficient for ${p.name}`)
        return
      }
    }

    // Simple case: aA -> bB with one reactant and one product
    if (reactants.length === 1 && products.length === 1) {
      const a = reactants[0].coefficient
      const b = products[0].coefficient
      const A0 = Number.parseFloat(reactants[0].initial)
      const B0 = Number.parseFloat(products[0].initial)

      // At equilibrium: [A] = A0 - ax, [B] = B0 + bx
      // K = [B]^b / [A]^a = (B0 + bx)^b / (A0 - ax)^a

      // For simple case where a=1, b=1: K = (B0 + x) / (A0 - x)
      // K(A0 - x) = B0 + x
      // KA0 - Kx = B0 + x
      // KA0 - B0 = x + Kx
      // x = (KA0 - B0) / (1 + K)

      let x: number

      if (a === 1 && b === 1) {
        x = (K * A0 - B0) / (1 + K)
      } else if (a === 1 && b === 2) {
        // K = (B0 + 2x)^2 / (A0 - x)
        // K(A0 - x) = (B0 + 2x)^2
        // Let u = B0 + 2x, then x = (u - B0)/2
        // K(A0 - (u-B0)/2) = u^2
        // K*A0 - K*(u-B0)/2 = u^2
        // 2*K*A0 - K*u + K*B0 = 2*u^2
        // 2*u^2 + K*u - (2*K*A0 + K*B0) = 0
        const quadA = 4
        const quadB = 4 * B0 + K
        const quadC = B0 * B0 - K * A0
        const solutions = solveQuadratic(quadA, quadB, quadC)
        const validX = solutions.filter(sol => sol >= 0 && sol <= A0)
        if (validX.length === 0) {
          setError("No valid solution found. Check your input values.")
          return
        }
        x = validX[0]
      } else {
        // General numerical approach using Newton's method
        // For now, use simple iteration for other cases
        let xGuess = A0 * 0.5
        for (let i = 0; i < 100; i++) {
          const Aeq = A0 - a * xGuess
          const Beq = B0 + b * xGuess
          if (Aeq <= 0 || Beq < 0) {
            xGuess = xGuess * 0.5
            continue
          }
          const Qcurrent = Math.pow(Beq, b) / Math.pow(Aeq, a)
          if (Math.abs(Qcurrent - K) < 1e-10) break
          // Adjust x
          if (Qcurrent < K) {
            xGuess += (A0 - xGuess) * 0.1
          } else {
            xGuess -= xGuess * 0.1
          }
        }
        x = xGuess
      }

      // Validate x
      if (x < 0 || x > A0 / a) {
        setError("No valid solution found. The reaction may not reach equilibrium with these conditions.")
        return
      }

      const Aeq = A0 - a * x
      const Beq = B0 + b * x

      if (Aeq < 0 || Beq < 0) {
        setError("Invalid result: negative concentrations. Check your input values.")
        return
      }

      const Q = Math.pow(Beq, b) / Math.pow(Aeq, a)

      setResult({
        x: Math.round(x * 1e6) / 1e6,
        equilibriumConcentrations: [
          { name: reactants[0].name, value: Math.round(Aeq * 1e6) / 1e6 },
          { name: products[0].name, value: Math.round(Beq * 1e6) / 1e6 }
        ],
        Q: Math.round(Q * 1e4) / 1e4,
        valid: true
      })
    } else {
      // Multiple reactants/products - simplified calculation
      // Using the approximation method for small x
      
      const A0_values = reactants.map(r => Number.parseFloat(r.initial))
      const B0_values = products.map(p => Number.parseFloat(p.initial))
      
      // Iterative solver
      let x = 0.001
      const maxIterations = 1000
      const tolerance = 1e-10
      
      for (let iter = 0; iter < maxIterations; iter++) {
        // Calculate equilibrium concentrations
        const Aeq = reactants.map((r, i) => A0_values[i] - r.coefficient * x)
        const Beq = products.map((p, i) => B0_values[i] + p.coefficient * x)
        
        // Check for negative concentrations
        if (Aeq.some(val => val <= 0) || Beq.some(val => val < 0)) {
          x = x * 0.9
          continue
        }
        
        // Calculate Q
        let numerator = 1
        let denominator = 1
        for (let i = 0; i < products.length; i++) {
          numerator *= Math.pow(Beq[i], products[i].coefficient)
        }
        for (let i = 0; i < reactants.length; i++) {
          denominator *= Math.pow(Aeq[i], reactants[i].coefficient)
        }
        const Q = numerator / denominator
        
        if (Math.abs(Q - K) < tolerance) {
          const equilibriumConcentrations = [
            ...reactants.map((r, i) => ({ name: r.name, value: Math.round(Aeq[i] * 1e6) / 1e6 })),
            ...products.map((p, i) => ({ name: p.name, value: Math.round(Beq[i] * 1e6) / 1e6 }))
          ]
          
          setResult({
            x: Math.round(x * 1e6) / 1e6,
            equilibriumConcentrations,
            Q: Math.round(Q * 1e4) / 1e4,
            valid: true
          })
          return
        }
        
        // Adjust x using bisection-like approach
        if (Q < K) {
          x += Math.min(0.001, (Math.min(...A0_values) - x) * 0.1)
        } else {
          x -= x * 0.1
        }
        
        if (x <= 0) x = 0.0001
      }
      
      setError("Could not converge to a solution. Try adjusting your input values.")
    }
  }

  const handleReset = () => {
    setReactants([{ name: "A", coefficient: 1, initial: "" }])
    setProducts([{ name: "B", coefficient: 1, initial: "0" }])
    setEquilibriumConstant("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `ICE Table Results:\nx = ${result.x}\nEquilibrium: ${result.equilibriumConcentrations.map(e => `[${e.name}] = ${e.value}`).join(", ")}\nQ = ${result.Q}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "ICE Table Calculator Result",
          text: `ICE Table Results: x = ${result.x}, Equilibrium concentrations calculated using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "concentration" ? "pressure" : "concentration"))
    handleReset()
  }

  const unitLabel = unitSystem === "concentration" ? "M" : "atm"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">ICE Table Calculator</CardTitle>
                    <CardDescription>Solve equilibrium problems with ICE tables</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Type</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "pressure" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "concentration" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Concentration
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "pressure" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Pressure
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Reactants */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Reactants</Label>
                    <Button variant="outline" size="sm" onClick={addReactant} disabled={reactants.length >= 4}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>
                  {reactants.map((reactant, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2 items-end">
                      <div className="col-span-3">
                        <Label className="text-xs">Coef.</Label>
                        <Input
                          type="number"
                          value={reactant.coefficient}
                          onChange={(e) => updateReactant(index, "coefficient", parseInt(e.target.value) || 1)}
                          min="1"
                          className="h-9"
                        />
                      </div>
                      <div className="col-span-3">
                        <Label className="text-xs">Name</Label>
                        <Input
                          value={reactant.name}
                          onChange={(e) => updateReactant(index, "name", e.target.value)}
                          className="h-9"
                        />
                      </div>
                      <div className="col-span-4">
                        <Label className="text-xs">Initial ({unitLabel})</Label>
                        <Input
                          type="number"
                          placeholder="0.00"
                          value={reactant.initial}
                          onChange={(e) => updateReactant(index, "initial", e.target.value)}
                          min="0"
                          step="0.01"
                          className="h-9"
                        />
                      </div>
                      <div className="col-span-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeReactant(index)}
                          disabled={reactants.length <= 1}
                          className="h-9 w-full"
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Products */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Products</Label>
                    <Button variant="outline" size="sm" onClick={addProduct} disabled={products.length >= 4}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>
                  {products.map((product, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2 items-end">
                      <div className="col-span-3">
                        <Label className="text-xs">Coef.</Label>
                        <Input
                          type="number"
                          value={product.coefficient}
                          onChange={(e) => updateProduct(index, "coefficient", parseInt(e.target.value) || 1)}
                          min="1"
                          className="h-9"
                        />
                      </div>
                      <div className="col-span-3">
                        <Label className="text-xs">Name</Label>
                        <Input
                          value={product.name}
                          onChange={(e) => updateProduct(index, "name", e.target.value)}
                          className="h-9"
                        />
                      </div>
                      <div className="col-span-4">
                        <Label className="text-xs">Initial ({unitLabel})</Label>
                        <Input
                          type="number"
                          placeholder="0.00"
                          value={product.initial}
                          onChange={(e) => updateProduct(index, "initial", e.target.value)}
                          min="0"
                          step="0.01"
                          className="h-9"
                        />
                      </div>
                      <div className="col-span-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeProduct(index)}
                          disabled={products.length <= 1}
                          className="h-9 w-full"
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Equilibrium Constant */}
                <div className="space-y-2">
                  <Label htmlFor="K">Equilibrium Constant (K{unitSystem === "pressure" ? "p" : "c"})</Label>
                  <Input
                    id="K"
                    type="number"
                    placeholder="Enter K value"
                    value={equilibriumConstant}
                    onChange={(e) => setEquilibriumConstant(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Equilibrium
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Change Variable (x)</p>
                      <p className="text-4xl font-bold text-purple-600 mb-2">{result.x}</p>
                      <p className="text-sm text-purple-600">{unitLabel}</p>
                    </div>

                    {/* ICE Table Display */}
                    <div className="bg-white rounded-lg p-3 mb-4">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2 px-2">Species</th>
                            <th className="text-center py-2 px-2">I</th>
                            <th className="text-center py-2 px-2">C</th>
                            <th className="text-center py-2 px-2">E</th>
                          </tr>
                        </thead>
                        <tbody>
                          {reactants.map((r, i) => {
                            const eq = result.equilibriumConcentrations.find(e => e.name === r.name)
                            return (
                              <tr key={`r-${i}`} className="border-b">
                                <td className="py-2 px-2 font-medium">{r.name}</td>
                                <td className="text-center py-2 px-2">{r.initial}</td>
                                <td className="text-center py-2 px-2 text-red-600">-{r.coefficient}x</td>
                                <td className="text-center py-2 px-2 font-semibold text-purple-600">{eq?.value}</td>
                              </tr>
                            )
                          })}
                          {products.map((p, i) => {
                            const eq = result.equilibriumConcentrations.find(e => e.name === p.name)
                            return (
                              <tr key={`p-${i}`} className={i < products.length - 1 ? "border-b" : ""}>
                                <td className="py-2 px-2 font-medium">{p.name}</td>
                                <td className="text-center py-2 px-2">{p.initial}</td>
                                <td className="text-center py-2 px-2 text-green-600">+{p.coefficient}x</td>
                                <td className="text-center py-2 px-2 font-semibold text-purple-600">{eq?.value}</td>
                              </tr>
                            )
                          })}
                        </tbody>
                      </table>
                    </div>

                    <div className="text-center text-sm text-muted-foreground">
                      Verification: Q = {result.Q} (should equal K)
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">ICE Table Structure</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">I - Initial</span>
                      <span className="text-sm text-blue-600">Starting concentrations</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">C - Change</span>
                      <span className="text-sm text-yellow-600">Change during reaction</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">E - Equilibrium</span>
                      <span className="text-sm text-green-600">Final concentrations</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">ICE Table Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">K = [Products]^n / [Reactants]^m</p>
                  </div>
                  <p>
                    For a reaction aA + bB ⇌ cC + dD:{" "}
                    <strong>K = [C]^c[D]^d / [A]^a[B]^b</strong>
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Detailed Content Cards */}
          <div className="mt-12 space-y-8">
            {/* What is ICE Table */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an ICE Table?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An ICE table (Initial-Change-Equilibrium table) is a systematic method used in chemistry to organize 
                  and solve equilibrium problems. The acronym ICE represents the three rows of the table: Initial 
                  concentrations (or pressures) before the reaction proceeds, Change in concentrations as the reaction 
                  moves toward equilibrium, and Equilibrium concentrations when the system has reached its final state.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This powerful organizational tool helps students and chemists alike to visualize how concentrations 
                  change during a chemical reaction and to systematically solve for unknown equilibrium values. ICE 
                  tables are particularly useful when dealing with equilibrium constants and determining the extent to 
                  which a reaction will proceed under given conditions.
                </p>
              </CardContent>
            </Card>

            {/* How to Use ICE Tables */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use ICE Tables</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Using an ICE table involves several systematic steps. First, write out the balanced chemical equation 
                  and set up the table with columns for each species involved in the reaction. Fill in the Initial row 
                  with the starting concentrations or partial pressures of all reactants and products (products often 
                  start at zero).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In the Change row, express changes in terms of a variable x, using the stoichiometric coefficients. 
                  Reactants decrease (−x multiplied by coefficient), while products increase (+x multiplied by 
                  coefficient). The Equilibrium row is simply the sum of Initial and Change values. Finally, substitute 
                  equilibrium expressions into the K expression and solve for x algebraically.
                </p>
              </CardContent>
            </Card>

            {/* When to Use ICE Tables */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  <CardTitle>When to Use ICE Tables</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  ICE tables are essential when you need to calculate equilibrium concentrations given initial 
                  conditions and an equilibrium constant. They are commonly used in general chemistry, analytical 
                  chemistry, and biochemistry courses. Typical applications include acid-base equilibria, solubility 
                  equilibria, gas-phase reactions, and complex ion formation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Use an ICE table whenever you encounter problems that give you initial concentrations and ask for 
                  equilibrium values, or when you need to verify that calculated equilibrium concentrations satisfy 
                  the equilibrium constant expression. They are particularly helpful for reactions that do not go to 
                  completion and establish a dynamic equilibrium.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations of ICE Tables</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While ICE tables are powerful tools, they have several limitations. They assume ideal behavior of 
                  solutions and gases, which may not hold at high concentrations or pressures. The calculations assume 
                  that the system reaches true thermodynamic equilibrium, which may not always occur in real-world 
                  situations due to kinetic barriers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Complex equilibrium systems with multiple simultaneous equilibria may require more sophisticated 
                  approaches. Additionally, solving ICE table problems can lead to polynomial equations that are 
                  difficult to solve without approximations (like the "x is small" approximation) or numerical methods. 
                  Always verify your results by substituting back into the equilibrium expression to ensure Q = K.
                </p>
                <div className="mt-4 p-3 rounded-lg bg-yellow-50 border border-yellow-200 text-yellow-700 text-sm">
                  ICE table calculations assume ideal solutions or gases and proper equilibrium conditions. Non-ideal 
                  effects are not accounted for.
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
