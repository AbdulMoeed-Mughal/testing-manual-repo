"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Layers, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type PressureUnit = "Pa" | "kPa" | "MPa" | "GPa" | "psi" | "ksi"
type VolumeChangeMode = "decimal" | "percentage"

interface BulkModulusResult {
  value: number
  displayValue: string
  category: string
  color: string
  bgColor: string
}

const pressureConversions: Record<PressureUnit, number> = {
  Pa: 1,
  kPa: 1e3,
  MPa: 1e6,
  GPa: 1e9,
  psi: 6894.76,
  ksi: 6894760,
}

const pressureLabels: Record<PressureUnit, string> = {
  Pa: "Pa",
  kPa: "kPa",
  MPa: "MPa",
  GPa: "GPa",
  psi: "psi",
  ksi: "ksi",
}

export function BulkModulusCalculator() {
  const [pressureChange, setPressureChange] = useState("")
  const [pressureUnit, setPressureUnit] = useState<PressureUnit>("MPa")
  const [volumeChange, setVolumeChange] = useState("")
  const [volumeChangeMode, setVolumeChangeMode] = useState<VolumeChangeMode>("decimal")
  const [outputUnit, setOutputUnit] = useState<PressureUnit>("GPa")
  const [result, setResult] = useState<BulkModulusResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateBulkModulus = () => {
    setError("")
    setResult(null)

    const deltaP = Number.parseFloat(pressureChange)
    if (isNaN(deltaP) || deltaP <= 0) {
      setError("Please enter a valid positive pressure change")
      return
    }

    let volumeChangeDecimal = Number.parseFloat(volumeChange)
    if (isNaN(volumeChangeDecimal)) {
      setError("Please enter a valid volume change")
      return
    }

    // Convert percentage to decimal if needed
    if (volumeChangeMode === "percentage") {
      volumeChangeDecimal = volumeChangeDecimal / 100
    }

    if (volumeChangeDecimal === 0) {
      setError("Volume change cannot be zero")
      return
    }

    // Convert pressure to Pa
    const deltaPInPa = deltaP * pressureConversions[pressureUnit]

    // Calculate bulk modulus: K = -ΔP / (ΔV/V₀)
    // Since compression means negative ΔV/V₀, we use absolute value
    const bulkModulusPa = Math.abs(deltaPInPa / volumeChangeDecimal)

    // Convert to output unit
    const bulkModulusOutput = bulkModulusPa / pressureConversions[outputUnit]

    // Format display value
    let displayValue: string
    if (bulkModulusOutput >= 1000) {
      displayValue = bulkModulusOutput.toExponential(3)
    } else if (bulkModulusOutput < 0.001) {
      displayValue = bulkModulusOutput.toExponential(3)
    } else {
      displayValue = bulkModulusOutput.toFixed(4)
    }

    // Categorize the bulk modulus
    let category: string
    let color: string
    let bgColor: string

    const bulkModulusGPa = bulkModulusPa / 1e9

    if (bulkModulusGPa < 1) {
      category = "Very Compressible (Gas/Foam)"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (bulkModulusGPa < 10) {
      category = "Compressible (Rubber/Polymer)"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (bulkModulusGPa < 100) {
      category = "Moderate Stiffness (Soft Metals)"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (bulkModulusGPa < 300) {
      category = "Stiff (Common Metals)"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Very Stiff (Hard Materials)"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      value: bulkModulusOutput,
      displayValue,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setPressureChange("")
    setVolumeChange("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Bulk Modulus: ${result.displayValue} ${pressureLabels[outputUnit]} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Bulk Modulus Result",
          text: `I calculated bulk modulus using CalcHub! K = ${result.displayValue} ${pressureLabels[outputUnit]} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleVolumeChangeMode = () => {
    setVolumeChangeMode((prev) => (prev === "decimal" ? "percentage" : "decimal"))
    setVolumeChange("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Bulk Modulus Calculator</CardTitle>
                    <CardDescription>Calculate resistance to uniform compression</CardDescription>
                  </div>
                </div>

                {/* Volume Change Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Volume Change Input</span>
                  <button
                    onClick={toggleVolumeChangeMode}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        volumeChangeMode === "percentage" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        volumeChangeMode === "decimal" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Decimal
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        volumeChangeMode === "percentage" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Percentage
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Pressure Change Input */}
                <div className="space-y-2">
                  <Label htmlFor="pressureChange">Pressure Change (ΔP)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="pressureChange"
                      type="number"
                      placeholder="Enter pressure change"
                      value={pressureChange}
                      onChange={(e) => setPressureChange(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={pressureUnit} onValueChange={(v) => setPressureUnit(v as PressureUnit)}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Pa">Pa</SelectItem>
                        <SelectItem value="kPa">kPa</SelectItem>
                        <SelectItem value="MPa">MPa</SelectItem>
                        <SelectItem value="GPa">GPa</SelectItem>
                        <SelectItem value="psi">psi</SelectItem>
                        <SelectItem value="ksi">ksi</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Volume Change Input */}
                <div className="space-y-2">
                  <Label htmlFor="volumeChange">
                    Relative Volume Change (ΔV/V₀) {volumeChangeMode === "percentage" ? "(%)" : "(decimal)"}
                  </Label>
                  <Input
                    id="volumeChange"
                    type="number"
                    placeholder={volumeChangeMode === "percentage" ? "e.g., 2 for 2%" : "e.g., 0.02"}
                    value={volumeChange}
                    onChange={(e) => setVolumeChange(e.target.value)}
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">
                    {volumeChangeMode === "percentage"
                      ? "Enter as percentage (e.g., 2 means 2% compression)"
                      : "Enter as decimal (e.g., 0.02 means 2% compression)"}
                  </p>
                </div>

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <Select value={outputUnit} onValueChange={(v) => setOutputUnit(v as PressureUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pa">Pascal (Pa)</SelectItem>
                      <SelectItem value="kPa">Kilopascal (kPa)</SelectItem>
                      <SelectItem value="MPa">Megapascal (MPa)</SelectItem>
                      <SelectItem value="GPa">Gigapascal (GPa)</SelectItem>
                      <SelectItem value="psi">Pounds per sq inch (psi)</SelectItem>
                      <SelectItem value="ksi">Kilopounds per sq inch (ksi)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBulkModulus} className="w-full" size="lg">
                  Calculate Bulk Modulus
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Bulk Modulus (K)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.displayValue}
                        <span className="text-lg ml-1">{pressureLabels[outputUnit]}</span>
                      </p>
                      <p className={`text-sm font-medium ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Step-by-step toggle */}
                    <div className="mt-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowSteps(!showSteps)}
                        className="w-full text-muted-foreground"
                      >
                        <Calculator className="h-4 w-4 mr-1" />
                        {showSteps ? "Hide" : "Show"} Calculation Steps
                      </Button>

                      {showSteps && (
                        <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                          <p>
                            <strong>Formula:</strong> K = −ΔP / (ΔV/V₀)
                          </p>
                          <p>
                            <strong>Step 1:</strong> ΔP = {pressureChange} {pressureLabels[pressureUnit]}
                          </p>
                          <p>
                            <strong>Step 2:</strong> ΔV/V₀ ={" "}
                            {volumeChangeMode === "percentage"
                              ? `${volumeChange}% = ${(Number.parseFloat(volumeChange) / 100).toFixed(4)}`
                              : volumeChange}
                          </p>
                          <p>
                            <strong>Step 3:</strong> K = |{pressureChange} /{" "}
                            {volumeChangeMode === "percentage"
                              ? (Number.parseFloat(volumeChange) / 100).toFixed(4)
                              : volumeChange}
                            | = {result.displayValue} {pressureLabels[outputUnit]}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bulk Modulus Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Very Compressible</span>
                      <span className="text-sm text-blue-600">{"< 1 GPa"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Compressible</span>
                      <span className="text-sm text-green-600">1 – 10 GPa</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate</span>
                      <span className="text-sm text-yellow-600">10 – 100 GPa</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Stiff</span>
                      <span className="text-sm text-orange-600">100 – 300 GPa</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very Stiff</span>
                      <span className="text-sm text-red-600">≥ 300 GPa</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Material Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between py-1 border-b">
                      <span className="text-muted-foreground">Air (STP)</span>
                      <span className="font-medium">~0.0001 GPa</span>
                    </div>
                    <div className="flex justify-between py-1 border-b">
                      <span className="text-muted-foreground">Water</span>
                      <span className="font-medium">~2.2 GPa</span>
                    </div>
                    <div className="flex justify-between py-1 border-b">
                      <span className="text-muted-foreground">Rubber</span>
                      <span className="font-medium">~2 GPa</span>
                    </div>
                    <div className="flex justify-between py-1 border-b">
                      <span className="text-muted-foreground">Aluminum</span>
                      <span className="font-medium">~76 GPa</span>
                    </div>
                    <div className="flex justify-between py-1 border-b">
                      <span className="text-muted-foreground">Steel</span>
                      <span className="font-medium">~160 GPa</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-muted-foreground">Diamond</span>
                      <span className="font-medium">~443 GPa</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bulk Modulus Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">K = −ΔP / (ΔV/V₀)</p>
                  </div>
                  <p>
                    Where <strong>K</strong> is bulk modulus, <strong>ΔP</strong> is pressure change, and{" "}
                    <strong>ΔV/V₀</strong> is relative volume change.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Bulk Modulus?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bulk modulus (K) is a measure of a material's resistance to uniform compression. It quantifies how
                  much pressure is needed to cause a given relative decrease in volume. A higher bulk modulus indicates
                  a stiffer material that is more resistant to compression, while a lower bulk modulus indicates a more
                  compressible material.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The bulk modulus is one of the three main elastic moduli, along with Young's modulus (resistance to
                  linear strain) and shear modulus (resistance to shear deformation). It is particularly important in
                  fluid mechanics, geophysics, and materials science where understanding volumetric deformation under
                  pressure is critical.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Bulk Modulus</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bulk modulus is essential in many engineering and scientific applications. In hydraulic systems, it
                  determines how much fluid compresses under pressure, affecting system responsiveness. In geophysics,
                  it helps characterize Earth's interior and predict seismic wave velocities. In materials engineering,
                  it's used to design structures that must withstand uniform pressure, such as submarine hulls and
                  pressure vessels.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The relationship between bulk modulus and other elastic properties is given by K = E / (3(1 - 2ν)),
                  where E is Young's modulus and ν is Poisson's ratio. This connection allows engineers to predict one
                  property from others and design materials with specific mechanical characteristics.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Bulk modulus calculations are estimates based on ideal behavior. Actual material response may vary due
                  to temperature, heterogeneity, and experimental conditions. Consult material datasheets for precise
                  values.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
