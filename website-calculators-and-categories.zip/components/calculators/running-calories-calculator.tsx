"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Activity,
  Info,
  ChevronDown,
  ChevronUp,
  Flame,
  Timer,
  MapPin,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type TerrainType = "flat" | "hilly" | "trail"
type Gender = "male" | "female"

interface RunningCaloriesResult {
  totalCalories: number
  caloriesPerUnit: number
  metValue: number
  pace: number
  speed: number
  color: string
  bgColor: string
  intensity: string
}

export function RunningCaloriesCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [distance, setDistance] = useState("")
  const [duration, setDuration] = useState("")
  const [terrain, setTerrain] = useState<TerrainType>("flat")
  const [gender, setGender] = useState<Gender>("male")
  const [result, setResult] = useState<RunningCaloriesResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const getMETValue = (speedKmh: number, terrainType: TerrainType): number => {
    // Base MET values based on running speed (km/h)
    let baseMET: number
    if (speedKmh < 6.4)
      baseMET = 6.0 // Light jogging
    else if (speedKmh < 8) baseMET = 8.3
    else if (speedKmh < 9.7) baseMET = 9.8
    else if (speedKmh < 11.3) baseMET = 10.5
    else if (speedKmh < 12.9) baseMET = 11.0
    else if (speedKmh < 14.5) baseMET = 11.8
    else if (speedKmh < 16.1) baseMET = 12.8
    else if (speedKmh < 17.7) baseMET = 14.5
    else baseMET = 16.0 // Very fast running

    // Terrain adjustments
    const terrainMultipliers: Record<TerrainType, number> = {
      flat: 1.0,
      hilly: 1.15,
      trail: 1.25,
    }

    return baseMET * terrainMultipliers[terrainType]
  }

  const getIntensityLevel = (speedKmh: number): { intensity: string; color: string; bgColor: string } => {
    if (speedKmh < 8) {
      return { intensity: "Light", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    } else if (speedKmh < 11) {
      return { intensity: "Moderate", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    } else if (speedKmh < 14) {
      return { intensity: "Vigorous", color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    } else {
      return { intensity: "High Intensity", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    }
  }

  const calculateCalories = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const distanceNum = Number.parseFloat(distance)
    const durationNum = Number.parseFloat(duration)

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(distanceNum) || distanceNum <= 0) {
      setError("Please enter a valid distance greater than 0")
      return
    }

    if (isNaN(durationNum) || durationNum <= 0) {
      setError("Please enter a valid duration greater than 0")
      return
    }

    // Convert to metric if needed
    const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum
    const distanceKm = unitSystem === "imperial" ? distanceNum * 1.60934 : distanceNum

    // Calculate speed in km/h
    const speedKmh = distanceKm / (durationNum / 60)

    // Validate realistic speed (walking to elite sprinting)
    if (speedKmh < 4 || speedKmh > 25) {
      setError("Please check your distance and duration values - the calculated pace seems unrealistic")
      return
    }

    // Get MET value based on speed and terrain
    const metValue = getMETValue(speedKmh, terrain)

    // Calculate calories burned
    // Formula: Calories = (MET × 3.5 × Weight in kg) ÷ 200 × Duration in minutes
    let totalCalories = ((metValue * 3.5 * weightKg) / 200) * durationNum

    // Gender adjustment (women typically burn ~5% fewer calories)
    if (gender === "female") {
      totalCalories *= 0.95
    }

    // Calculate pace (min/km or min/mile)
    const paceMinPerKm = durationNum / distanceKm
    const pace = unitSystem === "imperial" ? paceMinPerKm * 1.60934 : paceMinPerKm

    // Calculate calories per distance unit
    const caloriesPerUnit = totalCalories / (unitSystem === "imperial" ? distanceNum : distanceKm)

    const { intensity, color, bgColor } = getIntensityLevel(speedKmh)

    setResult({
      totalCalories: Math.round(totalCalories),
      caloriesPerUnit: Math.round(caloriesPerUnit * 10) / 10,
      metValue: Math.round(metValue * 10) / 10,
      pace: Math.round(pace * 100) / 100,
      speed: Math.round(speedKmh * 10) / 10,
      color,
      bgColor,
      intensity,
    })
  }

  const handleReset = () => {
    setWeight("")
    setDistance("")
    setDuration("")
    setTerrain("flat")
    setGender("male")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Running Calories: ${result.totalCalories} kcal burned over ${distance} ${unitSystem === "metric" ? "km" : "miles"} in ${duration} minutes (${result.intensity} intensity)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Running Calories Result",
          text: `I burned ${result.totalCalories} calories running ${distance} ${unitSystem === "metric" ? "km" : "miles"} in ${duration} minutes! Calculate yours at CalcHub.`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setDistance("")
    setDuration("")
    setResult(null)
    setError("")
  }

  const formatPace = (pace: number): string => {
    const minutes = Math.floor(pace)
    const seconds = Math.round((pace - minutes) * 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Running Calories Calculator</CardTitle>
                    <CardDescription>Estimate calories burned while running</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Distance Input */}
                <div className="space-y-2">
                  <Label htmlFor="distance">Distance ({unitSystem === "metric" ? "km" : "miles"})</Label>
                  <Input
                    id="distance"
                    type="number"
                    placeholder={`Enter distance in ${unitSystem === "metric" ? "kilometers" : "miles"}`}
                    value={distance}
                    onChange={(e) => setDistance(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Duration Input */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Enter running time in minutes"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Terrain Selection */}
                <div className="space-y-2">
                  <Label htmlFor="terrain">Terrain Type</Label>
                  <Select value={terrain} onValueChange={(value: TerrainType) => setTerrain(value)}>
                    <SelectTrigger id="terrain">
                      <SelectValue placeholder="Select terrain" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="flat">Flat / Road</SelectItem>
                      <SelectItem value="hilly">Hilly / Incline</SelectItem>
                      <SelectItem value="trail">Trail / Off-road</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender (optional)</Label>
                  <Select value={gender} onValueChange={(value: Gender) => setGender(value)}>
                    <SelectTrigger id="gender">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCalories} className="w-full" size="lg">
                  Calculate Calories Burned
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Calories Burned</p>
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Flame className={`h-8 w-8 ${result.color}`} />
                        <p className={`text-5xl font-bold ${result.color}`}>{result.totalCalories}</p>
                      </div>
                      <p className="text-lg text-muted-foreground">kcal</p>
                      <p className={`text-sm font-semibold ${result.color} mt-2`}>{result.intensity} Intensity</p>
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Pace:</span>
                          <span className="font-medium">
                            {formatPace(result.pace)} min/{unitSystem === "metric" ? "km" : "mi"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Speed:</span>
                          <span className="font-medium">
                            {result.speed} {unitSystem === "metric" ? "km/h" : "mph"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            Calories per {unitSystem === "metric" ? "km" : "mile"}:
                          </span>
                          <span className="font-medium">{result.caloriesPerUnit} kcal</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">MET Value:</span>
                          <span className="font-medium">{result.metValue}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Terrain:</span>
                          <span className="font-medium capitalize">{terrain}</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Flame className="h-5 w-5 text-orange-500" />
                    MET Values by Speed
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-green-50">
                      <span>Light jog ({"<"} 6.4 km/h)</span>
                      <span className="font-medium">6.0 MET</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-green-50">
                      <span>Easy run (8 km/h)</span>
                      <span className="font-medium">8.3 MET</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-blue-50">
                      <span>Moderate (10 km/h)</span>
                      <span className="font-medium">9.8 MET</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-orange-50">
                      <span>Fast (12 km/h)</span>
                      <span className="font-medium">11.0 MET</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-red-50">
                      <span>Very fast (16 km/h)</span>
                      <span className="font-medium">12.8 MET</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-blue-500" />
                    Terrain Adjustments
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span>Flat / Road</span>
                      <span className="font-medium">Base MET (×1.0)</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span>Hilly / Incline</span>
                      <span className="font-medium">+15% (×1.15)</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span>Trail / Off-road</span>
                      <span className="font-medium">+25% (×1.25)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Timer className="h-5 w-5 text-purple-500" />
                    Calorie Formula
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      Calories = (MET × 3.5 × Weight kg) ÷ 200 × Minutes
                    </p>
                  </div>
                  <p>
                    MET (Metabolic Equivalent of Task) represents energy expenditure relative to rest. Running MET
                    values range from 6 (light jog) to 16+ (sprinting).
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Running Calorie Burn</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Running is one of the most efficient forms of cardiovascular exercise for burning calories. The number
                  of calories you burn while running depends on several key factors: your body weight, running speed,
                  duration, and the terrain you're running on. Heavier individuals burn more calories because they
                  require more energy to move their body mass, while faster paces increase the metabolic demand
                  significantly.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator uses MET (Metabolic Equivalent of Task) values, which are scientifically validated
                  measures of energy expenditure. Running MET values range from about 6 for light jogging to over 16 for
                  competitive sprinting. These values are then adjusted for terrain - running uphill or on trails
                  requires significantly more energy than flat road running due to increased muscle engagement and
                  balance demands.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Calorie Burn</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Body Weight</h4>
                    <p className="text-sm text-muted-foreground">
                      Heavier runners burn more calories per mile because more energy is required to move greater mass.
                      A 180 lb runner burns about 50% more than a 120 lb runner at the same pace.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Running Speed</h4>
                    <p className="text-sm text-muted-foreground">
                      Faster running increases calorie burn exponentially. Running at 10 km/h burns about 30% more
                      calories than jogging at 7 km/h for the same duration.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Terrain & Elevation</h4>
                    <p className="text-sm text-muted-foreground">
                      Running uphill or on uneven trails increases calorie burn by 15-25% compared to flat surfaces due
                      to increased muscle activation and balance requirements.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Running Efficiency</h4>
                    <p className="text-sm text-muted-foreground">
                      Experienced runners have more efficient form and may burn slightly fewer calories per mile than
                      beginners. Individual metabolism also plays a role.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Tips to Maximize Calorie Burn</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2 list-disc pl-5">
                  <li>
                    <strong>Interval Training:</strong> Alternating between high and low intensity burns more calories
                    than steady-state running and continues burning calories after your workout (EPOC effect).
                  </li>
                  <li>
                    <strong>Hill Running:</strong> Incorporate hills to increase calorie burn by 15-25% and build leg
                    strength simultaneously.
                  </li>
                  <li>
                    <strong>Longer Duration:</strong> While intensity matters, longer runs at moderate pace can burn
                    significant total calories and improve endurance.
                  </li>
                  <li>
                    <strong>Consistency:</strong> Regular running sessions build cardiovascular fitness, allowing you to
                    run faster and longer over time.
                  </li>
                  <li>
                    <strong>Proper Form:</strong> Efficient running form helps prevent injury and allows for longer,
                    more effective workouts.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Calories burned are estimates based on MET values and may vary depending on individual metabolism,
                      running form, weather conditions, and environmental factors. Actual calorie expenditure can differ
                      by 10-20% from calculated values. For precise measurements, consider using a heart rate monitor or
                      GPS running watch with calorie tracking.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
