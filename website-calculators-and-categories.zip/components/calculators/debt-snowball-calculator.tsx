"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  TrendingDown,
  Target,
  Plus,
  Trash2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface Debt {
  id: string
  name: string
  balance: string
  minPayment: string
  interestRate: string
}

interface DebtPayoffResult {
  totalDebt: number
  totalInterest: number
  monthsToPayoff: number
  payoffDate: string
  payoffOrder: {
    name: string
    balance: number
    months: number
    interest: number
    payoffDate: string
  }[]
  interestSaved: number
  monthlySchedule: {
    month: number
    date: string
    payments: { name: string; payment: number; remaining: number }[]
    totalPayment: number
    totalRemaining: number
  }[]
}

export function DebtSnowballCalculator() {
  const [debts, setDebts] = useState<Debt[]>([{ id: "1", name: "", balance: "", minPayment: "", interestRate: "" }])
  const [extraPayment, setExtraPayment] = useState("")
  const [result, setResult] = useState<DebtPayoffResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSchedule, setShowSchedule] = useState(false)

  const addDebt = () => {
    setDebts([...debts, { id: Date.now().toString(), name: "", balance: "", minPayment: "", interestRate: "" }])
  }

  const removeDebt = (id: string) => {
    if (debts.length > 1) {
      setDebts(debts.filter((d) => d.id !== id))
    }
  }

  const updateDebt = (id: string, field: keyof Debt, value: string) => {
    setDebts(debts.map((d) => (d.id === id ? { ...d, [field]: value } : d)))
  }

  const calculateSnowball = () => {
    setError("")
    setResult(null)

    // Validate debts
    const validDebts = debts.filter((d) => d.name && d.balance && d.minPayment && d.interestRate)

    if (validDebts.length === 0) {
      setError("Please enter at least one complete debt entry")
      return
    }

    for (const debt of validDebts) {
      const balance = Number.parseFloat(debt.balance)
      const minPayment = Number.parseFloat(debt.minPayment)
      const rate = Number.parseFloat(debt.interestRate)

      if (balance <= 0 || minPayment <= 0 || rate < 0) {
        setError("Balance and minimum payment must be positive. Interest rate must be non-negative.")
        return
      }

      // Check if minimum payment can cover interest
      const monthlyInterest = (balance * (rate / 100)) / 12
      if (minPayment <= monthlyInterest && rate > 0) {
        setError(`Minimum payment for "${debt.name}" is too low to cover monthly interest`)
        return
      }
    }

    const extra = Number.parseFloat(extraPayment) || 0
    if (extra < 0) {
      setError("Extra payment must be non-negative")
      return
    }

    // Sort debts by balance (smallest first) - Snowball method
    const sortedDebts = validDebts
      .map((d) => ({
        name: d.name,
        balance: Number.parseFloat(d.balance),
        minPayment: Number.parseFloat(d.minPayment),
        interestRate: Number.parseFloat(d.interestRate) / 100 / 12,
        originalBalance: Number.parseFloat(d.balance),
      }))
      .sort((a, b) => a.balance - b.balance)

    const totalDebt = sortedDebts.reduce((sum, d) => sum + d.balance, 0)
    let totalInterest = 0
    let month = 0
    const payoffOrder: DebtPayoffResult["payoffOrder"] = []
    const monthlySchedule: DebtPayoffResult["monthlySchedule"] = []
    const startDate = new Date()

    // Track each debt's progress
    const debtProgress = sortedDebts.map((d) => ({
      ...d,
      currentBalance: d.balance,
      totalInterest: 0,
      paidOff: false,
      payoffMonth: 0,
    }))

    // Calculate without extra payment for comparison
    let baselineInterest = 0
    const baselineDebts = sortedDebts.map((d) => ({ ...d, currentBalance: d.balance }))
    let baselineMonth = 0
    while (baselineDebts.some((d) => d.currentBalance > 0) && baselineMonth < 600) {
      baselineMonth++
      for (const debt of baselineDebts) {
        if (debt.currentBalance <= 0) continue
        const interest = debt.currentBalance * debt.interestRate
        baselineInterest += interest
        debt.currentBalance += interest
        const payment = Math.min(debt.minPayment, debt.currentBalance)
        debt.currentBalance -= payment
      }
    }

    // Calculate with snowball method
    const availableExtra = extra
    while (debtProgress.some((d) => !d.paidOff) && month < 600) {
      month++
      const currentDate = new Date(startDate)
      currentDate.setMonth(currentDate.getMonth() + month)

      const monthPayments: { name: string; payment: number; remaining: number }[] = []
      let totalMonthPayment = 0

      // Apply interest to all unpaid debts
      for (const debt of debtProgress) {
        if (debt.paidOff) continue
        const interest = debt.currentBalance * debt.interestRate
        debt.totalInterest += interest
        totalInterest += interest
        debt.currentBalance += interest
      }

      // Find the smallest unpaid debt
      const targetDebt = debtProgress.find((d) => !d.paidOff)

      // Pay minimum on all debts except the target
      for (const debt of debtProgress) {
        if (debt.paidOff) continue
        if (debt === targetDebt) continue

        const payment = Math.min(debt.minPayment, debt.currentBalance)
        debt.currentBalance -= payment
        totalMonthPayment += payment

        monthPayments.push({
          name: debt.name,
          payment: Math.round(payment * 100) / 100,
          remaining: Math.round(debt.currentBalance * 100) / 100,
        })

        if (debt.currentBalance <= 0.01) {
          debt.currentBalance = 0
          debt.paidOff = true
          debt.payoffMonth = month
          const payoffDate = new Date(startDate)
          payoffDate.setMonth(payoffDate.getMonth() + month)
          payoffOrder.push({
            name: debt.name,
            balance: debt.originalBalance,
            months: month,
            interest: Math.round(debt.totalInterest * 100) / 100,
            payoffDate: payoffDate.toLocaleDateString("en-US", { month: "short", year: "numeric" }),
          })
        }
      }

      // Pay target debt with minimum + freed payments + extra
      if (targetDebt && !targetDebt.paidOff) {
        const freedPayments = debtProgress
          .filter((d) => d.paidOff && d.payoffMonth < month)
          .reduce((sum, d) => sum + d.minPayment, 0)

        const totalPayment = Math.min(targetDebt.minPayment + freedPayments + availableExtra, targetDebt.currentBalance)

        targetDebt.currentBalance -= totalPayment
        totalMonthPayment += totalPayment

        monthPayments.unshift({
          name: targetDebt.name,
          payment: Math.round(totalPayment * 100) / 100,
          remaining: Math.round(Math.max(0, targetDebt.currentBalance) * 100) / 100,
        })

        if (targetDebt.currentBalance <= 0.01) {
          targetDebt.currentBalance = 0
          targetDebt.paidOff = true
          targetDebt.payoffMonth = month
          const payoffDate = new Date(startDate)
          payoffDate.setMonth(payoffDate.getMonth() + month)
          payoffOrder.push({
            name: targetDebt.name,
            balance: targetDebt.originalBalance,
            months: month,
            interest: Math.round(targetDebt.totalInterest * 100) / 100,
            payoffDate: payoffDate.toLocaleDateString("en-US", { month: "short", year: "numeric" }),
          })
        }
      }

      monthlySchedule.push({
        month,
        date: currentDate.toLocaleDateString("en-US", { month: "short", year: "numeric" }),
        payments: monthPayments,
        totalPayment: Math.round(totalMonthPayment * 100) / 100,
        totalRemaining: Math.round(debtProgress.reduce((sum, d) => sum + d.currentBalance, 0) * 100) / 100,
      })
    }

    const payoffDate = new Date(startDate)
    payoffDate.setMonth(payoffDate.getMonth() + month)

    setResult({
      totalDebt: Math.round(totalDebt * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
      monthsToPayoff: month,
      payoffDate: payoffDate.toLocaleDateString("en-US", { month: "long", year: "numeric" }),
      payoffOrder,
      interestSaved: Math.round((baselineInterest - totalInterest) * 100) / 100,
      monthlySchedule,
    })
  }

  const handleReset = () => {
    setDebts([{ id: "1", name: "", balance: "", minPayment: "", interestRate: "" }])
    setExtraPayment("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSchedule(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Debt Snowball Plan:\nTotal Debt: $${result.totalDebt.toLocaleString()}\nPayoff Time: ${result.monthsToPayoff} months\nTotal Interest: $${result.totalInterest.toLocaleString()}\nInterest Saved: $${result.interestSaved.toLocaleString()}\nDebt-Free Date: ${result.payoffDate}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Debt Snowball Plan",
          text: `I'm using the Debt Snowball method to pay off $${result.totalDebt.toLocaleString()} in ${result.monthsToPayoff} months!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingDown className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Debt Snowball Calculator</CardTitle>
                    <CardDescription>Pay off debts smallest to largest</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Debts List */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Your Debts</Label>
                    <Button variant="outline" size="sm" onClick={addDebt}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Debt
                    </Button>
                  </div>

                  {debts.map((debt, index) => (
                    <div key={debt.id} className="p-4 border rounded-lg space-y-3 bg-muted/30">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-muted-foreground">Debt #{index + 1}</span>
                        {debts.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeDebt(debt.id)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Input
                          placeholder="Debt name (e.g., Credit Card)"
                          value={debt.name}
                          onChange={(e) => updateDebt(debt.id, "name", e.target.value)}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs">Balance ($)</Label>
                          <Input
                            type="number"
                            placeholder="5000"
                            value={debt.balance}
                            onChange={(e) => updateDebt(debt.id, "balance", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Min Payment ($)</Label>
                          <Input
                            type="number"
                            placeholder="100"
                            value={debt.minPayment}
                            onChange={(e) => updateDebt(debt.id, "minPayment", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Interest (%)</Label>
                          <Input
                            type="number"
                            placeholder="18"
                            value={debt.interestRate}
                            onChange={(e) => updateDebt(debt.id, "interestRate", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Extra Payment */}
                <div className="space-y-2">
                  <Label htmlFor="extraPayment">Monthly Extra Payment ($)</Label>
                  <Input
                    id="extraPayment"
                    type="number"
                    placeholder="Enter extra amount you can pay monthly"
                    value={extraPayment}
                    onChange={(e) => setExtraPayment(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSnowball} className="w-full" size="lg">
                  Calculate Payoff Plan
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Debt-Free Date</p>
                      <p className="text-3xl font-bold text-green-600 mb-1">{result.payoffDate}</p>
                      <p className="text-sm text-muted-foreground">
                        {result.monthsToPayoff} months ({Math.floor(result.monthsToPayoff / 12)} years{" "}
                        {result.monthsToPayoff % 12} months)
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Debt</p>
                        <p className="text-lg font-semibold">{formatCurrency(result.totalDebt)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Interest</p>
                        <p className="text-lg font-semibold">{formatCurrency(result.totalInterest)}</p>
                      </div>
                    </div>

                    {result.interestSaved > 0 && (
                      <div className="p-3 bg-emerald-100 border border-emerald-200 rounded-lg text-center mb-4">
                        <p className="text-xs text-emerald-700">Interest Saved with Extra Payments</p>
                        <p className="text-xl font-bold text-emerald-600">{formatCurrency(result.interestSaved)}</p>
                      </div>
                    )}

                    {/* Payoff Order */}
                    <div className="mb-4">
                      <p className="text-sm font-semibold mb-2">Payoff Order:</p>
                      <div className="space-y-2">
                        {result.payoffOrder.map((debt, index) => (
                          <div
                            key={debt.name}
                            className="flex items-center justify-between p-2 bg-white rounded-lg text-sm"
                          >
                            <div className="flex items-center gap-2">
                              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-700 text-xs font-bold">
                                {index + 1}
                              </span>
                              <span className="font-medium">{debt.name}</span>
                            </div>
                            <div className="text-right">
                              <span className="text-muted-foreground">{debt.payoffDate}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Monthly Schedule Toggle */}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowSchedule(!showSchedule)}
                      className="w-full mb-3"
                    >
                      {showSchedule ? (
                        <>
                          <ChevronUp className="h-4 w-4 mr-1" />
                          Hide Monthly Schedule
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4 mr-1" />
                          Show Monthly Schedule
                        </>
                      )}
                    </Button>

                    {showSchedule && (
                      <div className="max-h-64 overflow-y-auto border rounded-lg">
                        <table className="w-full text-xs">
                          <thead className="bg-muted sticky top-0">
                            <tr>
                              <th className="p-2 text-left">Month</th>
                              <th className="p-2 text-right">Payment</th>
                              <th className="p-2 text-right">Remaining</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.monthlySchedule.slice(0, 60).map((row) => (
                              <tr key={row.month} className="border-t">
                                <td className="p-2">{row.date}</td>
                                <td className="p-2 text-right">{formatCurrency(row.totalPayment)}</td>
                                <td className="p-2 text-right">{formatCurrency(row.totalRemaining)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How the Snowball Method Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-bold shrink-0">
                        1
                      </span>
                      <div>
                        <span className="font-medium text-blue-700">List all debts</span>
                        <p className="text-xs text-blue-600">Gather all debts with balances, rates, and minimums</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-green-600 text-white text-xs font-bold shrink-0">
                        2
                      </span>
                      <div>
                        <span className="font-medium text-green-700">Order smallest to largest</span>
                        <p className="text-xs text-green-600">Sort debts by balance, not interest rate</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-yellow-600 text-white text-xs font-bold shrink-0">
                        3
                      </span>
                      <div>
                        <span className="font-medium text-yellow-700">Attack the smallest debt</span>
                        <p className="text-xs text-yellow-600">Pay minimums on all, extra on smallest</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-purple-600 text-white text-xs font-bold shrink-0">
                        4
                      </span>
                      <div>
                        <span className="font-medium text-purple-700">Roll over payments</span>
                        <p className="text-xs text-purple-600">When paid, add that payment to the next debt</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Snowball vs Avalanche</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Debt Snowball</p>
                    <p>
                      Focuses on smallest balances first for quick wins and psychological momentum. May pay more
                      interest overall but builds motivation.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Debt Avalanche</p>
                    <p>
                      Focuses on highest interest rates first for mathematical optimization. Saves the most money but
                      may take longer to see progress.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Debt Snowball Method?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Debt Snowball Method is a debt reduction strategy popularized by personal finance expert Dave
                  Ramsey. This approach focuses on paying off debts from smallest to largest balance, regardless of
                  interest rate. The idea is to build momentum and motivation by achieving quick wins early in the
                  process. When you pay off a smaller debt, you gain psychological satisfaction and confidence that
                  keeps you motivated to continue tackling larger debts.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The method gets its name from the way a snowball grows as it rolls downhill. As you pay off each debt,
                  the payment amount you were making on that debt gets "rolled over" to the next debt on your list,
                  creating an increasingly larger payment that accelerates debt payoff. This snowball effect becomes
                  more powerful as you eliminate each debt, eventually helping you become completely debt-free.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Start by entering all your debts, including credit cards, personal loans, car loans, student loans,
                  and any other outstanding balances. For each debt, you'll need to provide the current balance, the
                  minimum monthly payment required, and the annual interest rate. The calculator will automatically sort
                  your debts from smallest to largest balance following the snowball method.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Next, enter any extra amount you can contribute toward debt repayment each month. Even a small extra
                  payment of $50-100 per month can significantly reduce your payoff time and total interest paid. The
                  calculator will show you exactly when each debt will be paid off, the total interest you'll pay, and
                  how much you'll save compared to making minimum payments only.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Debt Payoff Success</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Consistency is key when using the debt snowball method. Make your payments on time every month and
                  resist the temptation to skip payments or use credit cards for new purchases. Consider automating your
                  payments to ensure you never miss a due date. Building an emergency fund alongside your debt payoff
                  plan can help prevent new debt from unexpected expenses.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Look for ways to increase your income or reduce expenses to accelerate your debt payoff. Side gigs,
                  selling unused items, or cutting subscription services can all provide extra money to throw at your
                  debt. Celebrate each payoff milestone to maintain motivation, but avoid rewarding yourself with
                  purchases that could lead to new debt. Stay focused on your debt-free goal and visualize the financial
                  freedom you're working toward.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Debt snowball calculations are estimates and may vary based on interest rate changes, missed payments,
                  or additional charges. This calculator is for educational purposes and should not be considered
                  financial advice. Actual payoff times and interest amounts may differ from projections. Consult a
                  qualified financial advisor for personalized debt management advice tailored to your specific
                  situation.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
