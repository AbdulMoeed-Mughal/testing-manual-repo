"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Scale,
  Info,
  AlertTriangle,
  TrendingUp,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
  Trophy,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface LoanOption {
  id: string
  name: string
  principal: string
  rate: string
  term: string
  termUnit: "years" | "months"
}

interface ComparisonResult {
  options: {
    id: string
    name: string
    principal: number
    rate: number
    term: number
    monthlyPayment: number
    totalPayment: number
    totalInterest: number
    rank: number
  }[]
  bestOption: string
  worstOption: string
  potentialSavings: number
}

export function InterestRateComparisonCalculator() {
  const [options, setOptions] = useState<LoanOption[]>([
    { id: "1", name: "Option A", principal: "", rate: "", term: "", termUnit: "years" },
    { id: "2", name: "Option B", principal: "", rate: "", term: "", termUnit: "years" },
  ])
  const [result, setResult] = useState<ComparisonResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const addOption = () => {
    const newId = String(options.length + 1)
    const letters = "ABCDEFGHIJ"
    setOptions([
      ...options,
      {
        id: newId,
        name: `Option ${letters[options.length] || newId}`,
        principal: "",
        rate: "",
        term: "",
        termUnit: "years",
      },
    ])
  }

  const removeOption = (id: string) => {
    if (options.length > 2) {
      setOptions(options.filter((opt) => opt.id !== id))
    }
  }

  const updateOption = (id: string, field: keyof LoanOption, value: string) => {
    setOptions(options.map((opt) => (opt.id === id ? { ...opt, [field]: value } : opt)))
  }

  const calculateComparison = () => {
    setError("")
    setResult(null)

    const calculatedOptions: ComparisonResult["options"] = []

    for (const opt of options) {
      const principal = Number.parseFloat(opt.principal)
      const rate = Number.parseFloat(opt.rate)
      const term = Number.parseFloat(opt.term)

      if (isNaN(principal) || principal <= 0) {
        setError(`Please enter a valid principal for ${opt.name}`)
        return
      }
      if (isNaN(rate) || rate <= 0 || rate > 100) {
        setError(`Please enter a valid interest rate for ${opt.name}`)
        return
      }
      if (isNaN(term) || term <= 0) {
        setError(`Please enter a valid term for ${opt.name}`)
        return
      }

      // Convert to months if needed
      const termMonths = opt.termUnit === "years" ? term * 12 : term

      // Calculate monthly payment
      const monthlyRate = rate / 100 / 12
      const monthlyPayment =
        (principal * (monthlyRate * Math.pow(1 + monthlyRate, termMonths))) /
        (Math.pow(1 + monthlyRate, termMonths) - 1)

      const totalPayment = monthlyPayment * termMonths
      const totalInterest = totalPayment - principal

      calculatedOptions.push({
        id: opt.id,
        name: opt.name,
        principal,
        rate,
        term: termMonths,
        monthlyPayment: Math.round(monthlyPayment * 100) / 100,
        totalPayment: Math.round(totalPayment * 100) / 100,
        totalInterest: Math.round(totalInterest * 100) / 100,
        rank: 0,
      })
    }

    // Rank by total interest (lowest is best)
    calculatedOptions.sort((a, b) => a.totalInterest - b.totalInterest)
    calculatedOptions.forEach((opt, index) => {
      opt.rank = index + 1
    })

    const bestOption = calculatedOptions[0].name
    const worstOption = calculatedOptions[calculatedOptions.length - 1].name
    const potentialSavings =
      calculatedOptions[calculatedOptions.length - 1].totalInterest - calculatedOptions[0].totalInterest

    setResult({
      options: calculatedOptions,
      bestOption,
      worstOption,
      potentialSavings: Math.round(potentialSavings * 100) / 100,
    })
  }

  const handleReset = () => {
    setOptions([
      { id: "1", name: "Option A", principal: "", rate: "", term: "", termUnit: "years" },
      { id: "2", name: "Option B", principal: "", rate: "", term: "", termUnit: "years" },
    ])
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Best Option: ${result.bestOption} - Potential Savings: $${result.potentialSavings.toLocaleString()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Interest Rate Comparison",
          text: `Best Option: ${result.bestOption} - Potential Savings: $${result.potentialSavings.toLocaleString()}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Interest Rate Comparison</CardTitle>
                    <CardDescription>Compare loan options to find the best deal</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Loan Options */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Loan Options</Label>
                    {options.length < 5 && (
                      <Button variant="outline" size="sm" onClick={addOption}>
                        <Plus className="h-4 w-4 mr-1" />
                        Add Option
                      </Button>
                    )}
                  </div>

                  {options.map((opt) => (
                    <div key={opt.id} className="p-3 rounded-lg border bg-muted/30 space-y-3">
                      <div className="flex items-center justify-between">
                        <Input
                          value={opt.name}
                          onChange={(e) => updateOption(opt.id, "name", e.target.value)}
                          className="w-32 h-8 text-sm font-medium"
                          placeholder="Option name"
                        />
                        {options.length > 2 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeOption(opt.id)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs">Principal ($)</Label>
                          <Input
                            type="number"
                            placeholder="100000"
                            value={opt.principal}
                            onChange={(e) => updateOption(opt.id, "principal", e.target.value)}
                            min="0"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Rate (%)</Label>
                          <Input
                            type="number"
                            placeholder="6.5"
                            value={opt.rate}
                            onChange={(e) => updateOption(opt.id, "rate", e.target.value)}
                            min="0"
                            max="100"
                            step="0.1"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Term</Label>
                          <div className="flex gap-1">
                            <Input
                              type="number"
                              placeholder="30"
                              value={opt.term}
                              onChange={(e) => updateOption(opt.id, "term", e.target.value)}
                              min="0"
                              className="w-16"
                            />
                            <Select value={opt.termUnit} onValueChange={(v) => updateOption(opt.id, "termUnit", v)}>
                              <SelectTrigger className="w-16">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="years">Yr</SelectItem>
                                <SelectItem value="months">Mo</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateComparison} className="w-full" size="lg">
                  Compare Options
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Trophy className="h-6 w-6 text-yellow-500" />
                        <p className="text-sm text-muted-foreground">Best Option</p>
                      </div>
                      <p className="text-3xl font-bold text-green-600">{result.bestOption}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Save up to{" "}
                        <span className="font-semibold text-green-600">{formatCurrency(result.potentialSavings)}</span>{" "}
                        in interest
                      </p>
                    </div>

                    {/* Comparison Table */}
                    <div className="rounded-lg border overflow-hidden bg-white">
                      <table className="w-full text-xs">
                        <thead className="bg-muted">
                          <tr>
                            <th className="p-2 text-left">Rank</th>
                            <th className="p-2 text-left">Option</th>
                            <th className="p-2 text-right">Monthly</th>
                            <th className="p-2 text-right">Interest</th>
                          </tr>
                        </thead>
                        <tbody>
                          {result.options.map((opt) => (
                            <tr key={opt.id} className={`border-t ${opt.rank === 1 ? "bg-green-50" : ""}`}>
                              <td className="p-2">
                                {opt.rank === 1 && <Trophy className="h-4 w-4 text-yellow-500 inline mr-1" />}#
                                {opt.rank}
                              </td>
                              <td className="p-2 font-medium">{opt.name}</td>
                              <td className="p-2 text-right">{formatCurrency(opt.monthlyPayment)}</td>
                              <td className="p-2 text-right">{formatCurrency(opt.totalInterest)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Detailed Breakdown */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails} className="mt-3">
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full bg-transparent">
                          {showDetails ? "Hide" : "Show"} Detailed Breakdown
                          {showDetails ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2">
                        {result.options.map((opt) => (
                          <div key={opt.id} className="p-3 bg-white rounded-lg text-sm">
                            <p className="font-medium mb-2">{opt.name}</p>
                            <div className="grid grid-cols-2 gap-2 text-xs">
                              <div>
                                <p className="text-muted-foreground">Principal</p>
                                <p className="font-medium">{formatCurrency(opt.principal)}</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Rate</p>
                                <p className="font-medium">{opt.rate}%</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Term</p>
                                <p className="font-medium">{opt.term} months</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Total Payment</p>
                                <p className="font-medium">{formatCurrency(opt.totalPayment)}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">What to Compare</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-600 text-white text-xs font-bold">
                        1
                      </div>
                      <div>
                        <p className="font-medium text-green-700">Interest Rate</p>
                        <p className="text-sm text-green-600">Lower rates mean less total interest</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-bold">
                        2
                      </div>
                      <div>
                        <p className="font-medium text-blue-700">Loan Term</p>
                        <p className="text-sm text-blue-600">Shorter terms = less interest, higher payments</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-purple-600 text-white text-xs font-bold">
                        3
                      </div>
                      <div>
                        <p className="font-medium text-purple-700">Total Cost</p>
                        <p className="text-sm text-purple-600">Consider fees and total interest paid</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Monthly Payment Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">M = P × [r(1+r)ⁿ] / [(1+r)ⁿ - 1]</p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>M</strong> = Monthly payment
                    </p>
                    <p>
                      <strong>P</strong> = Principal (loan amount)
                    </p>
                    <p>
                      <strong>r</strong> = Monthly interest rate
                    </p>
                    <p>
                      <strong>n</strong> = Total number of payments
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Why Compare Interest Rates?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Even a small difference in interest rates can result in significant savings over the life of a loan.
                  For example, on a $200,000 mortgage, a 0.5% rate difference could save you over $20,000 in interest
                  over 30 years. This calculator helps you compare multiple loan options side by side to identify the
                  most cost-effective choice.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Getting Better Rates</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground leading-relaxed space-y-2 list-disc list-inside">
                  <li>Improve your credit score before applying</li>
                  <li>Shop around and get quotes from multiple lenders</li>
                  <li>Consider shorter loan terms for lower rates</li>
                  <li>Make a larger down payment if possible</li>
                  <li>Look into points to buy down your rate</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Interest rate comparisons are estimates based on entered values. Actual costs may vary based on fees,
                  points, closing costs, and other factors not included in this calculation. Always review the complete
                  loan terms and consult a financial advisor before making lending decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
