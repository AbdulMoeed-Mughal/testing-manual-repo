"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Ratio, Info, AlertTriangle, Plus, Minus, Scale } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type OperationType = "simplify" | "equivalent" | "scale" | "compare"

interface RatioResult {
  originalRatio: string
  simplifiedRatio: string
  equivalentRatios?: string[]
  scaledRatio?: string
  scaleFactor?: number
  gcd?: number
  comparison?: string
  steps: string[]
}

export function RatioCalculator() {
  const [operation, setOperation] = useState<OperationType>("simplify")
  const [values, setValues] = useState<string[]>(["", ""])
  const [scaleFactor, setScaleFactor] = useState("")
  const [targetValue, setTargetValue] = useState("")
  const [targetIndex, setTargetIndex] = useState(0)
  const [compareValues, setCompareValues] = useState<string[]>(["", ""])
  const [result, setResult] = useState<RatioResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const gcd = (a: number, b: number): number => {
    a = Math.abs(Math.round(a))
    b = Math.abs(Math.round(b))
    while (b) {
      const t = b
      b = a % b
      a = t
    }
    return a
  }

  const gcdArray = (arr: number[]): number => {
    return arr.reduce((acc, val) => gcd(acc, val))
  }

  const calculateRatio = () => {
    setError("")
    setResult(null)

    const nums = values.map((v) => Number.parseFloat(v)).filter((n) => !isNaN(n) && n > 0)

    if (nums.length < 2) {
      setError("Please enter at least 2 positive values for the ratio")
      return
    }

    const steps: string[] = []
    const originalRatio = nums.join(" : ")

    if (operation === "simplify") {
      steps.push(`Original ratio: ${originalRatio}`)

      // Convert decimals to integers by finding common multiplier
      const maxDecimals = Math.max(...nums.map((n) => (n.toString().split(".")[1] || "").length))
      const multiplier = Math.pow(10, maxDecimals)
      const integers = nums.map((n) => Math.round(n * multiplier))

      if (maxDecimals > 0) {
        steps.push(`Multiply all values by ${multiplier} to remove decimals: ${integers.join(" : ")}`)
      }

      const commonGcd = gcdArray(integers)
      steps.push(`Find GCD of all values: ${commonGcd}`)

      const simplified = integers.map((n) => n / commonGcd)
      steps.push(`Divide all values by GCD: ${simplified.join(" : ")}`)

      setResult({
        originalRatio,
        simplifiedRatio: simplified.join(" : "),
        gcd: commonGcd,
        steps,
      })
    } else if (operation === "equivalent") {
      const factor = Number.parseFloat(scaleFactor)
      if (isNaN(factor) || factor <= 0) {
        setError("Please enter a valid positive scale factor")
        return
      }

      steps.push(`Original ratio: ${originalRatio}`)
      steps.push(`Scale factor: ${factor}`)

      const scaled = nums.map((n) => Math.round(n * factor * 1000) / 1000)
      steps.push(`Multiply each value by ${factor}: ${scaled.join(" : ")}`)

      // Generate a few equivalent ratios
      const equivalentRatios: string[] = []
      for (let i = 2; i <= 5; i++) {
        equivalentRatios.push(nums.map((n) => Math.round(n * i * 1000) / 1000).join(" : "))
      }

      setResult({
        originalRatio,
        simplifiedRatio: originalRatio,
        scaledRatio: scaled.join(" : "),
        scaleFactor: factor,
        equivalentRatios,
        steps,
      })
    } else if (operation === "scale") {
      const target = Number.parseFloat(targetValue)
      if (isNaN(target) || target <= 0) {
        setError("Please enter a valid positive target value")
        return
      }

      if (targetIndex >= nums.length) {
        setError("Invalid target position")
        return
      }

      steps.push(`Original ratio: ${originalRatio}`)
      steps.push(`Target: Position ${targetIndex + 1} should equal ${target}`)

      const currentValue = nums[targetIndex]
      const factor = target / currentValue
      steps.push(`Calculate scale factor: ${target} ÷ ${currentValue} = ${factor.toFixed(4)}`)

      const scaled = nums.map((n) => Math.round(n * factor * 1000) / 1000)
      steps.push(`Apply scale factor to all values: ${scaled.join(" : ")}`)

      setResult({
        originalRatio,
        simplifiedRatio: originalRatio,
        scaledRatio: scaled.join(" : "),
        scaleFactor: Math.round(factor * 1000) / 1000,
        steps,
      })
    } else if (operation === "compare") {
      const compareNums = compareValues.map((v) => Number.parseFloat(v)).filter((n) => !isNaN(n) && n > 0)

      if (compareNums.length !== 2) {
        setError("Please enter 2 positive values for the comparison ratio")
        return
      }

      if (nums.length !== 2) {
        setError("Please enter exactly 2 values for the first ratio to compare")
        return
      }

      steps.push(`First ratio: ${nums[0]} : ${nums[1]}`)
      steps.push(`Second ratio: ${compareNums[0]} : ${compareNums[1]}`)

      // Cross multiply to compare
      const cross1 = nums[0] * compareNums[1]
      const cross2 = nums[1] * compareNums[0]
      steps.push(`Cross multiply: ${nums[0]} × ${compareNums[1]} = ${cross1}`)
      steps.push(`Cross multiply: ${nums[1]} × ${compareNums[0]} = ${cross2}`)

      let comparison: string
      if (Math.abs(cross1 - cross2) < 0.0001) {
        comparison = "The ratios are equal"
      } else if (cross1 > cross2) {
        comparison = `${nums[0]}:${nums[1]} > ${compareNums[0]}:${compareNums[1]}`
      } else {
        comparison = `${nums[0]}:${nums[1]} < ${compareNums[0]}:${compareNums[1]}`
      }
      steps.push(`Result: ${comparison}`)

      setResult({
        originalRatio,
        simplifiedRatio: originalRatio,
        comparison,
        steps,
      })
    }
  }

  const handleReset = () => {
    setValues(["", ""])
    setScaleFactor("")
    setTargetValue("")
    setTargetIndex(0)
    setCompareValues(["", ""])
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        operation === "simplify"
          ? `Simplified ratio: ${result.simplifiedRatio}`
          : operation === "scale" || operation === "equivalent"
            ? `Scaled ratio: ${result.scaledRatio}`
            : `Comparison: ${result.comparison}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Ratio Calculator Result",
          text: `Original: ${result.originalRatio} | Result: ${result.simplifiedRatio || result.scaledRatio || result.comparison}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const addValue = () => {
    if (values.length < 6) {
      setValues([...values, ""])
    }
  }

  const removeValue = (index: number) => {
    if (values.length > 2) {
      setValues(values.filter((_, i) => i !== index))
    }
  }

  const updateValue = (index: number, value: string) => {
    const newValues = [...values]
    newValues[index] = value
    setValues(newValues)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Ratio className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Ratio Calculator</CardTitle>
                    <CardDescription>Calculate, simplify, and scale ratios</CardDescription>
                  </div>
                </div>

                {/* Operation Toggle */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Operation</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "simplify", label: "Simplify" },
                      { value: "equivalent", label: "Equivalent" },
                      { value: "scale", label: "Scale" },
                      { value: "compare", label: "Compare" },
                    ].map((op) => (
                      <button
                        key={op.value}
                        onClick={() => {
                          setOperation(op.value as OperationType)
                          setResult(null)
                          setError("")
                        }}
                        className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                          operation === op.value
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {op.label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Ratio Values */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Ratio Values</Label>
                    {operation !== "compare" && values.length < 6 && (
                      <Button variant="ghost" size="sm" onClick={addValue} className="h-7 text-xs">
                        <Plus className="h-3 w-3 mr-1" />
                        Add
                      </Button>
                    )}
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {values.map((value, index) => (
                      <div key={index} className="flex items-center gap-1">
                        <Input
                          type="number"
                          placeholder={`Value ${index + 1}`}
                          value={value}
                          onChange={(e) => updateValue(index, e.target.value)}
                          className="w-20"
                          min="0"
                          step="any"
                        />
                        {index < values.length - 1 && <span className="text-muted-foreground font-bold">:</span>}
                        {values.length > 2 && index === values.length - 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeValue(index)}
                            className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Operation-specific inputs */}
                {operation === "equivalent" && (
                  <div className="space-y-2">
                    <Label htmlFor="scaleFactor">Scale Factor</Label>
                    <Input
                      id="scaleFactor"
                      type="number"
                      placeholder="Enter scale factor (e.g., 2, 3, 0.5)"
                      value={scaleFactor}
                      onChange={(e) => setScaleFactor(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {operation === "scale" && (
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Label>Scale which position?</Label>
                      <div className="flex gap-2">
                        {values.map((_, index) => (
                          <button
                            key={index}
                            onClick={() => setTargetIndex(index)}
                            className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
                              targetIndex === index
                                ? "bg-primary text-primary-foreground"
                                : "bg-muted text-muted-foreground hover:bg-muted/80"
                            }`}
                          >
                            Position {index + 1}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="targetValue">Target Value</Label>
                      <Input
                        id="targetValue"
                        type="number"
                        placeholder="Enter target value for selected position"
                        value={targetValue}
                        onChange={(e) => setTargetValue(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </div>
                )}

                {operation === "compare" && (
                  <div className="space-y-2">
                    <Label>Compare with Ratio</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        placeholder="Value 1"
                        value={compareValues[0]}
                        onChange={(e) => setCompareValues([e.target.value, compareValues[1]])}
                        className="w-24"
                        min="0"
                        step="any"
                      />
                      <span className="text-muted-foreground font-bold">:</span>
                      <Input
                        type="number"
                        placeholder="Value 2"
                        value={compareValues[1]}
                        onChange={(e) => setCompareValues([compareValues[0], e.target.value])}
                        className="w-24"
                        min="0"
                        step="any"
                      />
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRatio} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <p className="text-sm text-muted-foreground">Original Ratio</p>
                      <p className="text-xl font-semibold text-foreground">{result.originalRatio}</p>

                      {operation === "simplify" && (
                        <>
                          <div className="h-px bg-blue-200 my-3" />
                          <p className="text-sm text-muted-foreground">Simplified Ratio</p>
                          <p className="text-4xl font-bold text-blue-600">{result.simplifiedRatio}</p>
                          {result.gcd && result.gcd > 1 && (
                            <p className="text-sm text-muted-foreground">GCD: {result.gcd}</p>
                          )}
                        </>
                      )}

                      {(operation === "equivalent" || operation === "scale") && result.scaledRatio && (
                        <>
                          <div className="h-px bg-blue-200 my-3" />
                          <p className="text-sm text-muted-foreground">Scaled Ratio</p>
                          <p className="text-4xl font-bold text-blue-600">{result.scaledRatio}</p>
                          {result.scaleFactor && (
                            <p className="text-sm text-muted-foreground">Scale Factor: {result.scaleFactor}</p>
                          )}
                        </>
                      )}

                      {operation === "equivalent" && result.equivalentRatios && (
                        <div className="mt-4 p-3 bg-white/50 rounded-lg">
                          <p className="text-sm font-medium text-muted-foreground mb-2">More Equivalent Ratios:</p>
                          <div className="flex flex-wrap gap-2 justify-center">
                            {result.equivalentRatios.map((ratio, i) => (
                              <span key={i} className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-sm">
                                {ratio}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {operation === "compare" && result.comparison && (
                        <>
                          <div className="h-px bg-blue-200 my-3" />
                          <p className="text-sm text-muted-foreground">Comparison Result</p>
                          <p className="text-2xl font-bold text-blue-600">{result.comparison}</p>
                        </>
                      )}
                    </div>

                    {/* Steps */}
                    {result.steps.length > 0 && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg">
                        <p className="text-sm font-medium text-muted-foreground mb-2">Solution Steps:</p>
                        <ol className="text-sm text-muted-foreground space-y-1">
                          {result.steps.map((step, i) => (
                            <li key={i} className="flex gap-2">
                              <span className="text-blue-600 font-medium">{i + 1}.</span>
                              {step}
                            </li>
                          ))}
                        </ol>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Operations Guide</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <span className="font-medium text-blue-700">Simplify</span>
                    <p className="text-sm text-blue-600 mt-1">Reduce ratio to its lowest terms by dividing by GCD</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <span className="font-medium text-green-700">Equivalent</span>
                    <p className="text-sm text-green-600 mt-1">
                      Multiply all values by a factor to find equivalent ratios
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <span className="font-medium text-purple-700">Scale</span>
                    <p className="text-sm text-purple-600 mt-1">
                      Scale ratio so one value equals a specific target number
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <span className="font-medium text-orange-700">Compare</span>
                    <p className="text-sm text-orange-600 mt-1">Compare two ratios using cross-multiplication method</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Simplify 12:18:24</p>
                    <p>GCD = 6 → Result: 2:3:4</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Scale 2:3 where first = 10</p>
                    <p>Factor = 5 → Result: 10:15</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Compare 3:4 vs 6:8</p>
                    <p>Cross multiply: 24 = 24 → Equal</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium">Disclaimer</p>
                      <p className="mt-1">
                        This calculator provides estimates only. Verify manually for critical calculations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Ratio?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A ratio is a mathematical expression that compares two or more quantities, showing the relative size
                  of one quantity to another. Ratios are fundamental to mathematics and appear throughout daily life,
                  from recipes and maps to financial calculations and scientific measurements. They are typically
                  written with a colon (like 2:3) or as a fraction (2/3), expressing how many times one quantity
                  contains or is contained within another.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding ratios is essential because they help us make comparisons without using specific units.
                  For example, a ratio of 3:1 means that for every 3 units of one quantity, there is 1 unit of another,
                  regardless of whether we're measuring in grams, meters, or dollars. This makes ratios incredibly
                  versatile for scaling recipes, mixing solutions, calculating proportions, and solving real-world
                  problems across various fields.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Simplifying Ratios</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Simplifying a ratio means reducing it to its smallest whole number form while maintaining the same
                  relationship between values. This is done by finding the Greatest Common Divisor (GCD) of all the
                  numbers in the ratio and dividing each term by it. For example, the ratio 12:18 can be simplified to
                  2:3 by dividing both numbers by their GCD of 6.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Simplified ratios are easier to understand and work with. They provide a clearer picture of the
                  relationship between quantities. When dealing with decimal ratios, the first step is to multiply all
                  terms by a power of 10 to convert them to whole numbers, then find the GCD. For instance, 0.5:1.5
                  becomes 5:15 when multiplied by 10, which simplifies to 1:3.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ratio className="h-5 w-5 text-primary" />
                  <CardTitle>Equivalent Ratios and Scaling</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Equivalent ratios are different ratios that express the same relationship. They are created by
                  multiplying or dividing all terms of a ratio by the same non-zero number. For example, 2:3 is
                  equivalent to 4:6, 6:9, and 8:12. This concept is crucial for scaling recipes, resizing images,
                  creating proportional mixtures, and solving proportion problems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Scaling a ratio to a specific value uses cross-multiplication. If you have a ratio of 2:5 and need the
                  first value to equal 10, you calculate the scale factor (10 ÷ 2 = 5) and apply it to all terms,
                  resulting in 10:25. This technique is invaluable in real-world applications like adjusting recipe
                  quantities, calculating material requirements for construction, or determining dosages in medicine.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ratios are used extensively in cooking (recipe scaling), finance (debt-to-income ratios), science
                  (concentration ratios), engineering (gear ratios), and art (aspect ratios). In cooking, if a recipe
                  serves 4 and uses a 2:1 ratio of flour to sugar, scaling to serve 8 people means doubling both
                  quantities while maintaining the same ratio for consistent results.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In finance, ratios like Price-to-Earnings (P/E) help investors compare company valuations. In
                  photography and video, aspect ratios (16:9, 4:3) determine the shape of images. Map scales are ratios
                  that show the relationship between distances on a map and real-world distances. Understanding how to
                  calculate, simplify, and scale ratios empowers you to solve problems efficiently across countless
                  domains.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
