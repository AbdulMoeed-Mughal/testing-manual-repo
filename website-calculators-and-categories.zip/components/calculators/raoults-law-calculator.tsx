"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Beaker, Plus, Trash2, AlertCircle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface Component {
  id: string
  name: string
  moleFraction: string
  vaporPressure: string
}

interface RaoultResult {
  components: Array<{
    name: string
    moleFraction: number
    vaporPressure: number
    partialPressure: number
    contribution: number
  }>
  totalPressure: number
}

export function RaoultsLawCalculator() {
  const [components, setComponents] = useState<Component[]>([
    { id: "1", name: "Component 1", moleFraction: "", vaporPressure: "" },
    { id: "2", name: "Component 2", moleFraction: "", vaporPressure: "" },
  ])
  const [pressureUnit, setPressureUnit] = useState("mmHg")
  const [result, setResult] = useState<RaoultResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const addComponent = () => {
    if (components.length < 5) {
      const newId = (Math.max(...components.map((c) => Number.parseInt(c.id))) + 1).toString()
      setComponents([
        ...components,
        { id: newId, name: `Component ${newId}`, moleFraction: "", vaporPressure: "" },
      ])
    }
  }

  const removeComponent = (id: string) => {
    if (components.length > 2) {
      setComponents(components.filter((c) => c.id !== id))
    }
  }

  const updateComponent = (id: string, field: keyof Component, value: string) => {
    setComponents(components.map((c) => (c.id === id ? { ...c, [field]: value } : c)))
  }

  const calculateRaoults = () => {
    setError("")
    setResult(null)

    // Validate all inputs
    const parsedComponents = components.map((c) => ({
      name: c.name || `Component ${c.id}`,
      moleFraction: Number.parseFloat(c.moleFraction),
      vaporPressure: Number.parseFloat(c.vaporPressure),
    }))

    // Check for valid numbers
    for (const comp of parsedComponents) {
      if (Number.isNaN(comp.moleFraction) || comp.moleFraction <= 0 || comp.moleFraction > 1) {
        setError("All mole fractions must be between 0 and 1")
        return
      }
      if (Number.isNaN(comp.vaporPressure) || comp.vaporPressure <= 0) {
        setError("All vapor pressures must be positive")
        return
      }
    }

    // Check that mole fractions sum to 1 (with tolerance)
    const sum = parsedComponents.reduce((acc, c) => acc + c.moleFraction, 0)
    if (Math.abs(sum - 1) > 0.01) {
      setError(`Mole fractions must sum to 1.0 (current sum: ${sum.toFixed(3)})`)
      return
    }

    // Calculate partial pressures
    const resultsWithPartials = parsedComponents.map((comp) => {
      const partialPressure = comp.moleFraction * comp.vaporPressure
      return {
        ...comp,
        partialPressure,
        contribution: 0, // Will be calculated after total
      }
    })

    // Calculate total pressure
    const totalPressure = resultsWithPartials.reduce((acc, c) => acc + c.partialPressure, 0)

    // Calculate contributions
    const finalResults = resultsWithPartials.map((comp) => ({
      ...comp,
      contribution: (comp.partialPressure / totalPressure) * 100,
    }))

    setResult({
      components: finalResults,
      totalPressure,
    })
  }

  const handleReset = () => {
    setComponents([
      { id: "1", name: "Component 1", moleFraction: "", vaporPressure: "" },
      { id: "2", name: "Component 2", moleFraction: "", vaporPressure: "" },
    ])
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Raoult's Law Calculation:
Total Vapor Pressure: ${result.totalPressure.toFixed(2)} ${pressureUnit}
${result.components.map((c) => `${c.name}: ${c.partialPressure.toFixed(2)} ${pressureUnit} (${c.contribution.toFixed(1)}%)`).join("\n")}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Raoult's Law Result",
          text: `Total vapor pressure: ${result.totalPressure.toFixed(2)} ${pressureUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getPressureCategory = (pressure: number) => {
    if (pressure < 100) return { label: "Low Pressure", color: "text-blue-600", bgColor: "bg-blue-50" }
    if (pressure < 500) return { label: "Moderate Pressure", color: "text-green-600", bgColor: "bg-green-50" }
    if (pressure < 1000) return { label: "High Pressure", color: "text-yellow-600", bgColor: "bg-yellow-50" }
    return { label: "Very High Pressure", color: "text-red-600", bgColor: "bg-red-50" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Beaker className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Raoult's Law Calculator</CardTitle>
                    <CardDescription>Calculate vapor pressure of ideal solutions</CardDescription>
                  </div>
                </div>

                {/* Pressure Unit Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Pressure Unit</span>
                  <Select value={pressureUnit} onValueChange={setPressureUnit}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mmHg">mmHg</SelectItem>
                      <SelectItem value="Pa">Pa</SelectItem>
                      <SelectItem value="kPa">kPa</SelectItem>
                      <SelectItem value="bar">bar</SelectItem>
                      <SelectItem value="atm">atm</SelectItem>
                      <SelectItem value="psi">psi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Components */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Components</Label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={addComponent}
                      disabled={components.length >= 5}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {components.map((comp, index) => (
                    <Card key={comp.id} className="p-3 bg-muted/50">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Input
                            placeholder="Component name"
                            value={comp.name}
                            onChange={(e) => updateComponent(comp.id, "name", e.target.value)}
                            className="flex-1 mr-2"
                          />
                          {components.length > 2 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeComponent(comp.id)}
                              className="h-8 w-8 p-0"
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label className="text-xs">Mole Fraction (x)</Label>
                            <Input
                              type="number"
                              placeholder="0.5"
                              value={comp.moleFraction}
                              onChange={(e) => updateComponent(comp.id, "moleFraction", e.target.value)}
                              min="0"
                              max="1"
                              step="0.01"
                            />
                          </div>
                          <div>
                            <Label className="text-xs">P° ({pressureUnit})</Label>
                            <Input
                              type="number"
                              placeholder="100"
                              value={comp.vaporPressure}
                              onChange={(e) => updateComponent(comp.id, "vaporPressure", e.target.value)}
                              min="0"
                              step="0.1"
                            />
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRaoults} className="w-full" size="lg">
                  Calculate Vapor Pressure
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    {/* Total Pressure */}
                    <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total Vapor Pressure</p>
                        <p className="text-4xl font-bold text-purple-600 mb-1">
                          {result.totalPressure.toFixed(2)}
                        </p>
                        <p className="text-sm font-medium text-purple-600">{pressureUnit}</p>
                        <div className="mt-2">
                          <span
                            className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${getPressureCategory(result.totalPressure).bgColor} ${getPressureCategory(result.totalPressure).color}`}
                          >
                            {getPressureCategory(result.totalPressure).label}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Component Breakdown */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Partial Pressures</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        {result.components.map((comp, index) => (
                          <div key={index} className="flex items-center justify-between p-2 rounded bg-muted/50">
                            <span className="text-sm font-medium">{comp.name}</span>
                            <div className="text-right">
                              <p className="text-sm font-semibold text-purple-600">
                                {comp.partialPressure.toFixed(2)} {pressureUnit}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {comp.contribution.toFixed(1)}%
                              </p>
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </Card>

                    {/* Calculation Steps */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2 text-sm text-muted-foreground">
                        {result.components.map((comp, index) => (
                          <div key={index} className="font-mono text-xs bg-muted p-2 rounded">
                            <p>
                              P<sub>{index + 1}</sub> = x<sub>{index + 1}</sub> × P°
                              <sub>{index + 1}</sub>
                            </p>
                            <p>
                              P<sub>{index + 1}</sub> = {comp.moleFraction.toFixed(3)} × {comp.vaporPressure.toFixed(2)}{" "}
                              = {comp.partialPressure.toFixed(2)} {pressureUnit}
                            </p>
                          </div>
                        ))}
                        <div className="font-mono text-xs bg-purple-50 p-2 rounded border border-purple-200">
                          <p className="font-semibold text-purple-700">P_total = Σ(P_i)</p>
                          <p className="text-purple-600">
                            P_total = {result.components.map((c) => c.partialPressure.toFixed(2)).join(" + ")} ={" "}
                            {result.totalPressure.toFixed(2)} {pressureUnit}
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Raoult's Law Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">P_i = x_i × P°_i</p>
                    <p className="text-xs">Partial vapor pressure of component i</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg font-mono text-center border border-purple-200">
                    <p className="font-semibold text-purple-700">P_total = Σ(x_i × P°_i)</p>
                    <p className="text-xs text-purple-600">Total vapor pressure of solution</p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>P_i:</strong> Partial vapor pressure of component i
                    </p>
                    <p>
                      <strong>x_i:</strong> Mole fraction of component i
                    </p>
                    <p>
                      <strong>P°_i:</strong> Vapor pressure of pure component i
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-muted-foreground">
                  <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                    <h4 className="font-semibold text-purple-700 mb-1">Distillation</h4>
                    <p className="text-purple-600 text-xs">
                      Predicting boiling points and separation efficiency in fractional distillation processes.
                    </p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-700 mb-1">Solution Chemistry</h4>
                    <p className="text-blue-600 text-xs">
                      Understanding colligative properties like boiling point elevation and freezing point depression.
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                    <h4 className="font-semibold text-green-700 mb-1">Phase Equilibria</h4>
                    <p className="text-green-600 text-xs">
                      Calculating vapor-liquid equilibrium in ideal and near-ideal mixtures.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2 text-amber-900">
                    <AlertCircle className="h-5 w-5" />
                    Important Note
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-amber-800">
                  <p>
                    Raoult's Law applies to ideal solutions. Deviations may occur in non-ideal mixtures due to
                    intermolecular interactions. Real solutions may show positive or negative deviations from
                    Raoult's Law depending on the strength of molecular interactions between components.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
