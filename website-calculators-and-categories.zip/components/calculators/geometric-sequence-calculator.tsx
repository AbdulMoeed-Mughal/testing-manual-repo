"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface Result {
  nthTerm: number
  finiteSum: number
  infiniteSum: number | null
  converges: boolean
  sequence: number[]
}

export function GeometricSequenceCalculator() {
  const [firstTerm, setFirstTerm] = useState("")
  const [commonRatio, setCommonRatio] = useState("")
  const [termNumber, setTermNumber] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [showSequence, setShowSequence] = useState(false)
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [detailsOpen, setDetailsOpen] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const a1 = Number.parseFloat(firstTerm)
    const r = Number.parseFloat(commonRatio)
    const n = Number.parseInt(termNumber)

    if (isNaN(a1)) {
      setError("Please enter a valid first term (a₁)")
      return
    }

    if (isNaN(r)) {
      setError("Please enter a valid common ratio (r)")
      return
    }

    if (isNaN(n) || n < 1 || !Number.isInteger(n)) {
      setError("Please enter a valid positive integer for term number (n)")
      return
    }

    if (n > 1000) {
      setError("Term number must be 1000 or less")
      return
    }

    // Calculate n-th term: aₙ = a₁ × r^(n-1)
    const nthTerm = a1 * Math.pow(r, n - 1)

    // Calculate finite sum: Sₙ = a₁ × (1 - rⁿ) / (1 - r) for r ≠ 1
    let finiteSum: number
    if (r === 1) {
      finiteSum = a1 * n
    } else {
      finiteSum = (a1 * (1 - Math.pow(r, n))) / (1 - r)
    }

    // Calculate infinite sum (only if |r| < 1)
    const converges = Math.abs(r) < 1
    let infiniteSum: number | null = null
    if (converges) {
      infiniteSum = a1 / (1 - r)
    }

    // Generate sequence (up to 50 terms for display)
    const displayTerms = Math.min(n, 50)
    const sequence: number[] = []
    for (let i = 0; i < displayTerms; i++) {
      sequence.push(a1 * Math.pow(r, i))
    }

    setResult({
      nthTerm,
      finiteSum,
      infiniteSum,
      converges,
      sequence,
    })
  }

  const handleReset = () => {
    setFirstTerm("")
    setCommonRatio("")
    setTermNumber("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) < 0.0001 && num !== 0) {
      return num.toExponential(4)
    }
    if (Math.abs(num) >= 1e10) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 6 })
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Geometric Sequence: a₁ = ${firstTerm}, r = ${commonRatio}, n = ${termNumber}\na_n = ${formatNumber(result.nthTerm)}\nS_n = ${formatNumber(result.finiteSum)}${result.infiniteSum !== null ? `\nS_∞ = ${formatNumber(result.infiniteSum)}` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      const a1 = firstTerm
      const r = commonRatio
      const n = termNumber
      const latex = `a_n = ${a1} \\times ${r}^{${n}-1} = ${formatNumber(result.nthTerm)}\n\nS_n = \\frac{${a1}(1 - ${r}^{${n}})}{1 - ${r}} = ${formatNumber(result.finiteSum)}${result.infiniteSum !== null ? `\n\nS_\\infty = \\frac{${a1}}{1 - ${r}} = ${formatNumber(result.infiniteSum)}` : ""}`
      await navigator.clipboard.writeText(latex)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Geometric Sequence Result",
          text: `Geometric Sequence: a₁ = ${firstTerm}, r = ${commonRatio}, n = ${termNumber}\na_n = ${formatNumber(result.nthTerm)}\nS_n = ${formatNumber(result.finiteSum)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const a1 = Number.parseFloat(firstTerm) || 0
  const r = Number.parseFloat(commonRatio) || 0
  const n = Number.parseInt(termNumber) || 0

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Geometric Sequence Calculator</CardTitle>
                    <CardDescription>Calculate terms, sums, and properties</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* First Term Input */}
                <div className="space-y-2">
                  <Label htmlFor="firstTerm">First Term (a₁)</Label>
                  <Input
                    id="firstTerm"
                    type="number"
                    placeholder="Enter first term"
                    value={firstTerm}
                    onChange={(e) => setFirstTerm(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Common Ratio Input */}
                <div className="space-y-2">
                  <Label htmlFor="commonRatio">Common Ratio (r)</Label>
                  <Input
                    id="commonRatio"
                    type="number"
                    placeholder="Enter common ratio"
                    value={commonRatio}
                    onChange={(e) => setCommonRatio(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Term Number Input */}
                <div className="space-y-2">
                  <Label htmlFor="termNumber">Term Number (n)</Label>
                  <Input
                    id="termNumber"
                    type="number"
                    placeholder="Enter term number"
                    value={termNumber}
                    onChange={(e) => setTermNumber(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Options */}
                <div className="flex flex-wrap gap-4 pt-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                    <Label htmlFor="showSteps" className="text-sm">
                      Show steps
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="showSequence" checked={showSequence} onCheckedChange={setShowSequence} />
                    <Label htmlFor="showSequence" className="text-sm">
                      Show sequence
                    </Label>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">n-th Term (a_n)</p>
                        <p className="text-3xl font-bold text-blue-600">{formatNumber(result.nthTerm)}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-3 pt-2">
                        <div className="p-3 bg-white/60 rounded-lg">
                          <p className="text-xs text-muted-foreground">Sum of n terms (S_n)</p>
                          <p className="text-lg font-semibold text-blue-700">{formatNumber(result.finiteSum)}</p>
                        </div>
                        <div className="p-3 bg-white/60 rounded-lg">
                          <p className="text-xs text-muted-foreground">Infinite Sum (S_∞)</p>
                          <p className="text-lg font-semibold text-blue-700">
                            {result.infiniteSum !== null ? formatNumber(result.infiniteSum) : "Diverges"}
                          </p>
                        </div>
                      </div>

                      {/* Convergence Status */}
                      <div
                        className={`p-2 rounded-lg text-sm ${result.converges ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}
                      >
                        {result.converges
                          ? `Series converges (|r| = ${Math.abs(Number.parseFloat(commonRatio)).toFixed(2)} < 1)`
                          : `Series diverges (|r| = ${Math.abs(Number.parseFloat(commonRatio)).toFixed(2)} ≥ 1)`}
                      </div>
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && (
                      <Collapsible open={detailsOpen} onOpenChange={setDetailsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            Step-by-Step Solution
                            {detailsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="p-3 bg-white/80 rounded-lg text-sm space-y-3">
                            <div>
                              <p className="font-medium text-blue-800">n-th Term Calculation:</p>
                              <p className="text-muted-foreground mt-1">a_n = a₁ × r^(n-1)</p>
                              <p className="text-muted-foreground">
                                a_{n} = {a1} × {r}^({n}-1)
                              </p>
                              <p className="text-muted-foreground">
                                a_{n} = {a1} × {r}^{n - 1}
                              </p>
                              <p className="text-muted-foreground">
                                a_{n} = {a1} × {formatNumber(Math.pow(r, n - 1))}
                              </p>
                              <p className="font-semibold text-blue-700">
                                a_{n} = {formatNumber(result.nthTerm)}
                              </p>
                            </div>
                            <div>
                              <p className="font-medium text-blue-800">Sum of n Terms:</p>
                              {r === 1 ? (
                                <>
                                  <p className="text-muted-foreground mt-1">S_n = a₁ × n (when r = 1)</p>
                                  <p className="text-muted-foreground">
                                    S_{n} = {a1} × {n}
                                  </p>
                                  <p className="font-semibold text-blue-700">
                                    S_{n} = {formatNumber(result.finiteSum)}
                                  </p>
                                </>
                              ) : (
                                <>
                                  <p className="text-muted-foreground mt-1">S_n = a₁ × (1 - r^n) / (1 - r)</p>
                                  <p className="text-muted-foreground">
                                    S_{n} = {a1} × (1 - {r}^{n}) / (1 - {r})
                                  </p>
                                  <p className="text-muted-foreground">
                                    S_{n} = {a1} × (1 - {formatNumber(Math.pow(r, n))}) / {formatNumber(1 - r)}
                                  </p>
                                  <p className="text-muted-foreground">
                                    S_{n} = {a1} × {formatNumber(1 - Math.pow(r, n))} / {formatNumber(1 - r)}
                                  </p>
                                  <p className="font-semibold text-blue-700">
                                    S_{n} = {formatNumber(result.finiteSum)}
                                  </p>
                                </>
                              )}
                            </div>
                            {result.infiniteSum !== null && (
                              <div>
                                <p className="font-medium text-blue-800">Infinite Sum (|r| {"<"} 1):</p>
                                <p className="text-muted-foreground mt-1">S_∞ = a₁ / (1 - r)</p>
                                <p className="text-muted-foreground">
                                  S_∞ = {a1} / (1 - {r})
                                </p>
                                <p className="text-muted-foreground">
                                  S_∞ = {a1} / {formatNumber(1 - r)}
                                </p>
                                <p className="font-semibold text-blue-700">S_∞ = {formatNumber(result.infiniteSum)}</p>
                              </div>
                            )}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Sequence List */}
                    {showSequence && result.sequence.length > 0 && (
                      <div className="mt-4 p-3 bg-white/80 rounded-lg">
                        <p className="font-medium text-blue-800 text-sm mb-2">
                          Sequence (first {result.sequence.length} terms):
                        </p>
                        <p className="text-sm text-muted-foreground break-all">
                          {result.sequence.map((term, i) => formatNumber(term)).join(", ")}
                          {Number.parseInt(termNumber) > 50 && "..."}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Geometric Sequence Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-800 text-sm">n-th Term</p>
                    <p className="font-mono text-blue-700 mt-1">aₙ = a₁ × r^(n-1)</p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-800 text-sm">Sum of n Terms (r ≠ 1)</p>
                    <p className="font-mono text-green-700 mt-1">Sₙ = a₁ × (1 - rⁿ) / (1 - r)</p>
                  </div>
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-medium text-purple-800 text-sm">Infinite Sum (|r| {"<"} 1)</p>
                    <p className="font-mono text-purple-700 mt-1">S∞ = a₁ / (1 - r)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Variables</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">a₁</span>
                    <span>First term of the sequence</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">r</span>
                    <span>Common ratio</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">n</span>
                    <span>Position of the term</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">aₙ</span>
                    <span>n-th term value</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Sₙ</span>
                    <span>Sum of first n terms</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">2, 6, 18, 54, ...</p>
                    <p className="text-xs mt-1">a₁ = 2, r = 3 (multiply by 3)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">100, 50, 25, 12.5, ...</p>
                    <p className="text-xs mt-1">a₁ = 100, r = 0.5 (converges)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">3, -6, 12, -24, ...</p>
                    <p className="text-xs mt-1">a₁ = 3, r = -2 (alternating)</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Geometric Sequence?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A geometric sequence (or geometric progression) is a sequence of numbers where each term after the
                  first is found by multiplying the previous term by a fixed, non-zero number called the common ratio.
                  For example, in the sequence 2, 6, 18, 54, each term is multiplied by 3 to get the next term, so the
                  common ratio is 3.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Geometric sequences appear frequently in mathematics, science, and finance. They model phenomena like
                  population growth, compound interest, radioactive decay, and signal amplification. Understanding
                  geometric sequences is fundamental to calculus, particularly in the study of infinite series and
                  convergence.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>1. Enter the first term (a₁):</strong> This is the starting value of your sequence. It can be
                  any real number, positive, negative, or decimal.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-2">
                  <strong>2. Enter the common ratio (r):</strong> This is the multiplier between consecutive terms. If r
                  {">"} 1, the sequence grows; if 0 {"<"} r {"<"} 1, it shrinks; if r {"<"} 0, the terms alternate in
                  sign.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-2">
                  <strong>3. Enter the term number (n):</strong> Specify which term you want to find and how many terms
                  to sum. The calculator will compute the n-th term and the sum of the first n terms.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-2">
                  <strong>4. Toggle options:</strong> Enable "Show steps" to see the detailed calculation process, and
                  "Show sequence" to display the actual terms.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Geometric sequence calculations follow standard mathematical formulas. Results depend on correct input
                  values and assumptions. For very large values of n or r, results may be subject to floating-point
                  precision limitations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
