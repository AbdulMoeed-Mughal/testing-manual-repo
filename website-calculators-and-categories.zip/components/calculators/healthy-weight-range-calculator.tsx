"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Scale, Info, ChevronDown, ChevronUp, Heart } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type BodyFrame = "small" | "medium" | "large"
type BMIStandard = "who" | "cdc" | "custom"

interface WeightRangeResult {
  minWeight: number
  maxWeight: number
  idealWeight: number
  minBMI: number
  maxBMI: number
  frameAdjustedMin: number
  frameAdjustedMax: number
}

export function HealthyWeightRangeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [gender, setGender] = useState<Gender>("male")
  const [bodyFrame, setBodyFrame] = useState<BodyFrame>("medium")
  const [bmiStandard, setBMIStandard] = useState<BMIStandard>("who")
  const [customMinBMI, setCustomMinBMI] = useState("18.5")
  const [customMaxBMI, setCustomMaxBMI] = useState("24.9")
  const [result, setResult] = useState<WeightRangeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const getBMIRange = (): { min: number; max: number } => {
    switch (bmiStandard) {
      case "who":
        return { min: 18.5, max: 24.9 }
      case "cdc":
        return { min: 18.5, max: 24.9 }
      case "custom":
        return {
          min: Number.parseFloat(customMinBMI) || 18.5,
          max: Number.parseFloat(customMaxBMI) || 24.9,
        }
      default:
        return { min: 18.5, max: 24.9 }
    }
  }

  const getFrameAdjustment = (): { minAdj: number; maxAdj: number } => {
    switch (bodyFrame) {
      case "small":
        return { minAdj: -0.1, maxAdj: -0.05 }
      case "large":
        return { minAdj: 0.05, maxAdj: 0.1 }
      default:
        return { minAdj: 0, maxAdj: 0 }
    }
  }

  const calculateWeightRange = () => {
    setError("")
    setResult(null)

    let heightInMeters: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      if (heightCmNum < 50 || heightCmNum > 300) {
        setError("Please enter a realistic height (50-300 cm)")
        return
      }
      heightInMeters = heightCmNum / 100
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      if (totalInches < 20 || totalInches > 108) {
        setError("Please enter a realistic height")
        return
      }
      heightInMeters = totalInches * 0.0254
    }

    const { min: minBMI, max: maxBMI } = getBMIRange()
    const { minAdj, maxAdj } = getFrameAdjustment()

    // Calculate weight range: Weight = BMI × Height²
    const heightSquared = heightInMeters * heightInMeters
    let minWeight = minBMI * heightSquared
    let maxWeight = maxBMI * heightSquared

    // Apply frame adjustments
    const frameAdjustedMin = minWeight * (1 + minAdj)
    const frameAdjustedMax = maxWeight * (1 + maxAdj)

    // Calculate ideal weight (midpoint)
    const idealWeight = (frameAdjustedMin + frameAdjustedMax) / 2

    // Convert to imperial if needed
    if (unitSystem === "imperial") {
      minWeight = minWeight * 2.20462
      maxWeight = maxWeight * 2.20462
      setResult({
        minWeight: Math.round(frameAdjustedMin * 2.20462 * 10) / 10,
        maxWeight: Math.round(frameAdjustedMax * 2.20462 * 10) / 10,
        idealWeight: Math.round(idealWeight * 2.20462 * 10) / 10,
        minBMI,
        maxBMI,
        frameAdjustedMin: Math.round(frameAdjustedMin * 2.20462 * 10) / 10,
        frameAdjustedMax: Math.round(frameAdjustedMax * 2.20462 * 10) / 10,
      })
    } else {
      setResult({
        minWeight: Math.round(frameAdjustedMin * 10) / 10,
        maxWeight: Math.round(frameAdjustedMax * 10) / 10,
        idealWeight: Math.round(idealWeight * 10) / 10,
        minBMI,
        maxBMI,
        frameAdjustedMin: Math.round(frameAdjustedMin * 10) / 10,
        frameAdjustedMax: Math.round(frameAdjustedMax * 10) / 10,
      })
    }
  }

  const handleReset = () => {
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setGender("male")
    setBodyFrame("medium")
    setBMIStandard("who")
    setCustomMinBMI("18.5")
    setCustomMaxBMI("24.9")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "kg" : "lb"
      await navigator.clipboard.writeText(
        `My healthy weight range is ${result.minWeight} - ${result.maxWeight} ${unit} (Ideal: ${result.idealWeight} ${unit})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const unit = unitSystem === "metric" ? "kg" : "lb"
      try {
        await navigator.share({
          title: "My Healthy Weight Range",
          text: `I calculated my healthy weight range using CalcHub! My range is ${result.minWeight} - ${result.maxWeight} ${unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  const weightUnit = unitSystem === "metric" ? "kg" : "lb"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Healthy Weight Range Calculator</CardTitle>
                    <CardDescription>Find your ideal weight based on height and body frame</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Body Frame Selection */}
                <div className="space-y-2">
                  <Label>Body Frame (Optional)</Label>
                  <Select value={bodyFrame} onValueChange={(value: BodyFrame) => setBodyFrame(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select body frame" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small Frame</SelectItem>
                      <SelectItem value="medium">Medium Frame</SelectItem>
                      <SelectItem value="large">Large Frame</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">Adjusts weight range based on bone structure</p>
                </div>

                {/* BMI Standard Selection */}
                <div className="space-y-2">
                  <Label>BMI Standard (Optional)</Label>
                  <Select value={bmiStandard} onValueChange={(value: BMIStandard) => setBMIStandard(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select BMI standard" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="who">WHO Standard (18.5-24.9)</SelectItem>
                      <SelectItem value="cdc">CDC Standard (18.5-24.9)</SelectItem>
                      <SelectItem value="custom">Custom Range</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Custom BMI Range */}
                {bmiStandard === "custom" && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="customMinBMI">Min BMI</Label>
                      <Input
                        id="customMinBMI"
                        type="number"
                        placeholder="18.5"
                        value={customMinBMI}
                        onChange={(e) => setCustomMinBMI(e.target.value)}
                        min="10"
                        max="40"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customMaxBMI">Max BMI</Label>
                      <Input
                        id="customMaxBMI"
                        type="number"
                        placeholder="24.9"
                        value={customMaxBMI}
                        onChange={(e) => setCustomMaxBMI(e.target.value)}
                        min="10"
                        max="40"
                        step="0.1"
                      />
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWeightRange} className="w-full" size="lg">
                  Calculate Healthy Weight Range
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Healthy Weight Range</p>
                      <p className="text-4xl font-bold text-green-600 mb-2">
                        {result.minWeight} - {result.maxWeight} {weightUnit}
                      </p>
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Heart className="h-4 w-4 text-green-600" />
                        <p className="text-lg font-semibold text-green-600">
                          Ideal: {result.idealWeight} {weightUnit}
                        </p>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Based on BMI {result.minBMI} - {result.maxBMI}
                        {bodyFrame !== "medium" && ` (${bodyFrame} frame adjusted)`}
                      </p>
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-green-200 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">BMI Range Used:</span>
                          <span className="font-medium">
                            {result.minBMI} - {result.maxBMI}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Body Frame:</span>
                          <span className="font-medium capitalize">{bodyFrame}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Frame Adjustment:</span>
                          <span className="font-medium">
                            {bodyFrame === "small" ? "-5% to -10%" : bodyFrame === "large" ? "+5% to +10%" : "None"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Weight Range:</span>
                          <span className="font-medium">
                            {(result.maxWeight - result.minWeight).toFixed(1)} {weightUnit}
                          </span>
                        </div>
                        <div className="mt-3 p-3 bg-green-100 rounded-lg">
                          <p className="text-xs text-green-700">
                            <strong>Formula:</strong> Weight = BMI × Height² (m²)
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BMI Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Underweight</span>
                      <span className="text-sm text-blue-600">{"< 18.5"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Normal weight</span>
                      <span className="text-sm text-green-600">18.5 – 24.9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Overweight</span>
                      <span className="text-sm text-yellow-600">25 – 29.9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Obese</span>
                      <span className="text-sm text-red-600">≥ 30</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Body Frame Guide</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">How to Determine Your Frame Size</p>
                    <p>Wrap your thumb and middle finger around your wrist:</p>
                  </div>
                  <ul className="space-y-2 ml-4">
                    <li className="flex items-start gap-2">
                      <span className="text-primary font-bold">•</span>
                      <span>
                        <strong>Small:</strong> Fingers overlap
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary font-bold">•</span>
                      <span>
                        <strong>Medium:</strong> Fingers just touch
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary font-bold">•</span>
                      <span>
                        <strong>Large:</strong> Fingers don't touch
                      </span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Weight = BMI × Height² (m²)</p>
                  </div>
                  <p>
                    The healthy weight range is calculated using the BMI formula reversed. For a BMI range of 18.5-24.9,
                    we calculate the corresponding weights.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Healthy Weight Range?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A healthy weight range is the spectrum of body weights that are associated with optimal health
                  outcomes for individuals of a given height. This range is typically determined using the Body Mass
                  Index (BMI), which provides a simple relationship between weight and height. The World Health
                  Organization (WHO) defines a healthy BMI as falling between 18.5 and 24.9, which translates to
                  different weight ranges depending on your height.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding your healthy weight range can help you set realistic fitness goals and maintain a weight
                  that reduces your risk of chronic diseases such as heart disease, diabetes, and certain cancers.
                  However, it's important to remember that weight is just one indicator of health, and factors like
                  muscle mass, body composition, and overall fitness level also play crucial roles.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Body Frame Size</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Body frame size refers to the overall bone structure of your body. People with larger frames naturally
                  carry more weight due to their larger bone mass and structure, while those with smaller frames may
                  weigh less at the same height. Accounting for body frame can provide a more personalized healthy
                  weight range.
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-3">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Small Frame</h4>
                    <p className="text-blue-700 text-sm">
                      Characterized by narrow shoulders, small wrists, and a delicate bone structure. Weight range
                      adjusted 5-10% lower.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Medium Frame</h4>
                    <p className="text-green-700 text-sm">
                      Average bone structure with proportional shoulders and wrists. Standard BMI-based weight range
                      applies.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Large Frame</h4>
                    <p className="text-orange-700 text-sm">
                      Broader shoulders, larger wrists, and heavier bone structure. Weight range adjusted 5-10% higher.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Achieving Your Healthy Weight</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Balanced Nutrition</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Eat a variety of whole foods</li>
                      <li>• Control portion sizes</li>
                      <li>• Limit processed foods and sugars</li>
                      <li>• Stay hydrated with water</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Regular Exercise</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Aim for 150+ minutes of moderate activity weekly</li>
                      <li>• Include strength training exercises</li>
                      <li>• Stay active throughout the day</li>
                      <li>• Find activities you enjoy</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Lifestyle Habits</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Get 7-9 hours of sleep</li>
                      <li>• Manage stress levels</li>
                      <li>• Avoid crash diets</li>
                      <li>• Set realistic goals</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Track Progress</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Weigh yourself consistently</li>
                      <li>• Take body measurements</li>
                      <li>• Monitor how clothes fit</li>
                      <li>• Celebrate non-scale victories</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Healthy weight range estimates are general guidelines and may vary based
                  on individual body composition, age, muscle mass, and health conditions. This calculator provides
                  estimates for educational purposes only and should not replace professional medical advice. Consult a
                  healthcare professional for personalized recommendations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
