"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Droplets, Info, Thermometer, FlaskConical } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type TemperatureUnit = "celsius" | "kelvin"
type PressureUnit = "mmHg" | "Pa" | "kPa" | "bar" | "atm"

interface AntoineConstants {
  name: string
  A: number
  B: number
  C: number
  tMin: number
  tMax: number
}

interface VaporPressureResult {
  pressure: number
  pressureUnit: string
  substance: string
  temperature: number
  temperatureUnit: string
  category: string
  color: string
  bgColor: string
}

const substances: AntoineConstants[] = [
  { name: "Water", A: 8.07131, B: 1730.63, C: 233.426, tMin: 1, tMax: 100 },
  { name: "Ethanol", A: 8.20417, B: 1642.89, C: 230.300, tMin: -57, tMax: 80 },
  { name: "Methanol", A: 8.08097, B: 1582.27, C: 239.700, tMin: -16, tMax: 91 },
  { name: "Acetone", A: 7.11714, B: 1210.595, C: 229.664, tMin: -13, tMax: 55 },
  { name: "Benzene", A: 6.90565, B: 1211.033, C: 220.790, tMin: 8, tMax: 103 },
  { name: "Toluene", A: 6.95464, B: 1344.800, C: 219.482, tMin: 6, tMax: 137 },
  { name: "Chloroform", A: 6.95465, B: 1170.966, C: 226.232, tMin: -10, tMax: 60 },
  { name: "Diethyl Ether", A: 6.92032, B: 1064.07, C: 228.799, tMin: -60, tMax: 35 },
  { name: "Hexane", A: 6.87601, B: 1171.17, C: 224.408, tMin: -25, tMax: 92 },
  { name: "Heptane", A: 6.89385, B: 1264.37, C: 216.636, tMin: -2, tMax: 124 },
]

export function VaporPressureCalculator() {
  const [selectedSubstance, setSelectedSubstance] = useState<string>("Water")
  const [useCustomConstants, setUseCustomConstants] = useState(false)
  const [customA, setCustomA] = useState("")
  const [customB, setCustomB] = useState("")
  const [customC, setCustomC] = useState("")
  const [temperature, setTemperature] = useState("")
  const [temperatureUnit, setTemperatureUnit] = useState<TemperatureUnit>("celsius")
  const [pressureUnit, setPressureUnit] = useState<PressureUnit>("mmHg")
  const [result, setResult] = useState<VaporPressureResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const getSubstanceConstants = (): AntoineConstants | null => {
    if (useCustomConstants) {
      const A = parseFloat(customA)
      const B = parseFloat(customB)
      const C = parseFloat(customC)
      if (isNaN(A) || isNaN(B) || isNaN(C)) return null
      return { name: "Custom", A, B, C, tMin: -273, tMax: 1000 }
    }
    return substances.find(s => s.name === selectedSubstance) || null
  }

  const convertPressure = (mmHg: number, unit: PressureUnit): number => {
    switch (unit) {
      case "mmHg": return mmHg
      case "Pa": return mmHg * 133.322
      case "kPa": return mmHg * 0.133322
      case "bar": return mmHg * 0.00133322
      case "atm": return mmHg / 760
      default: return mmHg
    }
  }

  const getPressureUnitLabel = (unit: PressureUnit): string => {
    switch (unit) {
      case "mmHg": return "mmHg"
      case "Pa": return "Pa"
      case "kPa": return "kPa"
      case "bar": return "bar"
      case "atm": return "atm"
      default: return unit
    }
  }

  const calculateVaporPressure = () => {
    setError("")
    setResult(null)

    const tempValue = parseFloat(temperature)
    if (isNaN(tempValue)) {
      setError("Please enter a valid temperature")
      return
    }

    const constants = getSubstanceConstants()
    if (!constants) {
      setError("Please provide valid Antoine constants")
      return
    }

    // Convert to Celsius if needed
    let tempCelsius = tempValue
    if (temperatureUnit === "kelvin") {
      tempCelsius = tempValue - 273.15
    }

    // Check temperature range
    if (!useCustomConstants && (tempCelsius < constants.tMin || tempCelsius > constants.tMax)) {
      setError(`Temperature must be between ${constants.tMin}°C and ${constants.tMax}°C for ${constants.name}`)
      return
    }

    // Antoine equation: log10(P) = A - (B / (C + T))
    const logP = constants.A - (constants.B / (constants.C + tempCelsius))
    const pressureMmHg = Math.pow(10, logP)

    if (isNaN(pressureMmHg) || pressureMmHg <= 0) {
      setError("Calculation resulted in invalid pressure. Check your inputs.")
      return
    }

    const convertedPressure = convertPressure(pressureMmHg, pressureUnit)

    // Categorize vapor pressure
    let category: string
    let color: string
    let bgColor: string

    if (pressureMmHg < 10) {
      category = "Very Low Volatility"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (pressureMmHg < 100) {
      category = "Low Volatility"
      color = "text-cyan-600"
      bgColor = "bg-cyan-50 border-cyan-200"
    } else if (pressureMmHg < 400) {
      category = "Moderate Volatility"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (pressureMmHg < 760) {
      category = "High Volatility"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Volatility"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      pressure: convertedPressure,
      pressureUnit: getPressureUnitLabel(pressureUnit),
      substance: constants.name,
      temperature: tempValue,
      temperatureUnit: temperatureUnit === "celsius" ? "°C" : "K",
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setSelectedSubstance("Water")
    setUseCustomConstants(false)
    setCustomA("")
    setCustomB("")
    setCustomC("")
    setTemperature("")
    setTemperatureUnit("celsius")
    setPressureUnit("mmHg")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Vapor Pressure of ${result.substance} at ${result.temperature}${result.temperatureUnit}: ${result.pressure.toFixed(4)} ${result.pressureUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatPressure = (value: number): string => {
    if (value >= 1000) {
      return value.toFixed(1)
    } else if (value >= 1) {
      return value.toFixed(3)
    } else {
      return value.toExponential(3)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2 bg-transparent">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Vapor Pressure Calculator</CardTitle>
                    <CardDescription>Calculate vapor pressure using Antoine equation</CardDescription>
                  </div>
                </div>

                {/* Constants Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Constants Source</span>
                  <button
                    onClick={() => setUseCustomConstants(!useCustomConstants)}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        useCustomConstants ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !useCustomConstants ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Preset
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        useCustomConstants ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Custom
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Substance Selection or Custom Constants */}
                {!useCustomConstants ? (
                  <div className="space-y-2">
                    <Label htmlFor="substance">Substance</Label>
                    <Select value={selectedSubstance} onValueChange={setSelectedSubstance}>
                      <SelectTrigger id="substance">
                        <SelectValue placeholder="Select substance" />
                      </SelectTrigger>
                      <SelectContent>
                        {substances.map((s) => (
                          <SelectItem key={s.name} value={s.name}>
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <Label>Antoine Constants (log₁₀P in mmHg, T in °C)</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Input
                          type="number"
                          placeholder="A"
                          value={customA}
                          onChange={(e) => setCustomA(e.target.value)}
                          step="any"
                        />
                        <span className="text-xs text-muted-foreground mt-1 block text-center">A</span>
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="B"
                          value={customB}
                          onChange={(e) => setCustomB(e.target.value)}
                          step="any"
                        />
                        <span className="text-xs text-muted-foreground mt-1 block text-center">B</span>
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="C"
                          value={customC}
                          onChange={(e) => setCustomC(e.target.value)}
                          step="any"
                        />
                        <span className="text-xs text-muted-foreground mt-1 block text-center">C</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Temperature Input */}
                <div className="space-y-2">
                  <Label htmlFor="temperature">Temperature</Label>
                  <div className="flex gap-2">
                    <Input
                      id="temperature"
                      type="number"
                      placeholder="Enter temperature"
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                      className="flex-1"
                      step="any"
                    />
                    <Select value={temperatureUnit} onValueChange={(v) => setTemperatureUnit(v as TemperatureUnit)}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="celsius">°C</SelectItem>
                        <SelectItem value="kelvin">K</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Pressure Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="pressureUnit">Output Pressure Unit</Label>
                  <Select value={pressureUnit} onValueChange={(v) => setPressureUnit(v as PressureUnit)}>
                    <SelectTrigger id="pressureUnit">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mmHg">mmHg (Torr)</SelectItem>
                      <SelectItem value="Pa">Pa</SelectItem>
                      <SelectItem value="kPa">kPa</SelectItem>
                      <SelectItem value="bar">bar</SelectItem>
                      <SelectItem value="atm">atm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateVaporPressure} className="w-full" size="lg">
                  Calculate Vapor Pressure
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Vapor Pressure</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {formatPressure(result.pressure)}
                      </p>
                      <p className={`text-lg font-medium ${result.color} mb-2`}>{result.pressureUnit}</p>
                      <p className={`text-sm font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Details */}
                    <div className="mt-4 pt-4 border-t border-current/10 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Substance:</span>
                        <span className="font-medium">{result.substance}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Temperature:</span>
                        <span className="font-medium">{result.temperature}{result.temperatureUnit}</span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset} className="bg-transparent">
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy} className="bg-transparent">
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Antoine Equation</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">log₁₀(P) = A - B / (C + T)</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Where P is vapor pressure in mmHg, T is temperature in °C, and A, B, C are substance-specific constants.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Substances</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {substances.map((s) => (
                      <button
                        key={s.name}
                        onClick={() => {
                          setUseCustomConstants(false)
                          setSelectedSubstance(s.name)
                        }}
                        className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-muted transition-colors text-left"
                      >
                        <span className="font-medium text-sm">{s.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {s.tMin}°C to {s.tMax}°C
                        </span>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Volatility Scale</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700 text-sm">Very Low</span>
                      <span className="text-xs text-blue-600">{"< 10 mmHg"}</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700 text-sm">Low</span>
                      <span className="text-xs text-cyan-600">10 - 100 mmHg</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700 text-sm">Moderate</span>
                      <span className="text-xs text-green-600">100 - 400 mmHg</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700 text-sm">High</span>
                      <span className="text-xs text-yellow-600">400 - 760 mmHg</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700 text-sm">Very High</span>
                      <span className="text-xs text-red-600">{"> 760 mmHg"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Vapor Pressure?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Vapor pressure is the pressure exerted by a vapor in thermodynamic equilibrium with its condensed phases 
                  (solid or liquid) at a given temperature in a closed system. It is a measure of the tendency of particles 
                  to escape from the liquid or solid state into the gaseous phase. A substance with a high vapor pressure at 
                  normal temperatures is often referred to as volatile.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The vapor pressure of a liquid increases with temperature because, at higher temperatures, more molecules 
                  have enough kinetic energy to escape from the liquid surface. When the vapor pressure equals the external 
                  pressure (typically atmospheric pressure), the liquid boils. This is why water boils at a lower temperature 
                  at high altitudes where atmospheric pressure is lower.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>The Antoine Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Antoine equation is a semi-empirical correlation that describes the relationship between vapor pressure 
                  and temperature for pure substances. Developed by Louis Charles Antoine in 1888, it is derived from the 
                  Clausius-Clapeyron equation and provides accurate predictions within specific temperature ranges.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equation uses three substance-specific constants (A, B, and C) that are determined experimentally. 
                  These constants are tabulated for thousands of compounds and are widely used in chemical engineering 
                  calculations, distillation design, and thermodynamic modeling. The accuracy of the Antoine equation 
                  depends on using it within the recommended temperature range for each substance.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Vapor Pressure</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding vapor pressure is crucial in many fields and applications:
                </p>
                <ul className="text-muted-foreground mt-4 space-y-2">
                  <li><strong>Distillation:</strong> Separation of liquid mixtures based on different vapor pressures</li>
                  <li><strong>Evaporative Cooling:</strong> Design of cooling systems and air conditioning</li>
                  <li><strong>Fuel Systems:</strong> Understanding gasoline volatility for engine performance</li>
                  <li><strong>Pharmaceuticals:</strong> Drug formulation and stability studies</li>
                  <li><strong>Environmental Science:</strong> Predicting evaporation rates and air pollution</li>
                  <li><strong>Food Processing:</strong> Freeze-drying and vacuum evaporation processes</li>
                  <li><strong>Meteorology:</strong> Understanding humidity and dew point calculations</li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-purple-50 border-purple-200">
              <CardContent className="pt-6">
                <p className="text-sm text-purple-800">
                  <strong>Disclaimer:</strong> Vapor pressure values are calculated using empirical Antoine constants 
                  and are valid only within specified temperature ranges. The accuracy depends on the quality of the 
                  constants used. For critical applications, consult reliable thermodynamic data sources and verify 
                  results with experimental measurements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
