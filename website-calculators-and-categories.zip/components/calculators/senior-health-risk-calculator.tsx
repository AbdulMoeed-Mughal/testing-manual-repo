"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  UserRound,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Heart,
  Activity,
  Droplet,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type UnitSystem = "metric" | "imperial"
type GlucoseUnit = "mg/dL" | "mmol/L"
type CholesterolUnit = "mg/dL" | "mmol/L"

interface RiskFactor {
  name: string
  status: "normal" | "elevated" | "high"
  value: string
  points: number
}

interface SeniorHealthResult {
  riskCategory: string
  riskPercentage: number
  color: string
  bgColor: string
  riskFactors: RiskFactor[]
  totalPoints: number
  maxPoints: number
  recommendations: string[]
}

export function SeniorHealthRiskCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [glucoseUnit, setGlucoseUnit] = useState<GlucoseUnit>("mg/dL")
  const [cholesterolUnit, setCholesterolUnit] = useState<CholesterolUnit>("mg/dL")

  // Basic inputs
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<string>("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")

  // Clinical inputs
  const [systolic, setSystolic] = useState("")
  const [diastolic, setDiastolic] = useState("")
  const [glucose, setGlucose] = useState("")
  const [totalCholesterol, setTotalCholesterol] = useState("")
  const [ldl, setLdl] = useState("")
  const [hdl, setHdl] = useState("")
  const [triglycerides, setTriglycerides] = useState("")

  // Lifestyle inputs
  const [activityLevel, setActivityLevel] = useState<string>("")

  // Optional inputs
  const [showOptional, setShowOptional] = useState(false)
  const [smokingStatus, setSmokingStatus] = useState(false)
  const [familyHistory, setFamilyHistory] = useState(false)

  const [result, setResult] = useState<SeniorHealthResult | null>(null)
  const [showDetails, setShowDetails] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateRisk = () => {
    setError("")
    setResult(null)

    // Validate required inputs
    const ageNum = Number.parseFloat(age)
    if (isNaN(ageNum) || ageNum < 50 || ageNum > 120) {
      setError("Please enter a valid age between 50 and 120 years")
      return
    }

    if (!gender) {
      setError("Please select your gender")
      return
    }

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight")
      return
    }

    let heightInMeters: number
    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height")
        return
      }
      heightInMeters = heightCmNum / 100
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height")
        return
      }
      const totalInches = feet * 12 + inches
      heightInMeters = totalInches * 0.0254
    }

    const systolicNum = Number.parseFloat(systolic)
    const diastolicNum = Number.parseFloat(diastolic)
    if (
      isNaN(systolicNum) ||
      isNaN(diastolicNum) ||
      systolicNum < 70 ||
      systolicNum > 250 ||
      diastolicNum < 40 ||
      diastolicNum > 150
    ) {
      setError("Please enter valid blood pressure values (systolic: 70-250, diastolic: 40-150)")
      return
    }

    let glucoseNum = Number.parseFloat(glucose)
    if (isNaN(glucoseNum) || glucoseNum <= 0) {
      setError("Please enter a valid fasting glucose value")
      return
    }
    // Convert to mg/dL if needed
    if (glucoseUnit === "mmol/L") {
      glucoseNum = glucoseNum * 18.0182
    }

    let totalCholNum = Number.parseFloat(totalCholesterol)
    let ldlNum = Number.parseFloat(ldl)
    let hdlNum = Number.parseFloat(hdl)
    let triglyceridesNum = Number.parseFloat(triglycerides)

    if (isNaN(totalCholNum) || isNaN(ldlNum) || isNaN(hdlNum) || isNaN(triglyceridesNum)) {
      setError("Please enter valid cholesterol values")
      return
    }

    // Convert cholesterol to mg/dL if needed
    if (cholesterolUnit === "mmol/L") {
      totalCholNum = totalCholNum * 38.67
      ldlNum = ldlNum * 38.67
      hdlNum = hdlNum * 38.67
      triglyceridesNum = triglyceridesNum * 88.57
    }

    if (!activityLevel) {
      setError("Please select your physical activity level")
      return
    }

    // Calculate BMI
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum
    const bmi = weightInKg / (heightInMeters * heightInMeters)

    // Initialize risk factors and points
    const riskFactors: RiskFactor[] = []
    let totalPoints = 0
    const maxPoints = 100

    // Age risk (0-15 points)
    let agePoints = 0
    let ageStatus: "normal" | "elevated" | "high" = "normal"
    if (ageNum >= 75) {
      agePoints = 15
      ageStatus = "high"
    } else if (ageNum >= 65) {
      agePoints = 10
      ageStatus = "elevated"
    } else {
      agePoints = 5
      ageStatus = "normal"
    }
    totalPoints += agePoints
    riskFactors.push({
      name: "Age",
      status: ageStatus,
      value: `${ageNum} years`,
      points: agePoints,
    })

    // BMI risk (0-15 points)
    let bmiPoints = 0
    let bmiStatus: "normal" | "elevated" | "high" = "normal"
    if (bmi >= 30) {
      bmiPoints = 15
      bmiStatus = "high"
    } else if (bmi >= 25) {
      bmiPoints = 10
      bmiStatus = "elevated"
    } else if (bmi < 18.5) {
      bmiPoints = 8
      bmiStatus = "elevated"
    } else {
      bmiPoints = 0
      bmiStatus = "normal"
    }
    totalPoints += bmiPoints
    riskFactors.push({
      name: "BMI",
      status: bmiStatus,
      value: `${bmi.toFixed(1)} kg/m²`,
      points: bmiPoints,
    })

    // Blood pressure risk (0-20 points)
    let bpPoints = 0
    let bpStatus: "normal" | "elevated" | "high" = "normal"
    if (systolicNum >= 180 || diastolicNum >= 120) {
      bpPoints = 20
      bpStatus = "high"
    } else if (systolicNum >= 140 || diastolicNum >= 90) {
      bpPoints = 15
      bpStatus = "high"
    } else if (systolicNum >= 130 || diastolicNum >= 80) {
      bpPoints = 10
      bpStatus = "elevated"
    } else if (systolicNum >= 120) {
      bpPoints = 5
      bpStatus = "elevated"
    } else {
      bpPoints = 0
      bpStatus = "normal"
    }
    totalPoints += bpPoints
    riskFactors.push({
      name: "Blood Pressure",
      status: bpStatus,
      value: `${systolicNum}/${diastolicNum} mmHg`,
      points: bpPoints,
    })

    // Glucose risk (0-15 points)
    let glucosePoints = 0
    let glucoseStatus: "normal" | "elevated" | "high" = "normal"
    if (glucoseNum >= 126) {
      glucosePoints = 15
      glucoseStatus = "high"
    } else if (glucoseNum >= 100) {
      glucosePoints = 10
      glucoseStatus = "elevated"
    } else {
      glucosePoints = 0
      glucoseStatus = "normal"
    }
    totalPoints += glucosePoints
    riskFactors.push({
      name: "Fasting Glucose",
      status: glucoseStatus,
      value: `${glucoseNum.toFixed(0)} mg/dL`,
      points: glucosePoints,
    })

    // Total cholesterol risk (0-10 points)
    let cholPoints = 0
    let cholStatus: "normal" | "elevated" | "high" = "normal"
    if (totalCholNum >= 240) {
      cholPoints = 10
      cholStatus = "high"
    } else if (totalCholNum >= 200) {
      cholPoints = 5
      cholStatus = "elevated"
    } else {
      cholPoints = 0
      cholStatus = "normal"
    }
    totalPoints += cholPoints
    riskFactors.push({
      name: "Total Cholesterol",
      status: cholStatus,
      value: `${totalCholNum.toFixed(0)} mg/dL`,
      points: cholPoints,
    })

    // LDL risk (0-10 points)
    let ldlPoints = 0
    let ldlStatus: "normal" | "elevated" | "high" = "normal"
    if (ldlNum >= 160) {
      ldlPoints = 10
      ldlStatus = "high"
    } else if (ldlNum >= 130) {
      ldlPoints = 5
      ldlStatus = "elevated"
    } else {
      ldlPoints = 0
      ldlStatus = "normal"
    }
    totalPoints += ldlPoints
    riskFactors.push({
      name: "LDL Cholesterol",
      status: ldlStatus,
      value: `${ldlNum.toFixed(0)} mg/dL`,
      points: ldlPoints,
    })

    // HDL risk (0-10 points) - lower is worse
    let hdlPoints = 0
    let hdlStatus: "normal" | "elevated" | "high" = "normal"
    const hdlThreshold = gender === "male" ? 40 : 50
    if (hdlNum < hdlThreshold) {
      hdlPoints = 10
      hdlStatus = "high"
    } else if (hdlNum < 60) {
      hdlPoints = 5
      hdlStatus = "elevated"
    } else {
      hdlPoints = 0
      hdlStatus = "normal"
    }
    totalPoints += hdlPoints
    riskFactors.push({
      name: "HDL Cholesterol",
      status: hdlStatus,
      value: `${hdlNum.toFixed(0)} mg/dL`,
      points: hdlPoints,
    })

    // Triglycerides risk (0-10 points)
    let trigPoints = 0
    let trigStatus: "normal" | "elevated" | "high" = "normal"
    if (triglyceridesNum >= 200) {
      trigPoints = 10
      trigStatus = "high"
    } else if (triglyceridesNum >= 150) {
      trigPoints = 5
      trigStatus = "elevated"
    } else {
      trigPoints = 0
      trigStatus = "normal"
    }
    totalPoints += trigPoints
    riskFactors.push({
      name: "Triglycerides",
      status: trigStatus,
      value: `${triglyceridesNum.toFixed(0)} mg/dL`,
      points: trigPoints,
    })

    // Activity level risk (0-10 points)
    let activityPoints = 0
    let activityStatus: "normal" | "elevated" | "high" = "normal"
    if (activityLevel === "sedentary") {
      activityPoints = 10
      activityStatus = "high"
    } else if (activityLevel === "light") {
      activityPoints = 5
      activityStatus = "elevated"
    } else {
      activityPoints = 0
      activityStatus = "normal"
    }
    totalPoints += activityPoints
    riskFactors.push({
      name: "Physical Activity",
      status: activityStatus,
      value: activityLevel.charAt(0).toUpperCase() + activityLevel.slice(1),
      points: activityPoints,
    })

    // Optional: Smoking (0-10 points)
    if (showOptional && smokingStatus) {
      totalPoints += 10
      riskFactors.push({
        name: "Smoking",
        status: "high",
        value: "Yes",
        points: 10,
      })
    }

    // Optional: Family history (0-5 points)
    if (showOptional && familyHistory) {
      totalPoints += 5
      riskFactors.push({
        name: "Family History",
        status: "elevated",
        value: "Yes",
        points: 5,
      })
    }

    // Calculate risk percentage and category
    const riskPercentage = Math.min((totalPoints / maxPoints) * 100, 100)

    let riskCategory: string
    let color: string
    let bgColor: string

    if (riskPercentage < 25) {
      riskCategory = "Low Risk"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (riskPercentage < 50) {
      riskCategory = "Moderate Risk"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (riskPercentage < 75) {
      riskCategory = "High Risk"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      riskCategory = "Very High Risk"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    // Generate recommendations
    const recommendations: string[] = []

    if (bpStatus !== "normal") {
      recommendations.push("Monitor blood pressure regularly and consult your doctor about management strategies")
    }
    if (glucoseStatus !== "normal") {
      recommendations.push("Consider glucose monitoring and dietary modifications to manage blood sugar levels")
    }
    if (cholStatus !== "normal" || ldlStatus !== "normal") {
      recommendations.push("Discuss cholesterol management options with your healthcare provider")
    }
    if (hdlStatus !== "normal") {
      recommendations.push("Increase aerobic exercise to help raise HDL cholesterol levels")
    }
    if (trigStatus !== "normal") {
      recommendations.push("Reduce refined carbohydrates and increase omega-3 fatty acid intake")
    }
    if (bmiStatus !== "normal") {
      recommendations.push("Work with a healthcare provider on a safe weight management plan")
    }
    if (activityStatus !== "normal") {
      recommendations.push("Gradually increase physical activity with doctor approval")
    }
    if (showOptional && smokingStatus) {
      recommendations.push("Smoking cessation is strongly recommended - ask about support programs")
    }

    if (recommendations.length === 0) {
      recommendations.push("Continue maintaining your healthy lifestyle habits")
      recommendations.push("Schedule regular health check-ups with your healthcare provider")
    }

    setResult({
      riskCategory,
      riskPercentage,
      color,
      bgColor,
      riskFactors,
      totalPoints,
      maxPoints,
      recommendations,
    })
  }

  const handleReset = () => {
    setAge("")
    setGender("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setSystolic("")
    setDiastolic("")
    setGlucose("")
    setTotalCholesterol("")
    setLdl("")
    setHdl("")
    setTriglycerides("")
    setActivityLevel("")
    setSmokingStatus(false)
    setFamilyHistory(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Senior Health Risk Assessment: ${result.riskCategory} (${result.riskPercentage.toFixed(0)}%)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Senior Health Risk Assessment",
          text: `My Senior Health Risk Assessment: ${result.riskCategory} (${result.riskPercentage.toFixed(0)}%)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
  }

  const getStatusColor = (status: "normal" | "elevated" | "high") => {
    switch (status) {
      case "normal":
        return "bg-green-50 border-green-200 text-green-700"
      case "elevated":
        return "bg-yellow-50 border-yellow-200 text-yellow-700"
      case "high":
        return "bg-red-50 border-red-200 text-red-700"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <UserRound className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Senior Health Risk Calculator</CardTitle>
                    <CardDescription>Assess health risks for older adults</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Basic Information */}
                <div className="space-y-3">
                  <h3 className="font-medium text-sm text-muted-foreground">Basic Information</h3>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="age">Age (years)</Label>
                      <Input
                        id="age"
                        type="number"
                        placeholder="50-120"
                        value={age}
                        onChange={(e) => setAge(e.target.value)}
                        min="50"
                        max="120"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="gender">Gender</Label>
                      <Select value={gender} onValueChange={setGender}>
                        <SelectTrigger id="gender">
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder={`Enter weight`}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>

                  {unitSystem === "metric" ? (
                    <div className="space-y-2">
                      <Label htmlFor="height">Height (cm)</Label>
                      <Input
                        id="height"
                        type="number"
                        placeholder="Enter height"
                        value={heightCm}
                        onChange={(e) => setHeightCm(e.target.value)}
                        min="0"
                      />
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label>Height</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Blood Pressure */}
                <div className="space-y-3">
                  <h3 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                    <Heart className="h-4 w-4" />
                    Blood Pressure (mmHg)
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="systolic">Systolic</Label>
                      <Input
                        id="systolic"
                        type="number"
                        placeholder="120"
                        value={systolic}
                        onChange={(e) => setSystolic(e.target.value)}
                        min="70"
                        max="250"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="diastolic">Diastolic</Label>
                      <Input
                        id="diastolic"
                        type="number"
                        placeholder="80"
                        value={diastolic}
                        onChange={(e) => setDiastolic(e.target.value)}
                        min="40"
                        max="150"
                      />
                    </div>
                  </div>
                </div>

                {/* Glucose */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                      <Droplet className="h-4 w-4" />
                      Fasting Blood Glucose
                    </h3>
                    <Select value={glucoseUnit} onValueChange={(v) => setGlucoseUnit(v as GlucoseUnit)}>
                      <SelectTrigger className="w-24 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mg/dL">mg/dL</SelectItem>
                        <SelectItem value="mmol/L">mmol/L</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Input
                    type="number"
                    placeholder={glucoseUnit === "mg/dL" ? "70-126" : "3.9-7.0"}
                    value={glucose}
                    onChange={(e) => setGlucose(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Cholesterol */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                      <Activity className="h-4 w-4" />
                      Cholesterol Levels
                    </h3>
                    <Select value={cholesterolUnit} onValueChange={(v) => setCholesterolUnit(v as CholesterolUnit)}>
                      <SelectTrigger className="w-24 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mg/dL">mg/dL</SelectItem>
                        <SelectItem value="mmol/L">mmol/L</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="totalCholesterol">Total</Label>
                      <Input
                        id="totalCholesterol"
                        type="number"
                        placeholder={cholesterolUnit === "mg/dL" ? "200" : "5.2"}
                        value={totalCholesterol}
                        onChange={(e) => setTotalCholesterol(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ldl">LDL</Label>
                      <Input
                        id="ldl"
                        type="number"
                        placeholder={cholesterolUnit === "mg/dL" ? "100" : "2.6"}
                        value={ldl}
                        onChange={(e) => setLdl(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="hdl">HDL</Label>
                      <Input
                        id="hdl"
                        type="number"
                        placeholder={cholesterolUnit === "mg/dL" ? "60" : "1.6"}
                        value={hdl}
                        onChange={(e) => setHdl(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="triglycerides">Triglycerides</Label>
                      <Input
                        id="triglycerides"
                        type="number"
                        placeholder={cholesterolUnit === "mg/dL" ? "150" : "1.7"}
                        value={triglycerides}
                        onChange={(e) => setTriglycerides(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                </div>

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label htmlFor="activity">Physical Activity Level</Label>
                  <Select value={activityLevel} onValueChange={setActivityLevel}>
                    <SelectTrigger id="activity">
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary (little to no exercise)</SelectItem>
                      <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                      <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                      <SelectItem value="active">Active (6-7 days/week)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Optional Inputs */}
                <div className="space-y-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowOptional(!showOptional)}
                    className="flex items-center gap-2 text-sm font-medium text-primary hover:underline"
                  >
                    {showOptional ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    Optional: Lifestyle Factors
                  </button>

                  {showOptional && (
                    <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="smoking" className="cursor-pointer">
                          Current Smoker
                        </Label>
                        <Switch id="smoking" checked={smokingStatus} onCheckedChange={setSmokingStatus} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="family" className="cursor-pointer">
                          Family History of Chronic Disease
                        </Label>
                        <Switch id="family" checked={familyHistory} onCheckedChange={setFamilyHistory} />
                      </div>
                    </div>
                  )}
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateRisk} className="w-full" size="lg">
                  Calculate Health Risk
                </Button>

                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Overall Health Risk</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{result.riskPercentage.toFixed(0)}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.riskCategory}</p>
                    </div>

                    {/* Risk Gauge */}
                    <div className="mt-4 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-500 ${
                          result.riskPercentage < 25
                            ? "bg-green-500"
                            : result.riskPercentage < 50
                              ? "bg-yellow-500"
                              : result.riskPercentage < 75
                                ? "bg-orange-500"
                                : "bg-red-500"
                        }`}
                        style={{ width: `${result.riskPercentage}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>Low</span>
                      <span>Moderate</span>
                      <span>High</span>
                      <span>Very High</span>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="flex items-center justify-center gap-1 w-full mt-4 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Risk Factors
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 space-y-2">
                        {result.riskFactors.map((factor, index) => (
                          <div
                            key={index}
                            className={`flex items-center justify-between p-2 rounded-lg border ${getStatusColor(factor.status)}`}
                          >
                            <div>
                              <span className="font-medium text-sm">{factor.name}</span>
                              <span className="text-xs ml-2 opacity-75">{factor.value}</span>
                            </div>
                            <span className="text-xs font-medium">+{factor.points} pts</span>
                          </div>
                        ))}
                        <div className="pt-2 border-t">
                          <div className="flex justify-between text-sm">
                            <span className="font-medium">Total Risk Score</span>
                            <span className="font-bold">
                              {result.totalPoints} / {result.maxPoints}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Recommendations */}
                    {result.recommendations.length > 0 && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg">
                        <h4 className="font-medium text-sm mb-2">Recommendations:</h4>
                        <ul className="space-y-1">
                          {result.recommendations.map((rec, index) => (
                            <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                              <span className="text-primary mt-0.5">•</span>
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Risk Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low Risk</span>
                      <span className="text-sm text-green-600">{"< 25%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Risk</span>
                      <span className="text-sm text-yellow-600">25 – 49%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">High Risk</span>
                      <span className="text-sm text-orange-600">50 – 74%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very High Risk</span>
                      <span className="text-sm text-red-600">≥ 75%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Risk Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p>
                      <strong>Blood Pressure:</strong> Normal is below 120/80 mmHg. Elevated readings increase
                      cardiovascular risk.
                    </p>
                    <p>
                      <strong>Blood Glucose:</strong> Fasting levels above 100 mg/dL may indicate prediabetes or
                      diabetes.
                    </p>
                    <p>
                      <strong>Cholesterol:</strong> High LDL and low HDL levels contribute to heart disease risk.
                    </p>
                    <p>
                      <strong>Physical Activity:</strong> Regular exercise significantly reduces chronic disease risk.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Senior Health Risk Assessment</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  As we age, our bodies undergo various changes that can increase susceptibility to chronic diseases
                  such as cardiovascular disease, diabetes, and metabolic syndrome. A comprehensive health risk
                  assessment helps identify modifiable risk factors early, allowing for preventive interventions that
                  can significantly improve quality of life and longevity.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator evaluates multiple clinical and lifestyle factors commonly associated with health
                  risks in older adults. By analyzing blood pressure, blood glucose, cholesterol levels, BMI, and
                  physical activity patterns, it provides an estimate of overall health risk and personalized
                  recommendations for improvement.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Cardiovascular Health in Seniors</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Cardiovascular disease remains the leading cause of death in adults over 65. Key risk factors include
                  high blood pressure (hypertension), elevated cholesterol, diabetes, obesity, and physical inactivity.
                  Managing these factors through lifestyle modifications and medical treatment when necessary can
                  significantly reduce the risk of heart attack, stroke, and other cardiovascular events.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Blood pressure naturally tends to increase with age due to arterial stiffening. However, maintaining
                  blood pressure below 130/80 mmHg is associated with better outcomes. Regular monitoring and working
                  with healthcare providers to manage elevated readings is essential for cardiovascular health.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>The Importance of Physical Activity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Regular physical activity is one of the most effective ways to reduce health risks in older adults.
                  The CDC recommends at least 150 minutes of moderate-intensity aerobic activity per week, along with
                  muscle-strengthening activities on 2 or more days per week. Even light activity is better than being
                  sedentary.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Benefits of regular exercise for seniors include improved cardiovascular health, better blood sugar
                  control, stronger bones and muscles, enhanced balance and coordination, reduced risk of falls, better
                  mental health, and improved cognitive function. Always consult with a healthcare provider before
                  starting a new exercise program.
                </p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-800 text-sm leading-relaxed">
                  This health risk assessment is an educational tool that provides estimates based on input data and
                  standard clinical guidelines. It is not a substitute for professional medical evaluation. Results
                  should be discussed with a qualified healthcare provider who can consider your complete medical
                  history, perform appropriate examinations, and provide personalized recommendations. If you have
                  concerns about your health or any of the risk factors assessed, please consult your doctor or
                  healthcare provider promptly.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
