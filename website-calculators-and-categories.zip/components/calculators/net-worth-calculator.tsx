"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Wallet,
  Info,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Plus,
  Trash2,
  Building,
  Car,
  Landmark,
  PiggyBank,
  CreditCard,
  Home,
  Briefcase,
  Scale,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface AssetItem {
  id: string
  name: string
  value: string
  category: string
}

interface LiabilityItem {
  id: string
  name: string
  value: string
  category: string
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
]

const assetCategories = [
  { id: "cash", name: "Cash & Bank Accounts", icon: PiggyBank },
  { id: "investments", name: "Investments", icon: TrendingUp },
  { id: "real-estate", name: "Real Estate", icon: Building },
  { id: "vehicles", name: "Vehicles", icon: Car },
  { id: "other", name: "Other Assets", icon: Briefcase },
]

const liabilityCategories = [
  { id: "mortgage", name: "Mortgage/Home Loan", icon: Home },
  { id: "car-loan", name: "Car Loan", icon: Car },
  { id: "personal-loan", name: "Personal Loan", icon: Landmark },
  { id: "credit-card", name: "Credit Card Debt", icon: CreditCard },
  { id: "other", name: "Other Liabilities", icon: AlertTriangle },
]

export function NetWorthCalculator() {
  const [currency, setCurrency] = useState("USD")
  const [assets, setAssets] = useState<AssetItem[]>([
    { id: "1", name: "Savings Account", value: "", category: "cash" },
    { id: "2", name: "Checking Account", value: "", category: "cash" },
  ])
  const [liabilities, setLiabilities] = useState<LiabilityItem[]>([
    { id: "1", name: "Mortgage", value: "", category: "mortgage" },
    { id: "2", name: "Credit Card", value: "", category: "credit-card" },
  ])
  const [copied, setCopied] = useState(false)
  const [showResult, setShowResult] = useState(false)

  const currencySymbol = currencies.find((c) => c.code === currency)?.symbol || "$"

  const formatCurrency = (value: number): string => {
    if (currency === "INR") {
      if (value >= 10000000) return `${currencySymbol}${(value / 10000000).toFixed(2)} Cr`
      if (value >= 100000) return `${currencySymbol}${(value / 100000).toFixed(2)} L`
      return `${currencySymbol}${value.toLocaleString("en-IN")}`
    }
    if (value >= 1000000000) return `${currencySymbol}${(value / 1000000000).toFixed(2)}B`
    if (value >= 1000000) return `${currencySymbol}${(value / 1000000).toFixed(2)}M`
    if (value >= 1000) return `${currencySymbol}${(value / 1000).toFixed(2)}K`
    return `${currencySymbol}${value.toLocaleString()}`
  }

  const totalAssets = assets.reduce((sum, asset) => {
    const value = Number.parseFloat(asset.value) || 0
    return sum + value
  }, 0)

  const totalLiabilities = liabilities.reduce((sum, liability) => {
    const value = Number.parseFloat(liability.value) || 0
    return sum + value
  }, 0)

  const netWorth = totalAssets - totalLiabilities
  const isPositive = netWorth >= 0
  const assetPercentage = totalAssets > 0 ? (totalAssets / (totalAssets + totalLiabilities)) * 100 : 50

  const addAsset = () => {
    const newId = Date.now().toString()
    setAssets([...assets, { id: newId, name: "", value: "", category: "other" }])
  }

  const removeAsset = (id: string) => {
    if (assets.length > 1) {
      setAssets(assets.filter((a) => a.id !== id))
    }
  }

  const updateAsset = (id: string, field: "name" | "value" | "category", newValue: string) => {
    setAssets(assets.map((a) => (a.id === id ? { ...a, [field]: newValue } : a)))
  }

  const addLiability = () => {
    const newId = Date.now().toString()
    setLiabilities([...liabilities, { id: newId, name: "", value: "", category: "other" }])
  }

  const removeLiability = (id: string) => {
    if (liabilities.length > 1) {
      setLiabilities(liabilities.filter((l) => l.id !== id))
    }
  }

  const updateLiability = (id: string, field: "name" | "value" | "category", newValue: string) => {
    setLiabilities(liabilities.map((l) => (l.id === id ? { ...l, [field]: newValue } : l)))
  }

  const calculateNetWorth = () => {
    setShowResult(true)
  }

  const handleReset = () => {
    setAssets([
      { id: "1", name: "Savings Account", value: "", category: "cash" },
      { id: "2", name: "Checking Account", value: "", category: "cash" },
    ])
    setLiabilities([
      { id: "1", name: "Mortgage", value: "", category: "mortgage" },
      { id: "2", name: "Credit Card", value: "", category: "credit-card" },
    ])
    setCopied(false)
    setShowResult(false)
  }

  const handleCopy = async () => {
    const text = `My Net Worth: ${formatCurrency(Math.abs(netWorth))} (${isPositive ? "Positive" : "Negative"})\nTotal Assets: ${formatCurrency(totalAssets)}\nTotal Liabilities: ${formatCurrency(totalLiabilities)}`
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "My Net Worth",
          text: `I calculated my net worth using CalcHub! My net worth is ${formatCurrency(Math.abs(netWorth))} (${isPositive ? "Positive" : "Negative"})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Wallet className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Net Worth Calculator</CardTitle>
                    <CardDescription>Track your assets and liabilities</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    {currencies.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.symbol})
                      </option>
                    ))}
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Assets Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2 text-green-700">
                      <TrendingUp className="h-4 w-4" />
                      Assets (What You Own)
                    </Label>
                    <Button variant="ghost" size="sm" onClick={addAsset} className="h-7 text-xs">
                      <Plus className="h-3 w-3 mr-1" />
                      Add
                    </Button>
                  </div>

                  {assets.map((asset) => (
                    <div key={asset.id} className="flex gap-2 items-center">
                      <Input
                        placeholder="Name"
                        value={asset.name}
                        onChange={(e) => updateAsset(asset.id, "name", e.target.value)}
                        className="h-9 text-sm flex-1"
                      />
                      <div className="relative w-28">
                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                          {currencySymbol}
                        </span>
                        <Input
                          type="number"
                          placeholder="0"
                          value={asset.value}
                          onChange={(e) => updateAsset(asset.id, "value", e.target.value)}
                          className="h-9 pl-6 text-sm"
                          min="0"
                        />
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeAsset(asset.id)}
                        disabled={assets.length <= 1}
                        className="h-9 w-9 p-0 text-muted-foreground hover:text-red-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}

                  <div className="flex justify-between text-sm font-medium text-green-600 pt-2 border-t">
                    <span>Total Assets</span>
                    <span>{formatCurrency(totalAssets)}</span>
                  </div>
                </div>

                {/* Liabilities Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2 text-red-700">
                      <TrendingDown className="h-4 w-4" />
                      Liabilities (What You Owe)
                    </Label>
                    <Button variant="ghost" size="sm" onClick={addLiability} className="h-7 text-xs">
                      <Plus className="h-3 w-3 mr-1" />
                      Add
                    </Button>
                  </div>

                  {liabilities.map((liability) => (
                    <div key={liability.id} className="flex gap-2 items-center">
                      <Input
                        placeholder="Name"
                        value={liability.name}
                        onChange={(e) => updateLiability(liability.id, "name", e.target.value)}
                        className="h-9 text-sm flex-1"
                      />
                      <div className="relative w-28">
                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                          {currencySymbol}
                        </span>
                        <Input
                          type="number"
                          placeholder="0"
                          value={liability.value}
                          onChange={(e) => updateLiability(liability.id, "value", e.target.value)}
                          className="h-9 pl-6 text-sm"
                          min="0"
                        />
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeLiability(liability.id)}
                        disabled={liabilities.length <= 1}
                        className="h-9 w-9 p-0 text-muted-foreground hover:text-red-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}

                  <div className="flex justify-between text-sm font-medium text-red-600 pt-2 border-t">
                    <span>Total Liabilities</span>
                    <span>{formatCurrency(totalLiabilities)}</span>
                  </div>
                </div>

                {/* Calculate Button */}
                <Button onClick={calculateNetWorth} className="w-full" size="lg">
                  Calculate Net Worth
                </Button>

                {/* Result */}
                {showResult && (
                  <div
                    className={`p-4 rounded-xl border-2 ${isPositive ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Net Worth</p>
                      <p
                        className={`text-4xl sm:text-5xl font-bold ${isPositive ? "text-green-600" : "text-red-600"} mb-2`}
                      >
                        {!isPositive && "-"}
                        {formatCurrency(Math.abs(netWorth))}
                      </p>
                      <p className={`text-lg font-semibold ${isPositive ? "text-green-600" : "text-red-600"}`}>
                        {isPositive ? "Positive Net Worth" : "Negative Net Worth"}
                      </p>
                    </div>

                    {/* Progress Bar */}
                    <div className="mt-4">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-green-600">Assets</span>
                        <span className="text-red-600">Liabilities</span>
                      </div>
                      <div className="h-3 bg-red-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-500 rounded-full transition-all duration-500"
                          style={{ width: `${Math.min(Math.max(assetPercentage, 0), 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Warning for negative */}
                    {!isPositive && (
                      <div className="flex items-start gap-2 p-3 bg-red-100 rounded-lg mt-4">
                        <AlertTriangle className="h-4 w-4 text-red-600 flex-shrink-0 mt-0.5" />
                        <p className="text-xs text-red-700">
                          Your liabilities exceed your assets. Consider a debt payoff plan.
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Net Worth Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Net Worth = Total Assets − Total Liabilities</p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-3">
                    Your net worth is simply what you own minus what you owe. A positive number means you have more
                    assets than debts.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Assets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg">
                      <PiggyBank className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Cash & Bank Accounts</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg">
                      <TrendingUp className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Investments & Retirement</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg">
                      <Building className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Real Estate & Property</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg">
                      <Car className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Vehicles & Personal Property</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Liabilities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 p-2 bg-red-50 rounded-lg">
                      <Home className="h-4 w-4 text-red-600" />
                      <span className="text-sm">Mortgage & Home Loans</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-red-50 rounded-lg">
                      <Car className="h-4 w-4 text-red-600" />
                      <span className="text-sm">Auto Loans</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-red-50 rounded-lg">
                      <CreditCard className="h-4 w-4 text-red-600" />
                      <span className="text-sm">Credit Card Debt</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-red-50 rounded-lg">
                      <Landmark className="h-4 w-4 text-red-600" />
                      <span className="text-sm">Student & Personal Loans</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Net Worth?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Net worth is a financial metric that represents the difference between what you own (assets) and what
                  you owe (liabilities). It provides a snapshot of your overall financial health at a specific point in
                  time. Think of it as your personal balance sheet – a comprehensive view of where you stand
                  financially. Unlike income, which shows what you earn, net worth reveals what you've actually
                  accumulated over time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Tracking your net worth regularly is one of the most powerful habits for building wealth. It helps you
                  understand whether you're moving forward financially or falling behind. Many financial experts
                  recommend calculating your net worth at least quarterly to monitor progress toward your financial
                  goals. This simple metric cuts through the noise of day-to-day finances and shows the bigger picture.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Your Assets</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Assets are everything you own that has monetary value. They can be divided into liquid assets (easily
                  converted to cash) and illiquid assets (harder to sell quickly). Liquid assets include checking and
                  savings accounts, money market funds, and publicly traded stocks and bonds. These are important
                  because they provide financial flexibility and emergency funds when needed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Illiquid assets include real estate, vehicles, business interests, retirement accounts, and valuable
                  personal property like jewelry or art. While these contribute significantly to net worth, they can't
                  be quickly converted to cash without potentially losing value. When calculating net worth, use
                  realistic market values for these assets – what someone would actually pay today, not what you hope
                  they're worth or what you originally paid.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Your Liabilities</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Liabilities represent all your financial obligations – money you owe to others. Common liabilities
                  include mortgages, car loans, student loans, credit card balances, personal loans, and any other
                  debts. Not all debt is created equal: a mortgage on an appreciating property is often considered "good
                  debt," while high-interest credit card debt is typically "bad debt" that erodes wealth.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When listing liabilities, include the current balance owed, not the original loan amount. For credit
                  cards, use your current statement balance. Understanding your liabilities helps you prioritize debt
                  repayment. Generally, paying off high-interest debt first (the "avalanche method") saves the most
                  money, though some prefer paying off smaller debts first (the "snowball method") for psychological
                  wins.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Building Your Net Worth</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Growing your net worth comes down to two fundamental strategies: increasing assets and decreasing
                  liabilities. On the asset side, focus on saving consistently, investing wisely, and allowing compound
                  growth to work in your favor. Even small, regular contributions to investment accounts can grow
                  substantially over time. Maximize employer retirement matches – they're essentially free money added
                  to your assets.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  On the liability side, develop a systematic debt payoff plan. Avoid taking on new consumer debt, and
                  when you do borrow, ensure it's for appreciating assets or income-generating purposes. A useful
                  benchmark is the "net worth by age" rule: aim to have a net worth equal to your annual salary by age
                  30, twice your salary by 40, and so on. Remember, building significant net worth is a marathon, not a
                  sprint – consistency matters more than perfection.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
