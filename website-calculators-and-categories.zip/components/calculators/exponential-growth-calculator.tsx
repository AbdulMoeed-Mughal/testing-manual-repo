"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  Calculator,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type CompoundingFrequency = "continuous" | "yearly" | "semi-annually" | "quarterly" | "monthly" | "daily"

interface GrowthResult {
  finalValue: number
  growthFactor: number
  absoluteIncrease: number
  percentageIncrease: number
  schedule: { period: number; value: number }[]
}

export function ExponentialGrowthCalculator() {
  const [initialValue, setInitialValue] = useState("")
  const [growthRate, setGrowthRate] = useState("")
  const [timePeriod, setTimePeriod] = useState("")
  const [compounding, setCompounding] = useState<CompoundingFrequency>("continuous")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<GrowthResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSchedule, setShowSchedule] = useState(false)

  const getCompoundingPeriods = (freq: CompoundingFrequency): number => {
    switch (freq) {
      case "continuous":
        return 0
      case "yearly":
        return 1
      case "semi-annually":
        return 2
      case "quarterly":
        return 4
      case "monthly":
        return 12
      case "daily":
        return 365
    }
  }

  const calculateGrowth = () => {
    setError("")
    setResult(null)

    const P0 = Number.parseFloat(initialValue)
    const r = Number.parseFloat(growthRate) / 100
    const t = Number.parseFloat(timePeriod)

    if (isNaN(P0) || P0 <= 0) {
      setError("Please enter a valid initial value greater than 0")
      return
    }
    if (isNaN(r)) {
      setError("Please enter a valid growth rate")
      return
    }
    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid time period greater than 0")
      return
    }

    let finalValue: number
    const n = getCompoundingPeriods(compounding)

    if (compounding === "continuous") {
      finalValue = P0 * Math.exp(r * t)
    } else {
      finalValue = P0 * Math.pow(1 + r / n, n * t)
    }

    const growthFactor = finalValue / P0
    const absoluteIncrease = finalValue - P0
    const percentageIncrease = ((finalValue - P0) / P0) * 100

    // Generate schedule
    const schedule: { period: number; value: number }[] = []
    const maxPeriods = Math.min(Math.ceil(t), 50)
    for (let i = 0; i <= maxPeriods; i++) {
      let value: number
      if (compounding === "continuous") {
        value = P0 * Math.exp(r * i)
      } else {
        value = P0 * Math.pow(1 + r / n, n * i)
      }
      schedule.push({ period: i, value })
    }

    setResult({
      finalValue,
      growthFactor,
      absoluteIncrease,
      percentageIncrease,
      schedule,
    })
  }

  const handleReset = () => {
    setInitialValue("")
    setGrowthRate("")
    setTimePeriod("")
    setCompounding("continuous")
    setShowSteps(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowSchedule(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Exponential Growth Result:\nInitial Value: ${Number.parseFloat(initialValue).toLocaleString()}\nGrowth Rate: ${growthRate}%\nTime Period: ${timePeriod} years\nCompounding: ${compounding}\nFinal Value: ${result.finalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\nGrowth Factor: ${result.growthFactor.toFixed(4)}x\nAbsolute Increase: ${result.absoluteIncrease.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\nPercentage Increase: ${result.percentageIncrease.toFixed(2)}%`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Exponential Growth Calculation",
          text: `Initial: ${Number.parseFloat(initialValue).toLocaleString()}, Rate: ${growthRate}%, Time: ${timePeriod} years → Final: ${result.finalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${result.percentageIncrease.toFixed(2)}% increase)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num >= 1e15) return num.toExponential(4)
    return num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Exponential Growth Calculator</CardTitle>
                    <CardDescription>Calculate growth over time with various compounding</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Value */}
                <div className="space-y-2">
                  <Label htmlFor="initialValue">Initial Value (P₀)</Label>
                  <Input
                    id="initialValue"
                    type="number"
                    placeholder="e.g., 1000"
                    value={initialValue}
                    onChange={(e) => setInitialValue(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Growth Rate */}
                <div className="space-y-2">
                  <Label htmlFor="growthRate">Growth Rate (%) (r)</Label>
                  <Input
                    id="growthRate"
                    type="number"
                    placeholder="e.g., 5 for 5%"
                    value={growthRate}
                    onChange={(e) => setGrowthRate(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Time Period */}
                <div className="space-y-2">
                  <Label htmlFor="timePeriod">Time Period (years) (t)</Label>
                  <Input
                    id="timePeriod"
                    type="number"
                    placeholder="e.g., 10"
                    value={timePeriod}
                    onChange={(e) => setTimePeriod(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Compounding Frequency */}
                <div className="space-y-2">
                  <Label>Compounding Frequency</Label>
                  <Select value={compounding} onValueChange={(v) => setCompounding(v as CompoundingFrequency)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="continuous">Continuous</SelectItem>
                      <SelectItem value="yearly">Yearly (n=1)</SelectItem>
                      <SelectItem value="semi-annually">Semi-Annually (n=2)</SelectItem>
                      <SelectItem value="quarterly">Quarterly (n=4)</SelectItem>
                      <SelectItem value="monthly">Monthly (n=12)</SelectItem>
                      <SelectItem value="daily">Daily (n=365)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show step-by-step</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateGrowth} className="w-full" size="lg">
                  Calculate Growth
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Final Value</p>
                      <p className="text-4xl font-bold text-green-600 mb-2">{formatNumber(result.finalValue)}</p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-3 gap-2 mt-4">
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Growth Factor</p>
                        <p className="font-semibold text-green-600">{result.growthFactor.toFixed(4)}x</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Increase</p>
                        <p className="font-semibold text-green-600">{formatNumber(result.absoluteIncrease)}</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">% Increase</p>
                        <p className="font-semibold text-green-600">{result.percentageIncrease.toFixed(2)}%</p>
                      </div>
                    </div>

                    {/* Visual Progress Bar */}
                    <div className="mt-4">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Initial: {formatNumber(Number.parseFloat(initialValue))}</span>
                        <span>Final: {formatNumber(result.finalValue)}</span>
                      </div>
                      <div className="h-3 bg-white rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-green-400 to-green-600 rounded-full transition-all duration-500"
                          style={{
                            width: `${Math.min((Number.parseFloat(initialValue) / result.finalValue) * 100, 100)}%`,
                          }}
                        />
                      </div>
                    </div>

                    {/* Step-by-step */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg">
                        <p className="font-medium text-sm mb-2">Calculation Steps:</p>
                        <div className="text-xs space-y-1 font-mono text-muted-foreground">
                          {compounding === "continuous" ? (
                            <>
                              <p>Formula: P = P₀ × e^(r × t)</p>
                              <p>
                                P = {initialValue} × e^({(Number.parseFloat(growthRate) / 100).toFixed(4)} ×{" "}
                                {timePeriod})
                              </p>
                              <p>
                                P = {initialValue} × e^(
                                {((Number.parseFloat(growthRate) / 100) * Number.parseFloat(timePeriod)).toFixed(4)})
                              </p>
                              <p>
                                P = {initialValue} ×{" "}
                                {Math.exp(
                                  (Number.parseFloat(growthRate) / 100) * Number.parseFloat(timePeriod),
                                ).toFixed(6)}
                              </p>
                              <p className="font-semibold text-green-600">P = {formatNumber(result.finalValue)}</p>
                            </>
                          ) : (
                            <>
                              <p>Formula: P = P₀ × (1 + r/n)^(n × t)</p>
                              <p>n = {getCompoundingPeriods(compounding)} (compounding periods per year)</p>
                              <p>
                                P = {initialValue} × (1 + {(Number.parseFloat(growthRate) / 100).toFixed(4)}/
                                {getCompoundingPeriods(compounding)})^({getCompoundingPeriods(compounding)} ×{" "}
                                {timePeriod})
                              </p>
                              <p>
                                P = {initialValue} × (1 +{" "}
                                {(Number.parseFloat(growthRate) / 100 / getCompoundingPeriods(compounding)).toFixed(6)}
                                )^{getCompoundingPeriods(compounding) * Number.parseFloat(timePeriod)}
                              </p>
                              <p>
                                P = {initialValue} ×{" "}
                                {Math.pow(
                                  1 + Number.parseFloat(growthRate) / 100 / getCompoundingPeriods(compounding),
                                  getCompoundingPeriods(compounding) * Number.parseFloat(timePeriod),
                                ).toFixed(6)}
                              </p>
                              <p className="font-semibold text-green-600">P = {formatNumber(result.finalValue)}</p>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Growth Schedule */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSchedule(!showSchedule)}
                        className="flex items-center justify-between w-full p-2 bg-white rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <span className="text-sm font-medium">Growth Schedule</span>
                        {showSchedule ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                      {showSchedule && (
                        <div className="mt-2 max-h-48 overflow-y-auto">
                          <table className="w-full text-xs">
                            <thead className="bg-gray-100 sticky top-0">
                              <tr>
                                <th className="p-2 text-left">Year</th>
                                <th className="p-2 text-right">Value</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.schedule.map((row) => (
                                <tr key={row.period} className="border-b border-gray-100">
                                  <td className="p-2">{row.period}</td>
                                  <td className="p-2 text-right font-mono">{formatNumber(row.value)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Exponential Growth Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-800 text-sm mb-1">Continuous Growth</p>
                    <p className="font-mono text-blue-700 text-sm">P = P₀ × e^(r × t)</p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-800 text-sm mb-1">Discrete Compounding</p>
                    <p className="font-mono text-green-700 text-sm">P = P₀ × (1 + r/n)^(n × t)</p>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-1">
                    <p>
                      <strong>P₀</strong> = Initial value
                    </p>
                    <p>
                      <strong>r</strong> = Growth rate (as decimal)
                    </p>
                    <p>
                      <strong>t</strong> = Time in years
                    </p>
                    <p>
                      <strong>n</strong> = Compounding periods per year
                    </p>
                    <p>
                      <strong>e</strong> = Euler's number (~2.71828)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                      <p>
                        <strong>Population Growth:</strong> Modeling bacteria, human populations
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5" />
                      <p>
                        <strong>Compound Interest:</strong> Investment returns, savings accounts
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-yellow-500 mt-1.5" />
                      <p>
                        <strong>Radioactive Decay:</strong> Half-life calculations (negative rate)
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5" />
                      <p>
                        <strong>Technology:</strong> Moore's Law, viral spread
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Exponential Growth?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Exponential growth occurs when a quantity increases at a rate proportional to its current value.
                  Unlike linear growth, where a constant amount is added over time, exponential growth multiplies by a
                  constant factor. This leads to increasingly rapid growth as time progresses, creating the
                  characteristic "J-shaped" curve.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key feature of exponential growth is that the rate of change is always proportional to the current
                  size. For example, if a population doubles every year, it will grow from 100 to 200 in year one, 200
                  to 400 in year two, and 400 to 800 in year three - the absolute increase gets larger each period even
                  though the percentage increase stays constant.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter your initial value (the starting amount), growth rate (as a percentage), and time period (in
                  years). Select the compounding frequency that matches your scenario - continuous compounding is often
                  used for natural phenomena and theoretical calculations, while discrete compounding (yearly, monthly,
                  etc.) is more common for financial applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For decay scenarios (like radioactive decay or depreciation), enter a negative growth rate. The
                  calculator will show how the value decreases over time using the same exponential formula.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Exponential growth calculations are based on standard mathematical
                  formulas. Results may vary due to rounding and compounding assumptions. Real-world growth patterns may
                  deviate from pure exponential models due to limiting factors and external influences.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
