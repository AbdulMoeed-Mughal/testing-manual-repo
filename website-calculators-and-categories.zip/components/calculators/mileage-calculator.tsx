"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Gauge,
  Info,
  ChevronDown,
  ChevronUp,
  MapPin,
  Fuel,
  DollarSign,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface MileageResult {
  efficiency: number
  efficiencyUnit: string
  costPerUnit: number | null
  costUnit: string
  totalCost: number | null
  distance: number
  fuelUsed: number
}

export function MileageCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [distance, setDistance] = useState("")
  const [fuelUsed, setFuelUsed] = useState("")
  const [fuelPrice, setFuelPrice] = useState("")
  const [result, setResult] = useState<MileageResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateMileage = () => {
    setError("")
    setResult(null)

    const distanceNum = Number.parseFloat(distance)
    const fuelUsedNum = Number.parseFloat(fuelUsed)
    const fuelPriceNum = fuelPrice ? Number.parseFloat(fuelPrice) : null

    if (isNaN(distanceNum) || distanceNum <= 0) {
      setError("Please enter a valid distance greater than 0")
      return
    }

    if (isNaN(fuelUsedNum) || fuelUsedNum <= 0) {
      setError("Please enter a valid fuel amount greater than 0")
      return
    }

    if (fuelPrice && (isNaN(fuelPriceNum!) || fuelPriceNum! < 0)) {
      setError("Please enter a valid fuel price (0 or greater)")
      return
    }

    // Calculate fuel efficiency
    const efficiency = distanceNum / fuelUsedNum
    const roundedEfficiency = Math.round(efficiency * 100) / 100

    // Calculate cost per distance unit if fuel price is provided
    let costPerUnit: number | null = null
    let totalCost: number | null = null
    if (fuelPriceNum !== null && fuelPriceNum > 0) {
      totalCost = fuelUsedNum * fuelPriceNum
      costPerUnit = totalCost / distanceNum
    }

    setResult({
      efficiency: roundedEfficiency,
      efficiencyUnit: unitSystem === "metric" ? "km/L" : "MPG",
      costPerUnit: costPerUnit !== null ? Math.round(costPerUnit * 100) / 100 : null,
      costUnit: unitSystem === "metric" ? "per km" : "per mile",
      totalCost: totalCost !== null ? Math.round(totalCost * 100) / 100 : null,
      distance: distanceNum,
      fuelUsed: fuelUsedNum,
    })
  }

  const handleReset = () => {
    setDistance("")
    setFuelUsed("")
    setFuelPrice("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Fuel Efficiency: ${result.efficiency} ${result.efficiencyUnit}${
        result.costPerUnit !== null ? ` | Cost: $${result.costPerUnit} ${result.costUnit}` : ""
      }`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Mileage Result",
          text: `I calculated my fuel efficiency using CalcHub! ${result.efficiency} ${result.efficiencyUnit}${
            result.costPerUnit !== null ? ` | Cost: $${result.costPerUnit} ${result.costUnit}` : ""
          }`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setDistance("")
    setFuelUsed("")
    setFuelPrice("")
    setResult(null)
    setError("")
  }

  const getEfficiencyRating = (efficiency: number, unit: string): { label: string; color: string; bgColor: string } => {
    if (unit === "km/L") {
      if (efficiency >= 20)
        return { label: "Excellent", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
      if (efficiency >= 15) return { label: "Good", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
      if (efficiency >= 10)
        return { label: "Average", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
      return { label: "Poor", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    } else {
      // MPG
      if (efficiency >= 40)
        return { label: "Excellent", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
      if (efficiency >= 30) return { label: "Good", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
      if (efficiency >= 20)
        return { label: "Average", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
      return { label: "Poor", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/lifestyle-daily">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Lifestyle & Daily Use
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Mileage Calculator</CardTitle>
                    <CardDescription>Calculate your vehicle's fuel efficiency</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Distance Input */}
                <div className="space-y-2">
                  <Label htmlFor="distance">Distance Traveled ({unitSystem === "metric" ? "km" : "miles"})</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="distance"
                      type="number"
                      placeholder={`Enter distance in ${unitSystem === "metric" ? "kilometers" : "miles"}`}
                      value={distance}
                      onChange={(e) => setDistance(e.target.value)}
                      min="0"
                      step="0.1"
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Fuel Used Input */}
                <div className="space-y-2">
                  <Label htmlFor="fuelUsed">Fuel Used ({unitSystem === "metric" ? "liters" : "gallons"})</Label>
                  <div className="relative">
                    <Fuel className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="fuelUsed"
                      type="number"
                      placeholder={`Enter fuel in ${unitSystem === "metric" ? "liters" : "gallons"}`}
                      value={fuelUsed}
                      onChange={(e) => setFuelUsed(e.target.value)}
                      min="0"
                      step="0.01"
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Fuel Price Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="fuelPrice">
                    Fuel Price per {unitSystem === "metric" ? "Liter" : "Gallon"} (optional)
                  </Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="fuelPrice"
                      type="number"
                      placeholder="Enter fuel price"
                      value={fuelPrice}
                      onChange={(e) => setFuelPrice(e.target.value)}
                      min="0"
                      step="0.01"
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMileage} className="w-full" size="lg">
                  Calculate Mileage
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${
                      getEfficiencyRating(result.efficiency, result.efficiencyUnit).bgColor
                    } transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Fuel Efficiency</p>
                      <p
                        className={`text-5xl font-bold ${
                          getEfficiencyRating(result.efficiency, result.efficiencyUnit).color
                        } mb-1`}
                      >
                        {result.efficiency}
                      </p>
                      <p className="text-lg text-muted-foreground mb-2">{result.efficiencyUnit}</p>
                      <span
                        className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                          getEfficiencyRating(result.efficiency, result.efficiencyUnit).color
                        } ${getEfficiencyRating(result.efficiency, result.efficiencyUnit).bgColor}`}
                      >
                        {getEfficiencyRating(result.efficiency, result.efficiencyUnit).label}
                      </span>
                    </div>

                    {/* Cost Results */}
                    {result.costPerUnit !== null && result.totalCost !== null && (
                      <div className="mt-4 pt-4 border-t border-current/10 grid grid-cols-2 gap-4">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Cost {result.costUnit}</p>
                          <p className="text-xl font-semibold">${result.costPerUnit}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Total Fuel Cost</p>
                          <p className="text-xl font-semibold">${result.totalCost}</p>
                        </div>
                      </div>
                    )}

                    {/* Breakdown Toggle */}
                    <button
                      onClick={() => setShowBreakdown(!showBreakdown)}
                      className="flex items-center justify-center gap-1 w-full mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showBreakdown ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Breakdown
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Breakdown
                        </>
                      )}
                    </button>

                    {showBreakdown && (
                      <div className="mt-3 p-3 bg-background/50 rounded-lg text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Distance:</span>
                          <span className="font-medium">
                            {result.distance} {unitSystem === "metric" ? "km" : "mi"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fuel Used:</span>
                          <span className="font-medium">
                            {result.fuelUsed} {unitSystem === "metric" ? "L" : "gal"}
                          </span>
                        </div>
                        <div className="flex justify-between pt-2 border-t">
                          <span className="text-muted-foreground">Formula:</span>
                          <span className="font-mono text-xs">
                            {result.distance} ÷ {result.fuelUsed} = {result.efficiency}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fuel Efficiency Ratings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-sm text-green-600">
                        {unitSystem === "metric" ? "≥ 20 km/L" : "≥ 40 MPG"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-sm text-blue-600">
                        {unitSystem === "metric" ? "15–19 km/L" : "30–39 MPG"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Average</span>
                      <span className="text-sm text-yellow-600">
                        {unitSystem === "metric" ? "10–14 km/L" : "20–29 MPG"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Poor</span>
                      <span className="text-sm text-red-600">{unitSystem === "metric" ? "< 10 km/L" : "< 20 MPG"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Fuel Efficiency</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span className="text-muted-foreground">Compact Car</span>
                      <span className="font-medium">{unitSystem === "metric" ? "15–20 km/L" : "35–45 MPG"}</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span className="text-muted-foreground">Sedan</span>
                      <span className="font-medium">{unitSystem === "metric" ? "12–17 km/L" : "28–38 MPG"}</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span className="text-muted-foreground">SUV</span>
                      <span className="font-medium">{unitSystem === "metric" ? "8–14 km/L" : "20–32 MPG"}</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span className="text-muted-foreground">Pickup Truck</span>
                      <span className="font-medium">{unitSystem === "metric" ? "6–12 km/L" : "15–28 MPG"}</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted/50">
                      <span className="text-muted-foreground">Hybrid</span>
                      <span className="font-medium">{unitSystem === "metric" ? "20–25 km/L" : "45–55 MPG"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mileage Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">
                      {unitSystem === "metric"
                        ? "Mileage (km/L) = Distance (km) ÷ Fuel (L)"
                        : "MPG = Distance (mi) ÷ Fuel (gal)"}
                    </p>
                  </div>
                  <p>
                    Fuel efficiency measures how far your vehicle can travel on a specific amount of fuel. Higher values
                    indicate better efficiency.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Fuel Efficiency (Mileage)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Fuel efficiency, commonly referred to as mileage, is a measure of how far a vehicle can travel using a
                  specific amount of fuel. It's one of the most important metrics for vehicle owners as it directly
                  impacts operating costs and environmental impact. Understanding your vehicle's fuel efficiency helps
                  you make informed decisions about driving habits, maintenance, and future vehicle purchases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In metric countries, fuel efficiency is typically expressed in kilometers per liter (km/L), while in
                  countries using the imperial system, it's measured in miles per gallon (MPG). A higher number in
                  either system indicates better fuel efficiency—the vehicle travels farther on less fuel.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Fuel Efficiency</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Many factors influence your vehicle's actual fuel efficiency. Understanding these can help you
                  maximize your mileage and reduce fuel costs:
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Driving Conditions</h4>
                    <p className="text-cyan-700 text-sm">
                      Highway driving typically yields better fuel efficiency than city driving due to consistent speeds
                      and less braking. Traffic congestion, frequent stops, and aggressive acceleration all reduce
                      mileage.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Vehicle Maintenance</h4>
                    <p className="text-blue-700 text-sm">
                      Proper tire inflation, regular oil changes, clean air filters, and a well-tuned engine all
                      contribute to optimal fuel efficiency. Underinflated tires alone can reduce mileage by up to 3%.
                    </p>
                  </div>
                  <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                    <h4 className="font-semibold text-indigo-800 mb-2">Vehicle Load & Aerodynamics</h4>
                    <p className="text-indigo-700 text-sm">
                      Excess weight and roof-mounted cargo carriers increase fuel consumption. Every 100 pounds of extra
                      weight can reduce fuel efficiency by about 1-2%.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Weather & Climate</h4>
                    <p className="text-purple-700 text-sm">
                      Cold weather reduces fuel efficiency due to longer engine warm-up times and increased use of
                      heating systems. Air conditioning in hot weather also impacts mileage.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Fuel className="h-5 w-5 text-primary" />
                  <CardTitle>Tips to Improve Fuel Efficiency</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Drive smoothly:</strong> Avoid rapid acceleration and hard braking
                  </li>
                  <li>
                    <strong>Maintain steady speeds:</strong> Use cruise control on highways when possible
                  </li>
                  <li>
                    <strong>Keep tires properly inflated:</strong> Check pressure at least monthly
                  </li>
                  <li>
                    <strong>Remove excess weight:</strong> Clear out unnecessary items from your vehicle
                  </li>
                  <li>
                    <strong>Plan trips efficiently:</strong> Combine errands to reduce cold starts
                  </li>
                  <li>
                    <strong>Reduce idling:</strong> Turn off the engine if stopped for more than a minute
                  </li>
                  <li>
                    <strong>Use recommended fuel grade:</strong> Don't use premium if regular is specified
                  </li>
                  <li>
                    <strong>Keep up with maintenance:</strong> Regular tune-ups and filter changes help
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Mileage calculations are estimates and may vary depending on driving conditions, vehicle
                      performance, fuel quality, and measurement accuracy. Actual fuel efficiency can differ from
                      calculated values due to various factors including terrain, weather, and driving style.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
