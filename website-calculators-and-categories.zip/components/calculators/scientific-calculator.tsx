"use client"

import { useState, useCallback, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Calculator, Info, AlertTriangle, History, Delete } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type AngleUnit = "deg" | "rad"
type CalculatorMode = "basic" | "scientific"

interface HistoryEntry {
  expression: string
  result: string
}

export function ScientificCalculator() {
  const [display, setDisplay] = useState("0")
  const [expression, setExpression] = useState("")
  const [angleUnit, setAngleUnit] = useState<AngleUnit>("deg")
  const [mode, setMode] = useState<CalculatorMode>("scientific")
  const [history, setHistory] = useState<HistoryEntry[]>([])
  const [showHistory, setShowHistory] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [waitingForOperand, setWaitingForOperand] = useState(false)
  const [lastResult, setLastResult] = useState<string | null>(null)

  const toRadians = (deg: number) => (deg * Math.PI) / 180
  const toDegrees = (rad: number) => (rad * 180) / Math.PI

  const factorial = (n: number): number => {
    if (n < 0) throw new Error("Factorial of negative number")
    if (n > 170) throw new Error("Number too large")
    if (!Number.isInteger(n)) throw new Error("Factorial requires integer")
    if (n === 0 || n === 1) return 1
    let result = 1
    for (let i = 2; i <= n; i++) result *= i
    return result
  }

  const handleNumber = useCallback(
    (num: string) => {
      setError("")

      if (lastResult !== null) {
        setDisplay(num)
        setExpression(num)
        setLastResult(null)
        setWaitingForOperand(false)
        return
      }

      if (waitingForOperand) {
        setDisplay(num)
        setExpression((prev) => prev + num)
        setWaitingForOperand(false)
        return
      }

      if (num === ".") {
        if (display.includes(".")) return
        setDisplay((prev) => prev + ".")
        setExpression((prev) => prev + ".")
        return
      }

      if (display === "0") {
        setDisplay(num)
        setExpression((prev) => {
          if (prev === "" || prev === "0") {
            return num
          } else {
            return prev.slice(0, -1) + num
          }
        })
      } else {
        setDisplay((prev) => prev + num)
        setExpression((prev) => prev + num)
      }
    },
    [lastResult, waitingForOperand, display],
  )

  const handleOperator = useCallback(
    (op: string) => {
      setError("")

      const displayOp = op === "*" ? "×" : op === "/" ? "÷" : op

      if (lastResult !== null) {
        setExpression(lastResult + displayOp)
        setLastResult(null)
        setWaitingForOperand(true)
        return
      }

      if (expression === "") {
        if (op === "-") {
          setExpression("-")
          setDisplay("-")
        }
        return
      }

      const lastChar = expression.slice(-1)
      const operators = ["+", "-", "×", "÷", "*", "/"]

      if (operators.includes(lastChar)) {
        setExpression((prev) => prev.slice(0, -1) + displayOp)
      } else {
        setExpression((prev) => prev + displayOp)
      }

      setWaitingForOperand(true)
    },
    [lastResult, expression],
  )

  const handleParenthesis = useCallback(
    (paren: string) => {
      setError("")

      if (lastResult !== null) {
        if (paren === "(") {
          setExpression("(")
          setDisplay("(")
          setLastResult(null)
        }
        return
      }

      setExpression((prev) => prev + paren)
      setDisplay((prev) => (prev === "0" ? paren : prev + paren))
      setWaitingForOperand(paren === "(")
    },
    [lastResult],
  )

  const handleFunction = useCallback(
    (func: string) => {
      setError("")

      const currentValue = Number.parseFloat(display)
      let result: number

      try {
        const angleValue = angleUnit === "deg" ? toRadians(currentValue) : currentValue

        switch (func) {
          case "sin":
            result = Math.sin(angleValue)
            break
          case "cos":
            result = Math.cos(angleValue)
            break
          case "tan":
            if (Math.abs(Math.cos(angleValue)) < 1e-10) {
              throw new Error("Undefined (tan of 90°)")
            }
            result = Math.tan(angleValue)
            break
          case "asin":
            if (currentValue < -1 || currentValue > 1) {
              throw new Error("Domain error: input must be between -1 and 1")
            }
            result = angleUnit === "deg" ? toDegrees(Math.asin(currentValue)) : Math.asin(currentValue)
            break
          case "acos":
            if (currentValue < -1 || currentValue > 1) {
              throw new Error("Domain error: input must be between -1 and 1")
            }
            result = angleUnit === "deg" ? toDegrees(Math.acos(currentValue)) : Math.acos(currentValue)
            break
          case "atan":
            result = angleUnit === "deg" ? toDegrees(Math.atan(currentValue)) : Math.atan(currentValue)
            break
          case "log":
            if (currentValue <= 0) {
              throw new Error("Domain error: input must be positive")
            }
            result = Math.log10(currentValue)
            break
          case "ln":
            if (currentValue <= 0) {
              throw new Error("Domain error: input must be positive")
            }
            result = Math.log(currentValue)
            break
          case "sqrt":
            if (currentValue < 0) {
              throw new Error("Domain error: input must be non-negative")
            }
            result = Math.sqrt(currentValue)
            break
          case "cbrt":
            result = Math.cbrt(currentValue)
            break
          case "square":
            result = currentValue * currentValue
            break
          case "cube":
            result = currentValue * currentValue * currentValue
            break
          case "reciprocal":
            if (currentValue === 0) {
              throw new Error("Cannot divide by zero")
            }
            result = 1 / currentValue
            break
          case "factorial":
            result = factorial(currentValue)
            break
          case "abs":
            result = Math.abs(currentValue)
            break
          case "exp":
            result = Math.exp(currentValue)
            break
          case "10^x":
            result = Math.pow(10, currentValue)
            break
          default:
            return
        }

        const resultStr = Number.isInteger(result) ? result.toString() : result.toPrecision(10).replace(/\.?0+$/, "")
        setDisplay(resultStr)
        setExpression(resultStr)
        setLastResult(resultStr)
        setWaitingForOperand(true)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Error")
      }
    },
    [display, angleUnit],
  )

  const handleConstant = useCallback(
    (constant: string) => {
      setError("")
      let value: string

      switch (constant) {
        case "π":
          value = Math.PI.toString()
          break
        case "e":
          value = Math.E.toString()
          break
        default:
          return
      }

      if (lastResult !== null || waitingForOperand || display === "0") {
        setDisplay(value)
        if (waitingForOperand) {
          setExpression((prev) => prev + value)
        } else {
          setExpression(value)
        }
        setLastResult(null)
        setWaitingForOperand(false)
      } else {
        setExpression((prev) => prev + "*" + value)
        setDisplay(value)
        setWaitingForOperand(false)
      }
    },
    [lastResult, waitingForOperand, display],
  )

  const calculate = useCallback(() => {
    if (!expression) return

    try {
      let evalExpression = expression
        .replace(/×/g, "*")
        .replace(/÷/g, "/")
        .replace(/π/g, Math.PI.toString())
        .replace(/(\d)%/g, "($1/100)")

      // Handle trailing operators
      evalExpression = evalExpression.replace(/[+\-*/]$/, "")

      if (!evalExpression) return

      // Safe evaluation using Function constructor
      const result = new Function(`return ${evalExpression}`)()

      if (typeof result !== "number" || !isFinite(result)) {
        throw new Error("Invalid result")
      }

      const resultStr = Number.isInteger(result) ? result.toString() : result.toPrecision(10).replace(/\.?0+$/, "")

      setHistory((prev) => [...prev.slice(-9), { expression, result: resultStr }])
      setDisplay(resultStr)
      setLastResult(resultStr)
      setWaitingForOperand(true)
    } catch {
      setError("Invalid expression")
    }
  }, [expression])

  const clearAll = useCallback(() => {
    setDisplay("0")
    setExpression("")
    setError("")
    setWaitingForOperand(false)
    setLastResult(null)
  }, [])

  const backspace = useCallback(() => {
    if (lastResult !== null) {
      clearAll()
      return
    }

    if (expression.length <= 1) {
      setDisplay("0")
      setExpression("")
    } else {
      const newExpression = expression.slice(0, -1)
      setExpression(newExpression)

      // Update display - find the last number in the expression
      const match = newExpression.match(/[\d.]+$/)
      if (match) {
        setDisplay(match[0])
      } else {
        setDisplay("0")
      }
    }
  }, [lastResult, expression, clearAll])

  const handleCopy = useCallback(() => {
    navigator.clipboard
      .writeText(display)
      .then(() => {
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
      })
      .catch((err) => {
        console.error("Failed to copy text: ", err)
      })
  }, [display])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const calculatorKeys = [
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "+",
        "-",
        "*",
        "/",
        ".",
        "=",
        "Enter",
        "Backspace",
        "Escape",
        "Delete",
        "(",
        ")",
        "%",
        "^",
        "p",
        "e",
        "s",
        "c",
        "t",
        "l",
        "n",
        "r",
        "!",
      ]

      if (calculatorKeys.includes(e.key)) {
        e.preventDefault()
      }

      if (/^[0-9]$/.test(e.key)) {
        handleNumber(e.key)
        return
      }

      if (e.key === ".") {
        handleNumber(".")
        return
      }

      switch (e.key) {
        case "+":
          handleOperator("+")
          return
        case "-":
          handleOperator("-")
          return
        case "*":
          handleOperator("*")
          return
        case "/":
          handleOperator("/")
          return
        case "%":
          handleOperator("%")
          return
        case "^":
          handleOperator("^")
          return
      }

      if (e.key === "(") {
        handleParenthesis("(")
        return
      }
      if (e.key === ")") {
        handleParenthesis(")")
        return
      }

      if (e.key === "Enter" || e.key === "=") {
        calculate()
        return
      }

      if (e.key === "Escape" || e.key === "Delete") {
        clearAll()
        return
      }

      if (e.key === "Backspace") {
        backspace()
        return
      }

      switch (e.key.toLowerCase()) {
        case "p": // Pi
          handleConstant("π")
          return
        case "s": // Sin
          handleFunction("sin")
          return
        case "c": // Cos
          handleFunction("cos")
          return
        case "t": // Tan
          handleFunction("tan")
          return
        case "l": // Log
          handleFunction("log")
          return
        case "n": // Natural log (ln)
          handleFunction("ln")
          return
        case "r": // Square root
          handleFunction("sqrt")
          return
        case "!": // Factorial
          handleFunction("factorial")
          return
      }

      if (e.key === "e" && !e.ctrlKey && !e.metaKey) {
        handleConstant("e")
        return
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [handleNumber, handleOperator, handleParenthesis, calculate, clearAll, backspace, handleFunction, handleConstant])

  const toggleAngleUnit = () => {
    setAngleUnit((prev) => (prev === "deg" ? "rad" : "deg"))
  }

  const toggleMode = () => {
    setMode((prev) => (prev === "basic" ? "scientific" : "basic"))
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Scientific Calculator</CardTitle>
                    <CardDescription>Advanced mathematical operations</CardDescription>
                  </div>
                </div>

                {/* Mode & Angle Toggles */}
                <div className="flex items-center justify-between pt-2 gap-2 flex-wrap">
                  <button
                    onClick={toggleMode}
                    className="relative inline-flex h-9 w-36 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "scientific" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        mode === "basic" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Basic
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        mode === "scientific" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Scientific
                    </span>
                  </button>

                  <button
                    onClick={toggleAngleUnit}
                    className="relative inline-flex h-9 w-28 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        angleUnit === "rad" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        angleUnit === "deg" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      DEG
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        angleUnit === "rad" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      RAD
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Display */}
                <div className="bg-muted rounded-lg p-4">
                  <div className="text-right text-sm text-muted-foreground h-5 overflow-hidden truncate">
                    {expression || " "}
                  </div>
                  <div className="text-right text-3xl sm:text-4xl font-bold font-mono truncate">{display}</div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Scientific Buttons */}
                {mode === "scientific" && (
                  <div className="grid grid-cols-5 gap-1.5">
                    {/* Row 1: Trig functions + constants */}
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("sin")}
                    >
                      sin
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("cos")}
                    >
                      cos
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("tan")}
                    >
                      tan
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleConstant("π")}
                    >
                      π
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleConstant("e")}
                    >
                      e
                    </Button>

                    {/* Row 2: Inverse trig + logs */}
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("asin")}
                    >
                      sin⁻¹
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("acos")}
                    >
                      cos⁻¹
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("atan")}
                    >
                      tan⁻¹
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("log")}
                    >
                      log
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("ln")}
                    >
                      ln
                    </Button>

                    {/* Row 3: Powers, roots, special */}
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("square")}
                    >
                      x²
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("cube")}
                    >
                      x³
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleOperator("^")}
                    >
                      xʸ
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("sqrt")}
                    >
                      √x
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("cbrt")}
                    >
                      ³√x
                    </Button>

                    {/* Row 4: Additional functions */}
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("factorial")}
                    >
                      n!
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("reciprocal")}
                    >
                      1/x
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("abs")}
                    >
                      |x|
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("exp")}
                    >
                      eˣ
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleFunction("10^x")}
                    >
                      10ˣ
                    </Button>

                    {/* Row 5: Parentheses */}
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleParenthesis("(")}
                    >
                      (
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium bg-transparent"
                      onClick={() => handleParenthesis(")")}
                    >
                      )
                    </Button>
                    <Button
                      variant="outline"
                      className="h-10 text-xs font-medium col-span-3 bg-transparent"
                      onClick={() => handleOperator("%")}
                    >
                      mod %
                    </Button>
                  </div>
                )}

                {/* Basic Buttons */}
                <div className="grid grid-cols-4 gap-2">
                  {/* Row 1: Clear, Backspace, %, ÷ */}
                  <Button
                    variant="outline"
                    className="h-12 text-base font-medium bg-red-50 hover:bg-red-100 text-red-600 border-red-200"
                    onClick={clearAll}
                  >
                    AC
                  </Button>
                  <Button variant="outline" className="h-12 font-medium bg-transparent" onClick={backspace}>
                    <Delete className="h-5 w-5" />
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-base font-medium bg-blue-50 hover:bg-blue-100 text-blue-600 border-blue-200"
                    onClick={() => handleOperator("%")}
                  >
                    %
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-blue-50 hover:bg-blue-100 text-blue-600 border-blue-200"
                    onClick={() => handleOperator("/")}
                  >
                    ÷
                  </Button>

                  {/* Row 2: 7, 8, 9, × */}
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("7")}
                  >
                    7
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("8")}
                  >
                    8
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("9")}
                  >
                    9
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-blue-50 hover:bg-blue-100 text-blue-600 border-blue-200"
                    onClick={() => handleOperator("*")}
                  >
                    ×
                  </Button>

                  {/* Row 3: 4, 5, 6, - */}
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("4")}
                  >
                    4
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("5")}
                  >
                    5
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("6")}
                  >
                    6
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-blue-50 hover:bg-blue-100 text-blue-600 border-blue-200"
                    onClick={() => handleOperator("-")}
                  >
                    −
                  </Button>

                  {/* Row 4: 1, 2, 3, + */}
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("1")}
                  >
                    1
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("2")}
                  >
                    2
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber("3")}
                  >
                    3
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-blue-50 hover:bg-blue-100 text-blue-600 border-blue-200"
                    onClick={() => handleOperator("+")}
                  >
                    +
                  </Button>

                  {/* Row 5: 0, ., = */}
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium col-span-2 bg-transparent"
                    onClick={() => handleNumber("0")}
                  >
                    0
                  </Button>
                  <Button
                    variant="outline"
                    className="h-12 text-lg font-medium bg-transparent"
                    onClick={() => handleNumber(".")}
                  >
                    .
                  </Button>
                  <Button
                    className="h-12 text-lg font-medium bg-blue-600 hover:bg-blue-700 text-white"
                    onClick={calculate}
                  >
                    =
                  </Button>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-center gap-2 pt-2">
                  <Button variant="outline" size="sm" onClick={clearAll}>
                    <RotateCcw className="h-4 w-4 mr-1" />
                    Reset
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                    {copied ? "Copied" : "Copy"}
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setShowHistory(!showHistory)}>
                    <History className="h-4 w-4 mr-1" />
                    History
                  </Button>
                </div>

                {/* History Panel */}
                {showHistory && (
                  <div className="bg-muted/50 rounded-lg p-3 max-h-40 overflow-y-auto">
                    <p className="text-xs font-medium text-muted-foreground mb-2">Calculation History</p>
                    {history.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No history yet</p>
                    ) : (
                      <div className="space-y-1">
                        {history.map((entry, idx) => (
                          <button
                            key={idx}
                            className="w-full text-left p-2 rounded hover:bg-muted transition-colors"
                            onClick={() => {
                              setDisplay(entry.result)
                              setExpression(entry.result)
                              setLastResult(entry.result)
                            }}
                          >
                            <div className="text-xs text-muted-foreground truncate">{entry.expression}</div>
                            <div className="text-sm font-medium truncate">= {entry.result}</div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-4">
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Info className="h-4 w-4 text-blue-600" />
                    Functions Guide
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">sin/cos/tan</span> Trig functions
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">sin⁻¹/cos⁻¹/tan⁻¹</span> Inverse trig
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">log</span> Base-10 logarithm
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">ln</span> Natural logarithm
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">x²/x³</span> Square/Cube
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">√x/³√x</span> Square/Cube root
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">xʸ</span> Power (x^y)
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">n!</span> Factorial
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">1/x</span> Reciprocal
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">|x|</span> Absolute value
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">eˣ</span> Exponential
                    </div>
                    <div>
                      <span className="font-mono bg-muted px-1 rounded">10ˣ</span> Power of 10
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-md">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Calculator className="h-4 w-4 text-blue-600" />
                    Tips
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2 text-muted-foreground">
                  <p>• Toggle DEG/RAD for angle unit in trig functions</p>
                  <p>• Functions apply to the current displayed number</p>
                  <p>• Use xʸ for custom exponents (e.g., 2^10)</p>
                  <p>• Click history entries to reuse results</p>
                  <p>• Parentheses () for complex expressions</p>
                  <p>• Use keyboard shortcuts for faster calculations</p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-md bg-amber-50 border-amber-200">
                <CardContent className="pt-4">
                  <div className="flex gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-600 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-800">
                      Results are approximations. For critical calculations, verify with professional tools.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <Card className="mt-8 border-0 shadow-md">
            <CardHeader>
              <CardTitle className="text-xl">Understanding Scientific Calculators</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none text-muted-foreground space-y-4">
              <div>
                <h3 className="text-base font-semibold text-foreground mb-2">What is a Scientific Calculator?</h3>
                <p>
                  A scientific calculator is an advanced computing device designed to handle complex mathematical
                  operations beyond basic arithmetic. It includes functions for trigonometry, logarithms, exponents,
                  roots, and more, making it essential for students, engineers, scientists, and professionals working
                  with advanced mathematics.
                </p>
              </div>

              <div>
                <h3 className="text-base font-semibold text-foreground mb-2">Trigonometric Functions</h3>
                <p>
                  Trigonometric functions (sin, cos, tan) relate angles to ratios of sides in right triangles. They are
                  fundamental in physics, engineering, and navigation. The inverse functions (arcsin, arccos, arctan)
                  find the angle when given a ratio. Remember to set the correct angle unit (degrees or radians) for
                  your calculations.
                </p>
              </div>

              <div>
                <h3 className="text-base font-semibold text-foreground mb-2">Logarithms and Exponents</h3>
                <p>
                  Logarithms are the inverse of exponentiation. The common logarithm (log) uses base 10, while the
                  natural logarithm (ln) uses base e ≈ 2.718. These functions are crucial for solving exponential
                  equations, analyzing growth patterns, and working with very large or small numbers in scientific
                  notation.
                </p>
              </div>

              <div>
                <h3 className="text-base font-semibold text-foreground mb-2">Special Functions</h3>
                <p>
                  Factorial (n!) multiplies all positive integers up to n and is used in probability and combinatorics.
                  Absolute value (|x|) returns the non-negative value of a number. The reciprocal (1/x) is useful for
                  division operations and working with fractions. These functions extend the calculator's capabilities
                  for specialized mathematical problems.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
