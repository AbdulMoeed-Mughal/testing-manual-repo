"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  ArrowRight,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Periodic table data with atomic weights
const periodicTable: Record<string, number> = {
  H: 1.008,
  He: 4.003,
  Li: 6.941,
  Be: 9.012,
  B: 10.81,
  C: 12.01,
  N: 14.01,
  O: 16.0,
  F: 19.0,
  Ne: 20.18,
  Na: 22.99,
  Mg: 24.31,
  Al: 26.98,
  Si: 28.09,
  P: 30.97,
  S: 32.07,
  Cl: 35.45,
  Ar: 39.95,
  K: 39.1,
  Ca: 40.08,
  Sc: 44.96,
  Ti: 47.87,
  V: 50.94,
  Cr: 52.0,
  Mn: 54.94,
  Fe: 55.85,
  Co: 58.93,
  Ni: 58.69,
  Cu: 63.55,
  Zn: 65.38,
  Ga: 69.72,
  Ge: 72.63,
  As: 74.92,
  Se: 78.97,
  Br: 79.9,
  Kr: 83.8,
  Rb: 85.47,
  Sr: 87.62,
  Y: 88.91,
  Zr: 91.22,
  Nb: 92.91,
  Mo: 95.95,
  Tc: 98.0,
  Ru: 101.1,
  Rh: 102.9,
  Pd: 106.4,
  Ag: 107.9,
  Cd: 112.4,
  In: 114.8,
  Sn: 118.7,
  Sb: 121.8,
  Te: 127.6,
  I: 126.9,
  Xe: 131.3,
  Cs: 132.9,
  Ba: 137.3,
  La: 138.9,
  Ce: 140.1,
  Pr: 140.9,
  Nd: 144.2,
  Pm: 145.0,
  Sm: 150.4,
  Eu: 152.0,
  Gd: 157.3,
  Tb: 158.9,
  Dy: 162.5,
  Ho: 164.9,
  Er: 167.3,
  Tm: 168.9,
  Yb: 173.0,
  Lu: 175.0,
  Hf: 178.5,
  Ta: 180.9,
  W: 183.8,
  Re: 186.2,
  Os: 190.2,
  Ir: 192.2,
  Pt: 195.1,
  Au: 197.0,
  Hg: 200.6,
  Tl: 204.4,
  Pb: 207.2,
  Bi: 209.0,
  Po: 209.0,
  At: 210.0,
  Rn: 222.0,
  Fr: 223.0,
  Ra: 226.0,
  Ac: 227.0,
  Th: 232.0,
  Pa: 231.0,
  U: 238.0,
  Np: 237.0,
  Pu: 244.0,
  Am: 243.0,
  Cm: 247.0,
  Bk: 247.0,
  Cf: 251.0,
  Es: 252.0,
  Fm: 257.0,
  Md: 258.0,
  No: 259.0,
  Lr: 266.0,
  Rf: 267.0,
  Db: 268.0,
  Sg: 269.0,
  Bh: 270.0,
  Hs: 277.0,
  Mt: 278.0,
  Ds: 281.0,
  Rg: 282.0,
  Cn: 285.0,
  Nh: 286.0,
  Fl: 289.0,
  Mc: 290.0,
  Lv: 293.0,
  Ts: 294.0,
  Og: 294.0,
}

interface ParsedCompound {
  formula: string
  coefficient: number
  elements: Record<string, number>
  molecularWeight: number
}

interface ParsedEquation {
  reactants: ParsedCompound[]
  products: ParsedCompound[]
  isBalanced: boolean
}

interface StoichiometryResult {
  knownMoles: number
  targetMoles: number
  targetMass: number
  actualYield: number | null
  moleRatio: string
  steps: string[]
}

export function StoichiometryCalculator() {
  const [equation, setEquation] = useState("")
  const [parsedEquation, setParsedEquation] = useState<ParsedEquation | null>(null)
  const [knownSubstance, setKnownSubstance] = useState("")
  const [knownQuantity, setKnownQuantity] = useState("")
  const [knownUnit, setKnownUnit] = useState<"mass" | "moles">("mass")
  const [targetSubstance, setTargetSubstance] = useState("")
  const [reactionYield, setReactionYield] = useState("")
  const [result, setResult] = useState<StoichiometryResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  // Parse chemical formula and calculate molecular weight
  const parseFormula = (formula: string): { elements: Record<string, number>; molecularWeight: number } | null => {
    const elements: Record<string, number> = {}

    const parseGroup = (str: string, multiplier = 1): boolean => {
      let i = 0
      while (i < str.length) {
        if (str[i] === "(") {
          // Find matching closing parenthesis
          let depth = 1
          let j = i + 1
          while (j < str.length && depth > 0) {
            if (str[j] === "(") depth++
            if (str[j] === ")") depth--
            j++
          }
          if (depth !== 0) return false

          // Get subscript after parenthesis
          let subEnd = j
          while (subEnd < str.length && /\d/.test(str[subEnd])) subEnd++
          const sub = subEnd > j ? Number.parseInt(str.slice(j, subEnd)) : 1

          // Parse contents of parenthesis
          if (!parseGroup(str.slice(i + 1, j - 1), multiplier * sub)) return false
          i = subEnd
        } else if (/[A-Z]/.test(str[i])) {
          // Element symbol
          let symbol = str[i]
          i++
          while (i < str.length && /[a-z]/.test(str[i])) {
            symbol += str[i]
            i++
          }

          // Get subscript
          let subEnd = i
          while (subEnd < str.length && /\d/.test(str[subEnd])) subEnd++
          const sub = subEnd > i ? Number.parseInt(str.slice(i, subEnd)) : 1
          i = subEnd

          if (!periodicTable[symbol]) return false
          elements[symbol] = (elements[symbol] || 0) + sub * multiplier
        } else {
          return false
        }
      }
      return true
    }

    if (!parseGroup(formula)) return null

    let molecularWeight = 0
    for (const [element, count] of Object.entries(elements)) {
      molecularWeight += periodicTable[element] * count
    }

    return { elements, molecularWeight }
  }

  // Parse a term like "2H2O" into coefficient and formula
  const parseTerm = (term: string): ParsedCompound | null => {
    const match = term.match(/^(\d*)(.+)$/)
    if (!match) return null

    const coefficient = match[1] ? Number.parseInt(match[1]) : 1
    const formula = match[2]

    const parsed = parseFormula(formula)
    if (!parsed) return null

    return {
      formula,
      coefficient,
      elements: parsed.elements,
      molecularWeight: parsed.molecularWeight,
    }
  }

  // Parse the entire chemical equation
  const parseEquation = (eq: string): ParsedEquation | null => {
    // Normalize equation - replace various arrow symbols
    const normalized = eq.replace(/→|->|=|⟶/g, "→").replace(/\s+/g, "")
    const parts = normalized.split("→")

    if (parts.length !== 2) return null

    const reactantTerms = parts[0]
      .split("+")
      .map((t) => t.trim())
      .filter((t) => t)
    const productTerms = parts[1]
      .split("+")
      .map((t) => t.trim())
      .filter((t) => t)

    if (reactantTerms.length === 0 || productTerms.length === 0) return null

    const reactants: ParsedCompound[] = []
    const products: ParsedCompound[] = []

    for (const term of reactantTerms) {
      const parsed = parseTerm(term)
      if (!parsed) return null
      reactants.push(parsed)
    }

    for (const term of productTerms) {
      const parsed = parseTerm(term)
      if (!parsed) return null
      products.push(parsed)
    }

    // Check if equation is balanced
    const leftElements: Record<string, number> = {}
    const rightElements: Record<string, number> = {}

    for (const compound of reactants) {
      for (const [element, count] of Object.entries(compound.elements)) {
        leftElements[element] = (leftElements[element] || 0) + count * compound.coefficient
      }
    }

    for (const compound of products) {
      for (const [element, count] of Object.entries(compound.elements)) {
        rightElements[element] = (rightElements[element] || 0) + count * compound.coefficient
      }
    }

    const allElements = new Set([...Object.keys(leftElements), ...Object.keys(rightElements)])
    let isBalanced = true
    for (const element of allElements) {
      if ((leftElements[element] || 0) !== (rightElements[element] || 0)) {
        isBalanced = false
        break
      }
    }

    return { reactants, products, isBalanced }
  }

  const handleParseEquation = () => {
    setError("")
    setParsedEquation(null)
    setKnownSubstance("")
    setTargetSubstance("")
    setResult(null)

    if (!equation.trim()) {
      setError("Please enter a chemical equation")
      return
    }

    const parsed = parseEquation(equation)
    if (!parsed) {
      setError("Invalid equation format. Use format like: 2H2 + O2 → 2H2O")
      return
    }

    if (!parsed.isBalanced) {
      setError("Warning: The equation appears to be unbalanced. Results may be inaccurate.")
    }

    setParsedEquation(parsed)
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (!parsedEquation) {
      setError("Please parse a valid equation first")
      return
    }

    if (!knownSubstance) {
      setError("Please select the known substance")
      return
    }

    if (!targetSubstance) {
      setError("Please select the target substance")
      return
    }

    if (knownSubstance === targetSubstance) {
      setError("Known and target substances must be different")
      return
    }

    const quantity = Number.parseFloat(knownQuantity)
    if (isNaN(quantity) || quantity <= 0) {
      setError("Please enter a valid positive quantity")
      return
    }

    const yieldPercent = reactionYield ? Number.parseFloat(reactionYield) : 100
    if (reactionYield && (isNaN(yieldPercent) || yieldPercent <= 0 || yieldPercent > 100)) {
      setError("Yield must be between 0 and 100%")
      return
    }

    // Find known and target compounds
    const allCompounds = [...parsedEquation.reactants, ...parsedEquation.products]
    const knownCompound = allCompounds.find((c) => c.formula === knownSubstance)
    const targetCompound = allCompounds.find((c) => c.formula === targetSubstance)

    if (!knownCompound || !targetCompound) {
      setError("Could not find selected substances in the equation")
      return
    }

    const steps: string[] = []

    // Step 1: Convert known quantity to moles
    let knownMoles: number
    if (knownUnit === "mass") {
      knownMoles = quantity / knownCompound.molecularWeight
      steps.push(`Step 1: Convert ${quantity} g of ${knownSubstance} to moles`)
      steps.push(`Molecular weight of ${knownSubstance} = ${knownCompound.molecularWeight.toFixed(3)} g/mol`)
      steps.push(
        `Moles = ${quantity} g ÷ ${knownCompound.molecularWeight.toFixed(3)} g/mol = ${knownMoles.toFixed(6)} mol`,
      )
    } else {
      knownMoles = quantity
      steps.push(`Step 1: Given ${quantity} mol of ${knownSubstance}`)
    }

    // Step 2: Use mole ratio
    const moleRatio = `${targetCompound.coefficient}:${knownCompound.coefficient}`
    const targetMoles = knownMoles * (targetCompound.coefficient / knownCompound.coefficient)

    steps.push(`Step 2: Apply mole ratio from balanced equation`)
    steps.push(
      `Mole ratio of ${targetSubstance} to ${knownSubstance} = ${targetCompound.coefficient}:${knownCompound.coefficient}`,
    )
    steps.push(
      `Moles of ${targetSubstance} = ${knownMoles.toFixed(6)} mol × (${targetCompound.coefficient}/${knownCompound.coefficient}) = ${targetMoles.toFixed(6)} mol`,
    )

    // Step 3: Convert to mass
    const targetMass = targetMoles * targetCompound.molecularWeight
    steps.push(`Step 3: Convert moles to mass`)
    steps.push(`Molecular weight of ${targetSubstance} = ${targetCompound.molecularWeight.toFixed(3)} g/mol`)
    steps.push(
      `Theoretical yield = ${targetMoles.toFixed(6)} mol × ${targetCompound.molecularWeight.toFixed(3)} g/mol = ${targetMass.toFixed(4)} g`,
    )

    // Step 4: Apply yield if specified
    let actualYield: number | null = null
    if (reactionYield && yieldPercent < 100) {
      actualYield = targetMass * (yieldPercent / 100)
      steps.push(`Step 4: Apply ${yieldPercent}% reaction yield`)
      steps.push(`Actual yield = ${targetMass.toFixed(4)} g × ${yieldPercent}% = ${actualYield.toFixed(4)} g`)
    }

    setResult({
      knownMoles,
      targetMoles,
      targetMass,
      actualYield,
      moleRatio,
      steps,
    })
  }

  const handleReset = () => {
    setEquation("")
    setParsedEquation(null)
    setKnownSubstance("")
    setKnownQuantity("")
    setKnownUnit("mass")
    setTargetSubstance("")
    setReactionYield("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Stoichiometry Calculation:
Known: ${knownQuantity} ${knownUnit === "mass" ? "g" : "mol"} of ${knownSubstance}
Target: ${targetSubstance}
Mole Ratio: ${result.moleRatio}
Theoretical Yield: ${result.targetMoles.toFixed(6)} mol (${result.targetMass.toFixed(4)} g)${result.actualYield ? `\nActual Yield (${reactionYield}%): ${result.actualYield.toFixed(4)} g` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const allCompounds = parsedEquation ? [...parsedEquation.reactants, ...parsedEquation.products] : []

  // Quick examples
  const examples = [
    { equation: "2H2 + O2 → 2H2O", description: "Water formation" },
    { equation: "CH4 + 2O2 → CO2 + 2H2O", description: "Methane combustion" },
    { equation: "2Na + Cl2 → 2NaCl", description: "Salt formation" },
    { equation: "CaCO3 → CaO + CO2", description: "Limestone decomposition" },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Stoichiometry Calculator</CardTitle>
                    <CardDescription>Calculate reactant and product quantities</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Equation Input */}
                <div className="space-y-2">
                  <Label htmlFor="equation">Balanced Chemical Equation</Label>
                  <div className="flex gap-2">
                    <Input
                      id="equation"
                      type="text"
                      placeholder="e.g., 2H2 + O2 → 2H2O"
                      value={equation}
                      onChange={(e) => setEquation(e.target.value)}
                      className="flex-1"
                    />
                    <Button onClick={handleParseEquation} variant="secondary">
                      Parse
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">Use → or {"-> or ="} for the reaction arrow</p>
                </div>

                {/* Quick Examples */}
                <div className="space-y-2">
                  <Label className="text-sm">Quick Examples</Label>
                  <div className="flex flex-wrap gap-2">
                    {examples.map((ex, idx) => (
                      <Button
                        key={idx}
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEquation(ex.equation)
                          setParsedEquation(null)
                          setResult(null)
                        }}
                        className="text-xs"
                      >
                        {ex.description}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Parsed Equation Display */}
                {parsedEquation && (
                  <div
                    className={`p-3 rounded-lg border ${parsedEquation.isBalanced ? "bg-green-50 border-green-200" : "bg-yellow-50 border-yellow-200"}`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span
                        className={`text-sm font-medium ${parsedEquation.isBalanced ? "text-green-700" : "text-yellow-700"}`}
                      >
                        {parsedEquation.isBalanced ? "✓ Equation Balanced" : "⚠ Equation Unbalanced"}
                      </span>
                    </div>
                    <div className="flex items-center justify-center gap-2 flex-wrap text-sm">
                      {parsedEquation.reactants.map((r, i) => (
                        <span key={`r-${i}`} className="font-mono">
                          {i > 0 && <span className="mx-1">+</span>}
                          <span className="bg-white px-2 py-1 rounded border">
                            {r.coefficient > 1 ? r.coefficient : ""}
                            {r.formula}
                          </span>
                        </span>
                      ))}
                      <ArrowRight className="h-4 w-4 mx-2" />
                      {parsedEquation.products.map((p, i) => (
                        <span key={`p-${i}`} className="font-mono">
                          {i > 0 && <span className="mx-1">+</span>}
                          <span className="bg-white px-2 py-1 rounded border">
                            {p.coefficient > 1 ? p.coefficient : ""}
                            {p.formula}
                          </span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Substance Selection */}
                {parsedEquation && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Known Substance</Label>
                        <Select value={knownSubstance} onValueChange={setKnownSubstance}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select..." />
                          </SelectTrigger>
                          <SelectContent>
                            {allCompounds.map((c, i) => (
                              <SelectItem key={i} value={c.formula}>
                                {c.formula} ({c.molecularWeight.toFixed(2)} g/mol)
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Target Substance</Label>
                        <Select value={targetSubstance} onValueChange={setTargetSubstance}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select..." />
                          </SelectTrigger>
                          <SelectContent>
                            {allCompounds.map((c, i) => (
                              <SelectItem key={i} value={c.formula}>
                                {c.formula} ({c.molecularWeight.toFixed(2)} g/mol)
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Known Quantity */}
                    <div className="space-y-2">
                      <Label>Known Quantity</Label>
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          placeholder="Enter amount"
                          value={knownQuantity}
                          onChange={(e) => setKnownQuantity(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <Select value={knownUnit} onValueChange={(v: "mass" | "moles") => setKnownUnit(v)}>
                          <SelectTrigger className="w-24">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="mass">g</SelectItem>
                            <SelectItem value="moles">mol</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Optional Yield */}
                    <div className="space-y-2">
                      <Label htmlFor="yield">Reaction Yield (Optional)</Label>
                      <div className="flex gap-2 items-center">
                        <Input
                          id="yield"
                          type="number"
                          placeholder="100"
                          value={reactionYield}
                          onChange={(e) => setReactionYield(e.target.value)}
                          min="0"
                          max="100"
                          step="0.1"
                          className="flex-1"
                        />
                        <span className="text-sm text-muted-foreground">%</span>
                      </div>
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg" disabled={!parsedEquation}>
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Theoretical Yield of {targetSubstance}</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">{result.targetMass.toFixed(4)} g</p>
                      <p className="text-lg text-purple-500">{result.targetMoles.toFixed(6)} mol</p>
                      {result.actualYield !== null && (
                        <div className="mt-3 p-3 bg-white rounded-lg border border-purple-200">
                          <p className="text-sm text-muted-foreground">Actual Yield ({reactionYield}%)</p>
                          <p className="text-2xl font-bold text-green-600">{result.actualYield.toFixed(4)} g</p>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                      <div className="p-2 bg-white rounded-lg border">
                        <p className="text-muted-foreground">Known Moles</p>
                        <p className="font-semibold">{result.knownMoles.toFixed(6)} mol</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg border">
                        <p className="text-muted-foreground">Mole Ratio</p>
                        <p className="font-semibold">{result.moleRatio}</p>
                      </div>
                    </div>

                    {/* Step-by-step Solution */}
                    <div className="border-t border-purple-200 pt-3">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="flex items-center justify-between w-full text-sm font-medium text-purple-700"
                      >
                        <span>Step-by-Step Solution</span>
                        {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                      {showSteps && (
                        <div className="mt-3 space-y-2 text-sm text-muted-foreground">
                          {result.steps.map((step, i) => (
                            <p
                              key={i}
                              className={step.startsWith("Step") ? "font-medium text-foreground mt-3" : "pl-4"}
                            >
                              {step}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4 pt-3 border-t border-purple-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Stoichiometry Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">moles = mass ÷ molecular weight</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">
                      mol<sub>target</sub> = mol<sub>known</sub> × (coef<sub>target</sub> ÷ coef<sub>known</sub>)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How to Use</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex gap-2">
                    <span className="font-bold text-primary">1.</span>
                    <span>Enter a balanced chemical equation and click Parse</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-bold text-primary">2.</span>
                    <span>Select the known substance and enter its quantity</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-bold text-primary">3.</span>
                    <span>Select the target substance you want to calculate</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-bold text-primary">4.</span>
                    <span>Optionally enter reaction yield percentage</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Results assume complete reaction and ideal laboratory conditions unless yield is specified.
                        Always verify calculations for critical applications.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Stoichiometry?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Stoichiometry is the branch of chemistry that deals with the quantitative relationships between
                  reactants and products in chemical reactions. The word comes from the Greek words "stoicheion"
                  (element) and "metron" (measure). It allows chemists to predict how much product will form from given
                  amounts of reactants, or how much of a reactant is needed to produce a desired amount of product.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  At its core, stoichiometry is based on the law of conservation of mass, which states that matter
                  cannot be created or destroyed in a chemical reaction. This means the total mass of reactants must
                  equal the total mass of products. By using balanced chemical equations and molar relationships,
                  stoichiometry enables precise calculations essential for laboratory work, industrial processes, and
                  research.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>The Mole Concept</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The mole is the fundamental unit in stoichiometry. One mole contains exactly 6.022 × 10²³ particles
                  (Avogadro's number) of a substance, whether atoms, molecules, or ions. The molar mass of a substance
                  (in grams per mole) is numerically equal to its molecular or atomic weight.
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Mass to Moles</h4>
                    <p className="text-blue-700 text-sm">
                      To convert mass to moles, divide the mass (in grams) by the molar mass of the substance.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Moles to Mass</h4>
                    <p className="text-green-700 text-sm">
                      To convert moles to mass, multiply the number of moles by the molar mass of the substance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ArrowRight className="h-5 w-5 text-primary" />
                  <CardTitle>Mole Ratios and Balanced Equations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A balanced chemical equation provides the mole ratios between all substances in a reaction. The
                  coefficients in front of each formula represent the relative number of moles of each substance. For
                  example, in the equation 2H₂ + O₂ → 2H₂O, the mole ratio of H₂ to O₂ to H₂O is 2:1:2.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  These ratios are the key to stoichiometric calculations. Once you know the moles of one substance, you
                  can use the mole ratio to find the moles of any other substance in the reaction. This is why balancing
                  equations correctly is essential - an unbalanced equation will give incorrect mole ratios and
                  therefore incorrect calculations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Theoretical vs Actual Yield</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The theoretical yield is the maximum amount of product that could be formed based on stoichiometric
                  calculations, assuming the reaction goes to completion with no losses. However, in practice, reactions
                  rarely achieve 100% yield due to factors like incomplete reactions, side reactions, loss during
                  transfer, and purification losses.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="font-semibold text-foreground mb-2">Percent Yield Formula:</p>
                  <p className="font-mono text-center">% Yield = (Actual Yield ÷ Theoretical Yield) × 100</p>
                </div>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding yield is crucial for industrial chemistry where efficiency directly impacts costs. A
                  reaction with 80% yield means 20% of the potential product is lost, which can be significant at large
                  scales.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
