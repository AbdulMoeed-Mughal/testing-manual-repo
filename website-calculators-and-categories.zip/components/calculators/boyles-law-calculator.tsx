"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, Wind, Gauge } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type SolveFor = "P2" | "V2"
type PressureUnit = "Pa" | "kPa" | "atm" | "psi" | "bar"
type VolumeUnit = "m3" | "L" | "cm3" | "mL"

interface BoylesLawResult {
  solvedValue: number
  solvedFor: SolveFor
  p1: number
  v1: number
  p2: number
  v2: number
  constant: number
  status: string
  statusColor: string
  statusBg: string
}

const pressureConversions: Record<PressureUnit, number> = {
  Pa: 1,
  kPa: 1000,
  atm: 101325,
  psi: 6894.76,
  bar: 100000,
}

const volumeConversions: Record<VolumeUnit, number> = {
  m3: 1,
  L: 0.001,
  cm3: 0.000001,
  mL: 0.000001,
}

const pressureLabels: Record<PressureUnit, string> = {
  Pa: "Pa",
  kPa: "kPa",
  atm: "atm",
  psi: "psi",
  bar: "bar",
}

const volumeLabels: Record<VolumeUnit, string> = {
  m3: "m³",
  L: "L",
  cm3: "cm³",
  mL: "mL",
}

export function BoylesLawCalculator() {
  const [solveFor, setSolveFor] = useState<SolveFor>("V2")
  const [p1, setP1] = useState("")
  const [v1, setV1] = useState("")
  const [p2, setP2] = useState("")
  const [v2, setV2] = useState("")
  const [pressureUnit, setPressureUnit] = useState<PressureUnit>("kPa")
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("L")
  const [result, setResult] = useState<BoylesLawResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const p1Num = Number.parseFloat(p1)
    const v1Num = Number.parseFloat(v1)

    if (isNaN(p1Num) || p1Num <= 0) {
      setError("Please enter a valid initial pressure (P₁) greater than 0")
      return
    }

    if (isNaN(v1Num) || v1Num <= 0) {
      setError("Please enter a valid initial volume (V₁) greater than 0")
      return
    }

    // Convert to base units (Pa and m³)
    const p1Base = p1Num * pressureConversions[pressureUnit]
    const v1Base = v1Num * volumeConversions[volumeUnit]

    // Calculate the constant k = P₁ × V₁
    const constant = p1Base * v1Base

    let solvedValue: number
    let p2Final: number
    let v2Final: number
    let status: string
    let statusColor: string
    let statusBg: string

    if (solveFor === "V2") {
      const p2Num = Number.parseFloat(p2)
      if (isNaN(p2Num) || p2Num <= 0) {
        setError("Please enter a valid final pressure (P₂) greater than 0")
        return
      }
      const p2Base = p2Num * pressureConversions[pressureUnit]

      // V₂ = (P₁ × V₁) / P₂
      const v2Base = constant / p2Base
      v2Final = v2Base / volumeConversions[volumeUnit]
      p2Final = p2Num
      solvedValue = v2Final

      if (v2Final > v1Num) {
        status = "Gas Expands"
        statusColor = "text-blue-600"
        statusBg = "bg-blue-50 border-blue-200"
      } else if (v2Final < v1Num) {
        status = "Gas Compresses"
        statusColor = "text-orange-600"
        statusBg = "bg-orange-50 border-orange-200"
      } else {
        status = "No Change"
        statusColor = "text-green-600"
        statusBg = "bg-green-50 border-green-200"
      }
    } else {
      const v2Num = Number.parseFloat(v2)
      if (isNaN(v2Num) || v2Num <= 0) {
        setError("Please enter a valid final volume (V₂) greater than 0")
        return
      }
      const v2Base = v2Num * volumeConversions[volumeUnit]

      // P₂ = (P₁ × V₁) / V₂
      const p2Base = constant / v2Base
      p2Final = p2Base / pressureConversions[pressureUnit]
      v2Final = v2Num
      solvedValue = p2Final

      if (p2Final > p1Num) {
        status = "Pressure Increases"
        statusColor = "text-red-600"
        statusBg = "bg-red-50 border-red-200"
      } else if (p2Final < p1Num) {
        status = "Pressure Decreases"
        statusColor = "text-blue-600"
        statusBg = "bg-blue-50 border-blue-200"
      } else {
        status = "No Change"
        statusColor = "text-green-600"
        statusBg = "bg-green-50 border-green-200"
      }
    }

    setResult({
      solvedValue,
      solvedFor: solveFor,
      p1: p1Num,
      v1: v1Num,
      p2: p2Final,
      v2: v2Final,
      constant: constant,
      status,
      statusColor,
      statusBg,
    })
  }

  const handleReset = () => {
    setP1("")
    setV1("")
    setP2("")
    setV2("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        result.solvedFor === "V2"
          ? `Boyle's Law: V₂ = ${result.solvedValue.toFixed(4)} ${volumeLabels[volumeUnit]}`
          : `Boyle's Law: P₂ = ${result.solvedValue.toFixed(4)} ${pressureLabels[pressureUnit]}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text =
          result.solvedFor === "V2"
            ? `I calculated gas volume using Boyle's Law! V₂ = ${result.solvedValue.toFixed(4)} ${volumeLabels[volumeUnit]}`
            : `I calculated gas pressure using Boyle's Law! P₂ = ${result.solvedValue.toFixed(4)} ${pressureLabels[pressureUnit]}`
        await navigator.share({
          title: "Boyle's Law Calculation",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return num.toExponential(4)
    if (num < 0.0001) return num.toExponential(4)
    return num.toFixed(4)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Wind className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Boyle's Law Calculator</CardTitle>
                    <CardDescription>Calculate pressure-volume relationship at constant temperature</CardDescription>
                  </div>
                </div>

                {/* Solve For Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Solve For</span>
                  <button
                    onClick={() => {
                      setSolveFor(solveFor === "V2" ? "P2" : "V2")
                      setResult(null)
                    }}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        solveFor === "P2" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        solveFor === "V2" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Volume (V₂)
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        solveFor === "P2" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Pressure (P₂)
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Unit Selection */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="pressureUnit">Pressure Unit</Label>
                    <select
                      id="pressureUnit"
                      value={pressureUnit}
                      onChange={(e) => setPressureUnit(e.target.value as PressureUnit)}
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                    >
                      <option value="Pa">Pascal (Pa)</option>
                      <option value="kPa">Kilopascal (kPa)</option>
                      <option value="atm">Atmosphere (atm)</option>
                      <option value="psi">PSI (psi)</option>
                      <option value="bar">Bar (bar)</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="volumeUnit">Volume Unit</Label>
                    <select
                      id="volumeUnit"
                      value={volumeUnit}
                      onChange={(e) => setVolumeUnit(e.target.value as VolumeUnit)}
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                    >
                      <option value="m3">Cubic Meter (m³)</option>
                      <option value="L">Liter (L)</option>
                      <option value="cm3">Cubic Centimeter (cm³)</option>
                      <option value="mL">Milliliter (mL)</option>
                    </select>
                  </div>
                </div>

                {/* Initial State */}
                <div className="p-3 bg-muted/50 rounded-lg space-y-3">
                  <h4 className="font-medium text-sm">Initial State</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="p1">P₁ ({pressureLabels[pressureUnit]})</Label>
                      <Input
                        id="p1"
                        type="number"
                        placeholder="Initial pressure"
                        value={p1}
                        onChange={(e) => setP1(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="v1">V₁ ({volumeLabels[volumeUnit]})</Label>
                      <Input
                        id="v1"
                        type="number"
                        placeholder="Initial volume"
                        value={v1}
                        onChange={(e) => setV1(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </div>
                </div>

                {/* Final State - Known Value */}
                <div className="p-3 bg-muted/50 rounded-lg space-y-3">
                  <h4 className="font-medium text-sm">Final State (Known)</h4>
                  {solveFor === "V2" ? (
                    <div className="space-y-2">
                      <Label htmlFor="p2">P₂ ({pressureLabels[pressureUnit]})</Label>
                      <Input
                        id="p2"
                        type="number"
                        placeholder="Final pressure"
                        value={p2}
                        onChange={(e) => setP2(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label htmlFor="v2">V₂ ({volumeLabels[volumeUnit]})</Label>
                      <Input
                        id="v2"
                        type="number"
                        placeholder="Final volume"
                        value={v2}
                        onChange={(e) => setV2(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {solveFor === "V2" ? "Final Volume" : "Final Pressure"}
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.statusBg} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.solvedFor === "V2" ? "Final Volume (V₂)" : "Final Pressure (P₂)"}
                      </p>
                      <p className={`text-4xl font-bold ${result.statusColor} mb-1`}>
                        {formatNumber(result.solvedValue)}
                      </p>
                      <p className="text-lg font-medium text-muted-foreground mb-2">
                        {result.solvedFor === "V2" ? volumeLabels[volumeUnit] : pressureLabels[pressureUnit]}
                      </p>
                      <p className={`text-sm font-semibold ${result.statusColor}`}>{result.status}</p>
                    </div>

                    {/* Step-by-step toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Boyle's Law:</strong> P₁V₁ = P₂V₂
                        </p>
                        <p>
                          <strong>Given:</strong>
                        </p>
                        <p className="ml-4">
                          P₁ = {result.p1} {pressureLabels[pressureUnit]}
                        </p>
                        <p className="ml-4">
                          V₁ = {result.v1} {volumeLabels[volumeUnit]}
                        </p>
                        {result.solvedFor === "V2" ? (
                          <>
                            <p className="ml-4">
                              P₂ = {result.p2} {pressureLabels[pressureUnit]}
                            </p>
                            <p>
                              <strong>Solve for V₂:</strong>
                            </p>
                            <p className="ml-4">V₂ = (P₁ × V₁) / P₂</p>
                            <p className="ml-4">
                              V₂ = ({result.p1} × {result.v1}) / {result.p2}
                            </p>
                            <p className="ml-4">
                              V₂ = {formatNumber(result.solvedValue)} {volumeLabels[volumeUnit]}
                            </p>
                          </>
                        ) : (
                          <>
                            <p className="ml-4">
                              V₂ = {result.v2} {volumeLabels[volumeUnit]}
                            </p>
                            <p>
                              <strong>Solve for P₂:</strong>
                            </p>
                            <p className="ml-4">P₂ = (P₁ × V₁) / V₂</p>
                            <p className="ml-4">
                              P₂ = ({result.p1} × {result.v1}) / {result.v2}
                            </p>
                            <p className="ml-4">
                              P₂ = {formatNumber(result.solvedValue)} {pressureLabels[pressureUnit]}
                            </p>
                          </>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Boyle's Law Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-lg">P₁V₁ = P₂V₂</p>
                    <p className="text-sm text-muted-foreground mt-2">(at constant temperature)</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>P₁</strong> = Initial pressure
                    </p>
                    <p>
                      <strong>V₁</strong> = Initial volume
                    </p>
                    <p>
                      <strong>P₂</strong> = Final pressure
                    </p>
                    <p>
                      <strong>V₂</strong> = Final volume
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Relationships</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Pressure ↑</span>
                      <span className="text-sm text-blue-600">Volume ↓</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Pressure ↓</span>
                      <span className="text-sm text-orange-600">Volume ↑</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">P × V</span>
                      <span className="text-sm text-green-600">= Constant (k)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li className="flex items-start gap-2">
                      <Gauge className="h-4 w-4 mt-0.5 text-cyan-600" />
                      <span>Scuba diving - air tank pressure changes</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Gauge className="h-4 w-4 mt-0.5 text-cyan-600" />
                      <span>Syringes - medical and industrial applications</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Gauge className="h-4 w-4 mt-0.5 text-cyan-600" />
                      <span>Pneumatic systems - compressors and actuators</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Gauge className="h-4 w-4 mt-0.5 text-cyan-600" />
                      <span>Breathing mechanics - lung volume changes</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Boyle's Law?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Boyle's Law, formulated by Robert Boyle in 1662, is one of the fundamental gas laws in chemistry and
                  physics. It describes the inverse relationship between the pressure and volume of a gas when
                  temperature is held constant. Simply put, when you compress a gas (decrease its volume), its pressure
                  increases proportionally, and when you allow a gas to expand (increase its volume), its pressure
                  decreases proportionally.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The mathematical relationship is expressed as P₁V₁ = P₂V₂, where the product of pressure and volume
                  remains constant for a fixed amount of gas at constant temperature. This principle is crucial in
                  understanding how gases behave under different conditions and has numerous practical applications in
                  engineering, medicine, and everyday life.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Wind className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Boyle's Law has numerous practical applications across various fields. In medicine, it explains how
                  our lungs work - when the diaphragm contracts and expands the chest cavity, the increased volume
                  causes decreased pressure, drawing air into the lungs. Syringes also operate on this principle, where
                  pulling the plunger increases volume and decreases pressure, causing fluid to be drawn in.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In scuba diving, understanding Boyle's Law is essential for safety. As divers descend, the increased
                  water pressure compresses the air in their lungs and equipment. This is why divers must ascend slowly
                  - rapid ascent can cause dangerous expansion of gases in the body. Similarly, pneumatic systems, air
                  compressors, and hydraulic machinery all rely on the principles described by Boyle's Law.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Boyle's law calculations assume ideal gas behavior and constant
                  temperature. Real gas deviations may occur at high pressures or low temperatures. Consult
                  thermodynamics references for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
