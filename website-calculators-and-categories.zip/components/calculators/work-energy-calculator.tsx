"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Zap, Info, AlertTriangle, Activity, Gauge } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "work" | "force-from-work" | "distance-from-work" | "kinetic" | "potential" | "total-mechanical"

interface Result {
  value: number
  unit: string
  label: string
  steps: string[]
  additionalInfo?: { label: string; value: string }[]
}

const forceUnits = [
  { value: "N", label: "Newtons (N)", factor: 1 },
  { value: "kN", label: "Kilonewtons (kN)", factor: 1000 },
  { value: "lbf", label: "Pound-force (lbf)", factor: 4.44822 },
]

const distanceUnits = [
  { value: "m", label: "Meters (m)", factor: 1 },
  { value: "cm", label: "Centimeters (cm)", factor: 0.01 },
  { value: "ft", label: "Feet (ft)", factor: 0.3048 },
]

const massUnits = [
  { value: "kg", label: "Kilograms (kg)", factor: 1 },
  { value: "g", label: "Grams (g)", factor: 0.001 },
  { value: "lb", label: "Pounds (lb)", factor: 0.453592 },
]

const velocityUnits = [
  { value: "m/s", label: "m/s", factor: 1 },
  { value: "km/h", label: "km/h", factor: 0.277778 },
  { value: "mph", label: "mph", factor: 0.44704 },
]

const energyUnits = [
  { value: "J", label: "Joules (J)", factor: 1 },
  { value: "kJ", label: "Kilojoules (kJ)", factor: 1000 },
  { value: "cal", label: "Calories (cal)", factor: 4.184 },
]

export function WorkEnergyCalculator() {
  const [mode, setMode] = useState<CalculationMode>("work")
  const [force, setForce] = useState("")
  const [forceUnit, setForceUnit] = useState("N")
  const [distance, setDistance] = useState("")
  const [distanceUnit, setDistanceUnit] = useState("m")
  const [angle, setAngle] = useState("0")
  const [mass, setMass] = useState("")
  const [massUnit, setMassUnit] = useState("kg")
  const [velocity, setVelocity] = useState("")
  const [velocityUnit, setVelocityUnit] = useState("m/s")
  const [height, setHeight] = useState("")
  const [heightUnit, setHeightUnit] = useState("m")
  const [work, setWork] = useState("")
  const [workUnit, setWorkUnit] = useState("J")
  const [gravity, setGravity] = useState("9.81")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const getUnitFactor = (value: string, units: typeof forceUnits) => {
    return units.find((u) => u.value === value)?.factor || 1
  }

  const calculate = () => {
    setError("")
    setResult(null)

    try {
      let resultValue: number
      let resultUnit: string
      let resultLabel: string
      const steps: string[] = []
      const additionalInfo: { label: string; value: string }[] = []

      switch (mode) {
        case "work": {
          const forceVal = Number.parseFloat(force)
          const distVal = Number.parseFloat(distance)
          const angleVal = Number.parseFloat(angle) || 0

          if (isNaN(forceVal) || forceVal <= 0) {
            setError("Please enter a valid force greater than 0")
            return
          }
          if (isNaN(distVal) || distVal <= 0) {
            setError("Please enter a valid distance greater than 0")
            return
          }

          const forceInN = forceVal * getUnitFactor(forceUnit, forceUnits)
          const distInM = distVal * getUnitFactor(distanceUnit, distanceUnits)
          const angleRad = (angleVal * Math.PI) / 180
          const cosAngle = Math.cos(angleRad)

          resultValue = forceInN * distInM * cosAngle
          resultUnit = "J"
          resultLabel = "Work Done"

          steps.push(`Formula: W = F × d × cos(θ)`)
          steps.push(`Force: ${forceVal} ${forceUnit} = ${forceInN.toFixed(4)} N`)
          steps.push(`Distance: ${distVal} ${distanceUnit} = ${distInM.toFixed(4)} m`)
          steps.push(`Angle: ${angleVal}° → cos(${angleVal}°) = ${cosAngle.toFixed(4)}`)
          steps.push(`W = ${forceInN.toFixed(2)} × ${distInM.toFixed(2)} × ${cosAngle.toFixed(4)}`)
          steps.push(`W = ${resultValue.toFixed(4)} J`)

          additionalInfo.push({ label: "In kJ", value: `${(resultValue / 1000).toFixed(4)} kJ` })
          additionalInfo.push({ label: "In calories", value: `${(resultValue / 4.184).toFixed(4)} cal` })
          break
        }

        case "force-from-work": {
          const workVal = Number.parseFloat(work)
          const distVal = Number.parseFloat(distance)
          const angleVal = Number.parseFloat(angle) || 0

          if (isNaN(workVal) || workVal <= 0) {
            setError("Please enter a valid work greater than 0")
            return
          }
          if (isNaN(distVal) || distVal <= 0) {
            setError("Please enter a valid distance greater than 0")
            return
          }

          const workInJ = workVal * getUnitFactor(workUnit, energyUnits)
          const distInM = distVal * getUnitFactor(distanceUnit, distanceUnits)
          const angleRad = (angleVal * Math.PI) / 180
          const cosAngle = Math.cos(angleRad)

          if (Math.abs(cosAngle) < 0.0001) {
            setError("Angle results in zero force component (cos(θ) ≈ 0)")
            return
          }

          resultValue = workInJ / (distInM * cosAngle)
          resultUnit = "N"
          resultLabel = "Force Required"

          steps.push(`Formula: F = W ÷ (d × cos(θ))`)
          steps.push(`Work: ${workVal} ${workUnit} = ${workInJ.toFixed(4)} J`)
          steps.push(`Distance: ${distVal} ${distanceUnit} = ${distInM.toFixed(4)} m`)
          steps.push(`Angle: ${angleVal}° → cos(${angleVal}°) = ${cosAngle.toFixed(4)}`)
          steps.push(`F = ${workInJ.toFixed(2)} ÷ (${distInM.toFixed(2)} × ${cosAngle.toFixed(4)})`)
          steps.push(`F = ${resultValue.toFixed(4)} N`)

          additionalInfo.push({ label: "In kN", value: `${(resultValue / 1000).toFixed(4)} kN` })
          additionalInfo.push({ label: "In lbf", value: `${(resultValue / 4.44822).toFixed(4)} lbf` })
          break
        }

        case "distance-from-work": {
          const workVal = Number.parseFloat(work)
          const forceVal = Number.parseFloat(force)
          const angleVal = Number.parseFloat(angle) || 0

          if (isNaN(workVal) || workVal <= 0) {
            setError("Please enter a valid work greater than 0")
            return
          }
          if (isNaN(forceVal) || forceVal <= 0) {
            setError("Please enter a valid force greater than 0")
            return
          }

          const workInJ = workVal * getUnitFactor(workUnit, energyUnits)
          const forceInN = forceVal * getUnitFactor(forceUnit, forceUnits)
          const angleRad = (angleVal * Math.PI) / 180
          const cosAngle = Math.cos(angleRad)

          if (Math.abs(cosAngle) < 0.0001) {
            setError("Angle results in zero force component (cos(θ) ≈ 0)")
            return
          }

          resultValue = workInJ / (forceInN * cosAngle)
          resultUnit = "m"
          resultLabel = "Distance Required"

          steps.push(`Formula: d = W ÷ (F × cos(θ))`)
          steps.push(`Work: ${workVal} ${workUnit} = ${workInJ.toFixed(4)} J`)
          steps.push(`Force: ${forceVal} ${forceUnit} = ${forceInN.toFixed(4)} N`)
          steps.push(`Angle: ${angleVal}° → cos(${angleVal}°) = ${cosAngle.toFixed(4)}`)
          steps.push(`d = ${workInJ.toFixed(2)} ÷ (${forceInN.toFixed(2)} × ${cosAngle.toFixed(4)})`)
          steps.push(`d = ${resultValue.toFixed(4)} m`)

          additionalInfo.push({ label: "In cm", value: `${(resultValue * 100).toFixed(2)} cm` })
          additionalInfo.push({ label: "In feet", value: `${(resultValue / 0.3048).toFixed(4)} ft` })
          break
        }

        case "kinetic": {
          const massVal = Number.parseFloat(mass)
          const velVal = Number.parseFloat(velocity)

          if (isNaN(massVal) || massVal <= 0) {
            setError("Please enter a valid mass greater than 0")
            return
          }
          if (isNaN(velVal) || velVal < 0) {
            setError("Please enter a valid velocity (0 or greater)")
            return
          }

          const massInKg = massVal * getUnitFactor(massUnit, massUnits)
          const velInMs = velVal * getUnitFactor(velocityUnit, velocityUnits)

          resultValue = 0.5 * massInKg * velInMs * velInMs
          resultUnit = "J"
          resultLabel = "Kinetic Energy"

          steps.push(`Formula: KE = ½ × m × v²`)
          steps.push(`Mass: ${massVal} ${massUnit} = ${massInKg.toFixed(4)} kg`)
          steps.push(`Velocity: ${velVal} ${velocityUnit} = ${velInMs.toFixed(4)} m/s`)
          steps.push(`KE = 0.5 × ${massInKg.toFixed(2)} × (${velInMs.toFixed(2)})²`)
          steps.push(`KE = 0.5 × ${massInKg.toFixed(2)} × ${(velInMs * velInMs).toFixed(4)}`)
          steps.push(`KE = ${resultValue.toFixed(4)} J`)

          additionalInfo.push({ label: "In kJ", value: `${(resultValue / 1000).toFixed(4)} kJ` })
          additionalInfo.push({ label: "In calories", value: `${(resultValue / 4.184).toFixed(4)} cal` })
          break
        }

        case "potential": {
          const massVal = Number.parseFloat(mass)
          const heightVal = Number.parseFloat(height)
          const gravityVal = Number.parseFloat(gravity) || 9.81

          if (isNaN(massVal) || massVal <= 0) {
            setError("Please enter a valid mass greater than 0")
            return
          }
          if (isNaN(heightVal) || heightVal < 0) {
            setError("Please enter a valid height (0 or greater)")
            return
          }

          const massInKg = massVal * getUnitFactor(massUnit, massUnits)
          const heightInM = heightVal * getUnitFactor(heightUnit, distanceUnits)

          resultValue = massInKg * gravityVal * heightInM
          resultUnit = "J"
          resultLabel = "Potential Energy"

          steps.push(`Formula: PE = m × g × h`)
          steps.push(`Mass: ${massVal} ${massUnit} = ${massInKg.toFixed(4)} kg`)
          steps.push(`Gravity: ${gravityVal} m/s²`)
          steps.push(`Height: ${heightVal} ${heightUnit} = ${heightInM.toFixed(4)} m`)
          steps.push(`PE = ${massInKg.toFixed(2)} × ${gravityVal} × ${heightInM.toFixed(2)}`)
          steps.push(`PE = ${resultValue.toFixed(4)} J`)

          additionalInfo.push({ label: "In kJ", value: `${(resultValue / 1000).toFixed(4)} kJ` })
          additionalInfo.push({ label: "In calories", value: `${(resultValue / 4.184).toFixed(4)} cal` })
          break
        }

        case "total-mechanical": {
          const massVal = Number.parseFloat(mass)
          const velVal = Number.parseFloat(velocity)
          const heightVal = Number.parseFloat(height)
          const gravityVal = Number.parseFloat(gravity) || 9.81

          if (isNaN(massVal) || massVal <= 0) {
            setError("Please enter a valid mass greater than 0")
            return
          }
          if (isNaN(velVal) || velVal < 0) {
            setError("Please enter a valid velocity (0 or greater)")
            return
          }
          if (isNaN(heightVal) || heightVal < 0) {
            setError("Please enter a valid height (0 or greater)")
            return
          }

          const massInKg = massVal * getUnitFactor(massUnit, massUnits)
          const velInMs = velVal * getUnitFactor(velocityUnit, velocityUnits)
          const heightInM = heightVal * getUnitFactor(heightUnit, distanceUnits)

          const ke = 0.5 * massInKg * velInMs * velInMs
          const pe = massInKg * gravityVal * heightInM
          resultValue = ke + pe
          resultUnit = "J"
          resultLabel = "Total Mechanical Energy"

          steps.push(`Formula: E = KE + PE = ½mv² + mgh`)
          steps.push(`Mass: ${massVal} ${massUnit} = ${massInKg.toFixed(4)} kg`)
          steps.push(`Velocity: ${velVal} ${velocityUnit} = ${velInMs.toFixed(4)} m/s`)
          steps.push(`Height: ${heightVal} ${heightUnit} = ${heightInM.toFixed(4)} m`)
          steps.push(`KE = 0.5 × ${massInKg.toFixed(2)} × (${velInMs.toFixed(2)})² = ${ke.toFixed(4)} J`)
          steps.push(`PE = ${massInKg.toFixed(2)} × ${gravityVal} × ${heightInM.toFixed(2)} = ${pe.toFixed(4)} J`)
          steps.push(`E = ${ke.toFixed(4)} + ${pe.toFixed(4)} = ${resultValue.toFixed(4)} J`)

          additionalInfo.push({ label: "Kinetic Energy", value: `${ke.toFixed(4)} J` })
          additionalInfo.push({ label: "Potential Energy", value: `${pe.toFixed(4)} J` })
          additionalInfo.push({ label: "In kJ", value: `${(resultValue / 1000).toFixed(4)} kJ` })
          break
        }

        default:
          setError("Invalid calculation mode")
          return
      }

      setResult({ value: resultValue, unit: resultUnit, label: resultLabel, steps, additionalInfo })
    } catch {
      setError("Calculation error. Please check your inputs.")
    }
  }

  const handleReset = () => {
    setForce("")
    setDistance("")
    setAngle("0")
    setMass("")
    setVelocity("")
    setHeight("")
    setWork("")
    setGravity("9.81")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`${result.label}: ${result.value.toFixed(4)} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatResult = (value: number): string => {
    if (Math.abs(value) >= 1e6 || (Math.abs(value) < 0.001 && value !== 0)) {
      return value.toExponential(4)
    }
    return value.toFixed(4)
  }

  const getModeLabel = (m: CalculationMode): string => {
    switch (m) {
      case "work":
        return "Work (W = F×d×cos θ)"
      case "force-from-work":
        return "Force from Work"
      case "distance-from-work":
        return "Distance from Work"
      case "kinetic":
        return "Kinetic Energy (KE)"
      case "potential":
        return "Potential Energy (PE)"
      case "total-mechanical":
        return "Total Mechanical Energy"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Work & Energy Calculator</CardTitle>
                    <CardDescription>Calculate work, kinetic & potential energy</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Calculation Mode</Label>
                  <Select
                    value={mode}
                    onValueChange={(v) => {
                      setMode(v as CalculationMode)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="work">Work (W = F×d×cos θ)</SelectItem>
                      <SelectItem value="force-from-work">Force from Work</SelectItem>
                      <SelectItem value="distance-from-work">Distance from Work</SelectItem>
                      <SelectItem value="kinetic">Kinetic Energy (KE = ½mv²)</SelectItem>
                      <SelectItem value="potential">Potential Energy (PE = mgh)</SelectItem>
                      <SelectItem value="total-mechanical">Total Mechanical Energy (E = KE + PE)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Work mode inputs */}
                {mode === "work" && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Force</Label>
                        <Input
                          type="number"
                          placeholder="Enter force"
                          value={force}
                          onChange={(e) => setForce(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={forceUnit} onValueChange={setForceUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {forceUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Distance</Label>
                        <Input
                          type="number"
                          placeholder="Enter distance"
                          value={distance}
                          onChange={(e) => setDistance(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={distanceUnit} onValueChange={setDistanceUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {distanceUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Angle (degrees, optional - default 0°)</Label>
                      <Input
                        type="number"
                        placeholder="Enter angle"
                        value={angle}
                        onChange={(e) => setAngle(e.target.value)}
                        min="0"
                        max="360"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Force from work mode inputs */}
                {mode === "force-from-work" && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Work</Label>
                        <Input
                          type="number"
                          placeholder="Enter work"
                          value={work}
                          onChange={(e) => setWork(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={workUnit} onValueChange={setWorkUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {energyUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Distance</Label>
                        <Input
                          type="number"
                          placeholder="Enter distance"
                          value={distance}
                          onChange={(e) => setDistance(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={distanceUnit} onValueChange={setDistanceUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {distanceUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Angle (degrees, optional - default 0°)</Label>
                      <Input
                        type="number"
                        placeholder="Enter angle"
                        value={angle}
                        onChange={(e) => setAngle(e.target.value)}
                        min="0"
                        max="360"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Distance from work mode inputs */}
                {mode === "distance-from-work" && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Work</Label>
                        <Input
                          type="number"
                          placeholder="Enter work"
                          value={work}
                          onChange={(e) => setWork(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={workUnit} onValueChange={setWorkUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {energyUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Force</Label>
                        <Input
                          type="number"
                          placeholder="Enter force"
                          value={force}
                          onChange={(e) => setForce(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={forceUnit} onValueChange={setForceUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {forceUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Angle (degrees, optional - default 0°)</Label>
                      <Input
                        type="number"
                        placeholder="Enter angle"
                        value={angle}
                        onChange={(e) => setAngle(e.target.value)}
                        min="0"
                        max="360"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Kinetic energy mode inputs */}
                {mode === "kinetic" && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Mass</Label>
                        <Input
                          type="number"
                          placeholder="Enter mass"
                          value={mass}
                          onChange={(e) => setMass(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={massUnit} onValueChange={setMassUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {massUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Velocity</Label>
                        <Input
                          type="number"
                          placeholder="Enter velocity"
                          value={velocity}
                          onChange={(e) => setVelocity(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={velocityUnit} onValueChange={setVelocityUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {velocityUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                )}

                {/* Potential energy mode inputs */}
                {mode === "potential" && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Mass</Label>
                        <Input
                          type="number"
                          placeholder="Enter mass"
                          value={mass}
                          onChange={(e) => setMass(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={massUnit} onValueChange={setMassUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {massUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Height</Label>
                        <Input
                          type="number"
                          placeholder="Enter height"
                          value={height}
                          onChange={(e) => setHeight(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={heightUnit} onValueChange={setHeightUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {distanceUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Gravity (m/s²)</Label>
                      <Input
                        type="number"
                        placeholder="Enter gravity"
                        value={gravity}
                        onChange={(e) => setGravity(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Total mechanical energy mode inputs */}
                {mode === "total-mechanical" && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Mass</Label>
                        <Input
                          type="number"
                          placeholder="Enter mass"
                          value={mass}
                          onChange={(e) => setMass(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={massUnit} onValueChange={setMassUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {massUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Velocity</Label>
                        <Input
                          type="number"
                          placeholder="Enter velocity"
                          value={velocity}
                          onChange={(e) => setVelocity(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={velocityUnit} onValueChange={setVelocityUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {velocityUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>Height</Label>
                        <Input
                          type="number"
                          placeholder="Enter height"
                          value={height}
                          onChange={(e) => setHeight(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Unit</Label>
                        <Select value={heightUnit} onValueChange={setHeightUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {distanceUnits.map((u) => (
                              <SelectItem key={u.value} value={u.value}>
                                {u.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Gravity (m/s²)</Label>
                      <Input
                        type="number"
                        placeholder="Enter gravity"
                        value={gravity}
                        onChange={(e) => setGravity(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {getModeLabel(mode).split(" (")[0]}
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{result.label}</p>
                      <p className="text-4xl font-bold text-orange-600 mb-1">
                        {formatResult(result.value)} {result.unit}
                      </p>
                    </div>

                    {result.additionalInfo && result.additionalInfo.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-orange-200 grid grid-cols-2 gap-2">
                        {result.additionalInfo.map((info, idx) => (
                          <div key={idx} className="text-center">
                            <p className="text-xs text-muted-foreground">{info.label}</p>
                            <p className="text-sm font-medium text-orange-700">{info.value}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}

                {result && result.steps.length > 0 && (
                  <Card className="bg-muted/50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Step-by-Step Solution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-1 text-sm font-mono">
                        {result.steps.map((step, idx) => (
                          <p key={idx} className="text-muted-foreground">
                            {step}
                          </p>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <p className="font-semibold text-orange-800">Work</p>
                    <p className="text-sm text-orange-700 font-mono">W = F × d × cos(θ)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-semibold text-blue-800">Kinetic Energy</p>
                    <p className="text-sm text-blue-700 font-mono">KE = ½ × m × v²</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-semibold text-green-800">Potential Energy</p>
                    <p className="text-sm text-green-700 font-mono">PE = m × g × h</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-semibold text-purple-800">Total Mechanical Energy</p>
                    <p className="text-sm text-purple-700 font-mono">E = KE + PE</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Variable Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">W</span>
                      <span>Work (Joules)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">F</span>
                      <span>Force (Newtons)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">d</span>
                      <span>Distance (meters)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">m</span>
                      <span>Mass (kilograms)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">v</span>
                      <span>Velocity (m/s)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">h</span>
                      <span>Height (meters)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">g</span>
                      <span>Gravity (9.81 m/s²)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">θ</span>
                      <span>Angle (degrees)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-4">
                  <div className="flex gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium">Disclaimer</p>
                      <p className="mt-1">Results assume ideal conditions without friction or energy loss.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Work & Energy</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Work and energy are fundamental concepts in physics that describe how forces cause motion and how
                  objects store the ability to do work. Work is done when a force causes an object to move in the
                  direction of the force, while energy is the capacity to perform work. These concepts are
                  interconnected through the work-energy theorem, which states that the net work done on an object
                  equals its change in kinetic energy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The SI unit for both work and energy is the Joule (J), named after physicist James Prescott Joule. One
                  Joule is defined as the work done when a force of one Newton moves an object one meter in the
                  direction of the force. Understanding these relationships is essential for analyzing mechanical
                  systems, from simple machines to complex engineering applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Energy</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Kinetic Energy</h4>
                    <p className="text-blue-700 text-sm">
                      Kinetic energy is the energy of motion. Any object that is moving has kinetic energy, which
                      depends on both its mass and velocity. The formula KE = ½mv² shows that kinetic energy increases
                      with the square of velocity—doubling the speed quadruples the kinetic energy. This is why
                      high-speed impacts are so much more destructive than low-speed ones.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Potential Energy</h4>
                    <p className="text-green-700 text-sm">
                      Gravitational potential energy is stored energy due to an object's position in a gravitational
                      field. An object at height h above a reference point has potential energy PE = mgh. This energy
                      can be converted to kinetic energy when the object falls. Other forms include elastic potential
                      energy (stored in springs) and chemical potential energy (stored in molecular bonds).
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Conservation of Energy</h4>
                    <p className="text-purple-700 text-sm">
                      In an isolated system, the total mechanical energy (KE + PE) remains constant. As an object falls,
                      potential energy converts to kinetic energy, but the total remains the same. This principle is
                      fundamental to understanding pendulums, roller coasters, and many other mechanical systems.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Work and energy calculations are essential in numerous real-world applications. Engineers use these
                  principles to design efficient machines, vehicles, and structures. In automotive engineering, kinetic
                  energy calculations determine braking distances and crash safety requirements. Potential energy
                  concepts are crucial in hydroelectric power generation, where water's gravitational potential energy
                  is converted to electrical energy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In construction, work calculations help determine the power needed for cranes and lifts. Sports
                  scientists use kinetic energy analysis to optimize athletic performance. Energy conservation
                  principles guide the design of roller coasters, ensuring thrilling but safe rides. Understanding these
                  concepts helps us build more efficient systems and better understand the physical world around us.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
