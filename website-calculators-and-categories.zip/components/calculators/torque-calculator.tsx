"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Wrench, Info, AlertTriangle, Cog, RotateCw } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "torque" | "force" | "distance"

interface TorqueResult {
  value: number
  unit: string
  formula: string
  steps: string[]
}

const forceUnits = [
  { value: "N", label: "Newton (N)", toNewton: 1 },
  { value: "kgf", label: "Kilogram-force (kgf)", toNewton: 9.80665 },
  { value: "lbf", label: "Pound-force (lbf)", toNewton: 4.44822 },
]

const distanceUnits = [
  { value: "m", label: "Meters (m)", toMeters: 1 },
  { value: "cm", label: "Centimeters (cm)", toMeters: 0.01 },
  { value: "ft", label: "Feet (ft)", toMeters: 0.3048 },
  { value: "in", label: "Inches (in)", toMeters: 0.0254 },
]

const torqueUnits = [
  { value: "Nm", label: "Newton-meter (N·m)", fromNm: 1 },
  { value: "kgfm", label: "Kilogram-force meter (kgf·m)", fromNm: 1 / 9.80665 },
  { value: "lbfft", label: "Pound-force foot (lb·ft)", fromNm: 0.737562 },
]

export function TorqueCalculator() {
  const [mode, setMode] = useState<CalculationMode>("torque")
  const [force, setForce] = useState("")
  const [forceUnit, setForceUnit] = useState("N")
  const [distance, setDistance] = useState("")
  const [distanceUnit, setDistanceUnit] = useState("m")
  const [torque, setTorque] = useState("")
  const [torqueUnit, setTorqueUnit] = useState("Nm")
  const [angle, setAngle] = useState("90")
  const [result, setResult] = useState<TorqueResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const angleNum = Number.parseFloat(angle) || 90
    if (angleNum <= 0 || angleNum > 180) {
      setError("Angle must be between 0° and 180°")
      return
    }

    const sinAngle = Math.sin((angleNum * Math.PI) / 180)
    const steps: string[] = []

    if (mode === "torque") {
      const forceNum = Number.parseFloat(force)
      const distanceNum = Number.parseFloat(distance)

      if (isNaN(forceNum) || forceNum <= 0) {
        setError("Please enter a valid force greater than 0")
        return
      }
      if (isNaN(distanceNum) || distanceNum <= 0) {
        setError("Please enter a valid distance greater than 0")
        return
      }

      const forceConversion = forceUnits.find((u) => u.value === forceUnit)!
      const distanceConversion = distanceUnits.find((u) => u.value === distanceUnit)!
      const torqueConversion = torqueUnits.find((u) => u.value === torqueUnit)!

      const forceInNewtons = forceNum * forceConversion.toNewton
      const distanceInMeters = distanceNum * distanceConversion.toMeters

      steps.push(`Force: ${forceNum} ${forceUnit} = ${forceInNewtons.toFixed(4)} N`)
      steps.push(`Distance: ${distanceNum} ${distanceUnit} = ${distanceInMeters.toFixed(4)} m`)
      steps.push(`Angle: ${angleNum}° → sin(${angleNum}°) = ${sinAngle.toFixed(4)}`)

      const torqueInNm = forceInNewtons * distanceInMeters * sinAngle
      steps.push(
        `Torque = F × r × sin(θ) = ${forceInNewtons.toFixed(4)} × ${distanceInMeters.toFixed(4)} × ${sinAngle.toFixed(4)}`,
      )
      steps.push(`Torque = ${torqueInNm.toFixed(4)} N·m`)

      const finalTorque = torqueInNm * torqueConversion.fromNm

      if (torqueUnit !== "Nm") {
        steps.push(`Converting to ${torqueUnit}: ${finalTorque.toFixed(4)} ${torqueUnit}`)
      }

      setResult({
        value: finalTorque,
        unit: torqueUnit === "Nm" ? "N·m" : torqueUnit === "kgfm" ? "kgf·m" : "lb·ft",
        formula: "τ = F × r × sin(θ)",
        steps,
      })
    } else if (mode === "force") {
      const torqueNum = Number.parseFloat(torque)
      const distanceNum = Number.parseFloat(distance)

      if (isNaN(torqueNum) || torqueNum <= 0) {
        setError("Please enter a valid torque greater than 0")
        return
      }
      if (isNaN(distanceNum) || distanceNum <= 0) {
        setError("Please enter a valid distance greater than 0")
        return
      }
      if (sinAngle === 0) {
        setError("Cannot calculate force when angle is 0° or 180°")
        return
      }

      const torqueConversion = torqueUnits.find((u) => u.value === torqueUnit)!
      const distanceConversion = distanceUnits.find((u) => u.value === distanceUnit)!
      const forceConversion = forceUnits.find((u) => u.value === forceUnit)!

      const torqueInNm = torqueNum / torqueConversion.fromNm
      const distanceInMeters = distanceNum * distanceConversion.toMeters

      steps.push(
        `Torque: ${torqueNum} ${torqueUnit === "Nm" ? "N·m" : torqueUnit === "kgfm" ? "kgf·m" : "lb·ft"} = ${torqueInNm.toFixed(4)} N·m`,
      )
      steps.push(`Distance: ${distanceNum} ${distanceUnit} = ${distanceInMeters.toFixed(4)} m`)
      steps.push(`Angle: ${angleNum}° → sin(${angleNum}°) = ${sinAngle.toFixed(4)}`)

      const forceInNewtons = torqueInNm / (distanceInMeters * sinAngle)
      steps.push(
        `Force = τ ÷ (r × sin(θ)) = ${torqueInNm.toFixed(4)} ÷ (${distanceInMeters.toFixed(4)} × ${sinAngle.toFixed(4)})`,
      )
      steps.push(`Force = ${forceInNewtons.toFixed(4)} N`)

      const finalForce = forceInNewtons / forceConversion.toNewton

      if (forceUnit !== "N") {
        steps.push(`Converting to ${forceUnit}: ${finalForce.toFixed(4)} ${forceUnit}`)
      }

      setResult({
        value: finalForce,
        unit: forceUnit,
        formula: "F = τ ÷ (r × sin(θ))",
        steps,
      })
    } else {
      const torqueNum = Number.parseFloat(torque)
      const forceNum = Number.parseFloat(force)

      if (isNaN(torqueNum) || torqueNum <= 0) {
        setError("Please enter a valid torque greater than 0")
        return
      }
      if (isNaN(forceNum) || forceNum <= 0) {
        setError("Please enter a valid force greater than 0")
        return
      }
      if (sinAngle === 0) {
        setError("Cannot calculate distance when angle is 0° or 180°")
        return
      }

      const torqueConversion = torqueUnits.find((u) => u.value === torqueUnit)!
      const forceConversion = forceUnits.find((u) => u.value === forceUnit)!
      const distanceConversion = distanceUnits.find((u) => u.value === distanceUnit)!

      const torqueInNm = torqueNum / torqueConversion.fromNm
      const forceInNewtons = forceNum * forceConversion.toNewton

      steps.push(
        `Torque: ${torqueNum} ${torqueUnit === "Nm" ? "N·m" : torqueUnit === "kgfm" ? "kgf·m" : "lb·ft"} = ${torqueInNm.toFixed(4)} N·m`,
      )
      steps.push(`Force: ${forceNum} ${forceUnit} = ${forceInNewtons.toFixed(4)} N`)
      steps.push(`Angle: ${angleNum}° → sin(${angleNum}°) = ${sinAngle.toFixed(4)}`)

      const distanceInMeters = torqueInNm / (forceInNewtons * sinAngle)
      steps.push(
        `Distance = τ ÷ (F × sin(θ)) = ${torqueInNm.toFixed(4)} ÷ (${forceInNewtons.toFixed(4)} × ${sinAngle.toFixed(4)})`,
      )
      steps.push(`Distance = ${distanceInMeters.toFixed(4)} m`)

      const finalDistance = distanceInMeters / distanceConversion.toMeters

      if (distanceUnit !== "m") {
        steps.push(`Converting to ${distanceUnit}: ${finalDistance.toFixed(4)} ${distanceUnit}`)
      }

      setResult({
        value: finalDistance,
        unit: distanceUnit,
        formula: "r = τ ÷ (F × sin(θ))",
        steps,
      })
    }
  }

  const handleReset = () => {
    setForce("")
    setDistance("")
    setTorque("")
    setAngle("90")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const label = mode === "torque" ? "Torque" : mode === "force" ? "Force" : "Distance"
      await navigator.clipboard.writeText(`${label}: ${result.value.toFixed(4)} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const label = mode === "torque" ? "Torque" : mode === "force" ? "Force" : "Distance"
      try {
        await navigator.share({
          title: "Torque Calculator Result",
          text: `I calculated ${label}: ${result.value.toFixed(4)} ${result.unit} using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1000000 || (Math.abs(num) < 0.0001 && num !== 0)) {
      return num.toExponential(4)
    }
    return num.toFixed(4)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <RotateCw className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Torque Calculator</CardTitle>
                    <CardDescription>Calculate torque, force, or lever arm</CardDescription>
                  </div>
                </div>

                {/* Mode Selector */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Calculate</Label>
                  <Select
                    value={mode}
                    onValueChange={(value: CalculationMode) => {
                      setMode(value)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="torque">Torque from Force & Distance</SelectItem>
                      <SelectItem value="force">Force from Torque & Distance</SelectItem>
                      <SelectItem value="distance">Distance from Torque & Force</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Force Input */}
                {(mode === "torque" || mode === "distance") && (
                  <div className="space-y-2">
                    <Label>Force</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter force"
                        value={force}
                        onChange={(e) => setForce(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={forceUnit} onValueChange={setForceUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {forceUnits.map((unit) => (
                            <SelectItem key={unit.value} value={unit.value}>
                              {unit.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Distance Input */}
                {(mode === "torque" || mode === "force") && (
                  <div className="space-y-2">
                    <Label>Lever Arm Distance</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter distance"
                        value={distance}
                        onChange={(e) => setDistance(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={distanceUnit} onValueChange={setDistanceUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {distanceUnits.map((unit) => (
                            <SelectItem key={unit.value} value={unit.value}>
                              {unit.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Torque Input */}
                {(mode === "force" || mode === "distance") && (
                  <div className="space-y-2">
                    <Label>Torque</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter torque"
                        value={torque}
                        onChange={(e) => setTorque(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={torqueUnit} onValueChange={setTorqueUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {torqueUnits.map((unit) => (
                            <SelectItem key={unit.value} value={unit.value}>
                              {unit.value === "Nm" ? "N·m" : unit.value === "kgfm" ? "kgf·m" : "lb·ft"}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Angle Input */}
                <div className="space-y-2">
                  <Label>Angle between Force and Lever Arm (°)</Label>
                  <Input
                    type="number"
                    placeholder="90"
                    value={angle}
                    onChange={(e) => setAngle(e.target.value)}
                    min="0"
                    max="180"
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">Default is 90° (perpendicular force)</p>
                </div>

                {/* Output Unit Selector */}
                {mode === "torque" && (
                  <div className="space-y-2">
                    <Label>Output Unit</Label>
                    <Select value={torqueUnit} onValueChange={setTorqueUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {torqueUnits.map((unit) => (
                          <SelectItem key={unit.value} value={unit.value}>
                            {unit.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {mode === "force" && (
                  <div className="space-y-2">
                    <Label>Output Unit</Label>
                    <Select value={forceUnit} onValueChange={setForceUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {forceUnits.map((unit) => (
                          <SelectItem key={unit.value} value={unit.value}>
                            {unit.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {mode === "distance" && (
                  <div className="space-y-2">
                    <Label>Output Unit</Label>
                    <Select value={distanceUnit} onValueChange={setDistanceUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {distanceUnits.map((unit) => (
                          <SelectItem key={unit.value} value={unit.value}>
                            {unit.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {mode === "torque" ? "Torque" : mode === "force" ? "Force" : "Distance"}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "torque" ? "Torque" : mode === "force" ? "Force" : "Lever Arm Distance"}
                      </p>
                      <p className="text-4xl font-bold text-orange-600 mb-1">{formatNumber(result.value)}</p>
                      <p className="text-lg font-medium text-orange-600">{result.unit}</p>
                      <p className="text-sm text-muted-foreground mt-2">Formula: {result.formula}</p>
                    </div>

                    {/* Steps */}
                    <div className="mt-4 p-3 bg-white rounded-lg border">
                      <p className="text-sm font-medium mb-2">Calculation Steps:</p>
                      <div className="space-y-1">
                        {result.steps.map((step, index) => (
                          <p key={index} className="text-xs text-muted-foreground font-mono">
                            {step}
                          </p>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Torque Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                    <p className="font-medium text-orange-800">Torque</p>
                    <p className="font-mono text-sm text-orange-700">τ = F × r × sin(θ)</p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-800">Force</p>
                    <p className="font-mono text-sm text-blue-700">F = τ ÷ (r × sin(θ))</p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-800">Lever Arm</p>
                    <p className="font-mono text-sm text-green-700">r = τ ÷ (F × sin(θ))</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Presets</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                    <div className="flex items-center gap-2">
                      <Wrench className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Wheel Lug Nut</span>
                    </div>
                    <span className="text-sm text-muted-foreground">80-120 N·m</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                    <div className="flex items-center gap-2">
                      <Cog className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Cylinder Head Bolt</span>
                    </div>
                    <span className="text-sm text-muted-foreground">50-90 N·m</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                    <div className="flex items-center gap-2">
                      <Wrench className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Spark Plug</span>
                    </div>
                    <span className="text-sm text-muted-foreground">15-25 N·m</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2 text-amber-800">
                    <AlertTriangle className="h-5 w-5" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-amber-700">
                    Results are theoretical and assume ideal conditions without friction losses. Always verify critical
                    torque values with manufacturer specifications.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Torque?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Torque, also known as moment of force, is a measure of the rotational force applied to an object
                  around an axis or pivot point. It represents the tendency of a force to cause or change the rotational
                  motion of an object. Unlike linear force, which causes objects to move in a straight line, torque
                  causes objects to rotate or twist around a specific point.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of torque is fundamental in physics and engineering, appearing in countless applications
                  from simple tools like wrenches and screwdrivers to complex machinery like engines, motors, and
                  robotic systems. Understanding torque is essential for designing mechanical systems, ensuring proper
                  fastener tightness, and optimizing the performance of rotating equipment.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Cog className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Torque Formula</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The torque formula τ = F × r × sin(θ) consists of three key components. First, Force (F) is the
                  magnitude of the applied force, measured in Newtons (N), kilogram-force (kgf), or pound-force (lbf).
                  The greater the force applied, the more torque is generated.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Second, the Lever Arm Distance (r) is the perpendicular distance from the axis of rotation to the
                  point where the force is applied. This is why using a longer wrench makes it easier to loosen a tight
                  bolt. The longer the lever arm, the more torque you can generate with the same force.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Third, the Angle (θ) between the force vector and the lever arm affects how efficiently the force
                  generates rotation. When the force is applied perpendicular to the lever arm (90°), sin(90°) = 1,
                  maximizing the torque. At other angles, the effective torque is reduced by the sine of that angle.
                  This is why you instinctively push perpendicular to a door when opening it.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Wrench className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications of Torque</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Torque plays a critical role in automotive applications. Engine specifications often include torque
                  ratings, which determine the vehicle's acceleration and towing capacity. Proper torque settings for
                  fasteners like lug nuts, cylinder head bolts, and spark plugs are essential for safety and preventing
                  damage. Using a torque wrench ensures bolts are tightened to manufacturer specifications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In industrial settings, electric motors and machines are rated by their torque output, which
                  determines their ability to perform work. Manufacturing processes often require precise torque control
                  to ensure product quality and equipment longevity. Robotics and automation systems rely heavily on
                  torque calculations for accurate movement and force control.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Even in everyday life, torque principles are at work. Opening a door, turning a steering wheel,
                  pedaling a bicycle, or using a screwdriver all involve applying torque. Understanding these principles
                  can help you work more efficiently and avoid common mistakes like stripping threads or over-tightening
                  fasteners.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <RotateCw className="h-5 w-5 text-primary" />
                  <CardTitle>Units and Conversions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Torque is expressed as a force multiplied by a distance, resulting in units like Newton-meters (N·m),
                  kilogram-force meters (kgf·m), or pound-force feet (lb·ft). The SI unit is the Newton-meter, which
                  represents the torque produced by a force of one Newton applied at a perpendicular distance of one
                  meter from the axis of rotation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Converting between units is important when working with specifications from different regions. For
                  example, 1 N·m equals approximately 0.7376 lb·ft, and 1 lb·ft equals approximately 1.356 N·m. In
                  automotive contexts, European and Asian vehicles typically use N·m specifications, while American
                  vehicles often use lb·ft. Understanding these conversions ensures you apply the correct torque
                  regardless of the specification source.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
