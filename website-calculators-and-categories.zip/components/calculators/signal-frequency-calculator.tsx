"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, Radio } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMode = "period" | "wave"
type TimeUnit = "s" | "ms" | "us" | "ns"
type FrequencyUnit = "Hz" | "kHz" | "MHz" | "GHz"
type LengthUnit = "m" | "cm" | "mm" | "km"

interface FrequencyResult {
  frequency: number
  displayFrequency: string
  category: string
  color: string
  bgColor: string
  period: number
  wavelength?: number
}

export function SignalFrequencyCalculator() {
  const [mode, setMode] = useState<CalculationMode>("period")
  const [period, setPeriod] = useState("")
  const [timeUnit, setTimeUnit] = useState<TimeUnit>("s")
  const [wavelength, setWavelength] = useState("")
  const [lengthUnit, setLengthUnit] = useState<LengthUnit>("m")
  const [waveSpeed, setWaveSpeed] = useState("")
  const [frequencyUnit, setFrequencyUnit] = useState<FrequencyUnit>("Hz")
  const [result, setResult] = useState<FrequencyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const timeConversions: Record<TimeUnit, number> = {
    s: 1,
    ms: 1e-3,
    us: 1e-6,
    ns: 1e-9,
  }

  const lengthConversions: Record<LengthUnit, number> = {
    m: 1,
    cm: 0.01,
    mm: 0.001,
    km: 1000,
  }

  const frequencyConversions: Record<FrequencyUnit, number> = {
    Hz: 1,
    kHz: 1e3,
    MHz: 1e6,
    GHz: 1e9,
  }

  const calculateFrequency = () => {
    setError("")
    setResult(null)

    let frequencyHz: number
    let periodSeconds: number
    let wavelengthM: number | undefined

    if (mode === "period") {
      const periodNum = Number.parseFloat(period)
      if (isNaN(periodNum) || periodNum <= 0) {
        setError("Please enter a valid time period greater than 0")
        return
      }

      periodSeconds = periodNum * timeConversions[timeUnit]
      frequencyHz = 1 / periodSeconds
    } else {
      const wavelengthNum = Number.parseFloat(wavelength)
      const waveSpeedNum = Number.parseFloat(waveSpeed)

      if (isNaN(wavelengthNum) || wavelengthNum <= 0) {
        setError("Please enter a valid wavelength greater than 0")
        return
      }
      if (isNaN(waveSpeedNum) || waveSpeedNum <= 0) {
        setError("Please enter a valid wave speed greater than 0")
        return
      }

      wavelengthM = wavelengthNum * lengthConversions[lengthUnit]
      frequencyHz = waveSpeedNum / wavelengthM
      periodSeconds = 1 / frequencyHz
    }

    const displayFrequency = frequencyHz / frequencyConversions[frequencyUnit]

    let category: string
    let color: string
    let bgColor: string

    if (frequencyHz < 20) {
      category = "Infrasound"
      color = "text-purple-600"
      bgColor = "bg-purple-50 border-purple-200"
    } else if (frequencyHz < 20000) {
      category = "Audio Frequency"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (frequencyHz < 3e9) {
      category = "Radio Frequency"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (frequencyHz < 3e12) {
      category = "Microwave"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "High Frequency"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      frequency: frequencyHz,
      displayFrequency: displayFrequency.toFixed(6).replace(/\.?0+$/, ""),
      category,
      color,
      bgColor,
      period: periodSeconds,
      wavelength: wavelengthM,
    })
  }

  const handleReset = () => {
    setPeriod("")
    setWavelength("")
    setWaveSpeed("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Signal Frequency: ${result.displayFrequency} ${frequencyUnit} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatScientific = (num: number): string => {
    if (num === 0) return "0"
    if (num >= 0.001 && num < 1000000) {
      return num.toPrecision(6).replace(/\.?0+$/, "")
    }
    return num.toExponential(4)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Radio className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Signal Frequency Calculator</CardTitle>
                    <CardDescription>Calculate frequency from period or wavelength</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Mode</span>
                  <button
                    onClick={() => {
                      setMode(mode === "period" ? "wave" : "period")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "wave" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "period" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      From Period
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "wave" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      From Wave
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {mode === "period" ? (
                  /* Period Mode */
                  <div className="space-y-2">
                    <Label htmlFor="period">Time Period (T)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="period"
                        type="number"
                        placeholder="Enter time period"
                        value={period}
                        onChange={(e) => setPeriod(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <select
                        value={timeUnit}
                        onChange={(e) => setTimeUnit(e.target.value as TimeUnit)}
                        className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                      >
                        <option value="s">s</option>
                        <option value="ms">ms</option>
                        <option value="us">µs</option>
                        <option value="ns">ns</option>
                      </select>
                    </div>
                  </div>
                ) : (
                  /* Wave Mode */
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="wavelength">Wavelength (λ)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="wavelength"
                          type="number"
                          placeholder="Enter wavelength"
                          value={wavelength}
                          onChange={(e) => setWavelength(e.target.value)}
                          min="0"
                          step="any"
                          className="flex-1"
                        />
                        <select
                          value={lengthUnit}
                          onChange={(e) => setLengthUnit(e.target.value as LengthUnit)}
                          className="w-20 rounded-md border border-input bg-background px-3 py-2 text-sm"
                        >
                          <option value="m">m</option>
                          <option value="cm">cm</option>
                          <option value="mm">mm</option>
                          <option value="km">km</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="waveSpeed">Wave Speed (v) in m/s</Label>
                      <Input
                        id="waveSpeed"
                        type="number"
                        placeholder="Enter wave speed (e.g., 299792458 for light)"
                        value={waveSpeed}
                        onChange={(e) => setWaveSpeed(e.target.value)}
                        min="0"
                        step="any"
                      />
                      <div className="flex flex-wrap gap-2 mt-2">
                        <Button type="button" variant="outline" size="sm" onClick={() => setWaveSpeed("299792458")}>
                          Light (c)
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setWaveSpeed("343")}>
                          Sound (Air)
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setWaveSpeed("1500")}>
                          Sound (Water)
                        </Button>
                      </div>
                    </div>
                  </>
                )}

                {/* Output Unit */}
                <div className="space-y-2">
                  <Label>Output Frequency Unit</Label>
                  <select
                    value={frequencyUnit}
                    onChange={(e) => setFrequencyUnit(e.target.value as FrequencyUnit)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="Hz">Hz (Hertz)</option>
                    <option value="kHz">kHz (Kilohertz)</option>
                    <option value="MHz">MHz (Megahertz)</option>
                    <option value="GHz">GHz (Gigahertz)</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFrequency} className="w-full" size="lg">
                  Calculate Frequency
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Signal Frequency</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.displayFrequency} {frequencyUnit}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Period</p>
                        <p className="font-semibold">{formatScientific(result.period)} s</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">In Hz</p>
                        <p className="font-semibold">{formatScientific(result.frequency)}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setShowSteps(!showSteps)}>
                        {showSteps ? "Hide Steps" : "Show Steps"}
                      </Button>
                    </div>

                    {/* Step-by-step breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white/70 rounded-lg text-sm space-y-2">
                        <p className="font-semibold">Calculation Steps:</p>
                        {mode === "period" ? (
                          <>
                            <p>
                              1. Period T = {period} {timeUnit} ={" "}
                              {formatScientific(Number.parseFloat(period) * timeConversions[timeUnit])} s
                            </p>
                            <p>2. Using formula: f = 1 / T</p>
                            <p>3. f = 1 / {formatScientific(result.period)} s</p>
                            <p>4. f = {formatScientific(result.frequency)} Hz</p>
                            <p>
                              5. f = {result.displayFrequency} {frequencyUnit}
                            </p>
                          </>
                        ) : (
                          <>
                            <p>
                              1. Wavelength λ = {wavelength} {lengthUnit} = {formatScientific(result.wavelength!)} m
                            </p>
                            <p>2. Wave speed v = {waveSpeed} m/s</p>
                            <p>3. Using formula: f = v / λ</p>
                            <p>
                              4. f = {waveSpeed} / {formatScientific(result.wavelength!)} m
                            </p>
                            <p>5. f = {formatScientific(result.frequency)} Hz</p>
                            <p>
                              6. f = {result.displayFrequency} {frequencyUnit}
                            </p>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Frequency Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">f = 1 / T</p>
                    <p className="text-sm text-muted-foreground mt-1">From time period</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">f = v / λ</p>
                    <p className="text-sm text-muted-foreground mt-1">From wave speed and wavelength</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Frequency Bands</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Infrasound</span>
                      <span className="text-sm text-purple-600">{"< 20 Hz"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Audio</span>
                      <span className="text-sm text-green-600">20 Hz – 20 kHz</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Radio</span>
                      <span className="text-sm text-blue-600">20 kHz – 3 GHz</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Microwave</span>
                      <span className="text-sm text-orange-600">3 GHz – 3 THz</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Signal Frequency */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Signal Frequency?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Signal frequency is the number of complete oscillations or cycles that a periodic signal completes per
                  unit of time, typically measured in Hertz (Hz). It is a fundamental property of waves and oscillations
                  that describes how rapidly a signal repeats its pattern. Higher frequencies mean more cycles per
                  second, while lower frequencies indicate slower oscillations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Frequency is inversely related to the period of a signal - the time it takes to complete one full
                  cycle. For electromagnetic waves traveling at the speed of light, frequency is also related to
                  wavelength by the wave equation f = v/λ, where v is the wave speed and λ is the wavelength.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Radio className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Frequency Analysis</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Telecommunications</h4>
                    <p className="text-blue-700 text-sm">
                      Radio broadcasting, cellular networks, WiFi, and satellite communications all rely on specific
                      frequency bands for signal transmission and reception.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Audio Engineering</h4>
                    <p className="text-green-700 text-sm">
                      Sound frequency determines pitch in music and speech. Equalizers adjust frequency content, and
                      speakers are designed to reproduce specific frequency ranges.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Medical Imaging</h4>
                    <p className="text-purple-700 text-sm">
                      Ultrasound uses high-frequency sound waves for imaging. MRI machines use radio frequency pulses to
                      generate detailed images of internal body structures.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Electronics</h4>
                    <p className="text-orange-700 text-sm">
                      Clock frequencies determine processor speeds. Signal processing, filtering, and modulation all
                      depend on accurate frequency calculations.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Signal frequency calculations are based on ideal waveforms and constant time periods. Actual
                      signals may vary due to noise, modulation, or distortion. Consult electronics references for
                      precise analysis.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
