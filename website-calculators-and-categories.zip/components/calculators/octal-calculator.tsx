"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Binary,
  Info,
  ChevronDown,
  ChevronUp,
  Calculator,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type Operation =
  | "add"
  | "subtract"
  | "multiply"
  | "divide"
  | "modulo"
  | "power"
  | "and"
  | "or"
  | "xor"
  | "not"
  | "leftShift"
  | "rightShift"
type InputMode = "octal" | "decimal"
type BitWidth = 8 | 16 | 32 | 64

interface OctalResult {
  octal: string
  decimal: number
  binary: string
  hex: string
  overflow: boolean
  underflow: boolean
}

interface Step {
  description: string
  value: string
}

export function OctalCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("octal")
  const [operand1, setOperand1] = useState("")
  const [operand2, setOperand2] = useState("")
  const [operation, setOperation] = useState<Operation>("add")
  const [bitWidth, setBitWidth] = useState<BitWidth>(32)
  const [signed, setSigned] = useState(false)
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<OctalResult | null>(null)
  const [steps, setSteps] = useState<Step[]>([])
  const [copied, setCopied] = useState<string | null>(null)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const isValidOctal = (str: string): boolean => {
    if (!str) return false
    const cleaned = str.replace(/^0o?/i, "")
    return /^[0-7]+$/.test(cleaned)
  }

  const parseInput = (input: string): number | null => {
    if (!input) return null

    if (inputMode === "octal") {
      const cleaned = input.replace(/^0o?/i, "")
      if (!isValidOctal(input)) return null
      return Number.parseInt(cleaned, 8)
    } else {
      const num = Number.parseInt(input, 10)
      return isNaN(num) ? null : num
    }
  }

  const toOctal = (num: number): string => {
    if (num < 0) {
      // Handle negative numbers using two's complement
      const maxVal = Math.pow(2, bitWidth)
      num = maxVal + num
    }
    return num.toString(8)
  }

  const toBinary = (num: number): string => {
    if (num < 0) {
      const maxVal = Math.pow(2, bitWidth)
      num = maxVal + num
    }
    return num.toString(2).padStart(bitWidth, "0")
  }

  const toHex = (num: number): string => {
    if (num < 0) {
      const maxVal = Math.pow(2, bitWidth)
      num = maxVal + num
    }
    return num.toString(16).toUpperCase()
  }

  const checkOverflow = (num: number): { value: number; overflow: boolean; underflow: boolean } => {
    const maxVal = signed ? Math.pow(2, bitWidth - 1) - 1 : Math.pow(2, bitWidth) - 1
    const minVal = signed ? -Math.pow(2, bitWidth - 1) : 0

    let overflow = false
    let underflow = false

    if (num > maxVal) {
      overflow = true
      num = signed ? num - Math.pow(2, bitWidth) : num % Math.pow(2, bitWidth)
    } else if (num < minVal) {
      underflow = true
      num = signed ? num + Math.pow(2, bitWidth) : Math.pow(2, bitWidth) + num
    }

    return { value: num, overflow, underflow }
  }

  const calculate = () => {
    setError("")
    setResult(null)
    setSteps([])

    const num1 = parseInput(operand1)

    if (num1 === null) {
      setError(`Please enter a valid ${inputMode} number for the first operand`)
      return
    }

    const calculationSteps: Step[] = []

    calculationSteps.push({
      description: `Parse first operand`,
      value: `${operand1} ${inputMode === "octal" ? "(octal)" : "(decimal)"} = ${num1} (decimal)`,
    })

    let resultNum: number

    if (operation === "not") {
      // NOT is unary
      const notResult = ~num1 >>> 0
      const masked = notResult & (Math.pow(2, bitWidth) - 1)
      resultNum = signed && masked >= Math.pow(2, bitWidth - 1) ? masked - Math.pow(2, bitWidth) : masked

      calculationSteps.push({
        description: `Apply NOT operation`,
        value: `~${num1} = ${resultNum}`,
      })
    } else {
      const num2 = parseInput(operand2)

      if (num2 === null) {
        setError(`Please enter a valid ${inputMode} number for the second operand`)
        return
      }

      calculationSteps.push({
        description: `Parse second operand`,
        value: `${operand2} ${inputMode === "octal" ? "(octal)" : "(decimal)"} = ${num2} (decimal)`,
      })

      switch (operation) {
        case "add":
          resultNum = num1 + num2
          calculationSteps.push({
            description: `Addition`,
            value: `${num1} + ${num2} = ${resultNum}`,
          })
          break
        case "subtract":
          resultNum = num1 - num2
          calculationSteps.push({
            description: `Subtraction`,
            value: `${num1} - ${num2} = ${resultNum}`,
          })
          break
        case "multiply":
          resultNum = num1 * num2
          calculationSteps.push({
            description: `Multiplication`,
            value: `${num1} × ${num2} = ${resultNum}`,
          })
          break
        case "divide":
          if (num2 === 0) {
            setError("Cannot divide by zero")
            return
          }
          resultNum = Math.trunc(num1 / num2)
          calculationSteps.push({
            description: `Integer Division`,
            value: `${num1} ÷ ${num2} = ${resultNum}`,
          })
          break
        case "modulo":
          if (num2 === 0) {
            setError("Cannot modulo by zero")
            return
          }
          resultNum = num1 % num2
          calculationSteps.push({
            description: `Modulo`,
            value: `${num1} mod ${num2} = ${resultNum}`,
          })
          break
        case "power":
          resultNum = Math.pow(num1, num2)
          calculationSteps.push({
            description: `Exponentiation`,
            value: `${num1}^${num2} = ${resultNum}`,
          })
          break
        case "and":
          resultNum = num1 & num2
          calculationSteps.push({
            description: `Bitwise AND`,
            value: `${num1} AND ${num2} = ${resultNum}`,
          })
          break
        case "or":
          resultNum = num1 | num2
          calculationSteps.push({
            description: `Bitwise OR`,
            value: `${num1} OR ${num2} = ${resultNum}`,
          })
          break
        case "xor":
          resultNum = num1 ^ num2
          calculationSteps.push({
            description: `Bitwise XOR`,
            value: `${num1} XOR ${num2} = ${resultNum}`,
          })
          break
        case "leftShift":
          resultNum = num1 << num2
          calculationSteps.push({
            description: `Left Shift`,
            value: `${num1} << ${num2} = ${resultNum}`,
          })
          break
        case "rightShift":
          resultNum = num1 >> num2
          calculationSteps.push({
            description: `Right Shift`,
            value: `${num1} >> ${num2} = ${resultNum}`,
          })
          break
        default:
          resultNum = 0
      }
    }

    const { value: finalValue, overflow, underflow } = checkOverflow(resultNum)

    if (overflow || underflow) {
      calculationSteps.push({
        description: overflow ? `Overflow detected` : `Underflow detected`,
        value: `Result wrapped to ${finalValue} within ${bitWidth}-bit range`,
      })
    }

    calculationSteps.push({
      description: `Convert to octal`,
      value: `${finalValue} (decimal) = ${toOctal(finalValue)} (octal)`,
    })

    setSteps(calculationSteps)
    setResult({
      octal: toOctal(finalValue),
      decimal: finalValue,
      binary: toBinary(finalValue),
      hex: toHex(finalValue),
      overflow,
      underflow,
    })
  }

  const handleReset = () => {
    setOperand1("")
    setOperand2("")
    setResult(null)
    setSteps([])
    setError("")
    setCopied(null)
    setShowDetails(false)
  }

  const handleCopy = async (value: string, type: string) => {
    await navigator.clipboard.writeText(value)
    setCopied(type)
    setTimeout(() => setCopied(null), 2000)
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Octal Calculator Result",
          text: `Octal: ${result.octal}\nDecimal: ${result.decimal}\nBinary: ${result.binary}\nHex: ${result.hex}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const operationLabels: Record<Operation, string> = {
    add: "Addition (+)",
    subtract: "Subtraction (−)",
    multiply: "Multiplication (×)",
    divide: "Division (÷)",
    modulo: "Modulo (%)",
    power: "Power (^)",
    and: "Bitwise AND",
    or: "Bitwise OR",
    xor: "Bitwise XOR",
    not: "Bitwise NOT",
    leftShift: "Left Shift (<<)",
    rightShift: "Right Shift (>>)",
  }

  const isUnaryOperation = operation === "not"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Binary className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Octal Calculator</CardTitle>
                    <CardDescription>Perform octal arithmetic and bitwise operations</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between">
                  <Label>Input Mode</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={inputMode === "octal" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setInputMode("octal")}
                    >
                      Octal
                    </Button>
                    <Button
                      variant={inputMode === "decimal" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setInputMode("decimal")}
                    >
                      Decimal
                    </Button>
                  </div>
                </div>

                {/* First Operand */}
                <div className="space-y-2">
                  <Label htmlFor="operand1">First Operand {inputMode === "octal" ? "(e.g., 075)" : "(decimal)"}</Label>
                  <Input
                    id="operand1"
                    type="text"
                    placeholder={inputMode === "octal" ? "Enter octal number (0-7)" : "Enter decimal number"}
                    value={operand1}
                    onChange={(e) => setOperand1(e.target.value)}
                  />
                </div>

                {/* Operation Select */}
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <Select value={operation} onValueChange={(val) => setOperation(val as Operation)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="add">Addition (+)</SelectItem>
                      <SelectItem value="subtract">Subtraction (−)</SelectItem>
                      <SelectItem value="multiply">Multiplication (×)</SelectItem>
                      <SelectItem value="divide">Division (÷)</SelectItem>
                      <SelectItem value="modulo">Modulo (%)</SelectItem>
                      <SelectItem value="power">Power (^)</SelectItem>
                      <SelectItem value="and">Bitwise AND</SelectItem>
                      <SelectItem value="or">Bitwise OR</SelectItem>
                      <SelectItem value="xor">Bitwise XOR</SelectItem>
                      <SelectItem value="not">Bitwise NOT</SelectItem>
                      <SelectItem value="leftShift">Left Shift ({"<<"})</SelectItem>
                      <SelectItem value="rightShift">Right Shift ({">>"})</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Second Operand (hidden for NOT) */}
                {!isUnaryOperation && (
                  <div className="space-y-2">
                    <Label htmlFor="operand2">
                      Second Operand {inputMode === "octal" ? "(e.g., 012)" : "(decimal)"}
                    </Label>
                    <Input
                      id="operand2"
                      type="text"
                      placeholder={inputMode === "octal" ? "Enter octal number (0-7)" : "Enter decimal number"}
                      value={operand2}
                      onChange={(e) => setOperand2(e.target.value)}
                    />
                  </div>
                )}

                {/* Advanced Options */}
                <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm font-medium">Advanced Options</p>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="bitWidth" className="text-sm">
                      Bit Width
                    </Label>
                    <Select
                      value={bitWidth.toString()}
                      onValueChange={(val) => setBitWidth(Number.parseInt(val) as BitWidth)}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="8">8-bit</SelectItem>
                        <SelectItem value="16">16-bit</SelectItem>
                        <SelectItem value="32">32-bit</SelectItem>
                        <SelectItem value="64">64-bit</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="signed" className="text-sm">
                      Signed Numbers
                    </Label>
                    <Switch id="signed" checked={signed} onCheckedChange={setSigned} />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="showSteps" className="text-sm">
                      Show Steps
                    </Label>
                    <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Result (Octal)</p>
                      <p className="text-4xl font-bold text-blue-600 font-mono">{result.octal}</p>
                      {(result.overflow || result.underflow) && (
                        <p className="text-xs text-orange-600 mt-1">
                          {result.overflow ? "Overflow" : "Underflow"} detected - value wrapped
                        </p>
                      )}
                    </div>

                    {/* Multi-format output */}
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Decimal</p>
                        <div className="flex items-center justify-between">
                          <p className="font-mono text-sm font-medium">{result.decimal}</p>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => handleCopy(result.decimal.toString(), "decimal")}
                          >
                            {copied === "decimal" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          </Button>
                        </div>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Hexadecimal</p>
                        <div className="flex items-center justify-between">
                          <p className="font-mono text-sm font-medium">0x{result.hex}</p>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => handleCopy(`0x${result.hex}`, "hex")}
                          >
                            {copied === "hex" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="p-2 bg-white rounded-lg mb-4">
                      <p className="text-xs text-muted-foreground">Binary</p>
                      <div className="flex items-center justify-between">
                        <p className="font-mono text-xs font-medium break-all">{result.binary}</p>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 flex-shrink-0"
                          onClick={() => handleCopy(result.binary, "binary")}
                        >
                          {copied === "binary" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                        </Button>
                      </div>
                    </div>

                    {/* Steps */}
                    {showSteps && steps.length > 0 && (
                      <div className="mb-4">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="flex items-center gap-1 text-sm font-medium text-blue-700 hover:text-blue-800"
                        >
                          {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          {showDetails ? "Hide" : "Show"} Steps
                        </button>

                        {showDetails && (
                          <div className="mt-2 space-y-2">
                            {steps.map((step, idx) => (
                              <div key={idx} className="p-2 bg-white rounded-lg text-sm">
                                <span className="font-medium">{step.description}:</span>{" "}
                                <span className="font-mono text-muted-foreground">{step.value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleCopy(result.octal, "octal")}>
                        {copied === "octal" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied === "octal" ? "Copied" : "Copy Octal"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Octal Operations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-medium text-sm mb-2">Arithmetic</p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="font-mono">+</span> Addition
                      </div>
                      <div>
                        <span className="font-mono">−</span> Subtraction
                      </div>
                      <div>
                        <span className="font-mono">×</span> Multiplication
                      </div>
                      <div>
                        <span className="font-mono">÷</span> Division
                      </div>
                      <div>
                        <span className="font-mono">%</span> Modulo
                      </div>
                      <div>
                        <span className="font-mono">^</span> Power
                      </div>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-medium text-sm mb-2">Bitwise</p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="font-mono">AND</span> Logical AND
                      </div>
                      <div>
                        <span className="font-mono">OR</span> Logical OR
                      </div>
                      <div>
                        <span className="font-mono">XOR</span> Exclusive OR
                      </div>
                      <div>
                        <span className="font-mono">NOT</span> Complement
                      </div>
                      <div>
                        <span className="font-mono">{"<<"}</span> Left Shift
                      </div>
                      <div>
                        <span className="font-mono">{">>"}</span> Right Shift
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">10 (oct)</span>
                      <span className="font-mono">= 8 (dec)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">77 (oct)</span>
                      <span className="font-mono">= 63 (dec)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">100 (oct)</span>
                      <span className="font-mono">= 64 (dec)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span className="font-mono">777 (oct)</span>
                      <span className="font-mono">= 511 (dec)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bit Width Ranges</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-2 bg-muted rounded-lg">
                    <p>
                      <strong>8-bit:</strong> 0 to 377 (oct) / 255 (dec)
                    </p>
                  </div>
                  <div className="p-2 bg-muted rounded-lg">
                    <p>
                      <strong>16-bit:</strong> 0 to 177777 (oct) / 65535 (dec)
                    </p>
                  </div>
                  <div className="p-2 bg-muted rounded-lg">
                    <p>
                      <strong>32-bit:</strong> 0 to 37777777777 (oct)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Octal Number System?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The octal number system is a base-8 positional numeral system that uses eight symbols: 0, 1, 2, 3, 4,
                  5, 6, and 7. Each digit in an octal number represents a power of 8, just as each digit in a decimal
                  number represents a power of 10. Octal was widely used in computing during the early days because it
                  provided a convenient way to represent binary numbers in a more compact form - every three binary
                  digits can be represented by a single octal digit.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The octal system remains important in computing today, particularly in Unix/Linux file permissions
                  where each permission set (read, write, execute) for owner, group, and others is represented as a
                  three-digit octal number (e.g., 755 or 644). It's also used in some programming contexts and for
                  representing binary data in a human-readable format.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter your numbers in either octal format (using digits 0-7) or switch to decimal input mode. Select
                  the desired operation from arithmetic (addition, subtraction, multiplication, division, modulo, power)
                  or bitwise operations (AND, OR, XOR, NOT, shifts). The calculator will display results in octal,
                  decimal, binary, and hexadecimal formats.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Advanced options allow you to set the bit width (8, 16, 32, or 64 bits) for overflow handling, toggle
                  between signed and unsigned number representation, and enable step-by-step explanations of the
                  calculation process.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Octal calculations are based on standard arithmetic and bitwise rules.
                  Results may be limited by selected bit-width and signed/unsigned settings. Always verify critical
                  calculations independently.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
