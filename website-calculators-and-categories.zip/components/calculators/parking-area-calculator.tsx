"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Car, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type VehicleType = "car" | "motorcycle" | "bus" | "truck"
type ParkingLayout = "perpendicular" | "parallel" | "angled"

interface VehicleDimensions {
  length: number
  width: number
}

interface ParkingResult {
  totalArea: number
  areaPerVehicle: number
  efficiency: number
  layoutRecommendation: string
}

const vehiclePresets: Record<VehicleType, VehicleDimensions> = {
  car: { length: 5.0, width: 2.5 },
  motorcycle: { length: 2.2, width: 0.9 },
  bus: { length: 12.0, width: 2.6 },
  truck: { length: 8.0, width: 2.5 },
}

const layoutEfficiency: Record<ParkingLayout, number> = {
  perpendicular: 0.95,
  angled: 0.90,
  parallel: 0.85,
}

export function ParkingAreaCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [vehicleType, setVehicleType] = useState<VehicleType>("car")
  const [numberOfVehicles, setNumberOfVehicles] = useState("")
  const [vehicleLength, setVehicleLength] = useState("5.0")
  const [vehicleWidth, setVehicleWidth] = useState("2.5")
  const [aisleWidth, setAisleWidth] = useState("6.0")
  const [parkingLayout, setParkingLayout] = useState<ParkingLayout>("perpendicular")
  const [result, setResult] = useState<ParkingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const handleVehicleTypeChange = (type: VehicleType) => {
    setVehicleType(type)
    const preset = vehiclePresets[type]
    setVehicleLength(preset.length.toString())
    setVehicleWidth(preset.width.toString())
  }

  const calculateParkingArea = () => {
    setError("")
    setResult(null)

    const numVehicles = Number.parseFloat(numberOfVehicles)
    const length = Number.parseFloat(vehicleLength)
    const width = Number.parseFloat(vehicleWidth)
    const aisle = Number.parseFloat(aisleWidth)

    if (isNaN(numVehicles) || numVehicles <= 0) {
      setError("Please enter a valid number of vehicles greater than 0")
      return
    }

    if (isNaN(length) || length <= 0 || isNaN(width) || width <= 0) {
      setError("Please enter valid vehicle dimensions greater than 0")
      return
    }

    if (isNaN(aisle) || aisle <= 0) {
      setError("Please enter a valid aisle width greater than 0")
      return
    }

    // Convert to metric if imperial
    const lengthM = unitSystem === "imperial" ? length * 0.3048 : length
    const widthM = unitSystem === "imperial" ? width * 0.3048 : width
    const aisleM = unitSystem === "imperial" ? aisle * 0.3048 : aisle

    // Calculate area per vehicle (includes space dimensions + share of aisle)
    const spaceArea = lengthM * widthM
    const aisleShare = parkingLayout === "parallel" ? aisleM * lengthM * 0.5 : aisleM * widthM * 0.5
    const areaPerVehicle = spaceArea + aisleShare

    // Apply layout efficiency factor
    const efficiency = layoutEfficiency[parkingLayout]
    const totalArea = (areaPerVehicle * numVehicles) / efficiency

    // Convert back to imperial if needed
    const displayTotal = unitSystem === "imperial" ? totalArea * 10.7639 : totalArea
    const displayPerVehicle = unitSystem === "imperial" ? areaPerVehicle * 10.7639 : areaPerVehicle

    const layoutRecommendation =
      numVehicles < 20
        ? "Parallel parking for small lots"
        : numVehicles < 50
          ? "Angled parking (45° or 60°) for medium lots"
          : "Perpendicular parking (90°) for large lots"

    setResult({
      totalArea: displayTotal,
      areaPerVehicle: displayPerVehicle,
      efficiency: efficiency * 100,
      layoutRecommendation,
    })
  }

  const handleReset = () => {
    setNumberOfVehicles("")
    setVehicleLength("5.0")
    setVehicleWidth("2.5")
    setAisleWidth("6.0")
    setVehicleType("car")
    setParkingLayout("perpendicular")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "m²" : "ft²"
      await navigator.clipboard.writeText(
        `Parking Area: ${result.totalArea.toFixed(2)} ${unit} for ${numberOfVehicles} vehicles`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const unit = unitSystem === "metric" ? "m²" : "ft²"
        await navigator.share({
          title: "Parking Area Calculation",
          text: `I calculated parking area using CalcHub! Total area: ${result.totalArea.toFixed(2)} ${unit} for ${numberOfVehicles} vehicles`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Car className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Parking Area Calculator</CardTitle>
                    <CardDescription>Calculate required parking space</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Number of Vehicles */}
                <div className="space-y-2">
                  <Label htmlFor="vehicles">Number of Vehicles</Label>
                  <Input
                    id="vehicles"
                    type="number"
                    placeholder="Enter number of vehicles"
                    value={numberOfVehicles}
                    onChange={(e) => setNumberOfVehicles(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Vehicle Type */}
                <div className="space-y-2">
                  <Label htmlFor="vehicleType">Vehicle Type</Label>
                  <Select value={vehicleType} onValueChange={(value: VehicleType) => handleVehicleTypeChange(value)}>
                    <SelectTrigger id="vehicleType">
                      <SelectValue placeholder="Select vehicle type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="car">Car</SelectItem>
                      <SelectItem value="motorcycle">Motorcycle</SelectItem>
                      <SelectItem value="bus">Bus</SelectItem>
                      <SelectItem value="truck">Truck</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Vehicle Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder="Vehicle length"
                      value={vehicleLength}
                      onChange={(e) => setVehicleLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder="Vehicle width"
                      value={vehicleWidth}
                      onChange={(e) => setVehicleWidth(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Aisle Width */}
                <div className="space-y-2">
                  <Label htmlFor="aisle">Aisle Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="aisle"
                    type="number"
                    placeholder="Aisle width"
                    value={aisleWidth}
                    onChange={(e) => setAisleWidth(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Parking Layout */}
                <div className="space-y-2">
                  <Label htmlFor="layout">Parking Layout</Label>
                  <Select
                    value={parkingLayout}
                    onValueChange={(value: ParkingLayout) => setParkingLayout(value)}
                  >
                    <SelectTrigger id="layout">
                      <SelectValue placeholder="Select layout" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="perpendicular">Perpendicular (90°)</SelectItem>
                      <SelectItem value="angled">Angled (45°-60°)</SelectItem>
                      <SelectItem value="parallel">Parallel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateParkingArea} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Area
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Parking Area</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {result.totalArea.toFixed(2)}
                        </p>
                        <p className="text-lg font-semibold text-amber-600">
                          {unitSystem === "metric" ? "m²" : "ft²"}
                        </p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Area per Vehicle:</span>
                          <span className="font-semibold">
                            {result.areaPerVehicle.toFixed(2)} {unitSystem === "metric" ? "m²" : "ft²"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Layout Efficiency:</span>
                          <span className="font-semibold">{result.efficiency.toFixed(0)}%</span>
                        </div>
                        <div className="p-2 bg-amber-100 rounded text-amber-800 text-xs">
                          <strong>Recommendation:</strong> {result.layoutRecommendation}
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Vehicle Dimensions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Car</span>
                      <span className="text-sm text-amber-600">5.0m × 2.5m</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Motorcycle</span>
                      <span className="text-sm text-amber-600">2.2m × 0.9m</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Bus</span>
                      <span className="text-sm text-amber-600">12.0m × 2.6m</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Truck</span>
                      <span className="text-sm text-amber-600">8.0m × 2.5m</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Parking Layout Types</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p className="font-semibold text-foreground">Perpendicular (90°)</p>
                    <p>Most space-efficient for large lots. Requires wider aisles (6-7m). Efficiency: 95%</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-semibold text-foreground">Angled (45°-60°)</p>
                    <p>Easier entry/exit, moderate space use. Aisle width 4-5m. Efficiency: 90%</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-semibold text-foreground">Parallel</p>
                    <p>Best for narrow lots or streets. Less space-efficient. Efficiency: 85%</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Parking Area Planning */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Parking Area Planning?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Parking area planning involves calculating the total land area required to accommodate a specific
                  number of vehicles while ensuring safe circulation, accessibility, and compliance with local
                  regulations. Proper parking design considers vehicle dimensions, aisle widths, turning radii, traffic
                  flow patterns, and accessibility requirements for persons with disabilities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Effective parking layout maximizes space utilization while providing convenient and safe access for
                  users. Factors such as parking angle, aisle configuration, landscaping, lighting, and drainage all
                  contribute to the overall efficiency and user experience of a parking facility. Commercial and
                  residential developments must carefully plan parking areas to meet zoning requirements and provide
                  adequate capacity for peak demand periods.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Parking Area */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Parking Area</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating parking area involves determining the space required per vehicle and multiplying by the
                  total number of spaces needed. Each parking space includes not only the vehicle footprint but also a
                  proportional share of aisle width, circulation areas, and access drives. Standard car parking spaces
                  are typically 2.5m wide by 5.0m long, though dimensions may vary based on local codes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The formula considers: Area per Vehicle = (Vehicle Length × Width) + (Share of Aisle). Total Parking
                  Area = (Area per Vehicle × Number of Vehicles) ÷ Layout Efficiency Factor. The efficiency factor
                  accounts for the geometric constraints of the chosen parking layout, with perpendicular parking being
                  most efficient (95%), angled parking at 90%, and parallel parking at 85%. Additional area should be
                  allocated for driveways, entrances, landscaping, and accessible parking spaces.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions About Parking Areas</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What is the ideal aisle width?</h4>
                    <p className="text-muted-foreground text-sm">
                      For perpendicular (90°) parking, a two-way aisle should be 6-7m wide. Angled parking requires
                      4-5m aisles. One-way aisles can be narrower. Adequate aisle width ensures safe vehicle
                      maneuvering and prevents congestion.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      How many accessible parking spaces are required?
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      Accessibility requirements vary by jurisdiction, but typically 2-5% of total spaces must be
                      designated for persons with disabilities. These spaces require wider dimensions (3.6m minimum)
                      and adjacent access aisles for wheelchair access.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What factors affect parking lot efficiency?</h4>
                    <p className="text-muted-foreground text-sm">
                      Site shape, topography, landscaping requirements, drainage patterns, pedestrian walkways,
                      lighting, and local zoning setbacks all impact parking efficiency. Rectangular sites with minimal
                      grading typically achieve the highest parking density. Irregular sites may require creative
                      layouts that reduce overall efficiency.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-semibold text-amber-900">Important Note</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Parking area calculations are indicative. Actual layout may vary with site conditions and local
                      regulations. Always consult local building codes, zoning ordinances, and professional engineers
                      for site-specific parking design. Consider accessibility requirements, drainage, lighting, and
                      landscaping in final plans.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
