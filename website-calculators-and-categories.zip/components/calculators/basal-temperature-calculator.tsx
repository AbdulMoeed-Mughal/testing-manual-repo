"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Thermometer,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Calendar,
  TrendingUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type TempUnit = "celsius" | "fahrenheit"

interface TemperatureReading {
  id: string
  date: string
  temperature: string
  time: string
}

interface BBTResult {
  readings: { date: string; temp: number; phase: string }[]
  averageTemp: number
  minTemp: number
  maxTemp: number
  ovulationDay: string | null
  fertileWindow: { start: string; end: string } | null
  currentPhase: string
  temperatureShift: number | null
}

export function BasalTemperatureCalculator() {
  const [tempUnit, setTempUnit] = useState<TempUnit>("celsius")
  const [readings, setReadings] = useState<TemperatureReading[]>([
    { id: "1", date: "", temperature: "", time: "06:00" },
  ])
  const [cycleStartDate, setCycleStartDate] = useState("")
  const [averageCycleLength, setAverageCycleLength] = useState("28")
  const [result, setResult] = useState<BBTResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const addReading = () => {
    const newId = Date.now().toString()
    setReadings([...readings, { id: newId, date: "", temperature: "", time: "06:00" }])
  }

  const removeReading = (id: string) => {
    if (readings.length > 1) {
      setReadings(readings.filter((r) => r.id !== id))
    }
  }

  const updateReading = (id: string, field: keyof TemperatureReading, value: string) => {
    setReadings(readings.map((r) => (r.id === id ? { ...r, [field]: value } : r)))
  }

  const celsiusToFahrenheit = (c: number): number => (c * 9) / 5 + 32
  const fahrenheitToCelsius = (f: number): number => ((f - 32) * 5) / 9

  const calculateBBT = () => {
    setError("")
    setResult(null)

    // Validate readings
    const validReadings = readings.filter((r) => r.date && r.temperature)
    if (validReadings.length < 3) {
      setError("Please enter at least 3 temperature readings with dates")
      return
    }

    // Validate temperature range
    const minValidTemp = tempUnit === "celsius" ? 35 : 95
    const maxValidTemp = tempUnit === "celsius" ? 38 : 100.5

    const processedReadings: { date: string; temp: number; phase: string }[] = []

    for (const reading of validReadings) {
      const temp = Number.parseFloat(reading.temperature)
      if (isNaN(temp) || temp < minValidTemp || temp > maxValidTemp) {
        setError(
          `Temperature must be between ${minValidTemp}${tempUnit === "celsius" ? "°C" : "°F"} and ${maxValidTemp}${tempUnit === "celsius" ? "°C" : "°F"}`,
        )
        return
      }

      // Convert to Celsius for calculations
      const tempInCelsius = tempUnit === "fahrenheit" ? fahrenheitToCelsius(temp) : temp
      processedReadings.push({
        date: reading.date,
        temp: tempInCelsius,
        phase: "unknown",
      })
    }

    // Sort readings by date
    processedReadings.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

    // Calculate statistics
    const temps = processedReadings.map((r) => r.temp)
    const averageTemp = temps.reduce((a, b) => a + b, 0) / temps.length
    const minTemp = Math.min(...temps)
    const maxTemp = Math.max(...temps)

    // Detect ovulation (temperature shift of ~0.3-0.5°C)
    let ovulationDay: string | null = null
    let temperatureShift: number | null = null
    let preOvulationAvg = 0
    let postOvulationAvg = 0

    if (processedReadings.length >= 6) {
      // Look for sustained temperature rise
      for (let i = 3; i < processedReadings.length - 2; i++) {
        const beforeAvg = processedReadings.slice(0, i).reduce((sum, r) => sum + r.temp, 0) / i
        const afterAvg = processedReadings.slice(i).reduce((sum, r) => sum + r.temp, 0) / (processedReadings.length - i)

        const shift = afterAvg - beforeAvg

        // Check if there's a sustained rise of at least 0.2°C
        if (shift >= 0.2) {
          // Verify the next 3 temps are higher than the 6 before
          const sixBefore = processedReadings.slice(Math.max(0, i - 6), i)
          const threeBefore = processedReadings.slice(i, Math.min(i + 3, processedReadings.length))

          const sixBeforeMax = Math.max(...sixBefore.map((r) => r.temp))
          const threeAfterMin = Math.min(...threeBefore.map((r) => r.temp))

          if (threeAfterMin > sixBeforeMax) {
            ovulationDay = processedReadings[i].date
            temperatureShift = shift
            preOvulationAvg = beforeAvg
            postOvulationAvg = afterAvg
            break
          }
        }
      }
    }

    // Determine phases and fertile window
    let fertileWindow: { start: string; end: string } | null = null

    processedReadings.forEach((reading, index) => {
      if (ovulationDay) {
        const readingDate = new Date(reading.date)
        const ovDate = new Date(ovulationDay)

        if (readingDate < ovDate) {
          reading.phase = "follicular"
        } else if (readingDate.getTime() === ovDate.getTime()) {
          reading.phase = "ovulation"
        } else {
          reading.phase = "luteal"
        }
      } else {
        // Without detected ovulation, use cycle day estimates
        if (cycleStartDate) {
          const cycleStart = new Date(cycleStartDate)
          const readingDate = new Date(reading.date)
          const dayOfCycle = Math.floor((readingDate.getTime() - cycleStart.getTime()) / (1000 * 60 * 60 * 24)) + 1

          const cycleLen = Number.parseInt(averageCycleLength) || 28
          const estimatedOvulation = cycleLen - 14

          if (dayOfCycle <= 5) {
            reading.phase = "menstrual"
          } else if (dayOfCycle < estimatedOvulation - 5) {
            reading.phase = "follicular"
          } else if (dayOfCycle < estimatedOvulation + 2) {
            reading.phase = "fertile"
          } else {
            reading.phase = "luteal"
          }
        }
      }
    })

    // Calculate fertile window based on ovulation
    if (ovulationDay) {
      const ovDate = new Date(ovulationDay)
      const fertileStart = new Date(ovDate)
      fertileStart.setDate(fertileStart.getDate() - 5)
      const fertileEnd = new Date(ovDate)
      fertileEnd.setDate(fertileEnd.getDate() + 1)

      fertileWindow = {
        start: fertileStart.toISOString().split("T")[0],
        end: fertileEnd.toISOString().split("T")[0],
      }
    }

    // Determine current phase
    let currentPhase = "unknown"
    if (processedReadings.length > 0) {
      currentPhase = processedReadings[processedReadings.length - 1].phase
    }

    // Convert temps back to display unit
    const displayReadings = processedReadings.map((r) => ({
      ...r,
      temp: tempUnit === "fahrenheit" ? celsiusToFahrenheit(r.temp) : r.temp,
    }))

    setResult({
      readings: displayReadings,
      averageTemp: tempUnit === "fahrenheit" ? celsiusToFahrenheit(averageTemp) : averageTemp,
      minTemp: tempUnit === "fahrenheit" ? celsiusToFahrenheit(minTemp) : minTemp,
      maxTemp: tempUnit === "fahrenheit" ? celsiusToFahrenheit(maxTemp) : maxTemp,
      ovulationDay,
      fertileWindow,
      currentPhase,
      temperatureShift:
        temperatureShift !== null ? (tempUnit === "fahrenheit" ? temperatureShift * 1.8 : temperatureShift) : null,
    })
  }

  const handleReset = () => {
    setReadings([{ id: "1", date: "", temperature: "", time: "06:00" }])
    setCycleStartDate("")
    setAverageCycleLength("28")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `BBT Analysis:\nAverage: ${result.averageTemp.toFixed(2)}°${tempUnit === "celsius" ? "C" : "F"}\n${result.ovulationDay ? `Estimated Ovulation: ${result.ovulationDay}` : "Ovulation not detected"}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My BBT Analysis",
          text: `I tracked my basal body temperature using CalcHub! Average: ${result.averageTemp.toFixed(2)}°${tempUnit === "celsius" ? "C" : "F"}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleTempUnit = () => {
    setTempUnit((prev) => (prev === "celsius" ? "fahrenheit" : "celsius"))
    setReadings([{ id: "1", date: "", temperature: "", time: "06:00" }])
    setResult(null)
    setError("")
  }

  const getPhaseColor = (phase: string) => {
    switch (phase) {
      case "menstrual":
        return "text-red-600 bg-red-50 border-red-200"
      case "follicular":
        return "text-blue-600 bg-blue-50 border-blue-200"
      case "fertile":
        return "text-pink-600 bg-pink-50 border-pink-200"
      case "ovulation":
        return "text-purple-600 bg-purple-50 border-purple-200"
      case "luteal":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const getResultColor = () => {
    if (result?.ovulationDay) {
      return "text-purple-600 bg-purple-50 border-purple-200"
    }
    return "text-blue-600 bg-blue-50 border-blue-200"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Thermometer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Basal Temperature Calculator</CardTitle>
                    <CardDescription>Track BBT for fertility monitoring</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Temperature Unit</span>
                  <button
                    onClick={toggleTempUnit}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        tempUnit === "fahrenheit" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        tempUnit === "celsius" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Celsius
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        tempUnit === "fahrenheit" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Fahrenheit
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Cycle Info */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="cycleStart">Cycle Start Date (Optional)</Label>
                    <Input
                      id="cycleStart"
                      type="date"
                      value={cycleStartDate}
                      onChange={(e) => setCycleStartDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cycleLength">Avg. Cycle Length (days)</Label>
                    <Input
                      id="cycleLength"
                      type="number"
                      value={averageCycleLength}
                      onChange={(e) => setAverageCycleLength(e.target.value)}
                      min="21"
                      max="45"
                    />
                  </div>
                </div>

                {/* Temperature Readings */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Temperature Readings</Label>
                    <Button variant="outline" size="sm" onClick={addReading}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Reading
                    </Button>
                  </div>

                  <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                    {readings.map((reading, index) => (
                      <div key={reading.id} className="flex items-center gap-2">
                        <Input
                          type="date"
                          value={reading.date}
                          onChange={(e) => updateReading(reading.id, "date", e.target.value)}
                          className="flex-1"
                        />
                        <Input
                          type="number"
                          placeholder={tempUnit === "celsius" ? "36.5" : "97.7"}
                          value={reading.temperature}
                          onChange={(e) => updateReading(reading.id, "temperature", e.target.value)}
                          step="0.01"
                          className="w-24"
                        />
                        <span className="text-sm text-muted-foreground w-6">°{tempUnit === "celsius" ? "C" : "F"}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeReading(reading.id)}
                          disabled={readings.length === 1}
                          className="h-8 w-8"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBBT} className="w-full" size="lg">
                  Analyze Temperature Data
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getResultColor()} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Average BBT</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">
                        {result.averageTemp.toFixed(2)}°{tempUnit === "celsius" ? "C" : "F"}
                      </p>
                      {result.ovulationDay ? (
                        <div className="space-y-1">
                          <p className="text-lg font-semibold text-purple-600">Ovulation Detected</p>
                          <p className="text-sm text-muted-foreground">
                            Estimated: {new Date(result.ovulationDay).toLocaleDateString()}
                          </p>
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground">Ovulation pattern not yet detected</p>
                      )}
                    </div>

                    {/* Fertile Window */}
                    {result.fertileWindow && (
                      <div className="mt-3 p-3 bg-pink-100 rounded-lg border border-pink-200">
                        <p className="text-sm font-medium text-pink-700 text-center">
                          Fertile Window: {new Date(result.fertileWindow.start).toLocaleDateString()} -{" "}
                          {new Date(result.fertileWindow.end).toLocaleDateString()}
                        </p>
                      </div>
                    )}

                    {/* Toggle Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-3 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Readings Analyzed:</span>
                          <span className="font-medium">{result.readings.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Min Temperature:</span>
                          <span className="font-medium">
                            {result.minTemp.toFixed(2)}°{tempUnit === "celsius" ? "C" : "F"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Max Temperature:</span>
                          <span className="font-medium">
                            {result.maxTemp.toFixed(2)}°{tempUnit === "celsius" ? "C" : "F"}
                          </span>
                        </div>
                        {result.temperatureShift && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Temperature Shift:</span>
                            <span className="font-medium text-purple-600">
                              +{result.temperatureShift.toFixed(2)}°{tempUnit === "celsius" ? "C" : "F"}
                            </span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Current Phase:</span>
                          <span className="font-medium capitalize">{result.currentPhase}</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BBT Temperature Ranges</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Follicular Phase</span>
                      <span className="text-sm text-blue-600">
                        {tempUnit === "celsius" ? "36.1–36.4°C" : "97.0–97.5°F"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Ovulation</span>
                      <span className="text-sm text-purple-600">
                        {tempUnit === "celsius" ? "↑ 0.3–0.5°C rise" : "↑ 0.5–1°F rise"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Luteal Phase</span>
                      <span className="text-sm text-yellow-600">
                        {tempUnit === "celsius" ? "36.4–36.8°C" : "97.6–98.2°F"}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BBT Guidelines</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <ul className="list-disc list-inside space-y-2">
                    <li>Take temperature immediately upon waking</li>
                    <li>Measure at the same time each day</li>
                    <li>Use a basal thermometer (0.01° precision)</li>
                    <li>Record before any activity or getting out of bed</li>
                    <li>Track for at least 2-3 cycles for accuracy</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Understanding Phases</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p>
                      <strong>Pre-ovulation:</strong> Lower, stable temperatures during the follicular phase
                    </p>
                    <p>
                      <strong>Ovulation:</strong> Slight dip followed by a sustained temperature rise
                    </p>
                    <p>
                      <strong>Post-ovulation:</strong> Higher temperatures during the luteal phase until next period
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Basal Body Temperature (BBT)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Basal body temperature (BBT) is your body's temperature at complete rest, typically measured
                  immediately upon waking before any physical activity. BBT tracking is a natural fertility awareness
                  method that helps identify ovulation by detecting subtle temperature changes throughout the menstrual
                  cycle. After ovulation, progesterone causes a slight but measurable increase in body temperature.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The temperature shift typically ranges from 0.3°C to 0.5°C (0.5°F to 1°F) and remains elevated
                  throughout the luteal phase until menstruation begins. By tracking these patterns over several cycles,
                  you can better understand your fertility window and predict ovulation timing.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>How BBT Tracking Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  During the first half of your cycle (follicular phase), estrogen is the dominant hormone and keeps
                  your BBT relatively low and stable. Just before ovulation, some women experience a slight temperature
                  dip. After the egg is released, progesterone levels rise, causing your BBT to increase and remain
                  elevated for about 10-16 days.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The fertile window includes the 5 days before ovulation and the day of ovulation itself. Since BBT
                  rise confirms ovulation has already occurred, this method works best for understanding your cycle
                  patterns over time rather than predicting ovulation in real-time for the current cycle.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate BBT Tracking</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Best Practices</h4>
                    <ul className="text-muted-foreground text-sm space-y-1">
                      <li>Take temperature at the same time daily (±30 min)</li>
                      <li>Measure before getting out of bed or talking</li>
                      <li>Get at least 3-4 hours of uninterrupted sleep</li>
                      <li>Use a dedicated basal thermometer</li>
                      <li>Keep thermometer by your bedside</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Factors That Affect BBT</h4>
                    <ul className="text-muted-foreground text-sm space-y-1">
                      <li>Illness or fever</li>
                      <li>Alcohol consumption</li>
                      <li>Poor sleep or disrupted sleep</li>
                      <li>Travel or time zone changes</li>
                      <li>Certain medications</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Basal temperature tracking provides estimates for fertility monitoring and should not replace medical
                  advice. This method is not reliable for contraception when used alone. Consult a healthcare
                  professional for personalized guidance on fertility awareness, family planning, or if you have
                  concerns about your menstrual cycle. Results may vary based on individual factors and measurement
                  accuracy.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
