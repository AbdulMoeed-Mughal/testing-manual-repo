"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Ruler, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type LengthUnit = "m" | "cm" | "mm" | "in" | "ft"

interface StrainResult {
  strain: number
  strainPercent: number
  category: string
  color: string
  bgColor: string
}

const lengthUnits: { value: LengthUnit; label: string; toMeters: number }[] = [
  { value: "m", label: "Meters (m)", toMeters: 1 },
  { value: "cm", label: "Centimeters (cm)", toMeters: 0.01 },
  { value: "mm", label: "Millimeters (mm)", toMeters: 0.001 },
  { value: "in", label: "Inches (in)", toMeters: 0.0254 },
  { value: "ft", label: "Feet (ft)", toMeters: 0.3048 },
]

export function StrainCalculator() {
  const [originalLength, setOriginalLength] = useState("")
  const [changeInLength, setChangeInLength] = useState("")
  const [lengthUnit, setLengthUnit] = useState<LengthUnit>("m")
  const [result, setResult] = useState<StrainResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateStrain = () => {
    setError("")
    setResult(null)

    const L0 = Number.parseFloat(originalLength)
    const deltaL = Number.parseFloat(changeInLength)

    if (isNaN(L0) || L0 <= 0) {
      setError("Please enter a valid original length greater than 0")
      return
    }

    if (isNaN(deltaL)) {
      setError("Please enter a valid change in length")
      return
    }

    // Calculate strain (dimensionless)
    const strain = deltaL / L0
    const strainPercent = strain * 100

    // Categorize strain
    let category: string
    let color: string
    let bgColor: string

    const absStrain = Math.abs(strain)
    if (absStrain < 0.001) {
      category = "Negligible"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (absStrain < 0.01) {
      category = "Elastic (Low)"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (absStrain < 0.1) {
      category = "Moderate"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "High (Plastic)"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    if (strain < 0) {
      category = "Compressive " + category
    } else if (strain > 0) {
      category = "Tensile " + category
    }

    setResult({ strain, strainPercent, category, color, bgColor })
  }

  const handleReset = () => {
    setOriginalLength("")
    setChangeInLength("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Strain: ${result.strain.toExponential(4)} (${result.strainPercent.toFixed(4)}%) - ${result.category}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Strain Calculation Result",
          text: `I calculated strain using CalcHub! Strain: ${result.strain.toExponential(4)} (${result.strainPercent.toFixed(4)}%)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number, decimals = 6) => {
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 10000) {
      return num.toExponential(decimals)
    }
    return num.toFixed(decimals)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Ruler className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Strain Calculator</CardTitle>
                    <CardDescription>Calculate axial strain from deformation</CardDescription>
                  </div>
                </div>

                {/* Unit Selection */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Length Unit</span>
                  <select
                    value={lengthUnit}
                    onChange={(e) => setLengthUnit(e.target.value as LengthUnit)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {lengthUnits.map((unit) => (
                      <option key={unit.value} value={unit.value}>
                        {unit.label}
                      </option>
                    ))}
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Original Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="originalLength">Original Length (L₀) [{lengthUnit}]</Label>
                  <Input
                    id="originalLength"
                    type="number"
                    placeholder={`Enter original length in ${lengthUnit}`}
                    value={originalLength}
                    onChange={(e) => setOriginalLength(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Change in Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="changeInLength">Change in Length (ΔL) [{lengthUnit}]</Label>
                  <Input
                    id="changeInLength"
                    type="number"
                    placeholder={`Enter change in length (+ for extension, - for compression)`}
                    value={changeInLength}
                    onChange={(e) => setChangeInLength(e.target.value)}
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">
                    Use positive values for extension (tensile) and negative for compression
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateStrain} className="w-full" size="lg">
                  Calculate Strain
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Axial Strain (ε)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{formatNumber(result.strain)}</p>
                      <p className={`text-lg font-semibold ${result.color} mb-2`}>{result.strainPercent.toFixed(4)}%</p>
                      <p className={`text-sm font-medium ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Step-by-step toggle */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-muted-foreground"
                    >
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Formula:</strong> ε = ΔL / L₀
                        </p>
                        <p>
                          <strong>Step 1:</strong> Original Length (L₀) = {originalLength} {lengthUnit}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Change in Length (ΔL) = {changeInLength} {lengthUnit}
                        </p>
                        <p>
                          <strong>Step 3:</strong> ε = {changeInLength} / {originalLength} ={" "}
                          {formatNumber(result.strain)}
                        </p>
                        <p>
                          <strong>Step 4:</strong> Percentage = {formatNumber(result.strain)} × 100 ={" "}
                          {result.strainPercent.toFixed(4)}%
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Strain Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Negligible</span>
                      <span className="text-sm text-green-600">{"< 0.1%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Elastic (Low)</span>
                      <span className="text-sm text-blue-600">0.1% – 1%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate</span>
                      <span className="text-sm text-yellow-600">1% – 10%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">High (Plastic)</span>
                      <span className="text-sm text-red-600">≥ 10%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Strain Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ε = ΔL / L₀</p>
                  </div>
                  <p>
                    Where: <strong>ε</strong> = Strain (dimensionless), <strong>ΔL</strong> = Change in length,{" "}
                    <strong>L₀</strong> = Original length
                  </p>
                  <p>
                    Percentage strain: <strong>ε% = (ΔL / L₀) × 100</strong>
                  </p>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-amber-800">
                      Strain calculations are estimates based on ideal conditions. Actual material deformation may vary
                      due to material properties, stress distribution, and environmental factors. Consult engineering
                      references for precise analysis.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Strain?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Strain is a fundamental concept in mechanics and materials science that describes the deformation of a
                  material relative to its original dimensions. It is a dimensionless quantity that represents the ratio
                  of the change in length to the original length of the material. Strain is crucial for understanding
                  how materials respond to applied forces and is essential in structural engineering, materials testing,
                  and mechanical design.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  There are two primary types of axial strain: tensile strain (positive), which occurs when a material
                  is stretched, and compressive strain (negative), which occurs when a material is compressed. Engineers
                  use strain measurements to predict material failure, design safe structures, and ensure components can
                  withstand expected loads throughout their service life.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Strain</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Engineering Strain</h4>
                    <p className="text-blue-700 text-sm">
                      Also called nominal strain, calculated as ε = ΔL/L₀. This is the most commonly used strain measure
                      for small deformations and is what this calculator computes.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">True Strain</h4>
                    <p className="text-green-700 text-sm">
                      Also called logarithmic strain, calculated as ε_true = ln(L/L₀). Used for large deformations where
                      the change in cross-sectional area is significant.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Shear Strain</h4>
                    <p className="text-yellow-700 text-sm">
                      Measures angular deformation caused by shear stress. It is the tangent of the angle through which
                      the material is distorted.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Volumetric Strain</h4>
                    <p className="text-purple-700 text-sm">
                      Measures the change in volume relative to original volume. Important for analyzing materials under
                      hydrostatic pressure.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Stress-Strain Relationship</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The relationship between stress and strain is fundamental to understanding material behavior. For most
                  engineering materials under small deformations, this relationship is linear and follows Hooke's Law: σ
                  = E × ε, where σ is stress, E is the Young's modulus (modulus of elasticity), and ε is strain.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The elastic limit is the maximum strain a material can undergo while still returning to its original
                  shape when the load is removed. Beyond this point, the material enters the plastic region where
                  permanent deformation occurs. Understanding these limits is crucial for safe structural design.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
