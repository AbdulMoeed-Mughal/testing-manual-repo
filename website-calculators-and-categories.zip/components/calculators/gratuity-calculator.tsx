"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  DollarSign,
  Info,
  Calculator,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { currencies, formatCurrency, type CurrencyCode } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

interface GratuityResult {
  basicSalary: number
  yearsOfService: number
  totalMonths: number
  gratuityAmount: number
  taxableAmount: number
  netGratuity: number
  yearWiseBreakdown: { year: number; amount: number; cumulative: number }[]
}

export function GratuityCalculator() {
  const [basicSalary, setBasicSalary] = useState("")
  const [yearsOfService, setYearsOfService] = useState("")
  const [additionalMonths, setAdditionalMonths] = useState("")
  const [formulaType, setFormulaType] = useState<"government" | "organization">("government")
  const [applyTax, setApplyTax] = useState(false)
  const [taxExemptionLimit, setTaxExemptionLimit] = useState("2000000")
  const [result, setResult] = useState<GratuityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showBreakdown, setShowBreakdown] = useState(false)
  const [currency, setCurrency] = useState<CurrencyCode>("INR")

  const calculateGratuity = () => {
    setError("")
    setResult(null)

    const salary = Number.parseFloat(basicSalary)
    const years = Number.parseFloat(yearsOfService)
    const months = Number.parseFloat(additionalMonths) || 0

    if (isNaN(salary) || salary <= 0) {
      setError("Please enter a valid basic salary greater than 0")
      return
    }

    if (isNaN(years) || years < 0) {
      setError("Please enter valid years of service")
      return
    }

    if (years === 0 && months === 0) {
      setError("Total service period must be greater than 0")
      return
    }

    if (months < 0 || months > 11) {
      setError("Additional months must be between 0 and 11")
      return
    }

    let totalYears = years
    if (months >= 6) {
      totalYears = years + 1
    }
    const totalMonths = years * 12 + months

    let gratuityAmount: number

    if (formulaType === "government") {
      gratuityAmount = ((salary * 15) / 26) * totalYears
    } else {
      gratuityAmount = (salary / 2) * totalYears
    }

    const yearWiseBreakdown: { year: number; amount: number; cumulative: number }[] = []
    let cumulative = 0
    for (let i = 1; i <= Math.ceil(totalYears); i++) {
      const yearAmount = formulaType === "government" ? (salary * 15) / 26 : salary / 2
      cumulative += yearAmount
      yearWiseBreakdown.push({
        year: i,
        amount: yearAmount,
        cumulative: Math.min(cumulative, gratuityAmount),
      })
    }

    let taxableAmount = 0
    let netGratuity = gratuityAmount
    const exemptionLimit = Number.parseFloat(taxExemptionLimit) || 2000000

    if (applyTax && gratuityAmount > exemptionLimit) {
      taxableAmount = gratuityAmount - exemptionLimit
      const taxAmount = taxableAmount * 0.3
      netGratuity = gratuityAmount - taxAmount
    }

    setResult({
      basicSalary: salary,
      yearsOfService: totalYears,
      totalMonths,
      gratuityAmount,
      taxableAmount,
      netGratuity,
      yearWiseBreakdown,
    })
  }

  const handleReset = () => {
    setBasicSalary("")
    setYearsOfService("")
    setAdditionalMonths("")
    setFormulaType("government")
    setApplyTax(false)
    setTaxExemptionLimit("2000000")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Gratuity Calculation:\nBasic Salary: ${formatCurrency(result.basicSalary, currency)}\nYears of Service: ${result.yearsOfService}\nTotal Gratuity: ${formatCurrency(result.gratuityAmount, currency)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Gratuity Calculation",
          text: `I calculated my gratuity using CalcHub! Total Gratuity: ${formatCurrency(result.gratuityAmount, currency)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gratuity Calculator</CardTitle>
                    <CardDescription>Calculate employee gratuity payout</CardDescription>
                  </div>
                </div>
                <CurrencySelector value={currency} onValueChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="basicSalary">Last Drawn Basic Salary ({currencies[currency].symbol})</Label>
                  <Input
                    id="basicSalary"
                    type="number"
                    placeholder="Enter basic salary"
                    value={basicSalary}
                    onChange={(e) => setBasicSalary(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="yearsOfService">Years of Service</Label>
                  <Input
                    id="yearsOfService"
                    type="number"
                    placeholder="Enter completed years"
                    value={yearsOfService}
                    onChange={(e) => setYearsOfService(e.target.value)}
                    min="0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="additionalMonths">Additional Months (Optional)</Label>
                  <Input
                    id="additionalMonths"
                    type="number"
                    placeholder="0-11 months"
                    value={additionalMonths}
                    onChange={(e) => setAdditionalMonths(e.target.value)}
                    min="0"
                    max="11"
                  />
                  <p className="text-xs text-muted-foreground">If 6+ months, rounds up to next year</p>
                </div>

                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="w-full justify-between">
                      Advanced Options
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label>Gratuity Formula Type</Label>
                      <Select
                        value={formulaType}
                        onValueChange={(v) => setFormulaType(v as "government" | "organization")}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="government">Government (15/26 Formula)</SelectItem>
                          <SelectItem value="organization">Organization (Half Month)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="applyTax">Apply Tax Deduction</Label>
                      <button
                        onClick={() => setApplyTax(!applyTax)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          applyTax ? "bg-primary" : "bg-muted"
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform ${
                            applyTax ? "translate-x-6" : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>

                    {applyTax && (
                      <div className="space-y-2">
                        <Label htmlFor="taxExemptionLimit">Tax Exemption Limit ({currencies[currency].symbol})</Label>
                        <Input
                          id="taxExemptionLimit"
                          type="number"
                          placeholder="Default: 20,00,000"
                          value={taxExemptionLimit}
                          onChange={(e) => setTaxExemptionLimit(e.target.value)}
                          min="0"
                        />
                      </div>
                    )}
                  </CollapsibleContent>
                </Collapsible>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateGratuity} className="w-full" size="lg">
                  Calculate Gratuity
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Gratuity Amount</p>
                      <p className="text-4xl font-bold text-green-600 mb-2">
                        {formatCurrency(result.gratuityAmount, currency)}
                      </p>
                      <p className="text-sm text-green-700">For {result.yearsOfService} years of service</p>
                    </div>

                    {applyTax && result.taxableAmount > 0 && (
                      <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="flex justify-between text-sm">
                          <span className="text-yellow-700">Taxable Amount:</span>
                          <span className="font-medium text-yellow-800">
                            {formatCurrency(result.taxableAmount, currency)}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-yellow-700">Net Gratuity (After Tax):</span>
                          <span className="font-medium text-yellow-800">
                            {formatCurrency(result.netGratuity, currency)}
                          </span>
                        </div>
                      </div>
                    )}

                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-4 justify-between">
                          Year-wise Breakdown
                          {showBreakdown ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {result.yearWiseBreakdown.map((item) => (
                            <div key={item.year} className="flex justify-between text-sm p-2 bg-white rounded border">
                              <span>Year {item.year}</span>
                              <div className="text-right">
                                <span className="text-muted-foreground">{formatCurrency(item.amount, currency)}</span>
                                <span className="text-green-600 ml-2">
                                  ({formatCurrency(item.cumulative, currency)})
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gratuity Eligibility</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Minimum Service</span>
                      <span className="text-sm text-green-600">5 Years</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Tax Exemption</span>
                      <span className="text-sm text-blue-600">Up to 20 Lakh</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Maximum Gratuity</span>
                      <span className="text-sm text-purple-600">20 Lakh (Govt)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Part Year Rule</span>
                      <span className="text-sm text-orange-600">{"≥6 months = 1 year"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gratuity Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Gratuity = (Salary × 15/26) × Years</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>15</strong> = Days of salary per year of service
                    </p>
                    <p>
                      <strong>26</strong> = Working days per month
                    </p>
                    <p>
                      <strong>Salary</strong> = Last drawn basic + DA
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Gratuity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gratuity is a statutory benefit provided to employees as a token of appreciation for their long-term
                  service to an organization. It is a lump sum amount paid by the employer to the employee upon
                  retirement, resignation, or termination after completing a minimum of 5 years of continuous service.
                  The Payment of Gratuity Act, 1972 governs the payment of gratuity in India and applies to
                  establishments with 10 or more employees.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Gratuity is calculated based on the employee's last drawn basic salary and dearness allowance (DA),
                  along with the number of years of completed service. The standard formula considers 15 days of salary
                  for each year of completed service, with the salary being calculated on the basis of 26 working days
                  per month. This benefit acts as a form of financial security for employees and their families.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How is Gratuity Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation of gratuity depends on whether the organization is covered under the Payment of
                  Gratuity Act or not. For covered organizations, the formula is: Gratuity = (Last Drawn Salary × 15) /
                  26 × Number of Years of Service.
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2 mt-4">
                  <li>Last Drawn Salary includes basic pay plus dearness allowance</li>
                  <li>15 represents the number of days' wages for each year of service</li>
                  <li>26 is the number of working days in a month</li>
                  <li>If service months exceed 6, it's rounded up to the next year</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tax Implications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gratuity received by government employees is fully exempt from income tax. For private sector
                  employees covered under the Payment of Gratuity Act, the least of the following is exempt: actual
                  gratuity received, 15 days' salary for each completed year of service, or 20 lakh rupees.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For employees not covered under the Act, the exemption is calculated as the least of: actual gratuity,
                  half month's salary for each completed year, or 20 lakh rupees. Any amount exceeding the exemption
                  limit is added to your income and taxed at your applicable slab rate.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-muted/50 border-dashed">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    <p className="font-medium text-foreground mb-1">Important Disclaimer</p>
                    <p>
                      This calculator provides estimates based on standard gratuity formulas and should be used for
                      informational purposes only. Actual gratuity amounts may vary based on your organization's
                      policies and applicable laws. For accurate calculations specific to your situation, please consult
                      with your HR department or a financial advisor.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
