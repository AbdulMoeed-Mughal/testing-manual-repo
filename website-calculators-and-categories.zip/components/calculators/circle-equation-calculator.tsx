"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, Circle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type InputMode = "center-radius" | "three-points"
type OutputForm = "standard" | "general"

interface CircleResult {
  h: number
  k: number
  r: number
  standardForm: string
  generalForm: string
  d: number
  e: number
  f: number
}

interface Step {
  step: number
  description: string
  formula?: string
}

export function CircleEquationCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("center-radius")
  const [outputForm, setOutputForm] = useState<OutputForm>("standard")
  const [centerH, setCenterH] = useState("")
  const [centerK, setCenterK] = useState("")
  const [radius, setRadius] = useState("")
  const [point1X, setPoint1X] = useState("")
  const [point1Y, setPoint1Y] = useState("")
  const [point2X, setPoint2X] = useState("")
  const [point2Y, setPoint2Y] = useState("")
  const [point3X, setPoint3X] = useState("")
  const [point3Y, setPoint3Y] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<CircleResult | null>(null)
  const [steps, setSteps] = useState<Step[]>([])
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatNumber = (num: number): string => {
    if (Number.isInteger(num)) return num.toString()
    return num.toFixed(4).replace(/\.?0+$/, "")
  }

  const formatSign = (num: number, first = false): string => {
    if (first) return formatNumber(num)
    if (num >= 0) return `+ ${formatNumber(num)}`
    return `- ${formatNumber(Math.abs(num))}`
  }

  const formatStandardForm = (h: number, k: number, r: number): string => {
    const hPart = h === 0 ? "x²" : h > 0 ? `(x - ${formatNumber(h)})²` : `(x + ${formatNumber(Math.abs(h))})²`
    const kPart = k === 0 ? "y²" : k > 0 ? `(y - ${formatNumber(k)})²` : `(y + ${formatNumber(Math.abs(k))})²`
    return `${hPart} + ${kPart} = ${formatNumber(r * r)}`
  }

  const formatGeneralForm = (d: number, e: number, f: number): string => {
    let equation = "x²"
    equation += " + y²"
    if (d !== 0) equation += ` ${formatSign(d)}x`
    if (e !== 0) equation += ` ${formatSign(e)}y`
    if (f !== 0) equation += ` ${formatSign(f)}`
    equation += " = 0"
    return equation
  }

  const calculateFromCenterRadius = () => {
    const h = Number.parseFloat(centerH)
    const k = Number.parseFloat(centerK)
    const r = Number.parseFloat(radius)

    if (isNaN(h) || isNaN(k)) {
      setError("Please enter valid center coordinates")
      return
    }
    if (isNaN(r) || r <= 0) {
      setError("Please enter a valid positive radius")
      return
    }

    const d = -2 * h
    const e = -2 * k
    const f = h * h + k * k - r * r

    const calculationSteps: Step[] = [
      { step: 1, description: "Standard form of circle equation", formula: "(x - h)² + (y - k)² = r²" },
      {
        step: 2,
        description: `Substitute center (${formatNumber(h)}, ${formatNumber(k)}) and radius ${formatNumber(r)}`,
        formula: formatStandardForm(h, k, r),
      },
      { step: 3, description: "To convert to general form, expand the squares" },
      {
        step: 4,
        description: `x² - ${formatNumber(2 * h)}x + ${formatNumber(h * h)} + y² - ${formatNumber(2 * k)}y + ${formatNumber(k * k)} = ${formatNumber(r * r)}`,
      },
      {
        step: 5,
        description: "Rearrange to general form: x² + y² + Dx + Ey + F = 0",
        formula: `D = ${formatNumber(d)}, E = ${formatNumber(e)}, F = ${formatNumber(f)}`,
      },
      { step: 6, description: "General form", formula: formatGeneralForm(d, e, f) },
    ]

    setSteps(calculationSteps)
    setResult({
      h,
      k,
      r,
      standardForm: formatStandardForm(h, k, r),
      generalForm: formatGeneralForm(d, e, f),
      d,
      e,
      f,
    })
  }

  const calculateFromThreePoints = () => {
    const x1 = Number.parseFloat(point1X)
    const y1 = Number.parseFloat(point1Y)
    const x2 = Number.parseFloat(point2X)
    const y2 = Number.parseFloat(point2Y)
    const x3 = Number.parseFloat(point3X)
    const y3 = Number.parseFloat(point3Y)

    if ([x1, y1, x2, y2, x3, y3].some(isNaN)) {
      setError("Please enter valid coordinates for all three points")
      return
    }

    // Check if points are collinear
    const area = x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)
    if (Math.abs(area) < 1e-10) {
      setError("The three points are collinear. No circle can pass through them.")
      return
    }

    // Solve the system of equations for D, E, F
    // x² + y² + Dx + Ey + F = 0
    // For each point: x_i² + y_i² + D*x_i + E*y_i + F = 0

    const a11 = x1,
      a12 = y1,
      a13 = 1,
      b1 = -(x1 * x1 + y1 * y1)
    const a21 = x2,
      a22 = y2,
      a23 = 1,
      b2 = -(x2 * x2 + y2 * y2)
    const a31 = x3,
      a32 = y3,
      a33 = 1,
      b3 = -(x3 * x3 + y3 * y3)

    // Cramer's rule
    const det = a11 * (a22 * a33 - a23 * a32) - a12 * (a21 * a33 - a23 * a31) + a13 * (a21 * a32 - a22 * a31)

    const detD = b1 * (a22 * a33 - a23 * a32) - a12 * (b2 * a33 - a23 * b3) + a13 * (b2 * a32 - a22 * b3)
    const detE = a11 * (b2 * a33 - a23 * b3) - b1 * (a21 * a33 - a23 * a31) + a13 * (a21 * b3 - b2 * a31)
    const detF = a11 * (a22 * b3 - b2 * a32) - a12 * (a21 * b3 - b2 * a31) + b1 * (a21 * a32 - a22 * a31)

    const d = detD / det
    const e = detE / det
    const f = detF / det

    // Calculate center and radius from general form
    const h = -d / 2
    const k = -e / 2
    const r = Math.sqrt(h * h + k * k - f)

    if (isNaN(r) || r <= 0) {
      setError("Could not calculate a valid circle from these points")
      return
    }

    const calculationSteps: Step[] = [
      { step: 1, description: "Use general form: x² + y² + Dx + Ey + F = 0" },
      { step: 2, description: "Substitute each point to create a system of equations" },
      {
        step: 3,
        description: `Point 1 (${formatNumber(x1)}, ${formatNumber(y1)}): ${formatNumber(x1 * x1 + y1 * y1)} + ${formatNumber(x1)}D + ${formatNumber(y1)}E + F = 0`,
      },
      {
        step: 4,
        description: `Point 2 (${formatNumber(x2)}, ${formatNumber(y2)}): ${formatNumber(x2 * x2 + y2 * y2)} + ${formatNumber(x2)}D + ${formatNumber(y2)}E + F = 0`,
      },
      {
        step: 5,
        description: `Point 3 (${formatNumber(x3)}, ${formatNumber(y3)}): ${formatNumber(x3 * x3 + y3 * y3)} + ${formatNumber(x3)}D + ${formatNumber(y3)}E + F = 0`,
      },
      {
        step: 6,
        description: "Solve the system using Cramer's rule",
        formula: `D = ${formatNumber(d)}, E = ${formatNumber(e)}, F = ${formatNumber(f)}`,
      },
      {
        step: 7,
        description: "Calculate center: h = -D/2, k = -E/2",
        formula: `h = ${formatNumber(h)}, k = ${formatNumber(k)}`,
      },
      {
        step: 8,
        description: "Calculate radius: r = √(h² + k² - F)",
        formula: `r = √(${formatNumber(h * h)} + ${formatNumber(k * k)} - ${formatNumber(f)}) = ${formatNumber(r)}`,
      },
    ]

    setSteps(calculationSteps)
    setResult({
      h,
      k,
      r,
      standardForm: formatStandardForm(h, k, r),
      generalForm: formatGeneralForm(d, e, f),
      d,
      e,
      f,
    })
  }

  const calculate = () => {
    setError("")
    setResult(null)
    setSteps([])

    if (inputMode === "center-radius") {
      calculateFromCenterRadius()
    } else {
      calculateFromThreePoints()
    }
  }

  const handleReset = () => {
    setCenterH("")
    setCenterK("")
    setRadius("")
    setPoint1X("")
    setPoint1Y("")
    setPoint2X("")
    setPoint2Y("")
    setPoint3X("")
    setPoint3Y("")
    setResult(null)
    setSteps([])
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = outputForm === "standard" ? result.standardForm : result.generalForm
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Circle className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Circle Equation Calculator</CardTitle>
                    <CardDescription>Find circle equations from center/radius or points</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={() => {
                      setInputMode((prev) => (prev === "center-radius" ? "three-points" : "center-radius"))
                      handleReset()
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "three-points" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        inputMode === "center-radius" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Center & Radius
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        inputMode === "three-points" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Three Points
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {inputMode === "center-radius" ? (
                  <>
                    <div className="space-y-2">
                      <Label>Center (h, k)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          type="number"
                          placeholder="h (x-coordinate)"
                          value={centerH}
                          onChange={(e) => setCenterH(e.target.value)}
                          step="any"
                        />
                        <Input
                          type="number"
                          placeholder="k (y-coordinate)"
                          value={centerK}
                          onChange={(e) => setCenterK(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="radius">Radius (r)</Label>
                      <Input
                        id="radius"
                        type="number"
                        placeholder="Enter radius (must be positive)"
                        value={radius}
                        onChange={(e) => setRadius(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label>Point 1 (x₁, y₁)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          type="number"
                          placeholder="x₁"
                          value={point1X}
                          onChange={(e) => setPoint1X(e.target.value)}
                          step="any"
                        />
                        <Input
                          type="number"
                          placeholder="y₁"
                          value={point1Y}
                          onChange={(e) => setPoint1Y(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Point 2 (x₂, y₂)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          type="number"
                          placeholder="x₂"
                          value={point2X}
                          onChange={(e) => setPoint2X(e.target.value)}
                          step="any"
                        />
                        <Input
                          type="number"
                          placeholder="y₂"
                          value={point2Y}
                          onChange={(e) => setPoint2Y(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Point 3 (x₃, y₃)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          type="number"
                          placeholder="x₃"
                          value={point3X}
                          onChange={(e) => setPoint3X(e.target.value)}
                          step="any"
                        />
                        <Input
                          type="number"
                          placeholder="y₃"
                          value={point3Y}
                          onChange={(e) => setPoint3Y(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* Output Form Selection */}
                <div className="space-y-2">
                  <Label>Output Form</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={outputForm === "standard" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setOutputForm("standard")}
                      className="w-full"
                    >
                      Standard Form
                    </Button>
                    <Button
                      type="button"
                      variant={outputForm === "general" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setOutputForm("general")}
                      className="w-full"
                    >
                      General Form
                    </Button>
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step solution</Label>
                  <button
                    id="show-steps"
                    onClick={() => setShowSteps(!showSteps)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      showSteps ? "bg-primary" : "bg-muted"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        showSteps ? "translate-x-6" : "translate-x-1"
                      }`}
                    />
                  </button>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Circle Equation
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {outputForm === "standard" ? "Standard Form" : "General Form"}
                      </p>
                      <p className="text-xl sm:text-2xl font-bold text-blue-600 mb-3 font-mono break-all">
                        {outputForm === "standard" ? result.standardForm : result.generalForm}
                      </p>

                      <div className="grid grid-cols-3 gap-2 text-sm mt-4 p-3 bg-white rounded-lg">
                        <div>
                          <p className="text-muted-foreground">Center</p>
                          <p className="font-semibold">
                            ({formatNumber(result.h)}, {formatNumber(result.k)})
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Radius</p>
                          <p className="font-semibold">{formatNumber(result.r)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Diameter</p>
                          <p className="font-semibold">{formatNumber(result.r * 2)}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-step solution */}
                {showSteps && steps.length > 0 && (
                  <Card className="mt-4">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Step-by-Step Solution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {steps.map((step) => (
                          <div key={step.step} className="flex gap-3">
                            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-medium text-primary-foreground">
                              {step.step}
                            </div>
                            <div className="flex-1">
                              <p className="text-sm text-muted-foreground">{step.description}</p>
                              {step.formula && (
                                <p className="text-sm font-mono font-medium mt-1 p-2 bg-muted rounded">
                                  {step.formula}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Circle Equation Forms</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-medium text-blue-700 mb-1">Standard Form</p>
                    <p className="text-sm text-blue-600 font-mono">(x - h)² + (y - k)² = r²</p>
                    <p className="text-xs text-blue-500 mt-1">Center: (h, k), Radius: r</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-medium text-green-700 mb-1">General Form</p>
                    <p className="text-sm text-green-600 font-mono">x² + y² + Dx + Ey + F = 0</p>
                    <p className="text-xs text-green-500 mt-1">D = -2h, E = -2k, F = h² + k² - r²</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Unit circle at origin</span>
                      <span className="font-mono">x² + y² = 1</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Center (2, 3), r = 4</span>
                      <span className="font-mono">(x-2)² + (y-3)² = 16</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Center (-1, 0), r = 2</span>
                      <span className="font-mono">(x+1)² + y² = 4</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Converting Forms</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Standard → General:</strong> Expand the squares and collect like terms.
                  </p>
                  <p>
                    <strong>General → Standard:</strong> Complete the square for both x and y terms.
                  </p>
                  <div className="p-2 bg-muted rounded font-mono text-xs mt-2">
                    h = -D/2, k = -E/2, r = √(h² + k² - F)
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Circle Equation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A circle equation is a mathematical representation of all points that are equidistant from a central
                  point. The standard form of a circle equation, (x - h)² + (y - k)² = r², directly shows the center (h,
                  k) and radius r of the circle. The general form, x² + y² + Dx + Ey + F = 0, is an expanded version
                  that can be converted back to standard form through completing the square.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Circle equations are fundamental in analytic geometry and have applications in physics, engineering,
                  computer graphics, and many other fields. Understanding how to derive and manipulate circle equations
                  is essential for solving problems involving circular paths, orbits, and geometric constructions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Important Notes</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>When using three points, they must not be collinear (on the same line)</li>
                  <li>The radius must always be a positive value</li>
                  <li>For the general form, the equation must satisfy the condition D² + E² - 4F {">"} 0</li>
                  <li>Results may have rounding for irrational values</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-8 bg-yellow-50 border-yellow-200">
            <CardContent className="p-4">
              <p className="text-sm text-yellow-800">
                <strong>Disclaimer:</strong> Circle equations are calculated using standard mathematical formulas.
                Results depend on correct input values and non-collinear points.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
