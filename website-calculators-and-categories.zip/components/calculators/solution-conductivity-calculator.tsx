"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Beaker, Info, AlertTriangle, Zap, Plus, Trash2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Ion {
  id: number
  name: string
  concentration: string
  molarConductivity: string
}

interface ConductivityResult {
  value: number
  classification: string
  color: string
  bgColor: string
  contributions: { name: string; conductivity: number; percentage: number }[]
  unit: string
}

export function SolutionConductivityCalculator() {
  const [ions, setIons] = useState<Ion[]>([
    { id: 1, name: "Na⁺", concentration: "", molarConductivity: "50.1" },
    { id: 2, name: "Cl⁻", concentration: "", molarConductivity: "76.3" },
  ])
  const [unit, setUnit] = useState<string>("S/m")
  const [temperature, setTemperature] = useState<string>("25")
  const [result, setResult] = useState<ConductivityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [nextId, setNextId] = useState(3)

  const addIon = () => {
    setIons([...ions, { id: nextId, name: "", concentration: "", molarConductivity: "" }])
    setNextId(nextId + 1)
  }

  const removeIon = (id: number) => {
    if (ions.length > 1) {
      setIons(ions.filter((ion) => ion.id !== id))
    }
  }

  const updateIon = (id: number, field: keyof Ion, value: string) => {
    setIons(ions.map((ion) => (ion.id === id ? { ...ion, [field]: value } : ion)))
  }

  const calculateConductivity = () => {
    setError("")
    setResult(null)

    // Validate inputs
    const validIons: { name: string; concentration: number; molarConductivity: number }[] = []

    for (const ion of ions) {
      const conc = Number.parseFloat(ion.concentration)
      const molarCond = Number.parseFloat(ion.molarConductivity)

      if (ion.concentration === "" || ion.molarConductivity === "") {
        setError("Please fill in all concentration and molar conductivity fields")
        return
      }

      if (isNaN(conc) || conc < 0) {
        setError("Concentrations must be non-negative numbers")
        return
      }

      if (isNaN(molarCond) || molarCond < 0) {
        setError("Molar conductivities must be non-negative numbers")
        return
      }

      validIons.push({
        name: ion.name || `Ion ${ion.id}`,
        concentration: conc,
        molarConductivity: molarCond,
      })
    }

    if (validIons.length === 0) {
      setError("Please add at least one ion")
      return
    }

    // Calculate solution conductivity: κ = Σ(Cᵢ × Λᵢ)
    // Λᵢ is in S·cm²/mol, Cᵢ is in mol/L
    // κ will be in S/cm, need to convert based on unit selection
    let totalConductivity = 0
    const contributions: { name: string; conductivity: number; percentage: number }[] = []

    for (const ion of validIons) {
      // Cᵢ (mol/L) × Λᵢ (S·cm²/mol) = κᵢ (S·cm²/L) = κᵢ (S/cm) × 1000 cm³/L / 1000 = κᵢ (S/cm)
      // Actually: Cᵢ (mol/L) × Λᵢ (S·cm²/mol) / 1000 cm³/L = κᵢ (S/cm)
      const contributionSperCm = (ion.concentration * ion.molarConductivity) / 1000
      totalConductivity += contributionSperCm
      contributions.push({
        name: ion.name,
        conductivity: contributionSperCm,
        percentage: 0,
      })
    }

    // Apply temperature correction (approximate: 2% per °C from 25°C)
    const temp = Number.parseFloat(temperature)
    if (!isNaN(temp)) {
      const tempCorrection = 1 + 0.02 * (temp - 25)
      totalConductivity *= tempCorrection
      for (const contrib of contributions) {
        contrib.conductivity *= tempCorrection
      }
    }

    // Convert to selected unit
    let conductivityInUnit = totalConductivity // S/cm
    let displayUnit = "S/cm"

    if (unit === "S/m") {
      conductivityInUnit = totalConductivity * 100 // S/cm to S/m
      displayUnit = "S/m"
    } else if (unit === "µS/cm") {
      conductivityInUnit = totalConductivity * 1e6 // S/cm to µS/cm
      displayUnit = "µS/cm"
    }

    // Calculate percentages
    if (totalConductivity > 0) {
      for (const contrib of contributions) {
        contrib.percentage = (contrib.conductivity / totalConductivity) * 100
      }
    }

    // Classify conductivity (based on S/m)
    let classification: string
    let color: string
    let bgColor: string
    const conductivitySperM = totalConductivity * 100 // Convert to S/m for classification

    if (conductivitySperM < 0.01) {
      classification = "Very Low"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (conductivitySperM < 1) {
      classification = "Low"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (conductivitySperM < 10) {
      classification = "Medium"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      classification = "High"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      value: conductivityInUnit,
      classification,
      color,
      bgColor,
      contributions,
      unit: displayUnit,
    })
  }

  const handleReset = () => {
    setIons([
      { id: 1, name: "Na⁺", concentration: "", molarConductivity: "50.1" },
      { id: 2, name: "Cl⁻", concentration: "", molarConductivity: "76.3" },
    ])
    setNextId(3)
    setUnit("S/m")
    setTemperature("25")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const contributionText = result.contributions
        .map((c) => `${c.name}: ${c.percentage.toFixed(1)}%`)
        .join(", ")
      await navigator.clipboard.writeText(
        `Solution Conductivity: ${formatNumber(result.value)} ${result.unit} (${result.classification}). Contributions: ${contributionText}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Solution Conductivity Calculation",
          text: `I calculated the solution conductivity using CalcHub! Conductivity: ${formatNumber(result.value)} ${result.unit} (${result.classification})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (num < 0.0001 || num >= 10000) {
      return num.toExponential(3)
    }
    return num.toFixed(4).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Solution Conductivity Calculator</CardTitle>
                    <CardDescription>Calculate electrical conductivity of aqueous solutions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Temperature and Unit Selection */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-sm">Temperature (°C)</Label>
                    <Input
                      type="number"
                      placeholder="25"
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                      step="0.1"
                    />
                  </div>
                  <div>
                    <Label className="text-sm">Conductivity Unit</Label>
                    <Select value={unit} onValueChange={setUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="S/m">S/m</SelectItem>
                        <SelectItem value="S/cm">S/cm</SelectItem>
                        <SelectItem value="µS/cm">µS/cm</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Ion Inputs */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-medium">Ions in Solution</Label>
                    <Button variant="outline" size="sm" onClick={addIon}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Ion
                    </Button>
                  </div>

                  {ions.map((ion, index) => (
                    <div key={ion.id} className="p-3 bg-muted/50 rounded-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-muted-foreground">Ion {index + 1}</span>
                        {ions.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeIon(ion.id)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <Label className="text-xs">Name (optional)</Label>
                          <Input
                            type="text"
                            placeholder="e.g., Na⁺"
                            value={ion.name}
                            onChange={(e) => updateIon(ion.id, "name", e.target.value)}
                            className="h-9"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Conc. (mol/L)</Label>
                          <Input
                            type="number"
                            placeholder="0.1"
                            value={ion.concentration}
                            onChange={(e) => updateIon(ion.id, "concentration", e.target.value)}
                            min="0"
                            step="0.001"
                            className="h-9"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Λ (S·cm²/mol)</Label>
                          <Input
                            type="number"
                            placeholder="50.1"
                            value={ion.molarConductivity}
                            onChange={(e) => updateIon(ion.id, "molarConductivity", e.target.value)}
                            min="0"
                            step="0.1"
                            className="h-9"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateConductivity} className="w-full" size="lg">
                  Calculate Conductivity
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Solution Conductivity (κ)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{formatNumber(result.value)}</p>
                      <p className="text-sm text-muted-foreground mb-2">{result.unit}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.classification}</p>
                    </div>

                    {/* Ion Contributions */}
                    {result.contributions.length > 0 && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg">
                        <p className="text-sm font-medium mb-2 text-center">Ion Contributions</p>
                        <div className="space-y-1">
                          {result.contributions.map((contrib, idx) => (
                            <div key={idx} className="flex justify-between text-sm">
                              <span>{contrib.name}</span>
                              <span className="font-mono">{contrib.percentage.toFixed(1)}%</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conductivity Classification</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Very Low</span>
                      <span className="text-sm text-blue-600">{"< 0.01 S/m"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low</span>
                      <span className="text-sm text-green-600">0.01 – 1 S/m</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Medium</span>
                      <span className="text-sm text-yellow-600">1 – 10 S/m</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">High</span>
                      <span className="text-sm text-red-600">≥ 10 S/m</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conductivity Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">κ = Σ(Cᵢ × Λᵢ)</p>
                  </div>
                  <p>
                    Where <strong>Cᵢ</strong> is the molar concentration of ion i (mol/L) and <strong>Λᵢ</strong> is its
                    molar conductivity (S·cm²/mol).
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Ion Conductivities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>H⁺</span>
                      <span className="font-mono">349.6 S·cm²/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>OH⁻</span>
                      <span className="font-mono">198.0 S·cm²/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Na⁺</span>
                      <span className="font-mono">50.1 S·cm²/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Cl⁻</span>
                      <span className="font-mono">76.3 S·cm²/mol</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>K⁺</span>
                      <span className="font-mono">73.5 S·cm²/mol</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Solution Conductivity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Solution Conductivity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Solution conductivity (κ) is a measure of a solution's ability to conduct electrical current. It
                  depends on the concentration and mobility of ions present in the solution. Unlike pure water, which is
                  a poor conductor, aqueous solutions containing dissolved salts, acids, or bases are good conductors
                  due to the presence of mobile ions that carry electrical charge.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The conductivity of a solution is determined by summing the contributions of all ions present, where
                  each ion's contribution is the product of its concentration and its molar conductivity (also called
                  ionic conductivity). Molar conductivity represents the conducting power of all ions produced by
                  dissolving one mole of an electrolyte and is characteristic of each ion species.
                </p>
              </CardContent>
            </Card>

            {/* How Conductivity is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>How is Solution Conductivity Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate solution conductivity, multiply the molar concentration of each ion by its molar
                  conductivity and sum these products for all ions in solution. For example, a 0.1 M NaCl solution
                  contains 0.1 M Na⁺ (Λ = 50.1 S·cm²/mol) and 0.1 M Cl⁻ (Λ = 76.3 S·cm²/mol), giving a total
                  conductivity of approximately 1.26 S/m at 25°C.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature significantly affects conductivity, with conductivity typically increasing by about 2% per
                  degree Celsius above 25°C due to increased ion mobility. This calculator includes an optional
                  temperature correction to account for measurements made at temperatures different from the standard
                  25°C. The molar conductivity values used should ideally be at infinite dilution or appropriate for the
                  concentration range being studied.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Conductivity Measurements</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Conductivity measurements are widely used in water quality monitoring, where they provide a quick
                  assessment of total dissolved solids (TDS) in drinking water, wastewater, and environmental samples.
                  In analytical chemistry, conductivity detection is used in ion chromatography and capillary
                  electrophoresis to identify and quantify ionic species without requiring optical properties.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Industrial applications include monitoring the concentration of acids, bases, and salts in chemical
                  processes, controlling the purity of ultrapure water in semiconductor manufacturing and pharmaceutical
                  production, and optimizing electroplating baths. In agriculture, soil conductivity measurements help
                  assess salinity levels that affect crop growth. Conductivity is also fundamental to understanding
                  electrochemical cells, batteries, and fuel cells.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculations assume ideal dilute solutions where ion-ion interactions are negligible and molar
                  conductivities remain constant. Actual conductivity may vary due to ion pairing, incomplete
                  dissociation, changes in ion mobility with concentration, and temperature effects not fully captured
                  by the simple correction factor. For precise work, especially at high concentrations or with weak
                  electrolytes, experimental measurements or more sophisticated models should be used. Molar
                  conductivity values should be verified for the specific conditions of your application.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
