"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Volume2,
  Info,
  AlertTriangle,
  Waves,
  VolumeX,
  Volume1,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "intensity" | "power" | "voltage" | "difference" | "convert"

interface DecibelResult {
  value: number
  unit: string
  explanation: string[]
  comparison?: string
}

const soundLevels = [
  { db: 0, description: "Threshold of hearing", icon: VolumeX },
  { db: 20, description: "Whisper, rustling leaves", icon: VolumeX },
  { db: 40, description: "Quiet library", icon: Volume1 },
  { db: 60, description: "Normal conversation", icon: Volume1 },
  { db: 80, description: "Busy traffic, alarm clock", icon: Volume2 },
  { db: 100, description: "Motorcycle, power tools", icon: Volume2 },
  { db: 120, description: "Rock concert, thunder", icon: Volume2 },
  { db: 140, description: "Jet engine, threshold of pain", icon: Volume2 },
]

export function DecibelCalculator() {
  const [mode, setMode] = useState<CalculationMode>("intensity")
  const [intensity, setIntensity] = useState("")
  const [referenceIntensity, setReferenceIntensity] = useState("1e-12")
  const [power, setPower] = useState("")
  const [referencePower, setReferencePower] = useState("1")
  const [voltage, setVoltage] = useState("")
  const [referenceVoltage, setReferenceVoltage] = useState("1")
  const [db1, setDb1] = useState("")
  const [db2, setDb2] = useState("")
  const [convertValue, setConvertValue] = useState("")
  const [convertFrom, setConvertFrom] = useState("dB")
  const [convertTo, setConvertTo] = useState("dBm")
  const [impedance, setImpedance] = useState("50")
  const [result, setResult] = useState<DecibelResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  const getSoundComparison = (db: number): string => {
    if (db < 10) return "Barely audible, near silence"
    if (db < 30) return "Very quiet, like a whisper"
    if (db < 50) return "Quiet, like a library"
    if (db < 70) return "Moderate, like normal conversation"
    if (db < 90) return "Loud, like busy traffic"
    if (db < 110) return "Very loud, hearing protection recommended"
    if (db < 130) return "Extremely loud, risk of hearing damage"
    return "Painful, immediate hearing damage possible"
  }

  const calculate = () => {
    setError("")
    setResult(null)

    try {
      let decibelValue: number
      const steps: string[] = []
      let unit = "dB"

      switch (mode) {
        case "intensity": {
          const I = Number.parseFloat(intensity)
          const I0 = Number.parseFloat(referenceIntensity)

          if (isNaN(I) || I <= 0) {
            setError("Please enter a valid positive intensity value")
            return
          }
          if (isNaN(I0) || I0 <= 0) {
            setError("Please enter a valid positive reference intensity")
            return
          }

          decibelValue = 10 * Math.log10(I / I0)
          steps.push(`Formula: L = 10 × log₁₀(I / I₀)`)
          steps.push(`L = 10 × log₁₀(${I.toExponential(2)} / ${I0.toExponential(2)})`)
          steps.push(`L = 10 × log₁₀(${(I / I0).toExponential(4)})`)
          steps.push(`L = 10 × ${Math.log10(I / I0).toFixed(4)}`)
          steps.push(`L = ${decibelValue.toFixed(2)} dB`)
          unit = "dB SPL"
          break
        }

        case "power": {
          const P = Number.parseFloat(power)
          const P0 = Number.parseFloat(referencePower)

          if (isNaN(P) || P <= 0) {
            setError("Please enter a valid positive power value")
            return
          }
          if (isNaN(P0) || P0 <= 0) {
            setError("Please enter a valid positive reference power")
            return
          }

          decibelValue = 10 * Math.log10(P / P0)
          steps.push(`Formula: L = 10 × log₁₀(P / P₀)`)
          steps.push(`L = 10 × log₁₀(${P} / ${P0})`)
          steps.push(`L = 10 × log₁₀(${(P / P0).toFixed(6)})`)
          steps.push(`L = 10 × ${Math.log10(P / P0).toFixed(4)}`)
          steps.push(`L = ${decibelValue.toFixed(2)} dB`)
          break
        }

        case "voltage": {
          const V = Number.parseFloat(voltage)
          const V0 = Number.parseFloat(referenceVoltage)

          if (isNaN(V) || V <= 0) {
            setError("Please enter a valid positive voltage value")
            return
          }
          if (isNaN(V0) || V0 <= 0) {
            setError("Please enter a valid positive reference voltage")
            return
          }

          decibelValue = 20 * Math.log10(V / V0)
          steps.push(`Formula: L = 20 × log₁₀(V / V₀)`)
          steps.push(`Note: Factor is 20 for voltage/amplitude ratios`)
          steps.push(`L = 20 × log₁₀(${V} / ${V0})`)
          steps.push(`L = 20 × log₁₀(${(V / V0).toFixed(6)})`)
          steps.push(`L = 20 × ${Math.log10(V / V0).toFixed(4)}`)
          steps.push(`L = ${decibelValue.toFixed(2)} dB`)
          break
        }

        case "difference": {
          const dB1Val = Number.parseFloat(db1)
          const dB2Val = Number.parseFloat(db2)

          if (isNaN(dB1Val)) {
            setError("Please enter a valid first dB value")
            return
          }
          if (isNaN(dB2Val)) {
            setError("Please enter a valid second dB value")
            return
          }

          decibelValue = dB2Val - dB1Val
          steps.push(`Formula: ΔdB = dB₂ − dB₁`)
          steps.push(`ΔdB = ${dB2Val} − ${dB1Val}`)
          steps.push(`ΔdB = ${decibelValue.toFixed(2)} dB`)

          if (decibelValue > 0) {
            const ratio = Math.pow(10, decibelValue / 10)
            steps.push(`This represents a ${ratio.toFixed(2)}× increase in power`)
          } else if (decibelValue < 0) {
            const ratio = Math.pow(10, Math.abs(decibelValue) / 10)
            steps.push(`This represents a ${ratio.toFixed(2)}× decrease in power`)
          }
          break
        }

        case "convert": {
          const val = Number.parseFloat(convertValue)
          const Z = Number.parseFloat(impedance)

          if (isNaN(val)) {
            setError("Please enter a valid value to convert")
            return
          }
          if (isNaN(Z) || Z <= 0) {
            setError("Please enter a valid positive impedance")
            return
          }

          // Reference: dBm uses 1mW, dBW uses 1W
          let powerInWatts: number

          // First convert to Watts
          if (convertFrom === "dBm") {
            powerInWatts = Math.pow(10, val / 10) * 0.001
            steps.push(`Convert ${val} dBm to Watts:`)
            steps.push(`P = 10^(dBm/10) × 1mW`)
            steps.push(`P = 10^(${val}/10) × 0.001 W`)
            steps.push(`P = ${powerInWatts.toExponential(4)} W`)
          } else if (convertFrom === "dBW") {
            powerInWatts = Math.pow(10, val / 10)
            steps.push(`Convert ${val} dBW to Watts:`)
            steps.push(`P = 10^(dBW/10) × 1W`)
            steps.push(`P = 10^(${val}/10) W`)
            steps.push(`P = ${powerInWatts.toExponential(4)} W`)
          } else {
            // dB is relative, assume it's relative to 1W for conversion
            powerInWatts = Math.pow(10, val / 10)
            steps.push(`Assuming dB relative to 1W:`)
            steps.push(`P = 10^(${val}/10) W = ${powerInWatts.toExponential(4)} W`)
          }

          // Now convert to target unit
          if (convertTo === "dBm") {
            decibelValue = 10 * Math.log10(powerInWatts / 0.001)
            steps.push(`Convert to dBm:`)
            steps.push(`dBm = 10 × log₁₀(P / 1mW)`)
            steps.push(`dBm = 10 × log₁₀(${powerInWatts.toExponential(4)} / 0.001)`)
            steps.push(`dBm = ${decibelValue.toFixed(2)} dBm`)
            unit = "dBm"
          } else if (convertTo === "dBW") {
            decibelValue = 10 * Math.log10(powerInWatts)
            steps.push(`Convert to dBW:`)
            steps.push(`dBW = 10 × log₁₀(P / 1W)`)
            steps.push(`dBW = 10 × log₁₀(${powerInWatts.toExponential(4)})`)
            steps.push(`dBW = ${decibelValue.toFixed(2)} dBW`)
            unit = "dBW"
          } else {
            decibelValue = 10 * Math.log10(powerInWatts)
            steps.push(`Result: ${decibelValue.toFixed(2)} dB (relative to 1W)`)
            unit = "dB"
          }
          break
        }

        default:
          return
      }

      const comparison = mode === "intensity" ? getSoundComparison(decibelValue) : undefined

      setResult({
        value: decibelValue,
        unit,
        explanation: steps,
        comparison,
      })
    } catch {
      setError("An error occurred during calculation")
    }
  }

  const handleReset = () => {
    setIntensity("")
    setReferenceIntensity("1e-12")
    setPower("")
    setReferencePower("1")
    setVoltage("")
    setReferenceVoltage("1")
    setDb1("")
    setDb2("")
    setConvertValue("")
    setConvertFrom("dB")
    setConvertTo("dBm")
    setImpedance("50")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`${result.value.toFixed(2)} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Decibel Calculator Result",
          text: `Calculated: ${result.value.toFixed(2)} ${result.unit}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const getResultColor = () => {
    if (!result || mode !== "intensity") return "text-orange-600"
    if (result.value < 60) return "text-green-600"
    if (result.value < 85) return "text-yellow-600"
    if (result.value < 100) return "text-orange-600"
    return "text-red-600"
  }

  const getResultBgColor = () => {
    if (!result || mode !== "intensity") return "bg-orange-50 border-orange-200"
    if (result.value < 60) return "bg-green-50 border-green-200"
    if (result.value < 85) return "bg-yellow-50 border-yellow-200"
    if (result.value < 100) return "bg-orange-50 border-orange-200"
    return "bg-red-50 border-red-200"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Volume2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Decibel Calculator</CardTitle>
                    <CardDescription>Calculate sound levels and power ratios in dB</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Calculation Mode</Label>
                  <Select
                    value={mode}
                    onValueChange={(v) => {
                      setMode(v as CalculationMode)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="intensity">Sound Intensity to dB</SelectItem>
                      <SelectItem value="power">Power Ratio to dB</SelectItem>
                      <SelectItem value="voltage">Voltage Ratio to dB</SelectItem>
                      <SelectItem value="difference">dB Difference</SelectItem>
                      <SelectItem value="convert">Convert dB/dBm/dBW</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {mode === "intensity" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="intensity">Sound Intensity (W/m²)</Label>
                      <Input
                        id="intensity"
                        type="text"
                        placeholder="e.g., 1e-6 or 0.000001"
                        value={intensity}
                        onChange={(e) => setIntensity(e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Use scientific notation: 1e-6 = 0.000001</p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="refIntensity">Reference Intensity I₀ (W/m²)</Label>
                      <Input
                        id="refIntensity"
                        type="text"
                        placeholder="Default: 1e-12"
                        value={referenceIntensity}
                        onChange={(e) => setReferenceIntensity(e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Standard threshold of hearing: 1×10⁻¹² W/m²</p>
                    </div>
                  </>
                )}

                {mode === "power" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="power">Power (W)</Label>
                      <Input
                        id="power"
                        type="number"
                        placeholder="Enter power value"
                        value={power}
                        onChange={(e) => setPower(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="refPower">Reference Power P₀ (W)</Label>
                      <Input
                        id="refPower"
                        type="number"
                        placeholder="Default: 1"
                        value={referencePower}
                        onChange={(e) => setReferencePower(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {mode === "voltage" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="voltage">Voltage (V)</Label>
                      <Input
                        id="voltage"
                        type="number"
                        placeholder="Enter voltage value"
                        value={voltage}
                        onChange={(e) => setVoltage(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="refVoltage">Reference Voltage V₀ (V)</Label>
                      <Input
                        id="refVoltage"
                        type="number"
                        placeholder="Default: 1"
                        value={referenceVoltage}
                        onChange={(e) => setReferenceVoltage(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {mode === "difference" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="db1">First Value (dB₁)</Label>
                      <Input
                        id="db1"
                        type="number"
                        placeholder="Enter first dB value"
                        value={db1}
                        onChange={(e) => setDb1(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="db2">Second Value (dB₂)</Label>
                      <Input
                        id="db2"
                        type="number"
                        placeholder="Enter second dB value"
                        value={db2}
                        onChange={(e) => setDb2(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {mode === "convert" && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label>From</Label>
                        <Select value={convertFrom} onValueChange={setConvertFrom}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="dB">dB</SelectItem>
                            <SelectItem value="dBm">dBm</SelectItem>
                            <SelectItem value="dBW">dBW</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>To</Label>
                        <Select value={convertTo} onValueChange={setConvertTo}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="dB">dB</SelectItem>
                            <SelectItem value="dBm">dBm</SelectItem>
                            <SelectItem value="dBW">dBW</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="convertValue">Value</Label>
                      <Input
                        id="convertValue"
                        type="number"
                        placeholder={`Enter value in ${convertFrom}`}
                        value={convertValue}
                        onChange={(e) => setConvertValue(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="impedance">Impedance (Ω)</Label>
                      <Input
                        id="impedance"
                        type="number"
                        placeholder="Default: 50"
                        value={impedance}
                        onChange={(e) => setImpedance(e.target.value)}
                        min="0"
                        step="any"
                      />
                      <p className="text-xs text-muted-foreground">Standard impedance for RF: 50Ω</p>
                    </div>
                  </>
                )}

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getResultBgColor()} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <p className={`text-5xl font-bold ${getResultColor()} mb-2`}>{result.value.toFixed(2)}</p>
                      <p className={`text-lg font-semibold ${getResultColor()}`}>{result.unit}</p>
                      {result.comparison && <p className="text-sm text-muted-foreground mt-2">{result.comparison}</p>}
                    </div>

                    {showSteps && result.explanation.length > 0 && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg">
                        <p className="text-sm font-medium mb-2">Calculation Steps:</p>
                        <div className="space-y-1">
                          {result.explanation.map((step, index) => (
                            <p key={index} className="text-sm text-muted-foreground font-mono">
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Decibel Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-1">Sound Intensity Level</p>
                    <p className="font-mono text-sm">L = 10 × log₁₀(I / I₀) dB</p>
                    <p className="text-xs text-muted-foreground mt-1">I₀ = 10⁻¹² W/m² (threshold of hearing)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-1">Power Ratio</p>
                    <p className="font-mono text-sm">L = 10 × log₁₀(P / P₀) dB</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-1">Voltage/Amplitude Ratio</p>
                    <p className="font-mono text-sm">L = 20 × log₁₀(V / V₀) dB</p>
                    <p className="text-xs text-muted-foreground mt-1">Factor is 20 because power ∝ voltage²</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Sound Levels</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {soundLevels.map((level) => {
                      const IconComponent = level.icon
                      return (
                        <div key={level.db} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                          <div className="flex items-center gap-2">
                            <IconComponent className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{level.description}</span>
                          </div>
                          <span className="text-sm font-mono font-medium">{level.db} dB</span>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-orange-50 border-orange-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-orange-800 mb-1">Important Note</p>
                      <p className="text-sm text-orange-700">
                        Results are theoretical. Actual perceived loudness may vary due to environment, frequency, and
                        individual hearing sensitivity.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Decibel (dB)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The decibel (dB) is a logarithmic unit used to express the ratio between two values, most commonly
                  power or intensity. Named after Alexander Graham Bell, the decibel is one-tenth of a bel. The
                  logarithmic scale is used because human perception of sound intensity is approximately logarithmic - a
                  sound that is 10 times more intense sounds roughly twice as loud to our ears.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Decibels are dimensionless units since they represent a ratio. The key advantage of using decibels is
                  that very large or very small ratios can be expressed as manageable numbers. For example, a sound
                  intensity that is 1,000,000 times the reference level is simply 60 dB (10 × log₁₀(1,000,000) = 60).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Waves className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding dB, dBm, and dBW</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">dB (Decibel)</h4>
                    <p className="text-sm text-muted-foreground">
                      A relative unit expressing the ratio between two values. Always requires a reference point to be
                      meaningful.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">dBm (dB-milliwatt)</h4>
                    <p className="text-sm text-muted-foreground">
                      An absolute unit where 0 dBm = 1 milliwatt. Common in RF and telecommunications. dBm = 10 ×
                      log₁₀(P / 1mW).
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">dBW (dB-watt)</h4>
                    <p className="text-sm text-muted-foreground">
                      An absolute unit where 0 dBW = 1 watt. dBW = dBm - 30. Used for higher power applications.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Volume2 className="h-5 w-5 text-primary" />
                  <CardTitle>Sound Intensity and Hearing Safety</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Human hearing covers an incredible range of sound intensities. The threshold of hearing (0 dB)
                  represents the quietest sound detectable by the average human ear, while sounds above 120 dB can cause
                  immediate pain and hearing damage. For reference, normal conversation occurs at about 60 dB, while a
                  rock concert can reach 110-120 dB.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h4 className="font-semibold text-yellow-800 mb-2">Hearing Protection Guidelines</h4>
                  <ul className="text-sm text-yellow-700 space-y-1">
                    <li>85 dB: Maximum recommended for 8 hours continuous exposure</li>
                    <li>88 dB: Maximum recommended for 4 hours</li>
                    <li>91 dB: Maximum recommended for 2 hours</li>
                    <li>100 dB: Maximum recommended for 15 minutes</li>
                    <li>Above 120 dB: Immediate hearing protection required</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Waves className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Decibels</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h4 className="font-semibold mb-2">Acoustics & Audio</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>Sound pressure level (SPL) measurements</li>
                      <li>Audio equipment specifications</li>
                      <li>Noise pollution assessment</li>
                      <li>Studio recording levels</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Electronics & RF</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>Signal strength and power levels</li>
                      <li>Amplifier gain specifications</li>
                      <li>Antenna performance</li>
                      <li>Transmission line loss calculations</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Telecommunications</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>Signal-to-noise ratio (SNR)</li>
                      <li>Cable and fiber optic attenuation</li>
                      <li>Network link budgets</li>
                      <li>Receiver sensitivity</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Other Fields</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>Earthquake magnitude (Richter scale)</li>
                      <li>Camera exposure values</li>
                      <li>Sensor dynamic range</li>
                      <li>Vibration measurements</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
