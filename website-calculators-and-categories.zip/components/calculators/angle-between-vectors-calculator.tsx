"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

type Dimension = "2d" | "3d"

interface VectorResult {
  angle: number
  angleRadians: number
  dotProduct: number
  magnitudeA: number
  magnitudeB: number
  isOrthogonal: boolean
  isParallel: boolean
  steps: string[]
}

export function AngleBetweenVectorsCalculator() {
  const [dimension, setDimension] = useState<Dimension>("2d")
  const [ax, setAx] = useState("")
  const [ay, setAy] = useState("")
  const [az, setAz] = useState("")
  const [bx, setBx] = useState("")
  const [by, setBy] = useState("")
  const [bz, setBz] = useState("")
  const [result, setResult] = useState<VectorResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const axNum = Number.parseFloat(ax)
    const ayNum = Number.parseFloat(ay)
    const bxNum = Number.parseFloat(bx)
    const byNum = Number.parseFloat(by)

    if (isNaN(axNum) || isNaN(ayNum) || isNaN(bxNum) || isNaN(byNum)) {
      setError("Please enter valid numeric values for all vector components")
      return
    }

    let azNum = 0
    let bzNum = 0

    if (dimension === "3d") {
      azNum = Number.parseFloat(az)
      bzNum = Number.parseFloat(bz)
      if (isNaN(azNum) || isNaN(bzNum)) {
        setError("Please enter valid numeric values for all vector components")
        return
      }
    }

    const steps: string[] = []

    // Step 1: Identify vectors
    if (dimension === "2d") {
      steps.push(`Vector A = (${axNum}, ${ayNum})`)
      steps.push(`Vector B = (${bxNum}, ${byNum})`)
    } else {
      steps.push(`Vector A = (${axNum}, ${ayNum}, ${azNum})`)
      steps.push(`Vector B = (${bxNum}, ${byNum}, ${bzNum})`)
    }

    // Step 2: Calculate dot product
    const dotProduct =
      dimension === "2d" ? axNum * bxNum + ayNum * byNum : axNum * bxNum + ayNum * byNum + azNum * bzNum

    if (dimension === "2d") {
      steps.push(`A · B = (${axNum})(${bxNum}) + (${ayNum})(${byNum})`)
      steps.push(`A · B = ${axNum * bxNum} + ${ayNum * byNum} = ${dotProduct}`)
    } else {
      steps.push(`A · B = (${axNum})(${bxNum}) + (${ayNum})(${byNum}) + (${azNum})(${bzNum})`)
      steps.push(`A · B = ${axNum * bxNum} + ${ayNum * byNum} + ${azNum * bzNum} = ${dotProduct}`)
    }

    // Step 3: Calculate magnitudes
    const magnitudeA =
      dimension === "2d"
        ? Math.sqrt(axNum * axNum + ayNum * ayNum)
        : Math.sqrt(axNum * axNum + ayNum * ayNum + azNum * azNum)

    const magnitudeB =
      dimension === "2d"
        ? Math.sqrt(bxNum * bxNum + byNum * byNum)
        : Math.sqrt(bxNum * bxNum + byNum * byNum + bzNum * bzNum)

    if (dimension === "2d") {
      steps.push(
        `|A| = √(${axNum}² + ${ayNum}²) = √(${axNum * axNum} + ${ayNum * ayNum}) = √${axNum * axNum + ayNum * ayNum} ≈ ${magnitudeA.toFixed(6)}`,
      )
      steps.push(
        `|B| = √(${bxNum}² + ${byNum}²) = √(${bxNum * bxNum} + ${byNum * byNum}) = √${bxNum * bxNum + byNum * byNum} ≈ ${magnitudeB.toFixed(6)}`,
      )
    } else {
      steps.push(
        `|A| = √(${axNum}² + ${ayNum}² + ${azNum}²) = √${axNum * axNum + ayNum * ayNum + azNum * azNum} ≈ ${magnitudeA.toFixed(6)}`,
      )
      steps.push(
        `|B| = √(${bxNum}² + ${byNum}² + ${bzNum}²) = √${bxNum * bxNum + byNum * byNum + bzNum * bzNum} ≈ ${magnitudeB.toFixed(6)}`,
      )
    }

    // Check for zero vectors
    if (magnitudeA === 0 || magnitudeB === 0) {
      setError("Cannot calculate angle: one or both vectors have zero magnitude")
      return
    }

    // Step 4: Calculate angle
    const cosTheta = dotProduct / (magnitudeA * magnitudeB)
    // Clamp to [-1, 1] to handle floating point errors
    const clampedCosTheta = Math.max(-1, Math.min(1, cosTheta))
    const angleRadians = Math.acos(clampedCosTheta)
    const angle = angleRadians * (180 / Math.PI)

    steps.push(`cos(θ) = (A · B) / (|A| × |B|)`)
    steps.push(`cos(θ) = ${dotProduct} / (${magnitudeA.toFixed(6)} × ${magnitudeB.toFixed(6)})`)
    steps.push(`cos(θ) = ${dotProduct} / ${(magnitudeA * magnitudeB).toFixed(6)} ≈ ${clampedCosTheta.toFixed(6)}`)
    steps.push(`θ = arccos(${clampedCosTheta.toFixed(6)}) ≈ ${angleRadians.toFixed(6)} radians`)
    steps.push(`θ ≈ ${angle.toFixed(4)}°`)

    // Check special cases
    const isOrthogonal = Math.abs(dotProduct) < 1e-10
    const isParallel = Math.abs(Math.abs(clampedCosTheta) - 1) < 1e-10

    if (isOrthogonal) {
      steps.push(`Since A · B = 0, the vectors are orthogonal (perpendicular)`)
    }
    if (isParallel) {
      steps.push(`Since |cos(θ)| = 1, the vectors are parallel`)
    }

    setResult({
      angle: Math.round(angle * 10000) / 10000,
      angleRadians: Math.round(angleRadians * 1000000) / 1000000,
      dotProduct: Math.round(dotProduct * 1000000) / 1000000,
      magnitudeA: Math.round(magnitudeA * 1000000) / 1000000,
      magnitudeB: Math.round(magnitudeB * 1000000) / 1000000,
      isOrthogonal,
      isParallel,
      steps,
    })
  }

  const handleReset = () => {
    setAx("")
    setAy("")
    setAz("")
    setBx("")
    setBy("")
    setBz("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Angle between vectors: ${result.angle}° (${result.angleRadians} rad)\nDot Product: ${result.dotProduct}\n|A| = ${result.magnitudeA}\n|B| = ${result.magnitudeB}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Angle Between Vectors Result",
          text: `I calculated the angle between two vectors using CalcHub! The angle is ${result.angle}° (${result.angleRadians} rad)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleDimension = () => {
    setDimension((prev) => (prev === "2d" ? "3d" : "2d"))
    setAz("")
    setBz("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Angle Between Vectors Calculator</CardTitle>
                    <CardDescription>Calculate the angle between two vectors</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Dimension</span>
                  <button
                    onClick={toggleDimension}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        dimension === "3d" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        dimension === "2d" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      2D
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        dimension === "3d" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      3D
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Vector A */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Vector A</Label>
                  <div className={`grid gap-2 ${dimension === "3d" ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Label htmlFor="ax" className="text-xs text-muted-foreground">
                        x₁
                      </Label>
                      <Input
                        id="ax"
                        type="number"
                        placeholder="x₁"
                        value={ax}
                        onChange={(e) => setAx(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="ay" className="text-xs text-muted-foreground">
                        y₁
                      </Label>
                      <Input
                        id="ay"
                        type="number"
                        placeholder="y₁"
                        value={ay}
                        onChange={(e) => setAy(e.target.value)}
                        step="any"
                      />
                    </div>
                    {dimension === "3d" && (
                      <div>
                        <Label htmlFor="az" className="text-xs text-muted-foreground">
                          z₁
                        </Label>
                        <Input
                          id="az"
                          type="number"
                          placeholder="z₁"
                          value={az}
                          onChange={(e) => setAz(e.target.value)}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Vector B */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Vector B</Label>
                  <div className={`grid gap-2 ${dimension === "3d" ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Label htmlFor="bx" className="text-xs text-muted-foreground">
                        x₂
                      </Label>
                      <Input
                        id="bx"
                        type="number"
                        placeholder="x₂"
                        value={bx}
                        onChange={(e) => setBx(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="by" className="text-xs text-muted-foreground">
                        y₂
                      </Label>
                      <Input
                        id="by"
                        type="number"
                        placeholder="y₂"
                        value={by}
                        onChange={(e) => setBy(e.target.value)}
                        step="any"
                      />
                    </div>
                    {dimension === "3d" && (
                      <div>
                        <Label htmlFor="bz" className="text-xs text-muted-foreground">
                          z₂
                        </Label>
                        <Input
                          id="bz"
                          type="number"
                          placeholder="z₂"
                          value={bz}
                          onChange={(e) => setBz(e.target.value)}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps" className="text-sm">
                    Show step-by-step solution
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Angle
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Angle Between Vectors</p>
                      <p className="text-4xl font-bold text-blue-600 mb-1">{result.angle}°</p>
                      <p className="text-sm text-muted-foreground">{result.angleRadians} rad</p>
                    </div>

                    {/* Special cases */}
                    {(result.isOrthogonal || result.isParallel) && (
                      <div className="mb-4 text-center">
                        {result.isOrthogonal && (
                          <span className="inline-block px-3 py-1 rounded-full bg-green-100 text-green-700 text-sm font-medium">
                            Orthogonal (Perpendicular)
                          </span>
                        )}
                        {result.isParallel && (
                          <span className="inline-block px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-sm font-medium">
                            Parallel Vectors
                          </span>
                        )}
                      </div>
                    )}

                    {/* Additional results */}
                    <div className="grid grid-cols-3 gap-2 text-center text-sm mb-4">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">Dot Product</p>
                        <p className="font-semibold">{result.dotProduct}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">|A|</p>
                        <p className="font-semibold">{result.magnitudeA.toFixed(4)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground text-xs">|B|</p>
                        <p className="font-semibold">{result.magnitudeB.toFixed(4)}</p>
                      </div>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible defaultOpen>
                        <CollapsibleTrigger className="flex items-center justify-between w-full p-2 bg-white rounded-lg mb-2 hover:bg-gray-50">
                          <span className="text-sm font-medium">Step-by-Step Solution</span>
                          <ChevronDown className="h-4 w-4" />
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="space-y-1 p-3 bg-white rounded-lg text-sm">
                            {result.steps.map((step, index) => (
                              <p key={index} className="font-mono text-xs">
                                {index + 1}. {step}
                              </p>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">θ = arccos((A · B) / (|A| × |B|))</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>A · B</strong> = dot product of vectors A and B
                    </p>
                    <p>
                      <strong>|A|</strong> = magnitude of vector A
                    </p>
                    <p>
                      <strong>|B|</strong> = magnitude of vector B
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>(1, 0) & (0, 1)</span>
                      <span className="font-semibold">90°</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>(1, 1) & (1, 0)</span>
                      <span className="font-semibold">45°</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>(1, 0) & (1, 0)</span>
                      <span className="font-semibold">0°</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>(1, 0) & (-1, 0)</span>
                      <span className="font-semibold">180°</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Properties</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm text-muted-foreground space-y-2 list-disc list-inside">
                    <li>θ = 0° means vectors are parallel (same direction)</li>
                    <li>θ = 90° means vectors are orthogonal (perpendicular)</li>
                    <li>θ = 180° means vectors are antiparallel (opposite direction)</li>
                    <li>The angle is always between 0° and 180°</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Angle Between Vectors?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The angle between two vectors is a fundamental concept in linear algebra and vector geometry. It
                  represents the rotation needed to align one vector with another and is calculated using the dot
                  product formula. This angle is always between 0° and 180° (or 0 and π radians), as it represents the
                  smallest angle between the two vectors.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The calculation uses the geometric definition of the dot product: A · B = |A||B|cos(θ), where θ is the
                  angle between the vectors. By rearranging this formula, we get θ = arccos((A · B) / (|A||B|)), which
                  allows us to find the angle when we know the vector components.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The angle between vectors has numerous applications across physics, engineering, computer graphics,
                  and machine learning. In physics, it's used to calculate work done by a force (W = F·d·cos(θ)) and to
                  analyze motion in multiple dimensions. In computer graphics, vector angles determine lighting,
                  shading, and surface normals.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In machine learning, cosine similarity (which is based on the angle between vectors) is widely used to
                  measure document similarity, recommendation systems, and natural language processing. Navigation
                  systems use vector angles to calculate headings and directions between waypoints.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Angle calculations between vectors follow standard Euclidean formulas. Results depend on correct
                  component input and selected dimension. This calculator provides mathematical computations and should
                  be verified for critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
