"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Droplet, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface BoilingPointResult {
  elevation: number
  finalBoilingPoint: number
  molality: number
  vantHoff: number
  kb: number
  pureBoilingPoint: number
}

const COMMON_SOLVENTS = [
  { name: "Water", kb: 0.512, bp: 100.0 },
  { name: "Ethanol", kb: 1.22, bp: 78.4 },
  { name: "Benzene", kb: 2.53, bp: 80.1 },
  { name: "Chloroform", kb: 3.63, bp: 61.2 },
  { name: "Acetic Acid", kb: 3.07, bp: 118.1 },
  { name: "Cyclohexane", kb: 2.79, bp: 80.7 },
  { name: "Carbon Tetrachloride", kb: 5.03, bp: 76.8 },
  { name: "Acetone", kb: 1.71, bp: 56.2 },
  { name: "Diethyl Ether", kb: 2.02, bp: 34.6 },
  { name: "Custom", kb: 0, bp: 0 },
]

export function BoilingPointElevationCalculator() {
  const [selectedSolvent, setSelectedSolvent] = useState("Water")
  const [molality, setMolality] = useState("")
  const [vantHoff, setVantHoff] = useState("1")
  const [kb, setKb] = useState("0.512")
  const [pureBoilingPoint, setPureBoilingPoint] = useState("100.0")
  const [result, setResult] = useState<BoilingPointResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const handleSolventChange = (value: string) => {
    setSelectedSolvent(value)
    const solvent = COMMON_SOLVENTS.find((s) => s.name === value)
    if (solvent) {
      setKb(solvent.kb.toString())
      setPureBoilingPoint(solvent.bp.toString())
    }
    setResult(null)
    setError("")
  }

  const calculateBoilingPoint = () => {
    setError("")
    setResult(null)

    const m = Number.parseFloat(molality)
    const i = Number.parseFloat(vantHoff)
    const kbVal = Number.parseFloat(kb)
    const bpPure = Number.parseFloat(pureBoilingPoint)

    if (isNaN(m) || m <= 0) {
      setError("Please enter a valid molality greater than 0")
      return
    }

    if (isNaN(i) || i <= 0) {
      setError("Please enter a valid van't Hoff factor greater than 0")
      return
    }

    if (isNaN(kbVal) || kbVal <= 0) {
      setError("Please enter a valid ebullioscopic constant greater than 0")
      return
    }

    if (isNaN(bpPure)) {
      setError("Please enter a valid boiling point")
      return
    }

    // Calculate boiling point elevation: ΔTb = i × Kb × m
    const deltaT = i * kbVal * m
    const finalBp = bpPure + deltaT

    setResult({
      elevation: deltaT,
      finalBoilingPoint: finalBp,
      molality: m,
      vantHoff: i,
      kb: kbVal,
      pureBoilingPoint: bpPure,
    })
  }

  const handleReset = () => {
    setSelectedSolvent("Water")
    setMolality("")
    setVantHoff("1")
    setKb("0.512")
    setPureBoilingPoint("100.0")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Boiling Point Elevation: ${result.elevation.toFixed(3)}°C, Final BP: ${result.finalBoilingPoint.toFixed(2)}°C`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Boiling Point Elevation Result",
          text: `Boiling point elevation: ${result.elevation.toFixed(3)}°C, Final BP: ${result.finalBoilingPoint.toFixed(2)}°C`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getElevationCategory = (elevation: number) => {
    if (elevation < 0.5) return { label: "Negligible", color: "text-gray-600", bgColor: "bg-gray-50 border-gray-200" }
    if (elevation < 2.0) return { label: "Small", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    if (elevation < 5.0) return { label: "Moderate", color: "text-purple-600", bgColor: "bg-purple-50 border-purple-200" }
    if (elevation < 10.0) return { label: "Significant", color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    return { label: "Large", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Droplet className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Boiling Point Elevation</CardTitle>
                    <CardDescription>Calculate colligative property effects</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Solvent Selection */}
                <div className="space-y-2">
                  <Label htmlFor="solvent">Solvent</Label>
                  <Select value={selectedSolvent} onValueChange={handleSolventChange}>
                    <SelectTrigger id="solvent">
                      <SelectValue placeholder="Select solvent" />
                    </SelectTrigger>
                    <SelectContent>
                      {COMMON_SOLVENTS.map((solvent) => (
                        <SelectItem key={solvent.name} value={solvent.name}>
                          {solvent.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Molality Input */}
                <div className="space-y-2">
                  <Label htmlFor="molality">Molality (m, mol/kg)</Label>
                  <Input
                    id="molality"
                    type="number"
                    placeholder="Enter molality of solute"
                    value={molality}
                    onChange={(e) => setMolality(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Van't Hoff Factor */}
                <div className="space-y-2">
                  <Label htmlFor="vanthoff">Van&apos;t Hoff Factor (i)</Label>
                  <Input
                    id="vanthoff"
                    type="number"
                    placeholder="Enter van't Hoff factor"
                    value={vantHoff}
                    onChange={(e) => setVantHoff(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">
                    1 for non-electrolytes, 2 for NaCl, 3 for CaCl₂, etc.
                  </p>
                </div>

                {/* Ebullioscopic Constant */}
                <div className="space-y-2">
                  <Label htmlFor="kb">Ebullioscopic Constant (K_b, °C·kg/mol)</Label>
                  <Input
                    id="kb"
                    type="number"
                    placeholder="Enter Kb value"
                    value={kb}
                    onChange={(e) => setKb(e.target.value)}
                    min="0"
                    step="0.001"
                    disabled={selectedSolvent !== "Custom"}
                  />
                </div>

                {/* Pure Solvent Boiling Point */}
                <div className="space-y-2">
                  <Label htmlFor="bp">Pure Solvent Boiling Point (°C)</Label>
                  <Input
                    id="bp"
                    type="number"
                    placeholder="Enter pure solvent BP"
                    value={pureBoilingPoint}
                    onChange={(e) => setPureBoilingPoint(e.target.value)}
                    step="0.1"
                    disabled={selectedSolvent !== "Custom"}
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBoilingPoint} className="w-full bg-purple-600 hover:bg-purple-700" size="lg">
                  Calculate Boiling Point
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Boiling Point Elevation</p>
                        <p className="text-4xl font-bold text-purple-600 mb-1">
                          {result.elevation.toFixed(3)}°C
                        </p>
                        <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getElevationCategory(result.elevation).bgColor} ${getElevationCategory(result.elevation).color} border`}>
                          {getElevationCategory(result.elevation).label} Elevation
                        </div>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Final Boiling Point</p>
                        <p className="text-4xl font-bold text-blue-600">
                          {result.finalBoilingPoint.toFixed(2)}°C
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step Calculation */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Calculation Steps</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2 text-sm">
                        <div className="p-3 bg-muted rounded-lg">
                          <p className="font-mono text-center">
                            ΔT<sub>b</sub> = i × K<sub>b</sub> × m
                          </p>
                        </div>
                        <div className="space-y-1 text-muted-foreground">
                          <p>
                            ΔT<sub>b</sub> = {result.vantHoff} × {result.kb} × {result.molality}
                          </p>
                          <p>
                            ΔT<sub>b</sub> = {result.elevation.toFixed(3)}°C
                          </p>
                          <p className="pt-2 border-t">
                            T<sub>b</sub>(solution) = T<sub>b</sub>(pure) + ΔT<sub>b</sub>
                          </p>
                          <p>
                            T<sub>b</sub>(solution) = {result.pureBoilingPoint}°C + {result.elevation.toFixed(3)}°C
                          </p>
                          <p className="font-semibold text-foreground">
                            T<sub>b</sub>(solution) = {result.finalBoilingPoint.toFixed(2)}°C
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Solvents K_b Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {COMMON_SOLVENTS.filter((s) => s.name !== "Custom").map((solvent) => (
                      <div
                        key={solvent.name}
                        className="flex items-center justify-between p-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
                      >
                        <span className="font-medium">{solvent.name}</span>
                        <div className="text-right">
                          <span className="text-muted-foreground">
                            {solvent.kb} °C·kg/mol
                          </span>
                          <span className="text-xs text-muted-foreground ml-2">
                            (BP: {solvent.bp}°C)
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground mb-2">
                      ΔT<sub>b</sub> = i × K<sub>b</sub> × m
                    </p>
                    <p className="text-xs">
                      T<sub>b</sub>(solution) = T<sub>b</sub>(pure) + ΔT<sub>b</sub>
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p>
                      <strong>ΔT<sub>b</sub>:</strong> Boiling point elevation (°C)
                    </p>
                    <p>
                      <strong>i:</strong> Van&apos;t Hoff factor
                    </p>
                    <p>
                      <strong>K<sub>b</sub>:</strong> Ebullioscopic constant (°C·kg/mol)
                    </p>
                    <p>
                      <strong>m:</strong> Molality of solute (mol/kg)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Boiling Point Elevation */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-purple-600" />
                  <CardTitle>What is Boiling Point Elevation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Boiling point elevation is a colligative property of solutions, meaning it depends on the number of
                  solute particles dissolved in a solvent, not their identity. When a non-volatile solute is added to a
                  pure solvent, the boiling point of the resulting solution increases. This phenomenon occurs because
                  the presence of solute particles interferes with the vaporization of solvent molecules, requiring
                  more thermal energy to reach the vapor pressure needed for boiling.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The magnitude of boiling point elevation is directly proportional to the molal concentration of the
                  solute and is characterized by the ebullioscopic constant (K<sub>b</sub>), which is a unique property
                  of each solvent. For electrolytes that dissociate into ions, the van&apos;t Hoff factor accounts for the
                  number of particles produced per formula unit dissolved.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplet className="h-5 w-5 text-purple-600" />
                  <CardTitle>Applications of Boiling Point Elevation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding boiling point elevation has numerous practical applications in chemistry and industry.
                  In cooking, adding salt to water raises its boiling point, allowing food to cook at slightly higher
                  temperatures. In automotive engines, antifreeze solutions (typically ethylene glycol in water) both
                  lower the freezing point and raise the boiling point, protecting the engine across a wider
                  temperature range.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In analytical chemistry, boiling point elevation measurements can be used to determine the molar mass
                  of unknown compounds through ebullioscopy. The food industry uses this principle in the production of
                  concentrated foods like jams and syrups, where high sugar concentrations significantly elevate the
                  boiling point. Pharmaceutical and chemical manufacturing processes also rely on understanding boiling
                  point changes when working with solutions of various concentrations.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p className="leading-relaxed">
                  Boiling point elevation calculations assume ideal dilute solutions. Deviations may occur for
                  concentrated or non-ideal systems. The van&apos;t Hoff factor may differ from theoretical values for
                  strong electrolytes in concentrated solutions due to ion pairing and incomplete dissociation. For
                  precise scientific work, experimental verification is recommended. This calculator is for educational
                  and estimation purposes only.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
