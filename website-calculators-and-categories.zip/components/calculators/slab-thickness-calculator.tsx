"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Layers, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMode = "thickness" | "volume"
type SlabType = "one-way" | "two-way"
type UnitSystem = "metric" | "imperial"

interface SlabResult {
  thickness: number
  volume: number
  thicknessCategory: string
  color: string
  bgColor: string
}

export function SlabThicknessCalculator() {
  const [mode, setMode] = useState<CalculationMode>("thickness")
  const [slabType, setSlabType] = useState<SlabType>("one-way")
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [span, setSpan] = useState("")
  const [thickness, setThickness] = useState("")
  const [safetyFactor, setSafetyFactor] = useState("1.0")
  const [result, setResult] = useState<SlabResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateSlab = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const safetyFactorNum = Number.parseFloat(safetyFactor) || 1.0

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }

    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }

    if (safetyFactorNum <= 0) {
      setError("Safety factor must be greater than 0")
      return
    }

    let calculatedThickness: number
    let volume: number

    if (mode === "thickness") {
      const spanNum = Number.parseFloat(span)
      if (isNaN(spanNum) || spanNum <= 0) {
        setError("Please enter a valid span length greater than 0")
        return
      }

      // Convert to meters if imperial
      const spanInMeters = unitSystem === "imperial" ? spanNum * 0.3048 : spanNum

      // Rule of thumb calculation
      if (slabType === "one-way") {
        calculatedThickness = (spanInMeters / 25) * safetyFactorNum
      } else {
        calculatedThickness = (spanInMeters / 30) * safetyFactorNum
      }

      // Convert back to feet if imperial
      if (unitSystem === "imperial") {
        calculatedThickness = calculatedThickness / 0.3048
      }

      // Calculate volume
      volume = lengthNum * widthNum * calculatedThickness
    } else {
      const thicknessNum = Number.parseFloat(thickness)
      if (isNaN(thicknessNum) || thicknessNum <= 0) {
        setError("Please enter a valid thickness greater than 0")
        return
      }

      calculatedThickness = thicknessNum
      volume = lengthNum * widthNum * thicknessNum
    }

    // Determine thickness category
    let thicknessCategory: string
    let color: string
    let bgColor: string

    const thicknessInMeters = unitSystem === "imperial" ? calculatedThickness * 0.3048 : calculatedThickness

    if (thicknessInMeters < 0.10) {
      thicknessCategory = "Light Slab"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (thicknessInMeters < 0.15) {
      thicknessCategory = "Medium Slab"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (thicknessInMeters < 0.20) {
      thicknessCategory = "Heavy Slab"
      color = "text-amber-600"
      bgColor = "bg-amber-50 border-amber-200"
    } else {
      thicknessCategory = "Extra Heavy Slab"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      thickness: Math.round(calculatedThickness * 1000) / 1000,
      volume: Math.round(volume * 1000) / 1000,
      thicknessCategory,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setSpan("")
    setThickness("")
    setSafetyFactor("1.0")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "m" : "ft"
      const volumeUnit = unitSystem === "metric" ? "m³" : "ft³"
      await navigator.clipboard.writeText(
        `Slab Thickness: ${result.thickness} ${unit}\nConcrete Volume: ${result.volume} ${volumeUnit}\nCategory: ${result.thicknessCategory}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const unit = unitSystem === "metric" ? "m" : "ft"
        const volumeUnit = unitSystem === "metric" ? "m³" : "ft³"
        await navigator.share({
          title: "Slab Thickness Calculation",
          text: `I calculated my slab thickness using CalcHub! Thickness: ${result.thickness} ${unit}, Volume: ${result.volume} ${volumeUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setSpan("")
    setThickness("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Slab Thickness Calculator</CardTitle>
                    <CardDescription>Calculate RCC slab thickness and concrete volume</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Mode</span>
                  <button
                    onClick={() => setMode((prev) => (prev === "thickness" ? "volume" : "thickness"))}
                    className="relative inline-flex h-9 w-52 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "volume" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        mode === "thickness" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Find Thickness
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                        mode === "volume" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Find Volume
                    </span>
                  </button>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Slab Type */}
                <div className="space-y-2">
                  <Label>Slab Type</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setSlabType("one-way")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        slabType === "one-way"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-gray-200 hover:border-amber-200"
                      }`}
                    >
                      One-Way Slab
                    </button>
                    <button
                      onClick={() => setSlabType("two-way")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        slabType === "two-way"
                          ? "border-amber-500 bg-amber-50 text-amber-700"
                          : "border-gray-200 hover:border-amber-200"
                      }`}
                    >
                      Two-Way Slab
                    </button>
                  </div>
                </div>

                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Width Input */}
                <div className="space-y-2">
                  <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="width"
                    type="number"
                    placeholder={`Enter width in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={width}
                    onChange={(e) => setWidth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Conditional Inputs Based on Mode */}
                {mode === "thickness" ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="span">Span Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                      <Input
                        id="span"
                        type="number"
                        placeholder={`Enter span length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                        value={span}
                        onChange={(e) => setSpan(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="safety">Safety Factor (optional)</Label>
                      <Input
                        id="safety"
                        type="number"
                        placeholder="Default: 1.0"
                        value={safetyFactor}
                        onChange={(e) => setSafetyFactor(e.target.value)}
                        min="0.1"
                        step="0.1"
                      />
                    </div>
                  </>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="thickness">Slab Thickness ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="thickness"
                      type="number"
                      placeholder={`Enter thickness in ${unitSystem === "metric" ? "meters" : "feet"}`}
                      value={thickness}
                      onChange={(e) => setThickness(e.target.value)}
                      min="0"
                      step="0.001"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSlab} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Slab Thickness</p>
                        <p className={`text-3xl font-bold ${result.color}`}>
                          {result.thickness} {unitSystem === "metric" ? "m" : "ft"}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Concrete Volume</p>
                        <p className={`text-2xl font-bold ${result.color}`}>
                          {result.volume} {unitSystem === "metric" ? "m³" : "ft³"}
                        </p>
                      </div>
                      <div>
                        <p className={`text-lg font-semibold ${result.color}`}>{result.thicknessCategory}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Slab Thickness Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Light Slab</span>
                      <span className="text-sm text-blue-600">{"< 0.10 m"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Medium Slab</span>
                      <span className="text-sm text-green-600">0.10 – 0.15 m</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Heavy Slab</span>
                      <span className="text-sm text-amber-600">0.15 – 0.20 m</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Extra Heavy</span>
                      <span className="text-sm text-red-600">≥ 0.20 m</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Thickness Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground text-center">One-Way Slab</p>
                    <p className="font-mono text-center">Thickness ≈ Span / 25</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground text-center">Two-Way Slab</p>
                    <p className="font-mono text-center">Thickness ≈ Span / 30</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                    Important Note
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    Slab thickness calculations are preliminary estimates. Structural design must be verified by a
                    qualified engineer.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Slab Thickness */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Slab Thickness?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Slab thickness refers to the vertical depth of a reinforced concrete (RCC) slab, which is a
                  horizontal structural element that forms floors and roofs in buildings. The thickness of a slab is a
                  critical design parameter that directly affects the slab's ability to carry loads, resist deflection,
                  and provide adequate structural stability. Proper slab thickness ensures the building meets safety
                  standards and can support the intended loads over its lifespan.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Determining the correct slab thickness involves considering factors such as span length, support
                  conditions, loading conditions, and the type of slab (one-way or two-way). Engineers use both
                  empirical rules of thumb and detailed structural analysis to calculate appropriate slab thickness,
                  balancing structural requirements with economy and construction practicality.
                </p>
              </CardContent>
            </Card>

            {/* How is Slab Thickness Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How is Slab Thickness Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation of slab thickness typically starts with empirical rules of thumb that provide quick
                  preliminary estimates. For one-way slabs (where bending occurs in one direction), the thickness is
                  generally taken as span divided by 25. For two-way slabs (where bending occurs in both directions),
                  the thickness is approximately span divided by 30. These rules provide a starting point for design but
                  must be verified through detailed structural analysis.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concrete volume calculation is straightforward once the thickness is determined. Simply multiply
                  the length, width, and thickness of the slab to get the total volume of concrete required. This
                  calculation is essential for estimating material quantities and project costs. Safety factors may be
                  applied to account for uncertainties in loading, material properties, and construction variations.
                </p>
              </CardContent>
            </Card>

            {/* Understanding Slab Types */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Slab Types</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Slabs are classified based on their support conditions and the direction of load transfer. One-way
                  slabs are supported on two opposite sides and transfer loads primarily in one direction (the shorter
                  span). These slabs are typically used when the length-to-width ratio exceeds 2. The reinforcement in
                  one-way slabs is primarily provided in the direction of the shorter span, with minimal distribution
                  steel in the perpendicular direction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Two-way slabs are supported on all four sides and transfer loads in both directions to the supports.
                  These slabs are more efficient for square or nearly square panels where the length-to-width ratio is
                  less than 2. Two-way slabs require reinforcement in both directions and typically result in more
                  economical designs for appropriate geometries. The load distribution in two-way slabs is more complex,
                  with loads being carried by bending in both principal directions.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <CardTitle>Common Questions</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What is the minimum slab thickness?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The minimum thickness for residential slabs is typically 100mm (4 inches) for light loads and
                      short spans. However, building codes and engineering standards specify minimum thicknesses based
                      on span length, loading conditions, and support conditions. Always consult local building codes
                      and a structural engineer for specific requirements.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How do I choose between one-way and two-way?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The choice depends on the aspect ratio of the slab panel. If the longer span is more than twice
                      the shorter span (length/width {">"} 2), design as a one-way slab. If the ratio is less than 2,
                      design as a two-way slab. Two-way slabs are generally more economical for square or nearly square
                      panels.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What factors affect slab thickness?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Several factors influence slab thickness including span length, support conditions, live and dead
                      loads, concrete grade, reinforcement type and amount, deflection limits, fire resistance
                      requirements, and construction method. Professional structural analysis considers all these
                      factors to determine optimal thickness.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Can I reduce slab thickness to save costs?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      While reducing slab thickness may save on concrete and material costs, it can lead to structural
                      inadequacy, excessive deflection, cracking, and safety issues. Never reduce thickness below what
                      is specified by a qualified structural engineer. Proper thickness is essential for structural
                      integrity and long-term performance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
