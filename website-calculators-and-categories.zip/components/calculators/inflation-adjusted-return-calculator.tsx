"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Calculator,
  Target,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, currencyOptions, formatCurrency, currencySymbols } from "@/lib/currency"

type CompoundingFrequency = "annual" | "semiannual" | "quarterly" | "monthly"

interface YearBreakdown {
  year: number
  nominalValue: number
  realValue: number
  nominalGrowth: number
  realGrowth: number
  inflationImpact: number
}

interface CalculationResult {
  realReturn: number
  nominalFinalValue: number
  realFinalValue: number
  totalNominalGain: number
  totalRealGain: number
  purchasingPowerLoss: number
  yearBreakdown: YearBreakdown[]
  category: string
  color: string
  bgColor: string
}

export function InflationAdjustedReturnCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [nominalReturn, setNominalReturn] = useState("")
  const [inflationRate, setInflationRate] = useState("")
  const [initialInvestment, setInitialInvestment] = useState("")
  const [duration, setDuration] = useState("")
  const [compoundingFrequency, setCompoundingFrequency] = useState<CompoundingFrequency>("annual")
  const [monthlyContribution, setMonthlyContribution] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<CalculationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const getCompoundingPeriods = (freq: CompoundingFrequency): number => {
    switch (freq) {
      case "annual":
        return 1
      case "semiannual":
        return 2
      case "quarterly":
        return 4
      case "monthly":
        return 12
      default:
        return 1
    }
  }

  const calculateInflationAdjustedReturn = () => {
    setError("")
    setResult(null)

    const nominalReturnNum = Number.parseFloat(nominalReturn)
    const inflationRateNum = Number.parseFloat(inflationRate)

    if (isNaN(nominalReturnNum)) {
      setError("Please enter a valid nominal return rate")
      return
    }

    if (isNaN(inflationRateNum) || inflationRateNum < 0) {
      setError("Please enter a valid inflation rate (0 or greater)")
      return
    }

    // Calculate real return using Fisher equation
    const realReturn = ((1 + nominalReturnNum / 100) / (1 + inflationRateNum / 100) - 1) * 100

    let nominalFinalValue = 0
    let realFinalValue = 0
    let totalNominalGain = 0
    let totalRealGain = 0
    let purchasingPowerLoss = 0
    const yearBreakdown: YearBreakdown[] = []

    const initialInvestmentNum = Number.parseFloat(initialInvestment) || 0
    const durationNum = Number.parseFloat(duration) || 1
    const monthlyContributionNum = Number.parseFloat(monthlyContribution) || 0
    const periodsPerYear = getCompoundingPeriods(compoundingFrequency)

    if (initialInvestmentNum > 0 && durationNum > 0) {
      const nominalRatePerPeriod = nominalReturnNum / 100 / periodsPerYear
      const totalPeriods = durationNum * periodsPerYear

      let nominalValue = initialInvestmentNum
      let totalContributions = initialInvestmentNum

      for (let year = 1; year <= durationNum; year++) {
        const startNominalValue = nominalValue

        // Apply compounding for this year
        for (let period = 0; period < periodsPerYear; period++) {
          nominalValue *= 1 + nominalRatePerPeriod
          // Add monthly contributions proportionally
          if (monthlyContributionNum > 0) {
            const monthsPerPeriod = 12 / periodsPerYear
            for (let month = 0; month < monthsPerPeriod; month++) {
              nominalValue += monthlyContributionNum
              totalContributions += monthlyContributionNum
            }
          }
        }

        // Calculate real value adjusted for inflation
        const inflationMultiplier = Math.pow(1 + inflationRateNum / 100, year)
        const realValue = nominalValue / inflationMultiplier

        const nominalGrowth = nominalValue - startNominalValue
        const prevRealValue = year === 1 ? initialInvestmentNum : yearBreakdown[year - 2].realValue
        const realGrowth = realValue - prevRealValue
        const inflationImpact = nominalValue - realValue

        yearBreakdown.push({
          year,
          nominalValue,
          realValue,
          nominalGrowth,
          realGrowth,
          inflationImpact,
        })
      }

      nominalFinalValue = nominalValue
      realFinalValue = yearBreakdown[yearBreakdown.length - 1].realValue
      totalNominalGain = nominalFinalValue - totalContributions
      totalRealGain = realFinalValue - totalContributions
      purchasingPowerLoss = nominalFinalValue - realFinalValue
    }

    // Determine category based on real return
    let category: string
    let color: string
    let bgColor: string

    if (realReturn < 0) {
      category = "Negative Real Return"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else if (realReturn < 2) {
      category = "Low Real Return"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (realReturn < 5) {
      category = "Moderate Real Return"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else {
      category = "High Real Return"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    }

    setResult({
      realReturn,
      nominalFinalValue,
      realFinalValue,
      totalNominalGain,
      totalRealGain,
      purchasingPowerLoss,
      yearBreakdown,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setNominalReturn("")
    setInflationRate("")
    setInitialInvestment("")
    setDuration("")
    setCompoundingFrequency("annual")
    setMonthlyContribution("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Inflation-Adjusted Return Analysis:
Real Return: ${result.realReturn.toFixed(2)}%
Nominal Return: ${nominalReturn}%
Inflation Rate: ${inflationRate}%
${
  result.nominalFinalValue > 0
    ? `Nominal Final Value: ${formatCurrency(result.nominalFinalValue, currency)}
Real Final Value: ${formatCurrency(result.realFinalValue, currency)}
Purchasing Power Loss: ${formatCurrency(result.purchasingPowerLoss, currency)}`
    : ""
}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Inflation-Adjusted Return Analysis",
          text: `My real return is ${result.realReturn.toFixed(2)}% after accounting for ${inflationRate}% inflation`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Inflation-Adjusted Return</CardTitle>
                    <CardDescription>Calculate real return after inflation</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <Select value={currency} onValueChange={(value: Currency) => setCurrency(value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencyOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.symbol} {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Nominal Return Input */}
                <div className="space-y-2">
                  <Label htmlFor="nominalReturn">Nominal Return (%)</Label>
                  <Input
                    id="nominalReturn"
                    type="number"
                    placeholder="e.g., 8"
                    value={nominalReturn}
                    onChange={(e) => setNominalReturn(e.target.value)}
                    step="0.1"
                  />
                </div>

                {/* Inflation Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="inflationRate">Inflation Rate (%)</Label>
                  <Input
                    id="inflationRate"
                    type="number"
                    placeholder="e.g., 3"
                    value={inflationRate}
                    onChange={(e) => setInflationRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Optional: Initial Investment */}
                <div className="space-y-2">
                  <Label htmlFor="initialInvestment">Initial Investment ({symbol}) - Optional</Label>
                  <Input
                    id="initialInvestment"
                    type="number"
                    placeholder="e.g., 10000"
                    value={initialInvestment}
                    onChange={(e) => setInitialInvestment(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Optional: Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Investment Duration (years) - Optional</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="e.g., 10"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto font-medium">
                      Advanced Options
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    {/* Compounding Frequency */}
                    <div className="space-y-2">
                      <Label>Compounding Frequency</Label>
                      <Select
                        value={compoundingFrequency}
                        onValueChange={(value: CompoundingFrequency) => setCompoundingFrequency(value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="annual">Annual</SelectItem>
                          <SelectItem value="semiannual">Semi-Annual</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Monthly Contribution */}
                    <div className="space-y-2">
                      <Label htmlFor="monthlyContribution">Monthly Contribution ({symbol})</Label>
                      <Input
                        id="monthlyContribution"
                        type="number"
                        placeholder="e.g., 500"
                        value={monthlyContribution}
                        onChange={(e) => setMonthlyContribution(e.target.value)}
                        min="0"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateInflationAdjustedReturn} className="w-full" size="lg">
                  Calculate Real Return
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Real Return (After Inflation)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-2`}>{result.realReturn.toFixed(2)}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Comparison Bar */}
                    <div className="mt-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Nominal: {nominalReturn}%</span>
                        <span>Inflation: {inflationRate}%</span>
                      </div>
                      <div className="h-3 bg-muted rounded-full overflow-hidden flex">
                        <div
                          className="bg-green-500 h-full"
                          style={{
                            width: `${Math.max(0, (result.realReturn / Number.parseFloat(nominalReturn)) * 100)}%`,
                          }}
                        />
                        <div
                          className="bg-red-400 h-full"
                          style={{
                            width: `${Math.min(100, (Number.parseFloat(inflationRate) / Number.parseFloat(nominalReturn)) * 100)}%`,
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-green-500 rounded-full" /> Real Return
                        </span>
                        <span className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-red-400 rounded-full" /> Inflation Loss
                        </span>
                      </div>
                    </div>

                    {/* Future Value Results */}
                    {result.nominalFinalValue > 0 && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-3">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="text-center p-2 bg-white/50 rounded-lg">
                            <p className="text-xs text-muted-foreground">Nominal Value</p>
                            <p className="font-semibold">{formatCurrency(result.nominalFinalValue, currency)}</p>
                          </div>
                          <div className="text-center p-2 bg-white/50 rounded-lg">
                            <p className="text-xs text-muted-foreground">Real Value</p>
                            <p className="font-semibold">{formatCurrency(result.realFinalValue, currency)}</p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="text-center p-2 bg-white/50 rounded-lg">
                            <p className="text-xs text-muted-foreground">Nominal Gain</p>
                            <p className="font-semibold text-green-600">
                              +{formatCurrency(result.totalNominalGain, currency)}
                            </p>
                          </div>
                          <div className="text-center p-2 bg-white/50 rounded-lg">
                            <p className="text-xs text-muted-foreground">Purchasing Power Loss</p>
                            <p className="font-semibold text-red-600">
                              -{formatCurrency(result.purchasingPowerLoss, currency)}
                            </p>
                          </div>
                        </div>

                        {/* Year-by-Year Breakdown */}
                        {result.yearBreakdown.length > 0 && (
                          <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                            <CollapsibleTrigger asChild>
                              <Button variant="ghost" size="sm" className="w-full mt-2">
                                {showBreakdown ? "Hide" : "Show"} Year-by-Year Breakdown
                                {showBreakdown ? (
                                  <ChevronUp className="ml-2 h-4 w-4" />
                                ) : (
                                  <ChevronDown className="ml-2 h-4 w-4" />
                                )}
                              </Button>
                            </CollapsibleTrigger>
                            <CollapsibleContent>
                              <div className="mt-2 max-h-48 overflow-y-auto">
                                <table className="w-full text-xs">
                                  <thead className="bg-muted/50 sticky top-0">
                                    <tr>
                                      <th className="p-2 text-left">Year</th>
                                      <th className="p-2 text-right">Nominal</th>
                                      <th className="p-2 text-right">Real</th>
                                      <th className="p-2 text-right">Loss</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {result.yearBreakdown.map((row) => (
                                      <tr key={row.year} className="border-t border-muted">
                                        <td className="p-2">{row.year}</td>
                                        <td className="p-2 text-right">{formatCurrency(row.nominalValue, currency)}</td>
                                        <td className="p-2 text-right">{formatCurrency(row.realValue, currency)}</td>
                                        <td className="p-2 text-right text-red-600">
                                          -{formatCurrency(row.inflationImpact, currency)}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </CollapsibleContent>
                          </Collapsible>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Real Return Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Negative</span>
                      <span className="text-sm text-red-600">{"< 0%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Low</span>
                      <span className="text-sm text-yellow-600">0% – 2%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Moderate</span>
                      <span className="text-sm text-blue-600">2% – 5%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">High</span>
                      <span className="text-sm text-green-600">{"> 5%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fisher Equation</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Real Return = ((1 + r) / (1 + i)) - 1</p>
                  </div>
                  <p>
                    Where <strong>r</strong> is the nominal return and <strong>i</strong> is the inflation rate. This
                    formula accounts for the compounding effect of inflation.
                  </p>
                  <p className="text-xs">
                    Example: 8% nominal return with 3% inflation = ((1.08)/(1.03))-1 = 4.85% real return
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Inflation-Adjusted Return?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The inflation-adjusted return, also known as the real return, measures the actual growth of your
                  purchasing power after accounting for inflation. While your investments might show impressive nominal
                  gains on paper, inflation continuously erodes the buying power of those gains. Understanding your real
                  return helps you assess whether your investments are truly growing your wealth or merely keeping pace
                  with rising prices.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, if your investment earns 8% in a year but inflation is 3%, your real return is
                  approximately 4.85%. This means your actual purchasing power increased by only about 4.85%, not 8%.
                  This distinction is crucial for long-term financial planning, especially for retirement savings where
                  maintaining purchasing power over decades is essential.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Start by entering your investment's nominal return rate (the stated or expected return) and the
                  current or expected inflation rate. The calculator will immediately compute your real return using the
                  Fisher equation, which accounts for the compounding effect of inflation on returns.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For a more detailed analysis, enter your initial investment amount and duration. You can also add
                  monthly contributions and adjust the compounding frequency. The calculator will then show you the
                  year-by-year breakdown of nominal versus real values, helping you visualize how inflation erodes your
                  gains over time.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Why Real Returns Matter</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Retirement Planning</h4>
                    <p className="text-sm text-muted-foreground">
                      When planning for retirement decades away, inflation can dramatically reduce your purchasing
                      power. A million dollars today won't buy the same lifestyle in 30 years.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Investment Comparison</h4>
                    <p className="text-sm text-muted-foreground">
                      Comparing investments across different time periods requires inflation adjustment to make
                      meaningful comparisons of actual wealth growth.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Goal Setting</h4>
                    <p className="text-sm text-muted-foreground">
                      Setting realistic financial goals requires understanding that future costs will be higher than
                      today's prices due to inflation.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Risk Assessment</h4>
                    <p className="text-sm text-muted-foreground">
                      Conservative investments with low nominal returns may actually lose purchasing power after
                      inflation, representing a hidden risk.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Inflation-adjusted return calculations are estimates based on entered values. Actual investment
                  outcomes may vary due to market conditions, inflation fluctuations, and fees. Historical inflation
                  rates do not guarantee future rates. This calculator is for educational purposes only and should not
                  be considered financial advice. Consult a qualified financial advisor for personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
