"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  GraduationCap,
  Info,
  Plus,
  Trash2,
  BookOpen,
  Award,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type GPAScale = "4.0" | "5.0" | "10.0"

interface Course {
  id: string
  name: string
  grade: string
  credits: string
}

interface GPAResult {
  gpa: number
  totalCredits: number
  totalPoints: number
  courses: {
    name: string
    grade: string
    credits: number
    points: number
    gradePoints: number
  }[]
  category: string
  color: string
  bgColor: string
}

const gradePoints: Record<GPAScale, Record<string, number>> = {
  "4.0": {
    "A+": 4.0,
    A: 4.0,
    "A-": 3.7,
    "B+": 3.3,
    B: 3.0,
    "B-": 2.7,
    "C+": 2.3,
    C: 2.0,
    "C-": 1.7,
    "D+": 1.3,
    D: 1.0,
    "D-": 0.7,
    F: 0.0,
  },
  "5.0": {
    "A+": 5.0,
    A: 5.0,
    "A-": 4.7,
    "B+": 4.3,
    B: 4.0,
    "B-": 3.7,
    "C+": 3.3,
    C: 3.0,
    "C-": 2.7,
    "D+": 2.3,
    D: 2.0,
    "D-": 1.7,
    F: 0.0,
  },
  "10.0": {
    "A+": 10.0,
    A: 9.5,
    "A-": 9.0,
    "B+": 8.5,
    B: 8.0,
    "B-": 7.5,
    "C+": 7.0,
    C: 6.5,
    "C-": 6.0,
    "D+": 5.5,
    D: 5.0,
    "D-": 4.5,
    F: 0.0,
  },
}

const gradeOptions = ["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F"]

export function GPACalculator() {
  const [scale, setScale] = useState<GPAScale>("4.0")
  const [courses, setCourses] = useState<Course[]>([
    { id: "1", name: "Course 1", grade: "A", credits: "3" },
    { id: "2", name: "Course 2", grade: "B+", credits: "3" },
    { id: "3", name: "Course 3", grade: "A-", credits: "4" },
  ])
  const [result, setResult] = useState<GPAResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const addCourse = () => {
    const newId = (Math.max(...courses.map((c) => Number.parseInt(c.id))) + 1).toString()
    setCourses([...courses, { id: newId, name: `Course ${newId}`, grade: "A", credits: "3" }])
  }

  const removeCourse = (id: string) => {
    if (courses.length > 1) {
      setCourses(courses.filter((c) => c.id !== id))
    }
  }

  const updateCourse = (id: string, field: keyof Course, value: string) => {
    setCourses(courses.map((c) => (c.id === id ? { ...c, [field]: value } : c)))
  }

  const calculateGPA = () => {
    setError("")
    setResult(null)

    // Validate courses
    const validCourses = courses.filter((c) => {
      const credits = Number.parseFloat(c.credits)
      return !isNaN(credits) && credits > 0 && c.grade in gradePoints[scale]
    })

    if (validCourses.length === 0) {
      setError("Please enter at least one valid course with positive credit hours")
      return
    }

    let totalPoints = 0
    let totalCredits = 0
    const courseResults: GPAResult["courses"] = []

    for (const course of validCourses) {
      const credits = Number.parseFloat(course.credits)
      const gradePoint = gradePoints[scale][course.grade]
      const points = gradePoint * credits

      totalPoints += points
      totalCredits += credits

      courseResults.push({
        name: course.name,
        grade: course.grade,
        credits,
        points,
        gradePoints: gradePoint,
      })
    }

    const gpa = totalCredits > 0 ? totalPoints / totalCredits : 0
    const roundedGPA = Math.round(gpa * 100) / 100

    // Determine category based on scale
    let category: string
    let color: string
    let bgColor: string

    const maxGPA = Number.parseFloat(scale)
    const percentage = (roundedGPA / maxGPA) * 100

    if (percentage >= 90) {
      category = "Excellent"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (percentage >= 80) {
      category = "Very Good"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (percentage >= 70) {
      category = "Good"
      color = "text-cyan-600"
      bgColor = "bg-cyan-50 border-cyan-200"
    } else if (percentage >= 60) {
      category = "Satisfactory"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (percentage >= 50) {
      category = "Pass"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Needs Improvement"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      gpa: roundedGPA,
      totalCredits,
      totalPoints: Math.round(totalPoints * 100) / 100,
      courses: courseResults,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setCourses([
      { id: "1", name: "Course 1", grade: "A", credits: "3" },
      { id: "2", name: "Course 2", grade: "B+", credits: "3" },
      { id: "3", name: "Course 3", grade: "A-", credits: "4" },
    ])
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`My GPA is ${result.gpa} on a ${scale} scale (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My GPA Result",
          text: `I calculated my GPA using CalcHub! My GPA is ${result.gpa} on a ${scale} scale (${result.category})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/education-learning">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Education & Learning
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                    <GraduationCap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">GPA Calculator</CardTitle>
                    <CardDescription>Calculate your Grade Point Average</CardDescription>
                  </div>
                </div>

                {/* Scale Selection */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">GPA Scale</span>
                  <div className="flex gap-1 p-1 bg-muted rounded-lg">
                    {(["4.0", "5.0", "10.0"] as GPAScale[]).map((s) => (
                      <button
                        key={s}
                        onClick={() => {
                          setScale(s)
                          setResult(null)
                        }}
                        className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                          scale === s
                            ? "bg-primary text-primary-foreground shadow-sm"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Course Inputs */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Courses</Label>
                    <Button variant="outline" size="sm" onClick={addCourse}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Course
                    </Button>
                  </div>

                  <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                    {courses.map((course, index) => (
                      <div key={course.id} className="flex gap-2 items-center p-3 bg-muted/50 rounded-lg">
                        <div className="flex-1 min-w-0">
                          <Input
                            placeholder="Course name"
                            value={course.name}
                            onChange={(e) => updateCourse(course.id, "name", e.target.value)}
                            className="bg-background text-sm"
                          />
                        </div>
                        <div className="w-20">
                          <select
                            value={course.grade}
                            onChange={(e) => updateCourse(course.id, "grade", e.target.value)}
                            className="w-full h-9 px-2 text-sm border rounded-md bg-background"
                          >
                            {gradeOptions.map((g) => (
                              <option key={g} value={g}>
                                {g}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="w-20">
                          <Input
                            type="number"
                            placeholder="Credits"
                            value={course.credits}
                            onChange={(e) => updateCourse(course.id, "credits", e.target.value)}
                            min="0"
                            step="0.5"
                            className="bg-background text-sm"
                          />
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeCourse(course.id)}
                          disabled={courses.length <= 1}
                          className="h-9 w-9 text-muted-foreground hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateGPA} className="w-full" size="lg">
                  Calculate GPA
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your GPA ({scale} scale)</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.gpa.toFixed(2)}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-current/10">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Total Credits</p>
                        <p className="text-lg font-semibold">{result.totalCredits}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Total Points</p>
                        <p className="text-lg font-semibold">{result.totalPoints}</p>
                      </div>
                    </div>

                    {/* Course Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3 text-muted-foreground">
                          {showBreakdown ? "Hide" : "Show"} Course Breakdown
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2">
                        {result.courses.map((course, index) => (
                          <div
                            key={index}
                            className="flex justify-between items-center p-2 bg-background/50 rounded text-sm"
                          >
                            <span className="font-medium truncate mr-2">{course.name}</span>
                            <span className="text-muted-foreground whitespace-nowrap">
                              {course.grade} × {course.credits} cr = {course.points.toFixed(2)} pts
                            </span>
                          </div>
                        ))}
                        <div className="p-2 bg-muted rounded text-sm font-mono text-center">
                          GPA = {result.totalPoints} ÷ {result.totalCredits} = {result.gpa.toFixed(2)}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Grade Points ({scale} Scale)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    {gradeOptions.slice(0, 8).map((grade) => (
                      <div key={grade} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <span className="font-medium">{grade}</span>
                        <span className="text-sm text-muted-foreground">{gradePoints[scale][grade]}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">GPA Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">GPA = Σ(Grade Points × Credits) ÷ Total Credits</p>
                  </div>
                  <div className="space-y-2 text-sm">
                    <p>
                      <strong>Step 1:</strong> Convert each letter grade to grade points
                    </p>
                    <p>
                      <strong>Step 2:</strong> Multiply grade points by credit hours for each course
                    </p>
                    <p>
                      <strong>Step 3:</strong> Sum all the products (total quality points)
                    </p>
                    <p>
                      <strong>Step 4:</strong> Divide by total credit hours
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is GPA?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Grade Point Average (GPA) is a standardized method of measuring academic achievement in the United
                  States and many other countries. It provides a numerical representation of a student's average
                  performance across all courses, weighted by credit hours. The GPA serves as a crucial metric for
                  college admissions, scholarship applications, graduate school acceptance, and employment
                  opportunities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The most common GPA scale is the 4.0 scale, where an A equals 4.0 points, a B equals 3.0 points, and
                  so on. However, some institutions use 5.0 or 10.0 scales, particularly for weighted GPAs that account
                  for honors or AP courses. Understanding your GPA and how it's calculated can help you set academic
                  goals and track your progress throughout your educational journey.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding GPA Scales</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                    <h4 className="font-semibold text-indigo-800 mb-2">4.0 Scale (Most Common)</h4>
                    <p className="text-indigo-700 text-sm">
                      The standard scale used by most US high schools and colleges. An A is worth 4.0 points, B is 3.0,
                      C is 2.0, D is 1.0, and F is 0. Plus and minus grades typically add or subtract 0.3 points.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">5.0 Scale (Weighted)</h4>
                    <p className="text-blue-700 text-sm">
                      Often used for weighted GPAs that give extra points for honors, AP, or IB courses. This scale
                      rewards students for taking more challenging coursework while maintaining high grades.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">10.0 Scale</h4>
                    <p className="text-cyan-700 text-sm">
                      Common in some international education systems, particularly in India and parts of Europe. This
                      scale provides more granularity in distinguishing between performance levels.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Improving Your GPA</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Focus on high-credit courses:</strong> Since GPA is weighted by credits, improving grades in
                    courses with more credits will have a larger impact.
                  </li>
                  <li>
                    <strong>Seek help early:</strong> Don't wait until the end of the semester. Use tutoring, office
                    hours, and study groups from the beginning.
                  </li>
                  <li>
                    <strong>Retake courses strategically:</strong> Many schools allow grade replacement if you retake a
                    course. Check your institution's policy.
                  </li>
                  <li>
                    <strong>Consider course load:</strong> Balance challenging courses with manageable ones each
                    semester to maintain consistent performance.
                  </li>
                  <li>
                    <strong>Stay organized:</strong> Use planners, calendars, and study schedules to manage assignments
                    and exam preparation effectively.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> GPA calculations may vary depending on institution grading policies and
                  scales. Some schools use different point values for plus/minus grades, weighted vs. unweighted
                  calculations, or alternative grading systems. Always verify your GPA calculation method with your
                  academic institution.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
