"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Calendar,
  Info,
  ChevronDown,
  ChevronUp,
  Heart,
  Moon,
  Sun,
  Flower2,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface CycleResult {
  nextPeriodDate: Date
  ovulationDate: Date
  fertileWindowStart: Date
  fertileWindowEnd: Date
  currentPhase: string
  phaseColor: string
  phaseBgColor: string
  daysUntilPeriod: number
  daysUntilOvulation: number
  cycleDay: number
}

interface PhaseInfo {
  name: string
  startDay: number
  endDay: number
  color: string
  bgColor: string
  icon: React.ReactNode
}

export function MenstrualCycleCalculator() {
  const [lastPeriodDate, setLastPeriodDate] = useState("")
  const [cycleLength, setCycleLength] = useState("28")
  const [periodDuration, setPeriodDuration] = useState("5")
  const [result, setResult] = useState<CycleResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateCycle = () => {
    setError("")
    setResult(null)

    if (!lastPeriodDate) {
      setError("Please enter the first day of your last period")
      return
    }

    const cycleLengthNum = Number.parseInt(cycleLength)
    const periodDurationNum = Number.parseInt(periodDuration)

    if (isNaN(cycleLengthNum) || cycleLengthNum < 21 || cycleLengthNum > 45) {
      setError("Please enter a valid cycle length between 21 and 45 days")
      return
    }

    if (isNaN(periodDurationNum) || periodDurationNum < 2 || periodDurationNum > 10) {
      setError("Please enter a valid period duration between 2 and 10 days")
      return
    }

    const lmpDate = new Date(lastPeriodDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    // Calculate next period date
    const nextPeriodDate = new Date(lmpDate)
    while (nextPeriodDate <= today) {
      nextPeriodDate.setDate(nextPeriodDate.getDate() + cycleLengthNum)
    }

    // Calculate ovulation day (typically 14 days before next period)
    const ovulationDate = new Date(nextPeriodDate)
    ovulationDate.setDate(ovulationDate.getDate() - 14)

    // Calculate fertile window (5 days before ovulation to 1 day after)
    const fertileWindowStart = new Date(ovulationDate)
    fertileWindowStart.setDate(fertileWindowStart.getDate() - 5)
    const fertileWindowEnd = new Date(ovulationDate)
    fertileWindowEnd.setDate(fertileWindowEnd.getDate() + 1)

    // Calculate current cycle day
    const currentCycleStart = new Date(nextPeriodDate)
    currentCycleStart.setDate(currentCycleStart.getDate() - cycleLengthNum)
    const cycleDay = Math.floor((today.getTime() - currentCycleStart.getTime()) / (1000 * 60 * 60 * 24)) + 1

    // Determine current phase
    let currentPhase: string
    let phaseColor: string
    let phaseBgColor: string

    if (cycleDay <= periodDurationNum) {
      currentPhase = "Menstrual Phase"
      phaseColor = "text-red-600"
      phaseBgColor = "bg-red-50 border-red-200"
    } else if (cycleDay <= cycleLengthNum - 14 - 5) {
      currentPhase = "Follicular Phase"
      phaseColor = "text-pink-600"
      phaseBgColor = "bg-pink-50 border-pink-200"
    } else if (cycleDay <= cycleLengthNum - 14 + 1) {
      currentPhase = "Ovulatory Phase"
      phaseColor = "text-green-600"
      phaseBgColor = "bg-green-50 border-green-200"
    } else {
      currentPhase = "Luteal Phase"
      phaseColor = "text-purple-600"
      phaseBgColor = "bg-purple-50 border-purple-200"
    }

    // Days until events
    const daysUntilPeriod = Math.ceil((nextPeriodDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    const daysUntilOvulation = Math.ceil((ovulationDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

    setResult({
      nextPeriodDate,
      ovulationDate,
      fertileWindowStart,
      fertileWindowEnd,
      currentPhase,
      phaseColor,
      phaseBgColor,
      daysUntilPeriod,
      daysUntilOvulation,
      cycleDay,
    })
  }

  const handleReset = () => {
    setLastPeriodDate("")
    setCycleLength("28")
    setPeriodDuration("5")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Menstrual Cycle Prediction:
Next Period: ${formatDate(result.nextPeriodDate)}
Ovulation Date: ${formatDate(result.ovulationDate)}
Fertile Window: ${formatDate(result.fertileWindowStart)} - ${formatDate(result.fertileWindowEnd)}
Current Phase: ${result.currentPhase} (Day ${result.cycleDay})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" })
  }

  const getPhases = (): PhaseInfo[] => {
    const cycleLengthNum = Number.parseInt(cycleLength) || 28
    const periodDurationNum = Number.parseInt(periodDuration) || 5
    const follicularEnd = cycleLengthNum - 14 - 5
    const ovulatoryEnd = cycleLengthNum - 14 + 1

    return [
      {
        name: "Menstrual",
        startDay: 1,
        endDay: periodDurationNum,
        color: "text-red-600",
        bgColor: "bg-red-100",
        icon: <Moon className="h-4 w-4" />,
      },
      {
        name: "Follicular",
        startDay: periodDurationNum + 1,
        endDay: follicularEnd,
        color: "text-pink-600",
        bgColor: "bg-pink-100",
        icon: <Flower2 className="h-4 w-4" />,
      },
      {
        name: "Ovulatory",
        startDay: follicularEnd + 1,
        endDay: ovulatoryEnd,
        color: "text-green-600",
        bgColor: "bg-green-100",
        icon: <Sun className="h-4 w-4" />,
      },
      {
        name: "Luteal",
        startDay: ovulatoryEnd + 1,
        endDay: cycleLengthNum,
        color: "text-purple-600",
        bgColor: "bg-purple-100",
        icon: <Heart className="h-4 w-4" />,
      },
    ]
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Menstrual Cycle Calculator</CardTitle>
                    <CardDescription>Track and predict your cycle phases</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Last Period Date */}
                <div className="space-y-2">
                  <Label htmlFor="lastPeriod">First Day of Last Period</Label>
                  <Input
                    id="lastPeriod"
                    type="date"
                    value={lastPeriodDate}
                    onChange={(e) => setLastPeriodDate(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                {/* Cycle Length */}
                <div className="space-y-2">
                  <Label htmlFor="cycleLength">Average Cycle Length (days)</Label>
                  <Input
                    id="cycleLength"
                    type="number"
                    placeholder="28"
                    value={cycleLength}
                    onChange={(e) => setCycleLength(e.target.value)}
                    min="21"
                    max="45"
                  />
                  <p className="text-xs text-muted-foreground">Typical range: 21-35 days</p>
                </div>

                {/* Period Duration */}
                <div className="space-y-2">
                  <Label htmlFor="periodDuration">Average Period Duration (days)</Label>
                  <Input
                    id="periodDuration"
                    type="number"
                    placeholder="5"
                    value={periodDuration}
                    onChange={(e) => setPeriodDuration(e.target.value)}
                    min="2"
                    max="10"
                  />
                  <p className="text-xs text-muted-foreground">Typical range: 3-7 days</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCycle} className="w-full" size="lg">
                  Calculate Cycle
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.phaseBgColor} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Current Phase</p>
                      <p className={`text-2xl font-bold ${result.phaseColor}`}>{result.currentPhase}</p>
                      <p className="text-sm text-muted-foreground mt-1">Day {result.cycleDay} of your cycle</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="text-center p-3 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Next Period</p>
                        <p className="font-semibold text-sm">{formatDate(result.nextPeriodDate)}</p>
                        <p className="text-xs text-pink-600">
                          {result.daysUntilPeriod === 0 ? "Today" : `In ${result.daysUntilPeriod} days`}
                        </p>
                      </div>
                      <div className="text-center p-3 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Ovulation</p>
                        <p className="font-semibold text-sm">{formatDate(result.ovulationDate)}</p>
                        <p className="text-xs text-green-600">
                          {result.daysUntilOvulation <= 0
                            ? "Passed"
                            : result.daysUntilOvulation === 0
                              ? "Today"
                              : `In ${result.daysUntilOvulation} days`}
                        </p>
                      </div>
                    </div>

                    <div className="p-3 bg-green-100 border border-green-200 rounded-lg mb-4">
                      <p className="text-xs text-green-700 font-medium text-center">Fertile Window</p>
                      <p className="text-sm text-green-800 text-center font-semibold">
                        {formatDate(result.fertileWindowStart)} - {formatDate(result.fertileWindowEnd)}
                      </p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showDetails ? "Hide" : "Show"} Cycle Phases
                    </button>

                    {showDetails && (
                      <div className="mt-4 space-y-2">
                        {getPhases().map((phase) => (
                          <div
                            key={phase.name}
                            className={`flex items-center justify-between p-2 rounded-lg ${phase.bgColor}`}
                          >
                            <div className="flex items-center gap-2">
                              <span className={phase.color}>{phase.icon}</span>
                              <span className={`text-sm font-medium ${phase.color}`}>{phase.name}</span>
                            </div>
                            <span className="text-xs text-muted-foreground">
                              Days {phase.startDay}-{phase.endDay}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cycle Phases</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <div className="flex items-center gap-2">
                        <Moon className="h-4 w-4 text-red-600" />
                        <span className="font-medium text-red-700">Menstrual</span>
                      </div>
                      <span className="text-sm text-red-600">Days 1-5</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-pink-50 border border-pink-200">
                      <div className="flex items-center gap-2">
                        <Flower2 className="h-4 w-4 text-pink-600" />
                        <span className="font-medium text-pink-700">Follicular</span>
                      </div>
                      <span className="text-sm text-pink-600">Days 6-9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex items-center gap-2">
                        <Sun className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-700">Ovulatory</span>
                      </div>
                      <span className="text-sm text-green-600">Days 10-15</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex items-center gap-2">
                        <Heart className="h-4 w-4 text-purple-600" />
                        <span className="font-medium text-purple-700">Luteal</span>
                      </div>
                      <span className="text-sm text-purple-600">Days 16-28</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Ovulation = Next Period - 14 days</p>
                    <p className="font-semibold text-foreground text-xs mt-1">Fertile Window = Ovulation ± 5 days</p>
                  </div>
                  <p>
                    The luteal phase (after ovulation) is typically 14 days. Fertile window spans 5 days before
                    ovulation through 1 day after.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Your Menstrual Cycle</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The menstrual cycle is a monthly process that prepares your body for pregnancy. It involves a complex
                  interplay of hormones that regulate the release of an egg from the ovary (ovulation) and prepare the
                  uterus for potential implantation. Understanding your cycle can help with family planning, identifying
                  potential health issues, and managing symptoms.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A typical menstrual cycle lasts 28 days, but cycles ranging from 21 to 35 days are considered normal.
                  The cycle is divided into four main phases: menstrual, follicular, ovulatory, and luteal. Each phase
                  is characterized by different hormonal changes and physical symptoms. Tracking your cycle can provide
                  valuable insights into your reproductive health.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>The Four Phases of Your Cycle</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="mt-4 space-y-4">
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Menstrual Phase (Days 1-5)</h4>
                    <p className="text-red-700 text-sm">
                      This phase begins on the first day of bleeding. The uterine lining sheds through the vagina,
                      resulting in menstrual flow. Hormone levels are at their lowest, which may cause fatigue and mood
                      changes. This phase typically lasts 3-7 days.
                    </p>
                  </div>
                  <div className="p-4 bg-pink-50 border border-pink-200 rounded-lg">
                    <h4 className="font-semibold text-pink-800 mb-2">Follicular Phase (Days 6-14)</h4>
                    <p className="text-pink-700 text-sm">
                      Overlapping with menstruation, this phase sees rising estrogen levels that stimulate the growth of
                      follicles in the ovaries. One follicle becomes dominant and prepares to release an egg. Energy
                      levels often increase during this time.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Ovulatory Phase (Days 14-16)</h4>
                    <p className="text-green-700 text-sm">
                      A surge in luteinizing hormone (LH) triggers the release of the mature egg from the ovary. This is
                      the most fertile time of the cycle. The egg survives for 12-24 hours, while sperm can survive up
                      to 5 days, creating a fertile window of about 6 days.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Luteal Phase (Days 17-28)</h4>
                    <p className="text-purple-700 text-sm">
                      After ovulation, the empty follicle transforms into the corpus luteum, producing progesterone to
                      prepare the uterus for potential pregnancy. If fertilization doesn't occur, hormone levels drop,
                      triggering the next menstrual period.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Cycle Tracking</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2 list-disc list-inside">
                  <li>Track your cycle for at least 3-6 months to identify patterns</li>
                  <li>Note physical symptoms like cramps, breast tenderness, or mood changes</li>
                  <li>Monitor cervical mucus changes throughout your cycle</li>
                  <li>Consider tracking basal body temperature for more precise ovulation detection</li>
                  <li>Record any irregular bleeding or unusual symptoms to discuss with your healthcare provider</li>
                  <li>Remember that stress, illness, and lifestyle changes can affect cycle regularity</li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Menstrual cycle predictions are estimates based on average patterns and
                  may vary due to individual cycle variations, stress, illness, or other factors. This calculator should
                  not be used as a sole method of contraception or fertility planning. Consult a healthcare professional
                  for personalized advice about your reproductive health.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
