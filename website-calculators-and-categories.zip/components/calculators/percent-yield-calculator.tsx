"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Beaker,
  Target,
  TrendingUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type MassUnit = "g" | "kg" | "mg"

interface Result {
  percentYield: number
  difference: number
  classification: string
  color: string
  bgColor: string
}

export function PercentYieldCalculator() {
  const [actualYield, setActualYield] = useState("")
  const [theoreticalYield, setTheoreticalYield] = useState("")
  const [unit, setUnit] = useState<MassUnit>("g")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  const unitLabels: Record<MassUnit, string> = {
    g: "grams (g)",
    kg: "kilograms (kg)",
    mg: "milligrams (mg)",
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const actual = Number.parseFloat(actualYield)
    const theoretical = Number.parseFloat(theoreticalYield)

    if (isNaN(actual) || actual < 0) {
      setError("Please enter a valid actual yield (non-negative number)")
      return
    }

    if (isNaN(theoretical) || theoretical <= 0) {
      setError("Theoretical yield must be greater than zero")
      return
    }

    const percentYield = (actual / theoretical) * 100
    const difference = theoretical - actual

    let classification: string
    let color: string
    let bgColor: string

    if (percentYield >= 90) {
      classification = "Excellent"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (percentYield >= 70) {
      classification = "Good"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (percentYield >= 50) {
      classification = "Moderate"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      classification = "Low"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      percentYield,
      difference,
      classification,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setActualYield("")
    setTheoreticalYield("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Percent Yield: ${result.percentYield.toFixed(2)}% (${result.classification})\nActual Yield: ${actualYield} ${unit}\nTheoretical Yield: ${theoreticalYield} ${unit}\nDifference: ${result.difference.toFixed(4)} ${unit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Target className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Percent Yield Calculator</CardTitle>
                    <CardDescription>Calculate reaction efficiency</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Unit Selection */}
                <div className="space-y-2">
                  <Label>Mass Unit</Label>
                  <Select value={unit} onValueChange={(v) => setUnit(v as MassUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="g">Grams (g)</SelectItem>
                      <SelectItem value="kg">Kilograms (kg)</SelectItem>
                      <SelectItem value="mg">Milligrams (mg)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Actual Yield Input */}
                <div className="space-y-2">
                  <Label htmlFor="actual">Actual Yield ({unit})</Label>
                  <Input
                    id="actual"
                    type="number"
                    placeholder="Enter actual yield from experiment"
                    value={actualYield}
                    onChange={(e) => setActualYield(e.target.value)}
                    min="0"
                    step="0.0001"
                  />
                  <p className="text-xs text-muted-foreground">
                    The amount of product actually obtained from the reaction
                  </p>
                </div>

                {/* Theoretical Yield Input */}
                <div className="space-y-2">
                  <Label htmlFor="theoretical">Theoretical Yield ({unit})</Label>
                  <Input
                    id="theoretical"
                    type="number"
                    placeholder="Enter theoretical yield"
                    value={theoreticalYield}
                    onChange={(e) => setTheoreticalYield(e.target.value)}
                    min="0"
                    step="0.0001"
                  />
                  <p className="text-xs text-muted-foreground">
                    The maximum amount of product predicted by stoichiometry
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Percent Yield
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Percent Yield</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.percentYield.toFixed(2)}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.classification}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 pt-4 border-t border-current/10 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Actual Yield:</span>
                        <span className="font-medium">
                          {Number.parseFloat(actualYield).toFixed(4)} {unit}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Theoretical Yield:</span>
                        <span className="font-medium">
                          {Number.parseFloat(theoreticalYield).toFixed(4)} {unit}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Difference (Loss):</span>
                        <span className="font-medium">
                          {result.difference > 0 ? result.difference.toFixed(4) : "0"} {unit}
                        </span>
                      </div>
                    </div>

                    {/* Warning for yield > 100% */}
                    {result.percentYield > 100 && (
                      <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-700 text-sm flex items-start gap-2">
                        <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                        <span>
                          Percent yield exceeds 100%. This may indicate experimental error, impurities, or incomplete
                          drying of the product.
                        </span>
                      </div>
                    )}

                    {/* Step-by-step solution */}
                    {showSteps && (
                      <div className="mt-4 pt-4 border-t border-current/10">
                        <button
                          onClick={() => setShowSteps(!showSteps)}
                          className="text-sm font-medium text-primary hover:underline mb-2"
                        >
                          Hide Steps
                        </button>
                        <div className="bg-white/50 rounded-lg p-3 text-sm space-y-2">
                          <p className="font-medium">Calculation:</p>
                          <p className="font-mono text-xs">Percent Yield = (Actual Yield / Theoretical Yield) × 100</p>
                          <p className="font-mono text-xs">
                            Percent Yield = ({actualYield} / {theoreticalYield}) × 100
                          </p>
                          <p className="font-mono text-xs">
                            Percent Yield ={" "}
                            {(Number.parseFloat(actualYield) / Number.parseFloat(theoreticalYield)).toFixed(6)} × 100
                          </p>
                          <p className="font-mono text-xs font-bold">
                            Percent Yield = {result.percentYield.toFixed(2)}%
                          </p>
                        </div>
                      </div>
                    )}

                    {!showSteps && (
                      <div className="mt-4 pt-4 border-t border-current/10">
                        <button
                          onClick={() => setShowSteps(true)}
                          className="text-sm font-medium text-primary hover:underline"
                        >
                          Show Steps
                        </button>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              {/* Efficiency Classification */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Efficiency Classification</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-sm text-green-600">≥ 90%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-sm text-blue-600">70 – 89%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate</span>
                      <span className="text-sm text-yellow-600">50 – 69%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Low</span>
                      <span className="text-sm text-red-600">{"< 50%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Formula Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Percent Yield Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-sm">
                      Percent Yield = (Actual Yield / Theoretical Yield) × 100
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    The percent yield measures how efficient a chemical reaction is by comparing the amount of product
                    actually obtained to the maximum amount predicted by stoichiometry.
                  </p>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Important Note</p>
                      <p>
                        Percent yield may exceed 100% due to experimental error, impurities in the product, incomplete
                        drying, or side reactions. Always verify your measurements and calculations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Percent Yield?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Percent yield is a measure of the efficiency of a chemical reaction. It compares the actual amount of
                  product obtained from a reaction to the theoretical (maximum possible) amount predicted by
                  stoichiometric calculations. This value is expressed as a percentage and is a critical metric in both
                  academic and industrial chemistry.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In an ideal world, every chemical reaction would convert 100% of reactants into products. However, in
                  practice, yields are almost always less than 100% due to various factors including incomplete
                  reactions, side reactions, loss during product isolation and purification, and measurement errors.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Actual vs Theoretical Yield</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4 mt-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Theoretical Yield</h4>
                    <p className="text-blue-700 text-sm">
                      The maximum amount of product that can be formed from the given amounts of reactants, calculated
                      using stoichiometry. It assumes the reaction goes to completion with no losses.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Actual Yield</h4>
                    <p className="text-green-700 text-sm">
                      The amount of product actually obtained from the experiment. This is always measured
                      experimentally and is typically less than the theoretical yield.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Percent Yield</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors can cause the actual yield to be less than the theoretical yield:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Incomplete reactions:</strong> Not all reactants may convert to products before the reaction
                    reaches equilibrium
                  </li>
                  <li>
                    <strong>Side reactions:</strong> Reactants may form unwanted byproducts instead of the desired
                    product
                  </li>
                  <li>
                    <strong>Loss during transfer:</strong> Product may be lost when transferring between containers or
                    during filtration
                  </li>
                  <li>
                    <strong>Purification losses:</strong> Some product is inevitably lost during purification processes
                    like recrystallization
                  </li>
                  <li>
                    <strong>Measurement errors:</strong> Inaccurate weighing or volume measurements affect the
                    calculated yield
                  </li>
                  <li>
                    <strong>Impure reactants:</strong> If starting materials contain impurities, less product will form
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">Percent yield is important in many contexts:</p>
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Academic Chemistry</h4>
                    <p className="text-sm text-muted-foreground">
                      Students calculate percent yield to evaluate their laboratory technique and identify sources of
                      error in experiments.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Industrial Chemistry</h4>
                    <p className="text-sm text-muted-foreground">
                      Manufacturing processes are optimized to maximize percent yield, reducing waste and increasing
                      profitability.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Pharmaceutical Industry</h4>
                    <p className="text-sm text-muted-foreground">
                      Drug synthesis routes are evaluated based on percent yield to ensure cost-effective production.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Research & Development</h4>
                    <p className="text-sm text-muted-foreground">
                      New reaction conditions and catalysts are tested by comparing percent yields.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
