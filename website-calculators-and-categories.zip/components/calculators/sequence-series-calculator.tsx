"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Hash, Info, Calculator, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

type SequenceType = "arithmetic" | "geometric"

interface SequenceResult {
  nthTerm: number
  sum: number | null
  infiniteSum: number | null
  sequenceList: number[]
  steps: string[]
}

export function SequenceSeriesCalculator() {
  const [sequenceType, setSequenceType] = useState<SequenceType>("arithmetic")
  const [firstTerm, setFirstTerm] = useState("")
  const [commonDiffOrRatio, setCommonDiffOrRatio] = useState("")
  const [termNumber, setTermNumber] = useState("")
  const [sumTerms, setSumTerms] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [showSequenceList, setShowSequenceList] = useState(false)
  const [result, setResult] = useState<SequenceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const a1 = Number.parseFloat(firstTerm)
    const dr = Number.parseFloat(commonDiffOrRatio)
    const n = Number.parseInt(termNumber)
    const sumN = sumTerms ? Number.parseInt(sumTerms) : n

    if (isNaN(a1)) {
      setError("Please enter a valid first term")
      return
    }

    if (isNaN(dr)) {
      setError(`Please enter a valid common ${sequenceType === "arithmetic" ? "difference" : "ratio"}`)
      return
    }

    if (isNaN(n) || n < 1) {
      setError("Please enter a valid term number (positive integer)")
      return
    }

    if (n > 1000) {
      setError("Term number must be 1000 or less")
      return
    }

    const steps: string[] = []
    let nthTerm: number
    let sum: number | null = null
    let infiniteSum: number | null = null
    const sequenceList: number[] = []

    if (sequenceType === "arithmetic") {
      // Arithmetic sequence: aₙ = a₁ + (n - 1) × d
      nthTerm = a1 + (n - 1) * dr

      steps.push(`Arithmetic Sequence Formula: aₙ = a₁ + (n − 1) × d`)
      steps.push(`Given: a₁ = ${a1}, d = ${dr}, n = ${n}`)
      steps.push(`aₙ = ${a1} + (${n} − 1) × ${dr}`)
      steps.push(`aₙ = ${a1} + ${n - 1} × ${dr}`)
      steps.push(`aₙ = ${a1} + ${(n - 1) * dr}`)
      steps.push(`aₙ = ${nthTerm}`)

      // Sum of n terms: Sₙ = n/2 × (2a₁ + (n - 1)d)
      if (sumN >= 1) {
        sum = (sumN / 2) * (2 * a1 + (sumN - 1) * dr)
        steps.push(``)
        steps.push(`Sum Formula: Sₙ = n/2 × (2a₁ + (n − 1)d)`)
        steps.push(`S${sumN} = ${sumN}/2 × (2 × ${a1} + (${sumN} − 1) × ${dr})`)
        steps.push(`S${sumN} = ${sumN / 2} × (${2 * a1} + ${(sumN - 1) * dr})`)
        steps.push(`S${sumN} = ${sumN / 2} × ${2 * a1 + (sumN - 1) * dr}`)
        steps.push(`S${sumN} = ${sum}`)
      }

      // Generate sequence list
      const listLength = Math.min(showSequenceList ? sumN : 10, 50)
      for (let i = 1; i <= listLength; i++) {
        sequenceList.push(a1 + (i - 1) * dr)
      }
    } else {
      // Geometric sequence: aₙ = a₁ × r^(n - 1)
      nthTerm = a1 * Math.pow(dr, n - 1)

      steps.push(`Geometric Sequence Formula: aₙ = a₁ × r^(n − 1)`)
      steps.push(`Given: a₁ = ${a1}, r = ${dr}, n = ${n}`)
      steps.push(`aₙ = ${a1} × ${dr}^(${n} − 1)`)
      steps.push(`aₙ = ${a1} × ${dr}^${n - 1}`)
      steps.push(`aₙ = ${a1} × ${Math.pow(dr, n - 1)}`)
      steps.push(`aₙ = ${nthTerm}`)

      // Sum of n terms: Sₙ = a₁ × (1 - r^n) / (1 - r) for r ≠ 1
      if (sumN >= 1) {
        if (dr === 1) {
          sum = a1 * sumN
          steps.push(``)
          steps.push(`Sum Formula (r = 1): Sₙ = a₁ × n`)
          steps.push(`S${sumN} = ${a1} × ${sumN}`)
          steps.push(`S${sumN} = ${sum}`)
        } else {
          sum = (a1 * (1 - Math.pow(dr, sumN))) / (1 - dr)
          steps.push(``)
          steps.push(`Sum Formula: Sₙ = a₁ × (1 − r^n) / (1 − r)`)
          steps.push(`S${sumN} = ${a1} × (1 − ${dr}^${sumN}) / (1 − ${dr})`)
          steps.push(`S${sumN} = ${a1} × (1 − ${Math.pow(dr, sumN)}) / ${1 - dr}`)
          steps.push(`S${sumN} = ${a1} × ${1 - Math.pow(dr, sumN)} / ${1 - dr}`)
          steps.push(`S${sumN} = ${sum}`)
        }
      }

      // Infinite sum for |r| < 1
      if (Math.abs(dr) < 1 && dr !== 0) {
        infiniteSum = a1 / (1 - dr)
        steps.push(``)
        steps.push(`Infinite Sum (|r| < 1): S∞ = a₁ / (1 − r)`)
        steps.push(`S∞ = ${a1} / (1 − ${dr})`)
        steps.push(`S∞ = ${a1} / ${1 - dr}`)
        steps.push(`S∞ = ${infiniteSum}`)
      }

      // Generate sequence list
      const listLength = Math.min(showSequenceList ? sumN : 10, 50)
      for (let i = 1; i <= listLength; i++) {
        sequenceList.push(a1 * Math.pow(dr, i - 1))
      }
    }

    setResult({ nthTerm, sum, infiniteSum, sequenceList, steps })
  }

  const handleReset = () => {
    setFirstTerm("")
    setCommonDiffOrRatio("")
    setTermNumber("")
    setSumTerms("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
    setShowDetails(false)
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) < 0.0001 || Math.abs(num) > 1e10) {
      return num.toExponential(6)
    }
    return Number.isInteger(num) ? num.toString() : num.toFixed(6).replace(/\.?0+$/, "")
  }

  const getResultText = (): string => {
    if (!result) return ""
    const parts = [`${termNumber}th term: ${formatNumber(result.nthTerm)}`]
    if (result.sum !== null) {
      parts.push(`Sum of ${sumTerms || termNumber} terms: ${formatNumber(result.sum)}`)
    }
    if (result.infiniteSum !== null) {
      parts.push(`Infinite sum: ${formatNumber(result.infiniteSum)}`)
    }
    return parts.join("\n")
  }

  const getLatexText = (): string => {
    if (!result) return ""
    const a1 = Number.parseFloat(firstTerm)
    const dr = Number.parseFloat(commonDiffOrRatio)
    const n = Number.parseInt(termNumber)

    if (sequenceType === "arithmetic") {
      return `a_{${n}} = ${a1} + (${n} - 1) \\times ${dr} = ${formatNumber(result.nthTerm)}`
    } else {
      return `a_{${n}} = ${a1} \\times ${dr}^{${n} - 1} = ${formatNumber(result.nthTerm)}`
    }
  }

  const handleCopy = async () => {
    await navigator.clipboard.writeText(getResultText())
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleCopyLatex = async () => {
    await navigator.clipboard.writeText(getLatexText())
    setCopiedLatex(true)
    setTimeout(() => setCopiedLatex(false), 2000)
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Sequence & Series Result",
          text: `I calculated a sequence using CalcHub!\n${getResultText()}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Hash className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Sequence & Series Calculator</CardTitle>
                    <CardDescription>Analyze arithmetic and geometric sequences</CardDescription>
                  </div>
                </div>

                {/* Sequence Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Sequence Type</span>
                  <button
                    onClick={() => {
                      setSequenceType(sequenceType === "arithmetic" ? "geometric" : "arithmetic")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        sequenceType === "geometric" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        sequenceType === "arithmetic" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Arithmetic
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        sequenceType === "geometric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Geometric
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* First Term */}
                <div className="space-y-2">
                  <Label htmlFor="firstTerm">First Term (a₁)</Label>
                  <Input
                    id="firstTerm"
                    type="number"
                    placeholder="Enter first term"
                    value={firstTerm}
                    onChange={(e) => setFirstTerm(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Common Difference or Ratio */}
                <div className="space-y-2">
                  <Label htmlFor="commonDiffOrRatio">
                    {sequenceType === "arithmetic" ? "Common Difference (d)" : "Common Ratio (r)"}
                  </Label>
                  <Input
                    id="commonDiffOrRatio"
                    type="number"
                    placeholder={`Enter common ${sequenceType === "arithmetic" ? "difference" : "ratio"}`}
                    value={commonDiffOrRatio}
                    onChange={(e) => setCommonDiffOrRatio(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Term Number */}
                <div className="space-y-2">
                  <Label htmlFor="termNumber">Term Number (n)</Label>
                  <Input
                    id="termNumber"
                    type="number"
                    placeholder="Which term to find?"
                    value={termNumber}
                    onChange={(e) => setTermNumber(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Sum Terms (optional) */}
                <div className="space-y-2">
                  <Label htmlFor="sumTerms">Terms to Sum (optional)</Label>
                  <Input
                    id="sumTerms"
                    type="number"
                    placeholder="Number of terms to sum (defaults to n)"
                    value={sumTerms}
                    onChange={(e) => setSumTerms(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Options */}
                <div className="flex flex-col gap-3 pt-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="showSteps" className="text-sm">
                      Show step-by-step solution
                    </Label>
                    <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="showSequenceList" className="text-sm">
                      Show sequence list
                    </Label>
                    <Switch id="showSequenceList" checked={showSequenceList} onCheckedChange={setShowSequenceList} />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">
                          {termNumber}
                          {termNumber === "1" ? "st" : termNumber === "2" ? "nd" : termNumber === "3" ? "rd" : "th"}{" "}
                          Term
                        </p>
                        <p className="text-4xl font-bold text-blue-600">{formatNumber(result.nthTerm)}</p>
                      </div>

                      {result.sum !== null && (
                        <div className="pt-2 border-t border-blue-200">
                          <p className="text-sm text-muted-foreground mb-1">Sum of {sumTerms || termNumber} terms</p>
                          <p className="text-2xl font-bold text-blue-600">{formatNumber(result.sum)}</p>
                        </div>
                      )}

                      {result.infiniteSum !== null && (
                        <div className="pt-2 border-t border-blue-200">
                          <p className="text-sm text-muted-foreground mb-1">Infinite Sum (S∞)</p>
                          <p className="text-2xl font-bold text-green-600">{formatNumber(result.infiniteSum)}</p>
                        </div>
                      )}
                    </div>

                    {/* Sequence List */}
                    {showSequenceList && result.sequenceList.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-blue-200">
                        <p className="text-sm font-medium text-blue-700 mb-2">
                          Sequence: {result.sequenceList.length > 50 ? "(first 50 terms)" : ""}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {result.sequenceList.map((term, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 text-xs bg-white rounded border border-blue-200 text-blue-700"
                            >
                              {formatNumber(term)}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Step-by-step details */}
                    {showSteps && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="flex items-center gap-2 text-sm font-medium text-blue-700 hover:text-blue-800"
                        >
                          {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          {showDetails ? "Hide" : "Show"} calculation steps
                        </button>

                        {showDetails && (
                          <div className="mt-3 p-3 bg-white rounded-lg border border-blue-100">
                            <div className="space-y-1 font-mono text-sm">
                              {result.steps.map((step, index) => (
                                <p key={index} className={step === "" ? "h-2" : "text-muted-foreground"}>
                                  {step}
                                </p>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <h4 className="font-semibold text-blue-700 mb-2">Arithmetic Sequence</h4>
                    <div className="space-y-1 text-sm text-blue-600 font-mono">
                      <p>aₙ = a₁ + (n − 1) × d</p>
                      <p>Sₙ = n/2 × (2a₁ + (n − 1)d)</p>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <h4 className="font-semibold text-green-700 mb-2">Geometric Sequence</h4>
                    <div className="space-y-1 text-sm text-green-600 font-mono">
                      <p>aₙ = a₁ × r^(n − 1)</p>
                      <p>Sₙ = a₁ × (1 − rⁿ) / (1 − r)</p>
                      <p>S∞ = a₁ / (1 − r), |r| {"<"} 1</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Variable Definitions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex justify-between">
                      <span className="font-mono">a₁</span>
                      <span>First term of the sequence</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">aₙ</span>
                      <span>n-th term of the sequence</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">d</span>
                      <span>Common difference (arithmetic)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">r</span>
                      <span>Common ratio (geometric)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">n</span>
                      <span>Term position / number of terms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">Sₙ</span>
                      <span>Sum of first n terms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-mono">S∞</span>
                      <span>Infinite sum (convergent geometric)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-medium text-foreground">Arithmetic: 2, 5, 8, 11, ...</p>
                      <p>a₁ = 2, d = 3</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-medium text-foreground">Geometric: 3, 6, 12, 24, ...</p>
                      <p>a₁ = 3, r = 2</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-medium text-foreground">Convergent: 1, 0.5, 0.25, ...</p>
                      <p>a₁ = 1, r = 0.5, S∞ = 2</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Sequences and Series?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A <strong>sequence</strong> is an ordered list of numbers that follows a specific pattern or rule.
                  Each number in the sequence is called a term. The two most common types are arithmetic sequences
                  (where each term differs from the previous by a constant amount) and geometric sequences (where each
                  term is multiplied by a constant factor from the previous term).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A <strong>series</strong> is the sum of the terms in a sequence. When we add up a finite number of
                  terms, we get a finite series. Some geometric series with a common ratio between -1 and 1 (exclusive)
                  can be summed infinitely, converging to a specific value called the infinite sum.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  1. Select the sequence type: <strong>Arithmetic</strong> (constant difference between terms) or{" "}
                  <strong>Geometric</strong> (constant ratio between terms).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-2">
                  2. Enter the first term (a₁) of your sequence.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-2">
                  3. Enter the common difference (d) for arithmetic or common ratio (r) for geometric sequences.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-2">
                  4. Enter the term number (n) to find the n-th term.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-2">
                  5. Optionally, specify how many terms to sum. Toggle step-by-step solutions and sequence list for
                  detailed output.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-medium mb-1">Disclaimer</p>
                    <p>
                      Sequence and series calculations follow standard mathematical formulas. Results depend on correct
                      input values and assumptions. For very large terms or ratios, numerical precision may be affected.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
