"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, AlertTriangle, Codesandbox } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "spring-constant" | "force" | "displacement"
type DisplacementUnit = "m" | "cm"

interface Result {
  springConstant: number
  force: number
  displacement: number
  displacementUnit: DisplacementUnit
  mode: CalculationMode
}

export function SpringConstantCalculator() {
  const [mode, setMode] = useState<CalculationMode>("spring-constant")
  const [force, setForce] = useState("")
  const [displacement, setDisplacement] = useState("")
  const [displacementUnit, setDisplacementUnit] = useState<DisplacementUnit>("m")
  const [springConstant, setSpringConstant] = useState("")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const convertToMeters = (value: number, unit: DisplacementUnit): number => {
    if (unit === "cm") return value / 100
    return value
  }

  const convertFromMeters = (value: number, unit: DisplacementUnit): number => {
    if (unit === "cm") return value * 100
    return value
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (mode === "spring-constant") {
      const forceNum = Number.parseFloat(force)
      const dispNum = Number.parseFloat(displacement)

      if (isNaN(forceNum) || forceNum < 0) {
        setError("Please enter a valid force value (≥ 0)")
        return
      }
      if (isNaN(dispNum) || dispNum <= 0) {
        setError("Displacement must be greater than 0 to calculate spring constant")
        return
      }

      const dispInMeters = convertToMeters(dispNum, displacementUnit)
      const k = forceNum / dispInMeters

      setResult({
        springConstant: k,
        force: forceNum,
        displacement: dispNum,
        displacementUnit,
        mode,
      })
    } else if (mode === "force") {
      const kNum = Number.parseFloat(springConstant)
      const dispNum = Number.parseFloat(displacement)

      if (isNaN(kNum) || kNum <= 0) {
        setError("Please enter a valid spring constant (> 0)")
        return
      }
      if (isNaN(dispNum) || dispNum < 0) {
        setError("Please enter a valid displacement value (≥ 0)")
        return
      }

      const dispInMeters = convertToMeters(dispNum, displacementUnit)
      const f = kNum * dispInMeters

      setResult({
        springConstant: kNum,
        force: f,
        displacement: dispNum,
        displacementUnit,
        mode,
      })
    } else if (mode === "displacement") {
      const forceNum = Number.parseFloat(force)
      const kNum = Number.parseFloat(springConstant)

      if (isNaN(forceNum) || forceNum < 0) {
        setError("Please enter a valid force value (≥ 0)")
        return
      }
      if (isNaN(kNum) || kNum <= 0) {
        setError("Spring constant must be greater than 0 to calculate displacement")
        return
      }

      const dispInMeters = forceNum / kNum
      const dispInUnit = convertFromMeters(dispInMeters, displacementUnit)

      setResult({
        springConstant: kNum,
        force: forceNum,
        displacement: dispInUnit,
        displacementUnit,
        mode,
      })
    }
  }

  const handleReset = () => {
    setForce("")
    setDisplacement("")
    setSpringConstant("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = ""
      if (result.mode === "spring-constant") {
        text = `Spring Constant: ${result.springConstant.toFixed(4)} N/m`
      } else if (result.mode === "force") {
        text = `Force: ${result.force.toFixed(4)} N`
      } else {
        text = `Displacement: ${result.displacement.toFixed(4)} ${result.displacementUnit}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        let text = ""
        if (result.mode === "spring-constant") {
          text = `Spring Constant: ${result.springConstant.toFixed(4)} N/m`
        } else if (result.mode === "force") {
          text = `Force: ${result.force.toFixed(4)} N`
        } else {
          text = `Displacement: ${result.displacement.toFixed(4)} ${result.displacementUnit}`
        }
        await navigator.share({
          title: "Spring Constant Calculator Result",
          text: `I calculated using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1e6 || (Math.abs(num) < 0.0001 && num !== 0)) {
      return num.toExponential(4)
    }
    return num.toFixed(4)
  }

  const getResultColor = () => {
    return "text-orange-600"
  }

  const getResultBgColor = () => {
    return "bg-orange-50 border-orange-200"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Codesandbox className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Spring Constant Calculator</CardTitle>
                    <CardDescription>Calculate using Hooke's Law (F = kx)</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Mode Selection */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select
                    value={mode}
                    onValueChange={(v) => {
                      setMode(v as CalculationMode)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="spring-constant">Spring Constant (k) from Force & Displacement</SelectItem>
                      <SelectItem value="force">Force (F) from Spring Constant & Displacement</SelectItem>
                      <SelectItem value="displacement">Displacement (x) from Force & Spring Constant</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Conditional Inputs based on mode */}
                {(mode === "spring-constant" || mode === "displacement") && (
                  <div className="space-y-2">
                    <Label htmlFor="force">Force (N)</Label>
                    <Input
                      id="force"
                      type="number"
                      placeholder="Enter force in Newtons"
                      value={force}
                      onChange={(e) => setForce(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {(mode === "spring-constant" || mode === "force") && (
                  <div className="space-y-2">
                    <Label>Displacement</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter displacement"
                        value={displacement}
                        onChange={(e) => setDisplacement(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select
                        value={displacementUnit}
                        onValueChange={(v) => setDisplacementUnit(v as DisplacementUnit)}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="m">m</SelectItem>
                          <SelectItem value="cm">cm</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {(mode === "force" || mode === "displacement") && (
                  <div className="space-y-2">
                    <Label htmlFor="springConstant">Spring Constant (N/m)</Label>
                    <Input
                      id="springConstant"
                      type="number"
                      placeholder="Enter spring constant"
                      value={springConstant}
                      onChange={(e) => setSpringConstant(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Displacement Unit for output (when calculating displacement) */}
                {mode === "displacement" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={displacementUnit} onValueChange={(v) => setDisplacementUnit(v as DisplacementUnit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="m">meters (m)</SelectItem>
                        <SelectItem value="cm">centimeters (cm)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getResultBgColor()} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.mode === "spring-constant" && "Spring Constant (k)"}
                        {result.mode === "force" && "Force (F)"}
                        {result.mode === "displacement" && "Displacement (x)"}
                      </p>
                      <p className={`text-4xl font-bold ${getResultColor()} mb-2`}>
                        {result.mode === "spring-constant" && `${formatNumber(result.springConstant)} N/m`}
                        {result.mode === "force" && `${formatNumber(result.force)} N`}
                        {result.mode === "displacement" &&
                          `${formatNumber(result.displacement)} ${result.displacementUnit}`}
                      </p>
                    </div>

                    {/* Toggle Steps */}
                    <div className="mt-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowSteps(!showSteps)}
                        className="w-full text-muted-foreground"
                      >
                        {showSteps ? "Hide Steps" : "Show Steps"}
                      </Button>

                      {showSteps && (
                        <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                          <p className="font-semibold">Hooke's Law: F = k × x</p>
                          {result.mode === "spring-constant" && (
                            <>
                              <p>Given:</p>
                              <p className="ml-4">Force (F) = {result.force} N</p>
                              <p className="ml-4">
                                Displacement (x) = {result.displacement} {result.displacementUnit} ={" "}
                                {convertToMeters(result.displacement, result.displacementUnit)} m
                              </p>
                              <p className="mt-2">Calculate k:</p>
                              <p className="ml-4">k = F ÷ x</p>
                              <p className="ml-4">
                                k = {result.force} ÷ {convertToMeters(result.displacement, result.displacementUnit)}
                              </p>
                              <p className="ml-4 font-semibold">k = {formatNumber(result.springConstant)} N/m</p>
                            </>
                          )}
                          {result.mode === "force" && (
                            <>
                              <p>Given:</p>
                              <p className="ml-4">Spring Constant (k) = {result.springConstant} N/m</p>
                              <p className="ml-4">
                                Displacement (x) = {result.displacement} {result.displacementUnit} ={" "}
                                {convertToMeters(result.displacement, result.displacementUnit)} m
                              </p>
                              <p className="mt-2">Calculate F:</p>
                              <p className="ml-4">F = k × x</p>
                              <p className="ml-4">
                                F = {result.springConstant} ×{" "}
                                {convertToMeters(result.displacement, result.displacementUnit)}
                              </p>
                              <p className="ml-4 font-semibold">F = {formatNumber(result.force)} N</p>
                            </>
                          )}
                          {result.mode === "displacement" && (
                            <>
                              <p>Given:</p>
                              <p className="ml-4">Force (F) = {result.force} N</p>
                              <p className="ml-4">Spring Constant (k) = {result.springConstant} N/m</p>
                              <p className="mt-2">Calculate x:</p>
                              <p className="ml-4">x = F ÷ k</p>
                              <p className="ml-4">
                                x = {result.force} ÷ {result.springConstant}
                              </p>
                              <p className="ml-4">x = {formatNumber(result.force / result.springConstant)} m</p>
                              {result.displacementUnit === "cm" && (
                                <p className="ml-4 font-semibold">x = {formatNumber(result.displacement)} cm</p>
                              )}
                            </>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Hooke's Law Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-lg text-foreground">F = k × x</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>F</strong> = Force applied (Newtons, N)
                    </p>
                    <p>
                      <strong>k</strong> = Spring constant (N/m)
                    </p>
                    <p>
                      <strong>x</strong> = Displacement from equilibrium (meters, m)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rearranged Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <p className="font-medium text-orange-800">Spring Constant</p>
                      <p className="font-mono text-orange-700">k = F ÷ x</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-800">Force</p>
                      <p className="font-mono text-blue-700">F = k × x</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-800">Displacement</p>
                      <p className="font-mono text-green-700">x = F ÷ k</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Visual Spring Diagram */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Spring Visualization</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-center p-4">
                    <svg viewBox="0 0 200 120" className="w-full max-w-xs">
                      {/* Wall */}
                      <rect x="0" y="20" width="10" height="80" fill="#64748b" />
                      <line x1="0" y1="20" x2="0" y2="100" stroke="#334155" strokeWidth="2" />

                      {/* Spring coils */}
                      <path
                        d="M10 60 L25 50 L35 70 L45 50 L55 70 L65 50 L75 70 L85 50 L95 70 L105 50 L115 70 L125 60"
                        fill="none"
                        stroke="#f97316"
                        strokeWidth="3"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />

                      {/* Mass block */}
                      <rect x="125" y="40" width="40" height="40" rx="4" fill="#3b82f6" />
                      <text x="145" y="65" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">
                        m
                      </text>

                      {/* Force arrow */}
                      <line x1="165" y1="60" x2="190" y2="60" stroke="#ef4444" strokeWidth="2" />
                      <polygon points="190,60 182,55 182,65" fill="#ef4444" />
                      <text x="177" y="50" textAnchor="middle" fill="#ef4444" fontSize="11" fontWeight="bold">
                        F
                      </text>

                      {/* Displacement indicator */}
                      <line x1="125" y1="95" x2="165" y2="95" stroke="#22c55e" strokeWidth="2" />
                      <line x1="125" y1="90" x2="125" y2="100" stroke="#22c55e" strokeWidth="2" />
                      <line x1="165" y1="90" x2="165" y2="100" stroke="#22c55e" strokeWidth="2" />
                      <text x="145" y="110" textAnchor="middle" fill="#22c55e" fontSize="11" fontWeight="bold">
                        x
                      </text>
                    </svg>
                  </div>
                  <p className="text-sm text-muted-foreground text-center mt-2">
                    When force F is applied, the spring stretches by displacement x
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are theoretical and assume ideal linear springs without damping or friction. Real
                        springs may exhibit non-linear behavior at extreme displacements.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Hooke's Law?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Hooke's Law is a fundamental principle in physics that describes the behavior of elastic materials,
                  particularly springs. Named after the 17th-century British physicist Robert Hooke, this law states
                  that the force needed to extend or compress a spring by a certain distance is directly proportional to
                  that distance. In mathematical terms, F = kx, where F is the restoring force exerted by the spring, k
                  is the spring constant (a measure of the spring's stiffness), and x is the displacement from the
                  equilibrium position.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This relationship holds true as long as the spring is not stretched or compressed beyond its elastic
                  limit. When materials are deformed beyond this limit, they undergo permanent deformation and no longer
                  follow Hooke's Law. The spring constant k is measured in Newtons per meter (N/m) and represents how
                  stiff or soft a spring is—a higher spring constant indicates a stiffer spring that requires more force
                  to stretch or compress by the same amount.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Codesandbox className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Spring Constant</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The spring constant (k) is a crucial property that characterizes the stiffness of a spring. It tells
                  you how much force is required to stretch or compress the spring by one meter. A spring with a high
                  spring constant is very stiff and resists deformation, while a spring with a low spring constant is
                  soft and easily deformed.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">High Spring Constant</h4>
                    <p className="text-blue-700 text-sm">
                      Car suspension springs, garage door springs, and industrial shock absorbers typically have high
                      spring constants (1,000-100,000 N/m) to support heavy loads.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Low Spring Constant</h4>
                    <p className="text-green-700 text-sm">
                      Pen springs, toy springs, and mattress springs have low spring constants (10-500 N/m) for
                      comfortable compression and easy movement.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Hooke's Law and spring mechanics are foundational concepts used in countless engineering applications
                  and everyday devices. Understanding spring behavior is essential for designing mechanical systems that
                  rely on elastic components.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Automotive Industry</p>
                    <p className="text-sm text-muted-foreground">
                      Vehicle suspension systems use springs to absorb road shocks and maintain ride comfort. Engineers
                      carefully select spring constants to balance handling and comfort.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Measuring Instruments</p>
                    <p className="text-sm text-muted-foreground">
                      Spring scales and force gauges use calibrated springs to measure weight and force. The known
                      spring constant allows accurate force measurements.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Mechanical Watches</p>
                    <p className="text-sm text-muted-foreground">
                      The mainspring in mechanical watches stores energy and releases it gradually to power the
                      movement. Hairsprings regulate the oscillation of the balance wheel.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Sports Equipment</p>
                    <p className="text-sm text-muted-foreground">
                      Trampolines, pogo sticks, and archery bows all rely on spring mechanics to store and release
                      energy for propulsion and performance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations of Hooke's Law</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While Hooke's Law is extremely useful, it has important limitations that engineers and scientists must
                  consider:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Elastic Limit:</strong> The law only applies within the elastic region of the material.
                    Beyond the elastic limit, permanent deformation occurs.
                  </li>
                  <li>
                    <strong>Linear Assumption:</strong> Real springs may exhibit non-linear behavior, especially at
                    extreme extensions or compressions.
                  </li>
                  <li>
                    <strong>Temperature Effects:</strong> Spring constants can change with temperature as material
                    properties vary.
                  </li>
                  <li>
                    <strong>Fatigue:</strong> Repeated loading and unloading can cause spring fatigue, gradually
                    changing the spring constant over time.
                  </li>
                  <li>
                    <strong>Damping:</strong> Real springs often have internal friction and damping that this ideal
                    model doesn't account for.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
