"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Cog, Info, Calculator, BookOpen } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type StrainInputMode = "decimal" | "percentage"

interface PoissonResult {
  value: number
  category: string
  color: string
  bgColor: string
  lateralStrainDecimal: number
  axialStrainDecimal: number
}

export function PoissonsRatioCalculator() {
  const [strainMode, setStrainMode] = useState<StrainInputMode>("decimal")
  const [lateralStrain, setLateralStrain] = useState("")
  const [axialStrain, setAxialStrain] = useState("")
  const [result, setResult] = useState<PoissonResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculatePoissonsRatio = () => {
    setError("")
    setResult(null)

    const lateralNum = Number.parseFloat(lateralStrain)
    const axialNum = Number.parseFloat(axialStrain)

    if (isNaN(lateralNum)) {
      setError("Please enter a valid lateral strain value")
      return
    }

    if (isNaN(axialNum) || axialNum === 0) {
      setError("Please enter a valid non-zero axial strain value")
      return
    }

    // Convert to decimal if in percentage mode
    const lateralDecimal = strainMode === "percentage" ? lateralNum / 100 : lateralNum
    const axialDecimal = strainMode === "percentage" ? axialNum / 100 : axialNum

    // Calculate Poisson's ratio: ν = -ε_lat / ε_axial
    const poissonsRatio = -lateralDecimal / axialDecimal
    const roundedRatio = Math.round(poissonsRatio * 1000) / 1000

    let category: string
    let color: string
    let bgColor: string

    if (roundedRatio < 0) {
      category = "Auxetic Material (Negative)"
      color = "text-purple-600"
      bgColor = "bg-purple-50 border-purple-200"
    } else if (roundedRatio < 0.2) {
      category = "Low (Cork-like)"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (roundedRatio < 0.35) {
      category = "Typical (Most Metals)"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (roundedRatio <= 0.5) {
      category = "High (Rubber-like)"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Physically Implausible"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      value: roundedRatio,
      category,
      color,
      bgColor,
      lateralStrainDecimal: lateralDecimal,
      axialStrainDecimal: axialDecimal,
    })
  }

  const handleReset = () => {
    setLateralStrain("")
    setAxialStrain("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Poisson's Ratio: ν = ${result.value} (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Poisson's Ratio Result",
          text: `I calculated the Poisson's ratio using CalcHub! ν = ${result.value} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleStrainMode = () => {
    setStrainMode((prev) => (prev === "decimal" ? "percentage" : "decimal"))
    setLateralStrain("")
    setAxialStrain("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Cog className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Poisson's Ratio Calculator</CardTitle>
                    <CardDescription>Calculate material deformation ratio</CardDescription>
                  </div>
                </div>

                {/* Strain Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Strain Input</span>
                  <button
                    onClick={toggleStrainMode}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        strainMode === "percentage" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        strainMode === "decimal" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Decimal
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        strainMode === "percentage" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Percent
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Lateral Strain Input */}
                <div className="space-y-2">
                  <Label htmlFor="lateralStrain">Lateral Strain (ε_lat) {strainMode === "percentage" ? "%" : ""}</Label>
                  <Input
                    id="lateralStrain"
                    type="number"
                    placeholder={`Enter lateral strain ${strainMode === "percentage" ? "in %" : "as decimal"}`}
                    value={lateralStrain}
                    onChange={(e) => setLateralStrain(e.target.value)}
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">
                    Negative for contraction (typical), positive for expansion
                  </p>
                </div>

                {/* Axial Strain Input */}
                <div className="space-y-2">
                  <Label htmlFor="axialStrain">Axial Strain (ε_axial) {strainMode === "percentage" ? "%" : ""}</Label>
                  <Input
                    id="axialStrain"
                    type="number"
                    placeholder={`Enter axial strain ${strainMode === "percentage" ? "in %" : "as decimal"}`}
                    value={axialStrain}
                    onChange={(e) => setAxialStrain(e.target.value)}
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">
                    Positive for tension (elongation), negative for compression
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePoissonsRatio} className="w-full" size="lg">
                  Calculate Poisson's Ratio
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Poisson's Ratio (ν)</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.value}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Step-by-step toggle */}
                    <div className="mt-4">
                      <Button variant="outline" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full">
                        <Calculator className="h-4 w-4 mr-1" />
                        {showSteps ? "Hide" : "Show"} Calculation Steps
                      </Button>

                      {showSteps && (
                        <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                          <p>
                            <strong>Formula:</strong> ν = −ε_lat / ε_axial
                          </p>
                          <p>
                            <strong>Lateral Strain:</strong> {result.lateralStrainDecimal.toExponential(4)}
                          </p>
                          <p>
                            <strong>Axial Strain:</strong> {result.axialStrainDecimal.toExponential(4)}
                          </p>
                          <p>
                            <strong>Calculation:</strong> ν = −({result.lateralStrainDecimal.toExponential(4)}) / (
                            {result.axialStrainDecimal.toExponential(4)})
                          </p>
                          <p>
                            <strong>Result:</strong> ν = {result.value}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Poisson's Ratio Ranges</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Auxetic</span>
                      <span className="text-sm text-purple-600">{"< 0"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Low (Cork-like)</span>
                      <span className="text-sm text-blue-600">0 – 0.2</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Typical (Metals)</span>
                      <span className="text-sm text-green-600">0.2 – 0.35</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">High (Rubber-like)</span>
                      <span className="text-sm text-yellow-600">0.35 – 0.5</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Material Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Cork</span>
                      <span className="font-mono">≈ 0.0</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Concrete</span>
                      <span className="font-mono">0.1 – 0.2</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Steel</span>
                      <span className="font-mono">≈ 0.30</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Aluminum</span>
                      <span className="font-mono">≈ 0.33</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Copper</span>
                      <span className="font-mono">≈ 0.34</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Rubber</span>
                      <span className="font-mono">≈ 0.50</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ν = −ε_lat / ε_axial</p>
                  </div>
                  <p>
                    Where <strong>ε_lat</strong> is lateral strain and <strong>ε_axial</strong> is axial strain.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Poisson's Ratio?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Poisson's ratio (ν) is a fundamental material property that describes the relationship between lateral
                  (transverse) strain and axial (longitudinal) strain when a material is subjected to uniaxial stress.
                  Named after French mathematician Siméon Denis Poisson, this dimensionless quantity is essential in
                  understanding how materials deform under load.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When you stretch a rubber band, you'll notice it gets thinner in the middle as it elongates. This
                  phenomenon—where elongation in one direction causes contraction in perpendicular directions—is
                  characterized by Poisson's ratio. For most materials, this ratio falls between 0 and 0.5, though some
                  exotic "auxetic" materials exhibit negative values, expanding laterally when stretched.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>Engineering Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Poisson's ratio is crucial in structural engineering, materials science, and mechanical design.
                  Engineers use it to predict how structures will deform under load, design pressure vessels, analyze
                  thermal expansion, and calculate stress distributions in complex geometries using finite element
                  analysis (FEA).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The ratio also relates to other elastic constants through equations like E = 2G(1 + ν), where E is
                  Young's modulus and G is shear modulus. For incompressible materials like rubber (ν ≈ 0.5), volume
                  remains nearly constant during deformation. Understanding these relationships is vital for selecting
                  appropriate materials in engineering applications.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Poisson's ratio calculations are based on ideal material behavior. Actual
                  values may vary due to anisotropy, temperature, and material imperfections. Consult material
                  datasheets for precise values.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
