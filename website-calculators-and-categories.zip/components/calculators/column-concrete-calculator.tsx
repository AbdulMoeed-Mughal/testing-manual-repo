"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Columns, Info, Box } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type ColumnShape = "rectangular" | "circular"
type Unit = "m" | "ft"
type MixGrade = "M10" | "M15" | "M20" | "M25" | "custom"

interface ColumnResult {
  wetVolume: number
  dryVolume: number
  cement: number
  cementWeight: number
  sand: number
  aggregate: number
  unit: string
}

const mixRatios: Record<MixGrade, { ratio: string; cement: number; sand: number; aggregate: number }> = {
  M10: { ratio: "1:3:6", cement: 1, sand: 3, aggregate: 6 },
  M15: { ratio: "1:2:4", cement: 1, sand: 2, aggregate: 4 },
  M20: { ratio: "1:1.5:3", cement: 1, sand: 1.5, aggregate: 3 },
  M25: { ratio: "1:1:2", cement: 1, sand: 1, aggregate: 2 },
  custom: { ratio: "1:1.5:3", cement: 1, sand: 1.5, aggregate: 3 },
}

export function ColumnConcreteCalculator() {
  const [shape, setShape] = useState<ColumnShape>("rectangular")
  const [unit, setUnit] = useState<Unit>("m")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [diameter, setDiameter] = useState("")
  const [height, setHeight] = useState("")
  const [numberOfColumns, setNumberOfColumns] = useState("1")
  const [mixGrade, setMixGrade] = useState<MixGrade>("M20")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<ColumnResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateColumn = () => {
    setError("")
    setResult(null)

    const heightNum = Number.parseFloat(height)
    const numColumns = Number.parseFloat(numberOfColumns)
    const dryFactor = Number.parseFloat(dryVolumeFactor)
    const wastagePercent = Number.parseFloat(wastage)

    if (isNaN(heightNum) || heightNum <= 0) {
      setError("Please enter a valid height greater than 0")
      return
    }

    if (isNaN(numColumns) || numColumns < 1) {
      setError("Number of columns must be at least 1")
      return
    }

    if (isNaN(dryFactor) || dryFactor <= 0) {
      setError("Dry volume factor must be greater than 0")
      return
    }

    if (isNaN(wastagePercent) || wastagePercent < 0) {
      setError("Wastage percentage must be 0 or greater")
      return
    }

    let wetVolume = 0

    if (shape === "rectangular") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)

      if (isNaN(lengthNum) || lengthNum <= 0) {
        setError("Please enter a valid length greater than 0")
        return
      }

      if (isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter a valid width greater than 0")
        return
      }

      wetVolume = lengthNum * widthNum * heightNum * numColumns
    } else {
      const diameterNum = Number.parseFloat(diameter)

      if (isNaN(diameterNum) || diameterNum <= 0) {
        setError("Please enter a valid diameter greater than 0")
        return
      }

      const radius = diameterNum / 2
      wetVolume = Math.PI * radius * radius * heightNum * numColumns
    }

    // Add wastage
    wetVolume = wetVolume * (1 + wastagePercent / 100)

    const dryVolume = wetVolume * dryFactor

    // Calculate materials based on mix ratio
    const mix = mixRatios[mixGrade]
    const totalParts = mix.cement + mix.sand + mix.aggregate

    const cementVolume = (dryVolume * mix.cement) / totalParts
    const sandVolume = (dryVolume * mix.sand) / totalParts
    const aggregateVolume = (dryVolume * mix.aggregate) / totalParts

    // Convert cement volume to bags (1 bag = 0.035 m³ or 1.25 ft³)
    const cementBagVolume = unit === "m" ? 0.035 : 1.25
    const cementBags = Math.ceil(cementVolume / cementBagVolume)
    const cementWeight = cementBags * 50 // 50kg per bag

    setResult({
      wetVolume: Math.round(wetVolume * 1000) / 1000,
      dryVolume: Math.round(dryVolume * 1000) / 1000,
      cement: cementBags,
      cementWeight,
      sand: Math.round(sandVolume * 1000) / 1000,
      aggregate: Math.round(aggregateVolume * 1000) / 1000,
      unit: unit === "m" ? "m³" : "ft³",
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setDiameter("")
    setHeight("")
    setNumberOfColumns("1")
    setMixGrade("M20")
    setDryVolumeFactor("1.54")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Column Concrete: Wet Volume: ${result.wetVolume} ${result.unit}, Cement: ${result.cement} bags (${result.cementWeight}kg), Sand: ${result.sand} ${result.unit}, Aggregate: ${result.aggregate} ${result.unit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Column Concrete Calculator Result",
          text: `I calculated concrete requirements for columns using CalcHub! Wet Volume: ${result.wetVolume} ${result.unit}, Cement: ${result.cement} bags`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Columns className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Column Concrete Calculator</CardTitle>
                    <CardDescription>Calculate RCC column concrete requirements</CardDescription>
                  </div>
                </div>

                {/* Shape Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Column Shape</span>
                  <button
                    onClick={() => {
                      setShape((prev) => (prev === "rectangular" ? "circular" : "rectangular"))
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        shape === "circular" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        shape === "rectangular" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Rectangular
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        shape === "circular" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Circular
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="unit">Unit</Label>
                  <Select
                    value={unit}
                    onValueChange={(value: Unit) => {
                      setUnit(value)
                      setResult(null)
                    }}
                  >
                    <SelectTrigger id="unit">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="m">Meters (m)</SelectItem>
                      <SelectItem value="ft">Feet (ft)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dimension Inputs */}
                {shape === "rectangular" ? (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="length">Length ({unit})</Label>
                        <Input
                          id="length"
                          type="number"
                          placeholder="Enter length"
                          value={length}
                          onChange={(e) => setLength(e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="width">Width ({unit})</Label>
                        <Input
                          id="width"
                          type="number"
                          placeholder="Enter width"
                          value={width}
                          onChange={(e) => setWidth(e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="diameter">Diameter ({unit})</Label>
                    <Input
                      id="diameter"
                      type="number"
                      placeholder="Enter diameter"
                      value={diameter}
                      onChange={(e) => setDiameter(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="height">Height ({unit})</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="Enter height"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="numberOfColumns">Number of Columns</Label>
                  <Input
                    id="numberOfColumns"
                    type="number"
                    placeholder="Enter number"
                    value={numberOfColumns}
                    onChange={(e) => setNumberOfColumns(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Mix Grade */}
                <div className="space-y-2">
                  <Label htmlFor="mixGrade">Concrete Grade</Label>
                  <Select
                    value={mixGrade}
                    onValueChange={(value: MixGrade) => {
                      setMixGrade(value)
                      setResult(null)
                    }}
                  >
                    <SelectTrigger id="mixGrade">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M10">M10 (1:3:6)</SelectItem>
                      <SelectItem value="M15">M15 (1:2:4)</SelectItem>
                      <SelectItem value="M20">M20 (1:1.5:3)</SelectItem>
                      <SelectItem value="M25">M25 (1:1:2)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="dryVolumeFactor">Dry Volume Factor</Label>
                    <Input
                      id="dryVolumeFactor"
                      type="number"
                      placeholder="1.54"
                      value={dryVolumeFactor}
                      onChange={(e) => setDryVolumeFactor(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wastage">Wastage (%)</Label>
                    <Input
                      id="wastage"
                      type="number"
                      placeholder="5"
                      value={wastage}
                      onChange={(e) => setWastage(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateColumn} className="w-full" size="lg">
                  Calculate Concrete
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Wet Volume</p>
                        <p className="text-3xl font-bold text-amber-600">
                          {result.wetVolume} {result.unit}
                        </p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Dry Volume:</span>
                          <span className="font-semibold text-amber-700">
                            {result.dryVolume} {result.unit}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Cement:</span>
                          <span className="font-semibold text-amber-700">
                            {result.cement} bags ({result.cementWeight} kg)
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Sand:</span>
                          <span className="font-semibold text-amber-700">
                            {result.sand} {result.unit}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Aggregate:</span>
                          <span className="font-semibold text-amber-700">
                            {result.aggregate} {result.unit}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Column Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-800">Residential</p>
                      <p className="text-sm text-amber-600">230mm × 230mm to 300mm × 300mm</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-800">Commercial</p>
                      <p className="text-sm text-amber-600">300mm × 450mm to 400mm × 600mm</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-800">Circular</p>
                      <p className="text-sm text-amber-600">Diameter: 230mm to 500mm</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Concrete Grades</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong className="text-foreground">M10 (1:3:6):</strong> Non-structural work
                  </p>
                  <p>
                    <strong className="text-foreground">M15 (1:2:4):</strong> Light structures
                  </p>
                  <p>
                    <strong className="text-foreground">M20 (1:1.5:3):</strong> Standard residential columns
                  </p>
                  <p>
                    <strong className="text-foreground">M25 (1:1:2):</strong> Commercial structures
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Column Concrete */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-amber-600" />
                  <CardTitle>What is RCC Column Concrete?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Reinforced Cement Concrete (RCC) columns are vertical structural members that transfer loads from beams
                  and slabs to the foundation. Columns are one of the most critical elements in a building's structural
                  system, designed to bear compressive loads while providing stability and support to the entire
                  structure. The concrete used in columns must be of high quality and properly mixed to ensure structural
                  integrity and longevity.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Columns can be rectangular, square, or circular in cross-section, with the shape chosen based on
                  architectural requirements, load-bearing capacity, and aesthetic considerations. Rectangular columns are
                  most common in residential construction, while circular columns are often used in commercial buildings
                  for their superior load-bearing characteristics and elegant appearance. The concrete quantity required
                  depends on the column dimensions, number of columns, and the selected concrete grade.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Box className="h-5 w-5 text-amber-600" />
                  <CardTitle>How to Calculate Column Concrete</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating concrete for columns involves determining the wet volume based on the column shape and
                  dimensions. For rectangular columns, the formula is: Volume = Length × Width × Height × Number of
                  Columns. For circular columns, use: Volume = π × (Diameter/2)² × Height × Number of Columns. This gives
                  you the wet concrete volume needed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To account for voids and compaction during mixing, the wet volume is multiplied by a dry volume factor
                  (typically 1.54) to get the dry volume. The material quantities are then calculated based on the
                  selected concrete grade mix ratio. For example, M20 concrete (1:1.5:3) means 1 part cement, 1.5 parts
                  sand, and 3 parts aggregate. A wastage percentage (usually 5%) is added to account for spillage and
                  handling losses during construction.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Note:</strong> Column concrete calculations assume ideal geometry. Reinforcement volume is not
                  deducted unless specified. For critical structural calculations, always consult with a qualified
                  structural engineer. Material quantities may vary based on site conditions, mixing methods, and
                  construction practices.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
