"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Cable, Gauge } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type LengthUnit = "meters" | "feet"
type WireSizeUnit = "awg" | "mm2"
type ConductorMaterial = "copper" | "aluminum"
type CircuitType = "single-phase" | "three-phase"

interface VoltageDropResult {
  voltageDrop: number
  finalVoltage: number
  dropPercentage: number
  status: "acceptable" | "caution" | "excessive"
  wireResistance: number
}

// AWG to mm² conversion and cross-sectional areas
const awgSizes = [
  { awg: "14", mm2: 2.08, label: "14 AWG (2.08 mm²)" },
  { awg: "12", mm2: 3.31, label: "12 AWG (3.31 mm²)" },
  { awg: "10", mm2: 5.26, label: "10 AWG (5.26 mm²)" },
  { awg: "8", mm2: 8.37, label: "8 AWG (8.37 mm²)" },
  { awg: "6", mm2: 13.3, label: "6 AWG (13.3 mm²)" },
  { awg: "4", mm2: 21.2, label: "4 AWG (21.2 mm²)" },
  { awg: "2", mm2: 33.6, label: "2 AWG (33.6 mm²)" },
  { awg: "1", mm2: 42.4, label: "1 AWG (42.4 mm²)" },
  { awg: "1/0", mm2: 53.5, label: "1/0 AWG (53.5 mm²)" },
  { awg: "2/0", mm2: 67.4, label: "2/0 AWG (67.4 mm²)" },
  { awg: "3/0", mm2: 85.0, label: "3/0 AWG (85.0 mm²)" },
  { awg: "4/0", mm2: 107.2, label: "4/0 AWG (107.2 mm²)" },
]

const mm2Sizes = [
  { mm2: 1.5, label: "1.5 mm²" },
  { mm2: 2.5, label: "2.5 mm²" },
  { mm2: 4, label: "4 mm²" },
  { mm2: 6, label: "6 mm²" },
  { mm2: 10, label: "10 mm²" },
  { mm2: 16, label: "16 mm²" },
  { mm2: 25, label: "25 mm²" },
  { mm2: 35, label: "35 mm²" },
  { mm2: 50, label: "50 mm²" },
  { mm2: 70, label: "70 mm²" },
  { mm2: 95, label: "95 mm²" },
  { mm2: 120, label: "120 mm²" },
]

// Electrical resistivity in Ω·m
const resistivity = {
  copper: 1.68e-8,
  aluminum: 2.82e-8,
}

export function VoltageDropCalculator() {
  const [supplyVoltage, setSupplyVoltage] = useState("")
  const [loadCurrent, setLoadCurrent] = useState("")
  const [cableLength, setCableLength] = useState("")
  const [lengthUnit, setLengthUnit] = useState<LengthUnit>("meters")
  const [wireSizeUnit, setWireSizeUnit] = useState<WireSizeUnit>("awg")
  const [wireSize, setWireSize] = useState("")
  const [conductor, setConductor] = useState<ConductorMaterial>("copper")
  const [circuitType, setCircuitType] = useState<CircuitType>("single-phase")
  const [result, setResult] = useState<VoltageDropResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateVoltageDrop = () => {
    setError("")
    setResult(null)

    const voltage = Number.parseFloat(supplyVoltage)
    const current = Number.parseFloat(loadCurrent)
    const length = Number.parseFloat(cableLength)

    if (isNaN(voltage) || voltage <= 0) {
      setError("Please enter a valid supply voltage greater than 0")
      return
    }
    if (isNaN(current) || current <= 0) {
      setError("Please enter a valid load current greater than 0")
      return
    }
    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid cable length greater than 0")
      return
    }
    if (!wireSize) {
      setError("Please select a wire size")
      return
    }

    // Convert length to meters
    const lengthInMeters = lengthUnit === "feet" ? length * 0.3048 : length

    // Get cross-sectional area in mm²
    let crossSectionMm2: number
    if (wireSizeUnit === "awg") {
      const awgData = awgSizes.find((s) => s.awg === wireSize)
      crossSectionMm2 = awgData?.mm2 || 0
    } else {
      crossSectionMm2 = Number.parseFloat(wireSize)
    }

    if (crossSectionMm2 <= 0) {
      setError("Invalid wire size selected")
      return
    }

    // Convert mm² to m²
    const crossSectionM2 = crossSectionMm2 * 1e-6

    // Calculate wire resistance
    // R = (ρ × L) / A, but we need to account for round-trip (×2) for single-phase/DC
    // or √3 factor for three-phase
    const rho = resistivity[conductor]
    let wireResistance: number

    if (circuitType === "single-phase") {
      // Round-trip: 2 × length
      wireResistance = (rho * 2 * lengthInMeters) / crossSectionM2
    } else {
      // Three-phase: √3 × length
      wireResistance = (rho * Math.sqrt(3) * lengthInMeters) / crossSectionM2
    }

    // Calculate voltage drop: Vd = I × R
    const voltageDrop = current * wireResistance

    // Calculate final voltage at load
    const finalVoltage = voltage - voltageDrop

    // Calculate percentage drop
    const dropPercentage = (voltageDrop / voltage) * 100

    // Determine status
    let status: "acceptable" | "caution" | "excessive"
    if (dropPercentage < 3) {
      status = "acceptable"
    } else if (dropPercentage <= 5) {
      status = "caution"
    } else {
      status = "excessive"
    }

    setResult({
      voltageDrop,
      finalVoltage,
      dropPercentage,
      status,
      wireResistance,
    })
  }

  const handleReset = () => {
    setSupplyVoltage("")
    setLoadCurrent("")
    setCableLength("")
    setWireSize("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Voltage Drop: ${result.voltageDrop.toFixed(2)}V (${result.dropPercentage.toFixed(2)}%), Final Voltage: ${result.finalVoltage.toFixed(2)}V - ${result.status.charAt(0).toUpperCase() + result.status.slice(1)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Voltage Drop Calculation",
          text: `Voltage Drop: ${result.voltageDrop.toFixed(2)}V (${result.dropPercentage.toFixed(2)}%), Final Voltage: ${result.finalVoltage.toFixed(2)}V`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "acceptable":
        return { text: "text-green-600", bg: "bg-green-50 border-green-200" }
      case "caution":
        return { text: "text-yellow-600", bg: "bg-yellow-50 border-yellow-200" }
      case "excessive":
        return { text: "text-red-600", bg: "bg-red-50 border-red-200" }
      default:
        return { text: "text-gray-600", bg: "bg-gray-50 border-gray-200" }
    }
  }

  const getSuggestedWireSize = () => {
    if (!result || result.status === "acceptable") return null

    const voltage = Number.parseFloat(supplyVoltage)
    const current = Number.parseFloat(loadCurrent)
    const length = Number.parseFloat(cableLength)
    const lengthInMeters = lengthUnit === "feet" ? length * 0.3048 : length
    const rho = resistivity[conductor]

    // Target 2.5% drop for safety margin
    const targetDrop = voltage * 0.025
    const maxResistance = targetDrop / current

    // Calculate required cross-section
    const multiplier = circuitType === "single-phase" ? 2 : Math.sqrt(3)
    const requiredArea = (rho * multiplier * lengthInMeters) / maxResistance
    const requiredMm2 = requiredArea * 1e6

    // Find next size up
    const sizes = wireSizeUnit === "awg" ? awgSizes : mm2Sizes
    const suggested = sizes.find((s) => {
      const mm2 = "mm2" in s ? s.mm2 : Number.parseFloat(s.label)
      return mm2 >= requiredMm2
    })

    return suggested ? ("label" in suggested ? suggested.label : `${suggested.mm2} mm²`) : "Consider larger wire"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Cable className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Voltage Drop Calculator</CardTitle>
                    <CardDescription>Calculate voltage loss in electrical circuits</CardDescription>
                  </div>
                </div>

                {/* Unit Toggles */}
                <div className="flex flex-wrap gap-4 pt-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Length:</span>
                    <button
                      onClick={() => setLengthUnit(lengthUnit === "meters" ? "feet" : "meters")}
                      className="relative inline-flex h-8 w-28 items-center rounded-full bg-muted p-1 transition-colors"
                    >
                      <span
                        className={`absolute h-6 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                          lengthUnit === "feet" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                        }`}
                      />
                      <span
                        className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                          lengthUnit === "meters" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        Meters
                      </span>
                      <span
                        className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                          lengthUnit === "feet" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        Feet
                      </span>
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Wire:</span>
                    <button
                      onClick={() => {
                        setWireSizeUnit(wireSizeUnit === "awg" ? "mm2" : "awg")
                        setWireSize("")
                      }}
                      className="relative inline-flex h-8 w-24 items-center rounded-full bg-muted p-1 transition-colors"
                    >
                      <span
                        className={`absolute h-6 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                          wireSizeUnit === "mm2" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                        }`}
                      />
                      <span
                        className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                          wireSizeUnit === "awg" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        AWG
                      </span>
                      <span
                        className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
                          wireSizeUnit === "mm2" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        mm²
                      </span>
                    </button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Supply Voltage */}
                <div className="space-y-2">
                  <Label htmlFor="voltage">Supply Voltage (V)</Label>
                  <Input
                    id="voltage"
                    type="number"
                    placeholder="e.g., 120, 240, 480"
                    value={supplyVoltage}
                    onChange={(e) => setSupplyVoltage(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Load Current */}
                <div className="space-y-2">
                  <Label htmlFor="current">Load Current (A)</Label>
                  <Input
                    id="current"
                    type="number"
                    placeholder="Enter load current in amperes"
                    value={loadCurrent}
                    onChange={(e) => setLoadCurrent(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Cable Length */}
                <div className="space-y-2">
                  <Label htmlFor="length">One-Way Cable Length ({lengthUnit === "meters" ? "m" : "ft"})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder={`Enter length in ${lengthUnit}`}
                    value={cableLength}
                    onChange={(e) => setCableLength(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Wire Size */}
                <div className="space-y-2">
                  <Label>Wire Size</Label>
                  <Select value={wireSize} onValueChange={setWireSize}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select wire size" />
                    </SelectTrigger>
                    <SelectContent>
                      {wireSizeUnit === "awg"
                        ? awgSizes.map((size) => (
                            <SelectItem key={size.awg} value={size.awg}>
                              {size.label}
                            </SelectItem>
                          ))
                        : mm2Sizes.map((size) => (
                            <SelectItem key={size.mm2} value={size.mm2.toString()}>
                              {size.label}
                            </SelectItem>
                          ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Conductor Material */}
                <div className="space-y-2">
                  <Label>Conductor Material</Label>
                  <Select value={conductor} onValueChange={(v) => setConductor(v as ConductorMaterial)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="copper">Copper (ρ = 1.68×10⁻⁸ Ω·m)</SelectItem>
                      <SelectItem value="aluminum">Aluminum (ρ = 2.82×10⁻⁸ Ω·m)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Circuit Type */}
                <div className="space-y-2">
                  <Label>Circuit Type</Label>
                  <Select value={circuitType} onValueChange={(v) => setCircuitType(v as CircuitType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single-phase">Single-Phase / DC</SelectItem>
                      <SelectItem value="three-phase">Three-Phase</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateVoltageDrop} className="w-full" size="lg">
                  <Zap className="mr-2 h-4 w-4" />
                  Calculate Voltage Drop
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getStatusColor(result.status).bg} transition-all duration-300`}
                  >
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Voltage Drop</p>
                      <p className={`text-4xl font-bold ${getStatusColor(result.status).text} mb-1`}>
                        {result.voltageDrop.toFixed(2)} V
                      </p>
                      <p className={`text-xl font-semibold ${getStatusColor(result.status).text}`}>
                        {result.dropPercentage.toFixed(2)}% Drop
                      </p>
                      <p
                        className={`text-sm font-medium mt-2 px-3 py-1 rounded-full inline-block ${getStatusColor(result.status).bg} ${getStatusColor(result.status).text}`}
                      >
                        {result.status.charAt(0).toUpperCase() + result.status.slice(1)}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                      <div className="bg-background/50 p-3 rounded-lg text-center">
                        <p className="text-muted-foreground">Final Voltage</p>
                        <p className="font-semibold text-lg">{result.finalVoltage.toFixed(2)} V</p>
                      </div>
                      <div className="bg-background/50 p-3 rounded-lg text-center">
                        <p className="text-muted-foreground">Wire Resistance</p>
                        <p className="font-semibold text-lg">{result.wireResistance.toFixed(4)} Ω</p>
                      </div>
                    </div>

                    {/* Suggestion for excessive drop */}
                    {result.status === "excessive" && (
                      <div className="bg-red-100 p-3 rounded-lg text-sm text-red-700 mb-4">
                        <p className="font-medium flex items-center gap-1">
                          <AlertTriangle className="h-4 w-4" />
                          Voltage drop exceeds 5% recommendation
                        </p>
                        <p className="mt-1">Suggested wire size: {getSuggestedWireSize()}</p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Voltage Drop Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Acceptable</span>
                      <span className="text-sm text-green-600">{"< 3%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Caution</span>
                      <span className="text-sm text-yellow-600">3% – 5%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Excessive</span>
                      <span className="text-sm text-red-600">{"> 5%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas Used</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Wire Resistance (Single-Phase/DC)</p>
                    <p className="text-foreground">R = (ρ × 2 × L) ÷ A</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Wire Resistance (Three-Phase)</p>
                    <p className="text-foreground">R = (ρ × √3 × L) ÷ A</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Voltage Drop</p>
                    <p className="text-foreground">Vd = I × R</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Drop Percentage</p>
                    <p className="text-foreground">%Drop = (Vd ÷ V) × 100</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-yellow-600" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Results are estimates based on standard conductor values at 20°C and do not replace electrical code
                    requirements or professional engineering calculations. Always consult local codes and a qualified
                    electrician for actual installations.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Voltage Drop?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Voltage drop refers to the reduction in electrical voltage that occurs as current flows through a
                  conductor due to its inherent resistance. Every electrical conductor, whether copper or aluminum, has
                  some amount of resistance that opposes the flow of electrons. When current passes through this
                  resistance, some electrical energy is converted to heat, resulting in a lower voltage at the load end
                  of the circuit compared to the source.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding voltage drop is crucial for electrical system design because excessive voltage loss can
                  lead to inefficient operation of electrical equipment, overheating of conductors, reduced equipment
                  lifespan, and potential safety hazards. Most electrical codes and standards recommend keeping voltage
                  drop below 3% for branch circuits and 5% for combined feeder and branch circuits.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Cable className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Voltage Drop</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence the amount of voltage drop in an electrical circuit. The conductor material
                  plays a significant role—copper has lower resistivity than aluminum, making it more efficient but also
                  more expensive. The cross-sectional area of the wire is inversely proportional to resistance; larger
                  wires have lower resistance and thus less voltage drop.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Conductor Length</h4>
                    <p className="text-orange-700 text-sm">
                      Voltage drop increases linearly with conductor length. Longer cable runs require larger wire sizes
                      to maintain acceptable voltage levels at the load.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Load Current</h4>
                    <p className="text-blue-700 text-sm">
                      Higher current draw increases voltage drop proportionally. Heavy loads on long circuits need
                      careful wire sizing to prevent excessive losses.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Wire Size</h4>
                    <p className="text-green-700 text-sm">
                      Larger wire gauges (lower AWG numbers) have more cross-sectional area, reducing resistance and
                      voltage drop for the same current.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Temperature</h4>
                    <p className="text-purple-700 text-sm">
                      Conductor resistance increases with temperature. Hot environments or high-load conditions can
                      increase actual voltage drop beyond calculated values.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Single-Phase vs Three-Phase Circuits</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The type of electrical circuit significantly affects voltage drop calculations. In single-phase and DC
                  circuits, current flows through two conductors (hot and neutral/return), so the total conductor length
                  is twice the one-way distance. This is why we multiply by 2 in the resistance calculation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Three-phase circuits are more efficient for power transmission. The balanced three-phase system
                  results in a mathematical factor of √3 (approximately 1.732) instead of 2, making three-phase systems
                  more efficient for the same wire size. This is one reason why industrial and commercial installations
                  often use three-phase power distribution.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Reducing Voltage Drop</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When calculations show excessive voltage drop, several strategies can help bring it within acceptable
                  limits. The most common solution is to increase the wire size—moving to a larger gauge reduces
                  resistance proportionally. For example, going from 12 AWG to 10 AWG roughly doubles the
                  cross-sectional area, cutting resistance nearly in half.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Other approaches include reducing the circuit length by relocating the power source closer to the
                  load, splitting the load across multiple circuits, using copper instead of aluminum conductors, or
                  increasing the supply voltage where feasible. For critical applications, consulting with a licensed
                  electrician or electrical engineer ensures compliance with local codes and optimal system design.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
