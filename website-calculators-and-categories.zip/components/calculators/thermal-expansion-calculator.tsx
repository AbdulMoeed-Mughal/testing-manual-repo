"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Thermometer, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type ExpansionType = "linear" | "area" | "volume"
type LengthUnit = "m" | "cm" | "mm" | "in" | "ft"
type TempUnit = "C" | "K"

interface ExpansionResult {
  change: number
  final: number
  type: ExpansionType
  category: string
  color: string
  bgColor: string
}

const lengthConversions: Record<LengthUnit, number> = {
  m: 1,
  cm: 0.01,
  mm: 0.001,
  in: 0.0254,
  ft: 0.3048,
}

const lengthLabels: Record<LengthUnit, string> = {
  m: "meters",
  cm: "centimeters",
  mm: "millimeters",
  in: "inches",
  ft: "feet",
}

const commonMaterials = [
  { name: "Aluminum", alpha: 23e-6, description: "Common structural metal" },
  { name: "Steel", alpha: 12e-6, description: "Carbon steel" },
  { name: "Copper", alpha: 17e-6, description: "Electrical applications" },
  { name: "Brass", alpha: 19e-6, description: "Copper-zinc alloy" },
  { name: "Glass", alpha: 9e-6, description: "Standard soda-lime glass" },
  { name: "Concrete", alpha: 12e-6, description: "Standard concrete" },
  { name: "Invar", alpha: 1.2e-6, description: "Low expansion alloy" },
  { name: "PVC", alpha: 50e-6, description: "Polyvinyl chloride" },
]

export function ThermalExpansionCalculator() {
  const [expansionType, setExpansionType] = useState<ExpansionType>("linear")
  const [originalValue, setOriginalValue] = useState("")
  const [tempChange, setTempChange] = useState("")
  const [coefficient, setCoefficient] = useState("")
  const [lengthUnit, setLengthUnit] = useState<LengthUnit>("m")
  const [tempUnit, setTempUnit] = useState<TempUnit>("C")
  const [result, setResult] = useState<ExpansionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const L0 = Number.parseFloat(originalValue)
    const deltaT = Number.parseFloat(tempChange)
    const alpha = Number.parseFloat(coefficient)

    if (isNaN(L0) || L0 <= 0) {
      setError(
        `Please enter a valid original ${expansionType === "linear" ? "length" : expansionType === "area" ? "area" : "volume"} greater than 0`,
      )
      return
    }

    if (isNaN(deltaT)) {
      setError("Please enter a valid temperature change")
      return
    }

    if (isNaN(alpha) || alpha <= 0) {
      setError("Please enter a valid coefficient of thermal expansion greater than 0")
      return
    }

    let change: number
    let multiplier: number

    switch (expansionType) {
      case "linear":
        multiplier = 1
        change = L0 * alpha * deltaT
        break
      case "area":
        multiplier = 2
        change = multiplier * alpha * L0 * deltaT
        break
      case "volume":
        multiplier = 3
        change = multiplier * alpha * L0 * deltaT
        break
    }

    const final = L0 + change
    const percentChange = Math.abs((change / L0) * 100)

    let category: string
    let color: string
    let bgColor: string

    if (percentChange < 0.01) {
      category = "Negligible"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (percentChange < 0.1) {
      category = "Minor"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (percentChange < 1) {
      category = "Moderate"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Significant"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      change,
      final,
      type: expansionType,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setOriginalValue("")
    setTempChange("")
    setCoefficient("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const typeLabel = expansionType === "linear" ? "length" : expansionType === "area" ? "area" : "volume"
      await navigator.clipboard.writeText(
        `Thermal Expansion: Δ${typeLabel} = ${result.change.toExponential(4)} ${getUnitLabel()}, Final ${typeLabel} = ${result.final.toExponential(4)} ${getUnitLabel()}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const selectMaterial = (alpha: number) => {
    setCoefficient(alpha.toExponential(2))
  }

  const getUnitLabel = () => {
    if (expansionType === "linear") return lengthUnit
    if (expansionType === "area") return `${lengthUnit}²`
    return `${lengthUnit}³`
  }

  const getDimensionLabel = () => {
    if (expansionType === "linear") return "Length"
    if (expansionType === "area") return "Area"
    return "Volume"
  }

  const getFormulaMultiplier = () => {
    if (expansionType === "linear") return ""
    if (expansionType === "area") return "2 × "
    return "3 × "
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Thermometer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Thermal Expansion Calculator</CardTitle>
                    <CardDescription>Calculate material expansion due to temperature change</CardDescription>
                  </div>
                </div>

                {/* Expansion Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Expansion Type</span>
                  <div className="flex rounded-full bg-muted p-1">
                    {(["linear", "area", "volume"] as ExpansionType[]).map((type) => (
                      <button
                        key={type}
                        onClick={() => {
                          setExpansionType(type)
                          setResult(null)
                        }}
                        className={`px-3 py-1 text-sm font-medium rounded-full transition-colors ${
                          expansionType === type
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Original Dimension Input */}
                <div className="space-y-2">
                  <Label htmlFor="originalValue">
                    Original {getDimensionLabel()} ({getUnitLabel()})
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="originalValue"
                      type="number"
                      placeholder={`Enter original ${getDimensionLabel().toLowerCase()}`}
                      value={originalValue}
                      onChange={(e) => setOriginalValue(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={lengthUnit} onValueChange={(v) => setLengthUnit(v as LengthUnit)}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="m">m</SelectItem>
                        <SelectItem value="cm">cm</SelectItem>
                        <SelectItem value="mm">mm</SelectItem>
                        <SelectItem value="in">in</SelectItem>
                        <SelectItem value="ft">ft</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Temperature Change Input */}
                <div className="space-y-2">
                  <Label htmlFor="tempChange">Temperature Change (ΔT)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="tempChange"
                      type="number"
                      placeholder="Enter temperature change"
                      value={tempChange}
                      onChange={(e) => setTempChange(e.target.value)}
                      step="any"
                      className="flex-1"
                    />
                    <Select value={tempUnit} onValueChange={(v) => setTempUnit(v as TempUnit)}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="C">°C</SelectItem>
                        <SelectItem value="K">K</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Positive = heating (expansion), Negative = cooling (contraction)
                  </p>
                </div>

                {/* Coefficient of Thermal Expansion Input */}
                <div className="space-y-2">
                  <Label htmlFor="coefficient">
                    Coefficient of Thermal Expansion (α) [1/{tempUnit === "C" ? "°C" : "K"}]
                  </Label>
                  <Input
                    id="coefficient"
                    type="text"
                    placeholder="e.g., 12e-6 or 0.000012"
                    value={coefficient}
                    onChange={(e) => setCoefficient(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter in scientific notation (e.g., 12e-6) or decimal form
                  </p>
                </div>

                {/* Quick Material Selection */}
                <div className="space-y-2">
                  <Label>Quick Material Selection</Label>
                  <div className="flex flex-wrap gap-2">
                    {commonMaterials.slice(0, 4).map((mat) => (
                      <Button
                        key={mat.name}
                        variant="outline"
                        size="sm"
                        onClick={() => selectMaterial(mat.alpha)}
                        className="text-xs"
                      >
                        {mat.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Thermal Expansion
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Change in {getDimensionLabel()}</p>
                      <p className={`text-3xl font-bold ${result.color} mb-1`}>
                        {result.change >= 0 ? "+" : ""}
                        {result.change.toExponential(4)} {getUnitLabel()}
                      </p>
                      <p className="text-sm text-muted-foreground mb-2">
                        Final {getDimensionLabel()}: {result.final.toExponential(4)} {getUnitLabel()}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category} Expansion</p>
                    </div>

                    {/* Additional Info */}
                    <div className="mt-4 pt-4 border-t border-current/10 grid grid-cols-2 gap-4 text-sm">
                      <div className="text-center">
                        <p className="text-muted-foreground">Percent Change</p>
                        <p className="font-semibold">
                          {((result.change / Number.parseFloat(originalValue)) * 100).toFixed(6)}%
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground">Direction</p>
                        <p className="font-semibold">{result.change >= 0 ? "Expansion" : "Contraction"}</p>
                      </div>
                    </div>

                    {/* Step-by-step Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-background/50 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Formula:</strong> Δ
                          {expansionType === "linear" ? "L" : expansionType === "area" ? "A" : "V"} ={" "}
                          {getFormulaMultiplier()}α ×{" "}
                          {expansionType === "linear" ? "L₀" : expansionType === "area" ? "A₀" : "V₀"} × ΔT
                        </p>
                        <p>
                          <strong>Step 1:</strong>{" "}
                          {expansionType === "linear" ? "L₀" : expansionType === "area" ? "A₀" : "V₀"} = {originalValue}{" "}
                          {getUnitLabel()}
                        </p>
                        <p>
                          <strong>Step 2:</strong> ΔT = {tempChange} {tempUnit === "C" ? "°C" : "K"}
                        </p>
                        <p>
                          <strong>Step 3:</strong> α = {coefficient} 1/{tempUnit === "C" ? "°C" : "K"}
                        </p>
                        <p>
                          <strong>Step 4:</strong> Δ
                          {expansionType === "linear" ? "L" : expansionType === "area" ? "A" : "V"} ={" "}
                          {getFormulaMultiplier()}
                          {coefficient} × {originalValue} × {tempChange}
                        </p>
                        <p>
                          <strong>Result:</strong> Δ
                          {expansionType === "linear" ? "L" : expansionType === "area" ? "A" : "V"} ={" "}
                          {result.change.toExponential(4)} {getUnitLabel()}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Material Coefficients (α)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {commonMaterials.map((mat) => (
                      <button
                        key={mat.name}
                        onClick={() => selectMaterial(mat.alpha)}
                        className="w-full flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors text-left"
                      >
                        <div>
                          <span className="font-medium">{mat.name}</span>
                          <span className="text-xs text-muted-foreground block">{mat.description}</span>
                        </div>
                        <span className="text-sm font-mono">{mat.alpha.toExponential(1)} /°C</span>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Expansion Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Linear: ΔL = α × L₀ × ΔT</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Area: ΔA = 2α × A₀ × ΔT</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Volume: ΔV = 3α × V₀ × ΔT</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Thermal Expansion?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Thermal expansion is the tendency of matter to change its shape, area, volume, and density in response
                  to a change in temperature. When a substance is heated, its particles begin moving more and thus
                  usually maintain a greater average separation. This results in an increase in the overall dimensions
                  of the material.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The coefficient of thermal expansion (α) describes how the size of an object changes with a change in
                  temperature. Different materials have different coefficients, with metals generally having higher
                  values than ceramics or glass. Understanding thermal expansion is crucial in engineering applications
                  where temperature changes occur.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Engineering Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Thermal expansion must be considered in many engineering applications. Bridges often have expansion
                  joints to accommodate length changes. Railroad tracks have small gaps between sections to prevent
                  buckling in hot weather. Bimetallic strips, which bend due to differential expansion, are used in
                  thermostats and circuit breakers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In precision instruments and aerospace applications, materials with low thermal expansion coefficients
                  (like Invar) are used to maintain dimensional stability. Conversely, thermal expansion is exploited in
                  shrink fitting, where a metal ring is heated to expand, fitted over a shaft, and then cooled to create
                  a tight mechanical joint.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Thermal expansion calculations are estimates based on ideal material behavior. Actual expansion
                      may vary due to constraints, material inhomogeneity, and environmental conditions. Consult
                      material datasheets for precise values.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
