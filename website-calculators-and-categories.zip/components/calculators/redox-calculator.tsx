"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, Zap, ArrowRightLeft, FlaskConical } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "cell-potential" | "gibbs-energy" | "nernst" | "identify-redox"

interface HalfReaction {
  name: string
  equation: string
  potential: number
}

const standardReductionPotentials: HalfReaction[] = [
  { name: "F₂/F⁻", equation: "F₂ + 2e⁻ → 2F⁻", potential: 2.87 },
  { name: "Au³⁺/Au", equation: "Au³⁺ + 3e⁻ → Au", potential: 1.5 },
  { name: "Cl₂/Cl⁻", equation: "Cl₂ + 2e⁻ → 2Cl⁻", potential: 1.36 },
  { name: "O₂/H₂O (acidic)", equation: "O₂ + 4H⁺ + 4e⁻ → 2H₂O", potential: 1.23 },
  { name: "Br₂/Br⁻", equation: "Br₂ + 2e⁻ → 2Br⁻", potential: 1.07 },
  { name: "Ag⁺/Ag", equation: "Ag⁺ + e⁻ → Ag", potential: 0.8 },
  { name: "Fe³⁺/Fe²⁺", equation: "Fe³⁺ + e⁻ → Fe²⁺", potential: 0.77 },
  { name: "I₂/I⁻", equation: "I₂ + 2e⁻ → 2I⁻", potential: 0.54 },
  { name: "Cu²⁺/Cu", equation: "Cu²⁺ + 2e⁻ → Cu", potential: 0.34 },
  { name: "H⁺/H₂ (SHE)", equation: "2H⁺ + 2e⁻ → H₂", potential: 0.0 },
  { name: "Pb²⁺/Pb", equation: "Pb²⁺ + 2e⁻ → Pb", potential: -0.13 },
  { name: "Sn²⁺/Sn", equation: "Sn²⁺ + 2e⁻ → Sn", potential: -0.14 },
  { name: "Ni²⁺/Ni", equation: "Ni²⁺ + 2e⁻ → Ni", potential: -0.26 },
  { name: "Fe²⁺/Fe", equation: "Fe²⁺ + 2e⁻ → Fe", potential: -0.44 },
  { name: "Zn²⁺/Zn", equation: "Zn²⁺ + 2e⁻ → Zn", potential: -0.76 },
  { name: "Al³⁺/Al", equation: "Al³⁺ + 3e⁻ → Al", potential: -1.66 },
  { name: "Mg²⁺/Mg", equation: "Mg²⁺ + 2e⁻ → Mg", potential: -2.37 },
  { name: "Na⁺/Na", equation: "Na⁺ + e⁻ → Na", potential: -2.71 },
  { name: "Ca²⁺/Ca", equation: "Ca²⁺ + 2e⁻ → Ca", potential: -2.87 },
  { name: "K⁺/K", equation: "K⁺ + e⁻ → K", potential: -2.93 },
  { name: "Li⁺/Li", equation: "Li⁺ + e⁻ → Li", potential: -3.04 },
]

interface RedoxResult {
  cellPotential: number
  gibbsEnergy: number
  spontaneous: boolean
  cathode: HalfReaction | null
  anode: HalfReaction | null
  nernstPotential?: number
}

const FARADAY_CONSTANT = 96485 // C/mol
const GAS_CONSTANT = 8.314 // J/(mol·K)

export function RedoxCalculator() {
  const [mode, setMode] = useState<CalculationMode>("cell-potential")
  const [cathodeIndex, setCathodeIndex] = useState<string>("")
  const [anodeIndex, setAnodeIndex] = useState<string>("")
  const [customCathodeE, setCustomCathodeE] = useState("")
  const [customAnodeE, setCustomAnodeE] = useState("")
  const [electrons, setElectrons] = useState("2")
  const [temperature, setTemperature] = useState("25")
  const [reactionQuotient, setReactionQuotient] = useState("1")
  const [useCustom, setUseCustom] = useState(false)
  const [result, setResult] = useState<RedoxResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    let cathodeE: number
    let anodeE: number
    let cathode: HalfReaction | null = null
    let anode: HalfReaction | null = null

    if (useCustom) {
      cathodeE = Number.parseFloat(customCathodeE)
      anodeE = Number.parseFloat(customAnodeE)
      if (isNaN(cathodeE) || isNaN(anodeE)) {
        setError("Please enter valid E° values for both half-reactions")
        return
      }
    } else {
      if (!cathodeIndex || !anodeIndex) {
        setError("Please select both cathode and anode half-reactions")
        return
      }
      cathode = standardReductionPotentials[Number.parseInt(cathodeIndex)]
      anode = standardReductionPotentials[Number.parseInt(anodeIndex)]
      cathodeE = cathode.potential
      anodeE = anode.potential
    }

    const n = Number.parseFloat(electrons)
    if (isNaN(n) || n <= 0 || !Number.isInteger(n)) {
      setError("Number of electrons must be a positive integer")
      return
    }

    // Standard cell potential: E°cell = E°cathode - E°anode
    const cellPotential = cathodeE - anodeE

    // Gibbs free energy: ΔG° = -nFE°
    const gibbsEnergy = -n * FARADAY_CONSTANT * cellPotential

    // Spontaneity
    const spontaneous = gibbsEnergy < 0

    let nernstPotential: number | undefined

    if (mode === "nernst") {
      const T = Number.parseFloat(temperature) + 273.15 // Convert to Kelvin
      const Q = Number.parseFloat(reactionQuotient)

      if (isNaN(T) || T <= 0) {
        setError("Please enter a valid temperature")
        return
      }
      if (isNaN(Q) || Q <= 0) {
        setError("Reaction quotient must be a positive number")
        return
      }

      // Nernst equation: E = E° - (RT/nF)lnQ
      nernstPotential = cellPotential - ((GAS_CONSTANT * T) / (n * FARADAY_CONSTANT)) * Math.log(Q)
    }

    setResult({
      cellPotential,
      gibbsEnergy,
      spontaneous,
      cathode,
      anode,
      nernstPotential,
    })
  }

  const handleReset = () => {
    setCathodeIndex("")
    setAnodeIndex("")
    setCustomCathodeE("")
    setCustomAnodeE("")
    setElectrons("2")
    setTemperature("25")
    setReactionQuotient("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Cell Potential: ${result.cellPotential.toFixed(3)} V, ΔG°: ${(result.gibbsEnergy / 1000).toFixed(2)} kJ/mol, ${result.spontaneous ? "Spontaneous" : "Non-spontaneous"}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatEnergy = (joules: number): string => {
    if (Math.abs(joules) >= 1000) {
      return `${(joules / 1000).toFixed(2)} kJ/mol`
    }
    return `${joules.toFixed(2)} J/mol`
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Redox Calculator</CardTitle>
                    <CardDescription>Calculate electrochemical cell properties</CardDescription>
                  </div>
                </div>

                {/* Mode Selection */}
                <div className="space-y-2 pt-2">
                  <Label>Calculation Mode</Label>
                  <Select value={mode} onValueChange={(v) => setMode(v as CalculationMode)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cell-potential">Cell Potential & ΔG°</SelectItem>
                      <SelectItem value="nernst">Nernst Equation</SelectItem>
                      <SelectItem value="identify-redox">Identify Oxidation/Reduction</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={() => {
                      setUseCustom(!useCustom)
                      setResult(null)
                    }}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        useCustom ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !useCustom ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Table
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        useCustom ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Custom
                    </span>
                  </button>
                </div>

                {useCustom ? (
                  <>
                    {/* Custom E° Values */}
                    <div className="space-y-2">
                      <Label htmlFor="cathodeE">Cathode E° (V)</Label>
                      <Input
                        id="cathodeE"
                        type="number"
                        step="0.01"
                        placeholder="Enter reduction potential"
                        value={customCathodeE}
                        onChange={(e) => setCustomCathodeE(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="anodeE">Anode E° (V)</Label>
                      <Input
                        id="anodeE"
                        type="number"
                        step="0.01"
                        placeholder="Enter reduction potential"
                        value={customAnodeE}
                        onChange={(e) => setCustomAnodeE(e.target.value)}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    {/* Half-Reaction Selection */}
                    <div className="space-y-2">
                      <Label>Cathode (Reduction)</Label>
                      <Select value={cathodeIndex} onValueChange={setCathodeIndex}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select half-reaction" />
                        </SelectTrigger>
                        <SelectContent>
                          {standardReductionPotentials.map((hr, idx) => (
                            <SelectItem key={idx} value={idx.toString()}>
                              {hr.name} (E° = {hr.potential.toFixed(2)} V)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Anode (Oxidation)</Label>
                      <Select value={anodeIndex} onValueChange={setAnodeIndex}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select half-reaction" />
                        </SelectTrigger>
                        <SelectContent>
                          {standardReductionPotentials.map((hr, idx) => (
                            <SelectItem key={idx} value={idx.toString()}>
                              {hr.name} (E° = {hr.potential.toFixed(2)} V)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {/* Electrons Transferred */}
                <div className="space-y-2">
                  <Label htmlFor="electrons">Electrons Transferred (n)</Label>
                  <Input
                    id="electrons"
                    type="number"
                    min="1"
                    step="1"
                    placeholder="Number of electrons"
                    value={electrons}
                    onChange={(e) => setElectrons(e.target.value)}
                  />
                </div>

                {/* Nernst Equation Inputs */}
                {mode === "nernst" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="temperature">Temperature (°C)</Label>
                      <Input
                        id="temperature"
                        type="number"
                        step="0.1"
                        placeholder="Default: 25°C"
                        value={temperature}
                        onChange={(e) => setTemperature(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="quotient">Reaction Quotient (Q)</Label>
                      <Input
                        id="quotient"
                        type="number"
                        step="any"
                        min="0"
                        placeholder="Enter Q value"
                        value={reactionQuotient}
                        onChange={(e) => setReactionQuotient(e.target.value)}
                      />
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.spontaneous ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                    }`}
                  >
                    <div className="text-center space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Standard Cell Potential</p>
                        <p className="text-4xl font-bold text-purple-600">
                          {result.cellPotential >= 0 ? "+" : ""}
                          {result.cellPotential.toFixed(3)} V
                        </p>
                      </div>

                      {mode === "nernst" && result.nernstPotential !== undefined && (
                        <div className="pt-2 border-t border-purple-200">
                          <p className="text-sm text-muted-foreground mb-1">Cell Potential at Given Conditions</p>
                          <p className="text-2xl font-bold text-purple-600">
                            {result.nernstPotential >= 0 ? "+" : ""}
                            {result.nernstPotential.toFixed(3)} V
                          </p>
                        </div>
                      )}

                      <div className="pt-2 border-t border-gray-200">
                        <p className="text-sm text-muted-foreground mb-1">Gibbs Free Energy Change</p>
                        <p className="text-2xl font-bold text-blue-600">{formatEnergy(result.gibbsEnergy)}</p>
                      </div>

                      <div
                        className={`p-3 rounded-lg ${
                          result.spontaneous ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                        }`}
                      >
                        <p className="font-semibold text-lg">
                          {result.spontaneous ? "✓ Spontaneous Reaction" : "✗ Non-spontaneous Reaction"}
                        </p>
                        <p className="text-sm">
                          {result.spontaneous
                            ? "ΔG° < 0: Reaction proceeds forward"
                            : "ΔG° > 0: Reaction requires energy input"}
                        </p>
                      </div>

                      {(mode === "identify-redox" || mode === "cell-potential") && result.cathode && result.anode && (
                        <div className="pt-3 border-t border-gray-200 text-left space-y-2">
                          <div className="p-2 bg-blue-50 rounded-lg">
                            <p className="text-xs text-blue-600 font-medium">REDUCTION (Cathode)</p>
                            <p className="text-sm font-mono">{result.cathode.equation}</p>
                          </div>
                          <div className="p-2 bg-orange-50 rounded-lg">
                            <p className="text-xs text-orange-600 font-medium">OXIDATION (Anode)</p>
                            <p className="text-sm font-mono">
                              {result.anode.equation.replace("→", "←").replace("+ ", "← ").replace("e⁻", "e⁻ +")}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Show Steps Toggle */}
                    <div className="mt-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowSteps(!showSteps)}
                        className="w-full text-muted-foreground"
                      >
                        {showSteps ? "Hide Steps" : "Show Calculation Steps"}
                      </Button>

                      {showSteps && (
                        <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2 border">
                          <p className="font-medium">Step-by-Step Solution:</p>
                          <div className="space-y-1 text-muted-foreground">
                            <p>
                              1. E°<sub>cell</sub> = E°<sub>cathode</sub> − E°<sub>anode</sub>
                            </p>
                            <p className="pl-4">
                              = {useCustom ? customCathodeE : result.cathode?.potential.toFixed(2)} V − (
                              {useCustom ? customAnodeE : result.anode?.potential.toFixed(2)} V)
                            </p>
                            <p className="pl-4 font-medium text-foreground">= {result.cellPotential.toFixed(3)} V</p>
                            <p className="pt-2">
                              2. ΔG° = −nFE°<sub>cell</sub>
                            </p>
                            <p className="pl-4">
                              = −({electrons}) × (96485 C/mol) × ({result.cellPotential.toFixed(3)} V)
                            </p>
                            <p className="pl-4 font-medium text-foreground">= {formatEnergy(result.gibbsEnergy)}</p>
                            {mode === "nernst" && result.nernstPotential !== undefined && (
                              <>
                                <p className="pt-2">3. E = E° − (RT/nF) ln Q</p>
                                <p className="pl-4">
                                  = {result.cellPotential.toFixed(3)} − (8.314 ×{" "}
                                  {(Number.parseFloat(temperature) + 273.15).toFixed(2)}) / ({electrons} × 96485) × ln(
                                  {reactionQuotient})
                                </p>
                                <p className="pl-4 font-medium text-foreground">
                                  = {result.nernstPotential.toFixed(3)} V
                                </p>
                              </>
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="text-sm font-medium text-purple-700">Cell Potential</p>
                    <p className="font-mono text-purple-800">E°cell = E°cathode − E°anode</p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm font-medium text-blue-700">Gibbs Free Energy</p>
                    <p className="font-mono text-blue-800">ΔG° = −nFE°cell</p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm font-medium text-green-700">Nernst Equation</p>
                    <p className="font-mono text-green-800">E = E° − (RT/nF) ln Q</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Constants</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Faraday Constant (F)</span>
                      <span className="font-mono">96,485 C/mol</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Gas Constant (R)</span>
                      <span className="font-mono">8.314 J/(mol·K)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Standard Temp</span>
                      <span className="font-mono">25°C (298.15 K)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are based on standard conditions (25°C, 1 atm, 1 M concentrations) unless otherwise
                        specified. Actual experimental values may vary.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Standard Reduction Potentials Table */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Standard Reduction Potentials (E°)</CardTitle>
              <CardDescription>Reference table for common half-reactions at 25°C</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3 font-medium">Half-Reaction</th>
                      <th className="text-right py-2 px-3 font-medium">E° (V)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {standardReductionPotentials.map((hr, idx) => (
                      <tr key={idx} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="py-2 px-3 font-mono text-xs">{hr.equation}</td>
                        <td
                          className={`py-2 px-3 text-right font-mono ${
                            hr.potential > 0 ? "text-green-600" : hr.potential < 0 ? "text-red-600" : "text-gray-600"
                          }`}
                        >
                          {hr.potential >= 0 ? "+" : ""}
                          {hr.potential.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Electrochemistry?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrochemistry is the branch of chemistry that studies the relationship between electrical energy
                  and chemical reactions. It deals with redox (reduction-oxidation) reactions where electrons are
                  transferred between species. These reactions form the basis of batteries, fuel cells, electrolysis,
                  corrosion, and many industrial processes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In an electrochemical cell, oxidation (loss of electrons) occurs at the anode, while reduction (gain
                  of electrons) occurs at the cathode. The cell potential measures the driving force of the reaction,
                  with positive values indicating a spontaneous reaction and negative values indicating a
                  non-spontaneous reaction that requires external energy.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Cell Potential</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The standard cell potential (E°cell) is calculated by subtracting the anode's reduction potential from
                  the cathode's reduction potential. A positive E°cell indicates that the reaction will proceed
                  spontaneously under standard conditions. The more positive the cell potential, the greater the
                  tendency for the reaction to occur.
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Galvanic Cell (E° {">"} 0)</h4>
                    <p className="text-green-700 text-sm">
                      Spontaneous reaction that converts chemical energy to electrical energy. Used in batteries.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Electrolytic Cell (E° {"<"} 0)</h4>
                    <p className="text-red-700 text-sm">
                      Non-spontaneous reaction that requires electrical energy input. Used in electroplating.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Gibbs Free Energy and Spontaneity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Gibbs free energy change (ΔG°) provides a thermodynamic measure of whether a reaction is
                  spontaneous. It is directly related to cell potential through the equation ΔG° = −nFE°, where n is the
                  number of electrons transferred and F is the Faraday constant (96,485 C/mol).
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-700">ΔG° {"<"} 0 (Negative)</p>
                    <p className="text-sm text-green-600">
                      Reaction is spontaneous and releases energy. The more negative ΔG°, the more favorable the
                      reaction.
                    </p>
                  </div>
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="font-medium text-yellow-700">ΔG° = 0</p>
                    <p className="text-sm text-yellow-600">
                      System is at equilibrium. No net reaction occurs in either direction.
                    </p>
                  </div>
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="font-medium text-red-700">ΔG° {">"} 0 (Positive)</p>
                    <p className="text-sm text-red-600">
                      Reaction is non-spontaneous and requires energy input to proceed.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>The Nernst Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Nernst equation allows calculation of cell potential under non-standard conditions. It accounts
                  for the effect of temperature and concentration on cell potential. The equation is E = E° − (RT/nF) ln
                  Q, where Q is the reaction quotient representing the ratio of product to reactant concentrations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  At 25°C, this simplifies to E = E° − (0.0592/n) log Q. As the reaction proceeds and Q increases, the
                  cell potential decreases until equilibrium is reached (E = 0). This is why batteries lose voltage as
                  they discharge—the concentrations of reactants and products change, affecting the cell potential.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
