"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Activity,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type UnitSystem = "metric" | "imperial"
type GlucoseUnit = "mg/dL" | "mmol/L"

interface DiabetesRiskResult {
  totalScore: number
  category: string
  riskPercentage: string
  color: string
  bgColor: string
  factors: {
    name: string
    points: number
    status: "low" | "moderate" | "high"
  }[]
  recommendations: string[]
}

export function DiabetesRiskCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [glucoseUnit, setGlucoseUnit] = useState<GlucoseUnit>("mg/dL")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<string>("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [waist, setWaist] = useState("")
  const [familyHistory, setFamilyHistory] = useState<string>("")
  const [activityLevel, setActivityLevel] = useState<string>("")
  const [systolic, setSystolic] = useState("")
  const [diastolic, setDiastolic] = useState("")
  const [includeGlucose, setIncludeGlucose] = useState(false)
  const [glucose, setGlucose] = useState("")
  const [includeSmoking, setIncludeSmoking] = useState(false)
  const [smoking, setSmoking] = useState<string>("")
  const [result, setResult] = useState<DiabetesRiskResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateBMI = (): number | null => {
    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) return null

    let heightInMeters: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) return null
      heightInMeters = heightCmNum / 100
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) return null
      const totalInches = feet * 12 + inches
      heightInMeters = totalInches * 0.0254
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum
    return weightInKg / (heightInMeters * heightInMeters)
  }

  const calculateRisk = () => {
    setError("")
    setResult(null)

    // Validate inputs
    const ageNum = Number.parseFloat(age)
    if (isNaN(ageNum) || ageNum < 18 || ageNum > 120) {
      setError("Please enter a valid age between 18 and 120")
      return
    }

    if (!gender) {
      setError("Please select your gender")
      return
    }

    const bmi = calculateBMI()
    if (bmi === null || bmi < 10 || bmi > 70) {
      setError("Please enter valid weight and height values")
      return
    }

    const waistNum = Number.parseFloat(waist)
    const waistCm = unitSystem === "imperial" ? waistNum * 2.54 : waistNum
    if (isNaN(waistCm) || waistCm < 50 || waistCm > 200) {
      setError("Please enter a valid waist circumference")
      return
    }

    if (!familyHistory) {
      setError("Please select family history status")
      return
    }

    if (!activityLevel) {
      setError("Please select your physical activity level")
      return
    }

    const systolicNum = Number.parseFloat(systolic)
    const diastolicNum = Number.parseFloat(diastolic)
    if (
      isNaN(systolicNum) ||
      isNaN(diastolicNum) ||
      systolicNum < 70 ||
      systolicNum > 250 ||
      diastolicNum < 40 ||
      diastolicNum > 150
    ) {
      setError("Please enter valid blood pressure values")
      return
    }

    if (includeGlucose) {
      const glucoseNum = Number.parseFloat(glucose)
      const glucoseMgDL = glucoseUnit === "mmol/L" ? glucoseNum * 18 : glucoseNum
      if (isNaN(glucoseMgDL) || glucoseMgDL < 50 || glucoseMgDL > 400) {
        setError("Please enter a valid fasting glucose value")
        return
      }
    }

    // Calculate risk score based on FINDRISC-like scoring
    const factors: DiabetesRiskResult["factors"] = []
    let totalScore = 0

    // Age scoring (0-4 points)
    let agePoints = 0
    if (ageNum < 45) agePoints = 0
    else if (ageNum < 55) agePoints = 2
    else if (ageNum < 65) agePoints = 3
    else agePoints = 4
    factors.push({
      name: "Age",
      points: agePoints,
      status: agePoints <= 1 ? "low" : agePoints <= 2 ? "moderate" : "high",
    })
    totalScore += agePoints

    // BMI scoring (0-3 points)
    let bmiPoints = 0
    if (bmi < 25) bmiPoints = 0
    else if (bmi < 30) bmiPoints = 1
    else bmiPoints = 3
    factors.push({
      name: "BMI",
      points: bmiPoints,
      status: bmiPoints === 0 ? "low" : bmiPoints === 1 ? "moderate" : "high",
    })
    totalScore += bmiPoints

    // Waist circumference scoring (0-4 points)
    let waistPoints = 0
    if (gender === "male") {
      if (waistCm < 94) waistPoints = 0
      else if (waistCm < 102) waistPoints = 3
      else waistPoints = 4
    } else {
      if (waistCm < 80) waistPoints = 0
      else if (waistCm < 88) waistPoints = 3
      else waistPoints = 4
    }
    factors.push({
      name: "Waist Circumference",
      points: waistPoints,
      status: waistPoints === 0 ? "low" : waistPoints <= 3 ? "moderate" : "high",
    })
    totalScore += waistPoints

    // Family history scoring (0-5 points)
    let familyPoints = 0
    if (familyHistory === "none") familyPoints = 0
    else if (familyHistory === "grandparent" || familyHistory === "distant") familyPoints = 3
    else familyPoints = 5
    factors.push({
      name: "Family History",
      points: familyPoints,
      status: familyPoints === 0 ? "low" : familyPoints <= 3 ? "moderate" : "high",
    })
    totalScore += familyPoints

    // Physical activity scoring (0-2 points)
    let activityPoints = 0
    if (activityLevel === "high") activityPoints = 0
    else if (activityLevel === "moderate") activityPoints = 1
    else activityPoints = 2
    factors.push({
      name: "Physical Activity",
      points: activityPoints,
      status: activityPoints === 0 ? "low" : activityPoints === 1 ? "moderate" : "high",
    })
    totalScore += activityPoints

    // Blood pressure scoring (0-2 points)
    let bpPoints = 0
    if (systolicNum >= 140 || diastolicNum >= 90) bpPoints = 2
    else if (systolicNum >= 130 || diastolicNum >= 85) bpPoints = 1
    factors.push({
      name: "Blood Pressure",
      points: bpPoints,
      status: bpPoints === 0 ? "low" : bpPoints === 1 ? "moderate" : "high",
    })
    totalScore += bpPoints

    // Optional: Fasting glucose scoring (0-5 points)
    if (includeGlucose) {
      const glucoseNum = Number.parseFloat(glucose)
      const glucoseMgDL = glucoseUnit === "mmol/L" ? glucoseNum * 18 : glucoseNum
      let glucosePoints = 0
      if (glucoseMgDL < 100) glucosePoints = 0
      else if (glucoseMgDL < 110) glucosePoints = 2
      else if (glucoseMgDL < 126) glucosePoints = 4
      else glucosePoints = 5
      factors.push({
        name: "Fasting Glucose",
        points: glucosePoints,
        status: glucosePoints === 0 ? "low" : glucosePoints <= 2 ? "moderate" : "high",
      })
      totalScore += glucosePoints
    }

    // Optional: Smoking scoring (0-2 points)
    if (includeSmoking && smoking) {
      let smokingPoints = 0
      if (smoking === "never") smokingPoints = 0
      else if (smoking === "former") smokingPoints = 1
      else smokingPoints = 2
      factors.push({
        name: "Smoking Status",
        points: smokingPoints,
        status: smokingPoints === 0 ? "low" : smokingPoints === 1 ? "moderate" : "high",
      })
      totalScore += smokingPoints
    }

    // Determine risk category
    let category: string
    let riskPercentage: string
    let color: string
    let bgColor: string

    // Adjust thresholds based on optional factors included
    const maxScore = 20 + (includeGlucose ? 5 : 0) + (includeSmoking && smoking ? 2 : 0)
    const scorePercentage = (totalScore / maxScore) * 100

    if (totalScore < 7) {
      category = "Low Risk"
      riskPercentage = "~1%"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (totalScore < 12) {
      category = "Moderate Risk"
      riskPercentage = "~4%"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (totalScore < 15) {
      category = "High Risk"
      riskPercentage = "~17%"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Very High Risk"
      riskPercentage = "~50%"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    // Generate recommendations
    const recommendations: string[] = []
    if (bmiPoints > 0) {
      recommendations.push(
        "Consider achieving and maintaining a healthy weight through balanced diet and regular exercise",
      )
    }
    if (waistPoints > 0) {
      recommendations.push("Focus on reducing abdominal fat through cardiovascular exercise and dietary changes")
    }
    if (activityPoints > 0) {
      recommendations.push("Increase physical activity to at least 150 minutes of moderate exercise per week")
    }
    if (bpPoints > 0) {
      recommendations.push("Monitor blood pressure regularly and consider lifestyle modifications to improve it")
    }
    if (includeGlucose && factors.find((f) => f.name === "Fasting Glucose")?.points! > 0) {
      recommendations.push("Monitor blood glucose levels regularly and consider consulting a healthcare provider")
    }
    if (includeSmoking && smoking === "current") {
      recommendations.push("Consider quitting smoking to reduce diabetes and cardiovascular disease risk")
    }
    if (recommendations.length === 0) {
      recommendations.push("Continue maintaining your healthy lifestyle habits")
    }

    setResult({
      totalScore,
      category,
      riskPercentage,
      color,
      bgColor,
      factors,
      recommendations,
    })
  }

  const handleReset = () => {
    setAge("")
    setGender("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setWaist("")
    setFamilyHistory("")
    setActivityLevel("")
    setSystolic("")
    setDiastolic("")
    setIncludeGlucose(false)
    setGlucose("")
    setIncludeSmoking(false)
    setSmoking("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Diabetes Risk Assessment: ${result.category} (Score: ${result.totalScore}, 10-year risk: ${result.riskPercentage})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Diabetes Risk Assessment",
          text: `I assessed my diabetes risk using CalcHub! Result: ${result.category} (Score: ${result.totalScore})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setWaist("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Diabetes Risk Calculator</CardTitle>
                    <CardDescription>Assess your type 2 diabetes risk</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Age and Gender */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age (years)</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter age"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="18"
                      max="120"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender</Label>
                    <Select value={gender} onValueChange={setGender}>
                      <SelectTrigger id="gender">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Weight */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="Feet"
                        value={heightFeet}
                        onChange={(e) => setHeightFeet(e.target.value)}
                        min="0"
                      />
                      <Input
                        type="number"
                        placeholder="Inches"
                        value={heightInches}
                        onChange={(e) => setHeightInches(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                )}

                {/* Waist Circumference */}
                <div className="space-y-2">
                  <Label htmlFor="waist">Waist Circumference ({unitSystem === "metric" ? "cm" : "inches"})</Label>
                  <Input
                    id="waist"
                    type="number"
                    placeholder={`Enter waist in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                    value={waist}
                    onChange={(e) => setWaist(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Family History */}
                <div className="space-y-2">
                  <Label htmlFor="familyHistory">Family History of Diabetes</Label>
                  <Select value={familyHistory} onValueChange={setFamilyHistory}>
                    <SelectTrigger id="familyHistory">
                      <SelectValue placeholder="Select family history" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No family history</SelectItem>
                      <SelectItem value="grandparent">Grandparent, aunt, uncle, or cousin</SelectItem>
                      <SelectItem value="parent">Parent, sibling, or child</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Physical Activity */}
                <div className="space-y-2">
                  <Label htmlFor="activity">Physical Activity Level</Label>
                  <Select value={activityLevel} onValueChange={setActivityLevel}>
                    <SelectTrigger id="activity">
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (less than 30 min/day)</SelectItem>
                      <SelectItem value="moderate">Moderate (30-60 min/day)</SelectItem>
                      <SelectItem value="high">High (more than 60 min/day)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Blood Pressure */}
                <div className="space-y-2">
                  <Label>Blood Pressure (mmHg)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      type="number"
                      placeholder="Systolic"
                      value={systolic}
                      onChange={(e) => setSystolic(e.target.value)}
                      min="70"
                      max="250"
                    />
                    <Input
                      type="number"
                      placeholder="Diastolic"
                      value={diastolic}
                      onChange={(e) => setDiastolic(e.target.value)}
                      min="40"
                      max="150"
                    />
                  </div>
                </div>

                {/* Optional: Fasting Glucose */}
                <div className="space-y-3 p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="includeGlucose" className="cursor-pointer">
                      Include Fasting Glucose (optional)
                    </Label>
                    <Switch id="includeGlucose" checked={includeGlucose} onCheckedChange={setIncludeGlucose} />
                  </div>
                  {includeGlucose && (
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder={`Glucose (${glucoseUnit})`}
                        value={glucose}
                        onChange={(e) => setGlucose(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                      <Select value={glucoseUnit} onValueChange={(v) => setGlucoseUnit(v as GlucoseUnit)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mg/dL">mg/dL</SelectItem>
                          <SelectItem value="mmol/L">mmol/L</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                {/* Optional: Smoking */}
                <div className="space-y-3 p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="includeSmoking" className="cursor-pointer">
                      Include Smoking Status (optional)
                    </Label>
                    <Switch id="includeSmoking" checked={includeSmoking} onCheckedChange={setIncludeSmoking} />
                  </div>
                  {includeSmoking && (
                    <Select value={smoking} onValueChange={setSmoking}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select smoking status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="never">Never smoked</SelectItem>
                        <SelectItem value="former">Former smoker</SelectItem>
                        <SelectItem value="current">Current smoker</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRisk} className="w-full" size="lg">
                  Assess Diabetes Risk
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Risk Score</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.totalScore}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        10-year risk of developing type 2 diabetes: {result.riskPercentage}
                      </p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-2 mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          Hide Details <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Details <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 space-y-4">
                        <div className="space-y-2">
                          <p className="text-sm font-medium">Risk Factor Breakdown:</p>
                          {result.factors.map((factor, index) => (
                            <div key={index} className="flex items-center justify-between p-2 rounded bg-background/50">
                              <span className="text-sm">{factor.name}</span>
                              <span
                                className={`text-sm font-medium ${
                                  factor.status === "low"
                                    ? "text-green-600"
                                    : factor.status === "moderate"
                                      ? "text-yellow-600"
                                      : "text-red-600"
                                }`}
                              >
                                +{factor.points} pts
                              </span>
                            </div>
                          ))}
                        </div>

                        <div className="space-y-2">
                          <p className="text-sm font-medium">Recommendations:</p>
                          <ul className="space-y-1">
                            {result.recommendations.map((rec, index) => (
                              <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                                <span className="text-primary">•</span>
                                {rec}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Risk Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low Risk</span>
                      <span className="text-sm text-green-600">Score {"<"} 7</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Risk</span>
                      <span className="text-sm text-yellow-600">Score 7-11</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">High Risk</span>
                      <span className="text-sm text-orange-600">Score 12-14</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very High Risk</span>
                      <span className="text-sm text-red-600">Score ≥ 15</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Risk Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">Modifiable Factors:</p>
                    <ul className="list-disc list-inside space-y-1 ml-2">
                      <li>Body weight and BMI</li>
                      <li>Waist circumference</li>
                      <li>Physical activity level</li>
                      <li>Blood pressure</li>
                      <li>Smoking status</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">Non-Modifiable Factors:</p>
                    <ul className="list-disc list-inside space-y-1 ml-2">
                      <li>Age</li>
                      <li>Family history</li>
                      <li>Genetics</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Type 2 Diabetes Risk</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Type 2 diabetes is a chronic metabolic condition characterized by elevated blood glucose levels due to
                  insulin resistance or inadequate insulin production. It is the most common form of diabetes,
                  accounting for approximately 90-95% of all diabetes cases. Understanding your risk factors is the
                  first step in prevention, as many cases of type 2 diabetes can be prevented or delayed through
                  lifestyle modifications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This risk assessment is based on validated scoring systems like the Finnish Diabetes Risk Score
                  (FINDRISC) and considers multiple factors including age, body composition, family history, physical
                  activity, and clinical measurements. While this tool provides a useful estimate, it is not a
                  diagnostic tool and should not replace professional medical evaluation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Prevention Strategies</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Research has shown that lifestyle interventions can reduce the risk of developing type 2 diabetes by
                  up to 58% in high-risk individuals. Key prevention strategies include maintaining a healthy weight,
                  engaging in regular physical activity (at least 150 minutes per week of moderate-intensity exercise),
                  eating a balanced diet rich in fiber and low in processed foods, and avoiding tobacco use.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Dietary Changes</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Increase fiber intake</li>
                      <li>• Choose whole grains over refined</li>
                      <li>• Limit sugary beverages</li>
                      <li>• Control portion sizes</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Physical Activity</h4>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>• 150+ minutes moderate exercise/week</li>
                      <li>• Include resistance training</li>
                      <li>• Reduce sedentary time</li>
                      <li>• Take regular walking breaks</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p>
                      This calculator provides an estimate of diabetes risk and is not a medical diagnosis. It is
                      intended for educational purposes only and should not replace professional medical advice. If you
                      have concerns about your diabetes risk or have a high-risk score, please consult a healthcare
                      professional for proper evaluation, diagnostic testing, and personalized guidance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
