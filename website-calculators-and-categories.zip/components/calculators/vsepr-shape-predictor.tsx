"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Atom, Info, AlertTriangle, Shapes } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface VSEPRResult {
  electronDomains: number
  electronGeometry: string
  molecularGeometry: string
  bondAngle: string
  hybridization: string
  polarity: string
  color: string
  bgColor: string
}

const VSEPR_DATA: Record<string, VSEPRResult> = {
  "2-0": {
    electronDomains: 2,
    electronGeometry: "Linear",
    molecularGeometry: "Linear",
    bondAngle: "180°",
    hybridization: "sp",
    polarity: "Nonpolar (if identical atoms)",
    color: "text-blue-600",
    bgColor: "bg-blue-50 border-blue-200",
  },
  "3-0": {
    electronDomains: 3,
    electronGeometry: "Trigonal Planar",
    molecularGeometry: "Trigonal Planar",
    bondAngle: "120°",
    hybridization: "sp²",
    polarity: "Nonpolar (if identical atoms)",
    color: "text-green-600",
    bgColor: "bg-green-50 border-green-200",
  },
  "3-1": {
    electronDomains: 3,
    electronGeometry: "Trigonal Planar",
    molecularGeometry: "Bent",
    bondAngle: "~117°",
    hybridization: "sp²",
    polarity: "Polar",
    color: "text-yellow-600",
    bgColor: "bg-yellow-50 border-yellow-200",
  },
  "4-0": {
    electronDomains: 4,
    electronGeometry: "Tetrahedral",
    molecularGeometry: "Tetrahedral",
    bondAngle: "109.5°",
    hybridization: "sp³",
    polarity: "Nonpolar (if identical atoms)",
    color: "text-green-600",
    bgColor: "bg-green-50 border-green-200",
  },
  "4-1": {
    electronDomains: 4,
    electronGeometry: "Tetrahedral",
    molecularGeometry: "Trigonal Pyramidal",
    bondAngle: "~107°",
    hybridization: "sp³",
    polarity: "Polar",
    color: "text-purple-600",
    bgColor: "bg-purple-50 border-purple-200",
  },
  "4-2": {
    electronDomains: 4,
    electronGeometry: "Tetrahedral",
    molecularGeometry: "Bent",
    bondAngle: "~104.5°",
    hybridization: "sp³",
    polarity: "Polar",
    color: "text-yellow-600",
    bgColor: "bg-yellow-50 border-yellow-200",
  },
  "5-0": {
    electronDomains: 5,
    electronGeometry: "Trigonal Bipyramidal",
    molecularGeometry: "Trigonal Bipyramidal",
    bondAngle: "90° and 120°",
    hybridization: "sp³d",
    polarity: "Nonpolar (if identical atoms)",
    color: "text-blue-600",
    bgColor: "bg-blue-50 border-blue-200",
  },
  "5-1": {
    electronDomains: 5,
    electronGeometry: "Trigonal Bipyramidal",
    molecularGeometry: "Seesaw",
    bondAngle: "~90° and ~120°",
    hybridization: "sp³d",
    polarity: "Polar",
    color: "text-orange-600",
    bgColor: "bg-orange-50 border-orange-200",
  },
  "5-2": {
    electronDomains: 5,
    electronGeometry: "Trigonal Bipyramidal",
    molecularGeometry: "T-shaped",
    bondAngle: "~90°",
    hybridization: "sp³d",
    polarity: "Polar",
    color: "text-amber-600",
    bgColor: "bg-amber-50 border-amber-200",
  },
  "5-3": {
    electronDomains: 5,
    electronGeometry: "Trigonal Bipyramidal",
    molecularGeometry: "Linear",
    bondAngle: "180°",
    hybridization: "sp³d",
    polarity: "Nonpolar",
    color: "text-blue-600",
    bgColor: "bg-blue-50 border-blue-200",
  },
  "6-0": {
    electronDomains: 6,
    electronGeometry: "Octahedral",
    molecularGeometry: "Octahedral",
    bondAngle: "90°",
    hybridization: "sp³d²",
    polarity: "Nonpolar (if identical atoms)",
    color: "text-green-600",
    bgColor: "bg-green-50 border-green-200",
  },
  "6-1": {
    electronDomains: 6,
    electronGeometry: "Octahedral",
    molecularGeometry: "Square Pyramidal",
    bondAngle: "~90°",
    hybridization: "sp³d²",
    polarity: "Polar",
    color: "text-purple-600",
    bgColor: "bg-purple-50 border-purple-200",
  },
  "6-2": {
    electronDomains: 6,
    electronGeometry: "Octahedral",
    molecularGeometry: "Square Planar",
    bondAngle: "90°",
    hybridization: "sp³d²",
    polarity: "Nonpolar",
    color: "text-blue-600",
    bgColor: "bg-blue-50 border-blue-200",
  },
}

export function VSEPRShapePredictor() {
  const [bondingPairs, setBondingPairs] = useState("")
  const [lonePairs, setLonePairs] = useState("")
  const [molecularFormula, setMolecularFormula] = useState("")
  const [result, setResult] = useState<VSEPRResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const predictShape = () => {
    setError("")
    setResult(null)

    const bondingNum = parseInt(bondingPairs)
    const loneNum = parseInt(lonePairs)

    if (isNaN(bondingNum) || bondingNum < 0) {
      setError("Please enter a valid number of bonding pairs (0 or greater)")
      return
    }

    if (isNaN(loneNum) || loneNum < 0) {
      setError("Please enter a valid number of lone pairs (0 or greater)")
      return
    }

    if (bondingNum < 2) {
      setError("A molecule needs at least 2 bonding pairs for VSEPR analysis")
      return
    }

    const totalDomains = bondingNum + loneNum

    if (totalDomains < 2 || totalDomains > 6) {
      setError("Total electron domains must be between 2 and 6")
      return
    }

    const key = `${totalDomains}-${loneNum}`
    const prediction = VSEPR_DATA[key]

    if (!prediction) {
      setError("Invalid combination of bonding and lone pairs")
      return
    }

    setResult(prediction)
  }

  const handleReset = () => {
    setBondingPairs("")
    setLonePairs("")
    setMolecularFormula("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `VSEPR Prediction${molecularFormula ? ` for ${molecularFormula}` : ""}: ${result.molecularGeometry} (${result.bondAngle}), Hybridization: ${result.hybridization}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "VSEPR Shape Prediction",
          text: `I predicted a molecular shape using VSEPR theory! ${molecularFormula ? `${molecularFormula}: ` : ""}${result.molecularGeometry} geometry with ${result.bondAngle} bond angles.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Atom className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">VSEPR Shape Predictor</CardTitle>
                    <CardDescription>Predict molecular geometry using VSEPR theory</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Molecular Formula (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="formula">Molecular Formula (optional)</Label>
                  <Input
                    id="formula"
                    type="text"
                    placeholder="e.g., H2O, NH3, CH4"
                    value={molecularFormula}
                    onChange={(e) => setMolecularFormula(e.target.value)}
                  />
                </div>

                {/* Bonding Pairs Input */}
                <div className="space-y-2">
                  <Label htmlFor="bonding">Number of Bonding Pairs</Label>
                  <Input
                    id="bonding"
                    type="number"
                    placeholder="Enter number of bonding pairs on central atom"
                    value={bondingPairs}
                    onChange={(e) => setBondingPairs(e.target.value)}
                    min="0"
                    max="6"
                  />
                </div>

                {/* Lone Pairs Input */}
                <div className="space-y-2">
                  <Label htmlFor="lone">Number of Lone Pairs</Label>
                  <Input
                    id="lone"
                    type="number"
                    placeholder="Enter number of lone pairs on central atom"
                    value={lonePairs}
                    onChange={(e) => setLonePairs(e.target.value)}
                    min="0"
                    max="3"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={predictShape} className="w-full" size="lg">
                  Predict Shape
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Molecular Geometry</p>
                      <p className={`text-3xl font-bold ${result.color} mb-2`}>{result.molecularGeometry}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.bondAngle}</p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg">
                        <p className="text-muted-foreground">Electron Geometry</p>
                        <p className="font-semibold">{result.electronGeometry}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg">
                        <p className="text-muted-foreground">Hybridization</p>
                        <p className="font-semibold">{result.hybridization}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg col-span-2">
                        <p className="text-muted-foreground">Polarity</p>
                        <p className="font-semibold">{result.polarity}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Molecular Shapes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Linear</span>
                      <span className="text-sm text-blue-600">180°</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Trigonal Planar</span>
                      <span className="text-sm text-green-600">120°</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Tetrahedral</span>
                      <span className="text-sm text-purple-600">109.5°</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Trigonal Bipyramidal</span>
                      <span className="text-sm text-orange-600">90°/120°</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Octahedral</span>
                      <span className="text-sm text-yellow-600">90°</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">VSEPR Notation</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">AX<sub>m</sub>E<sub>n</sub></p>
                  </div>
                  <p>
                    <strong>A</strong> = Central atom, <strong>X</strong> = Bonded atoms,{" "}
                    <strong>E</strong> = Lone pairs
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is VSEPR */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is VSEPR Theory?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Valence Shell Electron Pair Repulsion (VSEPR) theory is a model used to predict the three-dimensional
                  geometry of molecules based on the repulsion between electron pairs around a central atom. Developed by
                  Ronald Gillespie and Ronald Nyholm in the 1950s, this theory has become one of the most important concepts
                  in chemistry for understanding molecular shapes and their relationship to chemical properties.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The fundamental principle of VSEPR is that electron pairs (both bonding and non-bonding) around a central
                  atom will arrange themselves to minimize repulsion and maximize the distance between them. This
                  arrangement determines the molecular geometry, which in turn affects properties such as polarity,
                  reactivity, and intermolecular interactions.
                </p>
              </CardContent>
            </Card>

            {/* How VSEPR Works */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shapes className="h-5 w-5 text-primary" />
                  <CardTitle>How VSEPR Predictions Work</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To predict molecular geometry using VSEPR theory, first count the total number of electron domains
                  around the central atom. An electron domain can be a bonding pair (single, double, or triple bond) or
                  a lone pair. The total number of electron domains determines the electron-domain geometry, which describes
                  the arrangement of all electron pairs.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The molecular geometry, however, describes only the arrangement of atoms, not lone pairs. Because lone
                  pairs occupy more space than bonding pairs, they cause greater repulsion, which compresses bond angles.
                  For example, water (H2O) has 4 electron domains (2 bonding + 2 lone pairs), giving it a tetrahedral
                  electron geometry but a bent molecular geometry with a bond angle of about 104.5° instead of 109.5°.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of VSEPR Theory</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  VSEPR theory has numerous practical applications in chemistry and related fields. It helps predict
                  molecular polarity, which is crucial for understanding solubility, boiling points, and intermolecular
                  forces. Polar molecules like water are excellent solvents for ionic compounds, while nonpolar molecules
                  like methane dissolve better in nonpolar solvents.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In biochemistry and drug design, molecular shape is critical for understanding enzyme-substrate
                  interactions and drug-receptor binding. The three-dimensional arrangement of atoms determines whether
                  a molecule can fit into an active site or receptor, making VSEPR predictions essential for rational
                  drug design and understanding biological processes at the molecular level.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations of VSEPR Theory</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While VSEPR theory is remarkably useful for predicting molecular shapes, it has several limitations.
                  The theory works best for main group elements and may not accurately predict geometries for transition
                  metal complexes, where d-orbital participation and crystal field effects become important. Additionally,
                  VSEPR cannot account for subtle distortions caused by differences in electronegativity or multiple
                  bonding.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The theory also assumes that all bonding pairs are equivalent, which is not always true. For instance,
                  in molecules with different types of bonds (single vs. double), the actual geometry may deviate from
                  VSEPR predictions. For more accurate predictions, especially for complex molecules, computational
                  methods like molecular orbital theory or density functional theory are often employed.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Disclaimer:</strong> Predictions are based on idealized VSEPR theory. Actual molecular shapes
                    may vary due to resonance, multiple bonds, or steric effects.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
