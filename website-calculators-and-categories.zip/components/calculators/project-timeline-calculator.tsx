"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, AlertTriangle, Plus, X } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface Task {
  id: string
  name: string
  duration: number
  unit: "days" | "weeks"
}

interface TaskSchedule {
  name: string
  startDate: Date
  endDate: Date
  duration: number
}

export function ProjectTimelineCalculator() {
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [excludeWeekends, setExcludeWeekends] = useState(false)
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", name: "Task 1", duration: 5, unit: "days" }
  ])
  const [result, setResult] = useState<{
    projectDuration: number
    schedule: TaskSchedule[]
  } | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const addTask = () => {
    const newTask: Task = {
      id: Date.now().toString(),
      name: `Task ${tasks.length + 1}`,
      duration: 1,
      unit: "days"
    }
    setTasks([...tasks, newTask])
  }

  const removeTask = (id: string) => {
    if (tasks.length > 1) {
      setTasks(tasks.filter(task => task.id !== id))
    }
  }

  const updateTask = (id: string, field: keyof Task, value: any) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, [field]: value } : task
    ))
  }

  const addDays = (date: Date, days: number, excludeWeekends: boolean): Date => {
    const result = new Date(date)
    let addedDays = 0
    
    while (addedDays < days) {
      result.setDate(result.getDate() + 1)
      if (!excludeWeekends || (result.getDay() !== 0 && result.getDay() !== 6)) {
        addedDays++
      }
    }
    
    return result
  }

  const calculateTimeline = () => {
    setError("")
    setResult(null)

    if (!startDate || !endDate) {
      setError("Please enter both start and end dates")
      return
    }

    const start = new Date(startDate)
    const end = new Date(endDate)

    if (end <= start) {
      setError("End date must be after start date")
      return
    }

    // Calculate project duration
    let projectDuration = 0
    let currentDate = new Date(start)
    while (currentDate < end) {
      currentDate.setDate(currentDate.getDate() + 1)
      if (!excludeWeekends || (currentDate.getDay() !== 0 && currentDate.getDay() !== 6)) {
        projectDuration++
      }
    }

    // Calculate task schedule
    const schedule: TaskSchedule[] = []
    let taskStartDate = new Date(start)

    for (const task of tasks) {
      if (!task.name.trim() || task.duration <= 0) {
        setError("All tasks must have a name and positive duration")
        return
      }

      const durationInDays = task.unit === "weeks" ? task.duration * 7 : task.duration
      const taskEndDate = addDays(taskStartDate, durationInDays, excludeWeekends)

      schedule.push({
        name: task.name,
        startDate: new Date(taskStartDate),
        endDate: taskEndDate,
        duration: durationInDays
      })

      taskStartDate = new Date(taskEndDate)
      taskStartDate.setDate(taskStartDate.getDate() + 1)
    }

    setResult({ projectDuration, schedule })
  }

  const handleReset = () => {
    setStartDate("")
    setEndDate("")
    setExcludeWeekends(false)
    setTasks([{ id: "1", name: "Task 1", duration: 5, unit: "days" }])
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Project Duration: ${result.projectDuration} days\n\nTask Schedule:\n${result.schedule.map(
        (task, i) => `${i + 1}. ${task.name}: ${task.startDate.toLocaleDateString()} - ${task.endDate.toLocaleDateString()}`
      ).join("\n")}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Project Timeline",
          text: `Project Duration: ${result.projectDuration} days with ${tasks.length} tasks scheduled`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", { 
      month: "short", 
      day: "numeric", 
      year: "numeric" 
    })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Project Timeline Calculator</CardTitle>
                    <CardDescription>Plan and schedule project tasks</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="excludeWeekends"
                    checked={excludeWeekends}
                    onCheckedChange={(checked) => setExcludeWeekends(checked as boolean)}
                  />
                  <Label htmlFor="excludeWeekends" className="text-sm font-normal cursor-pointer">
                    Exclude weekends
                  </Label>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Project Tasks</Label>
                    <Button variant="outline" size="sm" onClick={addTask}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Task
                    </Button>
                  </div>

                  <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                    {tasks.map((task, index) => (
                      <div key={task.id} className="flex gap-2 items-start p-3 border rounded-lg bg-muted/30">
                        <div className="flex-1 space-y-2">
                          <Input
                            placeholder="Task name"
                            value={task.name}
                            onChange={(e) => updateTask(task.id, "name", e.target.value)}
                            className="h-8"
                          />
                          <div className="flex gap-2">
                            <Input
                              type="number"
                              placeholder="Duration"
                              value={task.duration}
                              onChange={(e) => updateTask(task.id, "duration", Number(e.target.value))}
                              className="h-8"
                              min="1"
                            />
                            <select
                              value={task.unit}
                              onChange={(e) => updateTask(task.id, "unit", e.target.value)}
                              className="h-8 px-3 rounded-md border border-input bg-background text-sm"
                            >
                              <option value="days">Days</option>
                              <option value="weeks">Weeks</option>
                            </select>
                          </div>
                        </div>
                        {tasks.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeTask(task.id)}
                            className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculateTimeline} className="w-full" size="lg">
                  Generate Timeline
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Project Duration</p>
                      <p className="text-4xl font-bold text-cyan-600">{result.projectDuration}</p>
                      <p className="text-lg font-semibold text-cyan-600">
                        {excludeWeekends ? "business " : ""}days
                      </p>
                    </div>

                    <div className="space-y-2 mb-4">
                      <p className="text-sm font-semibold text-cyan-800">Task Schedule:</p>
                      <div className="space-y-2 max-h-[200px] overflow-y-auto">
                        {result.schedule.map((task, index) => (
                          <div key={index} className="p-3 bg-white rounded-lg border border-cyan-200">
                            <p className="font-medium text-cyan-900 text-sm">{task.name}</p>
                            <p className="text-xs text-cyan-700 mt-1">
                              {formatDate(task.startDate)} → {formatDate(task.endDate)}
                            </p>
                            <p className="text-xs text-cyan-600 mt-1">
                              Duration: {task.duration} {task.duration === 1 ? "day" : "days"}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Project Planning Tips</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-muted-foreground">
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-800 mb-1">Add Buffer Time</p>
                    <p className="text-cyan-700 text-xs">
                      Include 10-20% buffer time for unexpected delays or complications
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-800 mb-1">Break Down Tasks</p>
                    <p className="text-cyan-700 text-xs">
                      Smaller, manageable tasks are easier to track and complete
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-800 mb-1">Consider Dependencies</p>
                    <p className="text-cyan-700 text-xs">
                      Some tasks cannot start until others are completed
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Timeline Calculation</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    The calculator schedules tasks sequentially from the start date, calculating each task's
                    start and end date based on its duration. When "Exclude weekends" is enabled, only business
                    days are counted.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <Card className="mt-8">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-600" />
                <CardTitle>Important Note</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              <p>
                Project timeline calculations are estimates based on entered dates and durations. Results may vary
                depending on holidays, task dependencies, and unforeseen delays. Always build in buffer time for
                realistic project planning.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
