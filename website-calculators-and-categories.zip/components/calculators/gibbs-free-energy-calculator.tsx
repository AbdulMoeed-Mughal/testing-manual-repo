"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Flame, Info, AlertTriangle, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type EnergyUnit = "kJ" | "J"

interface GibbsResult {
  deltaG: number
  spontaneity: string
  color: string
  bgColor: string
  enthalpyContribution: number
  entropyContribution: number
}

export function GibbsFreeEnergyCalculator() {
  const [energyUnit, setEnergyUnit] = useState<EnergyUnit>("kJ")
  const [deltaH, setDeltaH] = useState("")
  const [deltaS, setDeltaS] = useState("")
  const [temperature, setTemperature] = useState("")
  const [result, setResult] = useState<GibbsResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const deltaHNum = Number.parseFloat(deltaH)
    const deltaSNum = Number.parseFloat(deltaS)
    const tempNum = Number.parseFloat(temperature)

    if (isNaN(deltaHNum)) {
      setError("Please enter a valid enthalpy change (ΔH)")
      return
    }

    if (isNaN(deltaSNum)) {
      setError("Please enter a valid entropy change (ΔS)")
      return
    }

    if (isNaN(tempNum) || tempNum <= 0) {
      setError("Please enter a valid temperature greater than 0 K")
      return
    }

    // Convert units if needed
    // ΔH is in kJ/mol or J/mol, ΔS is in J/(mol·K) or kJ/(mol·K)
    // For kJ unit: ΔS should be in kJ/(mol·K), so we convert J to kJ by dividing by 1000
    // For J unit: ΔH should be in J/mol, ΔS in J/(mol·K)
    
    let deltaHValue = deltaHNum
    let deltaSValue = deltaSNum
    
    // Standard: ΔH in kJ, ΔS in J/K, convert ΔS to kJ/K
    if (energyUnit === "kJ") {
      deltaSValue = deltaSNum / 1000 // Convert J/(mol·K) to kJ/(mol·K)
    }

    // ΔG = ΔH - TΔS
    const deltaG = deltaHValue - (tempNum * deltaSValue)
    const enthalpyContribution = deltaHValue
    const entropyContribution = tempNum * deltaSValue

    let spontaneity: string
    let color: string
    let bgColor: string

    if (deltaG < -0.001) {
      spontaneity = "Spontaneous"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (deltaG > 0.001) {
      spontaneity = "Non-spontaneous"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else {
      spontaneity = "At Equilibrium"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    }

    setResult({
      deltaG: Math.round(deltaG * 1000) / 1000,
      spontaneity,
      color,
      bgColor,
      enthalpyContribution: Math.round(enthalpyContribution * 1000) / 1000,
      entropyContribution: Math.round(entropyContribution * 1000) / 1000,
    })
  }

  const handleReset = () => {
    setDeltaH("")
    setDeltaS("")
    setTemperature("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Gibbs Free Energy (ΔG) = ${result.deltaG} ${energyUnit}/mol (${result.spontaneity})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Gibbs Free Energy Result",
          text: `I calculated Gibbs Free Energy using CalcHub! ΔG = ${result.deltaG} ${energyUnit}/mol (${result.spontaneity})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleEnergyUnit = () => {
    setEnergyUnit((prev) => (prev === "kJ" ? "J" : "kJ"))
    setResult(null)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gibbs Free Energy Calculator</CardTitle>
                    <CardDescription>Calculate ΔG to determine reaction spontaneity</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Energy Unit</span>
                  <button
                    onClick={toggleEnergyUnit}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        energyUnit === "J" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        energyUnit === "kJ" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      kJ/mol
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        energyUnit === "J" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      J/mol
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Enthalpy Input */}
                <div className="space-y-2">
                  <Label htmlFor="deltaH">Enthalpy Change (ΔH) in {energyUnit}/mol</Label>
                  <Input
                    id="deltaH"
                    type="number"
                    placeholder={`Enter ΔH in ${energyUnit}/mol`}
                    value={deltaH}
                    onChange={(e) => setDeltaH(e.target.value)}
                    step="0.001"
                  />
                </div>

                {/* Entropy Input */}
                <div className="space-y-2">
                  <Label htmlFor="deltaS">Entropy Change (ΔS) in {energyUnit === "kJ" ? "J" : energyUnit}/(mol·K)</Label>
                  <Input
                    id="deltaS"
                    type="number"
                    placeholder={`Enter ΔS in ${energyUnit === "kJ" ? "J" : energyUnit}/(mol·K)`}
                    value={deltaS}
                    onChange={(e) => setDeltaS(e.target.value)}
                    step="0.001"
                  />
                </div>

                {/* Temperature Input */}
                <div className="space-y-2">
                  <Label htmlFor="temperature">Temperature (K)</Label>
                  <Input
                    id="temperature"
                    type="number"
                    placeholder="Enter temperature in Kelvin"
                    value={temperature}
                    onChange={(e) => setTemperature(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate ΔG
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Gibbs Free Energy (ΔG)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.deltaG} {energyUnit}/mol
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.spontaneity}</p>
                    </div>

                    {/* Breakdown */}
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-white/60 rounded-lg p-2 text-center">
                        <p className="text-muted-foreground">Enthalpy (ΔH)</p>
                        <p className="font-semibold">{result.enthalpyContribution} {energyUnit}/mol</p>
                      </div>
                      <div className="bg-white/60 rounded-lg p-2 text-center">
                        <p className="text-muted-foreground">TΔS Term</p>
                        <p className="font-semibold">{result.entropyContribution} {energyUnit}/mol</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Spontaneity Conditions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Spontaneous</span>
                      <span className="text-sm text-green-600">{"ΔG < 0"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">At Equilibrium</span>
                      <span className="text-sm text-yellow-600">ΔG = 0</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Non-spontaneous</span>
                      <span className="text-sm text-red-600">{"ΔG > 0"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gibbs Free Energy Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ΔG = ΔH - TΔS</p>
                  </div>
                  <p>
                    Where <strong>ΔH</strong> is the enthalpy change, <strong>T</strong> is the absolute temperature in
                    Kelvin, and <strong>ΔS</strong> is the entropy change.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Content Cards */}
          <div className="mt-12 space-y-8">
            {/* What is Gibbs Free Energy */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Gibbs Free Energy?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gibbs free energy (G), named after American scientist Josiah Willard Gibbs, is a thermodynamic
                  potential that measures the maximum amount of reversible work that can be performed by a
                  thermodynamic system at constant temperature and pressure. The change in Gibbs free energy (ΔG)
                  is one of the most important concepts in chemistry because it tells us whether a reaction will
                  occur spontaneously under the given conditions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Gibbs free energy combines two fundamental thermodynamic quantities: enthalpy (H), which
                  represents the heat content of the system, and entropy (S), which represents the degree of
                  disorder or randomness. By accounting for both energy and entropy changes, Gibbs free energy
                  provides a complete picture of whether a process will be thermodynamically favorable.
                </p>
              </CardContent>
            </Card>

            {/* Understanding ΔG Values */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding ΔG Values</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When ΔG is negative, the reaction releases free energy and is thermodynamically favorable,
                  meaning it can occur spontaneously without external energy input. These reactions are called
                  exergonic reactions. Examples include the combustion of fuels and the hydrolysis of ATP in
                  biological systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When ΔG is positive, the reaction requires energy input and is non-spontaneous. These endergonic
                  reactions will not proceed on their own but can be driven by coupling them with exergonic
                  reactions or by supplying external energy. When ΔG equals zero, the system is at equilibrium
                  and there is no net change in the forward or reverse direction.
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting Spontaneity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Spontaneity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Always Spontaneous (ΔG {"<"} 0)</h4>
                    <p className="text-green-700 text-sm">
                      When ΔH {"<"} 0 (exothermic) and ΔS {">"} 0 (entropy increases), the reaction is spontaneous
                      at all temperatures. Both thermodynamic factors favor the forward reaction.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Never Spontaneous (ΔG {">"} 0)</h4>
                    <p className="text-red-700 text-sm">
                      When ΔH {">"} 0 (endothermic) and ΔS {"<"} 0 (entropy decreases), the reaction is
                      non-spontaneous at all temperatures. Both factors oppose the forward reaction.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Temperature Dependent</h4>
                    <p className="text-yellow-700 text-sm">
                      When ΔH and ΔS have the same sign, spontaneity depends on temperature. High temperatures
                      favor entropy-driven reactions, while low temperatures favor enthalpy-driven reactions.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculations assume constant temperature and pressure conditions. Real reactions may vary due
                  to non-ideal behavior, kinetic limitations, or changes in conditions. A negative ΔG indicates
                  thermodynamic favorability but does not guarantee a fast reaction rate. Some spontaneous
                  reactions may be extremely slow without a catalyst. Additionally, standard Gibbs free energy
                  values (ΔG°) assume standard conditions (1 atm, 1 M concentrations) which may differ from
                  actual experimental conditions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
