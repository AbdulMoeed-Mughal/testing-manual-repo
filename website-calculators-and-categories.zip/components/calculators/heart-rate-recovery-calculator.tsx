"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  HeartPulse,
  Info,
  ChevronDown,
  ChevronUp,
  Activity,
  Clock,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface HRRResult {
  hrr: number
  category: string
  color: string
  bgColor: string
  recommendation: string
}

export function HeartRateRecoveryCalculator() {
  const [peakHeartRate, setPeakHeartRate] = useState("")
  const [recoveryHeartRate, setRecoveryHeartRate] = useState("")
  const [age, setAge] = useState("")
  const [exerciseType, setExerciseType] = useState("moderate")
  const [result, setResult] = useState<HRRResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateHRR = () => {
    setError("")
    setResult(null)

    const peakHR = Number.parseFloat(peakHeartRate)
    const recoveryHR = Number.parseFloat(recoveryHeartRate)

    if (isNaN(peakHR) || peakHR <= 0) {
      setError("Please enter a valid peak heart rate greater than 0")
      return
    }

    if (isNaN(recoveryHR) || recoveryHR <= 0) {
      setError("Please enter a valid recovery heart rate greater than 0")
      return
    }

    if (recoveryHR >= peakHR) {
      setError("Recovery heart rate must be lower than peak heart rate")
      return
    }

    if (peakHR > 250 || recoveryHR > 250) {
      setError("Heart rate values seem too high. Please verify your inputs")
      return
    }

    const hrr = peakHR - recoveryHR

    let category: string
    let color: string
    let bgColor: string
    let recommendation: string

    if (hrr >= 50) {
      category = "Excellent"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      recommendation =
        "Your cardiovascular fitness is excellent! Your heart recovers very quickly after exercise, indicating strong heart health and aerobic conditioning."
    } else if (hrr >= 41) {
      category = "Good"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
      recommendation =
        "Your heart rate recovery is good. Continue your current exercise routine and consider adding variety to maintain and improve your cardiovascular health."
    } else if (hrr >= 31) {
      category = "Average"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
      recommendation =
        "Your heart rate recovery is average. Consider increasing your aerobic exercise frequency and intensity gradually to improve cardiovascular fitness."
    } else if (hrr >= 21) {
      category = "Below Average"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
      recommendation =
        "Your heart rate recovery is below average. Focus on regular aerobic exercise like walking, cycling, or swimming to improve your cardiovascular health."
    } else {
      category = "Poor"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
      recommendation =
        "Your heart rate recovery is poor. This may indicate reduced cardiovascular fitness. Consult a healthcare provider before starting an exercise program."
    }

    setResult({ hrr, category, color, bgColor, recommendation })
  }

  const handleReset = () => {
    setPeakHeartRate("")
    setRecoveryHeartRate("")
    setAge("")
    setExerciseType("moderate")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`My Heart Rate Recovery is ${result.hrr} bpm (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Heart Rate Recovery Result",
          text: `I calculated my Heart Rate Recovery using CalcHub! My HRR is ${result.hrr} bpm (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <HeartPulse className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Heart Rate Recovery Calculator</CardTitle>
                    <CardDescription>Measure your cardiovascular fitness</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Peak Heart Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="peakHeartRate">Heart Rate Immediately After Exercise (bpm)</Label>
                  <Input
                    id="peakHeartRate"
                    type="number"
                    placeholder="e.g., 160"
                    value={peakHeartRate}
                    onChange={(e) => setPeakHeartRate(e.target.value)}
                    min="0"
                    max="250"
                  />
                </div>

                {/* Recovery Heart Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="recoveryHeartRate">Heart Rate After 1 Minute (bpm)</Label>
                  <Input
                    id="recoveryHeartRate"
                    type="number"
                    placeholder="e.g., 120"
                    value={recoveryHeartRate}
                    onChange={(e) => setRecoveryHeartRate(e.target.value)}
                    min="0"
                    max="250"
                  />
                </div>

                {/* Optional Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (optional)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="0"
                    max="120"
                  />
                </div>

                {/* Exercise Type Selection */}
                <div className="space-y-2">
                  <Label htmlFor="exerciseType">Exercise Intensity (optional)</Label>
                  <Select value={exerciseType} onValueChange={setExerciseType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select intensity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light (Walking, Yoga)</SelectItem>
                      <SelectItem value="moderate">Moderate (Jogging, Cycling)</SelectItem>
                      <SelectItem value="vigorous">Vigorous (Running, HIIT)</SelectItem>
                      <SelectItem value="maximal">Maximal (Sprint, Stress Test)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateHRR} className="w-full" size="lg">
                  Calculate HRR
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Heart Rate Recovery</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>
                        {result.hrr} <span className="text-2xl">bpm</span>
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Peak Heart Rate:</span>
                          <span className="font-medium">{peakHeartRate} bpm</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Recovery Heart Rate (1 min):</span>
                          <span className="font-medium">{recoveryHeartRate} bpm</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Heart Rate Drop:</span>
                          <span className="font-medium">{result.hrr} bpm</span>
                        </div>
                        {age && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Age:</span>
                            <span className="font-medium">{age} years</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Exercise Intensity:</span>
                          <span className="font-medium capitalize">{exerciseType}</span>
                        </div>
                        <div className="mt-3 p-3 bg-white/50 rounded-lg">
                          <p className="text-muted-foreground">{result.recommendation}</p>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">HRR Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent</span>
                      <span className="text-sm text-green-600">≥ 50 bpm</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Good</span>
                      <span className="text-sm text-blue-600">41 – 49 bpm</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Average</span>
                      <span className="text-sm text-yellow-600">31 – 40 bpm</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Below Average</span>
                      <span className="text-sm text-orange-600">21 – 30 bpm</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Poor</span>
                      <span className="text-sm text-red-600">≤ 20 bpm</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How to Measure HRR</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-medium">
                        1
                      </span>
                      <p>Exercise at moderate to vigorous intensity for at least 10-15 minutes</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-medium">
                        2
                      </span>
                      <p>Record your heart rate immediately after stopping exercise</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-medium">
                        3
                      </span>
                      <p>Rest completely (sit or stand still) for exactly 1 minute</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-medium">
                        4
                      </span>
                      <p>Record your heart rate again after the 1-minute recovery period</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">HRR Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">HRR = Peak HR − Recovery HR (after 1 min)</p>
                  </div>
                  <p>A higher HRR indicates better cardiovascular fitness and autonomic nervous system function.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Heart Rate Recovery (HRR)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Heart Rate Recovery (HRR) is a measure of how quickly your heart rate decreases after stopping
                  exercise. It reflects your cardiovascular fitness level and the efficiency of your autonomic nervous
                  system, particularly the parasympathetic branch that helps your body return to a resting state. A
                  faster recovery indicates better heart health and aerobic conditioning.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  HRR is measured by calculating the difference between your heart rate immediately after exercise (peak
                  heart rate) and your heart rate after a specific recovery period, typically one minute. This simple
                  test provides valuable insights into your cardiovascular fitness without requiring specialized
                  equipment.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Why is HRR Important?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Research has shown that heart rate recovery is a powerful predictor of cardiovascular health and
                  mortality risk. A slow heart rate recovery (less than 12-20 bpm in the first minute) has been
                  associated with increased risk of death from cardiovascular causes. Conversely, a rapid recovery
                  indicates good vagal tone and cardiovascular fitness.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Benefits of Good HRR</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Lower cardiovascular disease risk</li>
                      <li>• Better exercise tolerance</li>
                      <li>• Improved autonomic function</li>
                      <li>• Enhanced overall fitness</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Factors Affecting HRR</h4>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>• Fitness level and training</li>
                      <li>• Age and genetics</li>
                      <li>• Medications (beta blockers)</li>
                      <li>• Health conditions</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>How to Improve Your HRR</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Improving your heart rate recovery is possible through consistent aerobic exercise and healthy
                  lifestyle choices. Here are evidence-based strategies to enhance your cardiovascular fitness and HRR:
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Regular Aerobic Exercise</p>
                    <p className="text-sm text-muted-foreground">
                      Aim for 150+ minutes of moderate or 75+ minutes of vigorous aerobic activity per week.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">High-Intensity Interval Training (HIIT)</p>
                    <p className="text-sm text-muted-foreground">
                      Include 1-2 HIIT sessions per week to boost cardiovascular adaptations.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Proper Cool-Down</p>
                    <p className="text-sm text-muted-foreground">
                      Always include a gradual cool-down period after intense exercise.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Stress Management</p>
                    <p className="text-sm text-muted-foreground">
                      Practice relaxation techniques to improve parasympathetic tone.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Adequate Sleep</p>
                    <p className="text-sm text-muted-foreground">
                      Get 7-9 hours of quality sleep for optimal recovery and heart health.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-yellow-600 shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-medium mb-1">Disclaimer</p>
                    <p>
                      Heart rate recovery is an estimate of cardiovascular fitness and may vary based on health,
                      medications, or exercise conditions. This calculator is for informational purposes only and should
                      not replace professional medical advice. Consult a healthcare professional for precise assessment
                      and before starting any exercise program.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
