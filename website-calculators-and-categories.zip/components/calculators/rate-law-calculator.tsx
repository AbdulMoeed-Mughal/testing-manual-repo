"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Activity,
  Plus,
  X,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type ConcentrationUnit = "M" | "mM" | "mol/L"

interface Reactant {
  id: string
  name: string
  concentration: string
  order: string
}

interface RateLawResult {
  rate: number
  rateConstant: number
  reactants: Reactant[]
  overallOrder: number
  concentrationUnit: ConcentrationUnit
}

export function RateLawCalculator() {
  const [rateConstant, setRateConstant] = useState("")
  const [concentrationUnit, setConcentrationUnit] = useState<ConcentrationUnit>("M")
  const [reactants, setReactants] = useState<Reactant[]>([
    { id: "1", name: "A", concentration: "", order: "1" },
  ])
  const [result, setResult] = useState<RateLawResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  const addReactant = () => {
    const nextLetter = String.fromCharCode(65 + reactants.length) // A, B, C, ...
    setReactants([
      ...reactants,
      {
        id: Date.now().toString(),
        name: nextLetter,
        concentration: "",
        order: "1",
      },
    ])
    setResult(null)
  }

  const removeReactant = (id: string) => {
    if (reactants.length > 1) {
      setReactants(reactants.filter((r) => r.id !== id))
      setResult(null)
    }
  }

  const updateReactant = (id: string, field: keyof Reactant, value: string) => {
    setReactants(reactants.map((r) => (r.id === id ? { ...r, [field]: value } : r)))
    setResult(null)
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const k = Number.parseFloat(rateConstant)

    // Validation
    if (isNaN(k) || k <= 0) {
      setError("Please enter a valid rate constant (> 0)")
      return
    }

    const validatedReactants: Reactant[] = []
    let overallOrder = 0

    for (const reactant of reactants) {
      const concentration = Number.parseFloat(reactant.concentration)
      const order = Number.parseFloat(reactant.order)

      if (isNaN(concentration) || concentration < 0) {
        setError(`Please enter a valid concentration for ${reactant.name} (≥ 0)`)
        return
      }

      if (isNaN(order)) {
        setError(`Please enter a valid reaction order for ${reactant.name}`)
        return
      }

      validatedReactants.push(reactant)
      overallOrder += order
    }

    // Calculate rate using the rate law: Rate = k × [A]^m × [B]^n × ...
    let rate = k
    for (const reactant of validatedReactants) {
      const concentration = Number.parseFloat(reactant.concentration)
      const order = Number.parseFloat(reactant.order)
      rate *= Math.pow(concentration, order)
    }

    setResult({
      rate,
      rateConstant: k,
      reactants: validatedReactants,
      overallOrder,
      concentrationUnit,
    })
  }

  const handleReset = () => {
    setRateConstant("")
    setReactants([{ id: "1", name: "A", concentration: "", order: "1" }])
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(true)
  }

  const handleCopy = async () => {
    if (result) {
      const rateUnit = `${result.concentrationUnit}/s`
      const text = `Reaction Rate: ${formatNumber(result.rate)} ${rateUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const rateUnit = `${result.concentrationUnit}/s`
        await navigator.share({
          title: "Rate Law Calculator Result",
          text: `I calculated a reaction rate of ${formatNumber(result.rate)} ${rateUnit} using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 6 })
  }

  const getRateLawExpression = () => {
    if (reactants.length === 0) return "Rate = k"
    const terms = reactants.map((r) => {
      const order = Number.parseFloat(r.order)
      if (isNaN(order) || order === 0) return ""
      if (order === 1) return `[${r.name}]`
      return `[${r.name}]^${order}`
    })
    return `Rate = k × ${terms.filter((t) => t !== "").join(" × ")}`
  }

  const getStepByStepCalculation = () => {
    if (!result) return []
    const steps = [`Rate = k × ${result.reactants.map((r) => `[${r.name}]^${r.order}`).join(" × ")}`]

    const substituted = `Rate = ${formatNumber(result.rateConstant)} × ${result.reactants
      .map((r) => {
        const order = Number.parseFloat(r.order)
        if (order === 1) {
          return formatNumber(Number.parseFloat(r.concentration))
        }
        return `(${formatNumber(Number.parseFloat(r.concentration))})^${order}`
      })
      .join(" × ")}`
    steps.push(substituted)

    const calculated = result.reactants.map((r) => {
      const concentration = Number.parseFloat(r.concentration)
      const order = Number.parseFloat(r.order)
      const value = Math.pow(concentration, order)
      return `[${r.name}]^${order} = ${formatNumber(value)}`
    })
    steps.push(...calculated)

    steps.push(`Rate = ${formatNumber(result.rate)} ${result.concentrationUnit}/s`)

    return steps
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Rate Law Calculator</CardTitle>
                    <CardDescription>Determine reaction rate from rate law</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Rate Constant Input */}
                <div className="space-y-2">
                  <Label htmlFor="rateConstant">Rate Constant (k)</Label>
                  <Input
                    id="rateConstant"
                    type="number"
                    placeholder="Enter rate constant"
                    value={rateConstant}
                    onChange={(e) => setRateConstant(e.target.value)}
                    min="0"
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">
                    Units depend on overall order (e.g., M⁻¹s⁻¹ for 2nd order)
                  </p>
                </div>

                {/* Concentration Unit Selector */}
                <div className="space-y-2">
                  <Label>Concentration Unit</Label>
                  <Select value={concentrationUnit} onValueChange={(v) => setConcentrationUnit(v as ConcentrationUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M">Molar (M)</SelectItem>
                      <SelectItem value="mM">Millimolar (mM)</SelectItem>
                      <SelectItem value="mol/L">mol/L</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Reactants Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Reactants</Label>
                    {reactants.length < 5 && (
                      <Button variant="outline" size="sm" onClick={addReactant}>
                        <Plus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                    )}
                  </div>

                  {reactants.map((reactant, index) => (
                    <div key={reactant.id} className="p-3 rounded-lg border bg-muted/50 space-y-2">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Reactant {reactant.name}</span>
                        {reactants.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeReactant(reactant.id)}
                            className="h-6 w-6 p-0"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label htmlFor={`concentration-${reactant.id}`} className="text-xs">
                            [{reactant.name}] ({concentrationUnit})
                          </Label>
                          <Input
                            id={`concentration-${reactant.id}`}
                            type="number"
                            placeholder="Concentration"
                            value={reactant.concentration}
                            onChange={(e) => updateReactant(reactant.id, "concentration", e.target.value)}
                            min="0"
                            step="any"
                            className="h-9"
                          />
                        </div>

                        <div className="space-y-1">
                          <Label htmlFor={`order-${reactant.id}`} className="text-xs">
                            Order (m, n)
                          </Label>
                          <Input
                            id={`order-${reactant.id}`}
                            type="number"
                            placeholder="Order"
                            value={reactant.order}
                            onChange={(e) => updateReactant(reactant.id, "order", e.target.value)}
                            step="any"
                            className="h-9"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Rate Law Expression Preview */}
                <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                  <p className="text-xs text-purple-600 mb-1">Rate Law Expression:</p>
                  <p className="font-mono text-sm font-semibold text-purple-700">{getRateLawExpression()}</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Reaction Rate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Reaction Rate</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">{formatNumber(result.rate)}</p>
                      <p className="text-lg font-medium text-purple-500">
                        {result.concentrationUnit}/s
                      </p>
                      <p className="text-sm text-purple-600 mt-2 flex items-center justify-center gap-1">
                        <Activity className="h-4 w-4" />
                        Overall Order: {result.overallOrder}
                      </p>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-purple-100">
                        <p className="text-sm font-medium text-purple-700 mb-2">Step-by-step Solution:</p>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          {getStepByStepCalculation().map((step, index) => (
                            <p key={index} className={index === getStepByStepCalculation().length - 1 ? "font-medium text-purple-600 mt-2" : "font-mono"}>
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rate Law Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-mono font-semibold text-purple-700 text-center text-sm">
                      Rate = k × [A]^m × [B]^n
                    </p>
                    <p className="text-xs text-purple-600 text-center mt-1">General rate law expression</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p><strong>k</strong> = rate constant</p>
                    <p><strong>[A], [B]</strong> = reactant concentrations</p>
                    <p><strong>m, n</strong> = reaction orders (experimentally determined)</p>
                    <p><strong>Overall order</strong> = m + n</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Info className="h-5 w-5" />
                    Understanding Rate Laws
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div>
                    <p className="font-medium text-foreground mb-1">What is a Rate Law?</p>
                    <p>
                      The rate law expresses how the reaction rate depends on the concentrations of reactants. It is
                      experimentally determined and cannot be inferred from stoichiometry alone.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Reaction Order</p>
                    <p>
                      The order with respect to each reactant indicates how the rate changes with concentration. A
                      first-order reaction doubles in rate when concentration doubles.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Rate Constant (k)</p>
                    <p>
                      The rate constant is specific to each reaction and changes with temperature. Its units depend on
                      the overall reaction order.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rate Constant Units</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between">
                    <span>Zero order</span>
                    <span className="font-mono">M/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span>First order</span>
                    <span className="font-mono">s⁻¹</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Second order</span>
                    <span className="font-mono">M⁻¹s⁻¹</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Third order</span>
                    <span className="font-mono">M⁻²s⁻¹</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="space-y-2 text-sm text-amber-900">
                      <p className="font-medium">Important Note</p>
                      <p>
                        Rate law expressions are experimentally determined. Calculated rates are theoretical and assume
                        ideal reaction conditions. The reaction order cannot be determined from balanced chemical
                        equations and must be found experimentally.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
