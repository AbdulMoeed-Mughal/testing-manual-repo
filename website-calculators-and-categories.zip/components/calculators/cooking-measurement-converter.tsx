"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, ChefHat, Info, ArrowRightLeft, Thermometer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type ConversionType = "volume" | "weight" | "temperature"

interface ConversionResult {
  value: number
  unit: string
  type: ConversionType
}

// Volume conversions to milliliters (base unit)
const volumeToML: Record<string, number> = {
  ml: 1,
  liter: 1000,
  tsp: 4.929,
  tbsp: 14.787,
  "fl-oz": 29.574,
  cup: 236.588,
  pint: 473.176,
  quart: 946.353,
  gallon: 3785.41,
}

// Weight conversions to grams (base unit)
const weightToGrams: Record<string, number> = {
  g: 1,
  kg: 1000,
  mg: 0.001,
  oz: 28.3495,
  lb: 453.592,
}

// Ingredient densities (grams per cup)
const ingredientDensities: Record<string, { name: string; gramsPerCup: number }> = {
  "all-purpose-flour": { name: "All-Purpose Flour", gramsPerCup: 125 },
  "bread-flour": { name: "Bread Flour", gramsPerCup: 127 },
  "cake-flour": { name: "Cake Flour", gramsPerCup: 114 },
  "granulated-sugar": { name: "Granulated Sugar", gramsPerCup: 200 },
  "brown-sugar": { name: "Brown Sugar (packed)", gramsPerCup: 220 },
  "powdered-sugar": { name: "Powdered Sugar", gramsPerCup: 120 },
  butter: { name: "Butter", gramsPerCup: 227 },
  honey: { name: "Honey", gramsPerCup: 340 },
  "maple-syrup": { name: "Maple Syrup", gramsPerCup: 322 },
  milk: { name: "Milk", gramsPerCup: 244 },
  water: { name: "Water", gramsPerCup: 237 },
  "vegetable-oil": { name: "Vegetable Oil", gramsPerCup: 218 },
  "olive-oil": { name: "Olive Oil", gramsPerCup: 216 },
  "cocoa-powder": { name: "Cocoa Powder", gramsPerCup: 85 },
  "rolled-oats": { name: "Rolled Oats", gramsPerCup: 90 },
  rice: { name: "Rice (uncooked)", gramsPerCup: 185 },
  "chocolate-chips": { name: "Chocolate Chips", gramsPerCup: 170 },
  "peanut-butter": { name: "Peanut Butter", gramsPerCup: 258 },
  yogurt: { name: "Yogurt", gramsPerCup: 245 },
  "sour-cream": { name: "Sour Cream", gramsPerCup: 242 },
}

const volumeUnits = [
  { value: "tsp", label: "Teaspoon (tsp)" },
  { value: "tbsp", label: "Tablespoon (tbsp)" },
  { value: "fl-oz", label: "Fluid Ounce (fl oz)" },
  { value: "cup", label: "Cup" },
  { value: "pint", label: "Pint" },
  { value: "quart", label: "Quart" },
  { value: "gallon", label: "Gallon" },
  { value: "ml", label: "Milliliter (ml)" },
  { value: "liter", label: "Liter (L)" },
]

const weightUnits = [
  { value: "g", label: "Gram (g)" },
  { value: "kg", label: "Kilogram (kg)" },
  { value: "mg", label: "Milligram (mg)" },
  { value: "oz", label: "Ounce (oz)" },
  { value: "lb", label: "Pound (lb)" },
]

export function CookingMeasurementConverter() {
  const [conversionType, setConversionType] = useState<ConversionType>("volume")
  const [inputValue, setInputValue] = useState("")
  const [fromUnit, setFromUnit] = useState("cup")
  const [toUnit, setToUnit] = useState("ml")
  const [ingredient, setIngredient] = useState("")
  const [tempFrom, setTempFrom] = useState<"celsius" | "fahrenheit">("celsius")
  const [tempTo, setTempTo] = useState<"celsius" | "fahrenheit">("fahrenheit")
  const [result, setResult] = useState<ConversionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const convert = () => {
    setError("")
    setResult(null)

    const value = Number.parseFloat(inputValue)
    if (isNaN(value) || value < 0) {
      setError("Please enter a valid positive number")
      return
    }

    if (conversionType === "temperature") {
      let convertedValue: number
      if (tempFrom === "celsius" && tempTo === "fahrenheit") {
        convertedValue = (value * 9) / 5 + 32
      } else if (tempFrom === "fahrenheit" && tempTo === "celsius") {
        convertedValue = ((value - 32) * 5) / 9
      } else {
        convertedValue = value
      }
      setResult({
        value: Math.round(convertedValue * 100) / 100,
        unit: tempTo === "celsius" ? "°C" : "°F",
        type: "temperature",
      })
      return
    }

    if (conversionType === "volume") {
      // Check if we need ingredient for volume-to-weight conversion
      const isFromVolume = fromUnit in volumeToML
      const isToWeight = toUnit in weightToGrams

      if (isFromVolume && isToWeight) {
        if (!ingredient) {
          setError("Please select an ingredient for volume-to-weight conversion")
          return
        }
        // Convert volume to weight using ingredient density
        const mlValue = value * volumeToML[fromUnit]
        const cupValue = mlValue / volumeToML["cup"]
        const gramsValue = cupValue * ingredientDensities[ingredient].gramsPerCup
        const convertedValue = gramsValue / weightToGrams[toUnit]
        setResult({
          value: Math.round(convertedValue * 100) / 100,
          unit: toUnit,
          type: "weight",
        })
        return
      }

      // Volume to volume conversion
      if (isFromVolume && toUnit in volumeToML) {
        const mlValue = value * volumeToML[fromUnit]
        const convertedValue = mlValue / volumeToML[toUnit]
        setResult({
          value: Math.round(convertedValue * 1000) / 1000,
          unit: toUnit,
          type: "volume",
        })
        return
      }
    }

    if (conversionType === "weight") {
      // Check if we need ingredient for weight-to-volume conversion
      const isFromWeight = fromUnit in weightToGrams
      const isToVolume = toUnit in volumeToML

      if (isFromWeight && isToVolume) {
        if (!ingredient) {
          setError("Please select an ingredient for weight-to-volume conversion")
          return
        }
        // Convert weight to volume using ingredient density
        const gramsValue = value * weightToGrams[fromUnit]
        const cupValue = gramsValue / ingredientDensities[ingredient].gramsPerCup
        const mlValue = cupValue * volumeToML["cup"]
        const convertedValue = mlValue / volumeToML[toUnit]
        setResult({
          value: Math.round(convertedValue * 1000) / 1000,
          unit: toUnit,
          type: "volume",
        })
        return
      }

      // Weight to weight conversion
      if (isFromWeight && toUnit in weightToGrams) {
        const gramsValue = value * weightToGrams[fromUnit]
        const convertedValue = gramsValue / weightToGrams[toUnit]
        setResult({
          value: Math.round(convertedValue * 1000) / 1000,
          unit: toUnit,
          type: "weight",
        })
        return
      }
    }

    setError("Invalid conversion. Please check your unit selections.")
  }

  const handleReset = () => {
    setInputValue("")
    setFromUnit(conversionType === "volume" ? "cup" : conversionType === "weight" ? "g" : "cup")
    setToUnit(conversionType === "volume" ? "ml" : conversionType === "weight" ? "oz" : "ml")
    setIngredient("")
    setTempFrom("celsius")
    setTempTo("fahrenheit")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`${result.value} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const swapUnits = () => {
    if (conversionType === "temperature") {
      setTempFrom(tempTo)
      setTempTo(tempFrom)
    } else {
      const temp = fromUnit
      setFromUnit(toUnit)
      setToUnit(temp)
    }
    setResult(null)
  }

  const handleTypeChange = (type: ConversionType) => {
    setConversionType(type)
    setResult(null)
    setError("")
    setIngredient("")
    if (type === "volume") {
      setFromUnit("cup")
      setToUnit("ml")
    } else if (type === "weight") {
      setFromUnit("g")
      setToUnit("oz")
    }
  }

  const getUnitLabel = (unit: string): string => {
    const vol = volumeUnits.find((u) => u.value === unit)
    if (vol) return vol.label
    const wt = weightUnits.find((u) => u.value === unit)
    if (wt) return wt.label
    return unit
  }

  // Determine if ingredient selection is needed
  const needsIngredient =
    conversionType !== "temperature" &&
    ((fromUnit in volumeToML && toUnit in weightToGrams) || (fromUnit in weightToGrams && toUnit in volumeToML))

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/lifestyle-daily">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Lifestyle & Daily Use
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <ChefHat className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Cooking Measurement Converter</CardTitle>
                    <CardDescription>Convert cooking units with ease</CardDescription>
                  </div>
                </div>

                {/* Conversion Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Conversion Type</span>
                  <div className="flex gap-1 p-1 bg-muted rounded-lg">
                    {(["volume", "weight", "temperature"] as ConversionType[]).map((type) => (
                      <button
                        key={type}
                        onClick={() => handleTypeChange(type)}
                        className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                          conversionType === type
                            ? "bg-primary text-primary-foreground shadow-sm"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Value Input */}
                <div className="space-y-2">
                  <Label htmlFor="value">Value</Label>
                  <Input
                    id="value"
                    type="number"
                    placeholder="Enter value to convert"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Temperature Conversion */}
                {conversionType === "temperature" ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-[1fr,auto,1fr] gap-2 items-end">
                      <div className="space-y-2">
                        <Label>From</Label>
                        <Select value={tempFrom} onValueChange={(v) => setTempFrom(v as "celsius" | "fahrenheit")}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="celsius">Celsius (°C)</SelectItem>
                            <SelectItem value="fahrenheit">Fahrenheit (°F)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <Button variant="outline" size="icon" onClick={swapUnits} className="mb-0.5 bg-transparent">
                        <ArrowRightLeft className="h-4 w-4" />
                      </Button>

                      <div className="space-y-2">
                        <Label>To</Label>
                        <Select value={tempTo} onValueChange={(v) => setTempTo(v as "celsius" | "fahrenheit")}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="celsius">Celsius (°C)</SelectItem>
                            <SelectItem value="fahrenheit">Fahrenheit (°F)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                ) : (
                  <>
                    {/* Volume/Weight Conversion */}
                    <div className="grid grid-cols-[1fr,auto,1fr] gap-2 items-end">
                      <div className="space-y-2">
                        <Label>From</Label>
                        <Select value={fromUnit} onValueChange={setFromUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <div className="px-2 py-1 text-xs font-semibold text-muted-foreground">Volume</div>
                            {volumeUnits.map((unit) => (
                              <SelectItem key={unit.value} value={unit.value}>
                                {unit.label}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-muted-foreground border-t mt-1 pt-2">
                              Weight
                            </div>
                            {weightUnits.map((unit) => (
                              <SelectItem key={unit.value} value={unit.value}>
                                {unit.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <Button variant="outline" size="icon" onClick={swapUnits} className="mb-0.5 bg-transparent">
                        <ArrowRightLeft className="h-4 w-4" />
                      </Button>

                      <div className="space-y-2">
                        <Label>To</Label>
                        <Select value={toUnit} onValueChange={setToUnit}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <div className="px-2 py-1 text-xs font-semibold text-muted-foreground">Volume</div>
                            {volumeUnits.map((unit) => (
                              <SelectItem key={unit.value} value={unit.value}>
                                {unit.label}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-muted-foreground border-t mt-1 pt-2">
                              Weight
                            </div>
                            {weightUnits.map((unit) => (
                              <SelectItem key={unit.value} value={unit.value}>
                                {unit.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Ingredient Selection (for volume-to-weight conversions) */}
                    {needsIngredient && (
                      <div className="space-y-2">
                        <Label htmlFor="ingredient">Ingredient (required for volume-weight conversion)</Label>
                        <Select value={ingredient} onValueChange={setIngredient}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select an ingredient" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(ingredientDensities).map(([key, { name }]) => (
                              <SelectItem key={key} value={key}>
                                {name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Convert Button */}
                <Button onClick={convert} className="w-full" size="lg">
                  Convert
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <p className="text-4xl font-bold text-amber-700 mb-1">
                        {result.value.toLocaleString(undefined, { maximumFractionDigits: 4 })}
                      </p>
                      <p className="text-lg font-semibold text-amber-600">{getUnitLabel(result.unit)}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>

                    {/* Calculation Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full text-amber-700">
                          {showBreakdown ? "Hide" : "Show"} Conversion Details
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="p-3 bg-white rounded-lg text-sm space-y-2">
                          <p className="font-medium text-foreground">Conversion Steps:</p>
                          {conversionType === "temperature" ? (
                            <div className="text-muted-foreground">
                              {tempFrom === "celsius" && tempTo === "fahrenheit" && (
                                <>
                                  <p>1. Formula: °F = (°C × 9/5) + 32</p>
                                  <p>
                                    2. ({inputValue} × 9/5) + 32 = {result.value}°F
                                  </p>
                                </>
                              )}
                              {tempFrom === "fahrenheit" && tempTo === "celsius" && (
                                <>
                                  <p>1. Formula: °C = (°F − 32) × 5/9</p>
                                  <p>
                                    2. ({inputValue} − 32) × 5/9 = {result.value}°C
                                  </p>
                                </>
                              )}
                            </div>
                          ) : needsIngredient && ingredient ? (
                            <div className="text-muted-foreground">
                              <p>1. Ingredient: {ingredientDensities[ingredient].name}</p>
                              <p>2. Density: {ingredientDensities[ingredient].gramsPerCup} g/cup</p>
                              <p>
                                3. Convert {inputValue} {getUnitLabel(fromUnit)} → {result.value}{" "}
                                {getUnitLabel(result.unit)}
                              </p>
                            </div>
                          ) : (
                            <div className="text-muted-foreground">
                              <p>
                                1. Input: {inputValue} {getUnitLabel(fromUnit)}
                              </p>
                              <p>
                                2. Result: {result.value} {getUnitLabel(result.unit)}
                              </p>
                            </div>
                          )}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Volume Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1 cup</span>
                      <span className="text-muted-foreground">= 16 tbsp = 48 tsp = 237 ml</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1 tablespoon</span>
                      <span className="text-muted-foreground">= 3 tsp = 15 ml</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1 fluid ounce</span>
                      <span className="text-muted-foreground">= 2 tbsp = 30 ml</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1 pint</span>
                      <span className="text-muted-foreground">= 2 cups = 473 ml</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1 quart</span>
                      <span className="text-muted-foreground">= 4 cups = 946 ml</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Thermometer className="h-5 w-5 text-amber-600" />
                    <CardTitle className="text-lg">Common Cooking Temperatures</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Water boils</span>
                      <span className="text-muted-foreground">100°C / 212°F</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Baking (moderate)</span>
                      <span className="text-muted-foreground">180°C / 350°F</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Roasting</span>
                      <span className="text-muted-foreground">200°C / 400°F</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Broiling</span>
                      <span className="text-muted-foreground">260°C / 500°F</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Ingredient Weights (per cup)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>All-Purpose Flour</span>
                      <span className="text-muted-foreground">125g / 4.4oz</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Granulated Sugar</span>
                      <span className="text-muted-foreground">200g / 7oz</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Butter</span>
                      <span className="text-muted-foreground">227g / 8oz</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Honey</span>
                      <span className="text-muted-foreground">340g / 12oz</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Cooking Measurements</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Cooking measurements can vary significantly between different countries and measurement systems. The
                  United States primarily uses volume measurements like cups, tablespoons, and teaspoons, while many
                  other countries prefer weight-based measurements in grams and kilograms. Understanding how to convert
                  between these systems is essential for successfully following recipes from around the world.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Volume-to-weight conversions are particularly important because different ingredients have different
                  densities. A cup of flour weighs much less than a cup of honey, for example. For precise baking, many
                  professional bakers recommend using weight measurements as they are more accurate and consistent than
                  volume measurements.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ChefHat className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Measuring</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">For Dry Ingredients</h4>
                    <ul className="text-amber-700 text-sm space-y-1">
                      <li>Spoon flour into measuring cup, don't scoop</li>
                      <li>Level off with a straight edge</li>
                      <li>Don't pack unless recipe specifies</li>
                      <li>Use dry measuring cups for accuracy</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">For Liquid Ingredients</h4>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>Use liquid measuring cups (with spout)</li>
                      <li>Place cup on flat surface</li>
                      <li>Read at eye level at the meniscus</li>
                      <li>Pour slowly to avoid over-measuring</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Note:</strong> Conversions are approximate, especially for volume-to-weight, which may vary
                  depending on ingredient density, humidity, how ingredients are measured (packed vs. sifted), and
                  regional differences in measuring cup sizes. For critical baking applications, weighing ingredients
                  with a kitchen scale is recommended for best results.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
