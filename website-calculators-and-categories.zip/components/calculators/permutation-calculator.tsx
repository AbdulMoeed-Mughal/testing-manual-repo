"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Shuffle,
  Info,
  AlertTriangle,
  Calculator,
  BookOpen,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface PermutationResult {
  value: string
  formula: string
  steps: string[]
}

export function PermutationCalculator() {
  const [n, setN] = useState("")
  const [r, setR] = useState("")
  const [allowRepetition, setAllowRepetition] = useState(false)
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<PermutationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  // Calculate factorial
  const factorial = (num: number): bigint => {
    if (num <= 1) return BigInt(1)
    let result = BigInt(1)
    for (let i = 2; i <= num; i++) {
      result *= BigInt(i)
    }
    return result
  }

  // Format large numbers
  const formatNumber = (num: bigint): string => {
    const str = num.toString()
    if (str.length > 20) {
      const exp = str.length - 1
      const mantissa = str[0] + "." + str.slice(1, 5)
      return `${mantissa} × 10^${exp}`
    }
    return num.toLocaleString()
  }

  const calculatePermutation = () => {
    setError("")
    setResult(null)

    const nNum = Number.parseInt(n)
    const rNum = Number.parseInt(r)

    if (isNaN(nNum) || nNum < 0) {
      setError("Please enter a valid positive integer for n")
      return
    }

    if (isNaN(rNum) || rNum < 0) {
      setError("Please enter a valid positive integer for r")
      return
    }

    if (!allowRepetition && rNum > nNum) {
      setError("r cannot be greater than n when repetition is not allowed")
      return
    }

    if (nNum > 170) {
      setError("n is too large. Please enter a value of 170 or less to avoid overflow")
      return
    }

    let permutations: bigint
    let formula: string
    const steps: string[] = []

    if (allowRepetition) {
      // P(n, r) = n^r
      permutations = BigInt(nNum) ** BigInt(rNum)
      formula = `P(${nNum}, ${rNum}) = ${nNum}^${rNum}`
      steps.push(`Formula: P(n, r) = n^r (with repetition)`)
      steps.push(`P(${nNum}, ${rNum}) = ${nNum}^${rNum}`)
      steps.push(`= ${formatNumber(permutations)}`)
    } else {
      // P(n, r) = n! / (n-r)!
      const nFactorial = factorial(nNum)
      const nMinusRFactorial = factorial(nNum - rNum)
      permutations = nFactorial / nMinusRFactorial
      formula = `P(${nNum}, ${rNum}) = ${nNum}! / (${nNum}-${rNum})!`

      steps.push(`Formula: P(n, r) = n! / (n-r)! (without repetition)`)
      steps.push(`P(${nNum}, ${rNum}) = ${nNum}! / (${nNum}-${rNum})!`)
      steps.push(`= ${nNum}! / ${nNum - rNum}!`)

      if (nNum <= 10) {
        const factorialExpansion = Array.from({ length: nNum }, (_, i) => nNum - i).join(" × ")
        steps.push(`${nNum}! = ${factorialExpansion} = ${formatNumber(nFactorial)}`)
        if (nNum - rNum > 0) {
          const factorialExpansion2 = Array.from({ length: nNum - rNum }, (_, i) => nNum - rNum - i).join(" × ")
          steps.push(`${nNum - rNum}! = ${factorialExpansion2} = ${formatNumber(nMinusRFactorial)}`)
        } else {
          steps.push(`0! = 1`)
        }
      }

      steps.push(`= ${formatNumber(nFactorial)} / ${formatNumber(nMinusRFactorial)}`)
      steps.push(`= ${formatNumber(permutations)}`)
    }

    setResult({ value: formatNumber(permutations), formula, steps })
  }

  const handleReset = () => {
    setN("")
    setR("")
    setAllowRepetition(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Permutations: ${result.value} | ${result.formula}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Permutation Calculator Result",
          text: `I calculated permutations using CalcHub! ${result.formula} = ${result.value}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Shuffle className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Permutation Calculator</CardTitle>
                    <CardDescription>Calculate arrangements of items</CardDescription>
                  </div>
                </div>

                {/* Repetition Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Allow Repetition</span>
                  <button
                    onClick={() => {
                      setAllowRepetition(!allowRepetition)
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        allowRepetition ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !allowRepetition ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      No
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        allowRepetition ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Yes
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* n Input */}
                <div className="space-y-2">
                  <Label htmlFor="n">Total Items (n)</Label>
                  <Input
                    id="n"
                    type="number"
                    placeholder="Enter total number of items"
                    value={n}
                    onChange={(e) => setN(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* r Input */}
                <div className="space-y-2">
                  <Label htmlFor="r">Items to Arrange (r)</Label>
                  <Input
                    id="r"
                    type="number"
                    placeholder="Enter number of items to arrange"
                    value={r}
                    onChange={(e) => setR(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="showSteps"
                    checked={showSteps}
                    onChange={(e) => setShowSteps(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300"
                  />
                  <Label htmlFor="showSteps" className="text-sm font-normal cursor-pointer">
                    Show step-by-step calculation
                  </Label>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePermutation} className="w-full" size="lg">
                  Calculate Permutations
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Permutations</p>
                      <p className="text-3xl sm:text-4xl font-bold text-blue-600 mb-2 break-all">{result.value}</p>
                      <p className="text-sm font-mono text-blue-700 bg-blue-100 px-3 py-1 rounded inline-block">
                        {result.formula}
                      </p>
                    </div>

                    {/* Step-by-step breakdown */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-blue-200">
                        <p className="text-sm font-medium text-blue-800 mb-2">Step-by-step:</p>
                        <div className="space-y-1 text-sm font-mono text-blue-700 bg-white/50 p-3 rounded-lg">
                          {result.steps.map((step, index) => (
                            <p key={index} className="break-all">
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Permutation Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700 mb-1">Without Repetition</p>
                      <p className="font-mono text-sm text-blue-600">P(n, r) = n! / (n − r)!</p>
                      <p className="text-xs text-blue-600 mt-1">Each item can only be used once</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-700 mb-1">With Repetition</p>
                      <p className="font-mono text-sm text-purple-600">P(n, r) = n^r</p>
                      <p className="text-xs text-purple-600 mt-1">Items can be repeated</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">3-digit code (no repeat)</p>
                    <p>n=10, r=3: P(10,3) = 720 arrangements</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">4-digit PIN (with repeat)</p>
                    <p>n=10, r=4: P(10,4) = 10,000 combinations</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Seating 5 people in 5 chairs</p>
                    <p>n=5, r=5: P(5,5) = 120 arrangements</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>This calculator provides estimates only. Verify manually for critical calculations.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Permutations?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A permutation is an arrangement of objects in a specific order. Unlike combinations, where only the
                  selection matters, permutations consider the sequence or order of the selected items. For example,
                  selecting the digits 1, 2, and 3 to form a code: 123, 132, 213, 231, 312, and 321 are all different
                  permutations of the same three digits.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The word "permutation" comes from the Latin "permutare," meaning to change thoroughly. In mathematics,
                  permutations are fundamental to combinatorics, probability theory, and many areas of computer science.
                  Understanding permutations helps solve problems involving arrangements, scheduling, cryptography, and
                  statistical analysis.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Permutation Formulas Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Without Repetition (P(n, r) = n! / (n-r)!):</strong> This formula calculates the number of
                  ways to arrange r items from a set of n distinct items, where each item can only be used once. The
                  factorial notation (n!) represents the product of all positive integers up to n. For instance, 5! = 5
                  × 4 × 3 × 2 × 1 = 120.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>With Repetition (P(n, r) = n^r):</strong> When items can be repeated, the formula becomes much
                  simpler. Each of the r positions can be filled by any of the n items, giving n choices for each
                  position. This is commonly used in PIN codes, passwords, and scenarios where the same element can
                  appear multiple times.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key difference is that without repetition, once an item is placed, it cannot be used again. With
                  repetition, items remain available for selection regardless of previous choices. This distinction
                  significantly impacts the total number of possible arrangements.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Permutations have countless practical applications in everyday life and various industries. In{" "}
                  <strong>cryptography and security</strong>, understanding permutations helps in creating secure
                  passwords and encryption schemes. A 4-digit PIN without repetition has 5,040 possibilities, while one
                  with repetition has 10,000 possibilities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In <strong>sports and competitions</strong>, permutations determine the number of possible finishing
                  orders in races or tournament brackets. For a race with 10 participants, there are P(10,3) = 720
                  different ways the top 3 positions can be filled.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Scheduling and logistics</strong> rely heavily on permutation calculations. Airlines use
                  permutations to optimize crew scheduling, manufacturers to plan assembly line sequences, and event
                  planners to arrange seating. In genetics, permutations help calculate possible gene sequences and
                  protein structures.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shuffle className="h-5 w-5 text-primary" />
                  <CardTitle>Permutations vs Combinations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A common source of confusion is the difference between permutations and combinations. The key
                  distinction is that <strong>permutations care about order</strong>, while{" "}
                  <strong>combinations do not</strong>. Selecting team captains A, B, C in that specific order is
                  different from B, C, A in permutations, but in combinations, both represent the same group of three
                  people.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Use permutations when: arranging people in a line, creating passwords, assigning ranked positions
                  (1st, 2nd, 3rd place), or any scenario where sequence matters. Use combinations when: selecting a
                  committee, choosing lottery numbers, or picking team members where order doesn't matter.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The mathematical relationship between them is: P(n,r) = C(n,r) × r!, meaning permutations equal
                  combinations multiplied by the number of ways to arrange the selected items. This is because for every
                  combination, there are r! ways to arrange those r items.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
