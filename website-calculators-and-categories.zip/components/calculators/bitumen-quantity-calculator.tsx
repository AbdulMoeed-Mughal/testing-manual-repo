"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Truck, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface BitumenResult {
  bitumenKg: number
  bitumenTons: number
  bitumenLbs: number
  volumeM3: number
  volumeFt3: number
}

export function BitumenQuantityCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [area, setArea] = useState("")
  const [thickness, setThickness] = useState("")
  const [bitumenContent, setBitumenContent] = useState("5.5")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<BitumenResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBitumen = () => {
    setError("")
    setResult(null)

    const areaNum = Number.parseFloat(area)
    const thicknessNum = Number.parseFloat(thickness)
    const bitumenContentNum = Number.parseFloat(bitumenContent)
    const wastageNum = Number.parseFloat(wastage)

    // Validation
    if (isNaN(areaNum) || areaNum <= 0) {
      setError("Please enter a valid area greater than 0")
      return
    }
    if (isNaN(thicknessNum) || thicknessNum <= 0) {
      setError("Please enter a valid thickness greater than 0")
      return
    }
    if (isNaN(bitumenContentNum) || bitumenContentNum < 4 || bitumenContentNum > 7) {
      setError("Bitumen content must be between 4% and 7%")
      return
    }
    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Wastage percentage must be 0 or greater")
      return
    }

    // Convert to metric if imperial
    let areaM2 = areaNum
    let thicknessM = thicknessNum

    if (unitSystem === "imperial") {
      areaM2 = areaNum * 0.092903 // ft² to m²
      thicknessM = thicknessNum * 0.0254 // inches to meters
    } else {
      thicknessM = thicknessNum / 100 // cm to meters
    }

    // Calculate asphalt volume
    const asphaltVolumeM3 = areaM2 * thicknessM

    // Calculate bitumen quantity
    const bitumenDensity = 1020 // kg/m³
    const bitumenVolumeM3 = asphaltVolumeM3 * (bitumenContentNum / 100) * (1 + wastageNum / 100)
    const bitumenKg = bitumenVolumeM3 * bitumenDensity
    const bitumenTons = bitumenKg / 1000
    const bitumenLbs = bitumenKg * 2.20462

    const volumeFt3 = bitumenVolumeM3 * 35.3147

    setResult({
      bitumenKg,
      bitumenTons,
      bitumenLbs,
      volumeM3: bitumenVolumeM3,
      volumeFt3,
    })
  }

  const handleReset = () => {
    setArea("")
    setThickness("")
    setBitumenContent("5.5")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = unitSystem === "metric"
        ? `Bitumen Required: ${result.bitumenKg.toFixed(2)} kg (${result.bitumenTons.toFixed(3)} tons)`
        : `Bitumen Required: ${result.bitumenLbs.toFixed(2)} lbs`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Bitumen Quantity Calculation",
          text: `I calculated bitumen quantity using CalcHub! Required: ${result.bitumenKg.toFixed(2)} kg`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setArea("")
    setThickness("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Truck className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Bitumen Quantity Calculator</CardTitle>
                    <CardDescription>Calculate bitumen for road construction</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="area">Road Area ({unitSystem === "metric" ? "m²" : "ft²"})</Label>
                  <Input
                    id="area"
                    type="number"
                    placeholder={`Enter area in ${unitSystem === "metric" ? "square meters" : "square feet"}`}
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Thickness Input */}
                <div className="space-y-2">
                  <Label htmlFor="thickness">Asphalt Thickness ({unitSystem === "metric" ? "cm" : "in"})</Label>
                  <Input
                    id="thickness"
                    type="number"
                    placeholder={`Enter thickness in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                    value={thickness}
                    onChange={(e) => setThickness(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Bitumen Content */}
                <div className="space-y-2">
                  <Label htmlFor="bitumen-content">Bitumen Content (%)</Label>
                  <Input
                    id="bitumen-content"
                    type="number"
                    placeholder="5.5"
                    value={bitumenContent}
                    onChange={(e) => setBitumenContent(e.target.value)}
                    min="4"
                    max="7"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Typical range: 4-7%</p>
                </div>

                {/* Wastage */}
                <div className="space-y-2">
                  <Label htmlFor="wastage">Wastage (%)</Label>
                  <Input
                    id="wastage"
                    type="number"
                    placeholder="5"
                    value={wastage}
                    onChange={(e) => setWastage(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBitumen} className="w-full" size="lg">
                  Calculate Bitumen
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Bitumen Required</p>
                        {unitSystem === "metric" ? (
                          <>
                            <p className="text-4xl font-bold text-amber-700">{result.bitumenKg.toFixed(2)}</p>
                            <p className="text-sm font-medium text-amber-600">kg ({result.bitumenTons.toFixed(3)} tons)</p>
                          </>
                        ) : (
                          <>
                            <p className="text-4xl font-bold text-amber-700">{result.bitumenLbs.toFixed(2)}</p>
                            <p className="text-sm font-medium text-amber-600">lbs</p>
                          </>
                        )}
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Volume:</span>
                          <span className="font-medium">
                            {unitSystem === "metric"
                              ? `${result.volumeM3.toFixed(3)} m³`
                              : `${result.volumeFt3.toFixed(2)} ft³`}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4 pt-3 border-t border-amber-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Bitumen Content</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-800">Dense Graded Mix</span>
                      <span className="text-amber-600">5-6%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-800">Stone Mastic Asphalt</span>
                      <span className="text-amber-600">6-7%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-800">Porous Asphalt</span>
                      <span className="text-amber-600">4-5%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">Asphalt Volume = Area × Thickness</p>
                    <p className="font-semibold text-foreground">
                      Bitumen = Volume × Content% × (1 + Wastage%)
                    </p>
                  </div>
                  <p>
                    The calculator uses a standard bitumen density of <strong>1020 kg/m³</strong> to convert volume to weight.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Bitumen */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Bitumen?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bitumen, also known as asphalt binder, is a highly viscous, black, sticky petroleum-based material
                  that serves as the binding agent in asphalt concrete for road construction. It is obtained through
                  the distillation of crude oil and represents one of the heaviest fractions of petroleum. Bitumen's
                  adhesive and waterproofing properties make it ideal for binding aggregate materials together to
                  create durable road surfaces that can withstand heavy traffic loads and varying weather conditions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In road construction, bitumen is heated and mixed with aggregates (sand, gravel, and crushed stone)
                  to produce asphalt concrete, commonly referred to as "asphalt" or "blacktop." The bitumen content
                  typically ranges from 4% to 7% by weight of the total mix, depending on the specific application and
                  mix design. This relatively small percentage of bitumen is crucial for providing the flexibility,
                  durability, and water resistance that modern roads require.
                </p>
              </CardContent>
            </Card>

            {/* How to Use Calculator */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Using the Bitumen Quantity Calculator is straightforward and requires just a few measurements from
                  your road construction project. First, choose your preferred unit system - metric (m², cm) or
                  imperial (ft², inches). Then, input the total area of the road or pavement surface that needs to be
                  paved. This could be calculated by multiplying the length and width of your road section.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Next, enter the planned thickness of the asphalt layer. Typical road surfaces range from 5-10 cm
                  (2-4 inches) for light traffic areas to 10-20 cm (4-8 inches) for highways and heavy-duty roads.
                  Specify the bitumen content percentage based on your mix design - common values range from 5% to 6%
                  for most applications. Finally, add a wastage percentage (typically 5-10%) to account for material
                  loss during transportation, handling, and application. The calculator will instantly provide the
                  total bitumen required in both weight and volume units.
                </p>
              </CardContent>
            </Card>

            {/* Common Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Truck className="h-5 w-5 text-primary" />
                  <CardTitle>Common Bitumen Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Highway & Road Construction</h4>
                    <p className="text-amber-700 text-sm">
                      The primary use of bitumen is in highway and road construction, where it binds aggregate
                      materials to create flexible pavements. Dense graded mixes with 5-6% bitumen content are
                      standard for most roads, providing excellent durability and load-bearing capacity.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Airport Runways</h4>
                    <p className="text-amber-700 text-sm">
                      Airport pavements require specialized asphalt mixes with higher bitumen content (6-7%) to
                      withstand the extreme loads and high temperatures generated by aircraft. These mixes must
                      maintain stability under static loads while providing sufficient flexibility.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Parking Lots & Driveways</h4>
                    <p className="text-amber-700 text-sm">
                      Residential and commercial parking areas typically use thinner asphalt layers (5-7.5 cm) with
                      standard bitumen content. These applications benefit from bitumen's quick curing properties and
                      cost-effectiveness compared to concrete alternatives.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Waterproofing Applications</h4>
                    <p className="text-amber-700 text-sm">
                      Beyond paving, bitumen is extensively used for waterproofing roofs, basements, and foundations.
                      Modified bitumen membranes provide excellent water resistance and can last 20-30 years when
                      properly installed and maintained.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2 text-sm text-amber-800">
                    <p className="font-semibold">Important Note</p>
                    <p>
                      Bitumen quantity estimates are approximate. Actual requirements vary based on mix design,
                      compaction, and site conditions. Always consult with a qualified civil engineer or paving
                      contractor for precise specifications and material ordering for your specific project.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
