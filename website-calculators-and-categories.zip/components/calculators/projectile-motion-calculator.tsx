"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  AlertTriangle,
  Rocket,
  Target,
  ArrowUp,
  Clock,
  Navigation,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type VelocityUnit = "m/s" | "km/h" | "ft/s"
type DistanceUnit = "m" | "ft"

interface ProjectileResult {
  range: number
  maxHeight: number
  timeOfFlight: number
  timeToMaxHeight: number
  horizontalVelocity: number
  verticalVelocity: number
  finalVelocity: number
  impactAngle: number
}

export function ProjectileMotionCalculator() {
  const [initialVelocity, setInitialVelocity] = useState("")
  const [launchAngle, setLaunchAngle] = useState("")
  const [initialHeight, setInitialHeight] = useState("")
  const [gravity, setGravity] = useState("9.81")
  const [velocityUnit, setVelocityUnit] = useState<VelocityUnit>("m/s")
  const [distanceUnit, setDistanceUnit] = useState<DistanceUnit>("m")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<ProjectileResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  // Convert velocity to m/s
  const convertToMS = (value: number, unit: VelocityUnit): number => {
    switch (unit) {
      case "km/h":
        return value / 3.6
      case "ft/s":
        return value * 0.3048
      default:
        return value
    }
  }

  // Convert distance to meters
  const convertToMeters = (value: number, unit: DistanceUnit): number => {
    return unit === "ft" ? value * 0.3048 : value
  }

  // Convert meters to display unit
  const convertFromMeters = (value: number, unit: DistanceUnit): number => {
    return unit === "ft" ? value / 0.3048 : value
  }

  // Convert m/s to display unit
  const convertFromMS = (value: number, unit: VelocityUnit): number => {
    switch (unit) {
      case "km/h":
        return value * 3.6
      case "ft/s":
        return value / 0.3048
      default:
        return value
    }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const v0 = Number.parseFloat(initialVelocity)
    const angle = Number.parseFloat(launchAngle)
    const h0 = Number.parseFloat(initialHeight) || 0
    const g = Number.parseFloat(gravity)

    if (isNaN(v0) || v0 <= 0) {
      setError("Please enter a valid initial velocity greater than 0")
      return
    }

    if (isNaN(angle) || angle < 0 || angle > 90) {
      setError("Please enter a valid launch angle between 0° and 90°")
      return
    }

    if (h0 < 0) {
      setError("Initial height cannot be negative")
      return
    }

    if (isNaN(g) || g <= 0) {
      setError("Please enter a valid gravity value greater than 0")
      return
    }

    // Convert to SI units
    const v0SI = convertToMS(v0, velocityUnit)
    const h0SI = convertToMeters(h0, distanceUnit)

    // Convert angle to radians
    const angleRad = (angle * Math.PI) / 180

    // Calculate velocity components
    const vx = v0SI * Math.cos(angleRad)
    const vy = v0SI * Math.sin(angleRad)

    // Time to reach maximum height
    const tMax = vy / g

    // Maximum height (from launch point)
    const maxHeightFromLaunch = (vy * vy) / (2 * g)
    const maxHeight = h0SI + maxHeightFromLaunch

    // Time of flight (using quadratic formula for landing)
    // h0 + vy*t - 0.5*g*t² = 0
    // -0.5*g*t² + vy*t + h0 = 0
    const a = -0.5 * g
    const b = vy
    const c = h0SI
    const discriminant = b * b - 4 * a * c
    const tFlight = (-b - Math.sqrt(discriminant)) / (2 * a)

    // Range (horizontal distance)
    const range = vx * tFlight

    // Final velocity at impact
    const vyFinal = vy - g * tFlight
    const vFinal = Math.sqrt(vx * vx + vyFinal * vyFinal)

    // Impact angle (below horizontal)
    const impactAngle = Math.abs(Math.atan2(vyFinal, vx) * (180 / Math.PI))

    setResult({
      range,
      maxHeight,
      timeOfFlight: tFlight,
      timeToMaxHeight: tMax,
      horizontalVelocity: vx,
      verticalVelocity: vy,
      finalVelocity: vFinal,
      impactAngle,
    })
  }

  const handleReset = () => {
    setInitialVelocity("")
    setLaunchAngle("")
    setInitialHeight("")
    setGravity("9.81")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const rangeDisplay = convertFromMeters(result.range, distanceUnit).toFixed(2)
      const heightDisplay = convertFromMeters(result.maxHeight, distanceUnit).toFixed(2)
      await navigator.clipboard.writeText(
        `Projectile Motion: Range = ${rangeDisplay} ${distanceUnit}, Max Height = ${heightDisplay} ${distanceUnit}, Time of Flight = ${result.timeOfFlight.toFixed(2)} s`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const rangeDisplay = convertFromMeters(result.range, distanceUnit).toFixed(2)
      const heightDisplay = convertFromMeters(result.maxHeight, distanceUnit).toFixed(2)
      try {
        await navigator.share({
          title: "Projectile Motion Result",
          text: `Projectile Motion: Range = ${rangeDisplay} ${distanceUnit}, Max Height = ${heightDisplay} ${distanceUnit}, Time of Flight = ${result.timeOfFlight.toFixed(2)} s`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  // Generate trajectory points for visualization
  const trajectoryPoints = useMemo(() => {
    if (!result) return []

    const v0 = Number.parseFloat(initialVelocity)
    const angle = Number.parseFloat(launchAngle)
    const h0 = Number.parseFloat(initialHeight) || 0
    const g = Number.parseFloat(gravity)

    const v0SI = convertToMS(v0, velocityUnit)
    const h0SI = convertToMeters(h0, distanceUnit)
    const angleRad = (angle * Math.PI) / 180

    const vx = v0SI * Math.cos(angleRad)
    const vy = v0SI * Math.sin(angleRad)

    const points: { x: number; y: number }[] = []
    const steps = 50

    for (let i = 0; i <= steps; i++) {
      const t = (i / steps) * result.timeOfFlight
      const x = vx * t
      const y = h0SI + vy * t - 0.5 * g * t * t
      if (y >= 0) {
        points.push({ x, y })
      }
    }

    return points
  }, [result, initialVelocity, launchAngle, initialHeight, gravity, velocityUnit, distanceUnit])

  // SVG trajectory visualization
  const TrajectoryDiagram = () => {
    if (!result || trajectoryPoints.length === 0) return null

    const maxX = Math.max(...trajectoryPoints.map((p) => p.x))
    const maxY = Math.max(...trajectoryPoints.map((p) => p.y))

    const padding = 40
    const width = 320
    const height = 180

    const scaleX = (width - 2 * padding) / (maxX || 1)
    const scaleY = (height - 2 * padding) / (maxY || 1)
    const scale = Math.min(scaleX, scaleY)

    const pathData = trajectoryPoints
      .map((p, i) => {
        const x = padding + p.x * scale
        const y = height - padding - p.y * scale
        return `${i === 0 ? "M" : "L"} ${x} ${y}`
      })
      .join(" ")

    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
        {/* Ground line */}
        <line
          x1={padding - 10}
          y1={height - padding}
          x2={width - padding + 10}
          y2={height - padding}
          stroke="currentColor"
          strokeWidth="2"
          className="text-muted-foreground"
        />

        {/* Trajectory path */}
        <path d={pathData} fill="none" stroke="url(#trajectoryGradient)" strokeWidth="3" strokeLinecap="round" />

        {/* Gradient definition */}
        <defs>
          <linearGradient id="trajectoryGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="50%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#ef4444" />
          </linearGradient>
        </defs>

        {/* Launch point */}
        <circle
          cx={padding}
          cy={height - padding - (Number.parseFloat(initialHeight) || 0) * convertToMeters(1, distanceUnit) * scale}
          r="6"
          className="fill-green-500"
        />

        {/* Max height point */}
        <circle
          cx={padding + result.horizontalVelocity * result.timeToMaxHeight * scale}
          cy={height - padding - result.maxHeight * scale}
          r="5"
          className="fill-blue-500"
        />

        {/* Landing point */}
        <circle cx={padding + result.range * scale} cy={height - padding} r="6" className="fill-red-500" />

        {/* Labels */}
        <text x={padding} y={height - padding + 20} className="fill-current text-xs" textAnchor="middle">
          Start
        </text>
        <text
          x={padding + result.range * scale}
          y={height - padding + 20}
          className="fill-current text-xs"
          textAnchor="middle"
        >
          Land
        </text>
        <text
          x={padding + result.horizontalVelocity * result.timeToMaxHeight * scale}
          y={height - padding - result.maxHeight * scale - 10}
          className="fill-current text-xs"
          textAnchor="middle"
        >
          Max
        </text>
      </svg>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Rocket className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Projectile Motion Calculator</CardTitle>
                    <CardDescription>Calculate trajectory parameters</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Velocity */}
                <div className="space-y-2">
                  <Label htmlFor="velocity">Initial Velocity (v₀)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="velocity"
                      type="number"
                      placeholder="Enter initial velocity"
                      value={initialVelocity}
                      onChange={(e) => setInitialVelocity(e.target.value)}
                      min="0"
                      step="0.1"
                      className="flex-1"
                    />
                    <Select value={velocityUnit} onValueChange={(v) => setVelocityUnit(v as VelocityUnit)}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="m/s">m/s</SelectItem>
                        <SelectItem value="km/h">km/h</SelectItem>
                        <SelectItem value="ft/s">ft/s</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Launch Angle */}
                <div className="space-y-2">
                  <Label htmlFor="angle">Launch Angle (θ)</Label>
                  <div className="flex gap-2 items-center">
                    <Input
                      id="angle"
                      type="number"
                      placeholder="Enter angle (0-90)"
                      value={launchAngle}
                      onChange={(e) => setLaunchAngle(e.target.value)}
                      min="0"
                      max="90"
                      step="1"
                      className="flex-1"
                    />
                    <span className="text-muted-foreground w-16">degrees</span>
                  </div>
                </div>

                {/* Initial Height */}
                <div className="space-y-2">
                  <Label htmlFor="height">Initial Height (optional)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="height"
                      type="number"
                      placeholder="Default: 0"
                      value={initialHeight}
                      onChange={(e) => setInitialHeight(e.target.value)}
                      min="0"
                      step="0.1"
                      className="flex-1"
                    />
                    <Select value={distanceUnit} onValueChange={(v) => setDistanceUnit(v as DistanceUnit)}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="m">m</SelectItem>
                        <SelectItem value="ft">ft</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Gravity */}
                <div className="space-y-2">
                  <Label htmlFor="gravity">Gravity (g)</Label>
                  <div className="flex gap-2 items-center">
                    <Input
                      id="gravity"
                      type="number"
                      placeholder="9.81"
                      value={gravity}
                      onChange={(e) => setGravity(e.target.value)}
                      min="0"
                      step="0.01"
                      className="flex-1"
                    />
                    <span className="text-muted-foreground w-16">m/s²</span>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-1">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="text-xs h-7 bg-transparent"
                      onClick={() => setGravity("9.81")}
                    >
                      Earth (9.81)
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="text-xs h-7 bg-transparent"
                      onClick={() => setGravity("1.62")}
                    >
                      Moon (1.62)
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="text-xs h-7 bg-transparent"
                      onClick={() => setGravity("3.71")}
                    >
                      Mars (3.71)
                    </Button>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Trajectory
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    {/* Trajectory Visualization */}
                    <div className="mb-4 p-3 bg-white rounded-lg border">
                      <p className="text-xs text-muted-foreground text-center mb-2">Trajectory Path</p>
                      <TrajectoryDiagram />
                    </div>

                    {/* Primary Results */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <Target className="h-4 w-4 text-orange-600" />
                          <span className="text-xs text-muted-foreground">Range</span>
                        </div>
                        <p className="text-xl font-bold text-orange-600">
                          {convertFromMeters(result.range, distanceUnit).toFixed(2)}
                        </p>
                        <p className="text-xs text-muted-foreground">{distanceUnit}</p>
                      </div>

                      <div className="p-3 bg-white rounded-lg border text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <ArrowUp className="h-4 w-4 text-blue-600" />
                          <span className="text-xs text-muted-foreground">Max Height</span>
                        </div>
                        <p className="text-xl font-bold text-blue-600">
                          {convertFromMeters(result.maxHeight, distanceUnit).toFixed(2)}
                        </p>
                        <p className="text-xs text-muted-foreground">{distanceUnit}</p>
                      </div>

                      <div className="p-3 bg-white rounded-lg border text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <Clock className="h-4 w-4 text-green-600" />
                          <span className="text-xs text-muted-foreground">Time of Flight</span>
                        </div>
                        <p className="text-xl font-bold text-green-600">{result.timeOfFlight.toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">seconds</p>
                      </div>

                      <div className="p-3 bg-white rounded-lg border text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <Clock className="h-4 w-4 text-purple-600" />
                          <span className="text-xs text-muted-foreground">Time to Peak</span>
                        </div>
                        <p className="text-xl font-bold text-purple-600">{result.timeToMaxHeight.toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">seconds</p>
                      </div>
                    </div>

                    {/* Velocity Components */}
                    <div className="space-y-2 mb-4">
                      <p className="text-sm font-medium">Velocity Components</p>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="p-2 bg-white rounded border">
                          <span className="text-muted-foreground">Horizontal (vₓ): </span>
                          <span className="font-medium">
                            {convertFromMS(result.horizontalVelocity, velocityUnit).toFixed(2)} {velocityUnit}
                          </span>
                        </div>
                        <div className="p-2 bg-white rounded border">
                          <span className="text-muted-foreground">Vertical (vᵧ): </span>
                          <span className="font-medium">
                            {convertFromMS(result.verticalVelocity, velocityUnit).toFixed(2)} {velocityUnit}
                          </span>
                        </div>
                        <div className="p-2 bg-white rounded border">
                          <span className="text-muted-foreground">Final velocity: </span>
                          <span className="font-medium">
                            {convertFromMS(result.finalVelocity, velocityUnit).toFixed(2)} {velocityUnit}
                          </span>
                        </div>
                        <div className="p-2 bg-white rounded border">
                          <span className="text-muted-foreground">Impact angle: </span>
                          <span className="font-medium">{result.impactAngle.toFixed(1)}°</span>
                        </div>
                      </div>
                    </div>

                    {/* Step-by-step */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg border">
                        <button
                          onClick={() => setShowSteps(!showSteps)}
                          className="w-full text-left text-sm font-medium flex items-center justify-between"
                        >
                          Step-by-Step Solution
                          <span className="text-xs text-muted-foreground">click to toggle</span>
                        </button>
                        <div className="mt-2 space-y-2 text-sm text-muted-foreground">
                          <p>
                            1. Convert angle to radians: θ = {launchAngle}° × π/180 ={" "}
                            {((Number.parseFloat(launchAngle) * Math.PI) / 180).toFixed(4)} rad
                          </p>
                          <p>
                            2. Horizontal velocity: vₓ = v₀ × cos(θ) ={" "}
                            {convertFromMS(result.horizontalVelocity, velocityUnit).toFixed(2)} {velocityUnit}
                          </p>
                          <p>
                            3. Vertical velocity: vᵧ = v₀ × sin(θ) ={" "}
                            {convertFromMS(result.verticalVelocity, velocityUnit).toFixed(2)} {velocityUnit}
                          </p>
                          <p>4. Time to max height: t = vᵧ ÷ g = {result.timeToMaxHeight.toFixed(2)} s</p>
                          <p>
                            5. Max height: H = h₀ + vᵧ² ÷ (2g) ={" "}
                            {convertFromMeters(result.maxHeight, distanceUnit).toFixed(2)} {distanceUnit}
                          </p>
                          <p>6. Time of flight: t = {result.timeOfFlight.toFixed(2)} s (quadratic formula)</p>
                          <p>
                            7. Range: R = vₓ × t = {convertFromMeters(result.range, distanceUnit).toFixed(2)}{" "}
                            {distanceUnit}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-medium text-blue-700 text-sm">Horizontal Velocity</p>
                    <p className="font-mono text-blue-600 text-sm">vₓ = v₀ × cos(θ)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-medium text-green-700 text-sm">Vertical Velocity</p>
                    <p className="font-mono text-green-600 text-sm">vᵧ = v₀ × sin(θ)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-medium text-purple-700 text-sm">Maximum Height</p>
                    <p className="font-mono text-purple-600 text-sm">H = h₀ + vᵧ² ÷ (2g)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <p className="font-medium text-orange-700 text-sm">Range (h₀ = 0)</p>
                    <p className="font-mono text-orange-600 text-sm">R = v₀² × sin(2θ) ÷ g</p>
                  </div>
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                    <p className="font-medium text-red-700 text-sm">Time of Flight (h₀ = 0)</p>
                    <p className="font-mono text-red-600 text-sm">t = 2v₀ × sin(θ) ÷ g</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Results assume ideal projectile motion without air resistance, friction, or wind. Actual
                    trajectories may vary due to atmospheric conditions, projectile shape, and spin effects.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Projectile Motion?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Projectile motion is a form of motion experienced by an object that is projected near the Earth's
                  surface and moves along a curved path under the action of gravity only. This parabolic trajectory is
                  one of the most fundamental concepts in classical mechanics and has applications ranging from sports
                  to military ballistics and space exploration.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key insight of projectile motion is that the horizontal and vertical components of motion are
                  independent of each other. The horizontal velocity remains constant (ignoring air resistance), while
                  the vertical velocity changes linearly due to gravitational acceleration. This independence allows us
                  to analyze each component separately and combine them to understand the complete trajectory.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Key Parameters Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Range</h4>
                    <p className="text-orange-700 text-sm">
                      The horizontal distance traveled by the projectile from launch to landing. For a given initial
                      velocity and zero initial height, maximum range is achieved at a 45° launch angle. The range
                      depends on both the initial velocity and the launch angle.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Maximum Height</h4>
                    <p className="text-blue-700 text-sm">
                      The highest point reached by the projectile above the ground. At this point, the vertical velocity
                      momentarily becomes zero before the projectile begins its descent. Higher launch angles result in
                      greater maximum heights but may reduce the range.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Time of Flight</h4>
                    <p className="text-green-700 text-sm">
                      The total time the projectile spends in the air from launch to landing. This depends on the
                      initial vertical velocity and the initial height. A higher launch angle or initial height
                      increases the time of flight.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Velocity Components</h4>
                    <p className="text-purple-700 text-sm">
                      The initial velocity can be broken into horizontal (vₓ) and vertical (vᵧ) components using
                      trigonometry. The horizontal component remains constant throughout the flight, while the vertical
                      component decreases on the way up and increases on the way down.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Navigation className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding projectile motion is essential in many fields:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Sports:</strong> Athletes and coaches use projectile motion principles to optimize throwing
                    angles in javelin, shot put, basketball shots, and golf drives.
                  </li>
                  <li>
                    <strong>Military and Defense:</strong> Artillery calculations, missile trajectories, and ballistic
                    analysis all rely on projectile motion equations.
                  </li>
                  <li>
                    <strong>Engineering:</strong> Designing water fountains, irrigation systems, and industrial sprayers
                    requires understanding fluid projectile behavior.
                  </li>
                  <li>
                    <strong>Video Games:</strong> Physics engines simulate projectile motion for realistic gameplay in
                    shooting games, sports simulations, and puzzle games.
                  </li>
                  <li>
                    <strong>Forensics:</strong> Crime scene investigators use projectile analysis to reconstruct
                    shooting incidents and accident scenarios.
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Rocket className="h-5 w-5 text-primary" />
                  <CardTitle>Optimal Launch Angles</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The optimal launch angle depends on your objective:
                </p>
                <div className="mt-4 grid gap-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Maximum Range (flat ground): 45°</p>
                    <p className="text-sm text-muted-foreground">
                      When launching from and landing at the same height, 45° provides the perfect balance between
                      horizontal distance and time in the air.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Maximum Height: 90°</p>
                    <p className="text-sm text-muted-foreground">
                      A vertical launch achieves the greatest height but zero horizontal range.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Launching from Height: Less than 45°</p>
                    <p className="text-sm text-muted-foreground">
                      When launching from an elevated position, the optimal angle for maximum range is less than 45°.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Launching Uphill: Greater than 45°</p>
                    <p className="text-sm text-muted-foreground">
                      When the landing point is higher than the launch point, angles greater than 45° may be optimal.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
