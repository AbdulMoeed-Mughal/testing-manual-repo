"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Building2,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface RebarResult {
  areaPerBar: number
  volumePerBar: number
  weightPerBar: number
  totalWeight: number
  totalWeightWithWaste: number
  numberOfBars: number
}

// Common rebar sizes with diameters
const rebarSizesMetric = [
  { label: "6 mm", value: 6 },
  { label: "8 mm", value: 8 },
  { label: "10 mm", value: 10 },
  { label: "12 mm", value: 12 },
  { label: "16 mm", value: 16 },
  { label: "20 mm", value: 20 },
  { label: "25 mm", value: 25 },
  { label: "32 mm", value: 32 },
  { label: "40 mm", value: 40 },
]

const rebarSizesImperial = [
  { label: '#3 (3/8")', value: 0.375 },
  { label: '#4 (1/2")', value: 0.5 },
  { label: '#5 (5/8")', value: 0.625 },
  { label: '#6 (3/4")', value: 0.75 },
  { label: '#7 (7/8")', value: 0.875 },
  { label: '#8 (1")', value: 1 },
  { label: '#9 (1-1/8")', value: 1.128 },
  { label: '#10 (1-1/4")', value: 1.27 },
  { label: '#11 (1-3/8")', value: 1.41 },
]

export function SteelRebarCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [diameter, setDiameter] = useState("")
  const [customDiameter, setCustomDiameter] = useState("")
  const [length, setLength] = useState("")
  const [numberOfBars, setNumberOfBars] = useState("1")
  const [density, setDensity] = useState(unitSystem === "metric" ? "7850" : "0.284")
  const [wastePercentage, setWastePercentage] = useState("5")
  const [result, setResult] = useState<RebarResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    // Get diameter value
    let diameterValue: number
    if (diameter === "custom") {
      diameterValue = Number.parseFloat(customDiameter)
      if (isNaN(diameterValue) || diameterValue <= 0) {
        setError("Please enter a valid custom diameter greater than 0")
        return
      }
    } else {
      diameterValue = Number.parseFloat(diameter)
      if (isNaN(diameterValue) || diameterValue <= 0) {
        setError("Please select a rebar size")
        return
      }
    }

    const lengthNum = Number.parseFloat(length)
    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }

    const barsNum = Number.parseInt(numberOfBars)
    if (isNaN(barsNum) || barsNum < 1) {
      setError("Number of bars must be at least 1")
      return
    }

    const densityNum = Number.parseFloat(density)
    if (isNaN(densityNum) || densityNum <= 0) {
      setError("Please enter a valid density greater than 0")
      return
    }

    const wasteNum = Number.parseFloat(wastePercentage) || 0
    if (wasteNum < 0 || wasteNum > 100) {
      setError("Waste percentage must be between 0 and 100")
      return
    }

    let areaPerBar: number
    let volumePerBar: number
    let weightPerBar: number

    if (unitSystem === "metric") {
      // Diameter in mm, length in m, density in kg/m³
      const radiusM = diameterValue / 1000 / 2 // Convert mm to m
      areaPerBar = Math.PI * radiusM * radiusM // m²
      volumePerBar = areaPerBar * lengthNum // m³
      weightPerBar = volumePerBar * densityNum // kg
    } else {
      // Diameter in inches, length in ft, density in lb/in³
      const radiusIn = diameterValue / 2 // inches
      areaPerBar = Math.PI * radiusIn * radiusIn // in²
      const lengthIn = lengthNum * 12 // Convert ft to inches
      volumePerBar = areaPerBar * lengthIn // in³
      weightPerBar = volumePerBar * densityNum // lb
    }

    const totalWeight = weightPerBar * barsNum
    const totalWeightWithWaste = totalWeight * (1 + wasteNum / 100)

    setResult({
      areaPerBar,
      volumePerBar,
      weightPerBar,
      totalWeight,
      totalWeightWithWaste,
      numberOfBars: barsNum,
    })
  }

  const handleReset = () => {
    setDiameter("")
    setCustomDiameter("")
    setLength("")
    setNumberOfBars("1")
    setDensity(unitSystem === "metric" ? "7850" : "0.284")
    setWastePercentage("5")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        unitSystem === "metric"
          ? `Steel Rebar Calculation: ${result.numberOfBars} bars, Total Weight: ${result.totalWeightWithWaste.toFixed(2)} kg (with waste)`
          : `Steel Rebar Calculation: ${result.numberOfBars} bars, Total Weight: ${result.totalWeightWithWaste.toFixed(2)} lb (with waste)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Steel Rebar Calculation",
          text: `Calculated rebar weight using CalcHub: ${result.numberOfBars} bars, Total Weight: ${result.totalWeightWithWaste.toFixed(2)} ${unitSystem === "metric" ? "kg" : "lb"}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    const newSystem = unitSystem === "metric" ? "imperial" : "metric"
    setUnitSystem(newSystem)
    setDiameter("")
    setCustomDiameter("")
    setLength("")
    setDensity(newSystem === "metric" ? "7850" : "0.284")
    setResult(null)
    setError("")
  }

  const rebarSizes = unitSystem === "metric" ? rebarSizesMetric : rebarSizesImperial

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Steel Rebar Calculator</CardTitle>
                    <CardDescription>Calculate rebar weight and quantity</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Rebar Size Selection */}
                <div className="space-y-2">
                  <Label>Rebar Size / Diameter ({unitSystem === "metric" ? "mm" : "inches"})</Label>
                  <Select value={diameter} onValueChange={setDiameter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select rebar size" />
                    </SelectTrigger>
                    <SelectContent>
                      {rebarSizes.map((size) => (
                        <SelectItem key={size.value} value={size.value.toString()}>
                          {size.label}
                        </SelectItem>
                      ))}
                      <SelectItem value="custom">Custom diameter</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Custom Diameter Input */}
                {diameter === "custom" && (
                  <div className="space-y-2">
                    <Label htmlFor="customDiameter">
                      Custom Diameter ({unitSystem === "metric" ? "mm" : "inches"})
                    </Label>
                    <Input
                      id="customDiameter"
                      type="number"
                      placeholder={`Enter diameter in ${unitSystem === "metric" ? "mm" : "inches"}`}
                      value={customDiameter}
                      onChange={(e) => setCustomDiameter(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                )}

                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Rebar Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Number of Bars */}
                <div className="space-y-2">
                  <Label htmlFor="numberOfBars">Number of Bars</Label>
                  <Input
                    id="numberOfBars"
                    type="number"
                    placeholder="Enter number of rebars"
                    value={numberOfBars}
                    onChange={(e) => setNumberOfBars(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Density Input */}
                <div className="space-y-2">
                  <Label htmlFor="density">Steel Density ({unitSystem === "metric" ? "kg/m³" : "lb/in³"})</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder={unitSystem === "metric" ? "7850" : "0.284"}
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                  <p className="text-xs text-muted-foreground">
                    Default: {unitSystem === "metric" ? "7850 kg/m³" : "0.284 lb/in³"} (standard steel)
                  </p>
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="wastePercentage">Waste / Cutting Loss (%)</Label>
                  <Input
                    id="wastePercentage"
                    type="number"
                    placeholder="5"
                    value={wastePercentage}
                    onChange={(e) => setWastePercentage(e.target.value)}
                    min="0"
                    max="100"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">Typical: 5–10% for cutting losses</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Weight
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Weight (with waste)</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">{result.totalWeightWithWaste.toFixed(2)}</p>
                      <p className="text-lg text-amber-700">
                        {unitSystem === "metric" ? "kg" : "lb"}
                        {unitSystem === "metric" && result.totalWeightWithWaste >= 1000 && (
                          <span className="text-sm ml-2">
                            ({(result.totalWeightWithWaste / 1000).toFixed(3)} tonnes)
                          </span>
                        )}
                        {unitSystem === "imperial" && result.totalWeightWithWaste >= 2000 && (
                          <span className="text-sm ml-2">({(result.totalWeightWithWaste / 2000).toFixed(3)} tons)</span>
                        )}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Weight per Bar</p>
                        <p className="font-semibold">
                          {result.weightPerBar.toFixed(4)} {unitSystem === "metric" ? "kg" : "lb"}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Total (no waste)</p>
                        <p className="font-semibold">
                          {result.totalWeight.toFixed(2)} {unitSystem === "metric" ? "kg" : "lb"}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Number of Bars</p>
                        <p className="font-semibold">{result.numberOfBars}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Waste Added</p>
                        <p className="font-semibold">{wastePercentage}%</p>
                      </div>
                    </div>

                    {/* Step-by-step Breakdown */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-between w-full text-sm font-medium text-amber-700 hover:text-amber-800 mb-2"
                    >
                      <span>Calculation Steps</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="p-3 bg-white rounded-lg text-sm space-y-2 mb-4">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Cross-sectional Area:</span>
                          <span className="font-mono">
                            π × (d/2)² ={" "}
                            {unitSystem === "metric"
                              ? `${(result.areaPerBar * 1e6).toFixed(4)} mm²`
                              : `${result.areaPerBar.toFixed(6)} in²`}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Volume per Bar:</span>
                          <span className="font-mono">
                            {unitSystem === "metric"
                              ? `${(result.volumePerBar * 1e6).toFixed(4)} cm³`
                              : `${result.volumePerBar.toFixed(4)} in³`}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Weight per Bar:</span>
                          <span className="font-mono">
                            {result.weightPerBar.toFixed(4)} {unitSystem === "metric" ? "kg" : "lb"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Weight:</span>
                          <span className="font-mono">
                            {result.weightPerBar.toFixed(4)} × {result.numberOfBars} = {result.totalWeight.toFixed(2)}{" "}
                            {unitSystem === "metric" ? "kg" : "lb"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">With {wastePercentage}% Waste:</span>
                          <span className="font-mono">
                            {result.totalWeight.toFixed(2)} × {(1 + Number(wastePercentage) / 100).toFixed(2)} ={" "}
                            {result.totalWeightWithWaste.toFixed(2)} {unitSystem === "metric" ? "kg" : "lb"}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rebar Weight Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Area = π × (Diameter / 2)²</p>
                    <p className="font-semibold text-foreground mt-2">Volume = Area × Length</p>
                    <p className="font-semibold text-foreground mt-2">Weight = Volume × Density</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Rebar Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {unitSystem === "metric" ? (
                      <>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>6 mm</span>
                          <span className="text-muted-foreground">~0.222 kg/m</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>10 mm</span>
                          <span className="text-muted-foreground">~0.617 kg/m</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>12 mm</span>
                          <span className="text-muted-foreground">~0.888 kg/m</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>16 mm</span>
                          <span className="text-muted-foreground">~1.58 kg/m</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>20 mm</span>
                          <span className="text-muted-foreground">~2.47 kg/m</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>25 mm</span>
                          <span className="text-muted-foreground">~3.85 kg/m</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>#3 (3/8")</span>
                          <span className="text-muted-foreground">~0.376 lb/ft</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>#4 (1/2")</span>
                          <span className="text-muted-foreground">~0.668 lb/ft</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>#5 (5/8")</span>
                          <span className="text-muted-foreground">~1.043 lb/ft</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>#6 (3/4")</span>
                          <span className="text-muted-foreground">~1.502 lb/ft</span>
                        </div>
                        <div className="flex justify-between p-2 bg-muted/50 rounded">
                          <span>#8 (1")</span>
                          <span className="text-muted-foreground">~2.670 lb/ft</span>
                        </div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual rebar weight may vary due to manufacturing tolerances, surface
                        deformations (ribbed bars), and site requirements. Always verify with supplier specifications
                        for critical calculations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Rebar?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Rebar (short for reinforcing bar) is a steel bar used as a tension device in reinforced concrete and
                  reinforced masonry structures. Concrete is strong under compression but weak in tension. Rebar
                  significantly increases the tensile strength of the structure, preventing cracks and structural
                  failure. It is an essential component in foundations, slabs, columns, beams, and retaining walls.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Rebar is typically made from carbon steel with ridges (deformations) on its surface to help it bond
                  with the concrete. The most common grade is Grade 60 (yield strength of 60,000 psi or 420 MPa), though
                  other grades like Grade 40 and Grade 75 are also used depending on the application requirements.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  <CardTitle>Calculating Rebar Weight</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The weight of rebar is calculated using basic geometry and the density of steel. First, we calculate
                  the cross-sectional area of the bar using the formula for the area of a circle (π × r²). Then, we
                  multiply by the length to get the volume, and finally multiply by the steel density to get the weight.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <h4 className="font-semibold text-foreground mb-2">Quick Weight Formula (Metric)</h4>
                  <p className="text-sm text-muted-foreground font-mono">Weight (kg/m) = (Diameter in mm)² ÷ 162</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    This simplified formula gives a quick estimate for standard steel rebar with density of 7850 kg/m³.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Account for Overlap:</strong> When bars need to be spliced together, add overlap length
                    (typically 40-50 times the bar diameter) to your calculations.
                  </li>
                  <li>
                    <strong>Include Bends and Hooks:</strong> Standard hooks and bends add extra length to each bar.
                    Account for these in your total length calculations.
                  </li>
                  <li>
                    <strong>Cutting Waste:</strong> Always add 5-10% extra for cutting losses, especially when working
                    with non-standard lengths.
                  </li>
                  <li>
                    <strong>Verify Supplier Specifications:</strong> Different manufacturers may have slight variations
                    in actual weight per unit length due to rib patterns and tolerances.
                  </li>
                  <li>
                    <strong>Consider Bar Schedule:</strong> For complex structures, create a detailed bar schedule
                    listing each bar type, quantity, and total weight.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
