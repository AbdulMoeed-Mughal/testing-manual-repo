"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Mountain, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "m" | "ft"
type ShapeType = "rectangular" | "circular"
type SoilType = "loose" | "compacted"

interface EarthworkResult {
  totalVolume: number
  looseVolume: number
  compactedVolume: number
}

export function EarthworkCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("m")
  const [shapeType, setShapeType] = useState<ShapeType>("rectangular")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [radius, setRadius] = useState("")
  const [depth, setDepth] = useState("")
  const [slopeAllowance, setSlopeAllowance] = useState("1")
  const [soilType, setSoilType] = useState<SoilType>("loose")
  const [result, setResult] = useState<EarthworkResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateEarthwork = () => {
    setError("")
    setResult(null)

    const depthNum = Number.parseFloat(depth)
    const slopeAllowanceNum = Number.parseFloat(slopeAllowance)

    if (isNaN(depthNum) || depthNum <= 0) {
      setError("Please enter a valid depth greater than 0")
      return
    }

    if (isNaN(slopeAllowanceNum) || slopeAllowanceNum <= 0) {
      setError("Please enter a valid slope allowance factor greater than 0")
      return
    }

    let volumeM3 = 0

    if (shapeType === "rectangular") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)

      if (isNaN(lengthNum) || lengthNum <= 0) {
        setError("Please enter a valid length greater than 0")
        return
      }

      if (isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter a valid width greater than 0")
        return
      }

      // Convert to meters if needed
      let lengthM = lengthNum
      let widthM = widthNum
      let depthM = depthNum

      if (unitSystem === "ft") {
        lengthM = lengthNum * 0.3048
        widthM = widthNum * 0.3048
        depthM = depthNum * 0.3048
      }

      volumeM3 = lengthM * widthM * depthM
    } else {
      // Circular
      const radiusNum = Number.parseFloat(radius)

      if (isNaN(radiusNum) || radiusNum <= 0) {
        setError("Please enter a valid radius greater than 0")
        return
      }

      // Convert to meters if needed
      let radiusM = radiusNum
      let depthM = depthNum

      if (unitSystem === "ft") {
        radiusM = radiusNum * 0.3048
        depthM = depthNum * 0.3048
      }

      volumeM3 = Math.PI * radiusM * radiusM * depthM
    }

    // Apply slope allowance
    const totalVolume = volumeM3 * slopeAllowanceNum

    // Calculate loose and compacted volumes
    // Loose soil is typically 25% more volume than in-situ
    // Compacted soil is typically 20% less volume than in-situ
    const looseVolume = totalVolume * 1.25
    const compactedVolume = totalVolume * 0.8

    // Convert to selected unit if feet
    let displayVolume = totalVolume
    let displayLooseVolume = looseVolume
    let displayCompactedVolume = compactedVolume

    if (unitSystem === "ft") {
      displayVolume = totalVolume * 35.3147 // m³ to ft³
      displayLooseVolume = looseVolume * 35.3147
      displayCompactedVolume = compactedVolume * 35.3147
    }

    setResult({
      totalVolume: displayVolume,
      looseVolume: displayLooseVolume,
      compactedVolume: displayCompactedVolume,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setRadius("")
    setDepth("")
    setSlopeAllowance("1")
    setSoilType("loose")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Earthwork: Total Volume: ${result.totalVolume.toFixed(2)} ${unitSystem}³, Loose Volume: ${result.looseVolume.toFixed(2)} ${unitSystem}³, Compacted Volume: ${result.compactedVolume.toFixed(2)} ${unitSystem}³`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Earthwork Calculator Result",
          text: `I calculated earthwork volume using CalcHub! Total Volume: ${result.totalVolume.toFixed(2)} ${unitSystem}³`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "m" ? "ft" : "m"))
    setLength("")
    setWidth("")
    setRadius("")
    setDepth("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Mountain className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Earthwork Calculator</CardTitle>
                    <CardDescription>Estimate earthwork volume for excavation and filling</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "ft" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "m" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Meters
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "ft" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Feet
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Shape Type */}
                <div className="space-y-2">
                  <Label htmlFor="shapeType">Area Shape</Label>
                  <Select value={shapeType} onValueChange={(value) => setShapeType(value as ShapeType)}>
                    <SelectTrigger id="shapeType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rectangular">Rectangular</SelectItem>
                      <SelectItem value="circular">Circular</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Conditional Dimension Inputs */}
                {shapeType === "rectangular" ? (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="length">Length ({unitSystem})</Label>
                      <Input
                        id="length"
                        type="number"
                        placeholder="0"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="width">Width ({unitSystem})</Label>
                      <Input
                        id="width"
                        type="number"
                        placeholder="0"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="radius">Radius ({unitSystem})</Label>
                    <Input
                      id="radius"
                      type="number"
                      placeholder="0"
                      value={radius}
                      onChange={(e) => setRadius(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                )}

                {/* Depth */}
                <div className="space-y-2">
                  <Label htmlFor="depth">Depth/Height ({unitSystem})</Label>
                  <Input
                    id="depth"
                    type="number"
                    placeholder="0"
                    value={depth}
                    onChange={(e) => setDepth(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Slope Allowance */}
                <div className="space-y-2">
                  <Label htmlFor="slopeAllowance">Slope Allowance Factor</Label>
                  <Input
                    id="slopeAllowance"
                    type="number"
                    placeholder="1"
                    value={slopeAllowance}
                    onChange={(e) => setSlopeAllowance(e.target.value)}
                    min="1"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">
                    Factor to account for sloped sides (1.0 = vertical, 1.2+ = sloped)
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateEarthwork} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Volume
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                      <div className="text-center mb-4">
                        <p className="text-sm text-muted-foreground mb-1">Total Earthwork Volume</p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">
                          {result.totalVolume.toFixed(2)}
                        </p>
                        <p className="text-sm font-medium text-amber-600">{unitSystem}³</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between p-2 rounded bg-white/50">
                          <span className="text-muted-foreground">Loose Soil Volume</span>
                          <span className="font-semibold text-foreground">
                            {result.looseVolume.toFixed(2)} {unitSystem}³
                          </span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded bg-white/50">
                          <span className="text-muted-foreground">Compacted Volume</span>
                          <span className="font-semibold text-foreground">
                            {result.compactedVolume.toFixed(2)} {unitSystem}³
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Soil Volume States</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">In-Situ (Bank)</h4>
                      <p className="text-sm text-amber-700">
                        Natural undisturbed state in the ground. Base volume measurement.
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Loose</h4>
                      <p className="text-sm text-amber-700">
                        Excavated soil, +25% volume. Used for hauling and storage calculations.
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Compacted</h4>
                      <p className="text-sm text-amber-700">
                        Compacted fill, -20% volume. Used for final embankment estimates.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex items-start gap-2 p-2">
                    <span className="text-amber-600">•</span>
                    <span>Foundation excavation</span>
                  </div>
                  <div className="flex items-start gap-2 p-2">
                    <span className="text-amber-600">•</span>
                    <span>Road construction and grading</span>
                  </div>
                  <div className="flex items-start gap-2 p-2">
                    <span className="text-amber-600">•</span>
                    <span>Embankment and leveling</span>
                  </div>
                  <div className="flex items-start gap-2 p-2">
                    <span className="text-amber-600">•</span>
                    <span>Cut and fill operations</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Earthwork */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Earthwork?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Earthwork refers to the process of moving, shaping, or modifying large quantities of soil and rock
                  during construction projects. This includes excavation (removing soil), grading (leveling terrain),
                  embankment (building up earth), and cut-and-fill operations where material is moved from one area to
                  another. Earthwork is fundamental to nearly all construction projects, from building foundations and
                  roads to landscaping and site preparation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Accurate earthwork volume calculations are critical for project planning and cost estimation. These
                  calculations help determine the amount of soil to be excavated or filled, the number of trucks needed
                  for hauling, and the time required for completion. Understanding soil volume changes between different
                  states (in-situ, loose, and compacted) is essential, as soil expands when excavated and compacts when
                  placed and compressed, affecting the total quantities and costs involved.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Earthwork Volume */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Earthwork Volume</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  For simple rectangular excavations, multiply length × width × depth to get the volume. For example, a
                  foundation excavation 10m long, 5m wide, and 2m deep would have a volume of 10 × 5 × 2 = 100 m³. For
                  circular areas like tank excavations, use the formula π × radius² × depth. If slopes are involved,
                  apply a slope allowance factor—for instance, 1:1 slopes (45 degrees) typically require a factor of
                  1.2 to 1.3 to account for the additional volume.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Once you have the in-situ (bank) volume, convert it based on the soil state. When excavated, soil
                  becomes "loose" and increases in volume by approximately 25% due to air voids. This loose volume is
                  important for determining truck capacity and hauling requirements. If the soil will be used as fill
                  and compacted, it will compress to about 80% of the in-situ volume. For our 100 m³ example, you would
                  need to haul 125 m³ of loose soil, but it would compact to only 80 m³ of fill. These conversion
                  factors vary by soil type, so adjust accordingly for your specific conditions.
                </p>
              </CardContent>
            </Card>

            {/* Understanding Soil Volume Changes */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Mountain className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Soil Volume Changes</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Soil volume changes significantly depending on its state, and understanding these changes is crucial
                  for accurate earthwork estimation. In-situ or "bank" soil is the natural, undisturbed state in the
                  ground and serves as the baseline measurement. When this soil is excavated, it "swells" or increases
                  in volume as particles separate and air fills the spaces between them. Different soil types swell by
                  different amounts—clay may swell by 30-40%, while sand and gravel typically swell by 10-15%. The 25%
                  factor used in this calculator represents a common average.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When loose soil is placed as fill and compacted, it shrinks below its original in-situ volume. Proper
                  compaction is essential for stability and load-bearing capacity. Well-compacted soil typically
                  achieves 80-90% of the in-situ volume, depending on soil type and compaction methods. This means if
                  you need 100 m³ of compacted fill, you must start with about 125 m³ of in-situ soil, which becomes
                  156 m³ when excavated loose. Always consider these volume changes when planning cut-and-fill
                  operations to ensure you have sufficient material and accurate cost estimates.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      What is the slope allowance factor and when should I use it?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The slope allowance factor accounts for sloped excavation sides rather than vertical cuts. Safety
                      regulations and soil stability often require sloped sides. A factor of 1.0 means vertical sides,
                      1.2 represents moderate slopes (about 2:1), and 1.5+ indicates gentler slopes. Use this factor to
                      calculate the additional volume created by sloped excavations. The actual factor depends on soil
                      type, depth, and local safety regulations.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      How do I determine if I need to import or export soil?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Compare your excavation (cut) volume with your fill requirements, accounting for soil volume
                      changes. If your cuts yield more compacted volume than needed for fills, you have excess to
                      export. If fills require more than your cuts provide, you need to import material. Remember to
                      convert volumes appropriately—excavated soil must be converted to compacted volume to compare with
                      fill requirements. It's wise to add a 5-10% contingency for waste and uncontrollable losses.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      Can I use this calculator for complex terrains?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      This calculator is designed for simple, uniform excavations and fills. For complex terrain with
                      varying depths and irregular shapes, divide the area into simpler sections and calculate each
                      separately, then sum the results. For large-scale projects with significant terrain variations,
                      consider using specialized earthwork software or surveying methods like the grid method or
                      cross-section method, which provide more accurate volume calculations for complex topography.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      What equipment do I need for different earthwork volumes?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Equipment selection depends on volume and project timeline. Small volumes (under 50 m³) can often
                      be handled with mini excavators and skid steers. Medium projects (50-500 m³) typically use
                      standard excavators and loaders. Large projects (500+ m³) may require bulldozers, scrapers, and
                      large excavators. For hauling, standard dump trucks hold about 10-15 m³ of loose soil. Calculate
                      the number of truck loads by dividing your loose volume by the truck capacity, and consider
                      multiple trips if needed.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p className="font-semibold text-amber-900">Important Disclaimer</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Earthwork calculations are estimates based on simplified geometry. Actual volumes depend on soil
                      conditions, compaction methods, moisture content, and field tolerances. Volume change factors
                      (swell and shrinkage) vary by soil type and should be verified for your specific conditions.
                      Always conduct soil testing and consult with geotechnical engineers for critical applications.
                      Include contingencies in your estimates to account for variations and unforeseen conditions.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
