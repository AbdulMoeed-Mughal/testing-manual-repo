"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface DotProductResult {
  dotProduct: number
  magnitudeA: number
  magnitudeB: number
  angleDegrees: number
  angleRadians: number
  isOrthogonal: boolean
  isParallel: boolean
  steps: string[]
}

export function DotProductCalculator() {
  const [is3D, setIs3D] = useState(false)
  const [vectorA, setVectorA] = useState({ x: "", y: "", z: "" })
  const [vectorB, setVectorB] = useState({ x: "", y: "", z: "" })
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<DotProductResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDotProduct = () => {
    setError("")
    setResult(null)

    const ax = Number.parseFloat(vectorA.x)
    const ay = Number.parseFloat(vectorA.y)
    const az = is3D ? Number.parseFloat(vectorA.z) : 0
    const bx = Number.parseFloat(vectorB.x)
    const by = Number.parseFloat(vectorB.y)
    const bz = is3D ? Number.parseFloat(vectorB.z) : 0

    if (isNaN(ax) || isNaN(ay) || isNaN(bx) || isNaN(by)) {
      setError("Please enter valid numeric values for all vector components")
      return
    }

    if (is3D && (isNaN(az) || isNaN(bz))) {
      setError("Please enter valid numeric values for all vector components")
      return
    }

    const steps: string[] = []

    // Step 1: Identify vectors
    if (is3D) {
      steps.push(`Vector A = (${ax}, ${ay}, ${az})`)
      steps.push(`Vector B = (${bx}, ${by}, ${bz})`)
    } else {
      steps.push(`Vector A = (${ax}, ${ay})`)
      steps.push(`Vector B = (${bx}, ${by})`)
    }

    // Step 2: Calculate dot product
    let dotProduct: number
    if (is3D) {
      dotProduct = ax * bx + ay * by + az * bz
      steps.push(`A · B = (${ax})(${bx}) + (${ay})(${by}) + (${az})(${bz})`)
      steps.push(`A · B = ${ax * bx} + ${ay * by} + ${az * bz}`)
    } else {
      dotProduct = ax * bx + ay * by
      steps.push(`A · B = (${ax})(${bx}) + (${ay})(${by})`)
      steps.push(`A · B = ${ax * bx} + ${ay * by}`)
    }
    steps.push(`A · B = ${dotProduct}`)

    // Step 3: Calculate magnitudes
    const magnitudeA = Math.sqrt(ax * ax + ay * ay + (is3D ? az * az : 0))
    const magnitudeB = Math.sqrt(bx * bx + by * by + (is3D ? bz * bz : 0))

    if (is3D) {
      steps.push(`|A| = √(${ax}² + ${ay}² + ${az}²) = √${ax * ax + ay * ay + az * az} = ${magnitudeA.toFixed(6)}`)
      steps.push(`|B| = √(${bx}² + ${by}² + ${bz}²) = √${bx * bx + by * by + bz * bz} = ${magnitudeB.toFixed(6)}`)
    } else {
      steps.push(`|A| = √(${ax}² + ${ay}²) = √${ax * ax + ay * ay} = ${magnitudeA.toFixed(6)}`)
      steps.push(`|B| = √(${bx}² + ${by}²) = √${bx * bx + by * by} = ${magnitudeB.toFixed(6)}`)
    }

    // Step 4: Calculate angle
    let angleDegrees = 0
    let angleRadians = 0
    const isOrthogonal = Math.abs(dotProduct) < 1e-10

    if (magnitudeA === 0 || magnitudeB === 0) {
      steps.push("Cannot calculate angle: one or both vectors have zero magnitude")
    } else {
      const cosTheta = dotProduct / (magnitudeA * magnitudeB)
      // Clamp to [-1, 1] to handle floating point errors
      const clampedCosTheta = Math.max(-1, Math.min(1, cosTheta))
      angleRadians = Math.acos(clampedCosTheta)
      angleDegrees = angleRadians * (180 / Math.PI)

      steps.push(`cos(θ) = (A · B) / (|A| × |B|)`)
      steps.push(`cos(θ) = ${dotProduct} / (${magnitudeA.toFixed(6)} × ${magnitudeB.toFixed(6)})`)
      steps.push(`cos(θ) = ${cosTheta.toFixed(6)}`)
      steps.push(`θ = arccos(${cosTheta.toFixed(6)}) = ${angleDegrees.toFixed(4)}°`)
    }

    // Check if vectors are parallel (angle is 0° or 180°)
    const isParallel = Math.abs(angleDegrees) < 0.0001 || Math.abs(angleDegrees - 180) < 0.0001

    setResult({
      dotProduct,
      magnitudeA,
      magnitudeB,
      angleDegrees,
      angleRadians,
      isOrthogonal,
      isParallel,
      steps,
    })
  }

  const handleReset = () => {
    setVectorA({ x: "", y: "", z: "" })
    setVectorB({ x: "", y: "", z: "" })
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Dot Product: ${result.dotProduct}\nMagnitude A: ${result.magnitudeA.toFixed(6)}\nMagnitude B: ${result.magnitudeB.toFixed(6)}\nAngle: ${result.angleDegrees.toFixed(4)}°`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Dot Product Result",
          text: `I calculated the dot product using CalcHub! A · B = ${result.dotProduct}, Angle = ${result.angleDegrees.toFixed(4)}°`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleDimension = () => {
    setIs3D((prev) => !prev)
    setVectorA({ x: "", y: "", z: "" })
    setVectorB({ x: "", y: "", z: "" })
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Dot Product Calculator</CardTitle>
                    <CardDescription>Calculate the dot product of two vectors</CardDescription>
                  </div>
                </div>

                {/* Dimension Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Dimension</span>
                  <button
                    onClick={toggleDimension}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        is3D ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !is3D ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      2D
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        is3D ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      3D
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Vector A */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Vector A</Label>
                  <div className={`grid gap-2 ${is3D ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Label htmlFor="ax" className="text-xs text-muted-foreground">
                        x₁
                      </Label>
                      <Input
                        id="ax"
                        type="number"
                        placeholder="0"
                        value={vectorA.x}
                        onChange={(e) => setVectorA({ ...vectorA, x: e.target.value })}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="ay" className="text-xs text-muted-foreground">
                        y₁
                      </Label>
                      <Input
                        id="ay"
                        type="number"
                        placeholder="0"
                        value={vectorA.y}
                        onChange={(e) => setVectorA({ ...vectorA, y: e.target.value })}
                        step="any"
                      />
                    </div>
                    {is3D && (
                      <div>
                        <Label htmlFor="az" className="text-xs text-muted-foreground">
                          z₁
                        </Label>
                        <Input
                          id="az"
                          type="number"
                          placeholder="0"
                          value={vectorA.z}
                          onChange={(e) => setVectorA({ ...vectorA, z: e.target.value })}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Vector B */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Vector B</Label>
                  <div className={`grid gap-2 ${is3D ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Label htmlFor="bx" className="text-xs text-muted-foreground">
                        x₂
                      </Label>
                      <Input
                        id="bx"
                        type="number"
                        placeholder="0"
                        value={vectorB.x}
                        onChange={(e) => setVectorB({ ...vectorB, x: e.target.value })}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="by" className="text-xs text-muted-foreground">
                        y₂
                      </Label>
                      <Input
                        id="by"
                        type="number"
                        placeholder="0"
                        value={vectorB.y}
                        onChange={(e) => setVectorB({ ...vectorB, y: e.target.value })}
                        step="any"
                      />
                    </div>
                    {is3D && (
                      <div>
                        <Label htmlFor="bz" className="text-xs text-muted-foreground">
                          z₂
                        </Label>
                        <Input
                          id="bz"
                          type="number"
                          placeholder="0"
                          value={vectorB.z}
                          onChange={(e) => setVectorB({ ...vectorB, z: e.target.value })}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps" className="text-sm">
                    Show step-by-step solution
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDotProduct} className="w-full" size="lg">
                  Calculate Dot Product
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Dot Product (A · B)</p>
                      <p className="text-4xl font-bold text-blue-600 mb-2">{result.dotProduct}</p>
                      {result.isOrthogonal && (
                        <span className="inline-block px-2 py-1 text-xs font-medium bg-green-100 text-green-700 rounded-full">
                          Orthogonal (Perpendicular)
                        </span>
                      )}
                      {result.isParallel && (
                        <span className="inline-block px-2 py-1 text-xs font-medium bg-amber-100 text-amber-700 rounded-full">
                          Parallel
                        </span>
                      )}
                    </div>

                    {/* Additional Results */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">|A|</p>
                        <p className="font-semibold text-foreground">{result.magnitudeA.toFixed(4)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">|B|</p>
                        <p className="font-semibold text-foreground">{result.magnitudeB.toFixed(4)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Angle (°)</p>
                        <p className="font-semibold text-foreground">{result.angleDegrees.toFixed(4)}°</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Angle (rad)</p>
                        <p className="font-semibold text-foreground">{result.angleRadians.toFixed(4)}</p>
                      </div>
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible defaultOpen>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full mb-2">
                            Step-by-Step Solution
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="p-3 bg-white rounded-lg space-y-1">
                            {result.steps.map((step, index) => (
                              <p key={index} className="text-sm font-mono text-muted-foreground">
                                {step}
                              </p>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dot Product Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">2D: A · B = x₁x₂ + y₁y₂</p>
                    <p className="font-semibold text-foreground">3D: A · B = x₁x₂ + y₁y₂ + z₁z₂</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">θ = arccos(A · B / (|A||B|))</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(1, 0) · (0, 1)</span>
                      <span className="font-mono font-semibold">0 (⊥)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(1, 2) · (3, 4)</span>
                      <span className="font-mono font-semibold">11</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(1, 0, 0) · (0, 1, 0)</span>
                      <span className="font-mono font-semibold">0 (⊥)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(1, 2, 3) · (4, 5, 6)</span>
                      <span className="font-mono font-semibold">32</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Properties</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-medium text-green-700">If A · B = 0</p>
                    <p className="text-green-600">Vectors are orthogonal (perpendicular)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <p className="font-medium text-amber-700">If A · B {">"} 0</p>
                    <p className="text-amber-600">Angle between vectors is acute ({"<"} 90°)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                    <p className="font-medium text-red-700">If A · B {"<"} 0</p>
                    <p className="text-red-600">Angle between vectors is obtuse ({">"} 90°)</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Dot Product?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The dot product (also called the scalar product or inner product) is a fundamental operation in vector
                  algebra that takes two vectors and returns a single scalar value. It measures how much two vectors
                  point in the same direction and has widespread applications in physics, engineering, computer
                  graphics, and machine learning.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Geometrically, the dot product represents the product of the magnitudes of two vectors and the cosine
                  of the angle between them: A · B = |A||B|cos(θ). This relationship makes it invaluable for determining
                  angles between vectors, projecting one vector onto another, and testing for perpendicularity.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of the Dot Product</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Physics:</strong> The dot product is essential for calculating work done by a force (W = F ·
                  d), where work is the force applied in the direction of displacement. It's also used in calculating
                  power, torque components, and electromagnetic field interactions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Computer Graphics:</strong> Lighting calculations rely heavily on dot products to determine
                  how light interacts with surfaces. The angle between the light direction and surface normal determines
                  brightness. It's also used in collision detection and ray tracing.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Machine Learning:</strong> Dot products form the basis of neural network computations, where
                  inputs are multiplied by weights and summed. Cosine similarity, derived from the dot product, measures
                  how similar two vectors are in high-dimensional spaces.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm">
                  Dot product calculations follow standard Euclidean formulas. Results depend on correct component input
                  and selected dimension. This calculator is intended for educational and reference purposes. Always
                  verify critical calculations independently.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
