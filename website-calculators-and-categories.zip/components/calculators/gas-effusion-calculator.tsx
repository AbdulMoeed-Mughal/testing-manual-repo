"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, Wind, Gauge, ArrowRightLeft } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMode = "rate-ratio" | "find-rate" | "find-time"

interface EffusionResult {
  rateRatio: number
  fasterGas: number
  percentDifference: number
  calculatedValue?: number
  calculatedUnit?: string
}

export function GasEffusionCalculator() {
  const [mode, setMode] = useState<CalculationMode>("rate-ratio")
  const [molarMass1, setMolarMass1] = useState("")
  const [molarMass2, setMolarMass2] = useState("")
  const [knownRate, setKnownRate] = useState("")
  const [knownTime, setKnownTime] = useState("")
  const [result, setResult] = useState<EffusionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const m1 = Number.parseFloat(molarMass1)
    const m2 = Number.parseFloat(molarMass2)

    if (isNaN(m1) || m1 <= 0) {
      setError("Please enter a valid molar mass for Gas 1 (must be positive)")
      return
    }

    if (isNaN(m2) || m2 <= 0) {
      setError("Please enter a valid molar mass for Gas 2 (must be positive)")
      return
    }

    // Graham's Law: Rate₁/Rate₂ = √(M₂/M₁)
    const rateRatio = Math.sqrt(m2 / m1)
    const fasterGas = m1 < m2 ? 1 : 2
    const percentDifference = Math.abs(rateRatio - 1) * 100

    let calculatedValue: number | undefined
    let calculatedUnit: string | undefined

    if (mode === "find-rate") {
      const rate = Number.parseFloat(knownRate)
      if (isNaN(rate) || rate <= 0) {
        setError("Please enter a valid effusion rate for Gas 1")
        return
      }
      // Rate₂ = Rate₁ / rateRatio
      calculatedValue = rate / rateRatio
      calculatedUnit = "units/s"
    } else if (mode === "find-time") {
      const time = Number.parseFloat(knownTime)
      if (isNaN(time) || time <= 0) {
        setError("Please enter a valid effusion time for Gas 1")
        return
      }
      // Time₁/Time₂ = √(M₁/M₂), so Time₂ = Time₁ × √(M₂/M₁)
      calculatedValue = time * Math.sqrt(m2 / m1)
      calculatedUnit = "seconds"
    }

    setResult({
      rateRatio,
      fasterGas,
      percentDifference,
      calculatedValue,
      calculatedUnit,
    })
  }

  const handleReset = () => {
    setMolarMass1("")
    setMolarMass2("")
    setKnownRate("")
    setKnownTime("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = `Gas Effusion Rate Ratio: ${result.rateRatio.toFixed(4)} (Gas ${result.fasterGas} effuses faster)`
      if (result.calculatedValue) {
        text += ` | Calculated value: ${result.calculatedValue.toFixed(4)} ${result.calculatedUnit}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const commonGases = [
    { name: "Hydrogen (H₂)", mass: 2.016 },
    { name: "Helium (He)", mass: 4.003 },
    { name: "Methane (CH₄)", mass: 16.04 },
    { name: "Ammonia (NH₃)", mass: 17.03 },
    { name: "Water vapor (H₂O)", mass: 18.015 },
    { name: "Nitrogen (N₂)", mass: 28.014 },
    { name: "Oxygen (O₂)", mass: 31.998 },
    { name: "Carbon dioxide (CO₂)", mass: 44.01 },
    { name: "Sulfur dioxide (SO₂)", mass: 64.07 },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2 bg-transparent">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Wind className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gas Effusion Calculator</CardTitle>
                    <CardDescription>Graham's Law of Effusion</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Calculation Mode</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setMode("rate-ratio")}
                      className={`px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors ${
                        mode === "rate-ratio"
                          ? "bg-purple-600 text-white"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      Rate Ratio
                    </button>
                    <button
                      onClick={() => setMode("find-rate")}
                      className={`px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors ${
                        mode === "find-rate"
                          ? "bg-purple-600 text-white"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      Find Rate
                    </button>
                    <button
                      onClick={() => setMode("find-time")}
                      className={`px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors ${
                        mode === "find-time"
                          ? "bg-purple-600 text-white"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      Find Time
                    </button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Molar Mass Inputs */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="molarMass1">Molar Mass Gas 1 (g/mol)</Label>
                    <Input
                      id="molarMass1"
                      type="number"
                      placeholder="e.g., 2.016"
                      value={molarMass1}
                      onChange={(e) => setMolarMass1(e.target.value)}
                      min="0"
                      step="0.001"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="molarMass2">Molar Mass Gas 2 (g/mol)</Label>
                    <Input
                      id="molarMass2"
                      type="number"
                      placeholder="e.g., 32.00"
                      value={molarMass2}
                      onChange={(e) => setMolarMass2(e.target.value)}
                      min="0"
                      step="0.001"
                    />
                  </div>
                </div>

                {/* Conditional Inputs based on mode */}
                {mode === "find-rate" && (
                  <div className="space-y-2">
                    <Label htmlFor="knownRate">Effusion Rate of Gas 1 (units/s)</Label>
                    <Input
                      id="knownRate"
                      type="number"
                      placeholder="Enter known rate"
                      value={knownRate}
                      onChange={(e) => setKnownRate(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                {mode === "find-time" && (
                  <div className="space-y-2">
                    <Label htmlFor="knownTime">Effusion Time of Gas 1 (seconds)</Label>
                    <Input
                      id="knownTime"
                      type="number"
                      placeholder="Enter known time"
                      value={knownTime}
                      onChange={(e) => setKnownTime(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full bg-purple-600 hover:bg-purple-700" size="lg">
                  Calculate Effusion
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Rate Ratio (Rate₁/Rate₂)</p>
                      <p className="text-4xl font-bold text-purple-600 mb-2">{result.rateRatio.toFixed(4)}</p>
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${
                        result.fasterGas === 1 
                          ? "bg-green-100 text-green-700" 
                          : "bg-blue-100 text-blue-700"
                      }`}>
                        <Gauge className="h-4 w-4" />
                        Gas {result.fasterGas} effuses {result.rateRatio > 1 ? result.rateRatio.toFixed(2) : (1/result.rateRatio).toFixed(2)}× faster
                      </div>
                    </div>

                    {/* Additional Results */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Percent Difference</p>
                        <p className="text-lg font-semibold text-purple-600">{result.percentDifference.toFixed(2)}%</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Inverse Ratio</p>
                        <p className="text-lg font-semibold text-purple-600">{(1/result.rateRatio).toFixed(4)}</p>
                      </div>
                    </div>

                    {result.calculatedValue && (
                      <div className="mt-3 p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">
                          {mode === "find-rate" ? "Effusion Rate of Gas 2" : "Effusion Time for Gas 2"}
                        </p>
                        <p className="text-lg font-semibold text-purple-600">
                          {result.calculatedValue.toFixed(4)} {result.calculatedUnit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset} className="bg-transparent">
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy} className="bg-transparent">
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Graham's Law Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                    <p className="font-mono text-center text-purple-800 font-semibold">
                      Rate₁ / Rate₂ = √(M₂ / M₁)
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-mono text-center text-sm">
                      Time₁ / Time₂ = √(M₁ / M₂)
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Where M₁ and M₂ are the molar masses of the two gases. Lighter gases effuse faster.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Gas Molar Masses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {commonGases.map((gas) => (
                      <div
                        key={gas.name}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                        onClick={() => {
                          if (!molarMass1) {
                            setMolarMass1(gas.mass.toString())
                          } else if (!molarMass2) {
                            setMolarMass2(gas.mass.toString())
                          }
                        }}
                      >
                        <span className="text-sm">{gas.name}</span>
                        <span className="text-sm font-mono text-purple-600">{gas.mass} g/mol</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    Click a gas to fill in the molar mass field
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Step-by-Step Calculation */}
          {result && molarMass1 && molarMass2 && (
            <Card className="mt-6">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5 text-purple-600" />
                  <CardTitle>Step-by-Step Calculation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Step 1: Identify Values</p>
                    <p className="text-sm font-medium">M₁ = {molarMass1} g/mol</p>
                    <p className="text-sm font-medium">M₂ = {molarMass2} g/mol</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Step 2: Calculate Ratio</p>
                    <p className="text-sm font-medium">M₂/M₁ = {(Number.parseFloat(molarMass2) / Number.parseFloat(molarMass1)).toFixed(4)}</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Step 3: Take Square Root</p>
                    <p className="text-sm font-medium">√(M₂/M₁) = {result.rateRatio.toFixed(4)}</p>
                  </div>
                  <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                    <p className="text-xs text-muted-foreground mb-1">Result</p>
                    <p className="text-sm font-medium text-purple-700">Rate₁/Rate₂ = {result.rateRatio.toFixed(4)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Educational Content */}
          <div className="mt-8 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-purple-600" />
                  <CardTitle>What is Graham's Law of Effusion?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Graham's Law of Effusion, discovered by Scottish chemist Thomas Graham in 1848, describes the 
                  relationship between the rate at which gases escape through a small opening (effusion) and their 
                  molar masses. The law states that the rate of effusion of a gas is inversely proportional to the 
                  square root of its molar mass. This means lighter gases effuse faster than heavier gases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Effusion is the process by which gas molecules pass through a tiny opening into a vacuum or 
                  lower pressure region. This is different from diffusion, which is the spreading of gas molecules 
                  throughout a space. However, Graham's Law applies to both processes under ideal conditions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Wind className="h-5 w-5 text-purple-600" />
                  <CardTitle>Applications of Graham's Law</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Uranium Enrichment</h4>
                    <p className="text-sm text-muted-foreground">
                      Graham's Law is used in gaseous diffusion plants to separate uranium isotopes 
                      (U-235 and U-238) in the form of uranium hexafluoride gas.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Leak Detection</h4>
                    <p className="text-sm text-muted-foreground">
                      Helium, being a light gas, effuses quickly and is used to detect leaks in 
                      vacuum systems and sealed containers.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Gas Identification</h4>
                    <p className="text-sm text-muted-foreground">
                      By measuring effusion rates, unknown gases can be identified by comparing 
                      them to gases with known molar masses.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Balloon Deflation</h4>
                    <p className="text-sm text-muted-foreground">
                      Helium balloons deflate faster than air-filled balloons because helium 
                      effuses through the balloon material more quickly.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <Card className="mt-6 border-purple-200 bg-purple-50/50">
            <CardContent className="py-4">
              <p className="text-sm text-muted-foreground text-center">
                <strong>Note:</strong> Graham's Law applies to ideal gases under identical conditions. 
                Real gas behavior may deviate due to intermolecular forces or non-ideal conditions.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
