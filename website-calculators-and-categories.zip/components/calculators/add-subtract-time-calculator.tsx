"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Clock, Info, Calculator, Plus, Minus } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface TimeResult {
  hours: number
  minutes: number
  seconds: number
  formatted12h: string
  formatted24h: string
  dayOffset: number
}

export function AddSubtractTimeCalculator() {
  const [operation, setOperation] = useState<"add" | "subtract">("add")
  const [baseHours, setBaseHours] = useState("")
  const [baseMinutes, setBaseMinutes] = useState("")
  const [baseSeconds, setBaseSeconds] = useState("")
  const [addHours, setAddHours] = useState("")
  const [addMinutes, setAddMinutes] = useState("")
  const [addSeconds, setAddSeconds] = useState("")
  const [result, setResult] = useState<TimeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateTime = () => {
    setError("")
    setResult(null)

    const bHours = Number.parseInt(baseHours) || 0
    const bMinutes = Number.parseInt(baseMinutes) || 0
    const bSeconds = Number.parseInt(baseSeconds) || 0
    const aHours = Number.parseInt(addHours) || 0
    const aMinutes = Number.parseInt(addMinutes) || 0
    const aSeconds = Number.parseInt(addSeconds) || 0

    if (
      bHours < 0 ||
      bHours > 23 ||
      bMinutes < 0 ||
      bMinutes > 59 ||
      bSeconds < 0 ||
      bSeconds > 59
    ) {
      setError("Please enter a valid base time (0-23 hours, 0-59 minutes, 0-59 seconds)")
      return
    }

    if (aHours < 0 || aMinutes < 0 || aSeconds < 0) {
      setError("Duration values must be non-negative")
      return
    }

    // Convert to total seconds
    let totalSeconds = bHours * 3600 + bMinutes * 60 + bSeconds
    const addTotalSeconds = aHours * 3600 + aMinutes * 60 + aSeconds

    // Add or subtract
    if (operation === "add") {
      totalSeconds += addTotalSeconds
    } else {
      totalSeconds -= addTotalSeconds
    }

    // Handle day offset
    let dayOffset = 0
    while (totalSeconds >= 86400) {
      totalSeconds -= 86400
      dayOffset++
    }
    while (totalSeconds < 0) {
      totalSeconds += 86400
      dayOffset--
    }

    // Convert back to hours, minutes, seconds
    const hours = Math.floor(totalSeconds / 3600)
    const minutes = Math.floor((totalSeconds % 3600) / 60)
    const seconds = totalSeconds % 60

    // Format 12-hour
    const period = hours >= 12 ? "PM" : "AM"
    const hours12 = hours === 0 ? 12 : hours > 12 ? hours - 12 : hours
    const formatted12h = `${hours12}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")} ${period}`

    // Format 24-hour
    const formatted24h = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`

    setResult({ hours, minutes, seconds, formatted12h, formatted24h, dayOffset })
  }

  const handleReset = () => {
    setBaseHours("")
    setBaseMinutes("")
    setBaseSeconds("")
    setAddHours("")
    setAddMinutes("")
    setAddSeconds("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Result: ${result.formatted24h} (${result.formatted12h})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Time Calculation",
          text: `I calculated time using CalcHub! Result: ${result.formatted24h}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Clock className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Add/Subtract Time Calculator</CardTitle>
                    <CardDescription>Calculate time by adding or subtracting duration</CardDescription>
                  </div>
                </div>

                {/* Operation Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Operation</span>
                  <button
                    onClick={() => setOperation(operation === "add" ? "subtract" : "add")}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        operation === "subtract" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        operation === "add" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Add
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        operation === "subtract" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Subtract
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Base Time Input */}
                <div className="space-y-2">
                  <Label>Base Time (HH:MM:SS)</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Input
                      type="number"
                      placeholder="Hours"
                      value={baseHours}
                      onChange={(e) => setBaseHours(e.target.value)}
                      min="0"
                      max="23"
                    />
                    <Input
                      type="number"
                      placeholder="Minutes"
                      value={baseMinutes}
                      onChange={(e) => setBaseMinutes(e.target.value)}
                      min="0"
                      max="59"
                    />
                    <Input
                      type="number"
                      placeholder="Seconds"
                      value={baseSeconds}
                      onChange={(e) => setBaseSeconds(e.target.value)}
                      min="0"
                      max="59"
                    />
                  </div>
                </div>

                {/* Duration to Add/Subtract */}
                <div className="space-y-2">
                  <Label>Duration to {operation === "add" ? "Add" : "Subtract"}</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Input
                      type="number"
                      placeholder="Hours"
                      value={addHours}
                      onChange={(e) => setAddHours(e.target.value)}
                      min="0"
                    />
                    <Input
                      type="number"
                      placeholder="Minutes"
                      value={addMinutes}
                      onChange={(e) => setAddMinutes(e.target.value)}
                      min="0"
                    />
                    <Input
                      type="number"
                      placeholder="Seconds"
                      value={addSeconds}
                      onChange={(e) => setAddSeconds(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTime} className="w-full" size="lg">
                  Calculate Time
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <p className="text-4xl font-bold text-cyan-600 mb-2">{result.formatted24h}</p>
                      <p className="text-lg text-cyan-700 mb-1">{result.formatted12h}</p>
                      {result.dayOffset !== 0 && (
                        <p className="text-xs text-muted-foreground">
                          {result.dayOffset > 0 ? `+${result.dayOffset}` : result.dayOffset} day(s)
                        </p>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Use Cases</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <p>Schedule meetings across time zones</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <p>Calculate cooking or baking times</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <p>Track work hours and shifts</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <p>Plan travel itineraries</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Time Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    <strong>24-hour format:</strong> Uses 00:00 to 23:59 (military time)
                  </p>
                  <p>
                    <strong>12-hour format:</strong> Uses 12:00 AM to 11:59 PM with AM/PM indicators
                  </p>
                  <p>
                    The calculator automatically handles time rollovers when crossing midnight.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Time Addition/Subtraction */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Time Addition/Subtraction?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Time addition and subtraction are mathematical operations that allow you to calculate a new
                  time by adding or removing a specific duration from a base time. This calculation is
                  essential for scheduling, planning, and time management tasks where you need to determine
                  when an event will end, when to start a task to meet a deadline, or how to coordinate
                  activities across different time periods.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Unlike simple arithmetic, time calculations must account for the base-60 system (60 seconds
                  in a minute, 60 minutes in an hour) and the 24-hour or 12-hour clock format. This calculator
                  automatically handles these conversions and ensures accurate results, including managing
                  midnight rollovers when the calculated time crosses into the next or previous day.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Time */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Time</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To add time, start with your base time and add the hours, minutes, and seconds separately.
                  When any component exceeds its maximum value (60 for seconds or minutes, 24 for hours), carry
                  over the excess to the next higher unit. For example, adding 45 minutes to 10:30:00 gives you
                  11:15:00, but adding 45 minutes to 10:45:00 results in 11:30:00 (45+45=90 minutes = 1 hour and
                  30 minutes).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Subtracting time works similarly but in reverse. If any component becomes negative during
                  subtraction, borrow from the next higher unit. For instance, subtracting 45 minutes from
                  10:30:00 gives 9:45:00 (you borrow 1 hour from 10 hours, making it 9 hours and 90 minutes,
                  then subtract 45 minutes to get 9:45:00).
                </p>
              </CardContent>
            </Card>

            {/* Practical Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Time calculations are used daily in numerous scenarios. Professionals use them to schedule
                  meetings, coordinate work shifts, and plan project timelines. Travelers rely on time
                  calculations when booking flights, especially when dealing with layovers and time zone
                  changes. Healthcare providers use precise time calculations for medication schedules and
                  treatment protocols.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In everyday life, you might use time calculations to plan cooking multiple dishes that
                  require different preparation times, schedule back-to-back appointments with travel time in
                  between, or determine when to leave for an event considering commute duration. The calculator
                  simplifies these tasks by automatically handling the complex conversions and rollovers that
                  occur when working with time.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground text-center">
                  <strong>Note:</strong> Time calculations are based on entered values. Results may vary due to
                  time zones or daylight saving changes. For precise time zone conversions, use a dedicated time
                  zone converter.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
