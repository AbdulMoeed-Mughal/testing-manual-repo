"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, Plus, Minus, ArrowRight } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface VectorInput {
  x: string
  y: string
  z: string
}

interface VectorResult {
  components: { x: number; y: number; z: number }
  magnitude: number
  directionAngles: { alpha: number; beta: number; gamma: number }
  steps: string[]
}

export function VectorAdditionCalculator() {
  const [is3D, setIs3D] = useState(false)
  const [vectors, setVectors] = useState<VectorInput[]>([
    { x: "", y: "", z: "" },
    { x: "", y: "", z: "" },
  ])
  const [result, setResult] = useState<VectorResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const addVector = () => {
    if (vectors.length < 10) {
      setVectors([...vectors, { x: "", y: "", z: "" }])
    }
  }

  const removeVector = (index: number) => {
    if (vectors.length > 2) {
      setVectors(vectors.filter((_, i) => i !== index))
    }
  }

  const updateVector = (index: number, field: keyof VectorInput, value: string) => {
    const newVectors = [...vectors]
    newVectors[index][field] = value
    setVectors(newVectors)
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const parsedVectors: { x: number; y: number; z: number }[] = []

    for (let i = 0; i < vectors.length; i++) {
      const v = vectors[i]
      const x = Number.parseFloat(v.x)
      const y = Number.parseFloat(v.y)
      const z = is3D ? Number.parseFloat(v.z) : 0

      if (isNaN(x) || isNaN(y) || (is3D && isNaN(z))) {
        setError(`Please enter valid numeric values for Vector ${i + 1}`)
        return
      }

      parsedVectors.push({ x, y, z })
    }

    // Check at least one non-zero vector
    const hasNonZero = parsedVectors.some((v) => v.x !== 0 || v.y !== 0 || v.z !== 0)
    if (!hasNonZero) {
      setError("At least one vector must be non-zero")
      return
    }

    // Calculate resultant
    let Rx = 0
    let Ry = 0
    let Rz = 0

    const steps: string[] = []
    steps.push("Step 1: Identify the components of each vector")
    parsedVectors.forEach((v, i) => {
      if (is3D) {
        steps.push(`  Vector ${i + 1}: (${v.x}, ${v.y}, ${v.z})`)
      } else {
        steps.push(`  Vector ${i + 1}: (${v.x}, ${v.y})`)
      }
    })

    steps.push("")
    steps.push("Step 2: Sum the components")

    const xComponents = parsedVectors.map((v) => v.x)
    const yComponents = parsedVectors.map((v) => v.y)
    const zComponents = parsedVectors.map((v) => v.z)

    Rx = xComponents.reduce((a, b) => a + b, 0)
    Ry = yComponents.reduce((a, b) => a + b, 0)
    Rz = zComponents.reduce((a, b) => a + b, 0)

    steps.push(`  Rₓ = ${xComponents.join(" + ")} = ${Rx}`)
    steps.push(`  Rᵧ = ${yComponents.join(" + ")} = ${Ry}`)
    if (is3D) {
      steps.push(`  Rᵤ = ${zComponents.join(" + ")} = ${Rz}`)
    }

    steps.push("")
    steps.push("Step 3: Calculate the magnitude")

    let magnitude: number
    if (is3D) {
      magnitude = Math.sqrt(Rx * Rx + Ry * Ry + Rz * Rz)
      steps.push(`  |R| = √(Rₓ² + Rᵧ² + Rᵤ²)`)
      steps.push(`  |R| = √(${Rx}² + ${Ry}² + ${Rz}²)`)
      steps.push(`  |R| = √(${Rx * Rx} + ${Ry * Ry} + ${Rz * Rz})`)
      steps.push(`  |R| = √${Rx * Rx + Ry * Ry + Rz * Rz}`)
    } else {
      magnitude = Math.sqrt(Rx * Rx + Ry * Ry)
      steps.push(`  |R| = √(Rₓ² + Rᵧ²)`)
      steps.push(`  |R| = √(${Rx}² + ${Ry}²)`)
      steps.push(`  |R| = √(${Rx * Rx} + ${Ry * Ry})`)
      steps.push(`  |R| = √${Rx * Rx + Ry * Ry}`)
    }
    steps.push(`  |R| = ${magnitude.toFixed(6)}`)

    steps.push("")
    steps.push("Step 4: Calculate direction angles")

    let alpha = 0,
      beta = 0,
      gamma = 0
    if (magnitude > 0) {
      alpha = Math.acos(Rx / magnitude) * (180 / Math.PI)
      beta = Math.acos(Ry / magnitude) * (180 / Math.PI)
      if (is3D) {
        gamma = Math.acos(Rz / magnitude) * (180 / Math.PI)
        steps.push(
          `  α (angle with x-axis) = cos⁻¹(Rₓ/|R|) = cos⁻¹(${Rx}/${magnitude.toFixed(4)}) = ${alpha.toFixed(2)}°`,
        )
        steps.push(
          `  β (angle with y-axis) = cos⁻¹(Rᵧ/|R|) = cos⁻¹(${Ry}/${magnitude.toFixed(4)}) = ${beta.toFixed(2)}°`,
        )
        steps.push(
          `  γ (angle with z-axis) = cos⁻¹(Rᵤ/|R|) = cos⁻¹(${Rz}/${magnitude.toFixed(4)}) = ${gamma.toFixed(2)}°`,
        )
      } else {
        const theta = Math.atan2(Ry, Rx) * (180 / Math.PI)
        steps.push(`  θ (angle from positive x-axis) = tan⁻¹(Rᵧ/Rₓ) = tan⁻¹(${Ry}/${Rx}) = ${theta.toFixed(2)}°`)
        steps.push(`  α (angle with x-axis) = ${alpha.toFixed(2)}°`)
        steps.push(`  β (angle with y-axis) = ${beta.toFixed(2)}°`)
      }
    } else {
      steps.push("  Direction is undefined for zero vector")
    }

    setResult({
      components: { x: Rx, y: Ry, z: Rz },
      magnitude,
      directionAngles: { alpha, beta, gamma },
      steps,
    })
  }

  const handleReset = () => {
    setVectors([
      { x: "", y: "", z: "" },
      { x: "", y: "", z: "" },
    ])
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = is3D
        ? `Resultant Vector: (${result.components.x}, ${result.components.y}, ${result.components.z}), Magnitude: ${result.magnitude.toFixed(4)}`
        : `Resultant Vector: (${result.components.x}, ${result.components.y}), Magnitude: ${result.magnitude.toFixed(4)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const text = is3D
        ? `Resultant Vector: (${result.components.x}, ${result.components.y}, ${result.components.z}), Magnitude: ${result.magnitude.toFixed(4)}`
        : `Resultant Vector: (${result.components.x}, ${result.components.y}), Magnitude: ${result.magnitude.toFixed(4)}`
      try {
        await navigator.share({
          title: "Vector Addition Result",
          text: `I calculated vector addition using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggle3D = () => {
    setIs3D((prev) => !prev)
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <ArrowRight className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Vector Addition Calculator</CardTitle>
                    <CardDescription>Calculate resultant vector from multiple vectors</CardDescription>
                  </div>
                </div>

                {/* Dimension Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Dimension</span>
                  <button
                    onClick={toggle3D}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        is3D ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !is3D ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      2D
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        is3D ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      3D
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Vector Inputs */}
                {vectors.map((vector, index) => (
                  <div key={index} className="space-y-2 p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <Label className="font-medium">Vector {index + 1}</Label>
                      {vectors.length > 2 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeVector(index)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    <div className={`grid gap-2 ${is3D ? "grid-cols-3" : "grid-cols-2"}`}>
                      <div>
                        <Label htmlFor={`v${index}-x`} className="text-xs text-muted-foreground">
                          x
                        </Label>
                        <Input
                          id={`v${index}-x`}
                          type="number"
                          placeholder="0"
                          value={vector.x}
                          onChange={(e) => updateVector(index, "x", e.target.value)}
                          step="any"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`v${index}-y`} className="text-xs text-muted-foreground">
                          y
                        </Label>
                        <Input
                          id={`v${index}-y`}
                          type="number"
                          placeholder="0"
                          value={vector.y}
                          onChange={(e) => updateVector(index, "y", e.target.value)}
                          step="any"
                        />
                      </div>
                      {is3D && (
                        <div>
                          <Label htmlFor={`v${index}-z`} className="text-xs text-muted-foreground">
                            z
                          </Label>
                          <Input
                            id={`v${index}-z`}
                            type="number"
                            placeholder="0"
                            value={vector.z}
                            onChange={(e) => updateVector(index, "z", e.target.value)}
                            step="any"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                ))}

                {/* Add Vector Button */}
                {vectors.length < 10 && (
                  <Button variant="outline" onClick={addVector} className="w-full bg-transparent">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Vector
                  </Button>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Resultant
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Resultant Vector</p>
                      <p className="text-2xl font-bold text-blue-600 mb-2 font-mono">
                        {is3D
                          ? `(${result.components.x.toFixed(4)}, ${result.components.y.toFixed(4)}, ${result.components.z.toFixed(4)})`
                          : `(${result.components.x.toFixed(4)}, ${result.components.y.toFixed(4)})`}
                      </p>
                      <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
                        <div className="p-2 bg-white rounded-lg">
                          <p className="text-muted-foreground">Magnitude</p>
                          <p className="font-semibold text-blue-700">{result.magnitude.toFixed(4)}</p>
                        </div>
                        <div className="p-2 bg-white rounded-lg">
                          <p className="text-muted-foreground">α (x-axis)</p>
                          <p className="font-semibold text-blue-700">{result.directionAngles.alpha.toFixed(2)}°</p>
                        </div>
                      </div>
                      {is3D && (
                        <div className="grid grid-cols-2 gap-4 mt-2 text-sm">
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">β (y-axis)</p>
                            <p className="font-semibold text-blue-700">{result.directionAngles.beta.toFixed(2)}°</p>
                          </div>
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">γ (z-axis)</p>
                            <p className="font-semibold text-blue-700">{result.directionAngles.gamma.toFixed(2)}°</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Step-by-step Solution */}
                    <Collapsible open={showSteps} onOpenChange={setShowSteps} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-between">
                          Step-by-step Solution
                          <span className="text-xs">{showSteps ? "Hide" : "Show"}</span>
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="p-3 bg-white rounded-lg text-sm font-mono whitespace-pre-wrap text-left">
                          {result.steps.join("\n")}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Vector Addition Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">R = V₁ + V₂ + ... + Vₙ</p>
                    <p className="text-sm text-muted-foreground">Rₓ = Σxᵢ, Rᵧ = Σyᵢ, Rᵤ = Σzᵢ</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">|R| = √(Rₓ² + Rᵧ² + Rᵤ²)</p>
                    <p className="text-sm text-muted-foreground">Magnitude formula</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(3, 4) + (1, 2)</span>
                      <span className="font-mono text-sm">(4, 6), |R| = 7.21</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(1, 0) + (0, 1)</span>
                      <span className="font-mono text-sm">(1, 1), |R| = 1.41</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="text-sm">(2, -3) + (-2, 3)</span>
                      <span className="font-mono text-sm">(0, 0), |R| = 0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Applications</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Physics:</strong> Adding forces, velocities, or displacements
                  </p>
                  <p>
                    <strong>Navigation:</strong> Calculating total displacement from multiple movements
                  </p>
                  <p>
                    <strong>Graphics:</strong> Combining transformations and movements in games/simulations
                  </p>
                  <p>
                    <strong>Engineering:</strong> Analyzing combined loads and stresses
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Vector Addition?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Vector addition is a fundamental operation in mathematics and physics that combines two or more
                  vectors to produce a resultant vector. Unlike scalar addition, vector addition takes into account both
                  the magnitude and direction of each vector. The resultant vector represents the combined effect of all
                  the individual vectors and is found by summing the corresponding components.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  There are two primary methods for vector addition: the head-to-tail method (graphical) and the
                  component method (analytical). The component method, which this calculator uses, breaks each vector
                  into its x, y, and z components, sums each component separately, and then combines them to find the
                  resultant vector. This approach is more precise and works well for any number of vectors.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Direction Angles</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Direction angles (α, β, γ) are the angles that a vector makes with the positive x, y, and z axes,
                  respectively. They are calculated using the inverse cosine (arccos) of the ratio of each component to
                  the magnitude. These angles are useful for describing the orientation of a vector in space and are
                  commonly used in physics and engineering applications.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg font-mono text-sm">
                  <p>α = cos⁻¹(Rₓ / |R|) — angle with x-axis</p>
                  <p>β = cos⁻¹(Rᵧ / |R|) — angle with y-axis</p>
                  <p>γ = cos⁻¹(Rᵤ / |R|) — angle with z-axis</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <Card className="mt-8 border-amber-200 bg-amber-50">
            <CardContent className="pt-6">
              <div className="flex gap-3">
                <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-800">
                  <p className="font-medium mb-1">Disclaimer</p>
                  <p>
                    Vector addition calculations follow standard Euclidean formulas. Results depend on correct component
                    input and selected dimension. This calculator is for educational purposes.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
