"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Activity, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type TestType = "cooper" | "rockport" | "step" | "direct"
type Gender = "male" | "female"

interface VO2MaxResult {
  value: number
  category: string
  color: string
  bgColor: string
  testUsed: string
}

interface FitnessCategory {
  label: string
  maleRange: string
  femaleRange: string
  color: string
  bgColor: string
}

const fitnessCategories: FitnessCategory[] = [
  {
    label: "Superior",
    maleRange: "≥ 55",
    femaleRange: "≥ 50",
    color: "text-emerald-700",
    bgColor: "bg-emerald-50 border-emerald-200",
  },
  {
    label: "Excellent",
    maleRange: "49-54",
    femaleRange: "44-49",
    color: "text-green-700",
    bgColor: "bg-green-50 border-green-200",
  },
  {
    label: "Good",
    maleRange: "43-48",
    femaleRange: "38-43",
    color: "text-blue-700",
    bgColor: "bg-blue-50 border-blue-200",
  },
  {
    label: "Fair",
    maleRange: "37-42",
    femaleRange: "32-37",
    color: "text-yellow-700",
    bgColor: "bg-yellow-50 border-yellow-200",
  },
  {
    label: "Poor",
    maleRange: "31-36",
    femaleRange: "26-31",
    color: "text-orange-700",
    bgColor: "bg-orange-50 border-orange-200",
  },
  {
    label: "Very Poor",
    maleRange: "< 31",
    femaleRange: "< 26",
    color: "text-red-700",
    bgColor: "bg-red-50 border-red-200",
  },
]

export function VO2MaxCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [testType, setTestType] = useState<TestType>("cooper")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [distance, setDistance] = useState("")
  const [time, setTime] = useState("")
  const [heartRate, setHeartRate] = useState("")
  const [directVO2, setDirectVO2] = useState("")
  const [result, setResult] = useState<VO2MaxResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const getCategory = (vo2max: number, gender: Gender): { category: string; color: string; bgColor: string } => {
    const thresholds = gender === "male" ? [55, 49, 43, 37, 31] : [50, 44, 38, 32, 26]

    if (vo2max >= thresholds[0])
      return { category: "Superior", color: "text-emerald-600", bgColor: "bg-emerald-50 border-emerald-200" }
    if (vo2max >= thresholds[1])
      return { category: "Excellent", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    if (vo2max >= thresholds[2])
      return { category: "Good", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    if (vo2max >= thresholds[3])
      return { category: "Fair", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    if (vo2max >= thresholds[4])
      return { category: "Poor", color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    return { category: "Very Poor", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
  }

  const calculateVO2Max = () => {
    setError("")
    setResult(null)

    let vo2max: number
    let testUsed: string

    if (testType === "cooper") {
      const distanceNum = Number.parseFloat(distance)
      if (isNaN(distanceNum) || distanceNum <= 0) {
        setError("Please enter a valid distance greater than 0")
        return
      }

      // Convert to meters if imperial
      const distanceInMeters = unitSystem === "imperial" ? distanceNum * 1609.34 : distanceNum

      // Cooper 12-minute run formula: VO2 Max = (Distance in meters − 504.9) / 44.73
      vo2max = (distanceInMeters - 504.9) / 44.73
      testUsed = "Cooper 12-minute Run Test"
    } else if (testType === "rockport") {
      const ageNum = Number.parseFloat(age)
      const weightNum = Number.parseFloat(weight)
      const timeNum = Number.parseFloat(time)
      const hrNum = Number.parseFloat(heartRate)

      if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
        setError("Please enter a valid age between 1 and 120")
        return
      }
      if (isNaN(weightNum) || weightNum <= 0) {
        setError("Please enter a valid weight greater than 0")
        return
      }
      if (isNaN(timeNum) || timeNum <= 0) {
        setError("Please enter a valid time greater than 0")
        return
      }
      if (isNaN(hrNum) || hrNum < 40 || hrNum > 220) {
        setError("Please enter a valid heart rate between 40 and 220 bpm")
        return
      }

      // Convert weight to pounds if metric
      const weightInLbs = unitSystem === "metric" ? weightNum * 2.20462 : weightNum
      const genderFactor = gender === "male" ? 1 : 0

      // Rockport Walk Test formula
      vo2max =
        132.853 - 0.0769 * weightInLbs - 0.3877 * ageNum + 6.315 * genderFactor - 3.2649 * timeNum - 0.1565 * hrNum
      testUsed = "Rockport 1-Mile Walk Test"
    } else if (testType === "step") {
      const hrNum = Number.parseFloat(heartRate)
      const ageNum = Number.parseFloat(age)

      if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
        setError("Please enter a valid age between 1 and 120")
        return
      }
      if (isNaN(hrNum) || hrNum < 40 || hrNum > 220) {
        setError("Please enter a valid recovery heart rate between 40 and 220 bpm")
        return
      }

      // McArdle Step Test formula (simplified)
      // For males: VO2max = 111.33 - (0.42 × HR)
      // For females: VO2max = 65.81 - (0.1847 × HR)
      if (gender === "male") {
        vo2max = 111.33 - 0.42 * hrNum
      } else {
        vo2max = 65.81 - 0.1847 * hrNum
      }
      testUsed = "McArdle Step Test"
    } else {
      // Direct input
      const directNum = Number.parseFloat(directVO2)
      if (isNaN(directNum) || directNum <= 0 || directNum > 100) {
        setError("Please enter a valid VO2 Max between 1 and 100 ml/kg/min")
        return
      }
      vo2max = directNum
      testUsed = "Direct Input"
    }

    const roundedVO2Max = Math.round(vo2max * 10) / 10
    const { category, color, bgColor } = getCategory(roundedVO2Max, gender)

    setResult({
      value: roundedVO2Max,
      category,
      color,
      bgColor,
      testUsed,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setDistance("")
    setTime("")
    setHeartRate("")
    setDirectVO2("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My VO2 Max is ${result.value} ml/kg/min (${result.category}) - ${result.testUsed}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My VO2 Max Result",
          text: `I estimated my VO2 Max using CalcHub! My VO2 Max is ${result.value} ml/kg/min (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setDistance("")
    setWeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">VO2 Max Calculator</CardTitle>
                    <CardDescription>Estimate your maximal oxygen uptake</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Test Type Selection */}
                <div className="space-y-2">
                  <Label>Test Type</Label>
                  <Select value={testType} onValueChange={(value: TestType) => setTestType(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select test type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cooper">Cooper 12-minute Run Test</SelectItem>
                      <SelectItem value="rockport">Rockport 1-Mile Walk Test</SelectItem>
                      <SelectItem value="step">McArdle Step Test</SelectItem>
                      <SelectItem value="direct">Direct VO2 Max Input</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Gender Selection (for all tests except direct) */}
                {testType !== "direct" && (
                  <div className="space-y-2">
                    <Label>Gender</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Button
                        type="button"
                        variant={gender === "male" ? "default" : "outline"}
                        onClick={() => setGender("male")}
                        className="w-full"
                      >
                        Male
                      </Button>
                      <Button
                        type="button"
                        variant={gender === "female" ? "default" : "outline"}
                        onClick={() => setGender("female")}
                        className="w-full"
                      >
                        Female
                      </Button>
                    </div>
                  </div>
                )}

                {/* Cooper Test Inputs */}
                {testType === "cooper" && (
                  <div className="space-y-2">
                    <Label htmlFor="distance">
                      Distance covered in 12 minutes ({unitSystem === "metric" ? "meters" : "miles"})
                    </Label>
                    <Input
                      id="distance"
                      type="number"
                      placeholder={unitSystem === "metric" ? "e.g., 2400" : "e.g., 1.5"}
                      value={distance}
                      onChange={(e) => setDistance(e.target.value)}
                      min="0"
                      step={unitSystem === "metric" ? "1" : "0.01"}
                    />
                  </div>
                )}

                {/* Rockport Test Inputs */}
                {testType === "rockport" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="age">Age (years)</Label>
                      <Input
                        id="age"
                        type="number"
                        placeholder="Enter your age"
                        value={age}
                        onChange={(e) => setAge(e.target.value)}
                        min="1"
                        max="120"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                      <Input
                        id="weight"
                        type="number"
                        placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                        value={weight}
                        onChange={(e) => setWeight(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="time">Time to complete 1 mile (minutes)</Label>
                      <Input
                        id="time"
                        type="number"
                        placeholder="e.g., 15.5"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="heartRate">Heart rate at end of walk (bpm)</Label>
                      <Input
                        id="heartRate"
                        type="number"
                        placeholder="e.g., 140"
                        value={heartRate}
                        onChange={(e) => setHeartRate(e.target.value)}
                        min="40"
                        max="220"
                      />
                    </div>
                  </>
                )}

                {/* Step Test Inputs */}
                {testType === "step" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="age">Age (years)</Label>
                      <Input
                        id="age"
                        type="number"
                        placeholder="Enter your age"
                        value={age}
                        onChange={(e) => setAge(e.target.value)}
                        min="1"
                        max="120"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="heartRate">Recovery heart rate after 1 minute (bpm)</Label>
                      <Input
                        id="heartRate"
                        type="number"
                        placeholder="e.g., 100"
                        value={heartRate}
                        onChange={(e) => setHeartRate(e.target.value)}
                        min="40"
                        max="220"
                      />
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-sm">
                      <strong>Step Test Instructions:</strong> Step up and down on a 16.25-inch step for 3 minutes at a
                      rate of 24 steps/min for males or 22 steps/min for females. Rest for 1 minute, then measure your
                      heart rate.
                    </div>
                  </>
                )}

                {/* Direct Input */}
                {testType === "direct" && (
                  <>
                    <div className="space-y-2">
                      <Label>Gender (for fitness category)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Button
                          type="button"
                          variant={gender === "male" ? "default" : "outline"}
                          onClick={() => setGender("male")}
                          className="w-full"
                        >
                          Male
                        </Button>
                        <Button
                          type="button"
                          variant={gender === "female" ? "default" : "outline"}
                          onClick={() => setGender("female")}
                          className="w-full"
                        >
                          Female
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="directVO2">VO2 Max (ml/kg/min)</Label>
                      <Input
                        id="directVO2"
                        type="number"
                        placeholder="e.g., 45"
                        value={directVO2}
                        onChange={(e) => setDirectVO2(e.target.value)}
                        min="0"
                        max="100"
                        step="0.1"
                      />
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateVO2Max} className="w-full" size="lg">
                  Calculate VO2 Max
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your VO2 Max</p>
                      <p className={`text-5xl font-bold ${result.color} mb-1`}>{result.value}</p>
                      <p className="text-sm text-muted-foreground mb-2">ml/kg/min</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-xs text-muted-foreground mt-1">{result.testUsed}</p>
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-1 mt-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          Hide Details <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Details <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-current/10 text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Test Method:</span>
                          <span className="font-medium">{result.testUsed}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fitness Level:</span>
                          <span className={`font-medium ${result.color}`}>{result.category}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Gender:</span>
                          <span className="font-medium capitalize">{gender}</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">VO2 Max Fitness Categories</CardTitle>
                  <CardDescription>
                    Based on age-adjusted norms ({gender === "male" ? "Male" : "Female"})
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {fitnessCategories.map((cat) => (
                      <div
                        key={cat.label}
                        className={`flex items-center justify-between p-3 rounded-lg ${cat.bgColor} border`}
                      >
                        <span className={`font-medium ${cat.color}`}>{cat.label}</span>
                        <span className={`text-sm ${cat.color}`}>
                          {gender === "male" ? cat.maleRange : cat.femaleRange} ml/kg/min
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Test Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Cooper Test:</p>
                    <p className="font-mono text-xs">VO2 = (Distance − 504.9) / 44.73</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Rockport Test:</p>
                    <p className="font-mono text-xs">
                      VO2 = 132.853 − (0.0769 × Wt) − (0.3877 × Age) + (6.315 × G) − (3.2649 × Time) − (0.1565 × HR)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is VO2 Max?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  VO2 Max, or maximal oxygen uptake, is the maximum rate at which your body can consume oxygen during
                  intense exercise. It is considered one of the best indicators of cardiovascular fitness and aerobic
                  endurance. The measurement is expressed in milliliters of oxygen consumed per kilogram of body weight
                  per minute (ml/kg/min).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A higher VO2 Max indicates better aerobic fitness, meaning your body is more efficient at delivering
                  oxygen to your muscles during exercise. Elite endurance athletes often have VO2 Max values above 70
                  ml/kg/min, while average untrained individuals typically range from 30-40 ml/kg/min.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Tests</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Cooper 12-Minute Run Test</h4>
                    <p className="text-blue-700 text-sm">
                      Run as far as possible in 12 minutes on a flat surface. This test is best for individuals with
                      running experience and measures how far you can cover in the time limit. It&apos;s widely used in
                      fitness assessments and military testing.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Rockport 1-Mile Walk Test</h4>
                    <p className="text-green-700 text-sm">
                      Walk one mile as fast as possible while maintaining a consistent pace. Record your time and heart
                      rate immediately after finishing. This test is ideal for beginners, older adults, or those who
                      cannot run due to physical limitations.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">McArdle Step Test</h4>
                    <p className="text-yellow-700 text-sm">
                      Step up and down on a standardized step (16.25 inches) for 3 minutes at a specific cadence (24
                      steps/min for males, 22 for females). Rest for 1 minute, then measure your recovery heart rate.
                      This test requires minimal equipment and space.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Training Recommendations</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To improve your VO2 Max, focus on aerobic exercises that elevate your heart rate for extended periods.
                  High-intensity interval training (HIIT), tempo runs, and long slow distance training are all effective
                  methods. Consistency is key - aim for 3-5 cardio sessions per week, gradually increasing intensity and
                  duration over time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Most people can improve their VO2 Max by 15-20% with proper training, though genetic factors play a
                  significant role in your maximum potential. Tracking your progress over time can help motivate
                  continued improvement.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> VO2 Max estimates are based on standard formulas and field tests; actual
                  values may vary based on testing conditions, individual fitness level, and other factors. For the most
                  accurate measurement, consider a laboratory-based cardiopulmonary exercise test (CPET). Consult a
                  healthcare professional before starting any new exercise program.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
