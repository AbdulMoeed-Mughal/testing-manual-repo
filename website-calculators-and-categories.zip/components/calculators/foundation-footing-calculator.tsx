"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Home, Info, Calculator, Hammer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type FootingType = "isolated" | "strip" | "combined"
type Unit = "m" | "ft"

interface FootingResult {
  footingType: FootingType
  wetVolume: number
  dryVolume: number
  cementBags: number
  sandVolume: number
  aggregateVolume: number
  unit: Unit
}

export function FoundationFootingCalculator() {
  const [footingType, setFootingType] = useState<FootingType>("isolated")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [thickness, setThickness] = useState("")
  const [numberOfFootings, setNumberOfFootings] = useState("1")
  const [unit, setUnit] = useState<Unit>("m")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [wastagePercentage, setWastagePercentage] = useState("5")
  const [result, setResult] = useState<FootingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateFooting = () => {
    setError("")
    setResult(null)

    const l = Number.parseFloat(length)
    const w = Number.parseFloat(width)
    const t = Number.parseFloat(thickness)
    const n = Number.parseFloat(numberOfFootings)
    const dryFactor = Number.parseFloat(dryVolumeFactor)
    const wastage = Number.parseFloat(wastagePercentage)

    if (isNaN(l) || l <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }

    if (isNaN(w) || w <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }

    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid thickness greater than 0")
      return
    }

    if (isNaN(n) || n < 1) {
      setError("Number of footings must be at least 1")
      return
    }

    if (isNaN(dryFactor) || dryFactor <= 1) {
      setError("Dry volume factor must be greater than 1")
      return
    }

    if (isNaN(wastage) || wastage < 0) {
      setError("Wastage percentage must be non-negative")
      return
    }

    // Calculate wet volume
    let wetVolume = l * w * t * n

    // Apply wastage
    wetVolume = wetVolume * (1 + wastage / 100)

    // Calculate dry volume
    const dryVolume = wetVolume * dryFactor

    // Standard mix ratio 1:2:4 (cement:sand:aggregate)
    // Total parts = 1 + 2 + 4 = 7
    const cementVolume = dryVolume / 7
    const sandVolume = (dryVolume * 2) / 7
    const aggregateVolume = (dryVolume * 4) / 7

    // Cement: 1 bag = 0.035 m³ or 1.25 ft³
    const cementBagVolume = unit === "m" ? 0.035 : 1.25
    const cementBags = Math.ceil(cementVolume / cementBagVolume)

    setResult({
      footingType,
      wetVolume: Math.round(wetVolume * 1000) / 1000,
      dryVolume: Math.round(dryVolume * 1000) / 1000,
      cementBags,
      sandVolume: Math.round(sandVolume * 1000) / 1000,
      aggregateVolume: Math.round(aggregateVolume * 1000) / 1000,
      unit,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setThickness("")
    setNumberOfFootings("1")
    setDryVolumeFactor("1.54")
    setWastagePercentage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Foundation Footing: ${result.footingType}\nConcrete Volume: ${result.wetVolume} ${
        result.unit
      }³\nCement: ${result.cementBags} bags\nSand: ${result.sandVolume} ${result.unit}³\nAggregate: ${
        result.aggregateVolume
      } ${result.unit}³`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Foundation Footing Calculation",
          text: `Foundation Footing: ${result.footingType}\nConcrete Volume: ${result.wetVolume} ${
            result.unit
          }³\nCement: ${result.cementBags} bags`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getFootingLabel = () => {
    switch (footingType) {
      case "isolated":
        return "Isolated Footing"
      case "strip":
        return "Strip Footing"
      case "combined":
        return "Combined Footing"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Foundation Footing Calculator</CardTitle>
                    <CardDescription>Calculate concrete and materials for footings</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Footing Type Selection */}
                <div className="space-y-2">
                  <Label>Footing Type</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant={footingType === "isolated" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFootingType("isolated")}
                      className="text-xs"
                    >
                      Isolated
                    </Button>
                    <Button
                      variant={footingType === "strip" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFootingType("strip")}
                      className="text-xs"
                    >
                      Strip
                    </Button>
                    <Button
                      variant={footingType === "combined" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFootingType("combined")}
                      className="text-xs"
                    >
                      Combined
                    </Button>
                  </div>
                </div>

                {/* Unit Selection */}
                <div className="space-y-2">
                  <Label>Unit</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={unit === "m" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setUnit("m")}
                      className="flex-1"
                    >
                      Meters (m)
                    </Button>
                    <Button
                      variant={unit === "ft" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setUnit("ft")}
                      className="flex-1"
                    >
                      Feet (ft)
                    </Button>
                  </div>
                </div>

                {/* Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">Length ({unit})</Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder="Length"
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="width">Width ({unit})</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder="Width"
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="thickness">Thickness / Depth ({unit})</Label>
                  <Input
                    id="thickness"
                    type="number"
                    placeholder="Thickness"
                    value={thickness}
                    onChange={(e) => setThickness(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="number">Number of Footings</Label>
                  <Input
                    id="number"
                    type="number"
                    placeholder="Number"
                    value={numberOfFootings}
                    onChange={(e) => setNumberOfFootings(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Advanced Options */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="dryFactor">Dry Volume Factor</Label>
                    <Input
                      id="dryFactor"
                      type="number"
                      placeholder="1.54"
                      value={dryVolumeFactor}
                      onChange={(e) => setDryVolumeFactor(e.target.value)}
                      min="1"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wastage">Wastage (%)</Label>
                    <Input
                      id="wastage"
                      type="number"
                      placeholder="5"
                      value={wastagePercentage}
                      onChange={(e) => setWastagePercentage(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFooting} className="w-full" size="lg">
                  Calculate Materials
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-2 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">{getFootingLabel()}</p>
                        <p className="text-3xl font-bold text-amber-600">
                          {result.wetVolume} {result.unit}³
                        </p>
                        <p className="text-sm text-amber-700">Concrete Volume</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between p-2 rounded bg-white">
                          <span className="text-muted-foreground">Cement:</span>
                          <span className="font-semibold text-amber-700">{result.cementBags} bags</span>
                        </div>
                        <div className="flex justify-between p-2 rounded bg-white">
                          <span className="text-muted-foreground">Sand:</span>
                          <span className="font-semibold text-amber-700">
                            {result.sandVolume} {result.unit}³
                          </span>
                        </div>
                        <div className="flex justify-between p-2 rounded bg-white">
                          <span className="text-muted-foreground">Aggregate:</span>
                          <span className="font-semibold text-amber-700">
                            {result.aggregateVolume} {result.unit}³
                          </span>
                        </div>
                        <div className="flex justify-between p-2 rounded bg-white">
                          <span className="text-muted-foreground">Dry Volume:</span>
                          <span className="font-semibold text-amber-700">
                            {result.dryVolume} {result.unit}³
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Footing Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Isolated Footing</h4>
                      <p className="text-xs text-amber-700">Individual footing under each column</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Strip Footing</h4>
                      <p className="text-xs text-amber-700">Continuous footing along walls or columns</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Combined Footing</h4>
                      <p className="text-xs text-amber-700">Shared footing for two or more columns</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mix Ratio Used</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Standard Mix 1:2:4</p>
                    <div className="space-y-1 text-xs">
                      <p>1 part Cement</p>
                      <p>2 parts Sand</p>
                      <p>4 parts Aggregate</p>
                    </div>
                  </div>
                  <p className="text-xs">This calculator uses M15 grade concrete mix ratio by default.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Foundation Footing */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-amber-600" />
                  <CardTitle>What is a Foundation Footing?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A foundation footing is a structural element that transfers loads from columns or walls to the
                  underlying soil. It is typically made of reinforced concrete and is designed to distribute building
                  loads over a larger area, preventing excessive settlement and ensuring structural stability. Footings
                  are essential components of any building foundation system.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  There are several types of footings used in construction, each suited to different structural
                  requirements and soil conditions. Isolated footings support individual columns, strip footings run
                  continuously under walls, and combined footings support multiple columns where space is limited. The
                  choice of footing type depends on factors such as building load, soil bearing capacity, column spacing,
                  and site constraints.
                </p>
              </CardContent>
            </Card>

            {/* Material Calculations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-amber-600" />
                  <CardTitle>How Material Calculations Work</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator first determines the wet concrete volume by multiplying the footing's length, width, and
                  thickness, then multiplying by the number of footings. A wastage percentage (typically 5%) is added to
                  account for material losses during construction. The wet volume is then converted to dry volume using
                  the standard factor of 1.54 to determine the quantity of dry materials needed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The dry volume is divided according to the mix ratio to calculate individual material quantities. For a
                  1:2:4 mix, cement constitutes 1/7 of the total volume, sand 2/7, and aggregate 4/7. Cement is expressed
                  in bags (50kg each, approximately 0.035 m³ or 1.25 ft³ per bag), while sand and aggregate are given in
                  cubic units. These calculations help contractors order the right amount of materials and prepare accurate
                  cost estimates.
                </p>
              </CardContent>
            </Card>

            {/* Construction Tips */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Hammer className="h-5 w-5 text-amber-600" />
                  <CardTitle>Foundation Construction Tips</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Proper footing construction is critical for building stability and longevity. Always excavate to firm,
                  undisturbed soil and ensure the footing base is level. The depth of footings should be below the frost
                  line in cold climates to prevent frost heave. Reinforce footings with steel bars as specified in
                  structural drawings to handle both compression and tension forces.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Use proper concrete mix proportions and ensure adequate curing for at least 7 days by keeping the
                  concrete moist. Verify that formwork is secure and aligned before pouring. Consider soil testing to
                  determine bearing capacity and adjust footing dimensions accordingly. For projects with significant
                  loads or challenging soil conditions, always consult with a structural engineer to ensure safe and
                  code-compliant foundation design.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Concrete quantities are approximate. Actual site requirements may vary due
                  to soil conditions, formwork, and workmanship. This calculator provides estimates for planning purposes
                  only. For structural projects, always consult with a licensed structural engineer and follow local
                  building codes and regulations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
