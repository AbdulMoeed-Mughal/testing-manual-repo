"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type InequalityType = "single" | "compound" | "absolute"

interface SolutionResult {
  original: string
  solution: string
  intervalNotation: string
  setBuilder: string
  steps: string[]
  numberLine: {
    min: number
    max: number
    points: { value: number; type: "open" | "closed" }[]
    regions: { start: number; end: number }[]
  }
  hasNoSolution: boolean
  isAllReals: boolean
}

export function InequalitySolver() {
  const [inequalityType, setInequalityType] = useState<InequalityType>("single")
  const [inequality, setInequality] = useState("")
  const [variable, setVariable] = useState("x")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<SolutionResult | null>(null)
  const [copied, setCopied] = useState<string | null>(null)
  const [error, setError] = useState("")
  const [stepsExpanded, setStepsExpanded] = useState(true)

  const parseAndSolve = () => {
    setError("")
    setResult(null)

    if (!inequality.trim()) {
      setError("Please enter an inequality")
      return
    }

    try {
      const solution = solveInequality(inequality.trim(), inequalityType, variable)
      setResult(solution)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid inequality format")
    }
  }

  const solveInequality = (expr: string, type: InequalityType, varName: string): SolutionResult => {
    const steps: string[] = []
    let solution = ""
    let intervalNotation = ""
    let setBuilder = ""
    let hasNoSolution = false
    let isAllReals = false
    const numberLine = {
      min: -10,
      max: 10,
      points: [] as { value: number; type: "open" | "closed" }[],
      regions: [] as { start: number; end: number }[],
    }

    steps.push(`Original inequality: ${expr}`)

    if (type === "absolute") {
      // Handle absolute value inequalities like |x - 3| < 5
      const absMatch = expr.match(/\|([^|]+)\|\s*([<>]=?)\s*([\d.]+)/)
      if (!absMatch) {
        throw new Error("Invalid absolute value inequality format. Use format like |x - 3| < 5")
      }

      const innerExpr = absMatch[1].trim()
      const operator = absMatch[2]
      const bound = Number.parseFloat(absMatch[3])

      steps.push(`Identified: |${innerExpr}| ${operator} ${bound}`)

      // Parse inner expression (ax + b form)
      const coeffMatch = innerExpr.match(/([+-]?\d*\.?\d*)\s*\*?\s*([a-z])\s*([+-]\s*\d+\.?\d*)?/i)
      let a = 1,
        b = 0
      if (coeffMatch) {
        a =
          coeffMatch[1] === "" || coeffMatch[1] === "+"
            ? 1
            : coeffMatch[1] === "-"
              ? -1
              : Number.parseFloat(coeffMatch[1])
        b = coeffMatch[3] ? Number.parseFloat(coeffMatch[3].replace(/\s/g, "")) : 0
      }

      if (operator === "<" || operator === "<=") {
        // |ax + b| < c  means  -c < ax + b < c
        const isStrict = operator === "<"
        steps.push(
          `Split into compound inequality: -${bound} ${isStrict ? "<" : "≤"} ${innerExpr} ${isStrict ? "<" : "≤"} ${bound}`,
        )

        const lower = (-bound - b) / a
        const upper = (bound - b) / a

        steps.push(
          `Solve left side: ${varName} ${a > 0 ? (isStrict ? ">" : "≥") : isStrict ? "<" : "≤"} ${lower.toFixed(2)}`,
        )
        steps.push(
          `Solve right side: ${varName} ${a > 0 ? (isStrict ? "<" : "≤") : isStrict ? ">" : "≥"} ${upper.toFixed(2)}`,
        )

        const min = Math.min(lower, upper)
        const max = Math.max(lower, upper)

        solution = `${min.toFixed(2)} ${isStrict ? "<" : "≤"} ${varName} ${isStrict ? "<" : "≤"} ${max.toFixed(2)}`
        intervalNotation = `${isStrict ? "(" : "["}${min.toFixed(2)}, ${max.toFixed(2)}${isStrict ? ")" : "]"}`
        setBuilder = `{${varName} ∈ ℝ | ${solution}}`

        numberLine.points.push({ value: min, type: isStrict ? "open" : "closed" })
        numberLine.points.push({ value: max, type: isStrict ? "open" : "closed" })
        numberLine.regions.push({ start: min, end: max })
        numberLine.min = min - 3
        numberLine.max = max + 3
      } else {
        // |ax + b| > c  means  ax + b < -c  OR  ax + b > c
        const isStrict = operator === ">"
        steps.push(
          `Split into two cases: ${innerExpr} ${isStrict ? "<" : "≤"} -${bound}  OR  ${innerExpr} ${isStrict ? ">" : "≥"} ${bound}`,
        )

        const lower = (-bound - b) / a
        const upper = (bound - b) / a

        const min = Math.min(lower, upper)
        const max = Math.max(lower, upper)

        steps.push(`Case 1: ${varName} ${isStrict ? "<" : "≤"} ${min.toFixed(2)}`)
        steps.push(`Case 2: ${varName} ${isStrict ? ">" : "≥"} ${max.toFixed(2)}`)

        solution = `${varName} ${isStrict ? "<" : "≤"} ${min.toFixed(2)}  OR  ${varName} ${isStrict ? ">" : "≥"} ${max.toFixed(2)}`
        intervalNotation = `(-∞, ${min.toFixed(2)}${isStrict ? ")" : "]"} ∪ ${isStrict ? "(" : "["}${max.toFixed(2)}, +∞)`
        setBuilder = `{${varName} ∈ ℝ | ${varName} ${isStrict ? "<" : "≤"} ${min.toFixed(2)} ∨ ${varName} ${isStrict ? ">" : "≥"} ${max.toFixed(2)}}`

        numberLine.points.push({ value: min, type: isStrict ? "open" : "closed" })
        numberLine.points.push({ value: max, type: isStrict ? "open" : "closed" })
        numberLine.regions.push({ start: -100, end: min })
        numberLine.regions.push({ start: max, end: 100 })
        numberLine.min = min - 3
        numberLine.max = max + 3
      }
    } else if (type === "compound") {
      // Handle compound inequalities like 1 < 2x + 3 <= 7
      const compoundMatch = expr.match(/([\d.-]+)\s*([<>]=?)\s*([^<>=]+)\s*([<>]=?)\s*([\d.-]+)/)
      if (!compoundMatch) {
        throw new Error("Invalid compound inequality format. Use format like 1 < 2x + 3 <= 7")
      }

      const leftBound = Number.parseFloat(compoundMatch[1])
      const leftOp = compoundMatch[2]
      const middle = compoundMatch[3].trim()
      const rightOp = compoundMatch[4]
      const rightBound = Number.parseFloat(compoundMatch[5])

      steps.push(`Identified bounds: ${leftBound} ${leftOp} ${middle} ${rightOp} ${rightBound}`)

      // Parse middle expression
      const coeffMatch = middle.match(/([+-]?\d*\.?\d*)\s*\*?\s*([a-z])\s*([+-]\s*\d+\.?\d*)?/i)
      let a = 1,
        b = 0
      if (coeffMatch) {
        a =
          coeffMatch[1] === "" || coeffMatch[1] === "+"
            ? 1
            : coeffMatch[1] === "-"
              ? -1
              : Number.parseFloat(coeffMatch[1])
        b = coeffMatch[3] ? Number.parseFloat(coeffMatch[3].replace(/\s/g, "")) : 0
      }

      // Solve for variable
      const leftVal = (leftBound - b) / a
      const rightVal = (rightBound - b) / a

      steps.push(`Subtract ${b} from all parts: ${leftBound - b} ${leftOp} ${a}${varName} ${rightOp} ${rightBound - b}`)
      steps.push(
        `Divide all parts by ${a}: ${leftVal.toFixed(2)} ${a < 0 ? flipOperator(leftOp) : leftOp} ${varName} ${a < 0 ? flipOperator(rightOp) : rightOp} ${rightVal.toFixed(2)}`,
      )

      if (a < 0) {
        steps.push(`Note: Dividing by negative flips inequality signs`)
      }

      const min = Math.min(leftVal, rightVal)
      const max = Math.max(leftVal, rightVal)
      const minOp = a < 0 ? flipOperator(rightOp) : leftOp
      const maxOp = a < 0 ? flipOperator(leftOp) : rightOp

      solution = `${min.toFixed(2)} ${minOp} ${varName} ${maxOp} ${max.toFixed(2)}`
      intervalNotation = `${minOp.includes("=") ? "[" : "("}${min.toFixed(2)}, ${max.toFixed(2)}${maxOp.includes("=") ? "]" : ")"}`
      setBuilder = `{${varName} ∈ ℝ | ${solution}}`

      numberLine.points.push({ value: min, type: minOp.includes("=") ? "closed" : "open" })
      numberLine.points.push({ value: max, type: maxOp.includes("=") ? "closed" : "open" })
      numberLine.regions.push({ start: min, end: max })
      numberLine.min = min - 3
      numberLine.max = max + 3
    } else {
      // Handle single linear inequalities like 2x - 5 > 3x + 1
      const match = expr.match(/(.+?)([<>]=?)(.+)/)
      if (!match) {
        throw new Error("Invalid inequality format. Use format like 2x - 5 > 3")
      }

      const leftSide = match[1].trim()
      const operator = match[2]
      const rightSide = match[3].trim()

      steps.push(`Left side: ${leftSide}`)
      steps.push(`Operator: ${operator}`)
      steps.push(`Right side: ${rightSide}`)

      // Parse coefficients
      const parseCoeff = (side: string): { coeff: number; constant: number } => {
        let coeff = 0
        let constant = 0

        // Match variable terms
        const varMatches = side.matchAll(/([+-]?\s*\d*\.?\d*)\s*\*?\s*([a-z])/gi)
        for (const m of varMatches) {
          const c = m[1].replace(/\s/g, "")
          coeff += c === "" || c === "+" ? 1 : c === "-" ? -1 : Number.parseFloat(c)
        }

        // Match constant terms
        const constMatches = side.matchAll(/([+-]?\s*\d+\.?\d*)(?![a-z])/gi)
        for (const m of constMatches) {
          const val = m[1].replace(/\s/g, "")
          if (!isNaN(Number.parseFloat(val))) {
            constant += Number.parseFloat(val)
          }
        }

        return { coeff, constant }
      }

      const left = parseCoeff(leftSide)
      const right = parseCoeff(rightSide)

      steps.push(`Left: ${left.coeff}${varName} + ${left.constant}`)
      steps.push(`Right: ${right.coeff}${varName} + ${right.constant}`)

      // Move variables to left, constants to right
      const netCoeff = left.coeff - right.coeff
      const netConst = right.constant - left.constant

      steps.push(`Combine like terms: ${netCoeff}${varName} ${operator} ${netConst}`)

      if (netCoeff === 0) {
        // Check if always true or always false
        const leftVal = left.constant
        const rightVal = right.constant
        const isTrue =
          operator === "<"
            ? leftVal < rightVal
            : operator === "<="
              ? leftVal <= rightVal
              : operator === ">"
                ? leftVal > rightVal
                : leftVal >= rightVal

        if (isTrue) {
          solution = `All real numbers (${leftVal} ${operator} ${rightVal} is always true)`
          intervalNotation = "(-∞, +∞)"
          setBuilder = `{${varName} ∈ ℝ}`
          isAllReals = true
          numberLine.regions.push({ start: -100, end: 100 })
        } else {
          solution = `No solution (${leftVal} ${operator} ${rightVal} is always false)`
          intervalNotation = "∅"
          setBuilder = "{ }"
          hasNoSolution = true
        }
        steps.push(`Result: ${solution}`)
      } else {
        const value = netConst / netCoeff
        let finalOp = operator

        if (netCoeff < 0) {
          finalOp = flipOperator(operator)
          steps.push(`Divide by ${netCoeff} (negative, flip sign): ${varName} ${finalOp} ${value.toFixed(2)}`)
        } else {
          steps.push(`Divide by ${netCoeff}: ${varName} ${finalOp} ${value.toFixed(2)}`)
        }

        solution = `${varName} ${finalOp} ${value.toFixed(2)}`

        if (finalOp === "<") {
          intervalNotation = `(-∞, ${value.toFixed(2)})`
          numberLine.points.push({ value, type: "open" })
          numberLine.regions.push({ start: -100, end: value })
        } else if (finalOp === "<=") {
          intervalNotation = `(-∞, ${value.toFixed(2)}]`
          numberLine.points.push({ value, type: "closed" })
          numberLine.regions.push({ start: -100, end: value })
        } else if (finalOp === ">") {
          intervalNotation = `(${value.toFixed(2)}, +∞)`
          numberLine.points.push({ value, type: "open" })
          numberLine.regions.push({ start: value, end: 100 })
        } else {
          intervalNotation = `[${value.toFixed(2)}, +∞)`
          numberLine.points.push({ value, type: "closed" })
          numberLine.regions.push({ start: value, end: 100 })
        }

        setBuilder = `{${varName} ∈ ℝ | ${solution}}`
        numberLine.min = value - 5
        numberLine.max = value + 5
      }
    }

    steps.push(`Solution: ${solution}`)
    steps.push(`Interval notation: ${intervalNotation}`)

    return {
      original: expr,
      solution,
      intervalNotation,
      setBuilder,
      steps,
      numberLine,
      hasNoSolution,
      isAllReals,
    }
  }

  const flipOperator = (op: string): string => {
    switch (op) {
      case "<":
        return ">"
      case ">":
        return "<"
      case "<=":
        return ">="
      case ">=":
        return "<="
      default:
        return op
    }
  }

  const handleReset = () => {
    setInequality("")
    setResult(null)
    setError("")
    setCopied(null)
  }

  const handleCopy = async (text: string, type: string) => {
    await navigator.clipboard.writeText(text)
    setCopied(type)
    setTimeout(() => setCopied(null), 2000)
  }

  const renderNumberLine = () => {
    if (!result || result.hasNoSolution) return null

    const { min, max, points, regions } = result.numberLine
    const range = max - min
    const padding = 40

    const toX = (val: number) => {
      return padding + ((val - min) / range) * (300 - 2 * padding)
    }

    return (
      <div className="mt-4 p-4 bg-muted/50 rounded-lg">
        <p className="text-sm font-medium mb-3">Number Line Visualization</p>
        <svg width="100%" height="80" viewBox="0 0 300 80" className="overflow-visible">
          {/* Main line */}
          <line x1={padding} y1="40" x2={300 - padding} y2="40" stroke="currentColor" strokeWidth="2" />

          {/* Arrows */}
          <polygon points={`${padding - 5},40 ${padding + 5},35 ${padding + 5},45`} fill="currentColor" />
          <polygon
            points={`${300 - padding + 5},40 ${300 - padding - 5},35 ${300 - padding - 5},45`}
            fill="currentColor"
          />

          {/* Shaded regions */}
          {regions.map((region, i) => {
            const startX = Math.max(padding, toX(region.start))
            const endX = Math.min(300 - padding, toX(region.end))
            return (
              <rect key={i} x={startX} y="32" width={endX - startX} height="16" fill="rgb(34, 197, 94)" opacity="0.3" />
            )
          })}

          {/* Points */}
          {points.map((point, i) => {
            const x = toX(point.value)
            return (
              <g key={i}>
                <circle
                  cx={x}
                  cy="40"
                  r="6"
                  fill={point.type === "closed" ? "rgb(34, 197, 94)" : "white"}
                  stroke="rgb(34, 197, 94)"
                  strokeWidth="2"
                />
                <text x={x} y="65" textAnchor="middle" fontSize="12" fill="currentColor">
                  {point.value.toFixed(1)}
                </text>
              </g>
            )
          })}

          {/* Min/Max labels */}
          <text x={padding} y="65" textAnchor="middle" fontSize="10" fill="currentColor" opacity="0.6">
            -∞
          </text>
          <text x={300 - padding} y="65" textAnchor="middle" fontSize="10" fill="currentColor" opacity="0.6">
            +∞
          </text>
        </svg>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Inequality Solver</CardTitle>
                    <CardDescription>Solve linear, compound, and absolute value inequalities</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Inequality Type */}
                <div className="space-y-2">
                  <Label>Inequality Type</Label>
                  <Select value={inequalityType} onValueChange={(v) => setInequalityType(v as InequalityType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single">Single Inequality (e.g., 2x - 5 {">"} 3)</SelectItem>
                      <SelectItem value="compound">
                        Compound Inequality (e.g., 1 {"<"} 2x + 3 {"<="} 7)
                      </SelectItem>
                      <SelectItem value="absolute">Absolute Value (e.g., |x - 3| {"<"} 5)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Variable */}
                <div className="space-y-2">
                  <Label htmlFor="variable">Variable</Label>
                  <Select value={variable} onValueChange={setVariable}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="x">x</SelectItem>
                      <SelectItem value="y">y</SelectItem>
                      <SelectItem value="z">z</SelectItem>
                      <SelectItem value="t">t</SelectItem>
                      <SelectItem value="n">n</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Inequality Input */}
                <div className="space-y-2">
                  <Label htmlFor="inequality">Inequality</Label>
                  <Input
                    id="inequality"
                    placeholder={
                      inequalityType === "single"
                        ? "e.g., 2x - 5 > 3x + 1"
                        : inequalityType === "compound"
                          ? "e.g., 1 < 2x + 3 <= 7"
                          : "e.g., |x - 3| < 5"
                    }
                    value={inequality}
                    onChange={(e) => setInequality(e.target.value)}
                    className="font-mono"
                  />
                  <p className="text-xs text-muted-foreground">
                    Use {"<"}, {">"}, {"<="}, {">="} for inequality symbols
                  </p>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step solution</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={parseAndSolve} className="w-full" size="lg">
                  Solve Inequality
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    {/* Solution */}
                    <div
                      className={`p-4 rounded-xl border-2 ${
                        result.hasNoSolution
                          ? "bg-red-50 border-red-200"
                          : result.isAllReals
                            ? "bg-blue-50 border-blue-200"
                            : "bg-green-50 border-green-200"
                      }`}
                    >
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Solution</p>
                        <p
                          className={`text-2xl font-bold font-mono ${
                            result.hasNoSolution
                              ? "text-red-600"
                              : result.isAllReals
                                ? "text-blue-600"
                                : "text-green-600"
                          }`}
                        >
                          {result.solution}
                        </p>
                      </div>

                      <div className="mt-4 space-y-2">
                        <div className="flex items-center justify-between p-2 bg-background/50 rounded-lg">
                          <span className="text-sm text-muted-foreground">Interval Notation:</span>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-medium">{result.intervalNotation}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0"
                              onClick={() => handleCopy(result.intervalNotation, "interval")}
                            >
                              {copied === "interval" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                            </Button>
                          </div>
                        </div>
                        <div className="flex items-center justify-between p-2 bg-background/50 rounded-lg">
                          <span className="text-sm text-muted-foreground">Set-Builder:</span>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-medium text-sm">{result.setBuilder}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0"
                              onClick={() => handleCopy(result.setBuilder, "setbuilder")}
                            >
                              {copied === "setbuilder" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                            </Button>
                          </div>
                        </div>
                      </div>

                      {/* Number Line */}
                      {renderNumberLine()}

                      {/* Action Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleCopy(result.solution, "solution")}>
                          {copied === "solution" ? (
                            <Check className="h-4 w-4 mr-1" />
                          ) : (
                            <Copy className="h-4 w-4 mr-1" />
                          )}
                          {copied === "solution" ? "Copied" : "Copy"}
                        </Button>
                      </div>
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Card>
                        <CardHeader className="py-3 cursor-pointer" onClick={() => setStepsExpanded(!stepsExpanded)}>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-sm">Step-by-Step Solution</CardTitle>
                            {stepsExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </div>
                        </CardHeader>
                        {stepsExpanded && (
                          <CardContent className="pt-0">
                            <ol className="space-y-2">
                              {result.steps.map((step, index) => (
                                <li key={index} className="flex gap-3 text-sm">
                                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-medium flex-shrink-0">
                                    {index + 1}
                                  </span>
                                  <span className="font-mono pt-0.5">{step}</span>
                                </li>
                              ))}
                            </ol>
                          </CardContent>
                        )}
                      </Card>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Inequality Rules</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700 text-sm">Adding/Subtracting</p>
                      <p className="text-blue-600 text-xs mt-1">Inequality direction stays the same</p>
                    </div>
                    <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <p className="font-medium text-yellow-700 text-sm">Multiplying/Dividing by Positive</p>
                      <p className="text-yellow-600 text-xs mt-1">Inequality direction stays the same</p>
                    </div>
                    <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                      <p className="font-medium text-red-700 text-sm">Multiplying/Dividing by Negative</p>
                      <p className="text-red-600 text-xs mt-1">Inequality direction FLIPS</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Inequality Symbols</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <span className="font-mono font-bold">{"<"}</span>
                      <p className="text-xs text-muted-foreground mt-1">Less than</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <span className="font-mono font-bold">{">"}</span>
                      <p className="text-xs text-muted-foreground mt-1">Greater than</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <span className="font-mono font-bold">{"<="}</span>
                      <p className="text-xs text-muted-foreground mt-1">Less than or equal</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <span className="font-mono font-bold">{">="}</span>
                      <p className="text-xs text-muted-foreground mt-1">Greater than or equal</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-2 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Single:</p>
                    <code className="text-xs">2x - 5 {">"} 3x + 1</code>
                  </div>
                  <div className="p-2 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Compound:</p>
                    <code className="text-xs">
                      1 {"<"} 2x + 3 {"<="} 7
                    </code>
                  </div>
                  <div className="p-2 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Absolute Value:</p>
                    <code className="text-xs">|x - 3| {"<"} 5</code>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Inequalities?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Inequalities are mathematical expressions that compare two values using symbols like less than ({"<"}
                  ), greater than ({">"}), less than or equal to ({"≤"}), or greater than or equal to ({"≥"}). Unlike
                  equations that have specific solutions, inequalities often have ranges of values that satisfy them.
                  They are fundamental in algebra and have applications in optimization, economics, physics, and
                  everyday decision-making where constraints need to be expressed mathematically.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Inequalities</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Linear Inequalities</h4>
                    <p className="text-blue-700 text-sm">
                      Inequalities involving a single variable raised to the first power, like 2x + 5 {">"} 11. The
                      solution is typically a range of values on one side of a boundary point.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Compound Inequalities</h4>
                    <p className="text-green-700 text-sm">
                      Two inequalities joined by AND or OR. AND inequalities (like 1 {"<"} x {"<"} 5) require both
                      conditions to be true, while OR inequalities satisfy at least one condition.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Absolute Value Inequalities</h4>
                    <p className="text-purple-700 text-sm">
                      Inequalities containing absolute value expressions like |x - 3| {"<"} 5. These are solved by
                      considering the distance from a point, resulting in compound inequalities.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    <p className="font-medium text-foreground mb-1">Disclaimer</p>
                    <p>
                      This inequality solver applies standard algebraic rules. Results depend on correct input
                      formatting and mathematical assumptions. Always verify solutions for critical applications.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
