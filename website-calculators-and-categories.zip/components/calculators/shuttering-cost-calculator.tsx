"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Square, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type ElementType = "slab" | "beam" | "column" | "footing"
type CalculationMode = "auto" | "manual"

interface ShutteringResult {
  area: number
  totalCost: number
  costPerElement: number
}

export function ShutteringCostCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [elementType, setElementType] = useState<ElementType>("slab")
  const [calculationMode, setCalculationMode] = useState<CalculationMode>("auto")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [depth, setDepth] = useState("")
  const [manualArea, setManualArea] = useState("")
  const [rate, setRate] = useState("")
  const [repetitions, setRepetitions] = useState("1")
  const [result, setResult] = useState<ShutteringResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateShuttering = () => {
    setError("")
    setResult(null)

    const rateNum = parseFloat(rate)
    if (isNaN(rateNum) || rateNum <= 0) {
      setError("Please enter a valid shuttering rate greater than 0")
      return
    }

    const reps = parseInt(repetitions)
    if (isNaN(reps) || reps <= 0) {
      setError("Please enter valid number of repetitions")
      return
    }

    let areaM2: number

    if (calculationMode === "manual") {
      const area = parseFloat(manualArea)
      if (isNaN(area) || area <= 0) {
        setError("Please enter a valid area greater than 0")
        return
      }
      areaM2 = unitSystem === "imperial" ? area * 0.092903 : area
    } else {
      const l = parseFloat(length)
      const w = parseFloat(width)
      const h = parseFloat(height)
      const d = parseFloat(depth)

      if (elementType === "slab") {
        if (isNaN(l) || isNaN(w) || l <= 0 || w <= 0) {
          setError("Please enter valid length and width")
          return
        }
        const lengthM = unitSystem === "imperial" ? l * 0.3048 : l
        const widthM = unitSystem === "imperial" ? w * 0.3048 : w
        areaM2 = lengthM * widthM
      } else if (elementType === "beam") {
        if (isNaN(l) || isNaN(w) || isNaN(d) || l <= 0 || w <= 0 || d <= 0) {
          setError("Please enter valid length, width, and depth")
          return
        }
        const lengthM = unitSystem === "imperial" ? l * 0.3048 : l
        const widthM = unitSystem === "imperial" ? w * 0.3048 : w
        const depthM = unitSystem === "imperial" ? d * 0.3048 : d
        // Beam: two sides + bottom
        areaM2 = lengthM * widthM + 2 * (lengthM * depthM)
      } else if (elementType === "column") {
        if (isNaN(l) || isNaN(w) || isNaN(h) || l <= 0 || w <= 0 || h <= 0) {
          setError("Please enter valid length, width, and height")
          return
        }
        const lengthM = unitSystem === "imperial" ? l * 0.3048 : l
        const widthM = unitSystem === "imperial" ? w * 0.3048 : w
        const heightM = unitSystem === "imperial" ? h * 0.3048 : h
        // Column: all four sides
        areaM2 = 2 * (lengthM + widthM) * heightM
      } else if (elementType === "footing") {
        if (isNaN(l) || isNaN(w) || isNaN(d) || l <= 0 || w <= 0 || d <= 0) {
          setError("Please enter valid length, width, and depth")
          return
        }
        const lengthM = unitSystem === "imperial" ? l * 0.3048 : l
        const widthM = unitSystem === "imperial" ? w * 0.3048 : w
        const depthM = unitSystem === "imperial" ? d * 0.3048 : d
        // Footing: sides only (not bottom)
        areaM2 = 2 * (lengthM + widthM) * depthM
      }
    }

    const totalArea = areaM2 * reps
    const displayArea = unitSystem === "imperial" ? totalArea / 0.092903 : totalArea
    const totalCost = totalArea * rateNum
    const costPerElement = totalCost / reps

    setResult({
      area: Math.round(displayArea * 100) / 100,
      totalCost: Math.round(totalCost * 100) / 100,
      costPerElement: Math.round(costPerElement * 100) / 100,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setHeight("")
    setDepth("")
    setManualArea("")
    setRate("")
    setRepetitions("1")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Shuttering Requirements:\nArea: ${result.area} ${unitSystem === "metric" ? "m²" : "ft²"}\nTotal Cost: ${result.totalCost}\nCost Per Element: ${result.costPerElement}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Shuttering Cost Estimate",
          text: `Shuttering Area: ${result.area} ${unitSystem === "metric" ? "m²" : "ft²"}, Total Cost: ${result.totalCost}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setHeight("")
    setDepth("")
    setManualArea("")
    setRate("")
    setResult(null)
    setError("")
  }

  const presetRates = [
    { label: "Plywood - Standard", value: "15" },
    { label: "Plywood - Premium", value: "20" },
    { label: "Steel Formwork", value: "25" },
    { label: "Aluminum Formwork", value: "30" },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Square className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Shuttering Cost Calculator</CardTitle>
                    <CardDescription>Calculate formwork area and cost for RCC elements</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="element">RCC Element Type</Label>
                  <Select value={elementType} onValueChange={(v) => setElementType(v as ElementType)}>
                    <SelectTrigger id="element">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="slab">Slab</SelectItem>
                      <SelectItem value="beam">Beam</SelectItem>
                      <SelectItem value="column">Column</SelectItem>
                      <SelectItem value="footing">Footing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mode">Calculation Mode</Label>
                  <Select value={calculationMode} onValueChange={(v) => setCalculationMode(v as CalculationMode)}>
                    <SelectTrigger id="mode">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto (From Dimensions)</SelectItem>
                      <SelectItem value="manual">Manual Area Input</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {calculationMode === "auto" ? (
                  <>
                    {elementType === "slab" && (
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor="length">
                            Length ({unitSystem === "metric" ? "m" : "ft"})
                          </Label>
                          <Input
                            id="length"
                            type="number"
                            placeholder="Length"
                            value={length}
                            onChange={(e) => setLength(e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                          <Input
                            id="width"
                            type="number"
                            placeholder="Width"
                            value={width}
                            onChange={(e) => setWidth(e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                      </div>
                    )}

                    {elementType === "beam" && (
                      <div className="space-y-3">
                        <div className="space-y-2">
                          <Label htmlFor="length">
                            Length ({unitSystem === "metric" ? "m" : "ft"})
                          </Label>
                          <Input
                            id="length"
                            type="number"
                            placeholder="Length"
                            value={length}
                            onChange={(e) => setLength(e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                            <Input
                              id="width"
                              type="number"
                              placeholder="Width"
                              value={width}
                              onChange={(e) => setWidth(e.target.value)}
                              min="0"
                              step="0.01"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="depth">Depth ({unitSystem === "metric" ? "m" : "ft"})</Label>
                            <Input
                              id="depth"
                              type="number"
                              placeholder="Depth"
                              value={depth}
                              onChange={(e) => setDepth(e.target.value)}
                              min="0"
                              step="0.01"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {elementType === "column" && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <Label htmlFor="length">
                              Length ({unitSystem === "metric" ? "m" : "ft"})
                            </Label>
                            <Input
                              id="length"
                              type="number"
                              placeholder="Length"
                              value={length}
                              onChange={(e) => setLength(e.target.value)}
                              min="0"
                              step="0.01"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                            <Input
                              id="width"
                              type="number"
                              placeholder="Width"
                              value={width}
                              onChange={(e) => setWidth(e.target.value)}
                              min="0"
                              step="0.01"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="height">Height ({unitSystem === "metric" ? "m" : "ft"})</Label>
                          <Input
                            id="height"
                            type="number"
                            placeholder="Height"
                            value={height}
                            onChange={(e) => setHeight(e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                      </div>
                    )}

                    {elementType === "footing" && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <Label htmlFor="length">
                              Length ({unitSystem === "metric" ? "m" : "ft"})
                            </Label>
                            <Input
                              id="length"
                              type="number"
                              placeholder="Length"
                              value={length}
                              onChange={(e) => setLength(e.target.value)}
                              min="0"
                              step="0.01"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                            <Input
                              id="width"
                              type="number"
                              placeholder="Width"
                              value={width}
                              onChange={(e) => setWidth(e.target.value)}
                              min="0"
                              step="0.01"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="depth">Depth ({unitSystem === "metric" ? "m" : "ft"})</Label>
                          <Input
                            id="depth"
                            type="number"
                            placeholder="Depth"
                            value={depth}
                            onChange={(e) => setDepth(e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="manualArea">
                      Shuttering Area ({unitSystem === "metric" ? "m²" : "ft²"})
                    </Label>
                    <Input
                      id="manualArea"
                      type="number"
                      placeholder="Enter shuttering area"
                      value={manualArea}
                      onChange={(e) => setManualArea(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="rate">
                    Shuttering Rate (per {unitSystem === "metric" ? "m²" : "ft²"})
                  </Label>
                  <Input
                    id="rate"
                    type="number"
                    placeholder="Enter rate per unit area"
                    value={rate}
                    onChange={(e) => setRate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                  <div className="flex flex-wrap gap-1 mt-2">
                    {presetRates.map((preset) => (
                      <button
                        key={preset.label}
                        onClick={() => setRate(preset.value)}
                        className="px-2 py-1 text-xs rounded-md bg-amber-50 text-amber-700 hover:bg-amber-100 transition-colors"
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="repetitions">Number of Elements / Floors</Label>
                  <Input
                    id="repetitions"
                    type="number"
                    placeholder="Enter number"
                    value={repetitions}
                    onChange={(e) => setRepetitions(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculateShuttering} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Cost
                </Button>

                {result && (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Total Shuttering Area</p>
                          <p className="text-3xl font-bold text-amber-600">
                            {result.area} {unitSystem === "metric" ? "m²" : "ft²"}
                          </p>
                        </div>
                        <div className="border-t border-amber-200 pt-3 space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Total Cost:</span>
                            <p className="text-xl font-bold text-amber-700">{result.totalCost}</p>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Cost Per Element:</span>
                            <p className="font-semibold text-amber-600">{result.costPerElement}</p>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-xs">
                      <p className="font-medium mb-1">Disclaimer:</p>
                      <p>
                        Shuttering cost varies by material type, labor, and region. Rates used are indicative for
                        estimation only.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Element Shuttering Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-medium text-amber-800 mb-1">Slab</h4>
                      <p className="text-xs text-amber-700">Bottom area only (length × width)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-medium text-amber-800 mb-1">Beam</h4>
                      <p className="text-xs text-amber-700">Two sides + bottom surface</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-medium text-amber-800 mb-1">Column</h4>
                      <p className="text-xs text-amber-700">All four sides (perimeter × height)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-medium text-amber-800 mb-1">Footing</h4>
                      <p className="text-xs text-amber-700">Side faces only (not bottom)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Material Rates</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Plywood Standard:</span>
                    <span className="font-medium">₹15-20/ft²</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Steel Formwork:</span>
                    <span className="font-medium">₹25-30/ft²</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Aluminum:</span>
                    <span className="font-medium">₹30-40/ft²</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Shuttering in Construction?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Shuttering, also known as formwork, is a temporary structure used to support and shape wet concrete
                  until it gains sufficient strength to support itself. It plays a crucial role in construction by
                  providing the mold into which concrete is poured and held until it hardens. The quality and design of
                  shuttering directly impact the final appearance, dimensions, and structural integrity of concrete
                  elements.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Different types of shuttering materials are used based on project requirements, including timber
                  (plywood), steel, aluminum, and plastic. Modern construction increasingly uses aluminum and steel
                  formwork for their reusability, ease of handling, and superior finish quality. The cost of shuttering
                  typically accounts for 20-25% of the total concrete work cost, making accurate estimation essential for
                  budget planning and project management.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How Shuttering Area is Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Shuttering area calculation varies by element type. For slabs, only the bottom surface area is
                  considered since sides are typically supported by beams. For beams, the shuttering includes the bottom
                  surface and two vertical sides along the length. Columns require formwork on all four sides, calculated
                  as the perimeter multiplied by height. Footings need shuttering only on the vertical faces, excluding
                  the bottom which rests on the ground.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The total cost is determined by multiplying the shuttering area by the rate per square meter or square
                  foot. This rate varies based on material type, labor costs, regional pricing, and market conditions.
                  Plywood is generally the most economical option but has limited reuse cycles. Steel and aluminum
                  formwork have higher initial costs but can be reused multiple times, making them cost-effective for
                  large projects with repetitive elements. Additional factors like props, ties, clamps, and release agents
                  should also be considered in the overall shuttering budget.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Proper shuttering design and installation are critical for construction safety and quality. The formwork
                  must be strong enough to support the weight of wet concrete, reinforcement, construction loads, and
                  workers. Inadequate shuttering can lead to structural failures, surface defects, dimensional
                  inaccuracies, and safety hazards. Regular inspection and maintenance of formwork components ensure safe
                  and efficient concrete placement.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The removal time for shuttering depends on structural element type and concrete grade. Vertical
                  formwork for columns and walls can typically be removed after 24-48 hours, while soffit formwork for
                  beams and slabs requires longer periods (7-28 days) based on structural loading and concrete strength
                  development. Premature removal can cause deflection, cracking, or collapse. Using proper release agents
                  prevents concrete from bonding to formwork, facilitates easy removal, and improves surface finish
                  quality.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
