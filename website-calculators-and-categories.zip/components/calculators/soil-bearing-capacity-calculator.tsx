"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Mountain, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type SoilType = "clay" | "sand" | "silt" | "gravel"

interface BearingResult {
  ultimateCapacity: number
  safeCapacity: number
  foundationType: string
}

// Terzaghi bearing capacity factors (simplified)
const bearingFactors = {
  clay: { Nc: 5.7, Nq: 1.0, Nγ: 0.0, c: 50 }, // cohesion in kPa
  sand: { Nc: 37.2, Nq: 22.5, Nγ: 19.7, c: 0 },
  silt: { Nc: 20.0, Nq: 8.0, Nγ: 5.0, c: 20 },
  gravel: { Nc: 50.0, Nq: 35.0, Nγ: 40.0, c: 0 },
}

export function SoilBearingCapacityCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [soilType, setSoilType] = useState<SoilType>("sand")
  const [depth, setDepth] = useState("")
  const [width, setWidth] = useState("")
  const [unitWeight, setUnitWeight] = useState("")
  const [factorOfSafety, setFactorOfSafety] = useState("3")
  const [waterTableDepth, setWaterTableDepth] = useState("")
  const [result, setResult] = useState<BearingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBearingCapacity = () => {
    setError("")
    setResult(null)

    const depthNum = Number.parseFloat(depth)
    const widthNum = Number.parseFloat(width)
    const unitWeightNum = Number.parseFloat(unitWeight)
    const fosNum = Number.parseFloat(factorOfSafety)

    if (isNaN(depthNum) || depthNum <= 0) {
      setError("Please enter a valid depth greater than 0")
      return
    }
    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }
    if (isNaN(unitWeightNum) || unitWeightNum <= 0) {
      setError("Please enter a valid unit weight greater than 0")
      return
    }
    if (isNaN(fosNum) || fosNum < 1) {
      setError("Factor of safety must be at least 1")
      return
    }

    // Convert to metric if needed
    let depthM = depthNum
    let widthM = widthNum
    let γ = unitWeightNum // unit weight in kN/m³

    if (unitSystem === "imperial") {
      depthM = depthNum * 0.3048 // ft to m
      widthM = widthNum * 0.3048
      γ = unitWeightNum * 0.1571 // lb/ft³ to kN/m³
    }

    // Get bearing capacity factors
    const factors = bearingFactors[soilType]
    const c = factors.c // cohesion in kPa
    const Nc = factors.Nc
    const Nq = factors.Nq
    const Nγ = factors.Nγ

    // Overburden pressure
    const q = γ * depthM

    // Terzaghi's bearing capacity formula
    // q_ult = cNc + qNq + 0.5γBNγ
    const qUlt = c * Nc + q * Nq + 0.5 * γ * widthM * Nγ

    // Safe bearing capacity
    const qSafe = qUlt / fosNum

    // Convert back to imperial if needed
    let ultimateCapacity = qUlt
    let safeCapacity = qSafe

    if (unitSystem === "imperial") {
      ultimateCapacity = qUlt * 20.885 // kPa to psf
      safeCapacity = qSafe * 20.885
    }

    // Recommend foundation type
    let foundationType = "Shallow Strip Footing"
    if (safeCapacity < (unitSystem === "metric" ? 100 : 2000)) {
      foundationType = "Deep Pile Foundation Recommended"
    } else if (safeCapacity < (unitSystem === "metric" ? 200 : 4000)) {
      foundationType = "Mat/Raft Foundation"
    } else if (safeCapacity > (unitSystem === "metric" ? 400 : 8000)) {
      foundationType = "Shallow Isolated Footing"
    }

    setResult({
      ultimateCapacity: Math.round(ultimateCapacity * 10) / 10,
      safeCapacity: Math.round(safeCapacity * 10) / 10,
      foundationType,
    })
  }

  const handleReset = () => {
    setDepth("")
    setWidth("")
    setUnitWeight("")
    setFactorOfSafety("3")
    setWaterTableDepth("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "kPa" : "psf"
      await navigator.clipboard.writeText(
        `Soil Bearing Capacity: Safe Capacity = ${result.safeCapacity} ${unit}, Ultimate Capacity = ${result.ultimateCapacity} ${unit}, Recommended: ${result.foundationType}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const unit = unitSystem === "metric" ? "kPa" : "psf"
        await navigator.share({
          title: "Soil Bearing Capacity Result",
          text: `Safe Bearing Capacity: ${result.safeCapacity} ${unit} - Calculated using CalcHub`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setDepth("")
    setWidth("")
    setUnitWeight("")
    setWaterTableDepth("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Mountain className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Soil Bearing Capacity Calculator</CardTitle>
                    <CardDescription>Calculate safe bearing capacity for foundation design</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Soil Type */}
                <div className="space-y-2">
                  <Label htmlFor="soilType">Soil Type</Label>
                  <Select value={soilType} onValueChange={(value) => setSoilType(value as SoilType)}>
                    <SelectTrigger id="soilType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="clay">Clay (Cohesive)</SelectItem>
                      <SelectItem value="sand">Sand (Cohesionless)</SelectItem>
                      <SelectItem value="silt">Silt (Mixed)</SelectItem>
                      <SelectItem value="gravel">Gravel (Coarse)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Depth */}
                <div className="space-y-2">
                  <Label htmlFor="depth">Foundation Depth ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="depth"
                    type="number"
                    placeholder={`Enter depth in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={depth}
                    onChange={(e) => setDepth(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Width */}
                <div className="space-y-2">
                  <Label htmlFor="width">Foundation Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="width"
                    type="number"
                    placeholder={`Enter width in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={width}
                    onChange={(e) => setWidth(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Unit Weight */}
                <div className="space-y-2">
                  <Label htmlFor="unitWeight">
                    Unit Weight of Soil ({unitSystem === "metric" ? "kN/m³" : "lb/ft³"})
                  </Label>
                  <Input
                    id="unitWeight"
                    type="number"
                    placeholder={`Enter unit weight`}
                    value={unitWeight}
                    onChange={(e) => setUnitWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Factor of Safety */}
                <div className="space-y-2">
                  <Label htmlFor="fos">Factor of Safety</Label>
                  <Input
                    id="fos"
                    type="number"
                    placeholder="Default: 3"
                    value={factorOfSafety}
                    onChange={(e) => setFactorOfSafety(e.target.value)}
                    min="1"
                    step="0.1"
                  />
                </div>

                {/* Water Table Depth (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="waterTable">Water Table Depth (Optional) ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="waterTable"
                    type="number"
                    placeholder="Leave blank if not applicable"
                    value={waterTableDepth}
                    onChange={(e) => setWaterTableDepth(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBearingCapacity} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Capacity
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Safe Bearing Capacity</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {result.safeCapacity.toLocaleString()}
                        </p>
                        <p className="text-sm font-medium text-amber-600 mt-1">
                          {unitSystem === "metric" ? "kPa" : "psf"}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="text-center p-2 bg-white rounded-lg border border-amber-100">
                          <p className="text-xs text-muted-foreground mb-1">Ultimate Capacity</p>
                          <p className="font-semibold text-amber-700">
                            {result.ultimateCapacity.toLocaleString()} {unitSystem === "metric" ? "kPa" : "psf"}
                          </p>
                        </div>
                        <div className="text-center p-2 bg-white rounded-lg border border-amber-100">
                          <p className="text-xs text-muted-foreground mb-1">Recommended Type</p>
                          <p className="font-semibold text-amber-700 text-xs">{result.foundationType}</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Soil Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-amber-700">Clay</span>
                        <span className="text-xs text-amber-600">Cohesive</span>
                      </div>
                      <p className="text-xs text-amber-600">High cohesion, low permeability, prone to expansion</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-amber-700">Sand</span>
                        <span className="text-xs text-amber-600">Granular</span>
                      </div>
                      <p className="text-xs text-amber-600">Good drainage, high bearing capacity when compact</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-amber-700">Silt</span>
                        <span className="text-xs text-amber-600">Mixed</span>
                      </div>
                      <p className="text-xs text-amber-600">Moderate strength, susceptible to liquefaction</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-amber-700">Gravel</span>
                        <span className="text-xs text-amber-600">Coarse</span>
                      </div>
                      <p className="text-xs text-amber-600">Excellent drainage, highest bearing capacity</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bearing Capacity Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">q_ult = cNc + qNq + 0.5γBNγ</p>
                  </div>
                  <div className="space-y-2 text-xs">
                    <p><strong>c</strong> = Soil cohesion</p>
                    <p><strong>q</strong> = Overburden pressure (γ × Depth)</p>
                    <p><strong>γ</strong> = Unit weight of soil</p>
                    <p><strong>B</strong> = Foundation width</p>
                    <p><strong>Nc, Nq, Nγ</strong> = Bearing capacity factors</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Soil Bearing Capacity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Soil Bearing Capacity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Soil bearing capacity is the ability of soil to safely support the loads applied to it from structures
                  without excessive settlement or shear failure. It is a critical parameter in foundation design that
                  determines the size and depth of footings required to transfer structural loads to the underlying soil.
                  The bearing capacity depends on various factors including soil type, depth of foundation, groundwater
                  conditions, and the dimensions of the foundation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Engineers distinguish between ultimate bearing capacity (the maximum pressure the soil can withstand
                  before failure) and safe bearing capacity (ultimate capacity divided by a factor of safety). The factor
                  of safety, typically ranging from 2.5 to 3, accounts for uncertainties in soil properties, variations in
                  loading conditions, and potential construction defects. Proper assessment of soil bearing capacity is
                  essential to prevent foundation failures, excessive settlements, and structural damage.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Bearing Capacity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Bearing Capacity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The most widely used method for calculating bearing capacity is Terzaghi's bearing capacity equation,
                  developed in 1943. This equation considers three components: cohesion contribution (cNc), surcharge
                  contribution (qNq), and soil weight contribution (0.5γBNγ). The bearing capacity factors Nc, Nq, and Nγ
                  are dimensionless values that depend on the soil's internal friction angle and are obtained from
                  standard geotechnical tables.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For cohesive soils like clay, the cohesion term dominates the calculation, while for cohesionless soils
                  like sand, the friction terms are more significant. The surcharge pressure q represents the weight of
                  soil above the foundation base level. Modern geotechnical practice often employs more sophisticated
                  methods like the Meyerhof or Hansen equations, which account for foundation shape, load inclination, and
                  other factors for more accurate predictions.
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting Bearing Capacity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Mountain className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Bearing Capacity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors significantly influence the bearing capacity of soil. Soil type is the most fundamental
                  factor – cohesive soils (clay) derive strength from interparticle forces, while cohesionless soils
                  (sand, gravel) depend on friction between particles. The depth of foundation increases bearing capacity
                  because deeper foundations benefit from the confining pressure of overlying soil layers. Foundation
                  width also affects capacity, with wider foundations generally supporting higher loads due to better load
                  distribution.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Groundwater conditions play a crucial role – when the water table is near or above the foundation level,
                  it reduces the effective unit weight of soil, thereby decreasing bearing capacity. Soil density and
                  compaction directly impact strength, with denser soils providing greater resistance to settlement. The
                  shape and rigidity of the foundation, load eccentricity, and the rate of load application also influence
                  the actual bearing capacity achieved in practice.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p className="font-semibold text-amber-900">Important Disclaimer</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Soil bearing capacity calculations are approximate and based on simplified theoretical models.
                      Actual bearing capacity should be verified through comprehensive geotechnical investigation
                      including soil sampling, laboratory testing, and field tests such as Standard Penetration Test
                      (SPT) or Cone Penetration Test (CPT). Foundation design must comply with local building codes and
                      be reviewed by licensed geotechnical and structural engineers.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
