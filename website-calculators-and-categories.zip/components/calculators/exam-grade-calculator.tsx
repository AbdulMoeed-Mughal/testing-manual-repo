"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, Award, Plus, Trash2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type GradingScale = "standard" | "plusMinus" | "passFail" | "custom"

interface CustomGrade {
  letter: string
  minPercent: number
}

const standardGrades = [
  { letter: "A", minPercent: 90, description: "Excellent" },
  { letter: "B", minPercent: 80, description: "Good" },
  { letter: "C", minPercent: 70, description: "Average" },
  { letter: "D", minPercent: 60, description: "Below Average" },
  { letter: "F", minPercent: 0, description: "Fail" },
]

const plusMinusGrades = [
  { letter: "A+", minPercent: 97 },
  { letter: "A", minPercent: 93 },
  { letter: "A-", minPercent: 90 },
  { letter: "B+", minPercent: 87 },
  { letter: "B", minPercent: 83 },
  { letter: "B-", minPercent: 80 },
  { letter: "C+", minPercent: 77 },
  { letter: "C", minPercent: 73 },
  { letter: "C-", minPercent: 70 },
  { letter: "D+", minPercent: 67 },
  { letter: "D", minPercent: 63 },
  { letter: "D-", minPercent: 60 },
  { letter: "F", minPercent: 0 },
]

const passFailGrades = [
  { letter: "Pass", minPercent: 50 },
  { letter: "Fail", minPercent: 0 },
]

export function ExamGradeCalculator() {
  const [marksObtained, setMarksObtained] = useState<string>("")
  const [totalMarks, setTotalMarks] = useState<string>("100")
  const [gradingScale, setGradingScale] = useState<GradingScale>("standard")
  const [useWeightage, setUseWeightage] = useState(false)
  const [weightage, setWeightage] = useState<string>("100")
  const [customGrades, setCustomGrades] = useState<CustomGrade[]>([
    { letter: "A", minPercent: 90 },
    { letter: "B", minPercent: 80 },
    { letter: "C", minPercent: 70 },
    { letter: "D", minPercent: 60 },
    { letter: "F", minPercent: 0 },
  ])
  const [showBreakdown, setShowBreakdown] = useState(false)
  const [copied, setCopied] = useState(false)

  const marks = Number.parseFloat(marksObtained) || 0
  const total = Number.parseFloat(totalMarks) || 100
  const weight = Number.parseFloat(weightage) || 100

  const isValidInput = marks >= 0 && total > 0 && marks <= total && weight >= 0 && weight <= 100
  const percentage = isValidInput ? (marks / total) * 100 : 0
  const weightedScore = isValidInput ? percentage * (weight / 100) : 0

  const getGrades = () => {
    switch (gradingScale) {
      case "standard":
        return standardGrades
      case "plusMinus":
        return plusMinusGrades
      case "passFail":
        return passFailGrades
      case "custom":
        return customGrades.sort((a, b) => b.minPercent - a.minPercent)
      default:
        return standardGrades
    }
  }

  const getGrade = (percent: number) => {
    const grades = getGrades()
    for (const grade of grades) {
      if (percent >= grade.minPercent) {
        return grade
      }
    }
    return grades[grades.length - 1]
  }

  const grade = getGrade(percentage)

  const getGradeColor = (letter: string) => {
    if (letter.startsWith("A") || letter === "Pass") return "text-green-600"
    if (letter.startsWith("B")) return "text-blue-600"
    if (letter.startsWith("C")) return "text-yellow-600"
    if (letter.startsWith("D")) return "text-orange-600"
    return "text-red-600"
  }

  const getGradeBgColor = (letter: string) => {
    if (letter.startsWith("A") || letter === "Pass") return "bg-green-50 border-green-200"
    if (letter.startsWith("B")) return "bg-blue-50 border-blue-200"
    if (letter.startsWith("C")) return "bg-yellow-50 border-yellow-200"
    if (letter.startsWith("D")) return "bg-orange-50 border-orange-200"
    return "bg-red-50 border-red-200"
  }

  const addCustomGrade = () => {
    setCustomGrades([...customGrades, { letter: "", minPercent: 0 }])
  }

  const removeCustomGrade = (index: number) => {
    if (customGrades.length > 2) {
      setCustomGrades(customGrades.filter((_, i) => i !== index))
    }
  }

  const updateCustomGrade = (index: number, field: "letter" | "minPercent", value: string | number) => {
    const updated = [...customGrades]
    if (field === "letter") {
      updated[index].letter = value as string
    } else {
      updated[index].minPercent = value as number
    }
    setCustomGrades(updated)
  }

  const handleReset = () => {
    setMarksObtained("")
    setTotalMarks("100")
    setGradingScale("standard")
    setUseWeightage(false)
    setWeightage("100")
    setCustomGrades([
      { letter: "A", minPercent: 90 },
      { letter: "B", minPercent: 80 },
      { letter: "C", minPercent: 70 },
      { letter: "D", minPercent: 60 },
      { letter: "F", minPercent: 0 },
    ])
  }

  const handleCopy = async () => {
    if (!isValidInput || !marksObtained) return
    const text = `Exam Grade Results:\nMarks: ${marks}/${total}\nPercentage: ${percentage.toFixed(2)}%\nGrade: ${grade.letter}${useWeightage ? `\nWeighted Score: ${weightedScore.toFixed(2)}%` : ""}`
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShare = async () => {
    if (!isValidInput || !marksObtained) return
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Exam Grade Results",
          text: `Marks: ${marks}/${total} = ${percentage.toFixed(2)}% (${grade.letter})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/education-learning">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Education & Learning
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                    <Award className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Exam Grade Calculator</CardTitle>
                    <CardDescription>Calculate your grade from exam marks</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Marks Input */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="marks">Marks Obtained</Label>
                    <Input
                      id="marks"
                      type="number"
                      placeholder="e.g., 85"
                      value={marksObtained}
                      onChange={(e) => setMarksObtained(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="total">Total Marks</Label>
                    <Input
                      id="total"
                      type="number"
                      placeholder="e.g., 100"
                      value={totalMarks}
                      onChange={(e) => setTotalMarks(e.target.value)}
                      min="1"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Grading Scale */}
                <div className="space-y-2">
                  <Label>Grading Scale</Label>
                  <Select value={gradingScale} onValueChange={(v) => setGradingScale(v as GradingScale)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select grading scale" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard (A-F)</SelectItem>
                      <SelectItem value="plusMinus">Plus/Minus (A+ to F)</SelectItem>
                      <SelectItem value="passFail">Pass/Fail</SelectItem>
                      <SelectItem value="custom">Custom Scale</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Custom Grades */}
                {gradingScale === "custom" && (
                  <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">Custom Grade Thresholds</Label>
                      <Button variant="outline" size="sm" onClick={addCustomGrade}>
                        <Plus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {customGrades.map((g, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Input
                            placeholder="Grade"
                            value={g.letter}
                            onChange={(e) => updateCustomGrade(index, "letter", e.target.value)}
                            className="w-20"
                          />
                          <span className="text-sm text-muted-foreground">≥</span>
                          <Input
                            type="number"
                            placeholder="Min %"
                            value={g.minPercent}
                            onChange={(e) =>
                              updateCustomGrade(index, "minPercent", Number.parseFloat(e.target.value) || 0)
                            }
                            className="w-20"
                            min="0"
                            max="100"
                          />
                          <span className="text-sm text-muted-foreground">%</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeCustomGrade(index)}
                            disabled={customGrades.length <= 2}
                            className="h-8 w-8"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Weightage Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <Label className="text-sm font-medium">Include Weightage</Label>
                    <p className="text-xs text-muted-foreground">For weighted final grade</p>
                  </div>
                  <Switch checked={useWeightage} onCheckedChange={setUseWeightage} />
                </div>

                {useWeightage && (
                  <div className="space-y-2">
                    <Label htmlFor="weight">Exam Weightage (%)</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder="e.g., 30"
                      value={weightage}
                      onChange={(e) => setWeightage(e.target.value)}
                      min="0"
                      max="100"
                    />
                  </div>
                )}

                {/* Error */}
                {marksObtained && marks > total && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">
                    Marks obtained cannot exceed total marks
                  </div>
                )}

                {/* Result */}
                {marksObtained && isValidInput && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getGradeBgColor(grade.letter)} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Grade</p>
                      <p className={`text-5xl font-bold ${getGradeColor(grade.letter)} mb-2`}>{grade.letter}</p>
                      <p className="text-lg font-semibold text-muted-foreground">{percentage.toFixed(2)}%</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-current/10">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Score</p>
                        <p className="text-lg font-semibold">
                          {marks}/{total}
                        </p>
                      </div>
                      {useWeightage && (
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Weighted</p>
                          <p className="text-lg font-semibold">{weightedScore.toFixed(2)}%</p>
                        </div>
                      )}
                    </div>

                    {/* Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3 text-muted-foreground">
                          {showBreakdown ? "Hide" : "Show"} Calculation
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="p-3 bg-background/50 rounded text-sm space-y-2">
                          <p className="font-mono text-center">
                            ({marks} ÷ {total}) × 100 = {percentage.toFixed(2)}%
                          </p>
                          {useWeightage && (
                            <p className="font-mono text-center">
                              {percentage.toFixed(2)} × ({weight} ÷ 100) = {weightedScore.toFixed(2)}%
                            </p>
                          )}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">
                    {gradingScale === "plusMinus"
                      ? "Plus/Minus"
                      : gradingScale === "passFail"
                        ? "Pass/Fail"
                        : "Standard"}{" "}
                    Scale
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {getGrades()
                      .slice(0, 6)
                      .map((g) => (
                        <div
                          key={g.letter}
                          className={`flex items-center justify-between p-2 rounded-lg ${getGradeBgColor(g.letter)}`}
                        >
                          <span className={`font-medium ${getGradeColor(g.letter)}`}>{g.letter}</span>
                          <span className="text-sm text-muted-foreground">≥ {g.minPercent}%</span>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Grade Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Percentage = (Marks ÷ Total) × 100</p>
                  </div>
                  <p>
                    The percentage is then compared against the grading scale thresholds to determine your letter grade.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Exam Grades</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Exam grades are determined by converting your raw score (marks obtained) into a percentage, then
                  mapping that percentage to a letter grade based on the grading scale used by your institution.
                  Different schools and universities use different grading scales, with the most common being the
                  standard A-F scale and the plus/minus scale that provides more granularity.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Some courses use weighted grading where different components (exams, assignments, projects) contribute
                  different percentages to your final grade. The weightage feature in this calculator helps you
                  understand how much your exam score contributes to your overall course grade.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
