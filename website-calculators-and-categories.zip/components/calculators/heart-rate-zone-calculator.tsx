"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Heart,
  Info,
  Activity,
  AlertTriangle,
  Zap,
  Flame,
  Target,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type ActivityGoal = "fat-burn" | "cardio" | "peak"

interface HeartRateZone {
  name: string
  description: string
  minPercent: number
  maxPercent: number
  minBpm: number
  maxBpm: number
  color: string
  bgColor: string
}

interface HRResult {
  maxHR: number
  hrr: number
  zones: HeartRateZone[]
  recommendedZone: number
}

export function HeartRateZoneCalculator() {
  const [age, setAge] = useState("")
  const [restingHR, setRestingHR] = useState("70")
  const [activityGoal, setActivityGoal] = useState<ActivityGoal>("cardio")
  const [result, setResult] = useState<HRResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateZones = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseInt(age)
    const restingHRNum = Number.parseInt(restingHR) || 70

    if (isNaN(ageNum) || ageNum < 10) {
      setError("Please enter a valid age (10 or older)")
      return
    }

    if (restingHRNum < 30 || restingHRNum > 120) {
      setError("Resting heart rate should be between 30 and 120 bpm")
      return
    }

    // Calculate max heart rate and heart rate reserve
    const maxHR = 220 - ageNum
    const hrr = maxHR - restingHRNum

    // Calculate zones using Karvonen method
    const zoneData = [
      {
        name: "Zone 1 - Very Light",
        description: "Warm-up, recovery",
        minPercent: 50,
        maxPercent: 60,
        color: "text-gray-600",
        bgColor: "bg-gray-100 border-gray-300",
      },
      {
        name: "Zone 2 - Light (Fat Burn)",
        description: "Fat burning, endurance base",
        minPercent: 60,
        maxPercent: 70,
        color: "text-blue-600",
        bgColor: "bg-blue-50 border-blue-200",
      },
      {
        name: "Zone 3 - Moderate (Cardio)",
        description: "Aerobic fitness, stamina",
        minPercent: 70,
        maxPercent: 80,
        color: "text-green-600",
        bgColor: "bg-green-50 border-green-200",
      },
      {
        name: "Zone 4 - Hard (Threshold)",
        description: "Anaerobic threshold, speed",
        minPercent: 80,
        maxPercent: 90,
        color: "text-yellow-600",
        bgColor: "bg-yellow-50 border-yellow-200",
      },
      {
        name: "Zone 5 - Maximum (Peak)",
        description: "Maximum effort, power",
        minPercent: 90,
        maxPercent: 100,
        color: "text-red-600",
        bgColor: "bg-red-50 border-red-200",
      },
    ]

    const zones: HeartRateZone[] = zoneData.map((zone) => ({
      ...zone,
      minBpm: Math.round(restingHRNum + (zone.minPercent / 100) * hrr),
      maxBpm: Math.round(restingHRNum + (zone.maxPercent / 100) * hrr),
    }))

    // Determine recommended zone based on goal
    let recommendedZone = 2
    if (activityGoal === "fat-burn") recommendedZone = 1
    else if (activityGoal === "cardio") recommendedZone = 2
    else if (activityGoal === "peak") recommendedZone = 4

    setResult({ maxHR, hrr, zones, recommendedZone })
  }

  const handleReset = () => {
    setAge("")
    setRestingHR("70")
    setActivityGoal("cardio")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const zonesText = result.zones.map((z) => `${z.name}: ${z.minBpm}-${z.maxBpm} bpm`).join("\n")
      await navigator.clipboard.writeText(`My Heart Rate Zones:\nMax HR: ${result.maxHR} bpm\n\n${zonesText}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Heart Rate Zones",
          text: `I calculated my heart rate zones using CalcHub! My max HR is ${result.maxHR} bpm.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Heart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Heart Rate Zone Calculator</CardTitle>
                    <CardDescription>Calculate your target heart rate zones</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                    max="100"
                  />
                </div>

                {/* Resting Heart Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="restingHR">Resting Heart Rate (bpm) - Optional</Label>
                  <Input
                    id="restingHR"
                    type="number"
                    placeholder="Default: 70 bpm"
                    value={restingHR}
                    onChange={(e) => setRestingHR(e.target.value)}
                    min="30"
                    max="120"
                  />
                  <p className="text-xs text-muted-foreground">Measure in the morning before getting out of bed</p>
                </div>

                {/* Activity Goal */}
                <div className="space-y-2">
                  <Label>Activity Goal</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setActivityGoal("fat-burn")}
                      className={`flex flex-col items-center gap-1 p-3 rounded-lg border-2 transition-all ${
                        activityGoal === "fat-burn"
                          ? "border-blue-500 bg-blue-50 text-blue-700"
                          : "border-border hover:border-blue-300"
                      }`}
                    >
                      <Flame className="h-5 w-5" />
                      <span className="text-xs font-medium">Fat Burn</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActivityGoal("cardio")}
                      className={`flex flex-col items-center gap-1 p-3 rounded-lg border-2 transition-all ${
                        activityGoal === "cardio"
                          ? "border-green-500 bg-green-50 text-green-700"
                          : "border-border hover:border-green-300"
                      }`}
                    >
                      <Activity className="h-5 w-5" />
                      <span className="text-xs font-medium">Cardio</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActivityGoal("peak")}
                      className={`flex flex-col items-center gap-1 p-3 rounded-lg border-2 transition-all ${
                        activityGoal === "peak"
                          ? "border-red-500 bg-red-50 text-red-700"
                          : "border-border hover:border-red-300"
                      }`}
                    >
                      <Zap className="h-5 w-5" />
                      <span className="text-xs font-medium">Peak</span>
                    </button>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateZones} className="w-full" size="lg">
                  Calculate Heart Rate Zones
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    {/* Max HR and HRR */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-primary/10 text-center">
                        <p className="text-xs text-muted-foreground">Max Heart Rate</p>
                        <p className="text-2xl font-bold text-primary">{result.maxHR}</p>
                        <p className="text-xs text-muted-foreground">bpm</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted text-center">
                        <p className="text-xs text-muted-foreground">Heart Rate Reserve</p>
                        <p className="text-2xl font-bold">{result.hrr}</p>
                        <p className="text-xs text-muted-foreground">bpm</p>
                      </div>
                    </div>

                    {/* Zones */}
                    <div className="space-y-2">
                      {result.zones.map((zone, index) => (
                        <div
                          key={index}
                          className={`p-3 rounded-lg border-2 transition-all ${zone.bgColor} ${
                            index === result.recommendedZone ? "ring-2 ring-primary ring-offset-2" : ""
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {index === result.recommendedZone && <Target className="h-4 w-4 text-primary" />}
                              <div>
                                <p className={`font-semibold text-sm ${zone.color}`}>{zone.name}</p>
                                <p className="text-xs text-muted-foreground">{zone.description}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className={`font-bold ${zone.color}`}>
                                {zone.minBpm} - {zone.maxBpm}
                              </p>
                              <p className="text-xs text-muted-foreground">bpm</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 pt-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Zone Descriptions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <div className="h-3 w-3 rounded-full bg-gray-400 mt-1" />
                      <div>
                        <p className="font-medium text-gray-700 text-sm">Zone 1 - Very Light</p>
                        <p className="text-xs text-gray-600">Recovery, warm-up, cool-down</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="h-3 w-3 rounded-full bg-blue-500 mt-1" />
                      <div>
                        <p className="font-medium text-blue-700 text-sm">Zone 2 - Light</p>
                        <p className="text-xs text-blue-600">Fat burning, builds endurance</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="h-3 w-3 rounded-full bg-green-500 mt-1" />
                      <div>
                        <p className="font-medium text-green-700 text-sm">Zone 3 - Moderate</p>
                        <p className="text-xs text-green-600">Improves aerobic capacity</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <div className="h-3 w-3 rounded-full bg-yellow-500 mt-1" />
                      <div>
                        <p className="font-medium text-yellow-700 text-sm">Zone 4 - Hard</p>
                        <p className="text-xs text-yellow-600">Increases speed endurance</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-red-50 border border-red-200">
                      <div className="h-3 w-3 rounded-full bg-red-500 mt-1" />
                      <div>
                        <p className="font-medium text-red-700 text-sm">Zone 5 - Maximum</p>
                        <p className="text-xs text-red-600">Develops maximum performance</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Karvonen Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-1">
                    <p className="font-semibold text-foreground text-xs">Max HR = 220 - Age</p>
                    <p className="font-semibold text-foreground text-xs">HRR = Max HR - Resting HR</p>
                    <p className="font-semibold text-foreground text-xs">Target = Resting HR + (% × HRR)</p>
                  </div>
                  <p className="text-xs">
                    The Karvonen method accounts for your resting heart rate, making it more personalized than simpler
                    formulas.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Heart Rate Zone Training */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Heart Rate Zone Training?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Heart rate zone training is a scientifically-backed approach to exercise that uses your heart rate as
                  a guide to control the intensity of your workouts. By monitoring your heart rate and staying within
                  specific zones, you can optimize your training to achieve particular fitness goals, whether that's
                  burning fat, building endurance, improving cardiovascular health, or maximizing athletic performance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept is based on the physiological fact that different exercise intensities produce different
                  adaptations in your body. Lower intensities primarily use fat as fuel and build aerobic base, while
                  higher intensities improve anaerobic capacity and maximum performance. Understanding these zones
                  allows you to train smarter, not just harder, reducing the risk of overtraining while ensuring you're
                  getting the specific benefits you're looking for.
                </p>
              </CardContent>
            </Card>

            {/* The Karvonen Method */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Karvonen Method</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Karvonen method, also known as the Heart Rate Reserve (HRR) method, is considered more accurate
                  than simpler formulas because it takes into account your individual fitness level through your resting
                  heart rate. A lower resting heart rate generally indicates better cardiovascular fitness, and the
                  Karvonen formula adjusts your target zones accordingly.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The formula works by first calculating your maximum heart rate (typically 220 minus your age), then
                  determining your heart rate reserve (the difference between your maximum and resting heart rates).
                  Your target heart rate for any zone is then calculated by adding a percentage of your heart rate
                  reserve to your resting heart rate. This personalized approach means two people of the same age but
                  different fitness levels will have different target heart rates.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To get the most accurate results, measure your resting heart rate first thing in the morning before
                  getting out of bed. Take measurements over several days and use the average. Athletes and highly fit
                  individuals may have resting heart rates as low as 40-50 bpm, while the average adult typically ranges
                  from 60-80 bpm.
                </p>
              </CardContent>
            </Card>

            {/* Understanding the Five Zones */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Five Heart Rate Zones</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                    <h4 className="font-semibold text-gray-800 mb-2">Zone 1: Very Light (50-60% HRR)</h4>
                    <p className="text-gray-700 text-sm">
                      This is your recovery and warm-up zone. At this intensity, you can easily hold a conversation and
                      exercise for extended periods. It's ideal for warm-ups, cool-downs, and active recovery days.
                      While it may seem too easy, Zone 1 training is essential for recovery and building a foundation
                      for harder workouts.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Zone 2: Light / Fat Burn (60-70% HRR)</h4>
                    <p className="text-blue-700 text-sm">
                      Often called the "fat-burning zone," this intensity primarily uses fat as fuel. You can still
                      maintain a conversation but may need to catch your breath occasionally. Zone 2 is excellent for
                      building aerobic base, improving metabolic efficiency, and long-duration endurance training. Many
                      elite athletes spend 80% of their training time in this zone.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Zone 3: Moderate / Cardio (70-80% HRR)</h4>
                    <p className="text-green-700 text-sm">
                      This is the aerobic zone where you're working hard but sustainably. Conversation becomes
                      difficult, and you'll be breathing heavily. Zone 3 improves cardiovascular efficiency, increases
                      the number of mitochondria in your muscles, and enhances your body's ability to transport oxygen.
                      It's the go-to zone for general fitness improvement.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Zone 4: Hard / Threshold (80-90% HRR)</h4>
                    <p className="text-yellow-700 text-sm">
                      At this intensity, you're approaching your anaerobic threshold—the point where lactate accumulates
                      faster than it can be cleared. Speaking is limited to short phrases. Zone 4 training improves
                      lactate threshold, increases speed endurance, and prepares your body for high-intensity
                      performance. This zone is typically sustainable for 20-60 minutes.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Zone 5: Maximum / Peak (90-100% HRR)</h4>
                    <p className="text-red-700 text-sm">
                      This is your maximum effort zone, used for short, intense bursts. You cannot speak, and exercise
                      at this intensity is only sustainable for a few minutes. Zone 5 develops maximum speed, power, and
                      neuromuscular coordination. It's used sparingly in interval training and requires significant
                      recovery time afterward.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips for Heart Rate Training */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Effective Heart Rate Training</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To get the most out of heart rate zone training, invest in a reliable heart rate monitor—either a
                  chest strap for accuracy or a wrist-based optical sensor for convenience. Warm up properly before
                  attempting to reach higher zones, and always cool down after intense sessions. Remember that factors
                  like caffeine, stress, sleep quality, and hydration can affect your heart rate, so be flexible with
                  your training.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A balanced training program should include time in all zones, with the majority (about 80%) spent in
                  Zones 1-2, and the remaining 20% in higher intensity zones. This polarized approach has been shown to
                  produce the best long-term results while minimizing injury and burnout. Listen to your body, track
                  your progress, and don't hesitate to take rest days when needed.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-amber-800 mb-1">Important Disclaimer</p>
                    <p className="text-sm text-amber-700">
                      This calculator provides estimates only based on general formulas. Individual heart rate responses
                      can vary significantly based on genetics, fitness level, medications, and health conditions.
                      Consult a healthcare or fitness professional before starting any new exercise program, especially
                      if you have cardiovascular conditions or other health concerns.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
