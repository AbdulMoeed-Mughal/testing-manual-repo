"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Box, Info, AlertTriangle, Layers } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Shape =
  | "cube"
  | "cuboid"
  | "sphere"
  | "cylinder"
  | "cone"
  | "pyramid"
  | "triangular-prism"
  | "hemisphere"
  | "ellipsoid"
  | "torus"

type Unit = "mm" | "cm" | "m" | "in" | "ft" | "yd"

interface SurfaceAreaResult {
  totalArea: number
  lateralArea?: number
  baseArea?: number
  steps: string[]
  formula: string
}

const shapes: { value: Shape; label: string; icon: string }[] = [
  { value: "cube", label: "Cube", icon: "◻️" },
  { value: "cuboid", label: "Cuboid (Box)", icon: "📦" },
  { value: "sphere", label: "Sphere", icon: "🔵" },
  { value: "cylinder", label: "Cylinder", icon: "🛢️" },
  { value: "cone", label: "Cone", icon: "🔺" },
  { value: "pyramid", label: "Square Pyramid", icon: "🔻" },
  { value: "triangular-prism", label: "Triangular Prism", icon: "📐" },
  { value: "hemisphere", label: "Hemisphere", icon: "🌓" },
  { value: "ellipsoid", label: "Ellipsoid", icon: "🥚" },
  { value: "torus", label: "Torus (Donut)", icon: "🍩" },
]

const units: { value: Unit; label: string; areaLabel: string }[] = [
  { value: "mm", label: "Millimeters (mm)", areaLabel: "mm²" },
  { value: "cm", label: "Centimeters (cm)", areaLabel: "cm²" },
  { value: "m", label: "Meters (m)", areaLabel: "m²" },
  { value: "in", label: "Inches (in)", areaLabel: "in²" },
  { value: "ft", label: "Feet (ft)", areaLabel: "ft²" },
  { value: "yd", label: "Yards (yd)", areaLabel: "yd²" },
]

export function SurfaceAreaCalculator() {
  const [shape, setShape] = useState<Shape>("cube")
  const [unit, setUnit] = useState<Unit>("cm")
  const [result, setResult] = useState<SurfaceAreaResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Input states for different shapes
  const [side, setSide] = useState("")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [radius, setRadius] = useState("")
  const [slantHeight, setSlantHeight] = useState("")
  const [semiAxisA, setSemiAxisA] = useState("")
  const [semiAxisB, setSemiAxisB] = useState("")
  const [semiAxisC, setSemiAxisC] = useState("")
  const [majorRadius, setMajorRadius] = useState("")
  const [minorRadius, setMinorRadius] = useState("")
  const [baseA, setBaseA] = useState("")
  const [baseB, setBaseB] = useState("")
  const [baseC, setBaseC] = useState("")

  const getAreaUnit = () => units.find((u) => u.value === unit)?.areaLabel || "units²"

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return num.toExponential(4)
    if (num < 0.0001 && num > 0) return num.toExponential(4)
    return num.toLocaleString(undefined, { maximumFractionDigits: 4 })
  }

  const calculateSurfaceArea = () => {
    setError("")
    setResult(null)

    let totalArea = 0
    let lateralArea: number | undefined
    let baseArea: number | undefined
    const steps: string[] = []
    let formula = ""

    try {
      switch (shape) {
        case "cube": {
          const s = Number.parseFloat(side)
          if (isNaN(s) || s <= 0) {
            setError("Please enter a valid side length greater than 0")
            return
          }
          formula = "SA = 6s²"
          totalArea = 6 * s * s
          steps.push(`Side (s) = ${s} ${unit}`)
          steps.push(`Surface Area = 6 × s²`)
          steps.push(`Surface Area = 6 × ${s}²`)
          steps.push(`Surface Area = 6 × ${s * s}`)
          steps.push(`Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "cuboid": {
          const l = Number.parseFloat(length)
          const w = Number.parseFloat(width)
          const h = Number.parseFloat(height)
          if (isNaN(l) || l <= 0 || isNaN(w) || w <= 0 || isNaN(h) || h <= 0) {
            setError("Please enter valid dimensions greater than 0")
            return
          }
          formula = "SA = 2(lw + lh + wh)"
          totalArea = 2 * (l * w + l * h + w * h)
          lateralArea = 2 * (l * h + w * h)
          baseArea = 2 * l * w
          steps.push(`Length (l) = ${l} ${unit}, Width (w) = ${w} ${unit}, Height (h) = ${h} ${unit}`)
          steps.push(`Surface Area = 2(lw + lh + wh)`)
          steps.push(`Surface Area = 2(${l}×${w} + ${l}×${h} + ${w}×${h})`)
          steps.push(`Surface Area = 2(${l * w} + ${l * h} + ${w * h})`)
          steps.push(`Surface Area = 2 × ${l * w + l * h + w * h}`)
          steps.push(`Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "sphere": {
          const r = Number.parseFloat(radius)
          if (isNaN(r) || r <= 0) {
            setError("Please enter a valid radius greater than 0")
            return
          }
          formula = "SA = 4πr²"
          totalArea = 4 * Math.PI * r * r
          steps.push(`Radius (r) = ${r} ${unit}`)
          steps.push(`Surface Area = 4πr²`)
          steps.push(`Surface Area = 4 × π × ${r}²`)
          steps.push(`Surface Area = 4 × ${Math.PI.toFixed(6)} × ${r * r}`)
          steps.push(`Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "cylinder": {
          const r = Number.parseFloat(radius)
          const h = Number.parseFloat(height)
          if (isNaN(r) || r <= 0 || isNaN(h) || h <= 0) {
            setError("Please enter valid radius and height greater than 0")
            return
          }
          formula = "SA = 2πr² + 2πrh = 2πr(r + h)"
          lateralArea = 2 * Math.PI * r * h
          baseArea = 2 * Math.PI * r * r
          totalArea = lateralArea + baseArea
          steps.push(`Radius (r) = ${r} ${unit}, Height (h) = ${h} ${unit}`)
          steps.push(`Total Surface Area = 2πr² + 2πrh`)
          steps.push(`Lateral Area = 2πrh = 2 × π × ${r} × ${h} = ${formatNumber(lateralArea)} ${getAreaUnit()}`)
          steps.push(`Base Area (both) = 2πr² = 2 × π × ${r}² = ${formatNumber(baseArea)} ${getAreaUnit()}`)
          steps.push(`Total Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "cone": {
          const r = Number.parseFloat(radius)
          const sl = Number.parseFloat(slantHeight)
          if (isNaN(r) || r <= 0 || isNaN(sl) || sl <= 0) {
            setError("Please enter valid radius and slant height greater than 0")
            return
          }
          if (sl < r) {
            setError("Slant height must be greater than or equal to radius")
            return
          }
          formula = "SA = πr² + πrl = πr(r + l)"
          lateralArea = Math.PI * r * sl
          baseArea = Math.PI * r * r
          totalArea = lateralArea + baseArea
          steps.push(`Radius (r) = ${r} ${unit}, Slant Height (l) = ${sl} ${unit}`)
          steps.push(`Total Surface Area = πr² + πrl`)
          steps.push(`Lateral Area = πrl = π × ${r} × ${sl} = ${formatNumber(lateralArea)} ${getAreaUnit()}`)
          steps.push(`Base Area = πr² = π × ${r}² = ${formatNumber(baseArea)} ${getAreaUnit()}`)
          steps.push(`Total Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "pyramid": {
          const b = Number.parseFloat(side)
          const sl = Number.parseFloat(slantHeight)
          if (isNaN(b) || b <= 0 || isNaN(sl) || sl <= 0) {
            setError("Please enter valid base side and slant height greater than 0")
            return
          }
          formula = "SA = b² + 2bl"
          lateralArea = 2 * b * sl
          baseArea = b * b
          totalArea = baseArea + lateralArea
          steps.push(`Base Side (b) = ${b} ${unit}, Slant Height (l) = ${sl} ${unit}`)
          steps.push(`Total Surface Area = b² + 2bl`)
          steps.push(`Lateral Area = 2bl = 2 × ${b} × ${sl} = ${formatNumber(lateralArea)} ${getAreaUnit()}`)
          steps.push(`Base Area = b² = ${b}² = ${formatNumber(baseArea)} ${getAreaUnit()}`)
          steps.push(`Total Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "triangular-prism": {
          const a = Number.parseFloat(baseA)
          const b = Number.parseFloat(baseB)
          const c = Number.parseFloat(baseC)
          const h = Number.parseFloat(height)
          if (isNaN(a) || a <= 0 || isNaN(b) || b <= 0 || isNaN(c) || c <= 0 || isNaN(h) || h <= 0) {
            setError("Please enter valid dimensions greater than 0")
            return
          }
          // Check triangle inequality
          if (a + b <= c || a + c <= b || b + c <= a) {
            setError("Invalid triangle: sum of any two sides must be greater than the third")
            return
          }
          // Calculate base triangle area using Heron's formula
          const s = (a + b + c) / 2
          const triangleArea = Math.sqrt(s * (s - a) * (s - b) * (s - c))
          formula = "SA = 2 × (Base Triangle Area) + (Perimeter × Height)"
          lateralArea = (a + b + c) * h
          baseArea = 2 * triangleArea
          totalArea = baseArea + lateralArea
          steps.push(`Triangle sides: a = ${a}, b = ${b}, c = ${c} ${unit}, Height = ${h} ${unit}`)
          steps.push(`Semi-perimeter (s) = (a + b + c) / 2 = ${s}`)
          steps.push(`Base Triangle Area = √(s(s-a)(s-b)(s-c)) = ${formatNumber(triangleArea)} ${getAreaUnit()}`)
          steps.push(
            `Lateral Area = Perimeter × Height = ${a + b + c} × ${h} = ${formatNumber(lateralArea)} ${getAreaUnit()}`,
          )
          steps.push(`Total Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "hemisphere": {
          const r = Number.parseFloat(radius)
          if (isNaN(r) || r <= 0) {
            setError("Please enter a valid radius greater than 0")
            return
          }
          formula = "SA = 3πr²"
          lateralArea = 2 * Math.PI * r * r
          baseArea = Math.PI * r * r
          totalArea = lateralArea + baseArea
          steps.push(`Radius (r) = ${r} ${unit}`)
          steps.push(`Total Surface Area = 2πr² (curved) + πr² (base) = 3πr²`)
          steps.push(`Curved Surface Area = 2πr² = ${formatNumber(lateralArea)} ${getAreaUnit()}`)
          steps.push(`Base Area = πr² = ${formatNumber(baseArea)} ${getAreaUnit()}`)
          steps.push(`Total Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "ellipsoid": {
          const a = Number.parseFloat(semiAxisA)
          const b = Number.parseFloat(semiAxisB)
          const c = Number.parseFloat(semiAxisC)
          if (isNaN(a) || a <= 0 || isNaN(b) || b <= 0 || isNaN(c) || c <= 0) {
            setError("Please enter valid semi-axes greater than 0")
            return
          }
          // Approximate formula (Knud Thomsen's formula)
          const p = 1.6075
          formula = "SA ≈ 4π((aᵖbᵖ + aᵖcᵖ + bᵖcᵖ)/3)^(1/p)"
          const ap = Math.pow(a, p)
          const bp = Math.pow(b, p)
          const cp = Math.pow(c, p)
          totalArea = 4 * Math.PI * Math.pow((ap * bp + ap * cp + bp * cp) / 3, 1 / p)
          steps.push(`Semi-axes: a = ${a}, b = ${b}, c = ${c} ${unit}`)
          steps.push(`Using Knud Thomsen's approximation formula (p ≈ 1.6075)`)
          steps.push(`Surface Area ≈ 4π × ((aᵖbᵖ + aᵖcᵖ + bᵖcᵖ)/3)^(1/p)`)
          steps.push(`Surface Area ≈ ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }

        case "torus": {
          const R = Number.parseFloat(majorRadius)
          const r = Number.parseFloat(minorRadius)
          if (isNaN(R) || R <= 0 || isNaN(r) || r <= 0) {
            setError("Please enter valid radii greater than 0")
            return
          }
          if (r > R) {
            setError("Minor radius should be less than major radius for a standard torus")
            return
          }
          formula = "SA = 4π²Rr"
          totalArea = 4 * Math.PI * Math.PI * R * r
          steps.push(`Major Radius (R) = ${R} ${unit}, Minor Radius (r) = ${r} ${unit}`)
          steps.push(`Surface Area = 4π²Rr`)
          steps.push(`Surface Area = 4 × π² × ${R} × ${r}`)
          steps.push(`Surface Area = ${formatNumber(totalArea)} ${getAreaUnit()}`)
          break
        }
      }

      setResult({ totalArea, lateralArea, baseArea, steps, formula })
    } catch {
      setError("An error occurred during calculation")
    }
  }

  const handleReset = () => {
    setSide("")
    setLength("")
    setWidth("")
    setHeight("")
    setRadius("")
    setSlantHeight("")
    setSemiAxisA("")
    setSemiAxisB("")
    setSemiAxisC("")
    setMajorRadius("")
    setMinorRadius("")
    setBaseA("")
    setBaseB("")
    setBaseC("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Surface Area: ${formatNumber(result.totalArea)} ${getAreaUnit()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Surface Area Calculator Result",
          text: `I calculated the surface area using CalcHub! Surface Area: ${formatNumber(result.totalArea)} ${getAreaUnit()}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const renderInputs = () => {
    switch (shape) {
      case "cube":
        return (
          <div className="space-y-2">
            <Label htmlFor="side">Side Length ({unit})</Label>
            <Input
              id="side"
              type="number"
              placeholder="Enter side length"
              value={side}
              onChange={(e) => setSide(e.target.value)}
              min="0"
              step="any"
            />
          </div>
        )

      case "cuboid":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="length">Length ({unit})</Label>
              <Input
                id="length"
                type="number"
                placeholder="Enter length"
                value={length}
                onChange={(e) => setLength(e.target.value)}
                min="0"
                step="any"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="width">Width ({unit})</Label>
              <Input
                id="width"
                type="number"
                placeholder="Enter width"
                value={width}
                onChange={(e) => setWidth(e.target.value)}
                min="0"
                step="any"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="height">Height ({unit})</Label>
              <Input
                id="height"
                type="number"
                placeholder="Enter height"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                min="0"
                step="any"
              />
            </div>
          </>
        )

      case "sphere":
        return (
          <div className="space-y-2">
            <Label htmlFor="radius">Radius ({unit})</Label>
            <Input
              id="radius"
              type="number"
              placeholder="Enter radius"
              value={radius}
              onChange={(e) => setRadius(e.target.value)}
              min="0"
              step="any"
            />
          </div>
        )

      case "cylinder":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="radius">Radius ({unit})</Label>
              <Input
                id="radius"
                type="number"
                placeholder="Enter radius"
                value={radius}
                onChange={(e) => setRadius(e.target.value)}
                min="0"
                step="any"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="height">Height ({unit})</Label>
              <Input
                id="height"
                type="number"
                placeholder="Enter height"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                min="0"
                step="any"
              />
            </div>
          </>
        )

      case "cone":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="radius">Base Radius ({unit})</Label>
              <Input
                id="radius"
                type="number"
                placeholder="Enter base radius"
                value={radius}
                onChange={(e) => setRadius(e.target.value)}
                min="0"
                step="any"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slantHeight">Slant Height ({unit})</Label>
              <Input
                id="slantHeight"
                type="number"
                placeholder="Enter slant height"
                value={slantHeight}
                onChange={(e) => setSlantHeight(e.target.value)}
                min="0"
                step="any"
              />
            </div>
          </>
        )

      case "pyramid":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="side">Base Side ({unit})</Label>
              <Input
                id="side"
                type="number"
                placeholder="Enter base side length"
                value={side}
                onChange={(e) => setSide(e.target.value)}
                min="0"
                step="any"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slantHeight">Slant Height ({unit})</Label>
              <Input
                id="slantHeight"
                type="number"
                placeholder="Enter slant height"
                value={slantHeight}
                onChange={(e) => setSlantHeight(e.target.value)}
                min="0"
                step="any"
              />
            </div>
          </>
        )

      case "triangular-prism":
        return (
          <>
            <div className="space-y-2">
              <Label>Triangle Base Sides ({unit})</Label>
              <div className="grid grid-cols-3 gap-2">
                <Input
                  type="number"
                  placeholder="Side a"
                  value={baseA}
                  onChange={(e) => setBaseA(e.target.value)}
                  min="0"
                  step="any"
                />
                <Input
                  type="number"
                  placeholder="Side b"
                  value={baseB}
                  onChange={(e) => setBaseB(e.target.value)}
                  min="0"
                  step="any"
                />
                <Input
                  type="number"
                  placeholder="Side c"
                  value={baseC}
                  onChange={(e) => setBaseC(e.target.value)}
                  min="0"
                  step="any"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="height">Prism Height ({unit})</Label>
              <Input
                id="height"
                type="number"
                placeholder="Enter prism height"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                min="0"
                step="any"
              />
            </div>
          </>
        )

      case "hemisphere":
        return (
          <div className="space-y-2">
            <Label htmlFor="radius">Radius ({unit})</Label>
            <Input
              id="radius"
              type="number"
              placeholder="Enter radius"
              value={radius}
              onChange={(e) => setRadius(e.target.value)}
              min="0"
              step="any"
            />
          </div>
        )

      case "ellipsoid":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="semiAxisA">Semi-axis a ({unit})</Label>
              <Input
                id="semiAxisA"
                type="number"
                placeholder="Enter semi-axis a"
                value={semiAxisA}
                onChange={(e) => setSemiAxisA(e.target.value)}
                min="0"
                step="any"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="semiAxisB">Semi-axis b ({unit})</Label>
              <Input
                id="semiAxisB"
                type="number"
                placeholder="Enter semi-axis b"
                value={semiAxisB}
                onChange={(e) => setSemiAxisB(e.target.value)}
                min="0"
                step="any"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="semiAxisC">Semi-axis c ({unit})</Label>
              <Input
                id="semiAxisC"
                type="number"
                placeholder="Enter semi-axis c"
                value={semiAxisC}
                onChange={(e) => setSemiAxisC(e.target.value)}
                min="0"
                step="any"
              />
            </div>
          </>
        )

      case "torus":
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="majorRadius">Major Radius R ({unit})</Label>
              <Input
                id="majorRadius"
                type="number"
                placeholder="Distance from center to tube center"
                value={majorRadius}
                onChange={(e) => setMajorRadius(e.target.value)}
                min="0"
                step="any"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="minorRadius">Minor Radius r ({unit})</Label>
              <Input
                id="minorRadius"
                type="number"
                placeholder="Radius of the tube"
                value={minorRadius}
                onChange={(e) => setMinorRadius(e.target.value)}
                min="0"
                step="any"
              />
            </div>
          </>
        )
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Box className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Surface Area Calculator</CardTitle>
                    <CardDescription>Calculate the surface area of 3D shapes</CardDescription>
                  </div>
                </div>

                {/* Unit Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit</span>
                  <Select value={unit} onValueChange={(value: Unit) => setUnit(value)}>
                    <SelectTrigger className="w-44">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {units.map((u) => (
                        <SelectItem key={u.value} value={u.value}>
                          {u.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Shape Selector */}
                <div className="space-y-2">
                  <Label>Shape</Label>
                  <Select
                    value={shape}
                    onValueChange={(value: Shape) => {
                      setShape(value)
                      handleReset()
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {shapes.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.icon} {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Dynamic Inputs */}
                {renderInputs()}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSurfaceArea} className="w-full" size="lg">
                  Calculate Surface Area
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Surface Area</p>
                      <p className="text-4xl font-bold text-blue-600 mb-1">{formatNumber(result.totalArea)}</p>
                      <p className="text-lg text-blue-600">{getAreaUnit()}</p>

                      {/* Additional areas */}
                      {(result.lateralArea !== undefined || result.baseArea !== undefined) && (
                        <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                          {result.lateralArea !== undefined && (
                            <div className="p-2 bg-white rounded-lg">
                              <p className="text-muted-foreground">Lateral Area</p>
                              <p className="font-semibold text-blue-600">
                                {formatNumber(result.lateralArea)} {getAreaUnit()}
                              </p>
                            </div>
                          )}
                          {result.baseArea !== undefined && (
                            <div className="p-2 bg-white rounded-lg">
                              <p className="text-muted-foreground">Base Area</p>
                              <p className="font-semibold text-blue-600">
                                {formatNumber(result.baseArea)} {getAreaUnit()}
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Step-by-step toggle */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-blue-600"
                    >
                      {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-1">
                        <p className="font-semibold text-foreground mb-2">Formula: {result.formula}</p>
                        {result.steps.map((step, index) => (
                          <p key={index} className="text-muted-foreground">
                            {index + 1}. {step}
                          </p>
                        ))}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Surface Area Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm max-h-64 overflow-y-auto">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Cube</p>
                      <p className="text-muted-foreground font-mono">SA = 6s²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Cuboid</p>
                      <p className="text-muted-foreground font-mono">SA = 2(lw + lh + wh)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Sphere</p>
                      <p className="text-muted-foreground font-mono">SA = 4πr²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Cylinder</p>
                      <p className="text-muted-foreground font-mono">SA = 2πr(r + h)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Cone</p>
                      <p className="text-muted-foreground font-mono">SA = πr(r + l)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Pyramid (Square)</p>
                      <p className="text-muted-foreground font-mono">SA = b² + 2bl</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Hemisphere</p>
                      <p className="text-muted-foreground font-mono">SA = 3πr²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Torus</p>
                      <p className="text-muted-foreground font-mono">SA = 4π²Rr</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-yellow-500" />
                    Note
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    This calculator provides estimates only. Verify manually for critical measurements. The ellipsoid
                    formula uses Knud Thomsen's approximation which is accurate to within about 1.061% of the exact
                    value.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Surface Area?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Surface area is a fundamental concept in geometry that measures the total area of all the surfaces
                  (faces) of a three-dimensional object. Think of it as the amount of material needed to wrap or cover
                  an object completely. Unlike volume, which measures the space inside an object, surface area focuses
                  on the exterior—the "skin" of the shape.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding surface area is crucial in many real-world applications. Architects calculate surface
                  areas to determine how much paint or cladding is needed for buildings. Engineers use it to calculate
                  heat transfer rates, as larger surface areas allow for more efficient heating or cooling.
                  Manufacturers need surface area calculations to estimate material costs for packaging, containers, and
                  products.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Different 3D Shapes</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Three-dimensional shapes can be categorized into different groups based on their properties.{" "}
                  <strong>Prisms</strong> like cubes, cuboids, and triangular prisms have two identical parallel bases
                  connected by rectangular faces. Their surface area is calculated by adding the areas of both bases and
                  all lateral (side) faces.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Curved shapes</strong> like spheres, cylinders, and cones have surfaces that include curved
                  portions. Spheres have no edges or vertices—their surface area depends solely on the radius. Cylinders
                  combine flat circular bases with a curved lateral surface, while cones have one circular base and a
                  pointed apex connected by a curved surface.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Complex shapes</strong> like tori (donuts) and ellipsoids require more advanced formulas. The
                  torus is formed by rotating a circle around an external axis, creating a ring shape. Ellipsoids are
                  stretched spheres where all three axes can have different lengths, making exact surface area
                  calculation mathematically complex.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Box className="h-5 w-5 text-primary" />
                  <CardTitle>Total vs. Lateral Surface Area</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When working with 3D shapes, it's important to understand the distinction between{" "}
                  <strong>total surface area</strong> and <strong>lateral (curved) surface area</strong>. Total surface
                  area includes all faces of the shape, while lateral surface area only includes the side surfaces,
                  excluding the top and bottom bases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This distinction matters in practical applications. If you're calculating how much sheet metal is
                  needed to make a cylindrical tank, you'd use total surface area. But if the tank will have no top
                  (like a swimming pool), you'd calculate differently. For a cone-shaped party hat, you only need the
                  lateral surface area since the base remains open.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Our calculator provides both values where applicable, helping you choose the appropriate measurement
                  for your specific needs. Always consider whether your application requires covering all surfaces or
                  just certain portions of the shape.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Surface area calculations have countless applications across industries. In{" "}
                  <strong>construction and architecture</strong>, surface area determines the amount of paint, tiles, or
                  wallpaper needed. Roof calculations for shingles, HVAC duct sizing, and insulation requirements all
                  depend on accurate surface area measurements.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In <strong>manufacturing and packaging</strong>, companies calculate surface areas to optimize
                  material usage and reduce costs. A cereal box designer needs to know the surface area to determine
                  cardboard requirements. Pharmaceutical companies calculate pill surface areas for coating processes.
                  Even gift wrapping benefits from quick surface area estimates!
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Science and engineering</strong> rely heavily on surface area for heat transfer calculations,
                  chemical reaction rates (larger surface areas speed up reactions), aerodynamics (drag depends on
                  surface area), and biological studies (cell membrane surface areas affect nutrient absorption).
                  Understanding surface area is truly fundamental to many fields of study and work.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
