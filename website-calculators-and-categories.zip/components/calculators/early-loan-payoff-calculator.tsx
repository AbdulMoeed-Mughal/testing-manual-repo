"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  DollarSign,
  Info,
  Calculator,
  TrendingDown,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface PayoffResult {
  originalPayoffDate: Date
  newPayoffDate: Date
  monthsSaved: number
  totalInterestOriginal: number
  totalInterestWithExtra: number
  interestSaved: number
  totalPaidOriginal: number
  totalPaidWithExtra: number
  schedule: ScheduleEntry[]
}

interface ScheduleEntry {
  month: number
  payment: number
  extraPayment: number
  principal: number
  interest: number
  balance: number
}

export function EarlyLoanPayoffCalculator() {
  const [loanAmount, setLoanAmount] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [loanTermYears, setLoanTermYears] = useState("")
  const [monthlyPayment, setMonthlyPayment] = useState("")
  const [extraMonthly, setExtraMonthly] = useState("")
  const [lumpSum, setLumpSum] = useState("")
  const [result, setResult] = useState<PayoffResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSchedule, setShowSchedule] = useState(false)

  const calculatePayoff = () => {
    setError("")
    setResult(null)

    const principal = Number.parseFloat(loanAmount)
    const rate = Number.parseFloat(interestRate)
    const termYears = Number.parseInt(loanTermYears)
    const payment = Number.parseFloat(monthlyPayment)
    const extraMonthlyPayment = Number.parseFloat(extraMonthly) || 0
    const lumpSumPayment = Number.parseFloat(lumpSum) || 0

    if (isNaN(principal) || principal <= 0) {
      setError("Please enter a valid loan amount greater than 0")
      return
    }
    if (isNaN(rate) || rate <= 0 || rate > 100) {
      setError("Please enter a valid interest rate between 0 and 100")
      return
    }
    if (isNaN(termYears) || termYears <= 0) {
      setError("Please enter a valid loan term greater than 0")
      return
    }
    if (isNaN(payment) || payment <= 0) {
      setError("Please enter a valid monthly payment greater than 0")
      return
    }

    const monthlyRate = rate / 100 / 12
    const totalMonths = termYears * 12

    // Calculate original schedule
    let balanceOriginal = principal
    let totalInterestOriginal = 0
    let monthsOriginal = 0

    while (balanceOriginal > 0 && monthsOriginal < totalMonths * 2) {
      const interestPayment = balanceOriginal * monthlyRate
      let principalPayment = payment - interestPayment

      if (principalPayment <= 0) {
        setError("Monthly payment is too low to cover interest. Please increase the payment amount.")
        return
      }

      if (principalPayment > balanceOriginal) {
        principalPayment = balanceOriginal
      }

      totalInterestOriginal += interestPayment
      balanceOriginal -= principalPayment
      monthsOriginal++
    }

    // Calculate schedule with extra payments
    let balanceWithExtra = principal - lumpSumPayment
    if (balanceWithExtra < 0) balanceWithExtra = 0

    let totalInterestWithExtra = 0
    let monthsWithExtra = 0
    const schedule: ScheduleEntry[] = []

    while (balanceWithExtra > 0 && monthsWithExtra < totalMonths * 2) {
      const interestPayment = balanceWithExtra * monthlyRate
      let principalPayment = payment - interestPayment + extraMonthlyPayment

      if (principalPayment > balanceWithExtra) {
        principalPayment = balanceWithExtra
      }

      totalInterestWithExtra += interestPayment
      balanceWithExtra -= principalPayment
      monthsWithExtra++

      schedule.push({
        month: monthsWithExtra,
        payment: payment,
        extraPayment: extraMonthlyPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance: Math.max(0, balanceWithExtra),
      })
    }

    const today = new Date()
    const originalPayoffDate = new Date(today)
    originalPayoffDate.setMonth(originalPayoffDate.getMonth() + monthsOriginal)

    const newPayoffDate = new Date(today)
    newPayoffDate.setMonth(newPayoffDate.getMonth() + monthsWithExtra)

    const monthsSaved = monthsOriginal - monthsWithExtra
    const interestSaved = totalInterestOriginal - totalInterestWithExtra

    setResult({
      originalPayoffDate,
      newPayoffDate,
      monthsSaved,
      totalInterestOriginal,
      totalInterestWithExtra,
      interestSaved,
      totalPaidOriginal: principal + totalInterestOriginal,
      totalPaidWithExtra: principal + totalInterestWithExtra,
      schedule,
    })
  }

  const handleReset = () => {
    setLoanAmount("")
    setInterestRate("")
    setLoanTermYears("")
    setMonthlyPayment("")
    setExtraMonthly("")
    setLumpSum("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSchedule(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Early Loan Payoff Results:
- Interest Saved: $${result.interestSaved.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
- Months Saved: ${result.monthsSaved}
- New Payoff Date: ${result.newPayoffDate.toLocaleDateString()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Early Loan Payoff Calculator Results",
          text: `I can save $${result.interestSaved.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} in interest and pay off my loan ${result.monthsSaved} months earlier!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString(undefined, { year: "numeric", month: "long" })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingDown className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Early Loan Payoff Calculator</CardTitle>
                    <CardDescription>See how extra payments reduce your loan</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Loan Amount */}
                <div className="space-y-2">
                  <Label htmlFor="loanAmount">Loan Amount ($)</Label>
                  <Input
                    id="loanAmount"
                    type="number"
                    placeholder="Enter loan amount"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Enter interest rate"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Loan Term */}
                <div className="space-y-2">
                  <Label htmlFor="loanTermYears">Original Loan Term (years)</Label>
                  <Input
                    id="loanTermYears"
                    type="number"
                    placeholder="Enter loan term in years"
                    value={loanTermYears}
                    onChange={(e) => setLoanTermYears(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Monthly Payment */}
                <div className="space-y-2">
                  <Label htmlFor="monthlyPayment">Monthly Payment ($)</Label>
                  <Input
                    id="monthlyPayment"
                    type="number"
                    placeholder="Enter monthly payment"
                    value={monthlyPayment}
                    onChange={(e) => setMonthlyPayment(e.target.value)}
                    min="0"
                    step="10"
                  />
                </div>

                {/* Extra Monthly Payment */}
                <div className="space-y-2">
                  <Label htmlFor="extraMonthly">Extra Monthly Payment ($) (optional)</Label>
                  <Input
                    id="extraMonthly"
                    type="number"
                    placeholder="Enter extra monthly payment"
                    value={extraMonthly}
                    onChange={(e) => setExtraMonthly(e.target.value)}
                    min="0"
                    step="10"
                  />
                </div>

                {/* Lump Sum Payment */}
                <div className="space-y-2">
                  <Label htmlFor="lumpSum">One-Time Lump Sum Payment ($) (optional)</Label>
                  <Input
                    id="lumpSum"
                    type="number"
                    placeholder="Enter lump sum payment"
                    value={lumpSum}
                    onChange={(e) => setLumpSum(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePayoff} className="w-full" size="lg">
                  Calculate Savings
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Interest Saved</p>
                      <p className="text-4xl font-bold text-green-600">${formatCurrency(result.interestSaved)}</p>
                      <p className="text-lg font-semibold text-green-600 mt-1">
                        {result.monthsSaved} months earlier payoff
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Original Payoff</p>
                        <p className="font-semibold">{formatDate(result.originalPayoffDate)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">New Payoff</p>
                        <p className="font-semibold text-green-600">{formatDate(result.newPayoffDate)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Original Interest</p>
                        <p className="font-semibold">${formatCurrency(result.totalInterestOriginal)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">New Interest</p>
                        <p className="font-semibold text-green-600">${formatCurrency(result.totalInterestWithExtra)}</p>
                      </div>
                    </div>

                    {/* Amortization Schedule */}
                    <Collapsible open={showSchedule} onOpenChange={setShowSchedule} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full bg-transparent">
                          {showSchedule ? (
                            <>
                              <ChevronUp className="h-4 w-4 mr-2" />
                              Hide Amortization Schedule
                            </>
                          ) : (
                            <>
                              <ChevronDown className="h-4 w-4 mr-2" />
                              Show Amortization Schedule
                            </>
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="max-h-64 overflow-y-auto rounded-lg border bg-white">
                          <table className="w-full text-xs">
                            <thead className="bg-muted sticky top-0">
                              <tr>
                                <th className="p-2 text-left">Month</th>
                                <th className="p-2 text-right">Principal</th>
                                <th className="p-2 text-right">Interest</th>
                                <th className="p-2 text-right">Balance</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.schedule.slice(0, 60).map((entry) => (
                                <tr key={entry.month} className="border-t">
                                  <td className="p-2">{entry.month}</td>
                                  <td className="p-2 text-right">${formatCurrency(entry.principal)}</td>
                                  <td className="p-2 text-right">${formatCurrency(entry.interest)}</td>
                                  <td className="p-2 text-right">${formatCurrency(entry.balance)}</td>
                                </tr>
                              ))}
                              {result.schedule.length > 60 && (
                                <tr className="border-t bg-muted/50">
                                  <td colSpan={4} className="p-2 text-center text-muted-foreground">
                                    ... and {result.schedule.length - 60} more months
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Extra Payment Impact</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">$50/month extra</span>
                      <span className="text-sm text-green-600">Saves thousands</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">$100/month extra</span>
                      <span className="text-sm text-green-600">Years off loan</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">$200/month extra</span>
                      <span className="text-sm text-green-600">Major savings</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Lump sum</span>
                      <span className="text-sm text-blue-600">Immediate impact</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Payoff Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Interest = Balance × (Annual Rate ÷ 12)</p>
                  </div>
                  <p>
                    Extra payments go directly toward principal, reducing the balance faster and decreasing total
                    interest paid over the life of the loan.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Early Loan Payoff?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Early loan payoff refers to paying off a loan before its scheduled end date by making additional
                  payments beyond the required minimum. When you make extra payments, the additional amount goes
                  directly toward reducing your principal balance, which in turn reduces the amount of interest you pay
                  over time. This strategy can save you thousands of dollars and help you become debt-free years earlier
                  than originally planned.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The power of early payoff comes from how loan interest is calculated. Since interest is charged on
                  your remaining balance, every dollar you pay toward principal reduces future interest charges. Even
                  small additional payments can compound into significant savings over the life of a loan, especially
                  for long-term loans like mortgages.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How Extra Payments Work</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When you make your regular monthly payment, a portion goes toward interest and the rest toward
                  principal. With extra payments, the entire additional amount goes toward principal reduction. This
                  creates a snowball effect: as your balance decreases faster, less of each future payment goes to
                  interest, accelerating your payoff even more.
                </p>
                <div className="mt-4 grid gap-3">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Extra Monthly Payments</h4>
                    <p className="text-green-700 text-sm">
                      Adding even $50-100 per month to your payment can shave years off your loan and save thousands in
                      interest. This approach is sustainable and fits into most budgets.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Lump Sum Payments</h4>
                    <p className="text-blue-700 text-sm">
                      Using tax refunds, bonuses, or windfalls to make one-time payments can dramatically reduce your
                      balance. A single lump sum early in the loan has the greatest impact.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Early Payoff Success</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">1. Check for Prepayment Penalties</h4>
                    <p className="text-muted-foreground text-sm">
                      Some loans charge fees for paying off early. Review your loan terms before making extra payments.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">2. Specify Principal-Only Payments</h4>
                    <p className="text-muted-foreground text-sm">
                      When making extra payments, ensure they are applied to principal, not future payments.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">3. Prioritize High-Interest Debt</h4>
                    <p className="text-muted-foreground text-sm">
                      If you have multiple loans, focus extra payments on the highest interest rate debt first.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">4. Maintain Emergency Savings</h4>
                    <p className="text-muted-foreground text-sm">
                      Don&apos;t sacrifice your emergency fund for extra loan payments. Financial security comes first.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground text-center">
                  <strong>Disclaimer:</strong> Early loan payoff calculations are estimates and may vary based on
                  interest rates, loan terms, and payment processing. Consult a financial advisor or lender for
                  personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
