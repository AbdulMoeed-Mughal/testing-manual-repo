"use client"

import { useState, useCallback } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Binary,
  Info,
  AlertTriangle,
  BookOpen,
  Calculator,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type LogType = "log10" | "ln" | "custom"
type NotationType = "decimal" | "scientific"

interface LogResult {
  value: number
  formattedValue: string
  scientificValue: string
  steps: string[]
}

export function LogarithmCalculator() {
  const [logType, setLogType] = useState<LogType>("log10")
  const [notation, setNotation] = useState<NotationType>("decimal")
  const [number, setNumber] = useState("")
  const [customBase, setCustomBase] = useState("")
  const [result, setResult] = useState<LogResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateLogarithm = useCallback(() => {
    setError("")
    setResult(null)

    const x = Number.parseFloat(number)
    if (isNaN(x) || x <= 0) {
      setError("Number (x) must be greater than 0")
      return
    }

    let logValue: number
    const steps: string[] = []

    if (logType === "log10") {
      logValue = Math.log10(x)
      steps.push(`log₁₀(${x}) = log(${x}) / log(10)`)
      steps.push(`= ${Math.log(x).toFixed(8)} / ${Math.log(10).toFixed(8)}`)
      steps.push(`= ${logValue.toFixed(8)}`)
    } else if (logType === "ln") {
      logValue = Math.log(x)
      steps.push(`ln(${x}) = logₑ(${x})`)
      steps.push(`Using natural logarithm base e ≈ 2.71828`)
      steps.push(`= ${logValue.toFixed(8)}`)
    } else {
      const b = Number.parseFloat(customBase)
      if (isNaN(b) || b <= 0 || b === 1) {
        setError("Base must be greater than 0 and not equal to 1")
        return
      }
      logValue = Math.log(x) / Math.log(b)
      steps.push(`log_${b}(${x}) = log(${x}) / log(${b})`)
      steps.push(`= ${Math.log(x).toFixed(8)} / ${Math.log(b).toFixed(8)}`)
      steps.push(`= ${logValue.toFixed(8)}`)
    }

    // Format result
    const formattedValue = logValue.toFixed(8).replace(/\.?0+$/, "")
    const scientificValue = logValue.toExponential(6)

    setResult({
      value: logValue,
      formattedValue,
      scientificValue,
      steps,
    })
  }, [number, logType, customBase])

  const handleReset = () => {
    setNumber("")
    setCustomBase("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const displayValue = notation === "decimal" ? result.formattedValue : result.scientificValue
      const baseLabel = logType === "log10" ? "log₁₀" : logType === "ln" ? "ln" : `log_${customBase}`
      await navigator.clipboard.writeText(`${baseLabel}(${number}) = ${displayValue}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const displayValue = notation === "decimal" ? result.formattedValue : result.scientificValue
      const baseLabel = logType === "log10" ? "log₁₀" : logType === "ln" ? "ln" : `log_${customBase}`
      try {
        await navigator.share({
          title: "Logarithm Calculation",
          text: `${baseLabel}(${number}) = ${displayValue}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getLogTypeLabel = () => {
    switch (logType) {
      case "log10":
        return "log₁₀(x)"
      case "ln":
        return "ln(x)"
      case "custom":
        return customBase ? `log_${customBase}(x)` : "log_b(x)"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Binary className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Logarithm Calculator</CardTitle>
                    <CardDescription>Calculate logarithms with any base</CardDescription>
                  </div>
                </div>

                {/* Log Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Logarithm Type</span>
                  <div className="flex rounded-full bg-muted p-1">
                    <button
                      onClick={() => setLogType("log10")}
                      className={`px-3 py-1.5 text-sm font-medium rounded-full transition-colors ${
                        logType === "log10"
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      log
                    </button>
                    <button
                      onClick={() => setLogType("ln")}
                      className={`px-3 py-1.5 text-sm font-medium rounded-full transition-colors ${
                        logType === "ln"
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      ln
                    </button>
                    <button
                      onClick={() => setLogType("custom")}
                      className={`px-3 py-1.5 text-sm font-medium rounded-full transition-colors ${
                        logType === "custom"
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Custom
                    </button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Number Input */}
                <div className="space-y-2">
                  <Label htmlFor="number">Number (x)</Label>
                  <Input
                    id="number"
                    type="number"
                    placeholder="Enter a positive number"
                    value={number}
                    onChange={(e) => setNumber(e.target.value)}
                    min="0"
                    step="any"
                  />
                  <p className="text-xs text-muted-foreground">Must be greater than 0</p>
                </div>

                {/* Custom Base Input */}
                {logType === "custom" && (
                  <div className="space-y-2">
                    <Label htmlFor="base">Base (b)</Label>
                    <Input
                      id="base"
                      type="number"
                      placeholder="Enter base (e.g., 2, 5, 7)"
                      value={customBase}
                      onChange={(e) => setCustomBase(e.target.value)}
                      min="0"
                      step="any"
                    />
                    <p className="text-xs text-muted-foreground">Must be {">"} 0 and ≠ 1</p>
                  </div>
                )}

                {/* Notation Toggle */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Result Format</span>
                  <button
                    onClick={() => setNotation(notation === "decimal" ? "scientific" : "decimal")}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        notation === "scientific" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        notation === "decimal" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Decimal
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        notation === "scientific" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Scientific
                    </span>
                  </button>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLogarithm} className="w-full" size="lg">
                  Calculate Logarithm
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{getLogTypeLabel()}</p>
                      <p className="text-4xl sm:text-5xl font-bold text-blue-600 mb-2 break-all">
                        {notation === "decimal" ? result.formattedValue : result.scientificValue}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {notation === "decimal"
                          ? `Scientific: ${result.scientificValue}`
                          : `Decimal: ${result.formattedValue}`}
                      </p>
                    </div>

                    {/* Show Steps Toggle */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1 mx-auto"
                      >
                        {showSteps ? "Hide" : "Show"} Step-by-Step
                      </button>
                      {showSteps && (
                        <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-1">
                          {result.steps.map((step, index) => (
                            <p key={index} className="font-mono text-muted-foreground">
                              {step}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Logarithm Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700">Common Log (log₁₀)</p>
                      <p className="text-sm text-blue-600 mt-1">Base 10 logarithm, used in science and engineering</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-700">Natural Log (ln)</p>
                      <p className="text-sm text-green-600 mt-1">Base e (≈2.718) logarithm, used in calculus</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-700">Custom Base (log_b)</p>
                      <p className="text-sm text-purple-600 mt-1">Logarithm with any positive base except 1</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="text-sm">
                      <span className="font-semibold">log₁₀(x)</span> = log(x) / log(10)
                    </p>
                    <p className="text-sm">
                      <span className="font-semibold">ln(x)</span> = logₑ(x)
                    </p>
                    <p className="text-sm">
                      <span className="font-semibold">log_b(x)</span> = log(x) / log(b)
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    The change of base formula allows calculating any logarithm using natural or common logs.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Disclaimer</p>
                      <p className="text-sm text-amber-700 mt-1">
                        This calculator provides estimates only. Verify manually for critical calculations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Logarithm?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A logarithm is the inverse operation of exponentiation. In simple terms, the logarithm of a number
                  tells you what exponent you need to raise a base to in order to get that number. For example,
                  log₁₀(100) = 2 because 10² = 100. Logarithms were invented in the early 17th century by John Napier as
                  a way to simplify complex calculations, and they remain fundamental in mathematics, science, and
                  engineering today.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept can be expressed as: if b^y = x, then log_b(x) = y. Here, b is the base, x is the number
                  (also called the argument), and y is the logarithm or exponent. This relationship is the foundation of
                  all logarithmic calculations and explains why logarithms are so useful for solving exponential
                  equations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Logarithms</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  There are three commonly used types of logarithms, each with its own applications. The{" "}
                  <strong>common logarithm</strong> (log₁₀ or simply "log") uses base 10 and is widely used in
                  scientific notation, sound measurement (decibels), earthquake magnitude (Richter scale), and pH
                  calculations in chemistry. Its prevalence in these fields stems from our decimal number system.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The <strong>natural logarithm</strong> (ln) uses Euler's number e (≈2.71828) as its base. This
                  logarithm appears naturally in calculus, particularly in derivatives and integrals involving
                  exponential functions. It's essential in modeling continuous growth processes, compound interest,
                  radioactive decay, and population dynamics. Many natural phenomena follow exponential patterns that
                  are most elegantly described using natural logarithms.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Binary logarithm</strong> (log₂) and other custom-base logarithms have specialized
                  applications. Log₂ is fundamental in computer science for analyzing algorithm complexity and data
                  structures. Any logarithm can be calculated using the change of base formula: log_b(x) = ln(x) /
                  ln(b), making it possible to convert between different bases as needed.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>Properties of Logarithms</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Logarithms follow several important properties that make them powerful tools for simplifying
                  calculations. The <strong>product rule</strong> states that log_b(xy) = log_b(x) + log_b(y), meaning
                  the logarithm of a product equals the sum of logarithms. This property historically allowed
                  multiplication to be performed through addition, which was much easier to compute.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The <strong>quotient rule</strong> states that log_b(x/y) = log_b(x) - log_b(y), converting division
                  into subtraction. The <strong>power rule</strong> says that log_b(x^n) = n × log_b(x), which brings
                  exponents down as multipliers. These properties are invaluable for solving equations, simplifying
                  expressions, and understanding the behavior of exponential functions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding these properties helps in many practical applications: from calculating compound
                  interest and analyzing algorithm efficiency to measuring sound intensity and understanding earthquake
                  magnitudes. Logarithms compress large ranges of values into manageable scales, which is why they're
                  used in so many measurement systems.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Binary className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Logarithms are used extensively in everyday technology and science. In <strong>acoustics</strong>,
                  sound intensity is measured in decibels (dB), which uses a logarithmic scale: a 10 dB increase
                  represents a 10-fold increase in sound power. This allows us to represent the enormous range of human
                  hearing (from a whisper to a jet engine) in a manageable scale.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In <strong>chemistry</strong>, the pH scale measures acidity using the negative logarithm of hydrogen
                  ion concentration: pH = -log₁₀[H⁺]. Each unit change represents a 10-fold change in acidity. In{" "}
                  <strong>seismology</strong>, the Richter scale for earthquake magnitude is logarithmic—each whole
                  number increase represents roughly 31.6 times more energy released.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Computer scientists</strong> use logarithms to analyze algorithm efficiency. Binary search has
                  O(log n) complexity, meaning doubling the data size only adds one more step. In{" "}
                  <strong>finance</strong>, logarithmic returns help analyze investment performance and model price
                  movements. From information theory to signal processing, logarithms remain indispensable mathematical
                  tools.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
