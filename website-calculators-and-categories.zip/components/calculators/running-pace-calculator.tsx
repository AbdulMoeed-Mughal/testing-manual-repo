"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Timer, Info, AlertTriangle, Activity, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type CalculationMode = "pace" | "time"

interface PaceResult {
  pace: string
  paceSeconds: number
  totalTime: string
  speed: string
  caloriesEstimate?: number
  warning?: string
}

export function RunningPaceCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [mode, setMode] = useState<CalculationMode>("pace")
  const [distance, setDistance] = useState("")
  const [hours, setHours] = useState("")
  const [minutes, setMinutes] = useState("")
  const [seconds, setSeconds] = useState("")
  const [paceMinutes, setPaceMinutes] = useState("")
  const [paceSeconds, setPaceSeconds] = useState("")
  const [weight, setWeight] = useState("")
  const [result, setResult] = useState<PaceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatTime = (totalSeconds: number): string => {
    const hrs = Math.floor(totalSeconds / 3600)
    const mins = Math.floor((totalSeconds % 3600) / 60)
    const secs = Math.round(totalSeconds % 60)

    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    }
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const formatPace = (secondsPerUnit: number): string => {
    const mins = Math.floor(secondsPerUnit / 60)
    const secs = Math.round(secondsPerUnit % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const calculateResults = () => {
    setError("")
    setResult(null)

    const distanceNum = Number.parseFloat(distance)
    if (isNaN(distanceNum) || distanceNum <= 0) {
      setError("Please enter a valid distance greater than 0")
      return
    }

    let paceSecondsPerUnit: number
    let totalTimeSeconds: number

    if (mode === "pace") {
      // Calculate pace from distance and time
      const hrs = Number.parseFloat(hours) || 0
      const mins = Number.parseFloat(minutes) || 0
      const secs = Number.parseFloat(seconds) || 0
      totalTimeSeconds = hrs * 3600 + mins * 60 + secs

      if (totalTimeSeconds <= 0) {
        setError("Please enter a valid time greater than 0")
        return
      }

      paceSecondsPerUnit = totalTimeSeconds / distanceNum
    } else {
      // Calculate time from distance and pace
      const paceMins = Number.parseFloat(paceMinutes) || 0
      const paceSecs = Number.parseFloat(paceSeconds) || 0
      paceSecondsPerUnit = paceMins * 60 + paceSecs

      if (paceSecondsPerUnit <= 0) {
        setError("Please enter a valid pace greater than 0")
        return
      }

      totalTimeSeconds = paceSecondsPerUnit * distanceNum
    }

    // Calculate speed
    const distanceInKm = unitSystem === "imperial" ? distanceNum * 1.60934 : distanceNum
    const timeInHours = totalTimeSeconds / 3600
    const speedKmh = distanceInKm / timeInHours
    const speed = unitSystem === "metric" ? `${speedKmh.toFixed(2)} km/h` : `${(speedKmh / 1.60934).toFixed(2)} mph`

    // Calculate calories (optional, if weight provided)
    let caloriesEstimate: number | undefined
    const weightNum = Number.parseFloat(weight)
    if (!isNaN(weightNum) && weightNum > 0) {
      const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum
      // MET value for running varies by speed, using approximate formula
      const met = speedKmh < 8 ? 6 : speedKmh < 10 ? 8.3 : speedKmh < 12 ? 9.8 : speedKmh < 14 ? 11 : 12.8
      caloriesEstimate = Math.round(met * weightKg * timeInHours)
    }

    // Check for unrealistic pace
    let warning: string | undefined
    const paceMinPerKm = unitSystem === "imperial" ? paceSecondsPerUnit / 60 / 1.60934 : paceSecondsPerUnit / 60
    if (paceMinPerKm < 2.5) {
      warning = "This pace is faster than world record speed!"
    } else if (paceMinPerKm > 15) {
      warning = "This pace is quite slow - consider walking calculations"
    }

    setResult({
      pace: formatPace(paceSecondsPerUnit),
      paceSeconds: paceSecondsPerUnit,
      totalTime: formatTime(totalTimeSeconds),
      speed,
      caloriesEstimate,
      warning,
    })
  }

  const handleReset = () => {
    setDistance("")
    setHours("")
    setMinutes("")
    setSeconds("")
    setPaceMinutes("")
    setPaceSeconds("")
    setWeight("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "km" : "mi"
      const paceUnit = unitSystem === "metric" ? "min/km" : "min/mi"
      const text =
        mode === "pace"
          ? `Running ${distance} ${unit} in ${result.totalTime} - Pace: ${result.pace} ${paceUnit} (${result.speed})`
          : `Running ${distance} ${unit} at ${result.pace} ${paceUnit} - Time: ${result.totalTime} (${result.speed})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const unit = unitSystem === "metric" ? "km" : "mi"
      const paceUnit = unitSystem === "metric" ? "min/km" : "min/mi"
      try {
        await navigator.share({
          title: "My Running Pace",
          text: `I calculated my running pace using CalcHub! ${distance} ${unit} - Pace: ${result.pace} ${paceUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setResult(null)
    setError("")
  }

  const toggleMode = () => {
    setMode((prev) => (prev === "pace" ? "time" : "pace"))
    setResult(null)
    setError("")
  }

  const paceUnit = unitSystem === "metric" ? "min/km" : "min/mi"
  const distanceUnit = unitSystem === "metric" ? "km" : "mi"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Timer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Running Pace Calculator</CardTitle>
                    <CardDescription>Calculate pace or finish time</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculate</span>
                  <button
                    onClick={toggleMode}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "time" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "pace" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Pace
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "time" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Time
                    </span>
                  </button>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Distance Input */}
                <div className="space-y-2">
                  <Label htmlFor="distance">Distance ({distanceUnit})</Label>
                  <Input
                    id="distance"
                    type="number"
                    placeholder={`Enter distance in ${distanceUnit === "km" ? "kilometers" : "miles"}`}
                    value={distance}
                    onChange={(e) => setDistance(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {mode === "pace" ? (
                  /* Time Input for Pace Calculation */
                  <div className="space-y-2">
                    <Label>Time (hh:mm:ss)</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Input
                          type="number"
                          placeholder="Hours"
                          value={hours}
                          onChange={(e) => setHours(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Minutes"
                          value={minutes}
                          onChange={(e) => setMinutes(e.target.value)}
                          min="0"
                          max="59"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Seconds"
                          value={seconds}
                          onChange={(e) => setSeconds(e.target.value)}
                          min="0"
                          max="59"
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Pace Input for Time Calculation */
                  <div className="space-y-2">
                    <Label>Pace ({paceUnit})</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Input
                          type="number"
                          placeholder="Minutes"
                          value={paceMinutes}
                          onChange={(e) => setPaceMinutes(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Seconds"
                          value={paceSeconds}
                          onChange={(e) => setPaceSeconds(e.target.value)}
                          min="0"
                          max="59"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Weight Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"}) - Optional</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight for calorie estimate`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateResults} className="w-full" size="lg">
                  {mode === "pace" ? "Calculate Pace" : "Calculate Time"}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    {result.warning && (
                      <div className="flex items-center gap-2 p-2 mb-3 rounded-lg bg-yellow-50 border border-yellow-200 text-yellow-700 text-sm">
                        <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                        {result.warning}
                      </div>
                    )}

                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "pace" ? "Your Pace" : "Estimated Time"}
                      </p>
                      <p className="text-5xl font-bold text-green-600 mb-1">
                        {mode === "pace" ? result.pace : result.totalTime}
                      </p>
                      <p className="text-lg font-medium text-green-600">{mode === "pace" ? paceUnit : ""}</p>
                    </div>

                    {/* Additional Stats */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="text-center p-3 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">{mode === "pace" ? "Total Time" : "Pace"}</p>
                        <p className="text-lg font-semibold text-foreground">
                          {mode === "pace" ? result.totalTime : `${result.pace} ${paceUnit}`}
                        </p>
                      </div>
                      <div className="text-center p-3 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Speed</p>
                        <p className="text-lg font-semibold text-foreground">{result.speed}</p>
                      </div>
                    </div>

                    {result.caloriesEstimate && (
                      <div className="text-center p-3 mt-3 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Estimated Calories Burned</p>
                        <p className="text-lg font-semibold text-orange-600">{result.caloriesEstimate} kcal</p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Race Distances</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">5K</span>
                      <span className="text-sm text-blue-600">5 km / 3.11 mi</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">10K</span>
                      <span className="text-sm text-green-600">10 km / 6.21 mi</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Half Marathon</span>
                      <span className="text-sm text-yellow-600">21.1 km / 13.1 mi</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Marathon</span>
                      <span className="text-sm text-red-600">42.2 km / 26.2 mi</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pace Reference</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Easy/Recovery Run</span>
                      <span className="font-medium">6:00-7:00 min/km</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tempo Run</span>
                      <span className="font-medium">4:30-5:30 min/km</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Race Pace (5K)</span>
                      <span className="font-medium">4:00-5:00 min/km</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sprint/Interval</span>
                      <span className="font-medium">3:00-4:00 min/km</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Pace = Time ÷ Distance</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Speed = Distance ÷ Time</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Running Pace */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Running Pace?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Running pace is a measure of how long it takes you to cover a specific distance, typically expressed
                  as minutes per kilometer (min/km) or minutes per mile (min/mi). Unlike speed, which measures how far
                  you travel in a given time (km/h or mph), pace tells you how much time you need to complete each unit
                  of distance. This metric is fundamental to running because it helps athletes plan their training, set
                  race strategies, and track their progress over time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding your pace is crucial for runners of all levels. For beginners, it helps establish a
                  sustainable running rhythm that prevents early fatigue. For experienced runners, pace data enables
                  precise workout planning, from easy recovery runs to demanding interval sessions. Most runners find
                  that tracking pace is more intuitive than tracking speed because it directly answers the question:
                  "How long will it take me to finish?"
                </p>
              </CardContent>
            </Card>

            {/* Why Pace Matters */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Why Running Pace Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Running pace is essential for race planning and achieving your goals. If you want to finish a marathon
                  in under 4 hours, you need to maintain an average pace of about 5:41 min/km (9:09 min/mi). By knowing
                  your target pace, you can train specifically for that goal, practice maintaining it during long runs,
                  and avoid the common mistake of starting too fast on race day. Many runners have experienced the pain
                  of "hitting the wall" because they didn't respect their pace in the early miles.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Pace also plays a crucial role in training adaptation. Different training paces stress your body in
                  different ways: easy paces build aerobic base and promote recovery, tempo paces improve lactate
                  threshold, and fast interval paces boost VO2 max and running economy. By training at various paces,
                  you develop a complete runner's toolkit. Coaches often prescribe workouts based on percentages of race
                  pace or heart rate zones, making pace awareness fundamental to structured training.
                </p>
              </CardContent>
            </Card>

            {/* Training with Pace Zones */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Training with Pace Zones</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Most training plans divide running into several pace zones, each serving a specific purpose in your
                  fitness development. Recovery runs are performed at 60-70% of your maximum effort, allowing your body
                  to adapt to training stress while minimizing additional fatigue. These easy-paced runs should feel
                  conversational – if you can't talk in complete sentences, you're going too fast.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Easy/Recovery Pace (Zone 1-2)</h4>
                    <p className="text-blue-700 text-sm">
                      Typically 1-2 minutes slower than your race pace. This is where you should spend 70-80% of your
                      training time. It builds aerobic capacity, promotes fat burning, and allows recovery between hard
                      sessions. Most runners make the mistake of running their easy days too fast.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Tempo/Threshold Pace (Zone 3-4)</h4>
                    <p className="text-green-700 text-sm">
                      About 15-30 seconds faster than your marathon pace. This "comfortably hard" effort improves your
                      lactate threshold – the point at which lactic acid accumulates faster than your body can clear it.
                      Tempo runs typically last 20-40 minutes and should feel challenging but sustainable.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Interval/VO2 Max Pace (Zone 5)</h4>
                    <p className="text-orange-700 text-sm">
                      Your 5K race pace or faster. These hard efforts, typically done in intervals of 400m to 1600m,
                      push your cardiovascular system to its limits. They improve your body's ability to deliver and use
                      oxygen, making you faster at all distances. Recovery between intervals is crucial.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips for Improving Pace */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Timer className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Improving Your Running Pace</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Improving your running pace takes time and consistent training. The most effective approach combines
                  several strategies: increasing your weekly mileage gradually (no more than 10% per week),
                  incorporating speed work once or twice weekly, and ensuring adequate recovery between hard sessions.
                  Remember that faster paces are built on a strong aerobic foundation, so don't neglect your easy runs.
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Build your base:</strong> Increase your weekly running volume gradually before adding speed
                    work.
                  </li>
                  <li>
                    <strong>Practice race pace:</strong> Include segments at your goal pace in long runs to build
                    confidence.
                  </li>
                  <li>
                    <strong>Run hills:</strong> Hill training builds strength and improves running economy without the
                    impact of speed work.
                  </li>
                  <li>
                    <strong>Focus on cadence:</strong> Aim for 170-180 steps per minute to improve efficiency.
                  </li>
                  <li>
                    <strong>Recover properly:</strong> Sleep, nutrition, and rest days are when your body adapts to
                    training.
                  </li>
                  <li>
                    <strong>Stay consistent:</strong> Regular training over months and years yields the best results.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-yellow-800 mb-1">Disclaimer</h4>
                    <p className="text-sm text-yellow-700">
                      This calculator provides estimates only. Actual running performance may vary based on fitness
                      level, weather conditions, terrain, elevation changes, and individual factors. Calorie estimates
                      are approximations and may differ from actual energy expenditure. Always consult with a healthcare
                      provider before starting a new exercise program.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
