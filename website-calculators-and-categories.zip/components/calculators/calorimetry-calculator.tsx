"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Flame, Info, AlertTriangle, Thermometer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type MassUnit = "g" | "kg"
type HeatUnit = "J" | "kJ" | "cal"

interface CalorimetryResult {
  heat: number
  heatUnit: string
  type: string
  color: string
  bgColor: string
}

export function CalorimetryCalculator() {
  const [massUnit, setMassUnit] = useState<MassUnit>("g")
  const [heatUnit, setHeatUnit] = useState<HeatUnit>("J")
  const [mass, setMass] = useState("")
  const [specificHeat, setSpecificHeat] = useState("")
  const [tempChange, setTempChange] = useState("")
  const [result, setResult] = useState<CalorimetryResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const massNum = Number.parseFloat(mass)
    const specificHeatNum = Number.parseFloat(specificHeat)
    const tempChangeNum = Number.parseFloat(tempChange)

    if (isNaN(massNum) || massNum <= 0) {
      setError("Please enter a valid mass greater than 0")
      return
    }

    if (isNaN(specificHeatNum) || specificHeatNum <= 0) {
      setError("Please enter a valid specific heat capacity greater than 0")
      return
    }

    if (isNaN(tempChangeNum)) {
      setError("Please enter a valid temperature change")
      return
    }

    // Convert mass to grams if needed
    const massInGrams = massUnit === "kg" ? massNum * 1000 : massNum

    // Calculate heat: q = m × c × ΔT (in Joules when c is in J/g°C)
    let heat = massInGrams * specificHeatNum * tempChangeNum

    // Convert heat to selected unit
    let displayHeat = heat
    let unitLabel = "J"
    
    if (heatUnit === "kJ") {
      displayHeat = heat / 1000
      unitLabel = "kJ"
    } else if (heatUnit === "cal") {
      displayHeat = heat / 4.184
      unitLabel = "cal"
    }

    // Determine if exothermic or endothermic
    const isExothermic = displayHeat < 0
    const type = isExothermic ? "Exothermic (Heat Released)" : displayHeat > 0 ? "Endothermic (Heat Absorbed)" : "No Heat Transfer"
    
    let color: string
    let bgColor: string
    
    if (isExothermic) {
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else if (displayHeat > 0) {
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else {
      color = "text-gray-600"
      bgColor = "bg-gray-50 border-gray-200"
    }

    setResult({
      heat: Math.round(Math.abs(displayHeat) * 1000) / 1000,
      heatUnit: unitLabel,
      type,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setMass("")
    setSpecificHeat("")
    setTempChange("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Heat: ${result.heat} ${result.heatUnit} (${result.type})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Calorimetry Calculation Result",
          text: `Heat: ${result.heat} ${result.heatUnit} (${result.type}) - Calculated with CalcHub`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleMassUnit = () => {
    setMassUnit((prev) => (prev === "g" ? "kg" : "g"))
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Calorimetry Calculator</CardTitle>
                    <CardDescription>Calculate heat transfer in chemical processes</CardDescription>
                  </div>
                </div>

                {/* Mass Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Mass Unit</span>
                  <button
                    onClick={toggleMassUnit}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        massUnit === "kg" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        massUnit === "g" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      g
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        massUnit === "kg" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      kg
                    </span>
                  </button>
                </div>

                {/* Heat Unit Selection */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Heat Unit</span>
                  <div className="flex gap-1">
                    {(["J", "kJ", "cal"] as HeatUnit[]).map((unit) => (
                      <button
                        key={unit}
                        onClick={() => setHeatUnit(unit)}
                        className={`px-3 py-1.5 text-sm font-medium rounded-full transition-colors ${
                          heatUnit === unit
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {unit}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Mass Input */}
                <div className="space-y-2">
                  <Label htmlFor="mass">Mass ({massUnit})</Label>
                  <Input
                    id="mass"
                    type="number"
                    placeholder={`Enter mass in ${massUnit === "g" ? "grams" : "kilograms"}`}
                    value={mass}
                    onChange={(e) => setMass(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Specific Heat Capacity Input */}
                <div className="space-y-2">
                  <Label htmlFor="specificHeat">Specific Heat Capacity (J/g°C)</Label>
                  <Input
                    id="specificHeat"
                    type="number"
                    placeholder="e.g., 4.18 for water"
                    value={specificHeat}
                    onChange={(e) => setSpecificHeat(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Temperature Change Input */}
                <div className="space-y-2">
                  <Label htmlFor="tempChange">Temperature Change (°C)</Label>
                  <Input
                    id="tempChange"
                    type="number"
                    placeholder="Enter temperature change (positive or negative)"
                    value={tempChange}
                    onChange={(e) => setTempChange(e.target.value)}
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Heat
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Heat Transfer</p>
                      <p className={`text-5xl font-bold ${result.color} mb-1`}>{result.heat}</p>
                      <p className={`text-lg ${result.color} mb-2`}>{result.heatUnit}</p>
                      <p className={`text-sm font-semibold ${result.color}`}>{result.type}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Heat Transfer Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Endothermic</span>
                      <span className="text-sm text-blue-600">Heat Absorbed (+q)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Exothermic</span>
                      <span className="text-sm text-red-600">Heat Released (-q)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calorimetry Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">q = m × c × ΔT</p>
                  </div>
                  <p>
                    Where: <strong>q</strong> = heat, <strong>m</strong> = mass, <strong>c</strong> = specific heat capacity, <strong>ΔT</strong> = temperature change
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Specific Heat Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Water (liquid)</span>
                      <span className="font-mono">4.18 J/g°C</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Ice</span>
                      <span className="font-mono">2.09 J/g°C</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Aluminum</span>
                      <span className="font-mono">0.90 J/g°C</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Iron</span>
                      <span className="font-mono">0.45 J/g°C</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Copper</span>
                      <span className="font-mono">0.39 J/g°C</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Content Cards */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Calorimetry?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calorimetry is the science of measuring heat transfer during chemical reactions or physical changes. It is fundamental to thermodynamics and helps us understand how energy is exchanged between systems. The technique is widely used in chemistry, physics, biology, and engineering to study reaction energetics, determine specific heat capacities, and analyze thermal properties of materials.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A calorimeter is the device used to measure these heat changes. Simple calorimeters, like coffee-cup calorimeters, measure heat at constant pressure, while bomb calorimeters measure heat at constant volume. The data obtained from calorimetry experiments is essential for calculating enthalpy changes, reaction heats, and understanding the thermodynamic feasibility of processes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>How Does Heat Transfer Work?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Heat transfer occurs when there is a temperature difference between a system and its surroundings. The fundamental equation q = mcΔT describes sensible heat transfer, where the substance changes temperature without changing phase. The amount of heat transferred depends on three factors: the mass of the substance, its specific heat capacity (the energy required to raise 1 gram by 1°C), and the temperature change.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Endothermic processes absorb heat from surroundings (positive q), causing the surroundings to cool. Examples include melting ice and evaporating water. Exothermic processes release heat to surroundings (negative q), causing them to warm up. Combustion reactions and neutralization reactions are common exothermic processes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Calorimetry</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calorimetry has numerous practical applications across various fields. In food science, it determines the caloric content of foods by measuring the heat released during combustion. In pharmaceutical research, it helps study drug stability and interactions. In materials science, calorimetry characterizes thermal properties of new materials and polymers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Environmental scientists use calorimetry to study reaction kinetics and energy flows in ecosystems. In industry, it optimizes manufacturing processes by understanding heat requirements for chemical reactions. Biochemists use isothermal titration calorimetry to study protein-ligand binding and enzyme kinetics, providing crucial data for drug development.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations and Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator assumes ideal conditions with no heat loss to the surroundings. In real experiments, some heat is always lost to the calorimeter walls, air, and other components. Professional calorimeters are designed to minimize these losses, but perfect insulation is impossible to achieve.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The calculator does not account for phase changes (melting, boiling, sublimation), which require additional enthalpy terms. For accurate experimental results, proper calibration and heat capacity corrections for the calorimeter itself must be applied. Always consult appropriate references and laboratory protocols for precise scientific measurements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
