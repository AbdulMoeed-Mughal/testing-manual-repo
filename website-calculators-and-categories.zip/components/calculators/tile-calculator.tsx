"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Grid3X3, Info, AlertTriangle, Layers } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type AreaType = "floor" | "wall"
type LayoutType = "straight" | "diagonal"

interface TileResult {
  totalArea: number
  tileArea: number
  tilesNeeded: number
  tilesWithWaste: number
  boxesNeeded: number | null
  wasteTiles: number
}

export function TileCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [areaType, setAreaType] = useState<AreaType>("floor")
  const [layoutType, setLayoutType] = useState<LayoutType>("straight")
  const [areaLength, setAreaLength] = useState("")
  const [areaWidth, setAreaWidth] = useState("")
  const [tileLength, setTileLength] = useState("")
  const [tileWidth, setTileWidth] = useState("")
  const [groutGap, setGroutGap] = useState("3")
  const [wastePercent, setWastePercent] = useState("10")
  const [tilesPerBox, setTilesPerBox] = useState("")
  const [result, setResult] = useState<TileResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateTiles = () => {
    setError("")
    setResult(null)

    const length = Number.parseFloat(areaLength)
    const width = Number.parseFloat(areaWidth)
    const tileLengthNum = Number.parseFloat(tileLength)
    const tileWidthNum = Number.parseFloat(tileWidth)
    const grout = Number.parseFloat(groutGap) || 0
    const waste = Number.parseFloat(wastePercent) || 10
    const perBox = Number.parseFloat(tilesPerBox) || 0

    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid area length greater than 0")
      return
    }
    if (isNaN(width) || width <= 0) {
      setError("Please enter a valid area width/height greater than 0")
      return
    }
    if (isNaN(tileLengthNum) || tileLengthNum <= 0) {
      setError("Please enter a valid tile length greater than 0")
      return
    }
    if (isNaN(tileWidthNum) || tileWidthNum <= 0) {
      setError("Please enter a valid tile width greater than 0")
      return
    }

    // Convert tile dimensions to area units (cm to m for metric, inches to feet for imperial)
    const tileLengthInAreaUnits = unitSystem === "metric" ? tileLengthNum / 100 : tileLengthNum / 12
    const tileWidthInAreaUnits = unitSystem === "metric" ? tileWidthNum / 100 : tileWidthNum / 12
    const groutInAreaUnits = unitSystem === "metric" ? grout / 1000 : grout / 12

    // Calculate areas
    const totalArea = length * width
    const effectiveTileLength = tileLengthInAreaUnits + groutInAreaUnits
    const effectiveTileWidth = tileWidthInAreaUnits + groutInAreaUnits
    const tileArea = effectiveTileLength * effectiveTileWidth

    // Calculate tiles needed
    const tilesNeeded = Math.ceil(totalArea / tileArea)

    // Add extra waste for diagonal layout (typically 15% more)
    let effectiveWaste = waste
    if (layoutType === "diagonal") {
      effectiveWaste = Math.max(waste, 15) // Diagonal needs at least 15% waste
    }

    const wasteTiles = Math.ceil(tilesNeeded * (effectiveWaste / 100))
    const tilesWithWaste = tilesNeeded + wasteTiles

    // Calculate boxes needed
    const boxesNeeded = perBox > 0 ? Math.ceil(tilesWithWaste / perBox) : null

    setResult({
      totalArea,
      tileArea: tileLengthInAreaUnits * tileWidthInAreaUnits,
      tilesNeeded,
      tilesWithWaste,
      boxesNeeded,
      wasteTiles,
    })
  }

  const handleReset = () => {
    setAreaLength("")
    setAreaWidth("")
    setTileLength("")
    setTileWidth("")
    setGroutGap("3")
    setWastePercent("10")
    setTilesPerBox("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Tile Calculation: ${result.tilesWithWaste} tiles needed for ${result.totalArea.toFixed(2)} ${unitSystem === "metric" ? "m²" : "ft²"} (includes ${wastePercent}% waste)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setAreaLength("")
    setAreaWidth("")
    setTileLength("")
    setTileWidth("")
    setGroutGap(unitSystem === "metric" ? "0.125" : "3")
    setResult(null)
    setError("")
  }

  const areaUnit = unitSystem === "metric" ? "m" : "ft"
  const tileUnit = unitSystem === "metric" ? "cm" : "in"
  const groutUnit = unitSystem === "metric" ? "mm" : "in"
  const areaUnitSq = unitSystem === "metric" ? "m²" : "ft²"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <Grid3X3 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Tile Calculator</CardTitle>
                    <CardDescription>Calculate tiles for floor or wall</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Area Type Selection */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Area Type</Label>
                    <Select value={areaType} onValueChange={(v) => setAreaType(v as AreaType)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="floor">Floor</SelectItem>
                        <SelectItem value="wall">Wall</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Layout Type</Label>
                    <Select value={layoutType} onValueChange={(v) => setLayoutType(v as LayoutType)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="straight">Straight</SelectItem>
                        <SelectItem value="diagonal">Diagonal (45°)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Area Dimensions */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">{areaType === "floor" ? "Floor" : "Wall"} Dimensions</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder={`Length (${areaUnit})`}
                        value={areaLength}
                        onChange={(e) => setAreaLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder={areaType === "floor" ? `Width (${areaUnit})` : `Height (${areaUnit})`}
                        value={areaWidth}
                        onChange={(e) => setAreaWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                </div>

                {/* Tile Dimensions */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Tile Dimensions</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder={`Length (${tileUnit})`}
                        value={tileLength}
                        onChange={(e) => setTileLength(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder={`Width (${tileUnit})`}
                        value={tileWidth}
                        onChange={(e) => setTileWidth(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                </div>

                {/* Grout Gap and Waste */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="grout">Grout Gap ({groutUnit})</Label>
                    <Input
                      id="grout"
                      type="number"
                      placeholder={unitSystem === "metric" ? "3" : "0.125"}
                      value={groutGap}
                      onChange={(e) => setGroutGap(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="waste">Waste (%)</Label>
                    <Input
                      id="waste"
                      type="number"
                      placeholder="10"
                      value={wastePercent}
                      onChange={(e) => setWastePercent(e.target.value)}
                      min="0"
                      max="50"
                      step="1"
                    />
                  </div>
                </div>

                {/* Tiles Per Box (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="tilesPerBox">Tiles Per Box (optional)</Label>
                  <Input
                    id="tilesPerBox"
                    type="number"
                    placeholder="Enter tiles per box for box count"
                    value={tilesPerBox}
                    onChange={(e) => setTilesPerBox(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTiles} className="w-full" size="lg">
                  Calculate Tiles
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-yellow-50 border-yellow-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Tiles Required (with waste)</p>
                      <p className="text-5xl font-bold text-yellow-600 mb-2">{result.tilesWithWaste}</p>
                      <p className="text-sm text-muted-foreground">
                        {result.tilesNeeded} tiles + {result.wasteTiles} waste ({wastePercent}%)
                      </p>
                      {result.boxesNeeded && (
                        <p className="text-lg font-semibold text-yellow-700 mt-2">
                          {result.boxesNeeded} {result.boxesNeeded === 1 ? "box" : "boxes"} needed
                        </p>
                      )}
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-muted-foreground">Total Area</p>
                        <p className="font-semibold">
                          {result.totalArea.toFixed(2)} {areaUnitSq}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-muted-foreground">Tile Area</p>
                        <p className="font-semibold">
                          {(result.tileArea * 10000).toFixed(0)} {unitSystem === "metric" ? "cm²" : "in²"}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step toggle */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-yellow-700"
                    >
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg border text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Total Area = {areaLength} × {areaWidth} ={" "}
                          {result.totalArea.toFixed(2)} {areaUnitSq}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Effective Tile = ({tileLength} + grout) × ({tileWidth} + grout)
                        </p>
                        <p>
                          <strong>Step 3:</strong> Tiles Needed = {result.totalArea.toFixed(2)} ÷{" "}
                          {result.tileArea.toFixed(4)} ≈ {result.tilesNeeded}
                        </p>
                        <p>
                          <strong>Step 4:</strong> Waste = {result.tilesNeeded} × {wastePercent}% = {result.wasteTiles}{" "}
                          tiles
                        </p>
                        <p>
                          <strong>Step 5:</strong> Total = {result.tilesNeeded} + {result.wasteTiles} ={" "}
                          {result.tilesWithWaste} tiles
                        </p>
                        {layoutType === "diagonal" && (
                          <p className="text-yellow-600">
                            <strong>Note:</strong> Diagonal layout requires extra waste for cutting
                          </p>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tile Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Total Area</p>
                    <p className="font-mono text-sm">Area = Length × Width</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Tiles Required</p>
                    <p className="font-mono text-sm">Tiles = Area ÷ Tile Area</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">With Waste</p>
                    <p className="font-mono text-sm">Total = Tiles × (1 + Waste%)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Tile Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Small</span>
                      <span className="font-mono">30 × 30 cm (12 × 12 in)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Medium</span>
                      <span className="font-mono">45 × 45 cm (18 × 18 in)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Large</span>
                      <span className="font-mono">60 × 60 cm (24 × 24 in)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Subway</span>
                      <span className="font-mono">10 × 20 cm (4 × 8 in)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual tile requirements may vary based on cutting, layout patterns, and
                        room irregularities. Always order extra tiles.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Tile Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating the correct number of tiles for your project is essential for budgeting and ensuring you
                  have enough materials. The basic principle is simple: divide the total area to be covered by the area
                  of a single tile. However, several factors can affect the actual number of tiles needed, including
                  grout spacing, layout pattern, and cutting waste.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Always account for waste when ordering tiles. For straight layouts, a 10% waste allowance is typical,
                  while diagonal or herringbone patterns may require 15-20% extra due to increased cutting. Rooms with
                  many corners, obstacles, or irregular shapes will also need additional tiles.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Layout Patterns</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Straight Layout</h4>
                    <p className="text-green-700 text-sm">
                      The most common and economical pattern. Tiles are laid in a grid pattern with edges parallel to
                      the walls. Requires less cutting and typically 5-10% waste allowance.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Diagonal Layout (45°)</h4>
                    <p className="text-blue-700 text-sm">
                      Tiles are rotated 45° creating a diamond pattern. More visually interesting but requires more cuts
                      along walls. Plan for 15-20% waste allowance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Grid3X3 className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Measure twice:</strong> Always double-check your room measurements before ordering tiles.
                  </li>
                  <li>
                    <strong>Account for grout:</strong> Grout lines add to the effective size of each tile, slightly
                    reducing the number needed.
                  </li>
                  <li>
                    <strong>Consider obstacles:</strong> Toilets, cabinets, and other fixtures affect tile layout and
                    cutting requirements.
                  </li>
                  <li>
                    <strong>Buy extra:</strong> Always order 10-15% more tiles than calculated. Keep extras for future
                    repairs.
                  </li>
                  <li>
                    <strong>Same batch:</strong> Ensure all tiles come from the same production batch to avoid color
                    variations.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
