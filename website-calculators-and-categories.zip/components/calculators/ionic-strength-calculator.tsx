"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Beaker, Info, AlertTriangle, Atom, Plus, Trash2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface Ion {
  id: number
  name: string
  concentration: string
  charge: string
}

interface IonicStrengthResult {
  value: number
  classification: string
  color: string
  bgColor: string
  contributions: { name: string; contribution: number; percentage: number }[]
}

export function IonicStrengthCalculator() {
  const [ions, setIons] = useState<Ion[]>([
    { id: 1, name: "Na⁺", concentration: "", charge: "1" },
    { id: 2, name: "Cl⁻", concentration: "", charge: "-1" },
  ])
  const [result, setResult] = useState<IonicStrengthResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [nextId, setNextId] = useState(3)

  const addIon = () => {
    setIons([...ions, { id: nextId, name: "", concentration: "", charge: "" }])
    setNextId(nextId + 1)
  }

  const removeIon = (id: number) => {
    if (ions.length > 1) {
      setIons(ions.filter((ion) => ion.id !== id))
    }
  }

  const updateIon = (id: number, field: keyof Ion, value: string) => {
    setIons(ions.map((ion) => (ion.id === id ? { ...ion, [field]: value } : ion)))
  }

  const calculateIonicStrength = () => {
    setError("")
    setResult(null)

    // Validate inputs
    const validIons: { name: string; concentration: number; charge: number }[] = []

    for (const ion of ions) {
      const conc = Number.parseFloat(ion.concentration)
      const charge = Number.parseInt(ion.charge)

      if (ion.concentration === "" || ion.charge === "") {
        setError("Please fill in all concentration and charge fields")
        return
      }

      if (isNaN(conc) || conc < 0) {
        setError("Concentrations must be non-negative numbers")
        return
      }

      if (isNaN(charge)) {
        setError("Charges must be integers")
        return
      }

      validIons.push({
        name: ion.name || `Ion ${ion.id}`,
        concentration: conc,
        charge: charge,
      })
    }

    if (validIons.length === 0) {
      setError("Please add at least one ion")
      return
    }

    // Calculate ionic strength: I = 0.5 × Σ(Cᵢ × zᵢ²)
    let totalIonicStrength = 0
    const contributions: { name: string; contribution: number; percentage: number }[] = []

    for (const ion of validIons) {
      const contribution = ion.concentration * Math.pow(ion.charge, 2)
      totalIonicStrength += contribution
      contributions.push({
        name: ion.name,
        contribution: contribution,
        percentage: 0,
      })
    }

    const ionicStrength = 0.5 * totalIonicStrength

    // Calculate percentages
    if (totalIonicStrength > 0) {
      for (const contrib of contributions) {
        contrib.percentage = (contrib.contribution / totalIonicStrength) * 100
      }
    }

    // Classify ionic strength
    let classification: string
    let color: string
    let bgColor: string

    if (ionicStrength < 0.01) {
      classification = "Very Low"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (ionicStrength < 0.1) {
      classification = "Low"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (ionicStrength < 0.5) {
      classification = "Medium"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      classification = "High"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      value: ionicStrength,
      classification,
      color,
      bgColor,
      contributions,
    })
  }

  const handleReset = () => {
    setIons([
      { id: 1, name: "Na⁺", concentration: "", charge: "1" },
      { id: 2, name: "Cl⁻", concentration: "", charge: "-1" },
    ])
    setNextId(3)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const contributionText = result.contributions
        .map((c) => `${c.name}: ${c.percentage.toFixed(1)}%`)
        .join(", ")
      await navigator.clipboard.writeText(
        `Ionic Strength: ${result.value.toExponential(4)} M (${result.classification}). Contributions: ${contributionText}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Ionic Strength Calculation",
          text: `I calculated the ionic strength using CalcHub! Ionic Strength: ${result.value.toExponential(4)} M (${result.classification})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (num < 0.0001 || num >= 10000) {
      return num.toExponential(4)
    }
    return num.toFixed(6).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Beaker className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Ionic Strength Calculator</CardTitle>
                    <CardDescription>Calculate the ionic strength of a solution</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Ion Inputs */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-medium">Ions in Solution</Label>
                    <Button variant="outline" size="sm" onClick={addIon}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Ion
                    </Button>
                  </div>

                  {ions.map((ion, index) => (
                    <div key={ion.id} className="p-3 bg-muted/50 rounded-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-muted-foreground">Ion {index + 1}</span>
                        {ions.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeIon(ion.id)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <Label className="text-xs">Name (optional)</Label>
                          <Input
                            type="text"
                            placeholder="e.g., Na⁺"
                            value={ion.name}
                            onChange={(e) => updateIon(ion.id, "name", e.target.value)}
                            className="h-9"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Conc. (mol/L)</Label>
                          <Input
                            type="number"
                            placeholder="0.1"
                            value={ion.concentration}
                            onChange={(e) => updateIon(ion.id, "concentration", e.target.value)}
                            min="0"
                            step="0.001"
                            className="h-9"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Charge (z)</Label>
                          <Input
                            type="number"
                            placeholder="1 or -1"
                            value={ion.charge}
                            onChange={(e) => updateIon(ion.id, "charge", e.target.value)}
                            className="h-9"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateIonicStrength} className="w-full" size="lg">
                  Calculate Ionic Strength
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Ionic Strength (I)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{formatNumber(result.value)}</p>
                      <p className="text-sm text-muted-foreground mb-2">mol/L</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.classification}</p>
                    </div>

                    {/* Ion Contributions */}
                    {result.contributions.length > 0 && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg">
                        <p className="text-sm font-medium mb-2 text-center">Ion Contributions</p>
                        <div className="space-y-1">
                          {result.contributions.map((contrib, idx) => (
                            <div key={idx} className="flex justify-between text-sm">
                              <span>{contrib.name}</span>
                              <span className="font-mono">{contrib.percentage.toFixed(1)}%</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Ionic Strength Classification</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Very Low</span>
                      <span className="text-sm text-blue-600">{"< 0.01 M"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low</span>
                      <span className="text-sm text-green-600">0.01 – 0.1 M</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Medium</span>
                      <span className="text-sm text-yellow-600">0.1 – 0.5 M</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">High</span>
                      <span className="text-sm text-red-600">≥ 0.5 M</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Ionic Strength Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">I = ½ × Σ(Cᵢ × zᵢ²)</p>
                  </div>
                  <p>
                    Where <strong>Cᵢ</strong> is the molar concentration of ion i and <strong>zᵢ</strong> is its charge number.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Ionic Strength */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Ionic Strength?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ionic strength is a measure of the total concentration of ions in a solution, weighted by the square of 
                  their charges. It was introduced by Gilbert N. Lewis and Merle Randall in 1921 and has become a fundamental 
                  concept in solution chemistry. Unlike simple concentration, ionic strength accounts for the fact that 
                  highly charged ions have a greater effect on the properties of a solution than singly charged ions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The ionic strength of a solution directly influences many physical and chemical properties, including 
                  activity coefficients, solubility of ionic compounds, reaction rates, and the stability of colloids and 
                  proteins. Understanding ionic strength is essential in fields ranging from analytical chemistry and 
                  biochemistry to environmental science and industrial processes.
                </p>
              </CardContent>
            </Card>

            {/* How Ionic Strength is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>How is Ionic Strength Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The ionic strength calculation involves summing the contribution of each ion in solution. For each ion, 
                  you multiply its molar concentration by the square of its charge, then add all these values together 
                  and divide by 2. The squaring of the charge means that a divalent ion (charge ±2) contributes four times 
                  as much to ionic strength as a monovalent ion (charge ±1) at the same concentration.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, in a 0.1 M NaCl solution, Na⁺ contributes 0.1 × 1² = 0.1, and Cl⁻ contributes 0.1 × 1² = 0.1, 
                  giving a total of 0.2. The ionic strength is therefore I = 0.5 × 0.2 = 0.1 M. For a 0.1 M CaCl₂ solution, 
                  Ca²⁺ contributes 0.1 × 2² = 0.4, and the two Cl⁻ ions contribute 0.2 × 1² = 0.2, giving I = 0.5 × 0.6 = 0.3 M.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Ionic Strength</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ionic strength plays a crucial role in determining activity coefficients, which describe how ions in 
                  solution deviate from ideal behavior. The Debye-Hückel theory and its extensions use ionic strength to 
                  calculate activity coefficients, which are essential for accurate equilibrium calculations, pH measurements, 
                  and understanding reaction kinetics in electrolyte solutions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In biochemistry, ionic strength affects protein stability, enzyme activity, and the behavior of nucleic 
                  acids. Many biological assays and buffers are prepared at specific ionic strengths to ensure reproducible 
                  results. In environmental chemistry, ionic strength influences the solubility and mobility of pollutants 
                  in groundwater and soil. Industrial applications include electroplating, water treatment, and the 
                  formulation of pharmaceuticals and personal care products.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations and Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ionic strength calculations assume that all ions are fully dissociated and behave independently, which 
                  is valid only for dilute solutions (typically I less than 0.1 M). At higher concentrations, ion pairing 
                  and other interactions become significant, and the simple ionic strength formula may not accurately 
                  represent the solution's behavior.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Debye-Hückel limiting law, which relates ionic strength to activity coefficients, is only accurate 
                  at very low ionic strengths. For more concentrated solutions, extended Debye-Hückel equations or the 
                  Pitzer equations may be needed. Additionally, ionic strength calculations do not account for specific 
                  ion effects (Hofmeister series), which can significantly influence protein behavior and colloidal stability.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Note:</strong> Ionic strength calculations assume ideal behavior. Real solutions may deviate 
                    due to activity coefficients and interionic interactions, especially at concentrations above 0.1 M.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
