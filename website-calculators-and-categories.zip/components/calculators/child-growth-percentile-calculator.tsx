"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Baby,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Ruler,
  Scale,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type GrowthStandard = "who" | "cdc"
type AgeUnit = "months" | "years"

interface GrowthResult {
  heightPercentile: number
  weightPercentile: number
  bmiPercentile: number | null
  bmi: number | null
  heightCategory: string
  weightCategory: string
  bmiCategory: string | null
  heightColor: string
  weightColor: string
  bmiColor: string | null
}

// WHO/CDC Growth Chart Data (simplified LMS values for percentile calculation)
// These are approximated reference values based on WHO growth standards
const growthData = {
  who: {
    male: {
      height: [
        { age: 0, L: 1, M: 49.9, S: 0.0379 },
        { age: 3, L: 1, M: 61.4, S: 0.0332 },
        { age: 6, L: 1, M: 67.6, S: 0.0311 },
        { age: 12, L: 1, M: 75.7, S: 0.0293 },
        { age: 24, L: 1, M: 87.8, S: 0.0387 },
        { age: 36, L: 1, M: 96.1, S: 0.0399 },
        { age: 48, L: 1, M: 103.3, S: 0.0407 },
        { age: 60, L: 1, M: 110.0, S: 0.0412 },
        { age: 72, L: 1, M: 116.0, S: 0.0416 },
        { age: 84, L: 1, M: 121.7, S: 0.0419 },
        { age: 96, L: 1, M: 127.3, S: 0.0422 },
        { age: 108, L: 1, M: 132.6, S: 0.0425 },
        { age: 120, L: 1, M: 137.8, S: 0.0427 },
        { age: 132, L: 1, M: 143.5, S: 0.043 },
        { age: 144, L: 1, M: 149.8, S: 0.0435 },
        { age: 156, L: 1, M: 156.5, S: 0.044 },
        { age: 168, L: 1, M: 163.2, S: 0.0445 },
        { age: 180, L: 1, M: 169.0, S: 0.0448 },
        { age: 192, L: 1, M: 173.5, S: 0.045 },
        { age: 204, L: 1, M: 176.0, S: 0.0451 },
        { age: 216, L: 1, M: 177.0, S: 0.0452 },
      ],
      weight: [
        { age: 0, L: 0.35, M: 3.3, S: 0.14 },
        { age: 3, L: 0.23, M: 6.4, S: 0.12 },
        { age: 6, L: 0.17, M: 7.9, S: 0.11 },
        { age: 12, L: 0.08, M: 9.6, S: 0.11 },
        { age: 24, L: -0.05, M: 12.2, S: 0.11 },
        { age: 36, L: -0.13, M: 14.3, S: 0.11 },
        { age: 48, L: -0.18, M: 16.3, S: 0.12 },
        { age: 60, L: -0.22, M: 18.3, S: 0.12 },
        { age: 72, L: -0.25, M: 20.5, S: 0.13 },
        { age: 84, L: -0.27, M: 22.9, S: 0.13 },
        { age: 96, L: -0.29, M: 25.6, S: 0.14 },
        { age: 108, L: -0.3, M: 28.6, S: 0.15 },
        { age: 120, L: -0.31, M: 31.9, S: 0.15 },
        { age: 132, L: -0.32, M: 35.6, S: 0.16 },
        { age: 144, L: -0.32, M: 40.0, S: 0.16 },
        { age: 156, L: -0.32, M: 45.3, S: 0.16 },
        { age: 168, L: -0.31, M: 51.0, S: 0.16 },
        { age: 180, L: -0.3, M: 56.7, S: 0.15 },
        { age: 192, L: -0.28, M: 61.5, S: 0.14 },
        { age: 204, L: -0.26, M: 65.0, S: 0.13 },
        { age: 216, L: -0.24, M: 68.0, S: 0.13 },
      ],
    },
    female: {
      height: [
        { age: 0, L: 1, M: 49.1, S: 0.0379 },
        { age: 3, L: 1, M: 59.8, S: 0.0352 },
        { age: 6, L: 1, M: 65.7, S: 0.0329 },
        { age: 12, L: 1, M: 74.0, S: 0.0307 },
        { age: 24, L: 1, M: 86.4, S: 0.0396 },
        { age: 36, L: 1, M: 95.1, S: 0.0407 },
        { age: 48, L: 1, M: 102.7, S: 0.0413 },
        { age: 60, L: 1, M: 109.4, S: 0.0417 },
        { age: 72, L: 1, M: 115.5, S: 0.042 },
        { age: 84, L: 1, M: 121.1, S: 0.0422 },
        { age: 96, L: 1, M: 126.6, S: 0.0424 },
        { age: 108, L: 1, M: 132.2, S: 0.0426 },
        { age: 120, L: 1, M: 138.0, S: 0.0428 },
        { age: 132, L: 1, M: 144.5, S: 0.043 },
        { age: 144, L: 1, M: 151.0, S: 0.0432 },
        { age: 156, L: 1, M: 156.5, S: 0.0433 },
        { age: 168, L: 1, M: 160.0, S: 0.0434 },
        { age: 180, L: 1, M: 162.0, S: 0.0434 },
        { age: 192, L: 1, M: 163.0, S: 0.0434 },
        { age: 204, L: 1, M: 163.5, S: 0.0434 },
        { age: 216, L: 1, M: 164.0, S: 0.0434 },
      ],
      weight: [
        { age: 0, L: 0.35, M: 3.2, S: 0.14 },
        { age: 3, L: 0.23, M: 5.8, S: 0.12 },
        { age: 6, L: 0.17, M: 7.3, S: 0.11 },
        { age: 12, L: 0.08, M: 8.9, S: 0.11 },
        { age: 24, L: -0.05, M: 11.5, S: 0.11 },
        { age: 36, L: -0.13, M: 13.9, S: 0.12 },
        { age: 48, L: -0.18, M: 16.1, S: 0.12 },
        { age: 60, L: -0.22, M: 18.2, S: 0.13 },
        { age: 72, L: -0.25, M: 20.5, S: 0.13 },
        { age: 84, L: -0.27, M: 23.0, S: 0.14 },
        { age: 96, L: -0.29, M: 25.8, S: 0.15 },
        { age: 108, L: -0.3, M: 29.0, S: 0.16 },
        { age: 120, L: -0.31, M: 32.5, S: 0.16 },
        { age: 132, L: -0.32, M: 36.9, S: 0.17 },
        { age: 144, L: -0.32, M: 41.5, S: 0.17 },
        { age: 156, L: -0.32, M: 46.0, S: 0.17 },
        { age: 168, L: -0.31, M: 50.0, S: 0.16 },
        { age: 180, L: -0.3, M: 53.5, S: 0.16 },
        { age: 192, L: -0.28, M: 56.0, S: 0.15 },
        { age: 204, L: -0.26, M: 57.5, S: 0.15 },
        { age: 216, L: -0.24, M: 58.5, S: 0.15 },
      ],
    },
  },
  cdc: {
    male: {
      height: [
        { age: 24, L: 1, M: 86.5, S: 0.041 },
        { age: 36, L: 1, M: 95.3, S: 0.042 },
        { age: 48, L: 1, M: 102.9, S: 0.043 },
        { age: 60, L: 1, M: 109.9, S: 0.044 },
        { age: 72, L: 1, M: 116.1, S: 0.044 },
        { age: 84, L: 1, M: 122.0, S: 0.045 },
        { age: 96, L: 1, M: 127.7, S: 0.045 },
        { age: 108, L: 1, M: 133.0, S: 0.046 },
        { age: 120, L: 1, M: 138.3, S: 0.046 },
        { age: 132, L: 1, M: 143.8, S: 0.047 },
        { age: 144, L: 1, M: 150.3, S: 0.047 },
        { age: 156, L: 1, M: 157.3, S: 0.048 },
        { age: 168, L: 1, M: 164.3, S: 0.048 },
        { age: 180, L: 1, M: 170.0, S: 0.048 },
        { age: 192, L: 1, M: 174.0, S: 0.047 },
        { age: 204, L: 1, M: 176.5, S: 0.046 },
        { age: 216, L: 1, M: 177.5, S: 0.046 },
        { age: 228, L: 1, M: 178.0, S: 0.045 },
        { age: 240, L: 1, M: 178.3, S: 0.045 },
      ],
      weight: [
        { age: 24, L: -0.16, M: 12.3, S: 0.11 },
        { age: 36, L: -0.21, M: 14.3, S: 0.11 },
        { age: 48, L: -0.25, M: 16.2, S: 0.12 },
        { age: 60, L: -0.28, M: 18.3, S: 0.12 },
        { age: 72, L: -0.3, M: 20.7, S: 0.13 },
        { age: 84, L: -0.32, M: 23.1, S: 0.14 },
        { age: 96, L: -0.33, M: 26.0, S: 0.15 },
        { age: 108, L: -0.34, M: 29.2, S: 0.16 },
        { age: 120, L: -0.34, M: 32.9, S: 0.17 },
        { age: 132, L: -0.34, M: 37.0, S: 0.18 },
        { age: 144, L: -0.34, M: 41.7, S: 0.19 },
        { age: 156, L: -0.33, M: 47.2, S: 0.19 },
        { age: 168, L: -0.32, M: 53.2, S: 0.19 },
        { age: 180, L: -0.3, M: 59.1, S: 0.18 },
        { age: 192, L: -0.28, M: 64.2, S: 0.17 },
        { age: 204, L: -0.26, M: 68.0, S: 0.16 },
        { age: 216, L: -0.24, M: 70.5, S: 0.15 },
        { age: 228, L: -0.22, M: 72.0, S: 0.14 },
        { age: 240, L: -0.2, M: 73.0, S: 0.14 },
      ],
    },
    female: {
      height: [
        { age: 24, L: 1, M: 85.0, S: 0.042 },
        { age: 36, L: 1, M: 94.1, S: 0.043 },
        { age: 48, L: 1, M: 101.6, S: 0.044 },
        { age: 60, L: 1, M: 108.4, S: 0.044 },
        { age: 72, L: 1, M: 114.6, S: 0.045 },
        { age: 84, L: 1, M: 120.4, S: 0.045 },
        { age: 96, L: 1, M: 126.0, S: 0.046 },
        { age: 108, L: 1, M: 131.6, S: 0.046 },
        { age: 120, L: 1, M: 137.5, S: 0.047 },
        { age: 132, L: 1, M: 144.0, S: 0.047 },
        { age: 144, L: 1, M: 150.8, S: 0.047 },
        { age: 156, L: 1, M: 156.6, S: 0.046 },
        { age: 168, L: 1, M: 160.5, S: 0.045 },
        { age: 180, L: 1, M: 162.5, S: 0.044 },
        { age: 192, L: 1, M: 163.5, S: 0.044 },
        { age: 204, L: 1, M: 164.0, S: 0.044 },
        { age: 216, L: 1, M: 164.2, S: 0.044 },
        { age: 228, L: 1, M: 164.3, S: 0.044 },
        { age: 240, L: 1, M: 164.4, S: 0.044 },
      ],
      weight: [
        { age: 24, L: -0.16, M: 11.8, S: 0.12 },
        { age: 36, L: -0.21, M: 13.9, S: 0.12 },
        { age: 48, L: -0.25, M: 16.0, S: 0.13 },
        { age: 60, L: -0.28, M: 18.2, S: 0.14 },
        { age: 72, L: -0.3, M: 20.6, S: 0.14 },
        { age: 84, L: -0.32, M: 23.3, S: 0.15 },
        { age: 96, L: -0.33, M: 26.3, S: 0.16 },
        { age: 108, L: -0.34, M: 29.7, S: 0.17 },
        { age: 120, L: -0.34, M: 33.6, S: 0.18 },
        { age: 132, L: -0.34, M: 38.2, S: 0.19 },
        { age: 144, L: -0.34, M: 43.4, S: 0.19 },
        { age: 156, L: -0.33, M: 48.5, S: 0.19 },
        { age: 168, L: -0.32, M: 52.8, S: 0.18 },
        { age: 180, L: -0.3, M: 56.0, S: 0.17 },
        { age: 192, L: -0.28, M: 58.2, S: 0.16 },
        { age: 204, L: -0.26, M: 59.5, S: 0.16 },
        { age: 216, L: -0.24, M: 60.2, S: 0.15 },
        { age: 228, L: -0.22, M: 60.5, S: 0.15 },
        { age: 240, L: -0.2, M: 60.8, S: 0.15 },
      ],
    },
  },
}

// BMI for age percentile data (ages 2-20)
const bmiData = {
  male: [
    { age: 24, L: -2.0, M: 16.0, S: 0.08 },
    { age: 36, L: -1.8, M: 15.6, S: 0.08 },
    { age: 48, L: -1.6, M: 15.3, S: 0.08 },
    { age: 60, L: -1.4, M: 15.2, S: 0.09 },
    { age: 72, L: -1.2, M: 15.2, S: 0.09 },
    { age: 84, L: -1.0, M: 15.4, S: 0.1 },
    { age: 96, L: -0.8, M: 15.7, S: 0.11 },
    { age: 108, L: -0.6, M: 16.1, S: 0.12 },
    { age: 120, L: -0.4, M: 16.6, S: 0.13 },
    { age: 132, L: -0.2, M: 17.2, S: 0.14 },
    { age: 144, L: 0.0, M: 18.0, S: 0.14 },
    { age: 156, L: 0.2, M: 18.9, S: 0.15 },
    { age: 168, L: 0.4, M: 19.8, S: 0.15 },
    { age: 180, L: 0.6, M: 20.6, S: 0.14 },
    { age: 192, L: 0.7, M: 21.3, S: 0.14 },
    { age: 204, L: 0.8, M: 21.9, S: 0.13 },
    { age: 216, L: 0.9, M: 22.4, S: 0.13 },
    { age: 228, L: 1.0, M: 22.8, S: 0.12 },
    { age: 240, L: 1.0, M: 23.1, S: 0.12 },
  ],
  female: [
    { age: 24, L: -2.0, M: 15.7, S: 0.09 },
    { age: 36, L: -1.8, M: 15.4, S: 0.09 },
    { age: 48, L: -1.6, M: 15.2, S: 0.09 },
    { age: 60, L: -1.4, M: 15.1, S: 0.1 },
    { age: 72, L: -1.2, M: 15.2, S: 0.1 },
    { age: 84, L: -1.0, M: 15.4, S: 0.11 },
    { age: 96, L: -0.8, M: 15.7, S: 0.12 },
    { age: 108, L: -0.6, M: 16.2, S: 0.13 },
    { age: 120, L: -0.4, M: 16.8, S: 0.14 },
    { age: 132, L: -0.2, M: 17.5, S: 0.14 },
    { age: 144, L: 0.0, M: 18.4, S: 0.15 },
    { age: 156, L: 0.2, M: 19.3, S: 0.15 },
    { age: 168, L: 0.4, M: 20.1, S: 0.15 },
    { age: 180, L: 0.5, M: 20.7, S: 0.14 },
    { age: 192, L: 0.6, M: 21.1, S: 0.14 },
    { age: 204, L: 0.7, M: 21.4, S: 0.13 },
    { age: 216, L: 0.8, M: 21.6, S: 0.13 },
    { age: 228, L: 0.8, M: 21.8, S: 0.13 },
    { age: 240, L: 0.9, M: 22.0, S: 0.12 },
  ],
}

export function ChildGrowthPercentileCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [growthStandard, setGrowthStandard] = useState<GrowthStandard>("who")
  const [ageUnit, setAgeUnit] = useState<AgeUnit>("months")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [result, setResult] = useState<GrowthResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  // Calculate z-score using LMS method
  const calculateZScore = (value: number, L: number, M: number, S: number): number => {
    if (L === 0) {
      return Math.log(value / M) / S
    }
    return (Math.pow(value / M, L) - 1) / (L * S)
  }

  // Convert z-score to percentile using standard normal distribution
  const zScoreToPercentile = (z: number): number => {
    // Approximation of standard normal CDF
    const a1 = 0.254829592
    const a2 = -0.284496736
    const a3 = 1.421413741
    const a4 = -1.453152027
    const a5 = 1.061405429
    const p = 0.3275911

    const sign = z < 0 ? -1 : 1
    z = Math.abs(z) / Math.sqrt(2)

    const t = 1 / (1 + p * z)
    const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-z * z)

    return Math.round(0.5 * (1 + sign * y) * 1000) / 10
  }

  // Interpolate LMS values for given age
  const interpolateLMS = (
    data: Array<{ age: number; L: number; M: number; S: number }>,
    ageMonths: number,
  ): { L: number; M: number; S: number } | null => {
    if (ageMonths < data[0].age || ageMonths > data[data.length - 1].age) {
      return null
    }

    // Find surrounding data points
    let lower = data[0]
    let upper = data[data.length - 1]

    for (let i = 0; i < data.length - 1; i++) {
      if (ageMonths >= data[i].age && ageMonths <= data[i + 1].age) {
        lower = data[i]
        upper = data[i + 1]
        break
      }
    }

    if (lower.age === upper.age) {
      return { L: lower.L, M: lower.M, S: lower.S }
    }

    // Linear interpolation
    const ratio = (ageMonths - lower.age) / (upper.age - lower.age)
    return {
      L: lower.L + ratio * (upper.L - lower.L),
      M: lower.M + ratio * (upper.M - lower.M),
      S: lower.S + ratio * (upper.S - lower.S),
    }
  }

  const getPercentileCategory = (percentile: number): { category: string; color: string } => {
    if (percentile < 3) {
      return { category: "Very Low", color: "text-red-600" }
    } else if (percentile < 15) {
      return { category: "Below Average", color: "text-orange-600" }
    } else if (percentile < 85) {
      return { category: "Normal Range", color: "text-green-600" }
    } else if (percentile < 97) {
      return { category: "Above Average", color: "text-blue-600" }
    } else {
      return { category: "Very High", color: "text-purple-600" }
    }
  }

  const getBMICategory = (percentile: number): { category: string; color: string } => {
    if (percentile < 5) {
      return { category: "Underweight", color: "text-blue-600" }
    } else if (percentile < 85) {
      return { category: "Healthy Weight", color: "text-green-600" }
    } else if (percentile < 95) {
      return { category: "Overweight", color: "text-yellow-600" }
    } else {
      return { category: "Obese", color: "text-red-600" }
    }
  }

  const calculatePercentiles = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    if (isNaN(ageNum) || ageNum <= 0) {
      setError("Please enter a valid age greater than 0")
      return
    }

    // Convert age to months
    const ageMonths = ageUnit === "years" ? ageNum * 12 : ageNum

    // Validate age range
    if (ageMonths > 240) {
      setError("Age must be 20 years (240 months) or less")
      return
    }

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number
    if (unitSystem === "metric") {
      heightInCm = Number.parseFloat(heightCm)
      if (isNaN(heightInCm) || heightInCm <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = feet * 30.48 + inches * 2.54
    }

    // Convert weight to kg if imperial
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Get growth data based on standard, gender, and age
    const standardData = growthData[growthStandard]
    const genderData = standardData[gender]

    // Calculate height percentile
    const heightLMS = interpolateLMS(genderData.height, ageMonths)
    let heightPercentile = 50
    if (heightLMS) {
      const heightZ = calculateZScore(heightInCm, heightLMS.L, heightLMS.M, heightLMS.S)
      heightPercentile = zScoreToPercentile(heightZ)
    }

    // Calculate weight percentile
    const weightLMS = interpolateLMS(genderData.weight, ageMonths)
    let weightPercentile = 50
    if (weightLMS) {
      const weightZ = calculateZScore(weightInKg, weightLMS.L, weightLMS.M, weightLMS.S)
      weightPercentile = zScoreToPercentile(weightZ)
    }

    // Calculate BMI and BMI percentile (only for ages 2+)
    let bmi: number | null = null
    let bmiPercentile: number | null = null
    let bmiCategory: string | null = null
    let bmiColor: string | null = null

    if (ageMonths >= 24) {
      bmi = Math.round((weightInKg / Math.pow(heightInCm / 100, 2)) * 10) / 10
      const bmiLMS = interpolateLMS(bmiData[gender], ageMonths)
      if (bmiLMS) {
        const bmiZ = calculateZScore(bmi, bmiLMS.L, bmiLMS.M, bmiLMS.S)
        bmiPercentile = zScoreToPercentile(bmiZ)
        const bmiCat = getBMICategory(bmiPercentile)
        bmiCategory = bmiCat.category
        bmiColor = bmiCat.color
      }
    }

    const heightCat = getPercentileCategory(heightPercentile)
    const weightCat = getPercentileCategory(weightPercentile)

    setResult({
      heightPercentile,
      weightPercentile,
      bmiPercentile,
      bmi,
      heightCategory: heightCat.category,
      weightCategory: weightCat.category,
      bmiCategory,
      heightColor: heightCat.color,
      weightColor: weightCat.color,
      bmiColor,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Child Growth Percentiles:\nHeight: ${result.heightPercentile}th percentile (${result.heightCategory})\nWeight: ${result.weightPercentile}th percentile (${result.weightCategory})${result.bmiPercentile !== null ? `\nBMI: ${result.bmi} (${result.bmiPercentile}th percentile - ${result.bmiCategory})` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Child Growth Percentiles",
          text: `Child Growth Percentiles calculated using CalcHub!\nHeight: ${result.heightPercentile}th percentile\nWeight: ${result.weightPercentile}th percentile`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Baby className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Child Growth Percentile</CardTitle>
                    <CardDescription>Calculate growth percentiles using WHO/CDC charts</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Growth Standard */}
                <div className="space-y-2">
                  <Label>Growth Standard</Label>
                  <Select value={growthStandard} onValueChange={(v) => setGrowthStandard(v as GrowthStandard)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="who">WHO (0-18 years)</SelectItem>
                      <SelectItem value="cdc">CDC (2-20 years)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Gender */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label>Age</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder="Enter age"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="0"
                      step="1"
                      className="flex-1"
                    />
                    <Select value={ageUnit} onValueChange={(v) => setAgeUnit(v as AgeUnit)}>
                      <SelectTrigger className="w-28">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="months">Months</SelectItem>
                        <SelectItem value="years">Years</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <div className="relative">
                    <Scale className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="weight"
                      type="number"
                      placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      min="0"
                      step="0.1"
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <div className="relative">
                      <Ruler className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="height"
                        type="number"
                        placeholder="Enter height in centimeters"
                        value={heightCm}
                        onChange={(e) => setHeightCm(e.target.value)}
                        min="0"
                        step="0.1"
                        className="pl-10"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="relative">
                        <Ruler className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                          className="pl-10"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePercentiles} className="w-full" size="lg">
                  Calculate Percentiles
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-gradient-to-br from-pink-50 to-blue-50 border-pink-200 transition-all duration-300">
                    <div className="space-y-4">
                      {/* Height Percentile */}
                      <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                        <div className="flex items-center gap-2">
                          <Ruler className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium">Height Percentile</span>
                        </div>
                        <div className="text-right">
                          <p className={`text-2xl font-bold ${result.heightColor}`}>
                            {result.heightPercentile}
                            <span className="text-sm">th</span>
                          </p>
                          <p className={`text-xs ${result.heightColor}`}>{result.heightCategory}</p>
                        </div>
                      </div>

                      {/* Weight Percentile */}
                      <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                        <div className="flex items-center gap-2">
                          <Scale className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium">Weight Percentile</span>
                        </div>
                        <div className="text-right">
                          <p className={`text-2xl font-bold ${result.weightColor}`}>
                            {result.weightPercentile}
                            <span className="text-sm">th</span>
                          </p>
                          <p className={`text-xs ${result.weightColor}`}>{result.weightCategory}</p>
                        </div>
                      </div>

                      {/* BMI Percentile (if age >= 2 years) */}
                      {result.bmiPercentile !== null && result.bmi !== null && (
                        <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                          <div className="flex items-center gap-2">
                            <Baby className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <span className="text-sm font-medium">BMI Percentile</span>
                              <p className="text-xs text-muted-foreground">BMI: {result.bmi}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`text-2xl font-bold ${result.bmiColor}`}>
                              {result.bmiPercentile}
                              <span className="text-sm">th</span>
                            </p>
                            <p className={`text-xs ${result.bmiColor}`}>{result.bmiCategory}</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="flex items-center justify-center gap-1 w-full mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 p-3 bg-white/80 rounded-lg text-sm space-y-2">
                        <p>
                          <span className="text-muted-foreground">Growth Standard:</span>{" "}
                          <strong>{growthStandard.toUpperCase()}</strong>
                        </p>
                        <p>
                          <span className="text-muted-foreground">Interpretation:</span>
                        </p>
                        <ul className="list-disc list-inside text-xs text-muted-foreground space-y-1 ml-2">
                          <li>
                            Height at {result.heightPercentile}th percentile means taller than {result.heightPercentile}
                            % of children
                          </li>
                          <li>
                            Weight at {result.weightPercentile}th percentile means heavier than{" "}
                            {result.weightPercentile}% of children
                          </li>
                          {result.bmiPercentile !== null && (
                            <li>
                              BMI at {result.bmiPercentile}th percentile indicates {result.bmiCategory?.toLowerCase()}{" "}
                              status
                            </li>
                          )}
                        </ul>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Percentile Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very Low</span>
                      <span className="text-sm text-red-600">{"< 3rd"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Below Average</span>
                      <span className="text-sm text-orange-600">3rd – 15th</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Normal Range</span>
                      <span className="text-sm text-green-600">15th – 85th</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Above Average</span>
                      <span className="text-sm text-blue-600">85th – 97th</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Very High</span>
                      <span className="text-sm text-purple-600">{"> 97th"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BMI-for-Age Categories</CardTitle>
                  <CardDescription>For children ages 2-20 years</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Underweight</span>
                      <span className="text-sm text-blue-600">{"< 5th"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Healthy Weight</span>
                      <span className="text-sm text-green-600">5th – 85th</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Overweight</span>
                      <span className="text-sm text-yellow-600">85th – 95th</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Obese</span>
                      <span className="text-sm text-red-600">{"> 95th"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Growth Standards</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">WHO Growth Charts</p>
                    <p>
                      International standard for children 0-18 years. Describes optimal growth under ideal conditions.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">CDC Growth Charts</p>
                    <p>
                      US reference for children 2-20 years. Based on national survey data representing how children grew
                      at a specific time.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Growth Percentiles</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Growth percentiles indicate how a child's size compares to other children of the same age and sex. A
                  percentile rank of 50th means the child is right in the middle - 50% of children are larger and 50%
                  are smaller. These measurements help healthcare providers track a child's growth pattern over time and
                  identify potential nutritional or health concerns early.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Growth charts were developed from measurements of thousands of children and represent the range of
                  normal growth patterns. The WHO charts (2006) describe how children should grow under optimal
                  conditions with breastfeeding and healthy environments, while CDC charts (2000) describe how US
                  children actually grew during a specific time period.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Baby className="h-5 w-5 text-primary" />
                  <CardTitle>What Do Growth Percentiles Mean?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Normal Growth Pattern</h4>
                    <p className="text-green-700 text-sm">
                      Most healthy children fall between the 15th and 85th percentiles. What's most important is that a
                      child follows their own growth curve consistently over time, not necessarily being at a specific
                      percentile.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Tracking Over Time</h4>
                    <p className="text-blue-700 text-sm">
                      A child's percentile may naturally shift during growth spurts or periods of slower growth. Sudden
                      large changes in percentile rank (crossing two or more major percentile lines) may warrant
                      evaluation by a healthcare provider.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Genetic Factors</h4>
                    <p className="text-yellow-700 text-sm">
                      A child's growth is influenced by genetics. Children of taller parents tend to be taller than
                      average, while children of shorter parents may be shorter. This is normal variation and not
                      necessarily a concern.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Child growth percentiles are estimates based on standard growth charts and should not replace
                  professional medical assessment. Individual children grow at different rates, and a single measurement
                  provides limited information. Growth should be tracked over time by a healthcare provider who can
                  consider the full clinical picture. If you have concerns about your child's growth, please consult a
                  pediatrician or qualified healthcare professional for personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
