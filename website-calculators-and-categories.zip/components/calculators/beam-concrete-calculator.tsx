"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Minus, Info, Box } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Unit = "m" | "ft"
type MixGrade = "M10" | "M15" | "M20" | "M25" | "custom"

interface BeamResult {
  wetVolume: number
  dryVolume: number
  cement: number
  cementWeight: number
  sand: number
  aggregate: number
  unit: string
}

const mixRatios: Record<MixGrade, { ratio: string; cement: number; sand: number; aggregate: number }> = {
  M10: { ratio: "1:3:6", cement: 1, sand: 3, aggregate: 6 },
  M15: { ratio: "1:2:4", cement: 1, sand: 2, aggregate: 4 },
  M20: { ratio: "1:1.5:3", cement: 1, sand: 1.5, aggregate: 3 },
  M25: { ratio: "1:1:2", cement: 1, sand: 1, aggregate: 2 },
  custom: { ratio: "1:1.5:3", cement: 1, sand: 1.5, aggregate: 3 },
}

export function BeamConcreteCalculator() {
  const [unit, setUnit] = useState<Unit>("m")
  const [width, setWidth] = useState("")
  const [depth, setDepth] = useState("")
  const [length, setLength] = useState("")
  const [numberOfBeams, setNumberOfBeams] = useState("1")
  const [mixGrade, setMixGrade] = useState<MixGrade>("M20")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<BeamResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBeam = () => {
    setError("")
    setResult(null)

    const widthNum = Number.parseFloat(width)
    const depthNum = Number.parseFloat(depth)
    const lengthNum = Number.parseFloat(length)
    const numBeams = Number.parseFloat(numberOfBeams)
    const dryFactor = Number.parseFloat(dryVolumeFactor)
    const wastagePercent = Number.parseFloat(wastage)

    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }

    if (isNaN(depthNum) || depthNum <= 0) {
      setError("Please enter a valid depth greater than 0")
      return
    }

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }

    if (isNaN(numBeams) || numBeams < 1) {
      setError("Number of beams must be at least 1")
      return
    }

    if (isNaN(dryFactor) || dryFactor <= 0) {
      setError("Dry volume factor must be greater than 0")
      return
    }

    if (isNaN(wastagePercent) || wastagePercent < 0) {
      setError("Wastage percentage must be 0 or greater")
      return
    }

    // Calculate wet volume
    let wetVolume = widthNum * depthNum * lengthNum * numBeams

    // Add wastage
    wetVolume = wetVolume * (1 + wastagePercent / 100)

    const dryVolume = wetVolume * dryFactor

    // Calculate materials based on mix ratio
    const mix = mixRatios[mixGrade]
    const totalParts = mix.cement + mix.sand + mix.aggregate

    const cementVolume = (dryVolume * mix.cement) / totalParts
    const sandVolume = (dryVolume * mix.sand) / totalParts
    const aggregateVolume = (dryVolume * mix.aggregate) / totalParts

    // Convert cement volume to bags (1 bag = 0.035 m³ or 1.25 ft³)
    const cementBagVolume = unit === "m" ? 0.035 : 1.25
    const cementBags = Math.ceil(cementVolume / cementBagVolume)
    const cementWeight = cementBags * 50 // 50kg per bag

    setResult({
      wetVolume: Math.round(wetVolume * 1000) / 1000,
      dryVolume: Math.round(dryVolume * 1000) / 1000,
      cement: cementBags,
      cementWeight,
      sand: Math.round(sandVolume * 1000) / 1000,
      aggregate: Math.round(aggregateVolume * 1000) / 1000,
      unit: unit === "m" ? "m³" : "ft³",
    })
  }

  const handleReset = () => {
    setWidth("")
    setDepth("")
    setLength("")
    setNumberOfBeams("1")
    setMixGrade("M20")
    setDryVolumeFactor("1.54")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Beam Concrete: Wet Volume: ${result.wetVolume} ${result.unit}, Cement: ${result.cement} bags (${result.cementWeight}kg), Sand: ${result.sand} ${result.unit}, Aggregate: ${result.aggregate} ${result.unit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Beam Concrete Calculator Result",
          text: `I calculated concrete requirements for beams using CalcHub! Wet Volume: ${result.wetVolume} ${result.unit}, Cement: ${result.cement} bags`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Minus className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Beam Concrete Calculator</CardTitle>
                    <CardDescription>Calculate RCC beam concrete requirements</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="unit">Unit</Label>
                  <Select
                    value={unit}
                    onValueChange={(value: Unit) => {
                      setUnit(value)
                      setResult(null)
                    }}
                  >
                    <SelectTrigger id="unit">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="m">Meters (m)</SelectItem>
                      <SelectItem value="ft">Feet (ft)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dimension Inputs */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="width">Width (b) ({unit})</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder="Enter width"
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="depth">Depth (d) ({unit})</Label>
                    <Input
                      id="depth"
                      type="number"
                      placeholder="Enter depth"
                      value={depth}
                      onChange={(e) => setDepth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="length">Length (L) ({unit})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder="Enter length"
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="numberOfBeams">Number of Beams</Label>
                  <Input
                    id="numberOfBeams"
                    type="number"
                    placeholder="Enter number"
                    value={numberOfBeams}
                    onChange={(e) => setNumberOfBeams(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Mix Grade */}
                <div className="space-y-2">
                  <Label htmlFor="mixGrade">Concrete Grade</Label>
                  <Select
                    value={mixGrade}
                    onValueChange={(value: MixGrade) => {
                      setMixGrade(value)
                      setResult(null)
                    }}
                  >
                    <SelectTrigger id="mixGrade">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M10">M10 (1:3:6)</SelectItem>
                      <SelectItem value="M15">M15 (1:2:4)</SelectItem>
                      <SelectItem value="M20">M20 (1:1.5:3)</SelectItem>
                      <SelectItem value="M25">M25 (1:1:2)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="dryVolumeFactor">Dry Volume Factor</Label>
                    <Input
                      id="dryVolumeFactor"
                      type="number"
                      placeholder="1.54"
                      value={dryVolumeFactor}
                      onChange={(e) => setDryVolumeFactor(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wastage">Wastage (%)</Label>
                    <Input
                      id="wastage"
                      type="number"
                      placeholder="5"
                      value={wastage}
                      onChange={(e) => setWastage(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBeam} className="w-full" size="lg">
                  Calculate Concrete
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Wet Volume</p>
                        <p className="text-3xl font-bold text-amber-600">
                          {result.wetVolume} {result.unit}
                        </p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Dry Volume:</span>
                          <span className="font-semibold text-amber-700">
                            {result.dryVolume} {result.unit}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Cement:</span>
                          <span className="font-semibold text-amber-700">
                            {result.cement} bags ({result.cementWeight} kg)
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Sand:</span>
                          <span className="font-semibold text-amber-700">
                            {result.sand} {result.unit}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Aggregate:</span>
                          <span className="font-semibold text-amber-700">
                            {result.aggregate} {result.unit}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Beam Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-800">Residential</p>
                      <p className="text-sm text-amber-600">230mm × 300mm to 230mm × 450mm</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-800">Commercial</p>
                      <p className="text-sm text-amber-600">300mm × 600mm to 450mm × 750mm</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-800">Industrial</p>
                      <p className="text-sm text-amber-600">400mm × 900mm or larger</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Concrete Grades</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong className="text-foreground">M10 (1:3:6):</strong> Non-structural work
                  </p>
                  <p>
                    <strong className="text-foreground">M15 (1:2:4):</strong> Light structures
                  </p>
                  <p>
                    <strong className="text-foreground">M20 (1:1.5:3):</strong> Standard residential beams
                  </p>
                  <p>
                    <strong className="text-foreground">M25 (1:1:2):</strong> Commercial structures
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Beam Concrete */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-amber-600" />
                  <CardTitle>What is RCC Beam Concrete?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Reinforced Cement Concrete (RCC) beams are horizontal structural members designed to carry loads from
                  slabs and transfer them to columns. Beams are essential components in building construction, working
                  primarily in bending and shear to distribute loads evenly across the structure. The concrete used in
                  beams must have adequate compressive strength, while steel reinforcement provides the tensile strength
                  needed to resist bending moments.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Beams are typically rectangular in cross-section, with the depth usually 1.5 to 2 times the width for
                  optimal structural efficiency. The size and reinforcement of beams depend on the span length, load
                  conditions, and structural requirements. Accurate calculation of concrete quantity is essential for
                  cost estimation, material procurement, and ensuring adequate supply during construction without
                  wastage.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Box className="h-5 w-5 text-amber-600" />
                  <CardTitle>How to Calculate Beam Concrete</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The concrete volume for beams is calculated using the formula: Volume = Width × Depth × Length × Number
                  of Beams. The width (b) and depth (d) represent the cross-sectional dimensions of the beam, while the
                  length (L) is the span between columns. For example, a beam with dimensions 0.23m × 0.45m × 4m would
                  have a volume of 0.414 cubic meters per beam.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The wet concrete volume is then multiplied by a dry volume factor (typically 1.54) to account for voids
                  and compaction. Material quantities are calculated based on the concrete grade mix ratio. A wastage
                  factor (usually 5%) is added to compensate for material loss during mixing, transportation, and
                  placement. For critical projects, it's recommended to order slightly more concrete to ensure continuous
                  pouring without interruption.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Note:</strong> Beam calculations exclude reinforcement volume and formwork losses unless
                  specified. For structural design and critical calculations, always consult with a qualified structural
                  engineer. Material quantities may vary based on site conditions, concrete grade requirements, and
                  construction practices.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
