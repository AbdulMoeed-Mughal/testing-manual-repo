"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, BookOpen, Beaker } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationType = "potential" | "concentration"
type FormulaType = "ln" | "log10"
type TempUnit = "celsius" | "kelvin"

interface NernstResult {
  potential: number
  Q: number
  temperatureK: number
  rtNf: number
  color: string
  bgColor: string
  interpretation: string
}

// Physical constants
const R = 8.314 // Gas constant J/(mol·K)
const F = 96485 // Faraday constant C/mol

export function NernstEquationCalculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>("potential")
  const [formulaType, setFormulaType] = useState<FormulaType>("ln")
  const [tempUnit, setTempUnit] = useState<TempUnit>("celsius")
  const [standardPotential, setStandardPotential] = useState("")
  const [electrons, setElectrons] = useState("")
  const [temperature, setTemperature] = useState("25")
  const [reactionQuotient, setReactionQuotient] = useState("")
  const [productConc, setProductConc] = useState("")
  const [reactantConc, setReactantConc] = useState("")
  const [productCoeff, setProductCoeff] = useState("1")
  const [reactantCoeff, setReactantCoeff] = useState("1")
  const [useConcentrations, setUseConcentrations] = useState(false)
  const [result, setResult] = useState<NernstResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const E0 = Number.parseFloat(standardPotential)
    const n = Number.parseInt(electrons)
    const T = Number.parseFloat(temperature)

    if (isNaN(E0)) {
      setError("Please enter a valid standard electrode potential (E°)")
      return
    }

    if (isNaN(n) || n <= 0) {
      setError("Number of electrons transferred must be a positive integer")
      return
    }

    if (isNaN(T)) {
      setError("Please enter a valid temperature")
      return
    }

    // Convert temperature to Kelvin
    const tempK = tempUnit === "celsius" ? T + 273.15 : T

    if (tempK <= 0) {
      setError("Temperature must be above absolute zero")
      return
    }

    let Q: number

    if (useConcentrations) {
      const prodC = Number.parseFloat(productConc)
      const reactC = Number.parseFloat(reactantConc)
      const prodCoeff = Number.parseFloat(productCoeff)
      const reactCoeff = Number.parseFloat(reactantCoeff)

      if (isNaN(prodC) || prodC <= 0) {
        setError("Product concentration must be positive")
        return
      }
      if (isNaN(reactC) || reactC <= 0) {
        setError("Reactant concentration must be positive")
        return
      }
      if (isNaN(prodCoeff) || prodCoeff <= 0) {
        setError("Product coefficient must be positive")
        return
      }
      if (isNaN(reactCoeff) || reactCoeff <= 0) {
        setError("Reactant coefficient must be positive")
        return
      }

      Q = Math.pow(prodC, prodCoeff) / Math.pow(reactC, reactCoeff)
    } else {
      Q = Number.parseFloat(reactionQuotient)
      if (isNaN(Q) || Q <= 0) {
        setError("Reaction quotient (Q) must be positive")
        return
      }
    }

    // Calculate RT/nF
    const rtNf = (R * tempK) / (n * F)

    // Calculate potential using Nernst equation
    // E = E° - (RT/nF) × ln(Q)
    const E = E0 - rtNf * Math.log(Q)

    // Determine interpretation
    let interpretation: string
    let color: string
    let bgColor: string

    if (E > E0) {
      interpretation = "Reaction favors reduction (forward reaction spontaneous)"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (E < E0) {
      interpretation = "Reaction favors oxidation (reverse reaction spontaneous)"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      interpretation = "System at equilibrium"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    }

    setResult({
      potential: E,
      Q,
      temperatureK: tempK,
      rtNf,
      color,
      bgColor,
      interpretation,
    })
  }

  const handleReset = () => {
    setStandardPotential("")
    setElectrons("")
    setTemperature("25")
    setReactionQuotient("")
    setProductConc("")
    setReactantConc("")
    setProductCoeff("1")
    setReactantCoeff("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Nernst Equation Result: E = ${result.potential.toFixed(4)} V (E° = ${standardPotential} V, n = ${electrons}, T = ${result.temperatureK.toFixed(2)} K, Q = ${result.Q.toExponential(3)})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Nernst Equation Result",
          text: `I calculated the electrode potential using CalcHub! E = ${result.potential.toFixed(4)} V`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  // Format for log10 display
  const getLog10Factor = (tempK: number, n: number) => {
    return ((2.303 * R * tempK) / (n * F)).toFixed(4)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Nernst Equation Calculator</CardTitle>
                    <CardDescription>Calculate electrode potential under non-standard conditions</CardDescription>
                  </div>
                </div>

                {/* Formula Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Formula Type</span>
                  <button
                    onClick={() => setFormulaType(formulaType === "ln" ? "log10" : "ln")}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        formulaType === "log10" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        formulaType === "ln" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      ln(Q)
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        formulaType === "log10" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      log₁₀(Q)
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Standard Potential */}
                <div className="space-y-2">
                  <Label htmlFor="standardPotential">Standard Electrode Potential, E° (V)</Label>
                  <Input
                    id="standardPotential"
                    type="number"
                    placeholder="e.g., 0.34 for Cu²⁺/Cu"
                    value={standardPotential}
                    onChange={(e) => setStandardPotential(e.target.value)}
                    step="0.001"
                  />
                </div>

                {/* Number of Electrons */}
                <div className="space-y-2">
                  <Label htmlFor="electrons">Number of Electrons Transferred (n)</Label>
                  <Input
                    id="electrons"
                    type="number"
                    placeholder="e.g., 2"
                    value={electrons}
                    onChange={(e) => setElectrons(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Temperature */}
                <div className="space-y-2">
                  <Label htmlFor="temperature">Temperature</Label>
                  <div className="flex gap-2">
                    <Input
                      id="temperature"
                      type="number"
                      placeholder="25"
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                      className="flex-1"
                    />
                    <Select value={tempUnit} onValueChange={(v: TempUnit) => setTempUnit(v)}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="celsius">°C</SelectItem>
                        <SelectItem value="kelvin">K</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm font-medium">Input Method</span>
                  <button
                    onClick={() => setUseConcentrations(!useConcentrations)}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        useConcentrations ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !useConcentrations ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Direct Q
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        useConcentrations ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Concentrations
                    </span>
                  </button>
                </div>

                {/* Reaction Quotient or Concentrations */}
                {!useConcentrations ? (
                  <div className="space-y-2">
                    <Label htmlFor="reactionQuotient">Reaction Quotient (Q)</Label>
                    <Input
                      id="reactionQuotient"
                      type="number"
                      placeholder="e.g., 0.001"
                      value={reactionQuotient}
                      onChange={(e) => setReactionQuotient(e.target.value)}
                      step="any"
                    />
                    <p className="text-xs text-muted-foreground">Q = [Products]ⁿ / [Reactants]ᵐ</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="productConc">[Product] (mol/L)</Label>
                        <Input
                          id="productConc"
                          type="number"
                          placeholder="e.g., 0.01"
                          value={productConc}
                          onChange={(e) => setProductConc(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="productCoeff">Coefficient</Label>
                        <Input
                          id="productCoeff"
                          type="number"
                          placeholder="1"
                          value={productCoeff}
                          onChange={(e) => setProductCoeff(e.target.value)}
                          min="1"
                          step="1"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="reactantConc">[Reactant] (mol/L)</Label>
                        <Input
                          id="reactantConc"
                          type="number"
                          placeholder="e.g., 1.0"
                          value={reactantConc}
                          onChange={(e) => setReactantConc(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="reactantCoeff">Coefficient</Label>
                        <Input
                          id="reactantCoeff"
                          type="number"
                          placeholder="1"
                          value={reactantCoeff}
                          onChange={(e) => setReactantCoeff(e.target.value)}
                          min="1"
                          step="1"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Potential
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Electrode Potential (E)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-2`}>{result.potential.toFixed(4)} V</p>
                      <p className={`text-sm font-medium ${result.color}`}>{result.interpretation}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Q</p>
                        <p className="font-semibold">{result.Q.toExponential(3)}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">RT/nF</p>
                        <p className="font-semibold">{result.rtNf.toFixed(5)} V</p>
                      </div>
                    </div>

                    {/* Step-by-step toggle */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/70 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Identify given values
                        </p>
                        <p className="pl-4">
                          E° = {standardPotential} V, n = {electrons}, T = {result.temperatureK.toFixed(2)} K
                        </p>
                        <p>
                          <strong>Step 2:</strong> Calculate RT/nF
                        </p>
                        <p className="pl-4">
                          RT/nF = ({R} × {result.temperatureK.toFixed(2)}) / ({electrons} × {F})
                        </p>
                        <p className="pl-4">RT/nF = {result.rtNf.toFixed(5)} V</p>
                        <p>
                          <strong>Step 3:</strong> Apply Nernst equation
                        </p>
                        {formulaType === "ln" ? (
                          <>
                            <p className="pl-4">E = E° − (RT/nF) × ln(Q)</p>
                            <p className="pl-4">
                              E = {standardPotential} − ({result.rtNf.toFixed(5)}) × ln({result.Q.toExponential(3)})
                            </p>
                            <p className="pl-4">
                              E = {standardPotential} − ({result.rtNf.toFixed(5)}) × ({Math.log(result.Q).toFixed(4)})
                            </p>
                          </>
                        ) : (
                          <>
                            <p className="pl-4">E = E° − (2.303RT/nF) × log₁₀(Q)</p>
                            <p className="pl-4">
                              E = {standardPotential} − (
                              {getLog10Factor(result.temperatureK, Number.parseInt(electrons))}) × log₁₀(
                              {result.Q.toExponential(3)})
                            </p>
                            <p className="pl-4">
                              E = {standardPotential} − (
                              {getLog10Factor(result.temperatureK, Number.parseInt(electrons))}) × (
                              {Math.log10(result.Q).toFixed(4)})
                            </p>
                          </>
                        )}
                        <p>
                          <strong>Step 4:</strong> Final result
                        </p>
                        <p className="pl-4 font-semibold">E = {result.potential.toFixed(4)} V</p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Nernst Equation</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">E = E° − (RT/nF) × ln(Q)</p>
                    <p className="text-sm text-muted-foreground">or at 25°C:</p>
                    <p className="font-semibold text-foreground">E = E° − (0.0591/n) × log₁₀(Q)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Constants Used</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Gas Constant (R)</span>
                      <span className="text-sm text-purple-600">8.314 J/(mol·K)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Faraday Constant (F)</span>
                      <span className="text-sm text-blue-600">96,485 C/mol</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Standard Temp</span>
                      <span className="text-sm text-green-600">25°C = 298.15 K</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    <CardTitle className="text-lg">Disclaimer</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Results assume ideal behavior and standard conditions unless otherwise specified. Activity
                    coefficients are not considered in this simplified calculation.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Nernst Equation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Nernst equation, developed by German chemist Walther Nernst in 1889, is a fundamental equation in
                  electrochemistry that relates the reduction potential of an electrochemical reaction to the standard
                  electrode potential, temperature, and the activities (or concentrations) of the chemical species
                  involved. It allows us to calculate the cell potential under non-standard conditions, which is crucial
                  for understanding battery performance, corrosion processes, and biological membrane potentials.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  At its core, the Nernst equation quantifies how the electrode potential changes when the
                  concentrations of reactants and products differ from their standard state values (typically 1 M for
                  solutions). This relationship is essential for predicting the direction and extent of electrochemical
                  reactions in real-world applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Variables</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">E (Cell Potential)</h4>
                    <p className="text-purple-700 text-sm">
                      The actual electrode potential under the given conditions, measured in volts (V). This is what we
                      typically want to calculate using the Nernst equation.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">E° (Standard Electrode Potential)</h4>
                    <p className="text-blue-700 text-sm">
                      The electrode potential measured under standard conditions (1 M concentrations, 1 atm pressure,
                      25°C). These values are tabulated for many half-reactions.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">n (Number of Electrons)</h4>
                    <p className="text-green-700 text-sm">
                      The number of moles of electrons transferred in the balanced half-reaction. For example, n = 2 for
                      Cu²⁺ + 2e⁻ → Cu.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Q (Reaction Quotient)</h4>
                    <p className="text-orange-700 text-sm">
                      The ratio of product concentrations to reactant concentrations, each raised to their
                      stoichiometric coefficients. For the general reaction: Q = [Products]ⁿ/[Reactants]ᵐ.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>At 25°C: The Simplified Form</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  At 25°C (298.15 K), the Nernst equation simplifies to a commonly used form. Since RT/F at this
                  temperature equals approximately 0.0257 V, and converting from natural log to base-10 log multiplies
                  by 2.303, we get the factor 0.0591 V. This gives us the simplified equation: E = E° − (0.0591/n) ×
                  log₁₀(Q).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This simplified form is widely used in chemistry courses and laboratory calculations because most
                  experiments are conducted near room temperature. However, for precise work or calculations at other
                  temperatures, the full Nernst equation with the actual temperature value should be used.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of the Nernst Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Batteries & Fuel Cells</h4>
                    <p className="text-sm text-muted-foreground">
                      Predicting voltage output under varying charge states and optimizing battery design.
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">pH Electrodes</h4>
                    <p className="text-sm text-muted-foreground">
                      The glass electrode response to H⁺ concentration follows the Nernst equation.
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Corrosion Studies</h4>
                    <p className="text-sm text-muted-foreground">
                      Understanding metal corrosion rates and designing protection systems.
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Biological Systems</h4>
                    <p className="text-sm text-muted-foreground">
                      Calculating membrane potentials and understanding nerve signal transmission.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
