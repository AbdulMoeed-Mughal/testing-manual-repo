"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Flame, Info, Activity, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type Formula = "mifflin" | "harris"
type ActivityLevel = "sedentary" | "light" | "moderate" | "very" | "extra"

interface MaintenanceResult {
  bmr: number
  maintenanceCalories: number
  activityMultiplier: number
  activityLabel: string
  formula: string
}

const activityLevels: Record<ActivityLevel, { multiplier: number; label: string; description: string }> = {
  sedentary: { multiplier: 1.2, label: "Sedentary", description: "Little or no exercise, desk job" },
  light: { multiplier: 1.375, label: "Lightly Active", description: "Light exercise 1-3 days/week" },
  moderate: { multiplier: 1.55, label: "Moderately Active", description: "Moderate exercise 3-5 days/week" },
  very: { multiplier: 1.725, label: "Very Active", description: "Hard exercise 6-7 days/week" },
  extra: { multiplier: 1.9, label: "Extra Active", description: "Very hard exercise, physical job" },
}

export function MaintenanceCaloriesCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")
  const [formula, setFormula] = useState<Formula>("mifflin")
  const [result, setResult] = useState<MaintenanceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateMaintenanceCalories = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const weightNum = Number.parseFloat(weight)

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    let bmr: number
    let formulaName: string

    if (formula === "mifflin") {
      // Mifflin-St Jeor Formula
      if (gender === "male") {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
      } else {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
      }
      formulaName = "Mifflin-St Jeor"
    } else {
      // Harris-Benedict Formula
      if (gender === "male") {
        bmr = 88.362 + 13.397 * weightInKg + 4.799 * heightInCm - 5.677 * ageNum
      } else {
        bmr = 447.593 + 9.247 * weightInKg + 3.098 * heightInCm - 4.33 * ageNum
      }
      formulaName = "Harris-Benedict"
    }

    const activity = activityLevels[activityLevel]
    const maintenanceCalories = bmr * activity.multiplier

    setResult({
      bmr: Math.round(bmr),
      maintenanceCalories: Math.round(maintenanceCalories),
      activityMultiplier: activity.multiplier,
      activityLabel: activity.label,
      formula: formulaName,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setActivityLevel("moderate")
    setFormula("mifflin")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My maintenance calories: ${result.maintenanceCalories} cal/day (BMR: ${result.bmr} cal/day)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Maintenance Calories",
          text: `I calculated my maintenance calories using CalcHub! I need ${result.maintenanceCalories} calories/day to maintain my current weight.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Maintenance Calories Calculator</CardTitle>
                    <CardDescription>Estimate daily calories to maintain weight</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <Select value={activityLevel} onValueChange={(value: ActivityLevel) => setActivityLevel(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(activityLevels).map(([key, { label, description }]) => (
                        <SelectItem key={key} value={key}>
                          <div className="flex flex-col">
                            <span>{label}</span>
                            <span className="text-xs text-muted-foreground">{description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Formula Selection */}
                <div className="space-y-2">
                  <Label>BMR Formula</Label>
                  <Select value={formula} onValueChange={(value: Formula) => setFormula(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select formula" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mifflin">Mifflin-St Jeor (Recommended)</SelectItem>
                      <SelectItem value="harris">Harris-Benedict (Traditional)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMaintenanceCalories} className="w-full" size="lg">
                  Calculate Maintenance Calories
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Daily Maintenance Calories</p>
                      <p className="text-5xl font-bold text-orange-600 mb-2">
                        {result.maintenanceCalories.toLocaleString()}
                      </p>
                      <p className="text-lg font-medium text-orange-700">calories/day</p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-1 mt-3 text-sm text-orange-600 hover:text-orange-700"
                    >
                      {showDetails ? "Hide" : "Show"} Details
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-orange-200 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Basal Metabolic Rate (BMR):</span>
                          <span className="font-medium">{result.bmr.toLocaleString()} cal/day</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Activity Level:</span>
                          <span className="font-medium">{result.activityLabel}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Activity Multiplier:</span>
                          <span className="font-medium">× {result.activityMultiplier}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Formula Used:</span>
                          <span className="font-medium">{result.formula}</span>
                        </div>
                        <div className="mt-3 p-2 bg-orange-100 rounded-lg text-xs">
                          <p className="font-medium text-orange-800">Calorie Ranges:</p>
                          <p className="text-orange-700 mt-1">
                            Weight Loss: ~{Math.round(result.maintenanceCalories * 0.8).toLocaleString()} cal/day
                          </p>
                          <p className="text-orange-700">
                            Weight Gain: ~{Math.round(result.maintenanceCalories * 1.15).toLocaleString()} cal/day
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Activity Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(activityLevels).map(([key, { label, multiplier, description }]) => (
                      <div
                        key={key}
                        className={`flex items-center justify-between p-3 rounded-lg border ${
                          activityLevel === key ? "bg-orange-50 border-orange-200" : "bg-muted/50 border-transparent"
                        }`}
                      >
                        <div>
                          <span className="font-medium">{label}</span>
                          <p className="text-xs text-muted-foreground">{description}</p>
                        </div>
                        <span className="text-sm font-mono">× {multiplier}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BMR Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Mifflin-St Jeor</p>
                    <p className="text-xs font-mono">Male: (10 × weight) + (6.25 × height) − (5 × age) + 5</p>
                    <p className="text-xs font-mono">Female: (10 × weight) + (6.25 × height) − (5 × age) − 161</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Harris-Benedict</p>
                    <p className="text-xs font-mono">Male: 88.36 + (13.4 × weight) + (4.8 × height) − (5.7 × age)</p>
                    <p className="text-xs font-mono">Female: 447.6 + (9.2 × weight) + (3.1 × height) − (4.3 × age)</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Maintenance Calories?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Maintenance calories, also known as Total Daily Energy Expenditure (TDEE), represent the number of
                  calories your body needs each day to maintain your current weight. This figure accounts for all the
                  energy your body uses, from basic functions like breathing and circulation to physical activities and
                  exercise.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Your maintenance calories are calculated by first determining your Basal Metabolic Rate (BMR) - the
                  calories your body burns at complete rest - and then multiplying it by an activity factor that
                  reflects your daily physical activity level. Understanding this number is crucial for anyone looking
                  to lose, gain, or maintain their weight effectively.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use Your Results</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-3 mt-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Weight Loss</h4>
                    <p className="text-green-700 text-sm">
                      Create a calorie deficit by eating 15-20% below maintenance. A 500 cal/day deficit typically
                      results in ~0.5 kg (1 lb) loss per week.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Maintenance</h4>
                    <p className="text-blue-700 text-sm">
                      Eat at your maintenance calories to keep your current weight stable. Track for 2-4 weeks and
                      adjust based on actual results.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Weight Gain</h4>
                    <p className="text-purple-700 text-sm">
                      Create a calorie surplus by eating 10-15% above maintenance. Combined with strength training, this
                      supports muscle growth.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Maintenance calorie estimates are based on standard formulas and may vary
                  depending on individual metabolism, body composition, and lifestyle. These calculations provide a
                  starting point - monitor your weight over 2-4 weeks and adjust intake accordingly. Consult a
                  healthcare professional or registered dietitian for personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
