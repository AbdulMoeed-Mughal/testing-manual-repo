"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type ModulusConvention = "truncated" | "floored" | "euclidean"

interface ModulusResult {
  truncated: number
  floored: number
  euclidean: number
  quotientTruncated: number
  quotientFloored: number
  verification: string
}

interface Step {
  step: number
  description: string
  formula?: string
}

export function ModulusCalculator() {
  const [dividend, setDividend] = useState("")
  const [divisor, setDivisor] = useState("")
  const [convention, setConvention] = useState<ModulusConvention>("truncated")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<ModulusResult | null>(null)
  const [steps, setSteps] = useState<Step[]>([])
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateModulus = () => {
    setError("")
    setResult(null)
    setSteps([])

    const a = Number.parseInt(dividend)
    const n = Number.parseInt(divisor)

    if (isNaN(a)) {
      setError("Please enter a valid integer for dividend")
      return
    }

    if (isNaN(n)) {
      setError("Please enter a valid integer for divisor")
      return
    }

    if (n === 0) {
      setError("Divisor cannot be zero")
      return
    }

    // Truncated division (JavaScript default - rounds toward zero)
    const quotientTruncated = Math.trunc(a / n)
    const truncated = a - quotientTruncated * n

    // Floored division (Python style - rounds toward negative infinity)
    const quotientFloored = Math.floor(a / n)
    const floored = a - quotientFloored * n

    // Euclidean modulus (always non-negative)
    const euclidean = ((a % n) + Math.abs(n)) % Math.abs(n)

    const calculationSteps: Step[] = []

    calculationSteps.push({
      step: 1,
      description: `Start with dividend a = ${a} and divisor n = ${n}`,
    })

    calculationSteps.push({
      step: 2,
      description: "Truncated Division (JavaScript/C style)",
      formula: `q = trunc(${a} ÷ ${n}) = ${quotientTruncated}`,
    })

    calculationSteps.push({
      step: 3,
      description: "Calculate truncated remainder",
      formula: `r = ${a} - (${quotientTruncated} × ${n}) = ${truncated}`,
    })

    calculationSteps.push({
      step: 4,
      description: "Floored Division (Python style)",
      formula: `q = floor(${a} ÷ ${n}) = ${quotientFloored}`,
    })

    calculationSteps.push({
      step: 5,
      description: "Calculate floored remainder",
      formula: `r = ${a} - (${quotientFloored} × ${n}) = ${floored}`,
    })

    calculationSteps.push({
      step: 6,
      description: "Euclidean Modulus (always non-negative)",
      formula: `r = ((${a} mod ${n}) + |${n}|) mod |${n}| = ${euclidean}`,
    })

    calculationSteps.push({
      step: 7,
      description: "Verification",
      formula: `${a} = ${quotientTruncated} × ${n} + ${truncated} ✓`,
    })

    setSteps(calculationSteps)
    setResult({
      truncated,
      floored,
      euclidean,
      quotientTruncated,
      quotientFloored,
      verification: `${a} = ${quotientTruncated} × ${n} + ${truncated}`,
    })
  }

  const handleReset = () => {
    setDividend("")
    setDivisor("")
    setResult(null)
    setSteps([])
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const getResultByConvention = (): number | null => {
    if (!result) return null
    switch (convention) {
      case "truncated":
        return result.truncated
      case "floored":
        return result.floored
      case "euclidean":
        return result.euclidean
    }
  }

  const handleCopy = async () => {
    const mainResult = getResultByConvention()
    if (mainResult !== null) {
      await navigator.clipboard.writeText(`${dividend} mod ${divisor} = ${mainResult} (${convention})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    const mainResult = getResultByConvention()
    if (mainResult !== null && navigator.share) {
      try {
        await navigator.share({
          title: "Modulus Calculation",
          text: `${dividend} mod ${divisor} = ${mainResult} (${convention} convention)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Modulus Calculator</CardTitle>
                    <CardDescription>Calculate remainders with different conventions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Dividend Input */}
                <div className="space-y-2">
                  <Label htmlFor="dividend">Dividend (a)</Label>
                  <Input
                    id="dividend"
                    type="number"
                    placeholder="Enter an integer (e.g., -17)"
                    value={dividend}
                    onChange={(e) => setDividend(e.target.value)}
                  />
                </div>

                {/* Divisor Input */}
                <div className="space-y-2">
                  <Label htmlFor="divisor">Divisor (n)</Label>
                  <Input
                    id="divisor"
                    type="number"
                    placeholder="Enter a non-zero integer (e.g., 5)"
                    value={divisor}
                    onChange={(e) => setDivisor(e.target.value)}
                  />
                </div>

                {/* Convention Selection */}
                <div className="space-y-2">
                  <Label>Modulus Convention</Label>
                  <Select value={convention} onValueChange={(v) => setConvention(v as ModulusConvention)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="truncated">Truncated (JavaScript/C)</SelectItem>
                      <SelectItem value="floored">Floored (Python)</SelectItem>
                      <SelectItem value="euclidean">Euclidean (Mathematical)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="show-steps" className="cursor-pointer">
                    Show step-by-step solution
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateModulus} className="w-full" size="lg">
                  Calculate Modulus
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {dividend} mod {divisor} ({convention})
                      </p>
                      <p className="text-5xl font-bold text-blue-600 mb-2">{getResultByConvention()}</p>
                      <p className="text-sm text-muted-foreground">Remainder</p>
                    </div>

                    {/* Comparison of all conventions */}
                    <div className="mt-4 space-y-2">
                      <button
                        onClick={() => setShowDetails(!showDetails)}
                        className="flex items-center justify-between w-full text-sm font-medium text-muted-foreground hover:text-foreground"
                      >
                        <span>All Convention Results</span>
                        {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>

                      {showDetails && (
                        <div className="space-y-2 pt-2">
                          <div
                            className={`flex items-center justify-between p-2 rounded-lg ${convention === "truncated" ? "bg-blue-100 border border-blue-300" : "bg-muted"}`}
                          >
                            <span className="text-sm font-medium">Truncated (JS/C)</span>
                            <span className="font-mono">{result.truncated}</span>
                          </div>
                          <div
                            className={`flex items-center justify-between p-2 rounded-lg ${convention === "floored" ? "bg-blue-100 border border-blue-300" : "bg-muted"}`}
                          >
                            <span className="text-sm font-medium">Floored (Python)</span>
                            <span className="font-mono">{result.floored}</span>
                          </div>
                          <div
                            className={`flex items-center justify-between p-2 rounded-lg ${convention === "euclidean" ? "bg-blue-100 border border-blue-300" : "bg-muted"}`}
                          >
                            <span className="text-sm font-medium">Euclidean (Math)</span>
                            <span className="font-mono">{result.euclidean}</span>
                          </div>
                          <div className="p-2 rounded-lg bg-green-50 border border-green-200">
                            <p className="text-xs text-green-700 font-medium">Verification</p>
                            <p className="text-sm font-mono text-green-800">{result.verification}</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-Step Solution */}
                {showSteps && steps.length > 0 && (
                  <div className="p-4 rounded-lg bg-muted/50 border">
                    <h4 className="font-semibold mb-3">Step-by-Step Solution</h4>
                    <div className="space-y-3">
                      {steps.map((step) => (
                        <div key={step.step} className="flex gap-3">
                          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-medium">
                            {step.step}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm text-muted-foreground">{step.description}</p>
                            {step.formula && (
                              <p className="font-mono text-sm mt-1 p-2 bg-background rounded border">{step.formula}</p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Convention Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-blue-700">Truncated</span>
                        <span className="text-xs text-blue-600">JS/C/Java</span>
                      </div>
                      <p className="text-xs text-blue-600">Rounds quotient toward zero. Sign follows dividend.</p>
                      <p className="text-xs font-mono mt-1">-17 % 5 = -2</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-green-700">Floored</span>
                        <span className="text-xs text-green-600">Python/Ruby</span>
                      </div>
                      <p className="text-xs text-green-600">Rounds quotient toward -infinity. Sign follows divisor.</p>
                      <p className="text-xs font-mono mt-1">-17 % 5 = 3</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-purple-700">Euclidean</span>
                        <span className="text-xs text-purple-600">Mathematical</span>
                      </div>
                      <p className="text-xs text-purple-600">Result is always non-negative (0 to |n|-1).</p>
                      <p className="text-xs font-mono mt-1">-17 mod 5 = 3</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2 font-medium">a mod n</th>
                          <th className="text-center py-2 font-medium">Trunc</th>
                          <th className="text-center py-2 font-medium">Floor</th>
                          <th className="text-center py-2 font-medium">Euclid</th>
                        </tr>
                      </thead>
                      <tbody className="font-mono text-xs">
                        <tr className="border-b">
                          <td className="py-2">17 % 5</td>
                          <td className="text-center py-2">2</td>
                          <td className="text-center py-2">2</td>
                          <td className="text-center py-2">2</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">-17 % 5</td>
                          <td className="text-center py-2">-2</td>
                          <td className="text-center py-2">3</td>
                          <td className="text-center py-2">3</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">17 % -5</td>
                          <td className="text-center py-2">2</td>
                          <td className="text-center py-2">-3</td>
                          <td className="text-center py-2">2</td>
                        </tr>
                        <tr>
                          <td className="py-2">-17 % -5</td>
                          <td className="text-center py-2">-2</td>
                          <td className="text-center py-2">-2</td>
                          <td className="text-center py-2">3</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Modulus Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">a mod n = a - n × floor(a/n)</p>
                  </div>
                  <p>
                    The modulus operation finds the remainder after division. The result depends on how the quotient is
                    rounded.
                  </p>
                  <div className="text-xs space-y-1">
                    <p>
                      <strong>a</strong> = dividend (number being divided)
                    </p>
                    <p>
                      <strong>n</strong> = divisor (number dividing by)
                    </p>
                    <p>
                      <strong>r</strong> = remainder (result)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Modulus?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The modulus operation (also called modulo or mod) finds the remainder when one integer is divided by
                  another. For example, 17 mod 5 equals 2 because 17 = 5 × 3 + 2. The modulus is fundamental in computer
                  science, cryptography, and number theory. It is used extensively in hash functions, circular buffers,
                  clock arithmetic, and determining if numbers are even or odd.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  While the concept seems simple for positive numbers, handling negative numbers requires choosing a
                  convention. Different programming languages use different conventions, which can lead to unexpected
                  results when working across languages. Understanding these differences is crucial for writing portable
                  code and debugging cross-platform applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Modulus Conventions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Truncated Division</strong> (JavaScript, C, Java): The quotient is rounded toward zero, and
                  the remainder has the same sign as the dividend. This is the most common convention in low-level
                  programming languages.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Floored Division</strong> (Python, Ruby): The quotient is rounded toward negative infinity,
                  and the remainder has the same sign as the divisor. This convention is often preferred in mathematical
                  applications because it provides more predictable behavior with negative numbers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Euclidean Modulus</strong>: The remainder is always non-negative, ranging from 0 to |n|-1.
                  This is the traditional mathematical definition and is particularly useful in number theory and
                  cryptographic applications where negative remainders would be problematic.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-yellow-50 border-yellow-200">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Modulus calculations follow standard arithmetic rules. Results may vary based on the handling of
                  negative numbers and selected conventions. Always verify which convention your programming language
                  uses when working with negative numbers, and consider using the Euclidean modulus for mathematical
                  applications requiring non-negative results.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
