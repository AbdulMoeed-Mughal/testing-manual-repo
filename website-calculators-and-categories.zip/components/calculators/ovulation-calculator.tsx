"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Heart,
  Info,
  AlertTriangle,
  Calendar,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface OvulationResult {
  ovulationDate: Date
  fertileWindowStart: Date
  fertileWindowEnd: Date
  nextPeriodDate: Date
  currentPhase: string
  phaseColor: string
  phaseBgColor: string
  daysUntilOvulation: number
  daysUntilPeriod: number
}

export function OvulationCalculator() {
  const [lastPeriodDate, setLastPeriodDate] = useState("")
  const [cycleLength, setCycleLength] = useState("28")
  const [lutealPhaseLength, setLutealPhaseLength] = useState("14")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<OvulationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateOvulation = () => {
    setError("")
    setResult(null)

    if (!lastPeriodDate) {
      setError("Please enter your last menstrual period date")
      return
    }

    const cycleLengthNum = Number.parseInt(cycleLength)
    const lutealLengthNum = Number.parseInt(lutealPhaseLength)

    if (isNaN(cycleLengthNum) || cycleLengthNum < 21 || cycleLengthNum > 45) {
      setError("Cycle length should be between 21 and 45 days")
      return
    }

    if (isNaN(lutealLengthNum) || lutealLengthNum < 10 || lutealLengthNum > 16) {
      setError("Luteal phase length should be between 10 and 16 days")
      return
    }

    const lmpDate = new Date(lastPeriodDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    // Calculate ovulation day: LMP + (Cycle length - Luteal phase length)
    const ovulationDay = cycleLengthNum - lutealLengthNum
    const ovulationDate = new Date(lmpDate)
    ovulationDate.setDate(lmpDate.getDate() + ovulationDay)

    // Fertile window: 5 days before ovulation to 1 day after
    const fertileWindowStart = new Date(ovulationDate)
    fertileWindowStart.setDate(ovulationDate.getDate() - 5)

    const fertileWindowEnd = new Date(ovulationDate)
    fertileWindowEnd.setDate(ovulationDate.getDate() + 1)

    // Next period date
    const nextPeriodDate = new Date(lmpDate)
    nextPeriodDate.setDate(lmpDate.getDate() + cycleLengthNum)

    // Calculate days until ovulation and period
    const daysUntilOvulation = Math.ceil((ovulationDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    const daysUntilPeriod = Math.ceil((nextPeriodDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

    // Determine current phase
    const dayOfCycle = Math.ceil((today.getTime() - lmpDate.getTime()) / (1000 * 60 * 60 * 24)) + 1
    let currentPhase: string
    let phaseColor: string
    let phaseBgColor: string

    if (dayOfCycle <= 0 || dayOfCycle > cycleLengthNum) {
      currentPhase = "New Cycle Expected"
      phaseColor = "text-gray-600"
      phaseBgColor = "bg-gray-50 border-gray-200"
    } else if (dayOfCycle <= 5) {
      currentPhase = "Menstrual Phase"
      phaseColor = "text-red-600"
      phaseBgColor = "bg-red-50 border-red-200"
    } else if (dayOfCycle < ovulationDay - 5) {
      currentPhase = "Follicular Phase"
      phaseColor = "text-blue-600"
      phaseBgColor = "bg-blue-50 border-blue-200"
    } else if (dayOfCycle <= ovulationDay + 1) {
      currentPhase = "Fertile Window"
      phaseColor = "text-green-600"
      phaseBgColor = "bg-green-50 border-green-200"
    } else {
      currentPhase = "Luteal Phase"
      phaseColor = "text-purple-600"
      phaseBgColor = "bg-purple-50 border-purple-200"
    }

    setResult({
      ovulationDate,
      fertileWindowStart,
      fertileWindowEnd,
      nextPeriodDate,
      currentPhase,
      phaseColor,
      phaseBgColor,
      daysUntilOvulation,
      daysUntilPeriod,
    })
  }

  const handleReset = () => {
    setLastPeriodDate("")
    setCycleLength("28")
    setLutealPhaseLength("14")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Ovulation Calculator Results:
Ovulation Date: ${formatDate(result.ovulationDate)}
Fertile Window: ${formatDate(result.fertileWindowStart)} - ${formatDate(result.fertileWindowEnd)}
Next Period: ${formatDate(result.nextPeriodDate)}
Current Phase: ${result.currentPhase}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Ovulation Calculator Results",
          text: `I calculated my ovulation using CalcHub! Ovulation Date: ${formatDate(result.ovulationDate)}, Fertile Window: ${formatDate(result.fertileWindowStart)} - ${formatDate(result.fertileWindowEnd)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Heart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Ovulation Calculator</CardTitle>
                    <CardDescription>Predict ovulation and fertile window</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Last Period Date */}
                <div className="space-y-2">
                  <Label htmlFor="lastPeriod">First Day of Last Period</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="lastPeriod"
                      type="date"
                      value={lastPeriodDate}
                      onChange={(e) => setLastPeriodDate(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Cycle Length */}
                <div className="space-y-2">
                  <Label htmlFor="cycleLength">Average Cycle Length (days)</Label>
                  <Input
                    id="cycleLength"
                    type="number"
                    placeholder="28"
                    value={cycleLength}
                    onChange={(e) => setCycleLength(e.target.value)}
                    min="21"
                    max="45"
                  />
                  <p className="text-xs text-muted-foreground">Typical range: 21-35 days</p>
                </div>

                {/* Advanced Options Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="advanced" className="text-sm">
                    Advanced Options
                  </Label>
                  <Switch id="advanced" checked={showAdvanced} onCheckedChange={setShowAdvanced} />
                </div>

                {/* Advanced Options */}
                {showAdvanced && (
                  <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                    <div className="space-y-2">
                      <Label htmlFor="lutealPhase">Luteal Phase Length (days)</Label>
                      <Input
                        id="lutealPhase"
                        type="number"
                        placeholder="14"
                        value={lutealPhaseLength}
                        onChange={(e) => setLutealPhaseLength(e.target.value)}
                        min="10"
                        max="16"
                      />
                      <p className="text-xs text-muted-foreground">Default is 14 days (typical range: 10-16)</p>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateOvulation} className="w-full" size="lg">
                  Calculate Ovulation
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.phaseBgColor} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Current Phase</p>
                      <p className={`text-2xl font-bold ${result.phaseColor}`}>{result.currentPhase}</p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center p-3 bg-white/80 rounded-lg">
                        <span className="text-sm font-medium">Ovulation Date</span>
                        <span className="text-sm font-semibold text-green-600">{formatDate(result.ovulationDate)}</span>
                      </div>

                      <div className="flex justify-between items-center p-3 bg-white/80 rounded-lg">
                        <span className="text-sm font-medium">Fertile Window</span>
                        <span className="text-sm font-semibold text-pink-600">
                          {formatDate(result.fertileWindowStart).split(",")[0]} -{" "}
                          {formatDate(result.fertileWindowEnd).split(",")[0]}
                        </span>
                      </div>

                      <div className="flex justify-between items-center p-3 bg-white/80 rounded-lg">
                        <span className="text-sm font-medium">Next Period</span>
                        <span className="text-sm font-semibold text-red-600">{formatDate(result.nextPeriodDate)}</span>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 p-4 bg-white/60 rounded-lg space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Days Until Ovulation</span>
                          <span className="font-medium">
                            {result.daysUntilOvulation > 0
                              ? `${result.daysUntilOvulation} days`
                              : result.daysUntilOvulation === 0
                                ? "Today!"
                                : "Passed"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Days Until Next Period</span>
                          <span className="font-medium">
                            {result.daysUntilPeriod > 0
                              ? `${result.daysUntilPeriod} days`
                              : result.daysUntilPeriod === 0
                                ? "Today"
                                : "Overdue"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Peak Fertility Days</span>
                          <span className="font-medium">
                            {(() => {
                              const peakStart = new Date(result.ovulationDate)
                              peakStart.setDate(result.ovulationDate.getDate() - 2)
                              return `${formatDate(peakStart).split(",")[0]} - ${formatDate(result.ovulationDate).split(",")[0]}`
                            })()}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cycle Phases</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Menstrual</span>
                      <span className="text-sm text-red-600">Days 1-5</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Follicular</span>
                      <span className="text-sm text-blue-600">Days 6-13</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Ovulation</span>
                      <span className="text-sm text-green-600">Day 14 (varies)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Luteal</span>
                      <span className="text-sm text-purple-600">Days 15-28</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Ovulation Day = Cycle Length - Luteal Phase</p>
                  </div>
                  <p>
                    The fertile window extends from <strong>5 days before</strong> to <strong>1 day after</strong>{" "}
                    ovulation, as sperm can survive up to 5 days in the reproductive tract.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Ovulation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ovulation is the release of an egg from one of the ovaries, which typically occurs once per menstrual
                  cycle. This event is crucial for conception, as the released egg can be fertilized by sperm for about
                  12-24 hours after ovulation. Understanding your ovulation timing can help with family planning,
                  whether you&apos;re trying to conceive or avoid pregnancy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The fertile window spans approximately 6 days: the 5 days before ovulation and the day of ovulation
                  itself. This is because sperm can survive in the female reproductive tract for up to 5 days, waiting
                  for an egg to be released. Having intercourse during this window maximizes the chances of conception.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Signs of Ovulation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-pink-50 border border-pink-200 rounded-lg">
                    <h4 className="font-semibold text-pink-800 mb-2">Physical Signs</h4>
                    <ul className="text-pink-700 text-sm space-y-1">
                      <li>Change in cervical mucus (clear, stretchy)</li>
                      <li>Mild pelvic pain or cramping</li>
                      <li>Breast tenderness</li>
                      <li>Increased basal body temperature</li>
                      <li>Light spotting</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Other Indicators</h4>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>Heightened sense of smell</li>
                      <li>Increased libido</li>
                      <li>Positive ovulation test (LH surge)</li>
                      <li>Slight bloating</li>
                      <li>Mood changes</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-amber-800 text-sm leading-relaxed">
                    <strong>Note:</strong> Ovulation predictions are estimates and may vary due to individual cycle
                    differences, stress, illness, or other factors. This calculator should not be used as a sole method
                    of contraception. For personalized fertility guidance or concerns about your menstrual cycle,
                    consult a healthcare professional or reproductive specialist.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
