"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Radio, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type SystemType = "mechanical" | "electrical"

interface ResonantFrequencyResult {
  frequency: number
  frequencyUnit: string
  category: string
  color: string
  bgColor: string
}

export function ResonantFrequencyCalculator() {
  const [systemType, setSystemType] = useState<SystemType>("mechanical")

  // Mechanical system inputs
  const [mass, setMass] = useState("")
  const [massUnit, setMassUnit] = useState("kg")
  const [stiffness, setStiffness] = useState("")
  const [stiffnessUnit, setStiffnessUnit] = useState("N/m")

  // Electrical system inputs
  const [inductance, setInductance] = useState("")
  const [inductanceUnit, setInductanceUnit] = useState("H")
  const [capacitance, setCapacitance] = useState("")
  const [capacitanceUnit, setCapacitanceUnit] = useState("F")

  const [frequencyUnit, setFrequencyUnit] = useState("Hz")

  const [result, setResult] = useState<ResonantFrequencyResult | null>(null)
  const [showSteps, setShowSteps] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateResonantFrequency = () => {
    setError("")
    setResult(null)

    if (systemType === "mechanical") {
      const massNum = Number.parseFloat(mass)
      const stiffnessNum = Number.parseFloat(stiffness)

      if (isNaN(massNum) || massNum <= 0) {
        setError("Please enter a valid mass greater than 0")
        return
      }

      if (isNaN(stiffnessNum) || stiffnessNum <= 0) {
        setError("Please enter a valid stiffness/spring constant greater than 0")
        return
      }

      // Convert mass to kg
      let massKg = massNum
      if (massUnit === "lb") {
        massKg = massNum * 0.453592
      }

      // Convert stiffness to N/m
      let stiffnessNm = stiffnessNum
      if (stiffnessUnit === "lb/ft") {
        stiffnessNm = stiffnessNum * 14.5939
      }

      // Calculate resonant frequency: f = (1 / 2π) × √(k / m)
      const frequencyHz = (1 / (2 * Math.PI)) * Math.sqrt(stiffnessNm / massKg)

      displayResult(frequencyHz)
    } else {
      // Electrical system
      const inductanceNum = Number.parseFloat(inductance)
      const capacitanceNum = Number.parseFloat(capacitance)

      if (isNaN(inductanceNum) || inductanceNum <= 0) {
        setError("Please enter a valid inductance greater than 0")
        return
      }

      if (isNaN(capacitanceNum) || capacitanceNum <= 0) {
        setError("Please enter a valid capacitance greater than 0")
        return
      }

      // Convert inductance to H
      let inductanceH = inductanceNum
      if (inductanceUnit === "mH") {
        inductanceH = inductanceNum / 1000
      } else if (inductanceUnit === "µH") {
        inductanceH = inductanceNum / 1000000
      }

      // Convert capacitance to F
      let capacitanceF = capacitanceNum
      if (capacitanceUnit === "µF") {
        capacitanceF = capacitanceNum / 1000000
      } else if (capacitanceUnit === "nF") {
        capacitanceF = capacitanceNum / 1000000000
      } else if (capacitanceUnit === "pF") {
        capacitanceF = capacitanceNum / 1000000000000
      }

      // Calculate resonant frequency: f = 1 / (2π × √(L × C))
      const frequencyHz = 1 / (2 * Math.PI * Math.sqrt(inductanceH * capacitanceF))

      displayResult(frequencyHz)
    }
  }

  const displayResult = (frequencyHz: number) => {
    // Convert to selected unit
    let displayFrequency = frequencyHz
    if (frequencyUnit === "kHz") {
      displayFrequency = frequencyHz / 1000
    } else if (frequencyUnit === "MHz") {
      displayFrequency = frequencyHz / 1000000
    }

    const roundedFrequency = Math.round(displayFrequency * 1000) / 1000

    let category: string
    let color: string
    let bgColor: string

    if (frequencyHz < 20) {
      category = "Infrasonic"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (frequencyHz < 20000) {
      category = "Audio Range"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (frequencyHz < 1000000) {
      category = "Ultrasonic"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Radio Frequency"
      color = "text-purple-600"
      bgColor = "bg-purple-50 border-purple-200"
    }

    setResult({
      frequency: roundedFrequency,
      frequencyUnit,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setMass("")
    setStiffness("")
    setInductance("")
    setCapacitance("")
    setResult(null)
    setError("")
    setShowSteps(false)
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Resonant Frequency: ${result.frequency} ${result.frequencyUnit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Resonant Frequency Result",
          text: `I calculated a resonant frequency of ${result.frequency} ${result.frequencyUnit} using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleSystemType = () => {
    setSystemType((prev) => (prev === "mechanical" ? "electrical" : "mechanical"))
    handleReset()
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Radio className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Resonant Frequency Calculator</CardTitle>
                    <CardDescription>Calculate natural oscillation frequency</CardDescription>
                  </div>
                </div>

                {/* System Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">System Type</span>
                  <button
                    onClick={toggleSystemType}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        systemType === "electrical" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        systemType === "mechanical" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Mechanical
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        systemType === "electrical" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Electrical
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {systemType === "mechanical" ? (
                  <>
                    {/* Mass Input */}
                    <div className="space-y-2">
                      <Label htmlFor="mass">Mass (m)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="mass"
                          type="number"
                          placeholder="Enter mass"
                          value={mass}
                          onChange={(e) => setMass(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <select
                          value={massUnit}
                          onChange={(e) => setMassUnit(e.target.value)}
                          className="w-20 rounded-md border border-input bg-background px-3 text-sm"
                        >
                          <option value="kg">kg</option>
                          <option value="lb">lb</option>
                        </select>
                      </div>
                    </div>

                    {/* Stiffness Input */}
                    <div className="space-y-2">
                      <Label htmlFor="stiffness">Stiffness / Spring Constant (k)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="stiffness"
                          type="number"
                          placeholder="Enter stiffness"
                          value={stiffness}
                          onChange={(e) => setStiffness(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <select
                          value={stiffnessUnit}
                          onChange={(e) => setStiffnessUnit(e.target.value)}
                          className="w-24 rounded-md border border-input bg-background px-3 text-sm"
                        >
                          <option value="N/m">N/m</option>
                          <option value="lb/ft">lb/ft</option>
                        </select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Inductance Input */}
                    <div className="space-y-2">
                      <Label htmlFor="inductance">Inductance (L)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="inductance"
                          type="number"
                          placeholder="Enter inductance"
                          value={inductance}
                          onChange={(e) => setInductance(e.target.value)}
                          min="0"
                          step="0.000001"
                          className="flex-1"
                        />
                        <select
                          value={inductanceUnit}
                          onChange={(e) => setInductanceUnit(e.target.value)}
                          className="w-20 rounded-md border border-input bg-background px-3 text-sm"
                        >
                          <option value="H">H</option>
                          <option value="mH">mH</option>
                          <option value="µH">µH</option>
                        </select>
                      </div>
                    </div>

                    {/* Capacitance Input */}
                    <div className="space-y-2">
                      <Label htmlFor="capacitance">Capacitance (C)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="capacitance"
                          type="number"
                          placeholder="Enter capacitance"
                          value={capacitance}
                          onChange={(e) => setCapacitance(e.target.value)}
                          min="0"
                          step="0.000000000001"
                          className="flex-1"
                        />
                        <select
                          value={capacitanceUnit}
                          onChange={(e) => setCapacitanceUnit(e.target.value)}
                          className="w-20 rounded-md border border-input bg-background px-3 text-sm"
                        >
                          <option value="F">F</option>
                          <option value="µF">µF</option>
                          <option value="nF">nF</option>
                          <option value="pF">pF</option>
                        </select>
                      </div>
                    </div>
                  </>
                )}

                {/* Frequency Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="frequencyUnit">Output Frequency Unit</Label>
                  <select
                    id="frequencyUnit"
                    value={frequencyUnit}
                    onChange={(e) => setFrequencyUnit(e.target.value)}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="Hz">Hz (Hertz)</option>
                    <option value="kHz">kHz (Kilohertz)</option>
                    <option value="MHz">MHz (Megahertz)</option>
                  </select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateResonantFrequency} className="w-full" size="lg">
                  Calculate Resonant Frequency
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Resonant Frequency</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>
                        {result.frequency}
                        <span className="text-2xl ml-2">{result.frequencyUnit}</span>
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>

                    {/* Toggle Steps */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {/* Steps Breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-4 bg-background/50 rounded-lg space-y-2 text-sm">
                        <p className="font-semibold text-foreground">Step-by-Step Calculation:</p>
                        {systemType === "mechanical" ? (
                          <>
                            <p className="text-muted-foreground">
                              <strong>Formula:</strong> f = (1 / 2π) × √(k / m)
                            </p>
                            <p className="text-muted-foreground">
                              <strong>Given:</strong> m = {mass} {massUnit}, k = {stiffness} {stiffnessUnit}
                            </p>
                            <p className="text-muted-foreground">
                              <strong>Result:</strong> f = {result.frequency} {result.frequencyUnit}
                            </p>
                          </>
                        ) : (
                          <>
                            <p className="text-muted-foreground">
                              <strong>Formula:</strong> f = 1 / (2π × √(L × C))
                            </p>
                            <p className="text-muted-foreground">
                              <strong>Given:</strong> L = {inductance} {inductanceUnit}, C = {capacitance}{" "}
                              {capacitanceUnit}
                            </p>
                            <p className="text-muted-foreground">
                              <strong>Result:</strong> f = {result.frequency} {result.frequencyUnit}
                            </p>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Resonant Frequency Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-semibold text-blue-800 mb-1">Mechanical System</p>
                    <p className="text-sm text-blue-700 font-mono">f = (1 / 2π) × √(k / m)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-semibold text-purple-800 mb-1">Electrical System (LC Circuit)</p>
                    <p className="text-sm text-purple-700 font-mono">f = 1 / (2π × √(L × C))</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <p className="text-muted-foreground">Tuning radio receivers and transmitters</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <p className="text-muted-foreground">Designing mechanical vibration isolators</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <p className="text-muted-foreground">Musical instrument acoustics</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <p className="text-muted-foreground">Earthquake engineering and structural analysis</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Resonant Frequency?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Resonant frequency is the natural frequency at which a system tends to oscillate with maximum
                  amplitude when disturbed from equilibrium. Every physical system that can store and transfer energy
                  between two forms (such as kinetic and potential energy in mechanical systems, or electric and
                  magnetic energy in electrical systems) has one or more resonant frequencies. At these frequencies,
                  even small periodic driving forces can produce large amplitude oscillations because the system stores
                  energy efficiently.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding resonance is crucial in engineering and physics because it can be both beneficial and
                  destructive. Engineers design systems to either exploit resonance (as in musical instruments and radio
                  tuners) or avoid it (as in buildings during earthquakes). The resonant frequency depends on the
                  system's physical properties: in mechanical systems, it's determined by mass and stiffness; in
                  electrical LC circuits, it's determined by inductance and capacitance.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Resonant frequency calculations assume ideal systems with negligible damping. Actual resonance may
                  vary due to friction, resistance, or non-ideal components. Consult physics or engineering references
                  for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
