"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Package, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface MortarResult {
  cementBags: number
  cementKg: number
  sandVolume: number
  sandWeight: number
  waterVolume: number
}

export function MortarMixCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [volume, setVolume] = useState("")
  const [mixRatio, setMixRatio] = useState("1:4")
  const [cementBagSize, setCementBagSize] = useState("50")
  const [waterCementRatio, setWaterCementRatio] = useState("0.5")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<MortarResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateMortar = () => {
    setError("")
    setResult(null)

    const volumeNum = parseFloat(volume)
    const wastageNum = parseFloat(wastage)
    const cementBagSizeNum = parseFloat(cementBagSize)
    const waterCementRatioNum = parseFloat(waterCementRatio)

    if (isNaN(volumeNum) || volumeNum <= 0) {
      setError("Please enter a valid volume greater than 0")
      return
    }

    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }

    if (isNaN(cementBagSizeNum) || cementBagSizeNum <= 0) {
      setError("Please enter a valid bag size")
      return
    }

    // Parse mix ratio
    const [cementPart, sandPart] = mixRatio.split(":").map(Number)
    if (!cementPart || !sandPart) {
      setError("Invalid mix ratio")
      return
    }

    // Convert to cubic meters if imperial
    const volumeM3 = unitSystem === "imperial" ? volumeNum * 0.0283168 : volumeNum

    // Calculate dry volume (wet volume × 1.33)
    const dryVolume = volumeM3 * 1.33

    // Add wastage
    const totalVolume = dryVolume * (1 + wastageNum / 100)

    // Calculate parts
    const totalParts = cementPart + sandPart
    const cementVolume = totalVolume * (cementPart / totalParts)
    const sandVolume = totalVolume * (sandPart / totalParts)

    // Calculate weights
    const cementDensity = 1440 // kg/m³
    const sandDensity = 1600 // kg/m³

    const cementWeight = cementVolume * cementDensity
    const sandWeight = sandVolume * sandDensity
    const cementBags = cementWeight / cementBagSizeNum

    // Calculate water if ratio provided
    const waterVolume = waterCementRatioNum > 0 ? cementWeight * waterCementRatioNum : 0

    setResult({
      cementBags: Math.ceil(cementBags * 10) / 10,
      cementKg: Math.round(cementWeight * 10) / 10,
      sandVolume: Math.round(sandVolume * 1000) / 1000,
      sandWeight: Math.round(sandWeight * 10) / 10,
      waterVolume: Math.round(waterVolume * 10) / 10,
    })
  }

  const handleReset = () => {
    setVolume("")
    setMixRatio("1:4")
    setCementBagSize("50")
    setWaterCementRatio("0.5")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Mortar Mix Calculator Results:\nCement: ${result.cementBags} bags (${result.cementKg} kg)\nSand: ${result.sandVolume} m³ (${result.sandWeight} kg)\nWater: ${result.waterVolume} L`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Mortar Mix Calculator Results",
          text: `Cement: ${result.cementBags} bags (${result.cementKg} kg), Sand: ${result.sandVolume} m³, Water: ${result.waterVolume} L`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setVolume("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Package className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Mortar Mix Calculator</CardTitle>
                    <CardDescription>Calculate cement, sand, and water for mortar</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="volume">Mortar Volume ({unitSystem === "metric" ? "m³" : "ft³"})</Label>
                  <Input
                    id="volume"
                    type="number"
                    placeholder={`Enter volume in ${unitSystem === "metric" ? "cubic meters" : "cubic feet"}`}
                    value={volume}
                    onChange={(e) => setVolume(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mixRatio">Mix Ratio (Cement:Sand)</Label>
                  <Select value={mixRatio} onValueChange={setMixRatio}>
                    <SelectTrigger id="mixRatio">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1:3">1:3 (Strong mortar)</SelectItem>
                      <SelectItem value="1:4">1:4 (Standard mortar)</SelectItem>
                      <SelectItem value="1:5">1:5 (Weak mortar)</SelectItem>
                      <SelectItem value="1:6">1:6 (Lime mortar)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="bagSize">Cement Bag (kg)</Label>
                    <Select value={cementBagSize} onValueChange={setCementBagSize}>
                      <SelectTrigger id="bagSize">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="25">25 kg</SelectItem>
                        <SelectItem value="50">50 kg</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="wastage">Wastage (%)</Label>
                    <Input
                      id="wastage"
                      type="number"
                      placeholder="5-10%"
                      value={wastage}
                      onChange={(e) => setWastage(e.target.value)}
                      min="0"
                      max="30"
                      step="1"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="waterRatio">Water-Cement Ratio</Label>
                  <Input
                    id="waterRatio"
                    type="number"
                    placeholder="0.5"
                    value={waterCementRatio}
                    onChange={(e) => setWaterCementRatio(e.target.value)}
                    min="0"
                    max="1"
                    step="0.05"
                  />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculateMortar} className="w-full" size="lg">
                  Calculate Materials
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Material Requirements</p>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-amber-900">Cement</span>
                          <span className="text-lg font-bold text-amber-700">
                            {result.cementBags} bags ({result.cementKg} kg)
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-amber-900">Sand</span>
                          <span className="text-lg font-bold text-amber-700">
                            {result.sandVolume} m³ ({result.sandWeight} kg)
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-amber-900">Water</span>
                          <span className="text-lg font-bold text-amber-700">{result.waterVolume} L</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4 pt-3 border-t border-amber-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Mix Ratios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-900">1:3</span>
                      <span className="text-sm text-amber-700">Strong (Walls, pillars)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-900">1:4</span>
                      <span className="text-sm text-amber-700">Standard (Brickwork)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-900">1:5</span>
                      <span className="text-sm text-amber-700">Weak (Internal)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-900">1:6</span>
                      <span className="text-sm text-amber-700">Lime (Plastering)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Note</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    <strong>Dry Volume Factor:</strong> Mortar expands when mixed with water, so the dry volume is
                    calculated as wet volume × 1.33 to account for this.
                  </p>
                  <p>
                    <strong>Wastage:</strong> Add 5-10% extra material to account for spillage, uneven surfaces, and
                    material loss during construction.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Mortar Mix?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Mortar is a workable paste that binds building blocks such as bricks, stones, and concrete masonry
                  units together. It consists of cement, sand, and water mixed in specific proportions. The mix ratio
                  determines the strength and workability of the mortar, with different ratios suitable for different
                  applications in construction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The most common mortar mix is 1:4 (cement:sand), which provides good strength for general brickwork
                  and blockwork. Stronger mixes like 1:3 are used for structural walls and pillars, while weaker mixes
                  like 1:6 are suitable for internal plastering and non-load-bearing walls. The water-cement ratio
                  affects the mortar's consistency and curing strength.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Mortar Materials</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Mortar calculation starts with determining the wet volume required for your project. This is
                  converted to dry volume by multiplying by 1.33 (approximately 1.54 for some standards), as dry
                  materials occupy more space before water is added. The dry volume is then divided according to the
                  mix ratio parts to find individual material quantities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, in a 1:4 mix ratio, the total parts are 5 (1 part cement + 4 parts sand). If the dry
                  volume is 1 m³, cement volume = 1/5 = 0.2 m³, and sand volume = 4/5 = 0.8 m³. These volumes are then
                  converted to weight using standard densities: cement at 1440 kg/m³ and sand at 1600 kg/m³. Adding
                  5-10% wastage ensures adequate material for the project.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <p className="text-amber-900 text-sm leading-relaxed m-0">
                    <strong>Disclaimer:</strong> These calculations are approximate estimates. Actual quantities may
                    vary based on mortar consistency requirements, joint thickness, surface conditions, and site
                    practices. Always order slightly more material than calculated. Consult with structural engineers
                    for load-bearing walls and critical applications. Material quality and proper mixing ratios are
                    essential for structural integrity.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
