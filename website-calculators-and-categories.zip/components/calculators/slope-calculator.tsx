"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, TrendingUp, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type InputMode = "points" | "equation"

interface SlopeResult {
  slope: number | null
  isVertical: boolean
  isHorizontal: boolean
  angle: number | null
  angleDeg: number | null
  lineEquation: string
  yIntercept: number | null
}

export function SlopeCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("points")
  const [x1, setX1] = useState("")
  const [y1, setY1] = useState("")
  const [x2, setX2] = useState("")
  const [y2, setY2] = useState("")
  const [equation, setEquation] = useState("")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<SlopeResult | null>(null)
  const [steps, setSteps] = useState<string[]>([])
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateFromPoints = () => {
    const x1Num = Number.parseFloat(x1)
    const y1Num = Number.parseFloat(y1)
    const x2Num = Number.parseFloat(x2)
    const y2Num = Number.parseFloat(y2)

    if (isNaN(x1Num) || isNaN(y1Num) || isNaN(x2Num) || isNaN(y2Num)) {
      setError("Please enter valid numbers for all coordinates")
      return
    }

    if (x1Num === x2Num && y1Num === y2Num) {
      setError("Points are identical. Please enter two different points.")
      return
    }

    const calcSteps: string[] = []
    calcSteps.push(`Given points: (${x1Num}, ${y1Num}) and (${x2Num}, ${y2Num})`)
    calcSteps.push(`Slope formula: m = (y₂ - y₁) / (x₂ - x₁)`)

    const deltaY = y2Num - y1Num
    const deltaX = x2Num - x1Num

    calcSteps.push(`Δy = y₂ - y₁ = ${y2Num} - ${y1Num} = ${deltaY}`)
    calcSteps.push(`Δx = x₂ - x₁ = ${x2Num} - ${x1Num} = ${deltaX}`)

    if (deltaX === 0) {
      calcSteps.push(`Since Δx = 0, the line is vertical`)
      calcSteps.push(`Slope is undefined for vertical lines`)

      setResult({
        slope: null,
        isVertical: true,
        isHorizontal: false,
        angle: Math.PI / 2,
        angleDeg: 90,
        lineEquation: `x = ${x1Num}`,
        yIntercept: null,
      })
      setSteps(calcSteps)
      return
    }

    const slope = deltaY / deltaX
    calcSteps.push(`m = ${deltaY} / ${deltaX} = ${slope}`)

    const angle = Math.atan(slope)
    const angleDeg = (angle * 180) / Math.PI
    calcSteps.push(`Angle θ = arctan(${slope}) = ${angleDeg.toFixed(4)}°`)

    // Calculate y-intercept: y = mx + b => b = y - mx
    const yIntercept = y1Num - slope * x1Num
    calcSteps.push(`y-intercept: b = y₁ - m·x₁ = ${y1Num} - (${slope})(${x1Num}) = ${yIntercept}`)

    // Generate line equation
    let lineEquation = ""
    if (slope === 0) {
      lineEquation = `y = ${yIntercept}`
    } else if (yIntercept === 0) {
      lineEquation = `y = ${slope}x`
    } else if (yIntercept > 0) {
      lineEquation = `y = ${slope}x + ${yIntercept}`
    } else {
      lineEquation = `y = ${slope}x - ${Math.abs(yIntercept)}`
    }
    calcSteps.push(`Line equation: ${lineEquation}`)

    setResult({
      slope,
      isVertical: false,
      isHorizontal: slope === 0,
      angle,
      angleDeg,
      lineEquation,
      yIntercept,
    })
    setSteps(calcSteps)
  }

  const calculateFromEquation = () => {
    const eq = equation.trim().toLowerCase().replace(/\s+/g, "")

    const calcSteps: string[] = []
    calcSteps.push(`Input equation: ${equation}`)

    // Try slope-intercept form: y = mx + b
    const slopeInterceptMatch = eq.match(/^y=([+-]?\d*\.?\d*)x([+-]\d*\.?\d*)?$/)
    if (slopeInterceptMatch) {
      const slope =
        slopeInterceptMatch[1] === "" || slopeInterceptMatch[1] === "+"
          ? 1
          : slopeInterceptMatch[1] === "-"
            ? -1
            : Number.parseFloat(slopeInterceptMatch[1])
      const yIntercept = slopeInterceptMatch[2] ? Number.parseFloat(slopeInterceptMatch[2]) : 0

      calcSteps.push(`Recognized slope-intercept form: y = mx + b`)
      calcSteps.push(`Slope m = ${slope}`)
      calcSteps.push(`y-intercept b = ${yIntercept}`)

      const angle = Math.atan(slope)
      const angleDeg = (angle * 180) / Math.PI
      calcSteps.push(`Angle θ = arctan(${slope}) = ${angleDeg.toFixed(4)}°`)

      setResult({
        slope,
        isVertical: false,
        isHorizontal: slope === 0,
        angle,
        angleDeg,
        lineEquation: equation,
        yIntercept,
      })
      setSteps(calcSteps)
      return
    }

    // Try y = b (horizontal line)
    const horizontalMatch = eq.match(/^y=([+-]?\d*\.?\d+)$/)
    if (horizontalMatch) {
      const yIntercept = Number.parseFloat(horizontalMatch[1])
      calcSteps.push(`Recognized horizontal line: y = ${yIntercept}`)
      calcSteps.push(`Slope m = 0 (horizontal line)`)
      calcSteps.push(`Angle θ = 0°`)

      setResult({
        slope: 0,
        isVertical: false,
        isHorizontal: true,
        angle: 0,
        angleDeg: 0,
        lineEquation: `y = ${yIntercept}`,
        yIntercept,
      })
      setSteps(calcSteps)
      return
    }

    // Try x = c (vertical line)
    const verticalMatch = eq.match(/^x=([+-]?\d*\.?\d+)$/)
    if (verticalMatch) {
      const xValue = Number.parseFloat(verticalMatch[1])
      calcSteps.push(`Recognized vertical line: x = ${xValue}`)
      calcSteps.push(`Slope is undefined (vertical line)`)
      calcSteps.push(`Angle θ = 90°`)

      setResult({
        slope: null,
        isVertical: true,
        isHorizontal: false,
        angle: Math.PI / 2,
        angleDeg: 90,
        lineEquation: `x = ${xValue}`,
        yIntercept: null,
      })
      setSteps(calcSteps)
      return
    }

    // Try standard form: ax + by + c = 0 or ax + by = c
    const standardMatch = eq.match(/^([+-]?\d*\.?\d*)x([+-]\d*\.?\d*)y([+-=]\d*\.?\d*)?=?(\d*\.?\d*)?$/)
    if (standardMatch) {
      // Parse coefficients
      const a =
        standardMatch[1] === "" || standardMatch[1] === "+"
          ? 1
          : standardMatch[1] === "-"
            ? -1
            : Number.parseFloat(standardMatch[1])
      const b = standardMatch[2] === "+" ? 1 : standardMatch[2] === "-" ? -1 : Number.parseFloat(standardMatch[2])

      calcSteps.push(`Recognized standard form: ${a}x + ${b}y = c`)

      if (b === 0) {
        calcSteps.push(`Since coefficient of y is 0, this is a vertical line`)
        calcSteps.push(`Slope is undefined`)

        setResult({
          slope: null,
          isVertical: true,
          isHorizontal: false,
          angle: Math.PI / 2,
          angleDeg: 90,
          lineEquation: equation,
          yIntercept: null,
        })
        setSteps(calcSteps)
        return
      }

      const slope = -a / b
      calcSteps.push(`Converting to slope-intercept form: y = -a/b·x + c/b`)
      calcSteps.push(`Slope m = -a/b = -${a}/${b} = ${slope}`)

      const angle = Math.atan(slope)
      const angleDeg = (angle * 180) / Math.PI
      calcSteps.push(`Angle θ = arctan(${slope}) = ${angleDeg.toFixed(4)}°`)

      setResult({
        slope,
        isVertical: false,
        isHorizontal: slope === 0,
        angle,
        angleDeg,
        lineEquation: equation,
        yIntercept: null,
      })
      setSteps(calcSteps)
      return
    }

    setError("Could not parse equation. Try formats like: y = 2x + 3, y = -x, x = 5, or 2x + 3y = 6")
  }

  const handleCalculate = () => {
    setError("")
    setResult(null)
    setSteps([])

    if (inputMode === "points") {
      calculateFromPoints()
    } else {
      calculateFromEquation()
    }
  }

  const handleReset = () => {
    setX1("")
    setY1("")
    setX2("")
    setY2("")
    setEquation("")
    setResult(null)
    setSteps([])
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.isVertical
        ? `Slope: Undefined (Vertical Line)\nLine Equation: ${result.lineEquation}\nAngle: 90°`
        : `Slope: ${result.slope}\nLine Equation: ${result.lineEquation}\nAngle: ${result.angleDeg?.toFixed(4)}°`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatNumber = (num: number | null, decimals = 4): string => {
    if (num === null) return "Undefined"
    return Number.isInteger(num) ? num.toString() : num.toFixed(decimals)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Slope Calculator</CardTitle>
                    <CardDescription>Calculate slope from points or equation</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Type</span>
                  <button
                    onClick={() => {
                      setInputMode(inputMode === "points" ? "equation" : "points")
                      handleReset()
                    }}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "equation" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "points" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Points
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "equation" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Equation
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {inputMode === "points" ? (
                  <>
                    <div className="space-y-2">
                      <Label>Point 1 (x₁, y₁)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          type="number"
                          placeholder="x₁"
                          value={x1}
                          onChange={(e) => setX1(e.target.value)}
                          step="any"
                        />
                        <Input
                          type="number"
                          placeholder="y₁"
                          value={y1}
                          onChange={(e) => setY1(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Point 2 (x₂, y₂)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          type="number"
                          placeholder="x₂"
                          value={x2}
                          onChange={(e) => setX2(e.target.value)}
                          step="any"
                        />
                        <Input
                          type="number"
                          placeholder="y₂"
                          value={y2}
                          onChange={(e) => setY2(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="equation">Linear Equation</Label>
                    <Input
                      id="equation"
                      type="text"
                      placeholder="e.g., y = 2x + 3, x = 5, 2x + 3y = 6"
                      value={equation}
                      onChange={(e) => setEquation(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Supported formats: y = mx + b, y = c, x = c, ax + by = c
                    </p>
                  </div>
                )}

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step</Label>
                  <button
                    id="show-steps"
                    onClick={() => setShowSteps(!showSteps)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      showSteps ? "bg-primary" : "bg-muted"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        showSteps ? "translate-x-6" : "translate-x-1"
                      }`}
                    />
                  </button>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={handleCalculate} className="w-full" size="lg">
                  Calculate Slope
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Slope (m)</p>
                      <p className="text-5xl font-bold text-blue-600 mb-2">
                        {result.isVertical ? "Undefined" : formatNumber(result.slope, 4)}
                      </p>
                      <p className="text-lg font-semibold text-blue-600">
                        {result.isVertical ? "Vertical Line" : result.isHorizontal ? "Horizontal Line" : ""}
                      </p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white/70 rounded-lg text-center">
                        <p className="text-muted-foreground">Angle</p>
                        <p className="font-semibold">{formatNumber(result.angleDeg, 2)}°</p>
                      </div>
                      <div className="p-2 bg-white/70 rounded-lg text-center">
                        <p className="text-muted-foreground">y-intercept</p>
                        <p className="font-semibold">{formatNumber(result.yIntercept, 4)}</p>
                      </div>
                    </div>

                    <div className="mt-3 p-3 bg-white/70 rounded-lg text-center">
                      <p className="text-muted-foreground text-sm">Line Equation</p>
                      <p className="font-mono font-semibold text-lg">{result.lineEquation}</p>
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-step breakdown */}
                {showSteps && steps.length > 0 && (
                  <Collapsible defaultOpen>
                    <CollapsibleTrigger asChild>
                      <Button variant="outline" className="w-full justify-between bg-transparent">
                        Step-by-Step Solution
                        <Calculator className="h-4 w-4" />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-2">
                      <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                        {steps.map((step, index) => (
                          <div key={index} className="flex gap-3">
                            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                              {index + 1}
                            </span>
                            <p className="text-sm font-mono">{step}</p>
                          </div>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Slope Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="font-semibold text-foreground">m = (y₂ - y₁) / (x₂ - x₁)</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>m</strong> = slope of the line
                    </p>
                    <p>
                      <strong>(x₁, y₁)</strong> = first point
                    </p>
                    <p>
                      <strong>(x₂, y₂)</strong> = second point
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">(0, 0) and (1, 1)</span>
                      <span className="text-sm text-blue-600">m = 1</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">(0, 0) and (2, 4)</span>
                      <span className="text-sm text-green-600">m = 2</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">(0, 0) and (1, -1)</span>
                      <span className="text-sm text-yellow-600">m = -1</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">(0, 5) and (5, 5)</span>
                      <span className="text-sm text-purple-600">m = 0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Slope Types</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Positive Slope (m {">"} 0)</p>
                    <p>Line rises from left to right</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Negative Slope (m {"<"} 0)</p>
                    <p>Line falls from left to right</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Zero Slope (m = 0)</p>
                    <p>Horizontal line</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground">Undefined Slope</p>
                    <p>Vertical line</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Slope?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Slope is a fundamental concept in algebra and geometry that measures the steepness and direction of a
                  line. It represents the rate of change between two points on a line, describing how much the y-value
                  changes for each unit change in the x-value. The slope is often denoted by the letter "m" and is
                  calculated as the ratio of the vertical change (rise) to the horizontal change (run) between two
                  points.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding slope is essential for many applications including physics (velocity and acceleration),
                  economics (rate of change in prices or demand), engineering (grade of roads and ramps), and data
                  analysis (trend lines and linear regression). A positive slope indicates an upward trend, a negative
                  slope indicates a downward trend, a zero slope represents a horizontal line, and an undefined slope
                  represents a vertical line.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Angle of a Line</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The angle of a line with respect to the x-axis can be calculated using the arctangent (inverse
                  tangent) of the slope. This angle, often denoted as θ (theta), is measured in degrees or radians. A
                  horizontal line has an angle of 0°, while a vertical line has an angle of 90°.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The formula θ = arctan(m) gives the angle in radians, which can be converted to degrees by multiplying
                  by 180/π. For positive slopes, the angle is positive (line tilts upward), and for negative slopes, the
                  angle is negative (line tilts downward). Understanding this relationship is crucial in fields like
                  surveying, architecture, and physics where angles of inclination are important.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-amber-50 border-amber-200">
              <CardHeader>
                <CardTitle className="text-amber-800">Disclaimer</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm">
                  Slope calculations follow standard mathematical formulas. Vertical lines have undefined slope. This
                  calculator is for educational purposes. For professional applications, please verify results with
                  appropriate mathematical software or consult a qualified professional.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
