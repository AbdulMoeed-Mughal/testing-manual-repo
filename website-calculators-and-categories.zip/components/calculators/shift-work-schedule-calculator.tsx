"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Users, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface ShiftAssignment {
  employee: number
  shift: string
  hours: number
}

export function ShiftWorkScheduleCalculator() {
  const [startDate, setStartDate] = useState("")
  const [numEmployees, setNumEmployees] = useState("")
  const [shiftDuration, setShiftDuration] = useState("")
  const [shiftsPerDay, setShiftsPerDay] = useState("")
  const [rotationPattern, setRotationPattern] = useState<"fixed" | "rotating">("fixed")
  const [excludeWeekends, setExcludeWeekends] = useState(false)
  const [numDays, setNumDays] = useState("7")
  const [result, setResult] = useState<{
    schedule: { date: string; shifts: ShiftAssignment[] }[]
    totalHoursPerEmployee: number[]
  } | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const getShiftName = (shiftIndex: number, totalShifts: number): string => {
    if (totalShifts === 1) return "Day Shift"
    if (totalShifts === 2) return shiftIndex === 0 ? "Day Shift" : "Night Shift"
    if (totalShifts === 3) {
      if (shiftIndex === 0) return "Morning Shift"
      if (shiftIndex === 1) return "Afternoon Shift"
      return "Night Shift"
    }
    return `Shift ${shiftIndex + 1}`
  }

  const calculateSchedule = () => {
    setError("")
    setResult(null)

    const employees = Number(numEmployees)
    const duration = Number(shiftDuration)
    const shifts = Number(shiftsPerDay)
    const days = Number(numDays)

    if (!startDate) {
      setError("Please enter a start date")
      return
    }

    if (employees <= 0 || duration <= 0 || shifts <= 0 || days <= 0) {
      setError("All values must be positive numbers")
      return
    }

    if (duration > 24) {
      setError("Shift duration cannot exceed 24 hours")
      return
    }

    if (shifts > 4) {
      setError("Maximum 4 shifts per day supported")
      return
    }

    if (employees < shifts) {
      setError("Number of employees must be at least equal to shifts per day")
      return
    }

    const schedule: { date: string; shifts: ShiftAssignment[] }[] = []
    const totalHoursPerEmployee: number[] = Array(employees).fill(0)
    const start = new Date(startDate)

    for (let day = 0; day < days; day++) {
      const currentDate = new Date(start)
      currentDate.setDate(start.getDate() + day)

      // Skip weekends if excluded
      if (excludeWeekends && (currentDate.getDay() === 0 || currentDate.getDay() === 6)) {
        continue
      }

      const dayShifts: ShiftAssignment[] = []

      for (let shiftIndex = 0; shiftIndex < shifts; shiftIndex++) {
        let employeeIndex: number

        if (rotationPattern === "fixed") {
          // Fixed: same employee always works same shift
          employeeIndex = shiftIndex % employees
        } else {
          // Rotating: employees rotate through shifts
          employeeIndex = (day * shifts + shiftIndex) % employees
        }

        const shiftName = getShiftName(shiftIndex, shifts)
        dayShifts.push({
          employee: employeeIndex + 1,
          shift: shiftName,
          hours: duration
        })

        totalHoursPerEmployee[employeeIndex] += duration
      }

      schedule.push({
        date: currentDate.toLocaleDateString("en-US", { 
          month: "short", 
          day: "numeric",
          weekday: "short"
        }),
        shifts: dayShifts
      })
    }

    setResult({ schedule, totalHoursPerEmployee })
  }

  const handleReset = () => {
    setStartDate("")
    setNumEmployees("")
    setShiftDuration("")
    setShiftsPerDay("")
    setRotationPattern("fixed")
    setExcludeWeekends(false)
    setNumDays("7")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Shift Schedule:\n\n${result.schedule.map(day => 
        `${day.date}:\n${day.shifts.map(s => `  ${s.shift}: Employee ${s.employee} (${s.hours}h)`).join("\n")}`
      ).join("\n\n")}\n\nTotal Hours:\n${result.totalHoursPerEmployee.map((h, i) => 
        `Employee ${i + 1}: ${h} hours`
      ).join("\n")}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Shift Work Schedule",
          text: `Generated shift schedule for ${numEmployees} employees over ${result.schedule.length} days`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Users className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Shift Work Schedule Calculator</CardTitle>
                    <CardDescription>Generate employee shift schedules</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="numEmployees">Number of Employees</Label>
                    <Input
                      id="numEmployees"
                      type="number"
                      placeholder="e.g., 6"
                      value={numEmployees}
                      onChange={(e) => setNumEmployees(e.target.value)}
                      min="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="numDays">Number of Days</Label>
                    <Input
                      id="numDays"
                      type="number"
                      placeholder="e.g., 7"
                      value={numDays}
                      onChange={(e) => setNumDays(e.target.value)}
                      min="1"
                      max="30"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="shiftDuration">Shift Duration (hours)</Label>
                    <Input
                      id="shiftDuration"
                      type="number"
                      placeholder="e.g., 8"
                      value={shiftDuration}
                      onChange={(e) => setShiftDuration(e.target.value)}
                      min="1"
                      max="24"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="shiftsPerDay">Shifts per Day</Label>
                    <Input
                      id="shiftsPerDay"
                      type="number"
                      placeholder="e.g., 3"
                      value={shiftsPerDay}
                      onChange={(e) => setShiftsPerDay(e.target.value)}
                      min="1"
                      max="4"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Rotation Pattern</Label>
                  <div className="flex gap-4">
                    <button
                      onClick={() => setRotationPattern("fixed")}
                      className={`flex-1 p-3 rounded-lg border-2 transition-colors ${
                        rotationPattern === "fixed"
                          ? "border-cyan-600 bg-cyan-50 text-cyan-700"
                          : "border-muted bg-background"
                      }`}
                    >
                      <p className="font-medium text-sm">Fixed</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Same shift always
                      </p>
                    </button>
                    <button
                      onClick={() => setRotationPattern("rotating")}
                      className={`flex-1 p-3 rounded-lg border-2 transition-colors ${
                        rotationPattern === "rotating"
                          ? "border-cyan-600 bg-cyan-50 text-cyan-700"
                          : "border-muted bg-background"
                      }`}
                    >
                      <p className="font-medium text-sm">Rotating</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Shifts rotate
                      </p>
                    </button>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="excludeWeekends"
                    checked={excludeWeekends}
                    onCheckedChange={(checked) => setExcludeWeekends(checked as boolean)}
                  />
                  <Label htmlFor="excludeWeekends" className="text-sm font-normal cursor-pointer">
                    Exclude weekends
                  </Label>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculateSchedule} className="w-full" size="lg">
                  Generate Schedule
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="space-y-3 mb-4">
                      <p className="text-sm font-semibold text-cyan-800">Shift Schedule:</p>
                      <div className="space-y-2 max-h-[300px] overflow-y-auto">
                        {result.schedule.map((day, index) => (
                          <div key={index} className="p-3 bg-white rounded-lg border border-cyan-200">
                            <p className="font-medium text-cyan-900 text-sm mb-2">{day.date}</p>
                            <div className="space-y-1">
                              {day.shifts.map((shift, i) => (
                                <div key={i} className="flex justify-between text-xs">
                                  <span className="text-cyan-700">{shift.shift}</span>
                                  <span className="text-cyan-600 font-medium">
                                    Employee {shift.employee} ({shift.hours}h)
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2 mb-4">
                      <p className="text-sm font-semibold text-cyan-800">Total Hours per Employee:</p>
                      <div className="grid grid-cols-2 gap-2">
                        {result.totalHoursPerEmployee.map((hours, index) => (
                          <div key={index} className="p-2 bg-white rounded-lg border border-cyan-200 text-xs">
                            <span className="text-cyan-700">Employee {index + 1}:</span>
                            <span className="text-cyan-600 font-medium ml-1">{hours}h</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Shift Patterns</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-muted-foreground">
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-800 mb-1">Fixed Pattern</p>
                    <p className="text-cyan-700 text-xs">
                      Employees work the same shift every day (e.g., always morning shift)
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-800 mb-1">Rotating Pattern</p>
                    <p className="text-cyan-700 text-xs">
                      Employees rotate through different shifts for variety and fairness
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Shift Structures</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p><strong>2 Shifts:</strong> Day (8h) and Night (8h) - 16 hours coverage</p>
                  <p><strong>3 Shifts:</strong> Morning, Afternoon, Night (8h each) - 24 hours coverage</p>
                  <p><strong>4 Shifts:</strong> Extended coverage with overlapping shifts</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <Card className="mt-8">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-600" />
                <CardTitle>Important Note</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              <p>
                Shift schedule calculations are based on entered data and patterns. Results may vary depending on
                labor regulations, employee availability, and holidays. Always verify compliance with local labor
                laws and ensure adequate rest periods between shifts.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
