"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, Calculator, Clock } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface BusinessDaysResult {
  totalBusinessDays: number
  totalDays: number
  weeks: number
  remainingDays: number
}

export function BusinessDaysCalculator() {
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [excludeWeekends, setExcludeWeekends] = useState(true)
  const [holidays, setHolidays] = useState("")
  const [result, setResult] = useState<BusinessDaysResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBusinessDays = () => {
    setError("")
    setResult(null)

    if (!startDate || !endDate) {
      setError("Please enter both start and end dates")
      return
    }

    const start = new Date(startDate)
    const end = new Date(endDate)

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      setError("Please enter valid dates")
      return
    }

    if (end < start) {
      setError("End date must be after start date")
      return
    }

    // Parse holidays
    const holidayDates = holidays
      .split(",")
      .map((h) => h.trim())
      .filter((h) => h)
      .map((h) => new Date(h))
      .filter((d) => !isNaN(d.getTime()))

    let businessDays = 0
    let totalDays = 0
    const current = new Date(start)

    while (current <= end) {
      totalDays++
      const dayOfWeek = current.getDay()
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6
      const isHoliday = holidayDates.some(
        (h) => h.toDateString() === current.toDateString()
      )

      if (excludeWeekends && !isWeekend && !isHoliday) {
        businessDays++
      } else if (!excludeWeekends && !isHoliday) {
        businessDays++
      }

      current.setDate(current.getDate() + 1)
    }

    const weeks = Math.floor(businessDays / 5)
    const remainingDays = businessDays % 5

    setResult({ totalBusinessDays: businessDays, totalDays, weeks, remainingDays })
  }

  const handleReset = () => {
    setStartDate("")
    setEndDate("")
    setExcludeWeekends(true)
    setHolidays("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Business Days: ${result.totalBusinessDays} (${result.weeks} weeks and ${result.remainingDays} days)`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Business Days Calculation",
          text: `I calculated business days using CalcHub! Total: ${result.totalBusinessDays} business days`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Business Days Calculator</CardTitle>
                    <CardDescription>Calculate business days between dates</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Start Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>

                {/* End Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="endDate">End Date</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>

                {/* Exclude Weekends Checkbox */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="excludeWeekends"
                    checked={excludeWeekends}
                    onCheckedChange={(checked) => setExcludeWeekends(checked as boolean)}
                  />
                  <Label htmlFor="excludeWeekends" className="cursor-pointer">
                    Exclude weekends
                  </Label>
                </div>

                {/* Holidays Input */}
                <div className="space-y-2">
                  <Label htmlFor="holidays">Holidays (optional, comma-separated dates)</Label>
                  <Input
                    id="holidays"
                    type="text"
                    placeholder="2024-12-25, 2024-01-01"
                    value={holidays}
                    onChange={(e) => setHolidays(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Format: YYYY-MM-DD</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBusinessDays} className="w-full" size="lg">
                  Calculate Business Days
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Business Days</p>
                      <p className="text-5xl font-bold text-cyan-600 mb-2">{result.totalBusinessDays}</p>
                      <p className="text-sm text-cyan-700 mb-1">
                        {result.weeks} weeks and {result.remainingDays} days
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Total calendar days: {result.totalDays}
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Use Cases</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <p>Project planning and deadline tracking</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <p>Payroll and working days calculation</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <p>Contract and lease duration estimation</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <p>Service level agreement (SLA) tracking</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    The calculator counts all days between your start and end dates, excluding weekends
                    (Saturday and Sunday) if selected, and any holidays you specify.
                  </p>
                  <p>
                    Business days are typically Monday through Friday, used for scheduling work projects,
                    calculating delivery times, and determining working periods.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What are Business Days */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Business Days?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Business days, also known as working days or weekdays, refer to the days when business
                  operations are typically conducted. In most countries, business days include Monday through
                  Friday, excluding weekends (Saturday and Sunday) and public holidays. This concept is
                  fundamental in business planning, project management, and scheduling, as it provides a
                  standardized way to calculate timelines that account for non-working days.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding business days is crucial for setting realistic deadlines, calculating delivery
                  times, and managing work schedules. Many industries, including finance, logistics, and
                  professional services, base their operations and commitments on business days rather than
                  calendar days to ensure accurate planning and execution.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Business Days */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Business Days</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating business days involves counting the total number of days between two dates while
                  excluding weekends and any specified holidays. The process starts by identifying your start
                  and end dates, then systematically counting each day in between, skipping Saturdays and
                  Sundays if weekends are excluded, and removing any holiday dates from your count.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, if you need to calculate business days from Monday, January 2nd to Friday,
                  January 13th (excluding a holiday on January 10th), you would count: Monday-Friday (Week 1) =
                  5 days, Monday-Friday (Week 2) = 5 days, minus 1 holiday = 9 business days total. This
                  calculator automates this process, handling complex scenarios including month boundaries, leap
                  years, and custom holiday lists.
                </p>
              </CardContent>
            </Card>

            {/* Common Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Common Applications of Business Days</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Business days are used extensively across various industries and scenarios. In project
                  management, teams use business days to set milestones and deadlines, ensuring that timelines
                  account for weekends and holidays. Financial institutions rely on business days for
                  transaction processing, settlement periods, and interest calculations, as most financial
                  markets operate only on business days.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Human resources departments use business days to calculate employee benefits such as vacation
                  accrual, notice periods, and payroll cycles. Shipping and logistics companies specify delivery
                  times in business days to provide accurate estimates that exclude non-operational days. Legal
                  and contract work often specifies response times, appeal periods, and notice requirements in
                  business days to ensure fair and realistic timeframes.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground text-center">
                  <strong>Note:</strong> Business days calculations are based on entered dates and selected
                  options. Results may vary due to holidays, weekends, and calendar differences. Always verify
                  critical calculations for your specific region and industry requirements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
