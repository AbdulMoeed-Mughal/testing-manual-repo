"use client"

import { useState, useCallback } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  Triangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type AngleUnit = "degrees" | "radians"
type TrigFunction =
  | "sin"
  | "cos"
  | "tan"
  | "csc"
  | "sec"
  | "cot"
  | "arcsin"
  | "arccos"
  | "arctan"
  | "arccsc"
  | "arcsec"
  | "arccot"

interface TrigResult {
  value: number
  displayValue: string
  exactValue?: string
  inputAngle: number
  inputUnit: AngleUnit
  convertedAngle?: number
  warning?: string
}

// Special angle exact values
const specialAngles: Record<number, Record<string, string>> = {
  0: { sin: "0", cos: "1", tan: "0", csc: "undefined", sec: "1", cot: "undefined" },
  30: { sin: "1/2", cos: "√3/2", tan: "√3/3", csc: "2", sec: "2√3/3", cot: "√3" },
  45: { sin: "√2/2", cos: "√2/2", tan: "1", csc: "√2", sec: "√2", cot: "1" },
  60: { sin: "√3/2", cos: "1/2", tan: "√3", csc: "2√3/3", sec: "2", cot: "√3/3" },
  90: { sin: "1", cos: "0", tan: "undefined", csc: "1", sec: "undefined", cot: "0" },
  120: { sin: "√3/2", cos: "-1/2", tan: "-√3", csc: "2√3/3", sec: "-2", cot: "-√3/3" },
  135: { sin: "√2/2", cos: "-√2/2", tan: "-1", csc: "√2", sec: "-√2", cot: "-1" },
  150: { sin: "1/2", cos: "-√3/2", tan: "-√3/3", csc: "2", sec: "-2√3/3", cot: "-√3" },
  180: { sin: "0", cos: "-1", tan: "0", csc: "undefined", sec: "-1", cot: "undefined" },
  210: { sin: "-1/2", cos: "-√3/2", tan: "√3/3", csc: "-2", sec: "-2√3/3", cot: "√3" },
  225: { sin: "-√2/2", cos: "-√2/2", tan: "1", csc: "-√2", sec: "-√2", cot: "1" },
  240: { sin: "-√3/2", cos: "-1/2", tan: "√3", csc: "-2√3/3", sec: "-2", cot: "√3/3" },
  270: { sin: "-1", cos: "0", tan: "undefined", csc: "-1", sec: "undefined", cot: "0" },
  300: { sin: "-√3/2", cos: "1/2", tan: "-√3", csc: "-2√3/3", sec: "2", cot: "-√3/3" },
  315: { sin: "-√2/2", cos: "√2/2", tan: "-1", csc: "-√2", sec: "√2", cot: "-1" },
  330: { sin: "-1/2", cos: "√3/2", tan: "-√3/3", csc: "-2", sec: "2√3/3", cot: "-√3" },
  360: { sin: "0", cos: "1", tan: "0", csc: "undefined", sec: "1", cot: "undefined" },
}

export function TrigonometryCalculator() {
  const [angleUnit, setAngleUnit] = useState<AngleUnit>("degrees")
  const [trigFunction, setTrigFunction] = useState<TrigFunction>("sin")
  const [inputValue, setInputValue] = useState("")
  const [result, setResult] = useState<TrigResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const isInverseFunction = trigFunction.startsWith("arc")

  const degreesToRadians = (degrees: number): number => (degrees * Math.PI) / 180
  const radiansToDegrees = (radians: number): number => (radians * 180) / Math.PI

  const normalizeAngle = (angle: number): number => {
    let normalized = angle % 360
    if (normalized < 0) normalized += 360
    return normalized
  }

  const calculate = useCallback(() => {
    setError("")
    setResult(null)

    const input = Number.parseFloat(inputValue)
    if (isNaN(input)) {
      setError("Please enter a valid number")
      return
    }

    // Validate inverse function inputs
    if (isInverseFunction) {
      if ((trigFunction === "arcsin" || trigFunction === "arccos") && (input < -1 || input > 1)) {
        setError(`Input must be between -1 and 1 for ${trigFunction}`)
        return
      }
      if ((trigFunction === "arccsc" || trigFunction === "arcsec") && Math.abs(input) < 1) {
        setError(`Input must have absolute value ≥ 1 for ${trigFunction}`)
        return
      }
    }

    let calculatedValue: number
    let warning: string | undefined
    let exactValue: string | undefined

    // Convert angle for direct trig functions
    const angleInRadians = angleUnit === "degrees" ? degreesToRadians(input) : input
    const angleInDegrees = angleUnit === "degrees" ? input : radiansToDegrees(input)
    const normalizedDegrees = normalizeAngle(angleInDegrees)

    // Check for special angles
    if (!isInverseFunction && specialAngles[normalizedDegrees]) {
      const baseFn = trigFunction as keyof (typeof specialAngles)[0]
      exactValue = specialAngles[normalizedDegrees][baseFn]
    }

    switch (trigFunction) {
      case "sin":
        calculatedValue = Math.sin(angleInRadians)
        break
      case "cos":
        calculatedValue = Math.cos(angleInRadians)
        break
      case "tan":
        if (Math.abs(Math.cos(angleInRadians)) < 1e-10) {
          setError("tan is undefined at this angle (90° + n×180°)")
          return
        }
        calculatedValue = Math.tan(angleInRadians)
        break
      case "csc":
        if (Math.abs(Math.sin(angleInRadians)) < 1e-10) {
          setError("csc is undefined at this angle (n×180°)")
          return
        }
        calculatedValue = 1 / Math.sin(angleInRadians)
        break
      case "sec":
        if (Math.abs(Math.cos(angleInRadians)) < 1e-10) {
          setError("sec is undefined at this angle (90° + n×180°)")
          return
        }
        calculatedValue = 1 / Math.cos(angleInRadians)
        break
      case "cot":
        if (Math.abs(Math.sin(angleInRadians)) < 1e-10) {
          setError("cot is undefined at this angle (n×180°)")
          return
        }
        calculatedValue = 1 / Math.tan(angleInRadians)
        break
      case "arcsin":
        calculatedValue = Math.asin(input)
        break
      case "arccos":
        calculatedValue = Math.acos(input)
        break
      case "arctan":
        calculatedValue = Math.atan(input)
        break
      case "arccsc":
        calculatedValue = Math.asin(1 / input)
        break
      case "arcsec":
        calculatedValue = Math.acos(1 / input)
        break
      case "arccot":
        calculatedValue = Math.atan(1 / input)
        break
      default:
        setError("Unknown function")
        return
    }

    // Format display value
    let displayValue: string
    if (isInverseFunction) {
      const resultInDegrees = radiansToDegrees(calculatedValue)
      displayValue = angleUnit === "degrees" ? `${resultInDegrees.toFixed(6)}°` : `${calculatedValue.toFixed(6)} rad`
    } else {
      displayValue = calculatedValue.toFixed(10).replace(/\.?0+$/, "")
    }

    setResult({
      value: calculatedValue,
      displayValue,
      exactValue,
      inputAngle: input,
      inputUnit: angleUnit,
      convertedAngle: isInverseFunction ? undefined : angleUnit === "degrees" ? angleInRadians : angleInDegrees,
      warning,
    })
  }, [inputValue, trigFunction, angleUnit, isInverseFunction])

  const handleReset = () => {
    setInputValue("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `${trigFunction}(${inputValue}${isInverseFunction ? "" : angleUnit === "degrees" ? "°" : " rad"}) = ${result.displayValue}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Trigonometry Calculator Result",
          text: `${trigFunction}(${inputValue}${isInverseFunction ? "" : angleUnit === "degrees" ? "°" : " rad"}) = ${result.displayValue}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const toggleAngleUnit = () => {
    setAngleUnit((prev) => (prev === "degrees" ? "radians" : "degrees"))
    setResult(null)
    setError("")
  }

  const trigFunctions: { value: TrigFunction; label: string; category: string }[] = [
    { value: "sin", label: "sin(θ)", category: "Basic" },
    { value: "cos", label: "cos(θ)", category: "Basic" },
    { value: "tan", label: "tan(θ)", category: "Basic" },
    { value: "csc", label: "csc(θ)", category: "Reciprocal" },
    { value: "sec", label: "sec(θ)", category: "Reciprocal" },
    { value: "cot", label: "cot(θ)", category: "Reciprocal" },
    { value: "arcsin", label: "arcsin(x)", category: "Inverse" },
    { value: "arccos", label: "arccos(x)", category: "Inverse" },
    { value: "arctan", label: "arctan(x)", category: "Inverse" },
    { value: "arccsc", label: "arccsc(x)", category: "Inverse" },
    { value: "arcsec", label: "arcsec(x)", category: "Inverse" },
    { value: "arccot", label: "arccot(x)", category: "Inverse" },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Triangle className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Trigonometry Calculator</CardTitle>
                    <CardDescription>Calculate trig functions and inverses</CardDescription>
                  </div>
                </div>

                {/* Angle Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Angle Unit</span>
                  <button
                    onClick={toggleAngleUnit}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        angleUnit === "radians" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        angleUnit === "degrees" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Degrees
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        angleUnit === "radians" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Radians
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Function Selection */}
                <div className="space-y-2">
                  <Label>Function</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {trigFunctions.map((fn) => (
                      <button
                        key={fn.value}
                        onClick={() => {
                          setTrigFunction(fn.value)
                          setResult(null)
                          setError("")
                        }}
                        className={`p-2 text-sm rounded-lg border transition-colors ${
                          trigFunction === fn.value
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background hover:bg-muted border-border"
                        }`}
                      >
                        {fn.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Input */}
                <div className="space-y-2">
                  <Label htmlFor="input">
                    {isInverseFunction ? "Value (x)" : `Angle (${angleUnit === "degrees" ? "°" : "rad"})`}
                  </Label>
                  <Input
                    id="input"
                    type="number"
                    placeholder={isInverseFunction ? "Enter a value" : `Enter angle in ${angleUnit}`}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    step="any"
                  />
                  {isInverseFunction && (
                    <p className="text-xs text-muted-foreground">
                      {trigFunction === "arcsin" || trigFunction === "arccos"
                        ? "Value must be between -1 and 1"
                        : trigFunction === "arccsc" || trigFunction === "arcsec"
                          ? "Value must have |x| ≥ 1"
                          : "Any real number"}
                    </p>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {trigFunction}({inputValue}
                        {!isInverseFunction && (angleUnit === "degrees" ? "°" : " rad")})
                      </p>
                      <p className="text-4xl font-bold text-blue-600 mb-1">{result.displayValue}</p>
                      {result.exactValue && result.exactValue !== "undefined" && (
                        <p className="text-sm text-blue-600">
                          Exact: <span className="font-mono font-semibold">{result.exactValue}</span>
                        </p>
                      )}
                    </div>

                    {/* Conversion info */}
                    {result.convertedAngle !== undefined && (
                      <div className="mt-3 pt-3 border-t border-blue-200 text-center text-sm text-muted-foreground">
                        {angleUnit === "degrees"
                          ? `${result.inputAngle}° = ${result.convertedAngle.toFixed(6)} rad`
                          : `${result.inputAngle} rad = ${result.convertedAngle.toFixed(4)}°`}
                      </div>
                    )}

                    {/* Step-by-step toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 pt-3 border-t border-blue-200 flex items-center justify-center gap-2 text-sm text-blue-600 hover:text-blue-700"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide Steps" : "Show Steps"}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Input value: {inputValue}
                          {!isInverseFunction && (angleUnit === "degrees" ? "°" : " radians")}
                        </p>
                        {!isInverseFunction && (
                          <p>
                            <strong>Step 2:</strong> Convert to radians:{" "}
                            {angleUnit === "degrees"
                              ? `${inputValue} × π/180 = ${result.convertedAngle?.toFixed(6)} rad`
                              : "Already in radians"}
                          </p>
                        )}
                        <p>
                          <strong>Step {isInverseFunction ? 2 : 3}:</strong> Apply {trigFunction} function
                        </p>
                        <p>
                          <strong>Result:</strong> {result.displayValue}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Trig Function Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700 mb-1">Basic Functions</p>
                      <p className="text-sm text-blue-600">sin, cos, tan - based on right triangle ratios</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-700 mb-1">Reciprocal Functions</p>
                      <p className="text-sm text-purple-600">csc = 1/sin, sec = 1/cos, cot = 1/tan</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-700 mb-1">Inverse Functions</p>
                      <p className="text-sm text-green-600">Return the angle for a given ratio value</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Special Angles</CardTitle>
                </CardHeader>
                <CardContent className="text-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-center">
                      <thead>
                        <tr className="border-b">
                          <th className="p-2">Angle</th>
                          <th className="p-2">sin</th>
                          <th className="p-2">cos</th>
                          <th className="p-2">tan</th>
                        </tr>
                      </thead>
                      <tbody className="text-muted-foreground">
                        <tr className="border-b">
                          <td className="p-2 font-medium">0°</td>
                          <td className="p-2">0</td>
                          <td className="p-2">1</td>
                          <td className="p-2">0</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-2 font-medium">30°</td>
                          <td className="p-2">1/2</td>
                          <td className="p-2">√3/2</td>
                          <td className="p-2">√3/3</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-2 font-medium">45°</td>
                          <td className="p-2">√2/2</td>
                          <td className="p-2">√2/2</td>
                          <td className="p-2">1</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-2 font-medium">60°</td>
                          <td className="p-2">√3/2</td>
                          <td className="p-2">1/2</td>
                          <td className="p-2">√3</td>
                        </tr>
                        <tr>
                          <td className="p-2 font-medium">90°</td>
                          <td className="p-2">1</td>
                          <td className="p-2">0</td>
                          <td className="p-2">∞</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Note</p>
                      <p>
                        This calculator provides estimates only. Verify manually for critical calculations. Some
                        functions are undefined at certain angles.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Trigonometry?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Trigonometry is a branch of mathematics that studies relationships between the sides and angles of
                  triangles. The word itself comes from the Greek words "trigonon" (triangle) and "metron" (measure).
                  While it originated from the study of triangles, trigonometry has evolved to have applications far
                  beyond geometry, including physics, engineering, astronomy, music theory, and even medical imaging.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The foundation of trigonometry rests on six fundamental functions: sine (sin), cosine (cos), tangent
                  (tan), cosecant (csc), secant (sec), and cotangent (cot). These functions establish relationships
                  between angles and ratios of sides in right triangles, and they can be extended to any angle using the
                  unit circle concept. Understanding these functions opens doors to solving complex problems in various
                  scientific and engineering fields.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Triangle className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Trigonometric Functions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In a right triangle, the three basic trigonometric functions are defined as ratios of the sides
                  relative to an angle θ (theta). The sine of an angle is the ratio of the opposite side to the
                  hypotenuse (sin θ = opposite/hypotenuse). The cosine is the ratio of the adjacent side to the
                  hypotenuse (cos θ = adjacent/hypotenuse). The tangent is the ratio of the opposite side to the
                  adjacent side (tan θ = opposite/adjacent).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The reciprocal functions are derived from these basic functions: cosecant is the reciprocal of sine
                  (csc θ = 1/sin θ), secant is the reciprocal of cosine (sec θ = 1/cos θ), and cotangent is the
                  reciprocal of tangent (cot θ = 1/tan θ). These six functions together form a complete system for
                  analyzing angles and triangles. The unit circle extends these definitions to all angles, not just
                  those in right triangles.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Inverse Trigonometric Functions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Inverse trigonometric functions, also called arc functions, perform the opposite operation of regular
                  trig functions. While sin(30°) gives you 0.5, arcsin(0.5) returns 30°. These functions answer the
                  question: "What angle produces this ratio?" They are essential when you know the ratio of sides but
                  need to find the angle, which is common in navigation, surveying, and engineering applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Inverse functions have restricted domains to ensure they return unique values. For arcsin and arccos,
                  the input must be between -1 and 1 (since sine and cosine never exceed these bounds). Arctan accepts
                  any real number. The outputs are typically given in the principal value range: arcsin and arctan
                  return values from -90° to 90° (-π/2 to π/2 radians), while arccos returns values from 0° to 180° (0
                  to π radians).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Degrees vs Radians</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Angles can be measured in degrees or radians, and understanding both systems is crucial for
                  trigonometry. Degrees divide a full circle into 360 equal parts, a system that dates back to ancient
                  Babylonian mathematics. Radians, on the other hand, measure angles based on the radius of a circle:
                  one radian is the angle subtended when the arc length equals the radius. A full circle contains 2π
                  radians (approximately 6.283 radians).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To convert between the two: multiply degrees by π/180 to get radians, or multiply radians by 180/π to
                  get degrees. While degrees are more intuitive for everyday use, radians are preferred in calculus and
                  advanced mathematics because they simplify many formulas. For example, the derivative of sin(x) is
                  cos(x) only when x is measured in radians. Most scientific calculators and programming languages use
                  radians by default.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Triangle className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Trigonometry has countless practical applications. In construction and architecture, it's used to
                  calculate roof angles, building heights, and structural loads. Surveyors use trigonometric functions
                  to measure land areas and distances that cannot be measured directly. Navigation relies heavily on
                  trigonometry for calculating positions, distances, and courses for ships and aircraft.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In physics, trigonometry is essential for analyzing wave motion, oscillations, and periodic phenomena.
                  Engineers use it to design bridges, analyze electrical circuits, and create computer graphics. Even
                  music theory uses trigonometric functions to understand sound waves and harmonics. Medical imaging
                  technologies like CT scans use trigonometric algorithms to reconstruct images from multiple angles,
                  demonstrating how this ancient mathematical discipline remains vital in modern technology.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
