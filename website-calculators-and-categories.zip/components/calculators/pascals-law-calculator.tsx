"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Gauge, Info, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface PascalsLawResult {
  inputPressure: number
  outputForce: number
  forceAmplification: number
  pressureUnit: string
  forceUnit: string
}

export function PascalsLawCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [inputForce, setInputForce] = useState("")
  const [inputArea, setInputArea] = useState("")
  const [outputArea, setOutputArea] = useState("")
  const [result, setResult] = useState<PascalsLawResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const F1 = Number.parseFloat(inputForce)
    const A1 = Number.parseFloat(inputArea)
    const A2 = Number.parseFloat(outputArea)

    if (isNaN(F1) || F1 <= 0) {
      setError("Please enter a valid applied force greater than 0")
      return
    }
    if (isNaN(A1) || A1 <= 0) {
      setError("Please enter a valid input piston area greater than 0")
      return
    }
    if (isNaN(A2) || A2 <= 0) {
      setError("Please enter a valid output piston area greater than 0")
      return
    }

    // Calculate input pressure: P = F₁ / A₁
    const P1 = F1 / A1

    // Calculate output force: F₂ = P × A₂
    const F2 = P1 * A2

    // Force amplification ratio
    const amplification = A2 / A1

    const pressureUnit = unitSystem === "metric" ? "Pa" : "psi"
    const forceUnit = unitSystem === "metric" ? "N" : "lb"

    setResult({
      inputPressure: P1,
      outputForce: F2,
      forceAmplification: amplification,
      pressureUnit,
      forceUnit,
    })
  }

  const handleReset = () => {
    setInputForce("")
    setInputArea("")
    setOutputArea("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Pascal's Law Result: Input Pressure = ${result.inputPressure.toFixed(2)} ${result.pressureUnit}, Output Force = ${result.outputForce.toFixed(2)} ${result.forceUnit}, Force Amplification = ${result.forceAmplification.toFixed(2)}x`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Pascal's Law Calculator Result",
          text: `I calculated hydraulic force amplification using CalcHub! Output Force = ${result.outputForce.toFixed(2)} ${result.forceUnit} with ${result.forceAmplification.toFixed(2)}x amplification`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    handleReset()
  }

  const formatNumber = (num: number, decimals = 2) => {
    if (num >= 1e6) return num.toExponential(decimals)
    if (num >= 1000) return num.toLocaleString(undefined, { maximumFractionDigits: decimals })
    return num.toFixed(decimals)
  }

  const getAmplificationCategory = (amp: number) => {
    if (amp < 2) return { label: "Low", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    if (amp < 10) return { label: "Moderate", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    if (amp < 50) return { label: "High", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    return { label: "Very High", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Pascal's Law Calculator</CardTitle>
                    <CardDescription>Calculate hydraulic force amplification</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Input Force */}
                <div className="space-y-2">
                  <Label htmlFor="inputForce">Applied Force F₁ ({unitSystem === "metric" ? "N" : "lb"})</Label>
                  <Input
                    id="inputForce"
                    type="number"
                    placeholder={`Enter force in ${unitSystem === "metric" ? "Newtons" : "pounds"}`}
                    value={inputForce}
                    onChange={(e) => setInputForce(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Input Piston Area */}
                <div className="space-y-2">
                  <Label htmlFor="inputArea">Input Piston Area A₁ ({unitSystem === "metric" ? "m²" : "in²"})</Label>
                  <Input
                    id="inputArea"
                    type="number"
                    placeholder={`Enter area in ${unitSystem === "metric" ? "square meters" : "square inches"}`}
                    value={inputArea}
                    onChange={(e) => setInputArea(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Output Piston Area */}
                <div className="space-y-2">
                  <Label htmlFor="outputArea">Output Piston Area A₂ ({unitSystem === "metric" ? "m²" : "in²"})</Label>
                  <Input
                    id="outputArea"
                    type="number"
                    placeholder={`Enter area in ${unitSystem === "metric" ? "square meters" : "square inches"}`}
                    value={outputArea}
                    onChange={(e) => setOutputArea(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Output Force
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getAmplificationCategory(result.forceAmplification).bgColor} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Output Force (F₂)</p>
                      <p
                        className={`text-4xl font-bold ${getAmplificationCategory(result.forceAmplification).color} mb-1`}
                      >
                        {formatNumber(result.outputForce)} {result.forceUnit}
                      </p>
                      <p
                        className={`text-lg font-semibold ${getAmplificationCategory(result.forceAmplification).color}`}
                      >
                        {result.forceAmplification.toFixed(2)}x Amplification (
                        {getAmplificationCategory(result.forceAmplification).label})
                      </p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 pt-4 border-t border-current/10 grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-xs text-muted-foreground">Input Pressure</p>
                        <p className="font-semibold">
                          {formatNumber(result.inputPressure)} {result.pressureUnit}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Area Ratio</p>
                        <p className="font-semibold">{result.forceAmplification.toFixed(2)} : 1</p>
                      </div>
                    </div>

                    {/* Step-by-step Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Calculate input pressure
                        </p>
                        <p className="font-mono text-xs">
                          P = F₁ / A₁ = {inputForce} / {inputArea} = {formatNumber(result.inputPressure)}{" "}
                          {result.pressureUnit}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Calculate output force
                        </p>
                        <p className="font-mono text-xs">
                          F₂ = P × A₂ = {formatNumber(result.inputPressure)} × {outputArea} ={" "}
                          {formatNumber(result.outputForce)} {result.forceUnit}
                        </p>
                        <p>
                          <strong>Step 3:</strong> Calculate amplification
                        </p>
                        <p className="font-mono text-xs">
                          Amplification = A₂ / A₁ = {outputArea} / {inputArea} = {result.forceAmplification.toFixed(2)}x
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pascal's Law Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">P = F₁ / A₁</p>
                    <p className="font-semibold text-foreground">F₂ = P × A₂ = F₁ × (A₂ / A₁)</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>P</strong> = Pressure transmitted through fluid
                    </p>
                    <p>
                      <strong>F₁</strong> = Applied force on input piston
                    </p>
                    <p>
                      <strong>A₁</strong> = Area of input piston
                    </p>
                    <p>
                      <strong>F₂</strong> = Force on output piston
                    </p>
                    <p>
                      <strong>A₂</strong> = Area of output piston
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Hydraulic System Diagram */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Hydraulic System Schematic</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg">
                    <svg viewBox="0 0 300 150" className="w-full h-auto">
                      {/* Container */}
                      <rect
                        x="30"
                        y="50"
                        width="240"
                        height="80"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        rx="5"
                        className="text-muted-foreground"
                      />

                      {/* Fluid */}
                      <rect
                        x="32"
                        y="70"
                        width="236"
                        height="58"
                        fill="currentColor"
                        className="text-cyan-200"
                        opacity="0.5"
                      />

                      {/* Input Piston */}
                      <rect x="50" y="30" width="40" height="50" fill="currentColor" className="text-cyan-600" rx="3" />
                      <text x="70" y="20" textAnchor="middle" className="text-xs fill-current text-muted-foreground">
                        F₁
                      </text>
                      <text x="70" y="95" textAnchor="middle" className="text-xs fill-current text-muted-foreground">
                        A₁
                      </text>

                      {/* Output Piston */}
                      <rect
                        x="200"
                        y="10"
                        width="60"
                        height="70"
                        fill="currentColor"
                        className="text-cyan-600"
                        rx="3"
                      />
                      <text x="230" y="0" textAnchor="middle" className="text-xs fill-current text-muted-foreground">
                        F₂
                      </text>
                      <text x="230" y="95" textAnchor="middle" className="text-xs fill-current text-muted-foreground">
                        A₂
                      </text>

                      {/* Arrows */}
                      <path
                        d="M70 5 L70 25"
                        stroke="currentColor"
                        strokeWidth="2"
                        markerEnd="url(#arrowhead)"
                        className="text-foreground"
                      />
                      <path
                        d="M230 -15 L230 5"
                        stroke="currentColor"
                        strokeWidth="2"
                        markerEnd="url(#arrowhead)"
                        className="text-foreground"
                      />

                      {/* Pressure arrows */}
                      <path
                        d="M100 90 L190 90"
                        stroke="currentColor"
                        strokeWidth="1.5"
                        strokeDasharray="5,3"
                        className="text-cyan-500"
                      />
                      <text x="145" y="105" textAnchor="middle" className="text-xs fill-current text-cyan-600">
                        P (pressure)
                      </text>

                      <defs>
                        <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                          <polygon points="0 0, 10 3.5, 0 7" fill="currentColor" />
                        </marker>
                      </defs>
                    </svg>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    Small input force on small piston creates large output force on large piston
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <span>Hydraulic Car Lift</span>
                      <span className="text-muted-foreground">10-50x</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <span>Hydraulic Press</span>
                      <span className="text-muted-foreground">50-200x</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <span>Brake System</span>
                      <span className="text-muted-foreground">5-15x</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted">
                      <span>Hydraulic Jack</span>
                      <span className="text-muted-foreground">10-100x</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Pascal's Law?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pascal's Law, also known as Pascal's Principle, states that pressure applied to a confined fluid is
                  transmitted equally in all directions throughout the fluid. This fundamental principle of fluid
                  mechanics was formulated by French mathematician and physicist Blaise Pascal in the 17th century and
                  forms the basis for all hydraulic systems used in modern engineering.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The practical significance of Pascal's Law lies in its ability to multiply force. When a small force
                  is applied to a small-area piston, the resulting pressure is transmitted through an incompressible
                  fluid to a larger-area piston, producing a proportionally larger force. This mechanical advantage is
                  calculated by the ratio of the output piston area to the input piston area.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How Hydraulic Force Amplification Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In a hydraulic system, force amplification occurs because pressure is defined as force per unit area
                  (P = F/A). When you apply a force to a small piston, you create a certain pressure in the fluid. This
                  pressure acts uniformly on all surfaces in contact with the fluid, including a larger output piston.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Since the output piston has a larger area, the same pressure produces a proportionally larger force.
                  For example, if the output piston has 10 times the area of the input piston, the output force will be
                  10 times greater than the input force. This principle enables humans to lift heavy vehicles with car
                  jacks or operate powerful hydraulic presses with minimal manual effort.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Pascal's law calculations assume ideal, incompressible fluid behavior.
                  Actual forces may vary due to friction, leakage, and system imperfections. Consult hydraulic system
                  references for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
