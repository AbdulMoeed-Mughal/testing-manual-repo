"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Binary, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

interface ConversionResult {
  decimal: number
  binary: string
  isSigned: boolean
  bitWidth: number
  steps: { position: number; bit: string; value: number; calculation: string }[]
}

export function BinaryToDecimalConverter() {
  const [binaryInput, setBinaryInput] = useState("")
  const [twosComplement, setTwosComplement] = useState(false)
  const [showSteps, setShowSteps] = useState(true)
  const [bitWidth, setBitWidth] = useState<string>("auto")
  const [result, setResult] = useState<ConversionResult | null>(null)
  const [copied, setCopied] = useState<string | null>(null)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(true)

  const formatBinaryInput = (input: string): string => {
    // Remove spaces and only keep 0s and 1s
    return input.replace(/[^01]/g, "")
  }

  const calculateDecimal = () => {
    setError("")
    setResult(null)

    // Clean and validate input
    const cleanBinary = formatBinaryInput(binaryInput)

    if (!cleanBinary) {
      setError("Please enter a valid binary number (only 0s and 1s)")
      return
    }

    if (cleanBinary.length > 64) {
      setError("Binary number is too large (max 64 bits)")
      return
    }

    // Determine bit width
    const actualBitWidth = bitWidth === "auto" ? cleanBinary.length : Number.parseInt(bitWidth)

    // Pad binary to match bit width if needed
    let paddedBinary = cleanBinary
    if (cleanBinary.length < actualBitWidth) {
      paddedBinary = cleanBinary.padStart(actualBitWidth, "0")
    } else if (cleanBinary.length > actualBitWidth) {
      setError(`Binary number exceeds selected ${actualBitWidth}-bit width`)
      return
    }

    // Calculate decimal value
    let decimalValue = 0
    const steps: { position: number; bit: string; value: number; calculation: string }[] = []

    if (twosComplement && paddedBinary[0] === "1") {
      // Two's complement for negative numbers
      // Invert bits and add 1
      let invertedBinary = ""
      for (const bit of paddedBinary) {
        invertedBinary += bit === "0" ? "1" : "0"
      }

      // Add 1 to inverted
      let carry = 1
      let resultBinary = ""
      for (let i = invertedBinary.length - 1; i >= 0; i--) {
        const sum = Number.parseInt(invertedBinary[i]) + carry
        resultBinary = (sum % 2).toString() + resultBinary
        carry = Math.floor(sum / 2)
      }

      // Calculate magnitude
      for (let i = 0; i < resultBinary.length; i++) {
        const position = resultBinary.length - 1 - i
        const bit = resultBinary[i]
        const value = Number.parseInt(bit) * Math.pow(2, position)
        decimalValue += value

        if (bit === "1") {
          steps.push({
            position,
            bit,
            value,
            calculation: `${bit} × 2^${position} = ${value}`,
          })
        }
      }

      decimalValue = -decimalValue

      // Add step explaining two's complement
      steps.unshift({
        position: -1,
        bit: "sign",
        value: 0,
        calculation: `Two's complement: invert bits (${invertedBinary}) + 1 = ${resultBinary}`,
      })
    } else {
      // Standard unsigned conversion
      for (let i = 0; i < paddedBinary.length; i++) {
        const position = paddedBinary.length - 1 - i
        const bit = paddedBinary[i]
        const value = Number.parseInt(bit) * Math.pow(2, position)
        decimalValue += value

        if (bit === "1") {
          steps.push({
            position,
            bit,
            value,
            calculation: `${bit} × 2^${position} = ${value}`,
          })
        }
      }
    }

    setResult({
      decimal: decimalValue,
      binary: paddedBinary,
      isSigned: twosComplement && paddedBinary[0] === "1",
      bitWidth: actualBitWidth,
      steps,
    })
  }

  const handleReset = () => {
    setBinaryInput("")
    setResult(null)
    setError("")
    setCopied(null)
  }

  const handleCopy = async (text: string, type: string) => {
    await navigator.clipboard.writeText(text)
    setCopied(type)
    setTimeout(() => setCopied(null), 2000)
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Binary to Decimal Conversion",
          text: `Binary: ${result.binary} = Decimal: ${result.decimal}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  // Format binary with spaces for readability
  const formatBinaryDisplay = (binary: string): string => {
    const reversed = binary.split("").reverse()
    const groups = []
    for (let i = 0; i < reversed.length; i += 4) {
      groups.push(
        reversed
          .slice(i, i + 4)
          .reverse()
          .join(""),
      )
    }
    return groups.reverse().join(" ")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Binary className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Binary to Decimal Converter</CardTitle>
                    <CardDescription>Convert binary numbers to decimal</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Binary Input */}
                <div className="space-y-2">
                  <Label htmlFor="binary">Binary Number</Label>
                  <Input
                    id="binary"
                    type="text"
                    placeholder="Enter binary (e.g., 1010, 11001010)"
                    value={binaryInput}
                    onChange={(e) => setBinaryInput(e.target.value.replace(/[^01\s]/g, ""))}
                    className="font-mono text-lg"
                  />
                  <p className="text-xs text-muted-foreground">Only 0s and 1s allowed. Spaces are ignored.</p>
                </div>

                {/* Bit Width Selection */}
                <div className="space-y-2">
                  <Label>Bit Width</Label>
                  <Select value={bitWidth} onValueChange={setBitWidth}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select bit width" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto (based on input)</SelectItem>
                      <SelectItem value="8">8-bit</SelectItem>
                      <SelectItem value="16">16-bit</SelectItem>
                      <SelectItem value="32">32-bit</SelectItem>
                      <SelectItem value="64">64-bit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Options */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="twos-complement" className="cursor-pointer">
                      Two&apos;s Complement (signed)
                    </Label>
                    <Switch id="twos-complement" checked={twosComplement} onCheckedChange={setTwosComplement} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show-steps" className="cursor-pointer">
                      Show Step-by-Step
                    </Label>
                    <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDecimal} className="w-full" size="lg">
                  Convert to Decimal
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Binary Input ({result.bitWidth}-bit)</p>
                        <p className="text-lg font-mono font-semibold text-blue-700">
                          {formatBinaryDisplay(result.binary)}
                        </p>
                      </div>

                      <div className="text-2xl text-muted-foreground">=</div>

                      <div>
                        <p className="text-sm text-muted-foreground mb-1">
                          Decimal {result.isSigned ? "(Signed)" : "(Unsigned)"}
                        </p>
                        <p className={`text-4xl font-bold ${result.decimal < 0 ? "text-red-600" : "text-green-600"}`}>
                          {result.decimal.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-Step Breakdown */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            <span>Step-by-Step Breakdown</span>
                            <ChevronDown className={`h-4 w-4 transition-transform ${stepsOpen ? "rotate-180" : ""}`} />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="bg-white rounded-lg p-3 space-y-2 text-sm">
                            {result.steps.map((step, index) => (
                              <div key={index} className="flex items-center gap-2 font-mono">
                                {step.position === -1 ? (
                                  <span className="text-purple-600">{step.calculation}</span>
                                ) : (
                                  <>
                                    <span className="text-muted-foreground">Position {step.position}:</span>
                                    <span className="text-blue-600">{step.calculation}</span>
                                  </>
                                )}
                              </div>
                            ))}
                            <div className="pt-2 border-t font-semibold">Sum = {result.decimal.toLocaleString()}</div>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Bit Position Table */}
                    <div className="mt-4 overflow-x-auto">
                      <table className="w-full text-xs font-mono">
                        <thead>
                          <tr>
                            {result.binary.split("").map((_, i) => (
                              <th key={i} className="px-1 py-1 text-center text-muted-foreground">
                                2<sup>{result.binary.length - 1 - i}</sup>
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            {result.binary.split("").map((bit, i) => (
                              <td
                                key={i}
                                className={`px-1 py-1 text-center font-bold ${
                                  bit === "1" ? "text-green-600 bg-green-50" : "text-gray-400"
                                }`}
                              >
                                {bit}
                              </td>
                            ))}
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCopy(result.decimal.toString(), "decimal")}
                      >
                        {copied === "decimal" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied === "decimal" ? "Copied" : "Copy Decimal"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleCopy(result.binary, "binary")}>
                        {copied === "binary" ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied === "binary" ? "Copied" : "Copy Binary"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 font-mono text-sm">
                    {[
                      { binary: "0001", decimal: 1 },
                      { binary: "0010", decimal: 2 },
                      { binary: "0100", decimal: 4 },
                      { binary: "1000", decimal: 8 },
                      { binary: "1010", decimal: 10 },
                      { binary: "1111", decimal: 15 },
                      { binary: "10000", decimal: 16 },
                      { binary: "11111111", decimal: 255 },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center justify-between p-2 rounded bg-muted/50">
                        <span className="text-blue-600">{item.binary}</span>
                        <span className="text-muted-foreground">=</span>
                        <span className="text-green-600">{item.decimal}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conversion Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">
                      Decimal = Σ (bit × 2<sup>position</sup>)
                    </p>
                  </div>
                  <p>
                    Each bit position represents a power of 2, starting from 2<sup>0</sup> on the right.
                  </p>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="font-semibold text-blue-800 mb-1">Example: 1011</p>
                    <p className="text-blue-700 font-mono text-xs">
                      1×2³ + 0×2² + 1×2¹ + 1×2⁰
                      <br />= 8 + 0 + 2 + 1 = 11
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Two&apos;s Complement</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    Two&apos;s complement is a method to represent signed integers. If the leftmost bit is 1, the number
                    is negative.
                  </p>
                  <div className="space-y-1 text-xs font-mono">
                    <div className="p-2 rounded bg-green-50 border border-green-200">
                      <span className="text-green-700">01111111 (8-bit) = +127</span>
                    </div>
                    <div className="p-2 rounded bg-red-50 border border-red-200">
                      <span className="text-red-700">10000000 (8-bit) = -128</span>
                    </div>
                    <div className="p-2 rounded bg-red-50 border border-red-200">
                      <span className="text-red-700">11111111 (8-bit) = -1</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Binary to Decimal Conversion?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Binary to decimal conversion is the process of converting a number expressed in the binary numeral
                  system (base-2) to its equivalent in the decimal numeral system (base-10). Binary uses only two
                  digits, 0 and 1, while decimal uses ten digits, 0 through 9. This conversion is fundamental in
                  computer science as computers internally represent and process all data using binary numbers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The conversion is performed by multiplying each binary digit by its positional value (a power of 2)
                  and summing all the results. The rightmost position has a value of 2⁰ = 1, the next position to the
                  left has a value of 2¹ = 2, then 2² = 4, and so on. This positional notation makes binary an efficient
                  way to represent numbers in electronic circuits.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Converter</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter your binary number in the input field using only 0s and 1s. You can include spaces for
                  readability—they will be automatically ignored. Select a bit width if you want to work with a specific
                  format (8-bit, 16-bit, etc.), or leave it on &quot;Auto&quot; to use the minimum required bits.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Enable &quot;Two&apos;s Complement&quot; if you&apos;re working with signed integers where the most
                  significant bit represents the sign. When enabled, numbers starting with 1 will be interpreted as
                  negative values. The step-by-step option shows you exactly how each bit contributes to the final
                  decimal value.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-yellow-800 mb-1">Disclaimer</h4>
                    <p className="text-sm text-yellow-700">
                      Binary to decimal conversions are based on standard positional and two&apos;s complement rules.
                      Results depend on correct input formatting and selected options. This tool supports up to 64-bit
                      numbers.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
