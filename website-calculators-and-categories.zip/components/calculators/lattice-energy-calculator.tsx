"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Atom, Info, AlertTriangle, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "pm" | "angstrom"

interface LatticeResult {
  energy: number
  r0: number
  contributionA: number
  contributionCharge: number
  contributionBorn: number
}

export function LatticeEnergyCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("pm")
  const [cationCharge, setCationCharge] = useState("")
  const [anionCharge, setAnionCharge] = useState("")
  const [cationRadius, setCationRadius] = useState("")
  const [anionRadius, setAnionRadius] = useState("")
  const [madelungConstant, setMadelungConstant] = useState("1.748")
  const [bornExponent, setBornExponent] = useState("9")
  const [result, setResult] = useState<LatticeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateLatticeEnergy = () => {
    setError("")
    setResult(null)

    const zPlus = Math.abs(Number.parseFloat(cationCharge))
    const zMinus = Math.abs(Number.parseFloat(anionCharge))
    const rPlus = Number.parseFloat(cationRadius)
    const rMinus = Number.parseFloat(anionRadius)
    const A = Number.parseFloat(madelungConstant)
    const n = Number.parseFloat(bornExponent)

    if (isNaN(zPlus) || zPlus <= 0) {
      setError("Please enter a valid cation charge greater than 0")
      return
    }
    if (isNaN(zMinus) || zMinus <= 0) {
      setError("Please enter a valid anion charge greater than 0")
      return
    }
    if (isNaN(rPlus) || rPlus <= 0) {
      setError("Please enter a valid cation radius greater than 0")
      return
    }
    if (isNaN(rMinus) || rMinus <= 0) {
      setError("Please enter a valid anion radius greater than 0")
      return
    }
    if (isNaN(A) || A <= 0 || A > 5) {
      setError("Please enter a realistic Madelung constant (0 < A ≤ 5)")
      return
    }
    if (isNaN(n) || n <= 1) {
      setError("Please enter a valid Born exponent (n > 1)")
      return
    }

    // Convert radii to meters
    let r0InMeters: number
    if (unitSystem === "pm") {
      r0InMeters = (rPlus + rMinus) * 1e-12
    } else {
      r0InMeters = (rPlus + rMinus) * 1e-10
    }

    // Constants
    const e = 1.602176634e-19 // Elementary charge in Coulombs
    const epsilon0 = 8.854187817e-12 // Vacuum permittivity in F/m
    const Na = 6.02214076e23 // Avogadro's number

    // Born-Landé equation: U = (A × z⁺ × z⁻ × e² × Na) / (4 × π × ε₀ × r₀) × (1 − 1/n)
    const k = 1 / (4 * Math.PI * epsilon0)
    const U = (A * zPlus * zMinus * e * e * Na * k / r0InMeters) * (1 - 1 / n)

    // Convert to kJ/mol
    const UkJmol = U / 1000

    // Calculate contributions (as percentages of total)
    const baseTerm = (zPlus * zMinus * e * e * Na * k / r0InMeters) / 1000
    const contributionA = A * baseTerm
    const contributionBorn = baseTerm * A * (1 / n)
    const contributionCharge = zPlus * zMinus

    setResult({
      energy: Math.round(UkJmol),
      r0: unitSystem === "pm" ? rPlus + rMinus : (rPlus + rMinus) * 100,
      contributionA: A,
      contributionCharge: contributionCharge,
      contributionBorn: Math.round((1 - 1 / n) * 100),
    })
  }

  const handleReset = () => {
    setCationCharge("")
    setAnionCharge("")
    setCationRadius("")
    setAnionRadius("")
    setMadelungConstant("1.748")
    setBornExponent("9")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Lattice Energy: ${result.energy} kJ/mol`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Lattice Energy Result",
          text: `I calculated the lattice energy using CalcHub! Lattice Energy: ${result.energy} kJ/mol`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "pm" ? "angstrom" : "pm"))
    setCationRadius("")
    setAnionRadius("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Atom className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Lattice Energy Calculator</CardTitle>
                    <CardDescription>Calculate ionic compound lattice energy</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Radius Units</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "angstrom" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "pm" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      pm
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "angstrom" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Å
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Charge Inputs */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="cationCharge">Cation Charge (z⁺)</Label>
                    <Input
                      id="cationCharge"
                      type="number"
                      placeholder="e.g., 1, 2, 3"
                      value={cationCharge}
                      onChange={(e) => setCationCharge(e.target.value)}
                      min="1"
                      step="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="anionCharge">Anion Charge (z⁻)</Label>
                    <Input
                      id="anionCharge"
                      type="number"
                      placeholder="e.g., 1, 2, 3"
                      value={anionCharge}
                      onChange={(e) => setAnionCharge(e.target.value)}
                      min="1"
                      step="1"
                    />
                  </div>
                </div>

                {/* Radius Inputs */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="cationRadius">Cation Radius ({unitSystem === "pm" ? "pm" : "Å"})</Label>
                    <Input
                      id="cationRadius"
                      type="number"
                      placeholder={unitSystem === "pm" ? "e.g., 100" : "e.g., 1.0"}
                      value={cationRadius}
                      onChange={(e) => setCationRadius(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="anionRadius">Anion Radius ({unitSystem === "pm" ? "pm" : "Å"})</Label>
                    <Input
                      id="anionRadius"
                      type="number"
                      placeholder={unitSystem === "pm" ? "e.g., 181" : "e.g., 1.81"}
                      value={anionRadius}
                      onChange={(e) => setAnionRadius(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Optional Parameters */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="madelung">Madelung Constant (A)</Label>
                    <Input
                      id="madelung"
                      type="number"
                      placeholder="e.g., 1.748"
                      value={madelungConstant}
                      onChange={(e) => setMadelungConstant(e.target.value)}
                      min="0"
                      step="0.001"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bornExponent">Born Exponent (n)</Label>
                    <Input
                      id="bornExponent"
                      type="number"
                      placeholder="e.g., 9"
                      value={bornExponent}
                      onChange={(e) => setBornExponent(e.target.value)}
                      min="1"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLatticeEnergy} className="w-full" size="lg">
                  Calculate Lattice Energy
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Lattice Energy (U)</p>
                      <p className="text-5xl font-bold text-purple-600 mb-2">{result.energy}</p>
                      <p className="text-lg font-semibold text-purple-600">kJ/mol</p>
                    </div>

                    <div className="mt-4 pt-4 border-t border-purple-200 grid grid-cols-2 gap-3 text-sm">
                      <div className="text-center">
                        <p className="text-muted-foreground">Interionic Distance (r₀)</p>
                        <p className="font-semibold text-purple-700">{result.r0} pm</p>
                      </div>
                      <div className="text-center">
                        <p className="text-muted-foreground">Born Factor</p>
                        <p className="font-semibold text-purple-700">{result.contributionBorn}%</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Madelung Constants</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">NaCl (Rock Salt)</span>
                      <span className="text-sm text-purple-600">1.748</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">CsCl (Cesium Chloride)</span>
                      <span className="text-sm text-purple-600">1.763</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">ZnS (Zinc Blende)</span>
                      <span className="text-sm text-purple-600">1.638</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">CaF₂ (Fluorite)</span>
                      <span className="text-sm text-purple-600">2.519</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Born-Landé Equation</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">U = (A × z⁺ × z⁻ × e² × Nₐ) / (4πε₀r₀) × (1 − 1/n)</p>
                  </div>
                  <p>
                    Where <strong>A</strong> is the Madelung constant, <strong>z</strong> are ion charges,{" "}
                    <strong>r₀</strong> is the interionic distance, and <strong>n</strong> is the Born exponent.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Content Cards */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Lattice Energy?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Lattice energy is the energy required to completely separate one mole of a solid ionic compound into
                  gaseous ions. It represents the strength of the electrostatic interactions between the cations and
                  anions in an ionic crystal. The magnitude of lattice energy depends primarily on the charges of the
                  ions and the distance between them in the crystal lattice.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Higher lattice energies indicate stronger ionic bonds and generally correlate with higher melting
                  points, lower solubility in water, and greater hardness of the ionic compound. Understanding lattice
                  energy is essential for predicting the physical and chemical properties of ionic solids.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Lattice Energy</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Ion Charge:</strong> Lattice energy increases with the magnitude of ionic charges. Compounds
                  with doubly or triply charged ions (like MgO or Al₂O₃) have significantly higher lattice energies than
                  those with singly charged ions (like NaCl). This is because electrostatic attraction is proportional
                  to the product of the charges.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Ionic Radii:</strong> Smaller ions result in shorter interionic distances and stronger
                  electrostatic attractions, leading to higher lattice energies. This explains why LiF has a higher
                  lattice energy than CsI, even though both contain singly charged ions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>The Born-Landé Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Born-Landé equation is a theoretical model used to calculate lattice energy based on
                  electrostatic interactions between ions. It accounts for both the attractive forces between
                  oppositely charged ions and the repulsive forces that arise when electron clouds overlap at short
                  distances.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Madelung constant (A) accounts for the geometry of the crystal lattice, while the Born exponent
                  (n) describes the repulsive interactions. Common values for n range from 5 to 12, depending on the
                  electronic configuration of the ions. The equation provides reasonably accurate predictions for many
                  ionic compounds.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Born-Landé equation assumes purely ionic bonding and treats ions as hard spheres with a point
                  charge. In reality, many ionic compounds exhibit some degree of covalent character, especially when
                  the cation is small and highly charged or when the anion is large and polarizable. This covalent
                  contribution is not accounted for in the simple electrostatic model.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Additionally, crystal defects, thermal effects, and zero-point energy are not considered in this
                  calculation. For more accurate values, experimental methods such as the Born-Haber cycle are often
                  preferred, as they account for all energy changes in forming an ionic compound from its elements.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Disclaimer:</strong> Calculations assume ideal ionic crystals and electrostatic
                    interactions. Actual lattice energies may vary due to covalent character or crystal defects.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
