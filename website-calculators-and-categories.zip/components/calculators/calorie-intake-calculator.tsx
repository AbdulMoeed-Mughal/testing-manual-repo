"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Flame,
  Info,
  AlertTriangle,
  Activity,
  Dumbbell,
  Bike,
  Zap,
  Briefcase,
  TrendingDown,
  TrendingUp,
  Minus,
  Target,
  Apple,
  Utensils,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type Formula = "mifflin" | "harris"
type Goal = "lose" | "maintain" | "gain"
type Intensity = "mild" | "moderate" | "aggressive"
type ActivityLevel = "sedentary" | "light" | "moderate" | "very" | "extra"

interface CalorieResult {
  bmr: number
  tdee: number
  targetCalories: number
  weeklyChange: string
  macros: { protein: number; carbs: number; fat: number }
  warning: string | null
  color: string
  bgColor: string
}

const activityLevels = [
  { id: "sedentary", label: "Sedentary", description: "Little or no exercise", multiplier: 1.2, icon: Briefcase },
  { id: "light", label: "Light", description: "1-3 days/week", multiplier: 1.375, icon: Activity },
  { id: "moderate", label: "Moderate", description: "3-5 days/week", multiplier: 1.55, icon: Bike },
  { id: "very", label: "Very Active", description: "6-7 days/week", multiplier: 1.725, icon: Dumbbell },
  { id: "extra", label: "Extra Active", description: "Physical job or 2x training", multiplier: 1.9, icon: Zap },
]

const intensityOptions = [
  { id: "mild", label: "Mild", adjustment: 250, weeklyChange: "0.25 kg" },
  { id: "moderate", label: "Moderate", adjustment: 500, weeklyChange: "0.5 kg" },
  { id: "aggressive", label: "Aggressive", adjustment: 750, weeklyChange: "0.75 kg" },
]

export function CalorieIntakeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [formula, setFormula] = useState<Formula>("mifflin")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")
  const [goal, setGoal] = useState<Goal>("maintain")
  const [intensity, setIntensity] = useState<Intensity>("moderate")
  const [result, setResult] = useState<CalorieResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCalories = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const weightNum = Number.parseFloat(weight)

    if (isNaN(ageNum) || ageNum < 10 || ageNum > 100) {
      setError("Please enter a valid age between 10 and 100")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number
    let weightInKg: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
      weightInKg = weightNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = (feet * 12 + inches) * 2.54
      weightInKg = weightNum * 0.453592
    }

    let bmr: number

    if (formula === "mifflin") {
      if (gender === "male") {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
      } else {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
      }
    } else {
      if (gender === "male") {
        bmr = 88.362 + 13.397 * weightInKg + 4.799 * heightInCm - 5.677 * ageNum
      } else {
        bmr = 447.593 + 9.247 * weightInKg + 3.098 * heightInCm - 4.33 * ageNum
      }
    }

    const selectedActivity = activityLevels.find((a) => a.id === activityLevel)
    const tdee = bmr * (selectedActivity?.multiplier || 1.55)

    const selectedIntensity = intensityOptions.find((i) => i.id === intensity)
    const adjustment = selectedIntensity?.adjustment || 500

    let targetCalories: number
    let weeklyChange: string
    let color: string
    let bgColor: string

    if (goal === "lose") {
      targetCalories = tdee - adjustment
      weeklyChange = `-${selectedIntensity?.weeklyChange || "0.5 kg"}`
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (goal === "gain") {
      targetCalories = tdee + adjustment
      weeklyChange = `+${selectedIntensity?.weeklyChange || "0.5 kg"}`
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      targetCalories = tdee
      weeklyChange = "0 kg"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    }

    const minCalories = gender === "male" ? 1500 : 1200
    let warning: string | null = null

    if (targetCalories < minCalories) {
      warning = `Target calories are below the safe minimum (${minCalories} kcal). Adjusted to safe level.`
      targetCalories = minCalories
    }

    const proteinCals = targetCalories * 0.275
    const carbsCals = targetCalories * 0.45
    const fatCals = targetCalories * 0.275

    setResult({
      bmr: Math.round(bmr),
      tdee: Math.round(tdee),
      targetCalories: Math.round(targetCalories),
      weeklyChange,
      macros: {
        protein: Math.round(proteinCals / 4),
        carbs: Math.round(carbsCals / 4),
        fat: Math.round(fatCals / 9),
      },
      warning,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setGender("male")
    setFormula("mifflin")
    setActivityLevel("moderate")
    setGoal("maintain")
    setIntensity("moderate")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My Daily Calorie Target: ${result.targetCalories} kcal | BMR: ${result.bmr} kcal | TDEE: ${result.tdee} kcal | Weekly Change: ${result.weeklyChange}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Calorie Target",
          text: `I calculated my daily calorie needs using CalcHub! Target: ${result.targetCalories} kcal/day`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Calorie Calculator</CardTitle>
                    <CardDescription>Calculate your daily calorie needs</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Formula Toggle */}
                <div className="space-y-2">
                  <Label>Formula Method</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setFormula("mifflin")}
                      className={`py-2 px-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        formula === "mifflin"
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-muted hover:border-primary/50"
                      }`}
                    >
                      Mifflin-St Jeor
                    </button>
                    <button
                      onClick={() => setFormula("harris")}
                      className={`py-2 px-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        formula === "harris"
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-muted hover:border-primary/50"
                      }`}
                    >
                      Harris-Benedict
                    </button>
                  </div>
                </div>

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setGender("male")}
                      className={`py-2 px-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        gender === "male"
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-muted hover:border-primary/50"
                      }`}
                    >
                      Male
                    </button>
                    <button
                      onClick={() => setGender("female")}
                      className={`py-2 px-3 rounded-lg border-2 text-sm font-medium transition-all ${
                        gender === "female"
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-muted hover:border-primary/50"
                      }`}
                    >
                      Female
                    </button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                    max="100"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="Feet"
                        value={heightFeet}
                        onChange={(e) => setHeightFeet(e.target.value)}
                        min="0"
                      />
                      <Input
                        type="number"
                        placeholder="Inches"
                        value={heightInches}
                        onChange={(e) => setHeightInches(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                )}

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <div className="grid grid-cols-5 gap-1">
                    {activityLevels.map((level) => {
                      const Icon = level.icon
                      return (
                        <button
                          key={level.id}
                          onClick={() => setActivityLevel(level.id as ActivityLevel)}
                          className={`p-2 rounded-lg border-2 transition-all flex flex-col items-center ${
                            activityLevel === level.id
                              ? "border-primary bg-primary/10"
                              : "border-muted hover:border-primary/50"
                          }`}
                          title={level.description}
                        >
                          <Icon
                            className={`h-4 w-4 ${activityLevel === level.id ? "text-primary" : "text-muted-foreground"}`}
                          />
                          <span className="text-[10px] mt-1 font-medium">{level.label}</span>
                        </button>
                      )
                    })}
                  </div>
                </div>

                {/* Goal Selection */}
                <div className="space-y-2">
                  <Label>Your Goal</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setGoal("lose")}
                      className={`py-2 px-2 rounded-lg border-2 text-sm font-medium transition-all flex flex-col items-center gap-1 ${
                        goal === "lose"
                          ? "border-blue-500 bg-blue-50 text-blue-600"
                          : "border-muted hover:border-blue-500/50"
                      }`}
                    >
                      <TrendingDown className="h-4 w-4" />
                      Lose
                    </button>
                    <button
                      onClick={() => setGoal("maintain")}
                      className={`py-2 px-2 rounded-lg border-2 text-sm font-medium transition-all flex flex-col items-center gap-1 ${
                        goal === "maintain"
                          ? "border-green-500 bg-green-50 text-green-600"
                          : "border-muted hover:border-green-500/50"
                      }`}
                    >
                      <Minus className="h-4 w-4" />
                      Maintain
                    </button>
                    <button
                      onClick={() => setGoal("gain")}
                      className={`py-2 px-2 rounded-lg border-2 text-sm font-medium transition-all flex flex-col items-center gap-1 ${
                        goal === "gain"
                          ? "border-orange-500 bg-orange-50 text-orange-600"
                          : "border-muted hover:border-orange-500/50"
                      }`}
                    >
                      <TrendingUp className="h-4 w-4" />
                      Gain
                    </button>
                  </div>
                </div>

                {/* Intensity Selection */}
                {goal !== "maintain" && (
                  <div className="space-y-2">
                    <Label>Intensity</Label>
                    <div className="grid grid-cols-3 gap-2">
                      {intensityOptions.map((option) => (
                        <button
                          key={option.id}
                          onClick={() => setIntensity(option.id as Intensity)}
                          className={`py-2 px-2 rounded-lg border-2 text-xs font-medium transition-all ${
                            intensity === option.id
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-muted hover:border-primary/50"
                          }`}
                        >
                          <p className="font-semibold">{option.label}</p>
                          <p className="text-muted-foreground">±{option.adjustment}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCalories} className="w-full" size="lg">
                  Calculate Calories
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    {result.warning && (
                      <div className="flex items-start gap-2 p-2 rounded-lg bg-amber-100 border border-amber-300 text-amber-800 mb-3">
                        <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                        <p className="text-xs">{result.warning}</p>
                      </div>
                    )}
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Daily Calorie Target</p>
                      <p className={`text-5xl font-bold ${result.color} mb-1`}>
                        {result.targetCalories.toLocaleString()}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>kcal/day</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        BMR: {result.bmr} | TDEE: {result.tdee} | Weekly: {result.weeklyChange}
                      </p>
                    </div>

                    {/* Macros */}
                    <div className="grid grid-cols-3 gap-2 mt-4">
                      <div className="bg-white/60 rounded-lg p-2 text-center">
                        <p className="text-xs text-muted-foreground">Protein</p>
                        <p className="font-bold">{result.macros.protein}g</p>
                      </div>
                      <div className="bg-white/60 rounded-lg p-2 text-center">
                        <p className="text-xs text-muted-foreground">Carbs</p>
                        <p className="font-bold">{result.macros.carbs}g</p>
                      </div>
                      <div className="bg-white/60 rounded-lg p-2 text-center">
                        <p className="text-xs text-muted-foreground">Fat</p>
                        <p className="font-bold">{result.macros.fat}g</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Activity Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {activityLevels.map((level) => {
                      const Icon = level.icon
                      return (
                        <div key={level.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center gap-2">
                            <Icon className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium text-sm">{level.label}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">×{level.multiplier}</span>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula Info</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-xs mb-2">Mifflin-St Jeor (Recommended)</p>
                    <p className="text-xs">Men: (10 × weight) + (6.25 × height) - (5 × age) + 5</p>
                    <p className="text-xs">Women: (10 × weight) + (6.25 × height) - (5 × age) - 161</p>
                  </div>
                  <p className="text-xs">
                    The Mifflin-St Jeor equation is considered the most accurate for calculating BMR in most people.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What are Calories */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Calories and Why Do They Matter?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calories are units of energy that measure the amount of energy food provides to your body. Every
                  function your body performs—from breathing and circulating blood to thinking and exercising—requires
                  energy, which comes from the calories in the food you eat. Understanding your caloric needs is
                  fundamental to achieving and maintaining a healthy weight, whether your goal is weight loss, muscle
                  gain, or simply maintaining your current physique.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of energy balance is central to weight management. When you consume more calories than
                  your body burns, the excess energy is stored as fat, leading to weight gain. Conversely, when you
                  consume fewer calories than you burn, your body uses stored fat for energy, resulting in weight loss.
                  This calculator helps you determine exactly how many calories you need based on your unique
                  characteristics and activity level.
                </p>
              </CardContent>
            </Card>

            {/* Understanding BMR and TDEE */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding BMR and TDEE</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Your Basal Metabolic Rate (BMR) represents the number of calories your body needs to perform basic
                  life-sustaining functions while at complete rest. These functions include breathing, blood
                  circulation, cell production, nutrient processing, and temperature regulation. BMR typically accounts
                  for about 60-75% of your total daily calorie expenditure, making it the largest component of your
                  energy needs.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Total Daily Energy Expenditure (TDEE) takes your BMR and factors in your physical activity level to
                  give you a complete picture of how many calories you burn in a day. Your TDEE includes not just your
                  BMR, but also the thermic effect of food (energy used to digest food), non-exercise activity
                  thermogenesis (NEAT), and exercise activity thermogenesis. Understanding both values helps you create
                  an effective nutrition plan aligned with your goals.
                </p>
              </CardContent>
            </Card>

            {/* How the Formulas Work */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>How the Calorie Formulas Work</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator offers two scientifically validated formulas for estimating your BMR. The Mifflin-St
                  Jeor equation, developed in 1990, is widely considered the most accurate formula for most people and
                  is recommended by the Academy of Nutrition and Dietetics. It accounts for the changes in lifestyle and
                  body composition that have occurred since older formulas were developed.
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Mifflin-St Jeor Equation</h4>
                    <p className="text-green-700 text-sm">
                      The most accurate and widely recommended formula. Studies show it predicts actual metabolic rate
                      within 10% for most individuals.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Harris-Benedict Equation</h4>
                    <p className="text-blue-700 text-sm">
                      A classic formula from 1918, revised in 1984. Still useful but may overestimate caloric needs for
                      some individuals.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Setting the Right Deficit/Surplus */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Apple className="h-5 w-5 text-primary" />
                  <CardTitle>Setting the Right Caloric Deficit or Surplus</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When aiming for weight loss, creating a moderate caloric deficit is key to sustainable results. A
                  deficit of 500 calories per day translates to approximately 0.5 kg (1 pound) of fat loss per week, as
                  one kilogram of body fat contains roughly 7,700 calories. While larger deficits can produce faster
                  results, they may lead to muscle loss, nutrient deficiencies, metabolic adaptation, and are harder to
                  maintain long-term.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For muscle gain, a modest caloric surplus of 250-500 calories above your TDEE is recommended. This
                  provides your body with the extra energy needed to build new muscle tissue without excessive fat gain.
                  The rate of muscle gain varies based on training experience, genetics, and protein intake, but
                  beginners can typically expect to gain 0.5-1 kg of muscle per month with proper training and
                  nutrition.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator automatically adjusts for safe minimum calorie thresholds—1500 kcal for men and 1200
                  kcal for women—to prevent the negative health effects associated with very low calorie intakes. If
                  your calculated target falls below these minimums, the calculator will alert you and adjust to the
                  safe level.
                </p>
              </CardContent>
            </Card>

            {/* Tips for Success */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Utensils className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Successful Calorie Management</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Track Your Intake</h4>
                    <p className="text-muted-foreground text-sm">
                      Use a food diary or tracking app to monitor your calorie intake accurately. Studies show that
                      people who track their food are more successful at achieving their weight goals.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Prioritize Protein</h4>
                    <p className="text-muted-foreground text-sm">
                      Adequate protein intake (1.6-2.2g per kg of body weight) helps preserve muscle mass during weight
                      loss and supports muscle growth during bulking phases.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Be Patient and Consistent</h4>
                    <p className="text-muted-foreground text-sm">
                      Sustainable weight change takes time. Focus on weekly averages rather than daily fluctuations, and
                      give your body 2-4 weeks to respond to caloric changes.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Adjust as Needed</h4>
                    <p className="text-muted-foreground text-sm">
                      Your caloric needs change as you lose or gain weight. Recalculate every 4-6 weeks or when progress
                      stalls to ensure your targets remain accurate.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
