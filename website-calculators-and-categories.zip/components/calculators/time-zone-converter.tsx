"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Globe,
  Info,
  ArrowRightLeft,
  Clock,
  Sun,
  Moon,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface TimeZone {
  id: string
  name: string
  offset: number
  abbr: string
  region: string
}

interface ConversionResult {
  sourceTime: string
  sourceDate: string
  targetTime: string
  targetDate: string
  timeDifference: number
  dateChanged: "previous" | "same" | "next"
  sourceOffset: string
  targetOffset: string
}

const timeZones: TimeZone[] = [
  // UTC
  { id: "UTC", name: "UTC (Coordinated Universal Time)", offset: 0, abbr: "UTC", region: "Universal" },
  // Americas
  { id: "America/New_York", name: "New York (Eastern Time)", offset: -5, abbr: "EST/EDT", region: "Americas" },
  { id: "America/Chicago", name: "Chicago (Central Time)", offset: -6, abbr: "CST/CDT", region: "Americas" },
  { id: "America/Denver", name: "Denver (Mountain Time)", offset: -7, abbr: "MST/MDT", region: "Americas" },
  { id: "America/Los_Angeles", name: "Los Angeles (Pacific Time)", offset: -8, abbr: "PST/PDT", region: "Americas" },
  { id: "America/Anchorage", name: "Anchorage (Alaska Time)", offset: -9, abbr: "AKST/AKDT", region: "Americas" },
  { id: "Pacific/Honolulu", name: "Honolulu (Hawaii Time)", offset: -10, abbr: "HST", region: "Americas" },
  { id: "America/Toronto", name: "Toronto (Eastern Time)", offset: -5, abbr: "EST/EDT", region: "Americas" },
  { id: "America/Vancouver", name: "Vancouver (Pacific Time)", offset: -8, abbr: "PST/PDT", region: "Americas" },
  { id: "America/Mexico_City", name: "Mexico City (Central Time)", offset: -6, abbr: "CST/CDT", region: "Americas" },
  { id: "America/Sao_Paulo", name: "São Paulo (Brasília Time)", offset: -3, abbr: "BRT", region: "Americas" },
  { id: "America/Buenos_Aires", name: "Buenos Aires (Argentina Time)", offset: -3, abbr: "ART", region: "Americas" },
  // Europe
  { id: "Europe/London", name: "London (Greenwich Mean Time)", offset: 0, abbr: "GMT/BST", region: "Europe" },
  { id: "Europe/Paris", name: "Paris (Central European Time)", offset: 1, abbr: "CET/CEST", region: "Europe" },
  { id: "Europe/Berlin", name: "Berlin (Central European Time)", offset: 1, abbr: "CET/CEST", region: "Europe" },
  { id: "Europe/Rome", name: "Rome (Central European Time)", offset: 1, abbr: "CET/CEST", region: "Europe" },
  { id: "Europe/Madrid", name: "Madrid (Central European Time)", offset: 1, abbr: "CET/CEST", region: "Europe" },
  { id: "Europe/Amsterdam", name: "Amsterdam (Central European Time)", offset: 1, abbr: "CET/CEST", region: "Europe" },
  { id: "Europe/Moscow", name: "Moscow (Moscow Time)", offset: 3, abbr: "MSK", region: "Europe" },
  { id: "Europe/Istanbul", name: "Istanbul (Turkey Time)", offset: 3, abbr: "TRT", region: "Europe" },
  // Asia
  { id: "Asia/Dubai", name: "Dubai (Gulf Standard Time)", offset: 4, abbr: "GST", region: "Asia" },
  { id: "Asia/Karachi", name: "Karachi (Pakistan Time)", offset: 5, abbr: "PKT", region: "Asia" },
  { id: "Asia/Kolkata", name: "Mumbai/Delhi (India Standard Time)", offset: 5.5, abbr: "IST", region: "Asia" },
  { id: "Asia/Dhaka", name: "Dhaka (Bangladesh Time)", offset: 6, abbr: "BST", region: "Asia" },
  { id: "Asia/Bangkok", name: "Bangkok (Indochina Time)", offset: 7, abbr: "ICT", region: "Asia" },
  { id: "Asia/Jakarta", name: "Jakarta (Western Indonesia Time)", offset: 7, abbr: "WIB", region: "Asia" },
  { id: "Asia/Singapore", name: "Singapore (Singapore Time)", offset: 8, abbr: "SGT", region: "Asia" },
  { id: "Asia/Hong_Kong", name: "Hong Kong (Hong Kong Time)", offset: 8, abbr: "HKT", region: "Asia" },
  { id: "Asia/Shanghai", name: "Shanghai/Beijing (China Standard Time)", offset: 8, abbr: "CST", region: "Asia" },
  { id: "Asia/Tokyo", name: "Tokyo (Japan Standard Time)", offset: 9, abbr: "JST", region: "Asia" },
  { id: "Asia/Seoul", name: "Seoul (Korea Standard Time)", offset: 9, abbr: "KST", region: "Asia" },
  // Australia & Pacific
  { id: "Australia/Perth", name: "Perth (Australian Western Time)", offset: 8, abbr: "AWST", region: "Australia" },
  {
    id: "Australia/Adelaide",
    name: "Adelaide (Australian Central Time)",
    offset: 9.5,
    abbr: "ACST/ACDT",
    region: "Australia",
  },
  {
    id: "Australia/Sydney",
    name: "Sydney (Australian Eastern Time)",
    offset: 10,
    abbr: "AEST/AEDT",
    region: "Australia",
  },
  {
    id: "Australia/Brisbane",
    name: "Brisbane (Australian Eastern Time)",
    offset: 10,
    abbr: "AEST",
    region: "Australia",
  },
  { id: "Pacific/Auckland", name: "Auckland (New Zealand Time)", offset: 12, abbr: "NZST/NZDT", region: "Pacific" },
  { id: "Pacific/Fiji", name: "Fiji (Fiji Time)", offset: 12, abbr: "FJT", region: "Pacific" },
  // Africa & Middle East
  { id: "Africa/Cairo", name: "Cairo (Eastern European Time)", offset: 2, abbr: "EET", region: "Africa" },
  { id: "Africa/Johannesburg", name: "Johannesburg (South Africa Time)", offset: 2, abbr: "SAST", region: "Africa" },
  { id: "Africa/Lagos", name: "Lagos (West Africa Time)", offset: 1, abbr: "WAT", region: "Africa" },
  { id: "Asia/Jerusalem", name: "Jerusalem (Israel Time)", offset: 2, abbr: "IST/IDT", region: "Middle East" },
  { id: "Asia/Riyadh", name: "Riyadh (Arabia Standard Time)", offset: 3, abbr: "AST", region: "Middle East" },
]

export function TimeZoneConverter() {
  const [sourceDate, setSourceDate] = useState("")
  const [sourceTime, setSourceTime] = useState("")
  const [sourceZone, setSourceZone] = useState("America/New_York")
  const [targetZone, setTargetZone] = useState("Europe/London")
  const [use24Hour, setUse24Hour] = useState(true)
  const [result, setResult] = useState<ConversionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const groupedTimeZones = useMemo(() => {
    const groups: Record<string, TimeZone[]> = {}
    timeZones.forEach((tz) => {
      if (!groups[tz.region]) {
        groups[tz.region] = []
      }
      groups[tz.region].push(tz)
    })
    return groups
  }, [])

  const formatOffset = (offset: number): string => {
    const sign = offset >= 0 ? "+" : "-"
    const absOffset = Math.abs(offset)
    const hours = Math.floor(absOffset)
    const minutes = (absOffset % 1) * 60
    return `UTC${sign}${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
  }

  const formatTime = (hours: number, minutes: number, use24: boolean): string => {
    if (use24) {
      return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    } else {
      const period = hours >= 12 ? "PM" : "AM"
      const displayHours = hours % 12 || 12
      return `${displayHours}:${minutes.toString().padStart(2, "0")} ${period}`
    }
  }

  const formatDate = (year: number, month: number, day: number): string => {
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    const date = new Date(year, month - 1, day)
    return `${dayNames[date.getDay()]}, ${monthNames[month - 1]} ${day}, ${year}`
  }

  const convertTime = () => {
    setError("")
    setResult(null)

    if (!sourceDate) {
      setError("Please select a date")
      return
    }

    if (!sourceTime) {
      setError("Please enter a time")
      return
    }

    const sourceTz = timeZones.find((tz) => tz.id === sourceZone)
    const targetTz = timeZones.find((tz) => tz.id === targetZone)

    if (!sourceTz || !targetTz) {
      setError("Invalid time zone selection")
      return
    }

    // Parse input
    const [year, month, day] = sourceDate.split("-").map(Number)
    const [hours, minutes] = sourceTime.split(":").map(Number)

    // Calculate the offset difference in hours
    const offsetDiff = targetTz.offset - sourceTz.offset

    // Convert to target time
    let targetMinutes = minutes
    let targetHours = hours + offsetDiff
    let targetDay = day
    let targetMonth = month
    let targetYear = year

    // Handle fractional hours (e.g., India's +5:30)
    if (offsetDiff % 1 !== 0) {
      targetMinutes += (offsetDiff % 1) * 60
      targetHours = Math.floor(targetHours)
    }

    // Normalize minutes
    if (targetMinutes >= 60) {
      targetMinutes -= 60
      targetHours += 1
    } else if (targetMinutes < 0) {
      targetMinutes += 60
      targetHours -= 1
    }

    // Track date change
    let dateChanged: "previous" | "same" | "next" = "same"

    // Normalize hours and adjust date
    if (targetHours >= 24) {
      targetHours -= 24
      targetDay += 1
      dateChanged = "next"
    } else if (targetHours < 0) {
      targetHours += 24
      targetDay -= 1
      dateChanged = "previous"
    }

    // Handle month/year rollover
    const daysInMonth = new Date(targetYear, targetMonth, 0).getDate()
    if (targetDay > daysInMonth) {
      targetDay = 1
      targetMonth += 1
      if (targetMonth > 12) {
        targetMonth = 1
        targetYear += 1
      }
    } else if (targetDay < 1) {
      targetMonth -= 1
      if (targetMonth < 1) {
        targetMonth = 12
        targetYear -= 1
      }
      targetDay = new Date(targetYear, targetMonth, 0).getDate()
    }

    setResult({
      sourceTime: formatTime(hours, minutes, use24Hour),
      sourceDate: formatDate(year, month, day),
      targetTime: formatTime(targetHours, Math.round(targetMinutes), use24Hour),
      targetDate: formatDate(targetYear, targetMonth, targetDay),
      timeDifference: offsetDiff,
      dateChanged,
      sourceOffset: formatOffset(sourceTz.offset),
      targetOffset: formatOffset(targetTz.offset),
    })
  }

  const handleSwapZones = () => {
    const temp = sourceZone
    setSourceZone(targetZone)
    setTargetZone(temp)
    setResult(null)
  }

  const handleReset = () => {
    setSourceDate("")
    setSourceTime("")
    setSourceZone("America/New_York")
    setTargetZone("Europe/London")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const sourceTz = timeZones.find((tz) => tz.id === sourceZone)
      const targetTz = timeZones.find((tz) => tz.id === targetZone)
      await navigator.clipboard.writeText(
        `${result.sourceTime} ${sourceTz?.abbr} (${result.sourceDate}) = ${result.targetTime} ${targetTz?.abbr} (${result.targetDate})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const sourceTz = timeZones.find((tz) => tz.id === sourceZone)
      const targetTz = timeZones.find((tz) => tz.id === targetZone)
      try {
        await navigator.share({
          title: "Time Zone Conversion",
          text: `${result.sourceTime} ${sourceTz?.abbr} = ${result.targetTime} ${targetTz?.abbr}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const setCurrentTime = () => {
    const now = new Date()
    setSourceDate(now.toISOString().split("T")[0])
    setSourceTime(`${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Globe className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Time Zone Converter</CardTitle>
                    <CardDescription>Convert time between different zones</CardDescription>
                  </div>
                </div>

                {/* Format Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Time Format</span>
                  <button
                    onClick={() => setUse24Hour(!use24Hour)}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        !use24Hour ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        use24Hour ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      24-Hour
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        !use24Hour ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      12-Hour
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Date Input */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="sourceDate">Date</Label>
                    <Button variant="link" size="sm" onClick={setCurrentTime} className="h-auto p-0 text-xs">
                      Use current time
                    </Button>
                  </div>
                  <Input
                    id="sourceDate"
                    type="date"
                    value={sourceDate}
                    onChange={(e) => setSourceDate(e.target.value)}
                  />
                </div>

                {/* Time Input */}
                <div className="space-y-2">
                  <Label htmlFor="sourceTime">Time</Label>
                  <Input
                    id="sourceTime"
                    type="time"
                    value={sourceTime}
                    onChange={(e) => setSourceTime(e.target.value)}
                  />
                </div>

                {/* Source Time Zone */}
                <div className="space-y-2">
                  <Label>From Time Zone</Label>
                  <Select value={sourceZone} onValueChange={setSourceZone}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select source time zone" />
                    </SelectTrigger>
                    <SelectContent className="max-h-80">
                      {Object.entries(groupedTimeZones).map(([region, zones]) => (
                        <div key={region}>
                          <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted">
                            {region}
                          </div>
                          {zones.map((tz) => (
                            <SelectItem key={tz.id} value={tz.id}>
                              {tz.name} ({formatOffset(tz.offset)})
                            </SelectItem>
                          ))}
                        </div>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Swap Button */}
                <div className="flex justify-center">
                  <Button variant="outline" size="sm" onClick={handleSwapZones} className="gap-2 bg-transparent">
                    <ArrowRightLeft className="h-4 w-4" />
                    Swap Zones
                  </Button>
                </div>

                {/* Target Time Zone */}
                <div className="space-y-2">
                  <Label>To Time Zone</Label>
                  <Select value={targetZone} onValueChange={setTargetZone}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select target time zone" />
                    </SelectTrigger>
                    <SelectContent className="max-h-80">
                      {Object.entries(groupedTimeZones).map(([region, zones]) => (
                        <div key={region}>
                          <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted">
                            {region}
                          </div>
                          {zones.map((tz) => (
                            <SelectItem key={tz.id} value={tz.id}>
                              {tz.name} ({formatOffset(tz.offset)})
                            </SelectItem>
                          ))}
                        </div>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Convert Button */}
                <Button onClick={convertTime} className="w-full" size="lg">
                  Convert Time
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="space-y-4">
                      {/* Source */}
                      <div className="text-center pb-3 border-b border-cyan-200">
                        <p className="text-xs text-muted-foreground mb-1">
                          {timeZones.find((tz) => tz.id === sourceZone)?.name}
                        </p>
                        <p className="text-2xl font-bold text-cyan-700">{result.sourceTime}</p>
                        <p className="text-sm text-cyan-600">{result.sourceDate}</p>
                        <p className="text-xs text-muted-foreground mt-1">{result.sourceOffset}</p>
                      </div>

                      {/* Arrow */}
                      <div className="flex justify-center">
                        <div className="flex items-center gap-2 text-cyan-600">
                          <Clock className="h-4 w-4" />
                          <span className="text-sm font-medium">
                            {result.timeDifference >= 0 ? "+" : ""}
                            {result.timeDifference} hours
                          </span>
                        </div>
                      </div>

                      {/* Target */}
                      <div className="text-center pt-3 border-t border-cyan-200">
                        <p className="text-xs text-muted-foreground mb-1">
                          {timeZones.find((tz) => tz.id === targetZone)?.name}
                        </p>
                        <p className="text-4xl font-bold text-cyan-700">{result.targetTime}</p>
                        <p className="text-sm text-cyan-600">{result.targetDate}</p>
                        <p className="text-xs text-muted-foreground mt-1">{result.targetOffset}</p>
                      </div>

                      {/* Date Change Indicator */}
                      {result.dateChanged !== "same" && (
                        <div
                          className={`flex items-center justify-center gap-2 p-2 rounded-lg ${
                            result.dateChanged === "next" ? "bg-amber-100 text-amber-700" : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {result.dateChanged === "next" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                          <span className="text-sm font-medium">
                            {result.dateChanged === "next" ? "Next day" : "Previous day"}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>

                    {/* Step-by-step breakdown */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="flex items-center gap-2 text-sm text-cyan-700 hover:text-cyan-800 transition-colors w-full justify-center"
                      >
                        {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        {showSteps ? "Hide calculation" : "Show calculation"}
                      </button>
                      {showSteps && (
                        <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                          <p>
                            <span className="font-medium">1.</span> Source time: {result.sourceTime} (
                            {result.sourceOffset})
                          </p>
                          <p>
                            <span className="font-medium">2.</span> Target zone offset: {result.targetOffset}
                          </p>
                          <p>
                            <span className="font-medium">3.</span> Time difference:{" "}
                            {result.timeDifference >= 0 ? "+" : ""}
                            {result.timeDifference} hours
                          </p>
                          <p>
                            <span className="font-medium">4.</span> Result: {result.targetTime} on {result.targetDate}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Popular Time Zones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span>New York (EST/EDT)</span>
                      <span className="text-muted-foreground">UTC-5</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span>London (GMT/BST)</span>
                      <span className="text-muted-foreground">UTC+0</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span>Paris (CET/CEST)</span>
                      <span className="text-muted-foreground">UTC+1</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span>Dubai (GST)</span>
                      <span className="text-muted-foreground">UTC+4</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span>Mumbai (IST)</span>
                      <span className="text-muted-foreground">UTC+5:30</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span>Tokyo (JST)</span>
                      <span className="text-muted-foreground">UTC+9</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span>Sydney (AEST/AEDT)</span>
                      <span className="text-muted-foreground">UTC+10</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conversion Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">
                      Target Time = Source Time + (Target Offset - Source Offset)
                    </p>
                  </div>
                  <p>
                    Time zone offsets are measured relative to Coordinated Universal Time (UTC). Add or subtract the
                    difference in offsets to convert between zones.
                  </p>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-4">
                  <div className="flex gap-3 text-sm text-amber-800">
                    <Info className="h-5 w-5 flex-shrink-0 mt-0.5" />
                    <p>
                      Time conversions depend on time zone databases and daylight saving rules, which may change over
                      time. This calculator uses standard offsets and may not reflect recent DST changes.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Time Zones</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Time zones are regions of the Earth that observe a uniform standard time for legal, commercial, and
                  social purposes. The world is divided into 24 primary time zones, each roughly 15 degrees of longitude
                  wide, corresponding to one hour of time difference. The primary reference point is Coordinated
                  Universal Time (UTC), formerly known as Greenwich Mean Time (GMT), which runs through the Royal
                  Observatory in Greenwich, London.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Time zones to the east of UTC are ahead (positive offset), while zones to the west are behind
                  (negative offset). For example, Tokyo (UTC+9) is 9 hours ahead of UTC, while New York (UTC-5 during
                  standard time) is 5 hours behind. Some regions use fractional offsets, such as India (UTC+5:30) and
                  Nepal (UTC+5:45).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Sun className="h-5 w-5 text-primary" />
                  <CardTitle>Daylight Saving Time</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Daylight Saving Time (DST) is the practice of advancing clocks during warmer months so that evenings
                  have more daylight. Not all countries or regions observe DST, and those that do may change their
                  clocks on different dates. This can cause temporary shifts in the time difference between regions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, when the US observes DST (March to November), New York shifts from UTC-5 (EST) to UTC-4
                  (EDT). Meanwhile, countries like Japan, India, and most of Africa do not observe DST at all. The
                  Southern Hemisphere observes DST during opposite months, adding another layer of complexity to
                  international time coordination.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid sm:grid-cols-2 gap-4 mt-2">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Business & Remote Work</h4>
                    <p className="text-sm text-muted-foreground">
                      Coordinate meetings across global teams, schedule international calls, and manage deadlines across
                      different time zones.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Travel Planning</h4>
                    <p className="text-sm text-muted-foreground">
                      Calculate arrival times, plan connections, and adjust to new time zones when traveling
                      internationally.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Live Events</h4>
                    <p className="text-sm text-muted-foreground">
                      Determine when sports events, webinars, product launches, or live streams will occur in your local
                      time.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Personal Communication</h4>
                    <p className="text-sm text-muted-foreground">
                      Find appropriate times to call friends and family in different countries without disturbing their
                      sleep.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
