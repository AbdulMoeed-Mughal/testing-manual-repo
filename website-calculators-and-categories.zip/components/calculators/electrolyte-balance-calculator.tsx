"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Droplets,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface ElectrolyteResult {
  sodiumLoss: number
  potassiumLoss: number
  calciumLoss: number
  magnesiumLoss: number
  sodiumIntake: number
  potassiumIntake: number
  calciumIntake: number
  magnesiumIntake: number
  sodiumBalance: "deficit" | "adequate" | "excess"
  potassiumBalance: "deficit" | "adequate" | "excess"
  calciumBalance: "deficit" | "adequate" | "excess"
  magnesiumBalance: "deficit" | "adequate" | "excess"
  overallStatus: string
  statusColor: string
  statusBg: string
  fluidRecommendation: number
}

export function ElectrolyteBalanceCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [fluidIntake, setFluidIntake] = useState("")
  const [activityDuration, setActivityDuration] = useState("")
  const [activityIntensity, setActivityIntensity] = useState<"low" | "moderate" | "high">("moderate")
  const [sodiumIntake, setSodiumIntake] = useState("")
  const [potassiumIntake, setPotassiumIntake] = useState("")
  const [calciumIntake, setCalciumIntake] = useState("")
  const [magnesiumIntake, setMagnesiumIntake] = useState("")
  const [temperature, setTemperature] = useState("")
  const [humidity, setHumidity] = useState("")
  const [tempUnit, setTempUnit] = useState<"celsius" | "fahrenheit">("celsius")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<ElectrolyteResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateElectrolyteBalance = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const ageNum = Number.parseFloat(age)
    const fluidIntakeNum = Number.parseFloat(fluidIntake)
    const durationNum = Number.parseFloat(activityDuration)

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (isNaN(fluidIntakeNum) || fluidIntakeNum < 0) {
      setError("Please enter a valid daily fluid intake")
      return
    }

    if (isNaN(durationNum) || durationNum < 0) {
      setError("Please enter a valid activity duration")
      return
    }

    // Convert to metric if needed
    const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum
    const fluidLiters = unitSystem === "imperial" ? fluidIntakeNum * 0.0295735 : fluidIntakeNum

    // Parse optional inputs
    const sodiumIntakeNum = Number.parseFloat(sodiumIntake) || 0
    const potassiumIntakeNum = Number.parseFloat(potassiumIntake) || 0
    const calciumIntakeNum = Number.parseFloat(calciumIntake) || 0
    const magnesiumIntakeNum = Number.parseFloat(magnesiumIntake) || 0

    // Environmental factors
    let tempCelsius = Number.parseFloat(temperature) || 20
    if (tempUnit === "fahrenheit" && temperature) {
      tempCelsius = ((tempCelsius - 32) * 5) / 9
    }
    const humidityNum = Number.parseFloat(humidity) || 50

    // Intensity multipliers
    const intensityMultiplier = {
      low: 0.5,
      moderate: 1.0,
      high: 1.5,
    }[activityIntensity]

    // Environmental multiplier
    let envMultiplier = 1.0
    if (tempCelsius > 25) envMultiplier += (tempCelsius - 25) * 0.03
    if (humidityNum > 60) envMultiplier += (humidityNum - 60) * 0.01

    // Estimate sweat rate (L/hour) based on weight and intensity
    const baseSweatRate = weightKg * 0.01 * intensityMultiplier * envMultiplier
    const totalSweatLoss = baseSweatRate * (durationNum / 60)

    // Electrolyte loss per liter of sweat (mg)
    const sodiumPerLiter = gender === "male" ? 1150 : 1050
    const potassiumPerLiter = 200
    const calciumPerLiter = 40
    const magnesiumPerLiter = 25

    // Calculate losses
    const sodiumLoss = Math.round(totalSweatLoss * sodiumPerLiter)
    const potassiumLoss = Math.round(totalSweatLoss * potassiumPerLiter)
    const calciumLoss = Math.round(totalSweatLoss * calciumPerLiter)
    const magnesiumLoss = Math.round(totalSweatLoss * magnesiumPerLiter)

    // Daily requirements (mg)
    const sodiumReq = 2300
    const potassiumReq = gender === "male" ? 3400 : 2600
    const calciumReq = ageNum > 50 ? 1200 : 1000
    const magnesiumReq = gender === "male" ? 420 : 320

    // Total needs = daily requirement + activity loss
    const totalSodiumNeed = sodiumReq + sodiumLoss
    const totalPotassiumNeed = potassiumReq + potassiumLoss
    const totalCalciumNeed = calciumReq + calciumLoss
    const totalMagnesiumNeed = magnesiumReq + magnesiumLoss

    // Determine balance status
    const getBalance = (intake: number, need: number): "deficit" | "adequate" | "excess" => {
      if (intake < need * 0.8) return "deficit"
      if (intake > need * 1.2) return "excess"
      return "adequate"
    }

    const sodiumBalance = getBalance(sodiumIntakeNum, totalSodiumNeed)
    const potassiumBalance = getBalance(potassiumIntakeNum, totalPotassiumNeed)
    const calciumBalance = getBalance(calciumIntakeNum, totalCalciumNeed)
    const magnesiumBalance = getBalance(magnesiumIntakeNum, totalMagnesiumNeed)

    // Overall status
    const balances = [sodiumBalance, potassiumBalance, calciumBalance, magnesiumBalance]
    const deficitCount = balances.filter((b) => b === "deficit").length
    const excessCount = balances.filter((b) => b === "excess").length

    let overallStatus: string
    let statusColor: string
    let statusBg: string

    if (deficitCount === 0 && excessCount === 0) {
      overallStatus = "Balanced"
      statusColor = "text-green-600"
      statusBg = "bg-green-50 border-green-200"
    } else if (deficitCount >= 2) {
      overallStatus = "Multiple Deficits"
      statusColor = "text-red-600"
      statusBg = "bg-red-50 border-red-200"
    } else if (excessCount >= 2) {
      overallStatus = "Multiple Excess"
      statusColor = "text-orange-600"
      statusBg = "bg-orange-50 border-orange-200"
    } else {
      overallStatus = "Minor Imbalance"
      statusColor = "text-yellow-600"
      statusBg = "bg-yellow-50 border-yellow-200"
    }

    // Fluid recommendation
    const baseFluid = weightKg * 0.033
    const activityFluid = totalSweatLoss * 1.5
    const fluidRecommendation = Math.round((baseFluid + activityFluid) * 10) / 10

    setResult({
      sodiumLoss,
      potassiumLoss,
      calciumLoss,
      magnesiumLoss,
      sodiumIntake: Math.round(totalSodiumNeed),
      potassiumIntake: Math.round(totalPotassiumNeed),
      calciumIntake: Math.round(totalCalciumNeed),
      magnesiumIntake: Math.round(totalMagnesiumNeed),
      sodiumBalance,
      potassiumBalance,
      calciumBalance,
      magnesiumBalance,
      overallStatus,
      statusColor,
      statusBg,
      fluidRecommendation,
    })
  }

  const handleReset = () => {
    setWeight("")
    setAge("")
    setGender("male")
    setFluidIntake("")
    setActivityDuration("")
    setActivityIntensity("moderate")
    setSodiumIntake("")
    setPotassiumIntake("")
    setCalciumIntake("")
    setMagnesiumIntake("")
    setTemperature("")
    setHumidity("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Electrolyte Balance: ${result.overallStatus}\nRecommended Sodium: ${result.sodiumIntake}mg\nRecommended Potassium: ${result.potassiumIntake}mg\nRecommended Calcium: ${result.calciumIntake}mg\nRecommended Magnesium: ${result.magnesiumIntake}mg\nFluid Recommendation: ${result.fluidRecommendation}L/day`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Electrolyte Balance Results",
          text: `My electrolyte balance status: ${result.overallStatus}. Calculated with CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setFluidIntake("")
    setResult(null)
    setError("")
  }

  const getBalanceColor = (balance: "deficit" | "adequate" | "excess") => {
    switch (balance) {
      case "deficit":
        return "text-red-600 bg-red-50"
      case "adequate":
        return "text-green-600 bg-green-50"
      case "excess":
        return "text-orange-600 bg-orange-50"
    }
  }

  const getBalanceLabel = (balance: "deficit" | "adequate" | "excess") => {
    switch (balance) {
      case "deficit":
        return "Deficit"
      case "adequate":
        return "Adequate"
      case "excess":
        return "Excess"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Electrolyte Balance Calculator</CardTitle>
                    <CardDescription>Estimate electrolyte needs and balance</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder={unitSystem === "metric" ? "70" : "154"}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="age">Age (years)</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="30"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="1"
                      max="120"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fluidIntake">Daily Fluid Intake ({unitSystem === "metric" ? "L" : "oz"})</Label>
                    <Input
                      id="fluidIntake"
                      type="number"
                      placeholder={unitSystem === "metric" ? "2.5" : "85"}
                      value={fluidIntake}
                      onChange={(e) => setFluidIntake(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="activityDuration">Activity Duration (min)</Label>
                    <Input
                      id="activityDuration"
                      type="number"
                      placeholder="60"
                      value={activityDuration}
                      onChange={(e) => setActivityDuration(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Activity Intensity</Label>
                  <Select
                    value={activityIntensity}
                    onValueChange={(value: "low" | "moderate" | "high") => setActivityIntensity(value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (walking, yoga)</SelectItem>
                      <SelectItem value="moderate">Moderate (jogging, cycling)</SelectItem>
                      <SelectItem value="high">High (running, HIIT)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <button
                  type="button"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="flex items-center gap-2 text-sm font-medium text-primary hover:underline"
                >
                  {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  {showAdvanced ? "Hide" : "Show"} Advanced Options
                </button>

                {showAdvanced && (
                  <div className="space-y-4 pt-2 border-t">
                    <p className="text-sm text-muted-foreground">
                      Enter your current intake to see balance status (optional)
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="sodiumIntake">Sodium Intake (mg/day)</Label>
                        <Input
                          id="sodiumIntake"
                          type="number"
                          placeholder="2300"
                          value={sodiumIntake}
                          onChange={(e) => setSodiumIntake(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="potassiumIntake">Potassium Intake (mg/day)</Label>
                        <Input
                          id="potassiumIntake"
                          type="number"
                          placeholder="3400"
                          value={potassiumIntake}
                          onChange={(e) => setPotassiumIntake(e.target.value)}
                          min="0"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="calciumIntake">Calcium Intake (mg/day)</Label>
                        <Input
                          id="calciumIntake"
                          type="number"
                          placeholder="1000"
                          value={calciumIntake}
                          onChange={(e) => setCalciumIntake(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="magnesiumIntake">Magnesium Intake (mg/day)</Label>
                        <Input
                          id="magnesiumIntake"
                          type="number"
                          placeholder="400"
                          value={magnesiumIntake}
                          onChange={(e) => setMagnesiumIntake(e.target.value)}
                          min="0"
                        />
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground pt-2">Environmental Conditions</p>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="temperature">Temperature ({tempUnit === "celsius" ? "°C" : "°F"})</Label>
                        <div className="flex gap-2">
                          <Input
                            id="temperature"
                            type="number"
                            placeholder={tempUnit === "celsius" ? "25" : "77"}
                            value={temperature}
                            onChange={(e) => setTemperature(e.target.value)}
                            className="flex-1"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => setTempUnit(tempUnit === "celsius" ? "fahrenheit" : "celsius")}
                          >
                            {tempUnit === "celsius" ? "°C" : "°F"}
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="humidity">Humidity (%)</Label>
                        <Input
                          id="humidity"
                          type="number"
                          placeholder="50"
                          value={humidity}
                          onChange={(e) => setHumidity(e.target.value)}
                          min="0"
                          max="100"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateElectrolyteBalance} className="w-full" size="lg">
                  Calculate Electrolyte Balance
                </Button>

                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.statusBg} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Electrolyte Status</p>
                      <p className={`text-2xl font-bold ${result.statusColor}`}>{result.overallStatus}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Recommended fluid: {result.fluidRecommendation}L/day
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mb-4">
                      <div className={`p-2 rounded-lg ${getBalanceColor(result.sodiumBalance)}`}>
                        <p className="text-xs font-medium">Sodium</p>
                        <p className="text-sm font-bold">{result.sodiumIntake}mg</p>
                        <p className="text-xs">{getBalanceLabel(result.sodiumBalance)}</p>
                      </div>
                      <div className={`p-2 rounded-lg ${getBalanceColor(result.potassiumBalance)}`}>
                        <p className="text-xs font-medium">Potassium</p>
                        <p className="text-sm font-bold">{result.potassiumIntake}mg</p>
                        <p className="text-xs">{getBalanceLabel(result.potassiumBalance)}</p>
                      </div>
                      <div className={`p-2 rounded-lg ${getBalanceColor(result.calciumBalance)}`}>
                        <p className="text-xs font-medium">Calcium</p>
                        <p className="text-sm font-bold">{result.calciumIntake}mg</p>
                        <p className="text-xs">{getBalanceLabel(result.calciumBalance)}</p>
                      </div>
                      <div className={`p-2 rounded-lg ${getBalanceColor(result.magnesiumBalance)}`}>
                        <p className="text-xs font-medium">Magnesium</p>
                        <p className="text-sm font-bold">{result.magnesiumIntake}mg</p>
                        <p className="text-xs">{getBalanceLabel(result.magnesiumBalance)}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="flex items-center justify-center gap-1 w-full text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showDetails ? "Hide" : "Show"} Activity Losses
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-border/50 space-y-2">
                        <p className="text-sm font-medium text-muted-foreground">Estimated Activity Losses:</p>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="flex justify-between">
                            <span>Sodium Loss:</span>
                            <span className="font-medium">{result.sodiumLoss}mg</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Potassium Loss:</span>
                            <span className="font-medium">{result.potassiumLoss}mg</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Calcium Loss:</span>
                            <span className="font-medium">{result.calciumLoss}mg</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Magnesium Loss:</span>
                            <span className="font-medium">{result.magnesiumLoss}mg</span>
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Daily Electrolyte Needs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Sodium</span>
                      <span className="text-sm text-blue-600">{"< 2,300mg"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Potassium</span>
                      <span className="text-sm text-green-600">2,600-3,400mg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Calcium</span>
                      <span className="text-sm text-yellow-600">1,000-1,200mg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Magnesium</span>
                      <span className="text-sm text-purple-600">320-420mg</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sweat Electrolyte Content</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-medium text-foreground mb-2">Per Liter of Sweat:</p>
                    <ul className="space-y-1">
                      <li>Sodium: 900-1,400mg</li>
                      <li>Potassium: 150-300mg</li>
                      <li>Calcium: 20-60mg</li>
                      <li>Magnesium: 10-40mg</li>
                    </ul>
                  </div>
                  <p>
                    Sweat rate varies from 0.5-2.0L/hour depending on intensity, temperature, humidity, and individual
                    factors.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What Are Electrolytes?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrolytes are minerals that carry an electric charge when dissolved in body fluids like blood,
                  urine, and sweat. They play crucial roles in maintaining fluid balance, nerve function, muscle
                  contractions, and pH balance. The primary electrolytes include sodium, potassium, calcium, magnesium,
                  chloride, phosphate, and bicarbonate.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  During physical activity, especially in hot or humid conditions, we lose electrolytes through sweat.
                  Sodium is the primary electrolyte lost in sweat, followed by potassium, calcium, and magnesium.
                  Replacing these losses is essential for maintaining performance, preventing cramps, and supporting
                  overall health.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Signs of Electrolyte Imbalance</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Deficiency Signs:</h4>
                    <ul className="text-muted-foreground space-y-1 text-sm">
                      <li>Muscle cramps or spasms</li>
                      <li>Fatigue and weakness</li>
                      <li>Headaches and dizziness</li>
                      <li>Irregular heartbeat</li>
                      <li>Nausea or vomiting</li>
                      <li>Confusion or difficulty concentrating</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Excess Signs:</h4>
                    <ul className="text-muted-foreground space-y-1 text-sm">
                      <li>High blood pressure (sodium excess)</li>
                      <li>Swelling or edema</li>
                      <li>Digestive issues</li>
                      <li>Kidney problems</li>
                      <li>Heart palpitations</li>
                      <li>Tingling sensations</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm">
                  Electrolyte balance calculations are estimates and may vary based on individual metabolism, diet, and
                  health conditions. Factors such as medications, kidney function, and underlying health conditions can
                  significantly affect electrolyte needs. This calculator is for informational purposes only and should
                  not replace professional medical advice. If you experience symptoms of electrolyte imbalance or have
                  concerns about your nutrition, please consult a healthcare professional or registered dietitian for
                  personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
