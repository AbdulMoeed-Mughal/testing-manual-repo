"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Beaker } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMode = "standard" | "nernst"

interface CellPotentialResult {
  standardPotential: number
  nernstPotential: number | null
  spontaneous: boolean
  cathodeContribution: number
  anodeContribution: number
}

export function ElectrochemicalCellPotentialCalculator() {
  const [mode, setMode] = useState<CalculationMode>("standard")
  const [cathodePotential, setCathodePotential] = useState("")
  const [anodePotential, setAnodePotential] = useState("")
  const [electrons, setElectrons] = useState("")
  const [reactionQuotient, setReactionQuotient] = useState("")
  const [temperature, setTemperature] = useState("298.15")
  const [result, setResult] = useState<CellPotentialResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const R = 8.314 // Gas constant J/(mol·K)
  const F = 96485 // Faraday constant C/mol

  const calculate = () => {
    setError("")
    setResult(null)

    const cathodeE = Number.parseFloat(cathodePotential)
    const anodeE = Number.parseFloat(anodePotential)

    if (isNaN(cathodeE)) {
      setError("Please enter a valid cathode reduction potential")
      return
    }

    if (isNaN(anodeE)) {
      setError("Please enter a valid anode reduction potential")
      return
    }

    // Standard cell potential: E°cell = E°cathode - E°anode
    const standardPotential = cathodeE - anodeE
    const roundedStandard = Math.round(standardPotential * 1000) / 1000

    let nernstPotential: number | null = null

    if (mode === "nernst") {
      const n = Number.parseFloat(electrons)
      const Q = Number.parseFloat(reactionQuotient)
      const T = Number.parseFloat(temperature)

      if (isNaN(n) || n <= 0) {
        setError("Please enter a valid positive number of electrons transferred")
        return
      }

      if (isNaN(Q) || Q <= 0) {
        setError("Please enter a valid positive reaction quotient (Q)")
        return
      }

      if (isNaN(T) || T <= 0) {
        setError("Please enter a valid positive temperature in Kelvin")
        return
      }

      // Nernst equation: E = E° - (RT/nF)ln(Q)
      nernstPotential = standardPotential - ((R * T) / (n * F)) * Math.log(Q)
      nernstPotential = Math.round(nernstPotential * 1000) / 1000
    }

    const finalPotential = nernstPotential !== null ? nernstPotential : roundedStandard

    setResult({
      standardPotential: roundedStandard,
      nernstPotential,
      spontaneous: finalPotential > 0,
      cathodeContribution: cathodeE,
      anodeContribution: anodeE,
    })
  }

  const handleReset = () => {
    setCathodePotential("")
    setAnodePotential("")
    setElectrons("")
    setReactionQuotient("")
    setTemperature("298.15")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const potential = result.nernstPotential !== null ? result.nernstPotential : result.standardPotential
      const type = result.nernstPotential !== null ? "Non-standard" : "Standard"
      await navigator.clipboard.writeText(
        `${type} Cell Potential: ${potential} V (${result.spontaneous ? "Spontaneous" : "Non-spontaneous"})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const potential = result.nernstPotential !== null ? result.nernstPotential : result.standardPotential
      try {
        await navigator.share({
          title: "Electrochemical Cell Potential Result",
          text: `Cell Potential: ${potential} V (${result.spontaneous ? "Spontaneous" : "Non-spontaneous"})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleMode = () => {
    setMode((prev) => (prev === "standard" ? "nernst" : "standard"))
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Cell Potential Calculator</CardTitle>
                    <CardDescription>Calculate electrochemical cell potential</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Conditions</span>
                  <button
                    onClick={toggleMode}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "nernst" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "standard" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Standard
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "nernst" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Nernst
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Cathode Potential Input */}
                <div className="space-y-2">
                  <Label htmlFor="cathode">Cathode E° (V)</Label>
                  <Input
                    id="cathode"
                    type="number"
                    placeholder="Enter cathode reduction potential"
                    value={cathodePotential}
                    onChange={(e) => setCathodePotential(e.target.value)}
                    step="0.001"
                  />
                </div>

                {/* Anode Potential Input */}
                <div className="space-y-2">
                  <Label htmlFor="anode">Anode E° (V)</Label>
                  <Input
                    id="anode"
                    type="number"
                    placeholder="Enter anode reduction potential"
                    value={anodePotential}
                    onChange={(e) => setAnodePotential(e.target.value)}
                    step="0.001"
                  />
                </div>

                {/* Nernst equation inputs */}
                {mode === "nernst" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="electrons">Electrons Transferred (n)</Label>
                      <Input
                        id="electrons"
                        type="number"
                        placeholder="Enter number of electrons"
                        value={electrons}
                        onChange={(e) => setElectrons(e.target.value)}
                        min="1"
                        step="1"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="quotient">Reaction Quotient (Q)</Label>
                      <Input
                        id="quotient"
                        type="number"
                        placeholder="Enter reaction quotient"
                        value={reactionQuotient}
                        onChange={(e) => setReactionQuotient(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="temperature">Temperature (K)</Label>
                      <Input
                        id="temperature"
                        type="number"
                        placeholder="Enter temperature in Kelvin"
                        value={temperature}
                        onChange={(e) => setTemperature(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Cell Potential
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.spontaneous ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                    }`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.nernstPotential !== null ? "Cell Potential (E)" : "Standard Cell Potential (E°)"}
                      </p>
                      <p
                        className={`text-5xl font-bold mb-2 ${
                          result.spontaneous ? "text-green-600" : "text-red-600"
                        }`}
                      >
                        {result.nernstPotential !== null ? result.nernstPotential : result.standardPotential}
                      </p>
                      <p className="text-lg text-muted-foreground mb-1">V</p>
                      <p
                        className={`text-lg font-semibold ${
                          result.spontaneous ? "text-green-600" : "text-red-600"
                        }`}
                      >
                        {result.spontaneous ? "Spontaneous Reaction" : "Non-spontaneous Reaction"}
                      </p>
                    </div>

                    {/* Additional Info */}
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">E° (Standard)</p>
                        <p className="font-semibold">{result.standardPotential} V</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Cathode E°</p>
                        <p className="font-semibold">{result.cathodeContribution} V</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Reduction Potentials</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Li+ + e- → Li</span>
                      <span className="font-mono">-3.04 V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Zn2+ + 2e- → Zn</span>
                      <span className="font-mono">-0.76 V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>2H+ + 2e- → H2</span>
                      <span className="font-mono">0.00 V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Cu2+ + 2e- → Cu</span>
                      <span className="font-mono">+0.34 V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Ag+ + e- → Ag</span>
                      <span className="font-mono">+0.80 V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Au3+ + 3e- → Au</span>
                      <span className="font-mono">+1.50 V</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">E°cell = E°cathode - E°anode</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">E = E° - (RT/nF)ln(Q)</p>
                  </div>
                  <p className="text-xs">
                    R = 8.314 J/(mol·K), F = 96,485 C/mol
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Content Cards */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Electrochemical Cell Potential?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrochemical cell potential, also known as electromotive force (EMF), is the measure of the driving
                  force behind an electrochemical reaction. It represents the potential difference between two electrodes
                  in an electrochemical cell and determines whether a redox reaction will occur spontaneously. The cell
                  potential is measured in volts (V) and is fundamental to understanding batteries, fuel cells, and
                  electrolysis processes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Standard cell potential (E°) is measured under standard conditions: 25°C (298.15 K), 1 M concentration
                  for all aqueous species, 1 atm pressure for gases, and pure solids and liquids. These standardized
                  conditions allow for consistent comparison of different electrochemical systems and prediction of
                  reaction spontaneity.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>The Nernst Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Nernst equation extends the concept of standard cell potential to non-standard conditions. Named
                  after German chemist Walther Nernst, this equation accounts for the effects of concentration,
                  temperature, and pressure on the cell potential. It allows scientists to calculate the actual cell
                  potential when conditions deviate from the standard state.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equation E = E° - (RT/nF)ln(Q) shows that cell potential depends on the reaction quotient Q, which
                  represents the ratio of product concentrations to reactant concentrations at any given moment. As a
                  reaction proceeds and Q changes, the cell potential adjusts accordingly until equilibrium is reached
                  (E = 0, Q = K).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Spontaneity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A positive cell potential indicates a spontaneous electrochemical reaction - one that will occur
                  naturally without external energy input. This corresponds to a galvanic (voltaic) cell that can produce
                  electrical energy from chemical reactions, like a battery. The higher the positive voltage, the greater
                  the thermodynamic driving force for the reaction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Conversely, a negative cell potential indicates a non-spontaneous reaction that requires external
                  electrical energy to proceed. This is the principle behind electrolytic cells, which use electrical
                  energy to drive chemical reactions that would not occur naturally, such as electroplating or the
                  production of metals from their ores.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While cell potential calculations are powerful tools, they have limitations. Standard reduction
                  potentials are measured under ideal conditions that may not reflect real-world scenarios. Factors such
                  as electrode kinetics, overpotential, solution resistance, and mass transport can significantly affect
                  actual cell performance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Additionally, the Nernst equation assumes ideal solution behavior and may not be accurate for highly
                  concentrated solutions where activity coefficients deviate significantly from unity. Temperature
                  effects on standard potentials are also not accounted for in simple calculations and may require more
                  sophisticated thermodynamic analysis for precise predictions.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Disclaimer:</strong> Calculations assume ideal conditions. Actual potentials may vary due to
                    concentration, temperature, or non-ideal solution behavior.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
