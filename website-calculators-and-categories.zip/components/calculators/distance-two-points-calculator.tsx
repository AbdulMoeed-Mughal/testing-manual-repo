"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Ruler, Info } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Dimension = "2d" | "3d"

interface DistanceResult {
  distance: number
  squaredDifferences: { x: number; y: number; z?: number }
  sumOfSquares: number
}

export function DistanceTwoPointsCalculator() {
  const [dimension, setDimension] = useState<Dimension>("2d")
  const [x1, setX1] = useState("")
  const [y1, setY1] = useState("")
  const [z1, setZ1] = useState("")
  const [x2, setX2] = useState("")
  const [y2, setY2] = useState("")
  const [z2, setZ2] = useState("")
  const [result, setResult] = useState<DistanceResult | null>(null)
  const [showSteps, setShowSteps] = useState(true)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDistance = () => {
    setError("")
    setResult(null)

    const x1Num = Number.parseFloat(x1)
    const y1Num = Number.parseFloat(y1)
    const x2Num = Number.parseFloat(x2)
    const y2Num = Number.parseFloat(y2)

    if (isNaN(x1Num) || isNaN(y1Num) || isNaN(x2Num) || isNaN(y2Num)) {
      setError("Please enter valid numeric values for all coordinates")
      return
    }

    let z1Num = 0
    let z2Num = 0

    if (dimension === "3d") {
      z1Num = Number.parseFloat(z1)
      z2Num = Number.parseFloat(z2)
      if (isNaN(z1Num) || isNaN(z2Num)) {
        setError("Please enter valid numeric values for z coordinates")
        return
      }
    }

    const dx = x2Num - x1Num
    const dy = y2Num - y1Num
    const dz = dimension === "3d" ? z2Num - z1Num : 0

    const dxSquared = dx * dx
    const dySquared = dy * dy
    const dzSquared = dz * dz

    const sumOfSquares = dimension === "3d" ? dxSquared + dySquared + dzSquared : dxSquared + dySquared

    const distance = Math.sqrt(sumOfSquares)

    setResult({
      distance,
      squaredDifferences: {
        x: dxSquared,
        y: dySquared,
        ...(dimension === "3d" && { z: dzSquared }),
      },
      sumOfSquares,
    })
  }

  const handleReset = () => {
    setX1("")
    setY1("")
    setZ1("")
    setX2("")
    setY2("")
    setZ2("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Distance between points: ${result.distance.toFixed(6)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Distance Calculation Result",
          text: `I calculated the distance between two points using CalcHub! Distance: ${result.distance.toFixed(6)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Number.isInteger(num)) return num.toString()
    return num.toFixed(6).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Ruler className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Distance Calculator</CardTitle>
                    <CardDescription>Calculate distance between two points</CardDescription>
                  </div>
                </div>

                {/* Dimension Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Dimension</span>
                  <button
                    onClick={() => {
                      setDimension(dimension === "2d" ? "3d" : "2d")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        dimension === "3d" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        dimension === "2d" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      2D
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        dimension === "3d" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      3D
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Point 1 */}
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">Point 1 (x₁, y₁{dimension === "3d" ? ", z₁" : ""})</Label>
                  <div className={`grid gap-2 ${dimension === "3d" ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Input
                        type="number"
                        placeholder="x₁"
                        value={x1}
                        onChange={(e) => setX1(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="y₁"
                        value={y1}
                        onChange={(e) => setY1(e.target.value)}
                        step="any"
                      />
                    </div>
                    {dimension === "3d" && (
                      <div>
                        <Input
                          type="number"
                          placeholder="z₁"
                          value={z1}
                          onChange={(e) => setZ1(e.target.value)}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Point 2 */}
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">Point 2 (x₂, y₂{dimension === "3d" ? ", z₂" : ""})</Label>
                  <div className={`grid gap-2 ${dimension === "3d" ? "grid-cols-3" : "grid-cols-2"}`}>
                    <div>
                      <Input
                        type="number"
                        placeholder="x₂"
                        value={x2}
                        onChange={(e) => setX2(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="y₂"
                        value={y2}
                        onChange={(e) => setY2(e.target.value)}
                        step="any"
                      />
                    </div>
                    {dimension === "3d" && (
                      <div>
                        <Input
                          type="number"
                          placeholder="z₂"
                          value={z2}
                          onChange={(e) => setZ2(e.target.value)}
                          step="any"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps" className="text-sm">
                    Show step-by-step solution
                  </Label>
                  <button
                    id="show-steps"
                    onClick={() => setShowSteps(!showSteps)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      showSteps ? "bg-primary" : "bg-muted"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform ${
                        showSteps ? "translate-x-6" : "translate-x-1"
                      }`}
                    />
                  </button>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDistance} className="w-full" size="lg">
                  Calculate Distance
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Distance</p>
                      <p className="text-4xl font-bold text-blue-600 mb-2 font-mono">{formatNumber(result.distance)}</p>
                      {result.distance === 0 && (
                        <p className="text-sm text-muted-foreground">The two points are identical</p>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-step Solution */}
                {result && showSteps && (
                  <Card className="bg-muted/50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-semibold">Step-by-Step Solution</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3 text-sm">
                      <div className="space-y-2">
                        <p className="font-medium">1. Identify the coordinates:</p>
                        <div className="pl-4 font-mono text-muted-foreground">
                          <p>
                            Point 1: ({x1}, {y1}
                            {dimension === "3d" ? `, ${z1}` : ""})
                          </p>
                          <p>
                            Point 2: ({x2}, {y2}
                            {dimension === "3d" ? `, ${z2}` : ""})
                          </p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="font-medium">2. Apply the distance formula:</p>
                        <div className="pl-4 font-mono text-muted-foreground">
                          {dimension === "2d" ? (
                            <p>d = √[(x₂ − x₁)² + (y₂ − y₁)²]</p>
                          ) : (
                            <p>d = √[(x₂ − x₁)² + (y₂ − y₁)² + (z₂ − z₁)²]</p>
                          )}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="font-medium">3. Calculate the differences:</p>
                        <div className="pl-4 font-mono text-muted-foreground">
                          <p>
                            x₂ − x₁ = {x2} − {x1} = {formatNumber(Number.parseFloat(x2) - Number.parseFloat(x1))}
                          </p>
                          <p>
                            y₂ − y₁ = {y2} − {y1} = {formatNumber(Number.parseFloat(y2) - Number.parseFloat(y1))}
                          </p>
                          {dimension === "3d" && (
                            <p>
                              z₂ − z₁ = {z2} − {z1} = {formatNumber(Number.parseFloat(z2) - Number.parseFloat(z1))}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="font-medium">4. Square the differences:</p>
                        <div className="pl-4 font-mono text-muted-foreground">
                          <p>(x₂ − x₁)² = {formatNumber(result.squaredDifferences.x)}</p>
                          <p>(y₂ − y₁)² = {formatNumber(result.squaredDifferences.y)}</p>
                          {dimension === "3d" && result.squaredDifferences.z !== undefined && (
                            <p>(z₂ − z₁)² = {formatNumber(result.squaredDifferences.z)}</p>
                          )}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="font-medium">5. Sum the squared differences:</p>
                        <div className="pl-4 font-mono text-muted-foreground">
                          <p>Sum = {formatNumber(result.sumOfSquares)}</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="font-medium">6. Take the square root:</p>
                        <div className="pl-4 font-mono text-muted-foreground">
                          <p>
                            d = √{formatNumber(result.sumOfSquares)} ={" "}
                            <span className="text-blue-600 font-semibold">{formatNumber(result.distance)}</span>
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Distance Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-medium text-blue-700 mb-1">2D Distance</p>
                    <p className="font-mono text-sm text-blue-600">d = √[(x₂−x₁)² + (y₂−y₁)²]</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-medium text-purple-700 mb-1">3D Distance</p>
                    <p className="font-mono text-sm text-purple-600">d = √[(x₂−x₁)² + (y₂−y₁)² + (z₂−z₁)²]</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between items-center p-2 bg-muted rounded">
                      <span className="font-mono">(0,0) to (3,4)</span>
                      <span className="font-semibold">5</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded">
                      <span className="font-mono">(1,1) to (4,5)</span>
                      <span className="font-semibold">5</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded">
                      <span className="font-mono">(0,0,0) to (1,1,1)</span>
                      <span className="font-semibold">√3 ≈ 1.732</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded">
                      <span className="font-mono">(2,3,4) to (5,7,8)</span>
                      <span className="font-semibold">√41 ≈ 6.403</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Applications</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Navigation:</strong> Finding distances between GPS coordinates
                  </p>
                  <p>
                    <strong>Graphics:</strong> Calculating pixel distances in images
                  </p>
                  <p>
                    <strong>Physics:</strong> Measuring displacement between objects
                  </p>
                  <p>
                    <strong>Engineering:</strong> CAD/CAM measurements and tolerances
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Distance Formula?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The distance formula is derived from the Pythagorean theorem and calculates the straight-line distance
                  (Euclidean distance) between two points in a coordinate system. In two dimensions, given points (x₁,
                  y₁) and (x₂, y₂), the distance d is calculated as d = √[(x₂−x₁)² + (y₂−y₁)²]. This formula essentially
                  forms a right triangle where the horizontal and vertical distances are the legs, and the distance
                  between points is the hypotenuse.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For three-dimensional space, the formula extends naturally to include the z-coordinate: d = √[(x₂−x₁)²
                  + (y₂−y₁)² + (z₂−z₁)²]. This is crucial for applications in 3D graphics, physics simulations,
                  robotics, and spatial analysis where objects exist in three-dimensional space.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Euclidean Distance</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Euclidean distance is the most common way to measure the "ordinary" straight-line distance between two
                  points. Named after the ancient Greek mathematician Euclid, this metric is fundamental to geometry,
                  physics, and many computational applications. It represents the shortest path between two points in
                  Euclidean space.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  While other distance metrics exist (such as Manhattan distance or Chebyshev distance), Euclidean
                  distance is preferred when you need the actual "as the crow flies" distance. It's used extensively in
                  machine learning for clustering algorithms, in computer graphics for collision detection, and in
                  navigation systems for route calculation.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Distance calculations follow standard Euclidean formulas. Results depend on correct coordinate
                      input and selected dimension. For geographic distances on Earth's surface, consider using the
                      Haversine formula which accounts for Earth's curvature.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
