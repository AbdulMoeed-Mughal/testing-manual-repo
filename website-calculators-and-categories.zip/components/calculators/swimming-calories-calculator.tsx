"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Waves, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface SwimmingResult {
  calories: number
  caloriesPerMinute: number
  met: number
  style: string
  intensity: string
  caloriesPerDistance?: number
}

const swimmingStyles = [
  { id: "freestyle", name: "Freestyle (Front Crawl)", metLow: 5.8, metModerate: 8.3, metHigh: 9.8 },
  { id: "backstroke", name: "Backstroke", metLow: 4.8, metModerate: 6.0, metHigh: 7.0 },
  { id: "breaststroke", name: "Breaststroke", metLow: 5.3, metModerate: 7.0, metHigh: 10.3 },
  { id: "butterfly", name: "Butterfly", metLow: 8.0, metModerate: 11.0, metHigh: 13.8 },
  { id: "sidestroke", name: "Sidestroke", metLow: 4.5, metModerate: 6.0, metHigh: 7.0 },
  { id: "treading", name: "Treading Water", metLow: 3.5, metModerate: 5.0, metHigh: 9.8 },
  { id: "leisurely", name: "Leisurely/Recreational", metLow: 3.5, metModerate: 5.0, metHigh: 6.0 },
]

const intensityLevels = [
  { id: "low", name: "Low (Easy pace, can hold conversation)", label: "Low" },
  { id: "moderate", name: "Moderate (Steady pace, slightly breathless)", label: "Moderate" },
  { id: "high", name: "High (Vigorous pace, very breathless)", label: "High" },
]

export function SwimmingCaloriesCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [duration, setDuration] = useState("")
  const [style, setStyle] = useState("freestyle")
  const [intensity, setIntensity] = useState("moderate")
  const [distance, setDistance] = useState("")
  const [gender, setGender] = useState<"male" | "female" | "">("")
  const [result, setResult] = useState<SwimmingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateCalories = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    const durationNum = Number.parseFloat(duration)
    if (isNaN(durationNum) || durationNum <= 0) {
      setError("Please enter a valid duration greater than 0")
      return
    }

    // Convert weight to kg if imperial
    const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Get selected swimming style
    const selectedStyle = swimmingStyles.find((s) => s.id === style)
    if (!selectedStyle) {
      setError("Please select a swimming style")
      return
    }

    // Get MET value based on intensity
    let met: number
    switch (intensity) {
      case "low":
        met = selectedStyle.metLow
        break
      case "high":
        met = selectedStyle.metHigh
        break
      default:
        met = selectedStyle.metModerate
    }

    // Adjust MET slightly for gender (women typically burn ~10% fewer calories)
    if (gender === "female") {
      met *= 0.9
    }

    // Calculate calories: (MET × 3.5 × Weight in kg) ÷ 200 × duration
    const caloriesPerMinute = (met * 3.5 * weightKg) / 200
    const totalCalories = caloriesPerMinute * durationNum

    // Calculate calories per distance if distance is provided
    let caloriesPerDistance: number | undefined
    const distanceNum = Number.parseFloat(distance)
    if (!isNaN(distanceNum) && distanceNum > 0) {
      // Convert to meters if yards
      const distanceMeters = unitSystem === "imperial" ? distanceNum * 0.9144 : distanceNum
      caloriesPerDistance = totalCalories / distanceMeters
    }

    const selectedIntensity = intensityLevels.find((i) => i.id === intensity)

    setResult({
      calories: Math.round(totalCalories),
      caloriesPerMinute: Math.round(caloriesPerMinute * 10) / 10,
      met: Math.round(met * 10) / 10,
      style: selectedStyle.name,
      intensity: selectedIntensity?.label || "Moderate",
      caloriesPerDistance: caloriesPerDistance ? Math.round(caloriesPerDistance * 100) / 100 : undefined,
    })
  }

  const handleReset = () => {
    setWeight("")
    setDuration("")
    setStyle("freestyle")
    setIntensity("moderate")
    setDistance("")
    setGender("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Swimming Session: ${result.calories} calories burned (${result.style}, ${result.intensity} intensity, ${duration} minutes)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Swimming Calories Result",
          text: `I burned ${result.calories} calories swimming! (${result.style}, ${result.intensity} intensity, ${duration} minutes)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setDistance("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Waves className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Swimming Calories Calculator</CardTitle>
                    <CardDescription>Estimate calories burned while swimming</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Duration Input */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Enter swimming duration"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Swimming Style */}
                <div className="space-y-2">
                  <Label>Swimming Style</Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select swimming style" />
                    </SelectTrigger>
                    <SelectContent>
                      {swimmingStyles.map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Intensity Level */}
                <div className="space-y-2">
                  <Label>Intensity Level</Label>
                  <Select value={intensity} onValueChange={setIntensity}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select intensity" />
                    </SelectTrigger>
                    <SelectContent>
                      {intensityLevels.map((i) => (
                        <SelectItem key={i.id} value={i.id}>
                          {i.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Optional Distance */}
                <div className="space-y-2">
                  <Label htmlFor="distance">
                    Distance ({unitSystem === "metric" ? "meters" : "yards"}){" "}
                    <span className="text-muted-foreground text-xs">(optional)</span>
                  </Label>
                  <Input
                    id="distance"
                    type="number"
                    placeholder={`Enter distance in ${unitSystem === "metric" ? "meters" : "yards"}`}
                    value={distance}
                    onChange={(e) => setDistance(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Optional Gender */}
                <div className="space-y-2">
                  <Label>
                    Gender <span className="text-muted-foreground text-xs">(optional, for accuracy)</span>
                  </Label>
                  <Select value={gender} onValueChange={(v) => setGender(v as "male" | "female" | "")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCalories} className="w-full" size="lg">
                  Calculate Calories Burned
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Calories Burned</p>
                      <p className="text-5xl font-bold text-cyan-600 mb-2">{result.calories}</p>
                      <p className="text-lg font-semibold text-cyan-600">calories</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        {result.style} • {result.intensity} intensity
                      </p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-1 mt-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-cyan-200 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Calories per minute:</span>
                          <span className="font-medium">{result.caloriesPerMinute} cal/min</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">MET value used:</span>
                          <span className="font-medium">{result.met}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Duration:</span>
                          <span className="font-medium">{duration} minutes</span>
                        </div>
                        {result.caloriesPerDistance && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">
                              Calories per {unitSystem === "metric" ? "meter" : "yard"}:
                            </span>
                            <span className="font-medium">{result.caloriesPerDistance} cal</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">MET Values by Stroke</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    {swimmingStyles.slice(0, 5).map((s) => (
                      <div key={s.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <span className="font-medium">{s.name}</span>
                        <span className="text-muted-foreground">
                          {s.metLow} - {s.metHigh} MET
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calorie Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      Calories/min = (MET × 3.5 × Weight in kg) ÷ 200
                    </p>
                  </div>
                  <p>Total calories = Calories per minute × Duration in minutes</p>
                  <p>
                    MET (Metabolic Equivalent of Task) represents the energy cost of physical activities as a multiple
                    of resting metabolic rate.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Swimming Calories</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Swimming is one of the most effective full-body workouts, engaging nearly every major muscle group
                  while being gentle on the joints. The number of calories burned during swimming depends on several
                  factors including your body weight, the swimming stroke used, the intensity of your workout, and the
                  duration of your session. Unlike many land-based exercises, swimming provides both cardiovascular and
                  resistance training benefits simultaneously.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Different swimming strokes burn calories at different rates. The butterfly stroke is the most
                  demanding, burning the most calories per minute, followed by freestyle (front crawl). Breaststroke and
                  backstroke are generally less intense but still provide excellent cardiovascular benefits. The
                  intensity at which you swim also plays a crucial role, with vigorous swimming burning significantly
                  more calories than leisurely laps.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Waves className="h-5 w-5 text-primary" />
                  <CardTitle>Swimming Stroke Comparison</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Freestyle (Front Crawl)</h4>
                    <p className="text-cyan-700 text-sm">
                      The fastest and most popular stroke. Burns 400-700 calories per hour depending on intensity. Great
                      for building overall endurance and upper body strength.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Backstroke</h4>
                    <p className="text-blue-700 text-sm">
                      Excellent for posture and back muscles. Burns 350-500 calories per hour. Good option for those
                      with neck issues since face stays above water.
                    </p>
                  </div>
                  <div className="p-4 bg-teal-50 border border-teal-200 rounded-lg">
                    <h4 className="font-semibold text-teal-800 mb-2">Breaststroke</h4>
                    <p className="text-teal-700 text-sm">
                      Works inner thighs and chest muscles. Burns 400-700 calories per hour. Great for beginners and
                      easier to maintain breathing rhythm.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Butterfly</h4>
                    <p className="text-purple-700 text-sm">
                      Most demanding stroke. Burns 600-900 calories per hour. Provides intense full-body workout
                      targeting core, shoulders, and chest.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tips to Maximize Calorie Burn</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Mix up your strokes:</strong> Alternating between different strokes challenges different
                    muscle groups and prevents adaptation.
                  </li>
                  <li>
                    <strong>Add interval training:</strong> Alternate between high-intensity sprints and recovery laps
                    to boost metabolism.
                  </li>
                  <li>
                    <strong>Use equipment:</strong> Kickboards, pull buoys, and paddles can increase resistance and
                    calorie expenditure.
                  </li>
                  <li>
                    <strong>Maintain proper form:</strong> Efficient technique allows you to swim faster and longer,
                    burning more calories overall.
                  </li>
                  <li>
                    <strong>Swim consistently:</strong> Regular swimming sessions (3-5 times per week) maximize fitness
                    gains and calorie burn.
                  </li>
                  <li>
                    <strong>Track your progress:</strong> Monitor distance, time, and calories to stay motivated and
                    improve over time.
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Calories burned are estimates based on MET values and may vary depending
                  on individual metabolism, swimming technique, water temperature, and environmental conditions. These
                  calculations provide general guidance and should not replace professional fitness advice.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
