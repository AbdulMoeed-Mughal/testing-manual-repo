"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Wine,
  Info,
  AlertTriangle,
  Clock,
  Car,
  ShieldAlert,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"

interface BACResult {
  bac: number
  timeUntilSober: number
  status: string
  color: string
  bgColor: string
  canDrive: boolean
}

export function AlcoholCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [weight, setWeight] = useState("")
  const [drinks, setDrinks] = useState("")
  const [drinkSize, setDrinkSize] = useState("")
  const [abv, setAbv] = useState("")
  const [hours, setHours] = useState("")
  const [result, setResult] = useState<BACResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBAC = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const drinksNum = Number.parseFloat(drinks)
    const drinkSizeNum = Number.parseFloat(drinkSize)
    const abvNum = Number.parseFloat(abv)
    const hoursNum = Number.parseFloat(hours)

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }
    if (isNaN(drinksNum) || drinksNum < 0) {
      setError("Please enter a valid number of drinks (0 or more)")
      return
    }
    if (isNaN(drinkSizeNum) || drinkSizeNum <= 0) {
      setError("Please enter a valid drink size greater than 0")
      return
    }
    if (isNaN(abvNum) || abvNum < 0 || abvNum > 100) {
      setError("Please enter a valid ABV between 0 and 100%")
      return
    }
    if (isNaN(hoursNum) || hoursNum < 0) {
      setError("Please enter a valid time (0 or more hours)")
      return
    }

    // Convert weight to grams
    let weightInGrams: number
    if (unitSystem === "metric") {
      weightInGrams = weightNum * 1000
    } else {
      weightInGrams = weightNum * 453.592
    }

    // Convert drink size to ml
    let drinkSizeMl: number
    if (unitSystem === "metric") {
      drinkSizeMl = drinkSizeNum
    } else {
      drinkSizeMl = drinkSizeNum * 29.5735 // oz to ml
    }

    // Calculate alcohol in grams
    const totalVolumeMl = drinksNum * drinkSizeMl
    const alcoholGrams = totalVolumeMl * (abvNum / 100) * 0.789 // 0.789 is density of ethanol

    // Gender-specific alcohol distribution ratio (Widmark factor)
    const r = gender === "male" ? 0.68 : 0.55

    // Metabolism rate (BAC reduction per hour)
    const metabolismRate = 0.015

    // Calculate BAC using Widmark formula
    let bac = (alcoholGrams / (weightInGrams * r)) * 100 - metabolismRate * hoursNum
    bac = Math.max(0, bac) // BAC can't be negative
    bac = Math.round(bac * 1000) / 1000 // Round to 3 decimal places

    // Calculate time until sober
    const timeUntilSober = bac > 0 ? Math.ceil((bac / metabolismRate) * 10) / 10 : 0

    // Determine status and colors
    let status: string
    let color: string
    let bgColor: string
    let canDrive: boolean

    if (bac === 0) {
      status = "Sober"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      canDrive = true
    } else if (bac < 0.02) {
      status = "Minimal Impairment"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      canDrive = true
    } else if (bac < 0.05) {
      status = "Mild Impairment"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
      canDrive = true
    } else if (bac < 0.08) {
      status = "Moderate Impairment"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
      canDrive = false
    } else if (bac < 0.15) {
      status = "Significant Impairment"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
      canDrive = false
    } else if (bac < 0.3) {
      status = "Severe Impairment"
      color = "text-red-700"
      bgColor = "bg-red-100 border-red-300"
      canDrive = false
    } else if (bac < 0.4) {
      status = "Life-Threatening"
      color = "text-red-800"
      bgColor = "bg-red-200 border-red-400"
      canDrive = false
    } else {
      status = "Potentially Fatal"
      color = "text-red-900"
      bgColor = "bg-red-300 border-red-500"
      canDrive = false
    }

    setResult({ bac, timeUntilSober, status, color, bgColor, canDrive })
  }

  const handleReset = () => {
    setWeight("")
    setDrinks("")
    setDrinkSize("")
    setAbv("")
    setHours("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My estimated BAC is ${result.bac.toFixed(3)}% (${result.status}). Time until sober: ~${result.timeUntilSober} hours.`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My BAC Estimate",
          text: `I calculated my BAC using CalcHub! Estimated BAC: ${result.bac.toFixed(3)}% (${result.status})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setDrinkSize("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Wine className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Alcohol Calculator</CardTitle>
                    <CardDescription>Estimate your blood alcohol concentration</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Drinks Input */}
                <div className="space-y-2">
                  <Label htmlFor="drinks">Number of Drinks</Label>
                  <Input
                    id="drinks"
                    type="number"
                    placeholder="Enter number of drinks"
                    value={drinks}
                    onChange={(e) => setDrinks(e.target.value)}
                    min="0"
                    step="0.5"
                  />
                </div>

                {/* Drink Size Input */}
                <div className="space-y-2">
                  <Label htmlFor="drinkSize">Drink Size ({unitSystem === "metric" ? "ml" : "oz"})</Label>
                  <Input
                    id="drinkSize"
                    type="number"
                    placeholder={`Enter drink size in ${unitSystem === "metric" ? "milliliters" : "ounces"}`}
                    value={drinkSize}
                    onChange={(e) => setDrinkSize(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* ABV Input */}
                <div className="space-y-2">
                  <Label htmlFor="abv">Alcohol by Volume (ABV %)</Label>
                  <Input
                    id="abv"
                    type="number"
                    placeholder="Enter ABV percentage (e.g., 5 for beer, 12 for wine)"
                    value={abv}
                    onChange={(e) => setAbv(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Time Period Input */}
                <div className="space-y-2">
                  <Label htmlFor="hours">Time Period (hours)</Label>
                  <Input
                    id="hours"
                    type="number"
                    placeholder="Hours since first drink"
                    value={hours}
                    onChange={(e) => setHours(e.target.value)}
                    min="0"
                    step="0.5"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBAC} className="w-full" size="lg">
                  Calculate BAC
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated BAC</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.bac.toFixed(3)}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.status}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white/50 rounded-lg text-center">
                        <Clock className="h-4 w-4 mx-auto mb-1 text-muted-foreground" />
                        <p className="text-xs text-muted-foreground">Time Until Sober</p>
                        <p className="text-lg font-bold">{result.timeUntilSober}h</p>
                      </div>
                      <div className="p-3 bg-white/50 rounded-lg text-center">
                        <Car className="h-4 w-4 mx-auto mb-1 text-muted-foreground" />
                        <p className="text-xs text-muted-foreground">Legal to Drive</p>
                        <p className={`text-lg font-bold ${result.canDrive ? "text-green-600" : "text-red-600"}`}>
                          {result.canDrive ? "Yes" : "No"}
                        </p>
                      </div>
                    </div>

                    {/* Warning for high BAC */}
                    {result.bac >= 0.4 && (
                      <div className="mt-4 p-3 bg-red-100 border border-red-300 rounded-lg flex items-start gap-2">
                        <ShieldAlert className="h-5 w-5 text-red-700 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-red-800 font-medium">
                          Warning: A BAC of 0.40% or higher is potentially fatal. Seek medical attention immediately.
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BAC Levels & Effects</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Sober / Minimal</span>
                      <span className="text-sm text-green-600">0.00 - 0.02%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Mild Impairment</span>
                      <span className="text-sm text-yellow-600">0.02 - 0.05%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Moderate Impairment</span>
                      <span className="text-sm text-orange-600">0.05 - 0.08%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Significant Impairment</span>
                      <span className="text-sm text-red-600">0.08 - 0.15%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-100 border border-red-300">
                      <span className="font-medium text-red-800">Severe / Dangerous</span>
                      <span className="text-sm text-red-700">0.15%+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Drink ABV</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Light Beer</span>
                    <span className="font-medium">3-4%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Regular Beer</span>
                    <span className="font-medium">4-6%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Wine</span>
                    <span className="font-medium">11-14%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Spirits/Liquor</span>
                    <span className="font-medium">35-50%</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-600" />
                    <CardTitle className="text-lg text-amber-800">Important Disclaimer</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-amber-700">
                    This calculator provides estimates only and should not be used for legal or medical decisions. BAC
                    can vary based on many factors not accounted for here. Never drink and drive. Always drink
                    responsibly.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Blood Alcohol Concentration (BAC)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Blood Alcohol Concentration, commonly abbreviated as BAC, is a measurement of the amount of alcohol
                  present in your bloodstream. It is expressed as a percentage, representing the grams of alcohol per
                  100 milliliters of blood. For example, a BAC of 0.08% means there are 0.08 grams of alcohol per 100
                  milliliters of blood in your system. This measurement is the standard used worldwide by law
                  enforcement, medical professionals, and researchers to quantify alcohol intoxication levels.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  BAC is influenced by numerous factors including body weight, gender, the amount and type of alcohol
                  consumed, the rate of consumption, food intake, and individual metabolism. Understanding your BAC is
                  crucial for making informed decisions about drinking, particularly regarding driving and other
                  activities that require alertness and coordination. In most countries, the legal limit for driving is
                  0.08%, though some regions have stricter limits of 0.05% or even zero tolerance policies.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Wine className="h-5 w-5 text-primary" />
                  <CardTitle>The Widmark Formula Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator uses the Widmark formula, developed by Swedish professor Erik Widmark in the 1930s.
                  The formula calculates BAC by considering the amount of alcohol consumed, body weight, gender-specific
                  distribution ratios, and the time elapsed since drinking. The core formula is: BAC = (Alcohol in grams
                  ÷ (Body weight in grams × r)) × 100 - (Metabolism rate × hours), where 'r' is the Widmark factor
                  representing the proportion of body mass in which alcohol distributes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Widmark factor differs between males (0.68) and females (0.55) due to differences in body
                  composition. Women typically have a higher percentage of body fat and less water content than men,
                  which means alcohol becomes more concentrated in their bloodstream. The metabolism rate of
                  approximately 0.015% per hour represents how quickly the average liver processes alcohol, though this
                  can vary significantly between individuals based on genetics, liver health, and drinking habits.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Effects of Different BAC Levels</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The effects of alcohol on the body vary significantly based on BAC level. At low levels (0.02-0.05%),
                  you may experience mild relaxation, slight mood elevation, and minor impairment of judgment. As BAC
                  increases to 0.05-0.08%, effects become more pronounced including reduced coordination, impaired
                  reasoning, lowered inhibitions, and delayed reaction times. This is the range where driving becomes
                  increasingly dangerous, which is why most jurisdictions set their legal limits within this range.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Higher BAC levels bring more severe impairment. At 0.08-0.15%, you may experience significant loss of
                  balance, slurred speech, blurred vision, and substantial impairment of motor control and judgment. BAC
                  levels of 0.15-0.30% can cause severe motor impairment, vomiting, blackouts, and loss of
                  consciousness. Extremely high levels above 0.30% pose serious risk of alcohol poisoning, respiratory
                  depression, coma, and death. If you or someone you know shows signs of severe intoxication, seek
                  medical help immediately.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Alcohol Metabolism</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the Widmark formula provides a useful estimate, many factors can influence how your body
                  actually processes alcohol. Body composition plays a major role - muscle tissue contains more water
                  than fat tissue, so individuals with higher muscle mass may have slightly lower BAC for the same
                  amount of alcohol consumed. Age also matters, as older adults typically process alcohol more slowly
                  due to decreased liver function and changes in body composition.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Food consumption significantly affects alcohol absorption. Eating before or while drinking slows the
                  rate at which alcohol enters your bloodstream, potentially reducing peak BAC. Medications can interact
                  with alcohol and affect its metabolism - some drugs can dangerously amplify alcohol's effects. Genetic
                  factors also play a role, as some people have genetic variations that affect their liver enzymes
                  responsible for breaking down alcohol. Regular heavy drinking can actually increase metabolism rate
                  temporarily, though this comes with serious health risks.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ShieldAlert className="h-5 w-5 text-primary" />
                  <CardTitle>Responsible Drinking Guidelines</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Responsible drinking involves being aware of how much you consume and understanding your limits.
                  Health organizations generally recommend limiting alcohol intake to moderate levels - typically
                  defined as up to one drink per day for women and up to two drinks per day for men. A "standard drink"
                  contains roughly 14 grams of pure alcohol, equivalent to 12 ounces of beer (5% ABV), 5 ounces of wine
                  (12% ABV), or 1.5 ounces of distilled spirits (40% ABV).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  If you choose to drink, consider these safety tips: never drink and drive or operate machinery, pace
                  yourself by having no more than one drink per hour, alternate alcoholic drinks with water, eat food
                  before and while drinking, set a limit before you start and stick to it, and always have a safe way to
                  get home planned in advance. Remember that this calculator provides estimates only - when in doubt,
                  err on the side of caution. The only way to be completely certain you're safe to drive is to not drink
                  at all before driving.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
