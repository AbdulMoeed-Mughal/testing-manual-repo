"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, Plus, Minus } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

type OperationType = "add" | "subtract"
type UnitType = "days" | "weeks" | "months" | "years"

interface DateResult {
  date: Date
  dayOfWeek: string
  formattedDate: string
}

export function AddSubtractDateCalculator() {
  const [baseDate, setBaseDate] = useState("")
  const [duration, setDuration] = useState("")
  const [operation, setOperation] = useState<OperationType>("add")
  const [unitType, setUnitType] = useState<UnitType>("days")
  const [excludeWeekends, setExcludeWeekends] = useState(false)
  const [result, setResult] = useState<DateResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

  const calculateDate = () => {
    setError("")
    setResult(null)

    if (!baseDate) {
      setError("Please select a base date")
      return
    }

    const durationNum = Number.parseInt(duration)
    if (isNaN(durationNum) || durationNum < 0) {
      setError("Please enter a valid duration (non-negative)")
      return
    }

    const base = new Date(baseDate)
    if (isNaN(base.getTime())) {
      setError("Invalid base date")
      return
    }

    let resultDate = new Date(base)
    const multiplier = operation === "add" ? 1 : -1

    // Convert duration to days
    let daysToAdd = durationNum * multiplier
    if (unitType === "weeks") {
      daysToAdd *= 7
    } else if (unitType === "months") {
      resultDate.setMonth(resultDate.getMonth() + durationNum * multiplier)
      daysToAdd = 0 // Already handled
    } else if (unitType === "years") {
      resultDate.setFullYear(resultDate.getFullYear() + durationNum * multiplier)
      daysToAdd = 0 // Already handled
    }

    if (daysToAdd !== 0) {
      if (excludeWeekends) {
        // Add/subtract days while skipping weekends
        let daysAdded = 0
        const direction = daysToAdd > 0 ? 1 : -1
        const totalDays = Math.abs(daysToAdd)

        while (daysAdded < totalDays) {
          resultDate.setDate(resultDate.getDate() + direction)
          const dayOfWeek = resultDate.getDay()
          // Skip Saturday (6) and Sunday (0)
          if (dayOfWeek !== 0 && dayOfWeek !== 6) {
            daysAdded++
          }
        }
      } else {
        resultDate.setDate(resultDate.getDate() + daysToAdd)
      }
    }

    // Check if result is out of reasonable range (1900-2100)
    const year = resultDate.getFullYear()
    if (year < 1900 || year > 2100) {
      setError("Result date is out of valid range (1900-2100)")
      return
    }

    const dayOfWeek = dayNames[resultDate.getDay()]
    const formattedDate = resultDate.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    setResult({
      date: resultDate,
      dayOfWeek,
      formattedDate,
    })
  }

  const handleReset = () => {
    setBaseDate("")
    setDuration("")
    setOperation("add")
    setUnitType("days")
    setExcludeWeekends(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Date: ${result.formattedDate}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Date Calculation",
          text: `Calculated date: ${result.formattedDate}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Add/Subtract Date Calculator</CardTitle>
                    <CardDescription>Calculate dates by adding or subtracting time</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Base Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="baseDate">Base Date</Label>
                  <Input
                    id="baseDate"
                    type="date"
                    value={baseDate}
                    onChange={(e) => setBaseDate(e.target.value)}
                  />
                </div>

                {/* Operation Toggle */}
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setOperation("add")}
                      className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-lg border-2 transition-colors ${
                        operation === "add"
                          ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                          : "border-gray-200 bg-white text-gray-600 hover:border-cyan-300"
                      }`}
                    >
                      <Plus className="h-4 w-4" />
                      <span className="font-medium">Add</span>
                    </button>
                    <button
                      onClick={() => setOperation("subtract")}
                      className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-lg border-2 transition-colors ${
                        operation === "subtract"
                          ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                          : "border-gray-200 bg-white text-gray-600 hover:border-cyan-300"
                      }`}
                    >
                      <Minus className="h-4 w-4" />
                      <span className="font-medium">Subtract</span>
                    </button>
                  </div>
                </div>

                {/* Duration Input */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      id="duration"
                      type="number"
                      placeholder="Enter number"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      min="0"
                    />
                    <select
                      value={unitType}
                      onChange={(e) => setUnitType(e.target.value as UnitType)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <option value="days">Days</option>
                      <option value="weeks">Weeks</option>
                      <option value="months">Months</option>
                      <option value="years">Years</option>
                    </select>
                  </div>
                </div>

                {/* Exclude Weekends Option */}
                {(unitType === "days" || unitType === "weeks") && (
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="excludeWeekends"
                      checked={excludeWeekends}
                      onCheckedChange={(checked) => setExcludeWeekends(checked as boolean)}
                    />
                    <label
                      htmlFor="excludeWeekends"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Exclude weekends (business days only)
                    </label>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDate} className="w-full" size="lg">
                  Calculate Date
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Calculated Date</p>
                      <p className="text-2xl font-bold text-cyan-700 mb-1">
                        {result.date.toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                        })}
                      </p>
                      <p className="text-lg font-semibold text-cyan-600">{result.dayOfWeek}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <p className="font-medium text-cyan-900 text-sm">90 days from today</p>
                      <p className="text-xs text-cyan-700 mt-1">Great for project deadlines</p>
                    </div>
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <p className="font-medium text-cyan-900 text-sm">30 business days from start</p>
                      <p className="text-xs text-cyan-700 mt-1">Useful for contract terms</p>
                    </div>
                    <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <p className="font-medium text-cyan-900 text-sm">6 months before event</p>
                      <p className="text-xs text-cyan-700 mt-1">Perfect for event planning</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Information</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div>
                    <strong className="text-foreground">Days & Weeks:</strong> Calculated by exact number of days,
                    optionally excluding weekends
                  </div>
                  <div>
                    <strong className="text-foreground">Months:</strong> Adds/subtracts calendar months, handling
                    varying month lengths
                  </div>
                  <div>
                    <strong className="text-foreground">Years:</strong> Adds/subtracts full years, accounting for leap
                    years
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Add/Subtract Date */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Add/Subtract Date Calculation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Add/Subtract Date Calculator is a powerful tool that helps you determine future or past dates by
                  adding or subtracting a specific duration from a given starting date. This functionality is essential
                  for planning, scheduling, and tracking time-sensitive activities in both personal and professional
                  contexts. Whether you need to calculate project deadlines, track payment due dates, plan events, or
                  determine contract expiration dates, this calculator provides accurate and reliable date calculations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Unlike simple calendar counting, this calculator accounts for the complexities of date arithmetic,
                  including varying month lengths (28-31 days), leap years, and optionally business days by excluding
                  weekends. It handles different time units (days, weeks, months, and years) and performs intelligent
                  calculations that respect the calendar system's inherent irregularities, ensuring accurate results for
                  any date range within the valid calendar period.
                </p>
              </CardContent>
            </Card>

            {/* Common Use Cases */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Common Use Cases</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Date calculations are invaluable in numerous real-world scenarios. In project management, teams
                  frequently need to determine deadlines by adding a specific number of days or weeks to a project start
                  date. Financial professionals use date calculations to determine payment due dates, loan maturity
                  dates, and interest accrual periods. Legal contracts often specify terms in months or years, requiring
                  precise calculation of expiration or renewal dates.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Personal applications include planning vacations (calculating return dates), tracking pregnancies
                  (adding 40 weeks to conception date), monitoring subscriptions and warranties, scheduling medical
                  appointments, and managing recurring commitments. The business day option is particularly useful for
                  corporate environments where weekends don't count toward processing times, delivery schedules, or
                  response deadlines. This calculator simplifies all these scenarios by providing instant, accurate date
                  calculations.
                </p>
              </CardContent>
            </Card>

            {/* Understanding Date Arithmetic */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Plus className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Date Arithmetic</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Date arithmetic involves more complexity than simple numeric addition or subtraction because our
                  calendar system has irregular patterns. When adding days, the calculator counts forward sequentially,
                  automatically handling month boundaries and year transitions. For example, adding 15 days to January
                  20th correctly results in February 4th, accounting for January's 31 days.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Month and year calculations require special handling because months have different lengths. Adding one
                  month to January 31st results in February 28th (or 29th in leap years) because February lacks a 31st
                  day. Similarly, adding one year to February 29th, 2020 (a leap year) results in February 28th, 2021 (a
                  non-leap year). The calculator intelligently manages these edge cases to provide meaningful results.
                  When the business days option is enabled, weekends are automatically skipped in the counting process,
                  which is crucial for calculating working days in professional contexts where Saturday and Sunday are
                  non-working days.
                </p>
              </CardContent>
            </Card>

            {/* Tips for Accurate Calculations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  For the most accurate results, always verify your base date is correct before calculating. Pay
                  attention to the unit you're using—adding 4 weeks (28 days) is not always the same as adding 1 month,
                  which varies from 28 to 31 days depending on the specific month. When planning business-related
                  deadlines, enable the "exclude weekends" option to calculate only business days, giving you a more
                  realistic timeline for work that doesn't occur on weekends.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Consider time zones and regional holidays if your calculation involves international coordination or
                  region-specific business days. While this calculator handles weekends, it doesn't account for public
                  holidays, which vary by country and region. For critical deadline calculations, always add a buffer to
                  account for potential delays or unforeseen circumstances. Remember that the calculator supports dates
                  from 1900 to 2100, which covers virtually all practical modern use cases.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Date calculations are based on the entered values and selected options.
                  Actual results may vary depending on calendar differences, holidays, and time zones. This calculator
                  does not account for regional holidays or specific organizational calendars. Always verify critical
                  dates independently, especially for legal, financial, or time-sensitive commitments.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
