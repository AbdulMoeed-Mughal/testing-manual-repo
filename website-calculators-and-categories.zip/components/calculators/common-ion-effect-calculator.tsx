"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Beaker, TrendingDown } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type SaltType = "MX" | "MX2" | "M2X" | "MX3" | "M2X3"

interface CommonIonResult {
  newSolubility: number
  originalSolubility: number
  reductionPercent: number
  ksp: number
}

export function CommonIonEffectCalculator() {
  const [saltType, setSaltType] = useState<SaltType>("MX")
  const [originalSolubility, setOriginalSolubility] = useState("")
  const [commonIonConcentration, setCommonIonConcentration] = useState("")
  const [result, setResult] = useState<CommonIonResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCommonIonEffect = () => {
    setError("")
    setResult(null)

    const S0 = Number.parseFloat(originalSolubility)
    const commonIon = Number.parseFloat(commonIonConcentration)

    if (isNaN(S0) || S0 <= 0) {
      setError("Please enter a valid original solubility greater than 0")
      return
    }

    if (isNaN(commonIon) || commonIon <= 0) {
      setError("Please enter a valid common ion concentration greater than 0")
      return
    }

    let ksp: number
    let newSolubility: number

    // Calculate Ksp from original solubility based on salt type
    switch (saltType) {
      case "MX":
        // MX -> M+ + X-
        // Ksp = [M+][X-] = S * S = S^2
        ksp = S0 * S0
        // With common ion: Ksp = S * (S + commonIon) ≈ S * commonIon (when commonIon >> S)
        // Solving: S = Ksp / (S + commonIon)
        // Approximation: S ≈ Ksp / commonIon
        newSolubility = ksp / commonIon
        break
      case "MX2":
        // MX2 -> M2+ + 2X-
        // Ksp = [M2+][X-]^2 = S * (2S)^2 = 4S^3
        ksp = 4 * Math.pow(S0, 3)
        // With common ion X-: Ksp = S * (2S + commonIon)^2
        // Approximation when commonIon >> 2S: S ≈ Ksp / commonIon^2
        newSolubility = ksp / Math.pow(commonIon, 2)
        break
      case "M2X":
        // M2X -> 2M+ + X2-
        // Ksp = [M+]^2[X2-] = (2S)^2 * S = 4S^3
        ksp = 4 * Math.pow(S0, 3)
        // With common ion M+: Ksp = (2S + commonIon)^2 * S
        // Approximation: S ≈ Ksp / commonIon^2
        newSolubility = ksp / Math.pow(commonIon, 2)
        break
      case "MX3":
        // MX3 -> M3+ + 3X-
        // Ksp = [M3+][X-]^3 = S * (3S)^3 = 27S^4
        ksp = 27 * Math.pow(S0, 4)
        // With common ion: S ≈ Ksp / commonIon^3
        newSolubility = ksp / Math.pow(commonIon, 3)
        break
      case "M2X3":
        // M2X3 -> 2M3+ + 3X2-
        // Ksp = [M3+]^2[X2-]^3 = (2S)^2 * (3S)^3 = 4S^2 * 27S^3 = 108S^5
        ksp = 108 * Math.pow(S0, 5)
        // Approximation with common ion
        newSolubility = Math.pow(ksp / (4 * Math.pow(commonIon, 3)), 0.5)
        break
      default:
        ksp = S0 * S0
        newSolubility = ksp / commonIon
    }

    // Ensure solubility is positive and less than original
    if (newSolubility < 0) {
      newSolubility = 0
    }
    if (newSolubility > S0) {
      newSolubility = S0 * 0.99 // Cap at slightly less than original
    }

    const reductionPercent = ((S0 - newSolubility) / S0) * 100

    setResult({
      newSolubility,
      originalSolubility: S0,
      reductionPercent,
      ksp
    })
  }

  const handleReset = () => {
    setOriginalSolubility("")
    setCommonIonConcentration("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Common Ion Effect: Original solubility: ${result.originalSolubility.toExponential(3)} M, New solubility: ${result.newSolubility.toExponential(3)} M, Reduction: ${result.reductionPercent.toFixed(1)}%`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Common Ion Effect Result",
          text: `Common Ion Effect calculation: Original solubility: ${result.originalSolubility.toExponential(3)} M, New solubility: ${result.newSolubility.toExponential(3)} M, Reduction: ${result.reductionPercent.toFixed(1)}%`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getSaltTypeLabel = (type: SaltType): string => {
    switch (type) {
      case "MX": return "MX (1:1)"
      case "MX2": return "MX₂ (1:2)"
      case "M2X": return "M₂X (2:1)"
      case "MX3": return "MX₃ (1:3)"
      case "M2X3": return "M₂X₃ (2:3)"
      default: return type
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Common Ion Effect Calculator</CardTitle>
                    <CardDescription>Calculate solubility change with common ion</CardDescription>
                  </div>
                </div>

                {/* Salt Type Selection */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Salt Stoichiometry</Label>
                  <div className="grid grid-cols-5 gap-1">
                    {(["MX", "MX2", "M2X", "MX3", "M2X3"] as SaltType[]).map((type) => (
                      <button
                        key={type}
                        onClick={() => {
                          setSaltType(type)
                          setResult(null)
                        }}
                        className={`px-2 py-2 rounded-md text-xs font-medium transition-colors ${
                          saltType === type
                            ? "bg-purple-600 text-white"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {type === "MX2" ? "MX₂" : type === "M2X" ? "M₂X" : type === "MX3" ? "MX₃" : type === "M2X3" ? "M₂X₃" : type}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Original Solubility Input */}
                <div className="space-y-2">
                  <Label htmlFor="originalSolubility">Original Solubility, S₀ (mol/L)</Label>
                  <Input
                    id="originalSolubility"
                    type="number"
                    placeholder="e.g., 0.001 or 1e-3"
                    value={originalSolubility}
                    onChange={(e) => setOriginalSolubility(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Common Ion Concentration Input */}
                <div className="space-y-2">
                  <Label htmlFor="commonIonConcentration">Common Ion Concentration (mol/L)</Label>
                  <Input
                    id="commonIonConcentration"
                    type="number"
                    placeholder="e.g., 0.1"
                    value={commonIonConcentration}
                    onChange={(e) => setCommonIonConcentration(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCommonIonEffect} className="w-full bg-purple-600 hover:bg-purple-700" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">New Solubility</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">
                        {result.newSolubility.toExponential(3)}
                      </p>
                      <p className="text-sm text-purple-600 mb-3">mol/L</p>
                      
                      <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                        <div className="p-2 bg-white rounded-lg">
                          <p className="text-muted-foreground">Ksp</p>
                          <p className="font-semibold text-purple-700">{result.ksp.toExponential(3)}</p>
                        </div>
                        <div className="p-2 bg-white rounded-lg">
                          <p className="text-muted-foreground">Reduction</p>
                          <p className="font-semibold text-red-600">{result.reductionPercent.toFixed(1)}%</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Ksp Formulas by Salt Type</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">MX</span>
                      <span className="text-sm text-purple-600 font-mono">Ksp = S²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">MX₂ or M₂X</span>
                      <span className="text-sm text-purple-600 font-mono">Ksp = 4S³</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">MX₃</span>
                      <span className="text-sm text-purple-600 font-mono">Ksp = 27S⁴</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">M₂X₃</span>
                      <span className="text-sm text-purple-600 font-mono">Ksp = 108S⁵</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">The Common Ion Effect</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">MX ⇌ M⁺ + X⁻</p>
                    <p className="text-xs mt-2">Adding X⁻ shifts equilibrium left</p>
                  </div>
                  <p>
                    The common ion effect decreases the solubility of a sparingly soluble salt when a common ion is added to the solution.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Common Ion Effect */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-purple-600" />
                  <CardTitle>What is the Common Ion Effect?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The common ion effect is a phenomenon that occurs when a salt is dissolved in a solution that already contains one of the ions present in the salt. According to Le Chatelier's principle, when the concentration of a product ion is increased, the equilibrium shifts to favor the reactant side, thereby decreasing the solubility of the sparingly soluble salt.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This effect is a direct application of the solubility product principle and equilibrium chemistry. For example, if you try to dissolve silver chloride (AgCl) in a solution that already contains chloride ions from sodium chloride (NaCl), the solubility of AgCl will be significantly reduced because the system adjusts to maintain the solubility product constant (Ksp).
                </p>
              </CardContent>
            </Card>

            {/* How it Works */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-purple-600" />
                  <CardTitle>How the Calculation Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculator first determines the Ksp (solubility product constant) from the original molar solubility of the salt in pure water. The formula varies by salt stoichiometry: for a 1:1 salt like AgCl, Ksp = S²; for a 1:2 salt like CaF₂, Ksp = 4S³.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Once Ksp is known, the new solubility is calculated by considering the contribution of the common ion to the equilibrium expression. When the common ion concentration is much larger than the solubility, the approximation S' ≈ Ksp/(common ion concentration)ⁿ is used, where n depends on the salt stoichiometry.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-purple-600" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The common ion effect has numerous practical applications in chemistry and industry. In qualitative analysis, it is used to selectively precipitate certain ions from a mixture. By adding a common ion, chemists can reduce the solubility of a target compound enough to cause precipitation while keeping other compounds in solution.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In water treatment, the common ion effect is exploited to remove hardness ions (Ca²⁺ and Mg²⁺) from water. In pharmaceutical formulations, controlling drug solubility through the common ion effect can affect drug absorption and bioavailability. The effect is also important in biological systems, where ionic concentrations must be carefully regulated.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations and Assumptions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator assumes ideal solution behavior, which may not accurately reflect real-world conditions. At high ionic strengths, activity coefficients can differ significantly from unity, causing deviations from ideal behavior. The Debye-Hückel equation or other activity coefficient models would be needed for more accurate calculations in concentrated solutions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature effects are not accounted for in this calculation—Ksp values are temperature-dependent, and changes in temperature will affect both the original and new solubility values. Additionally, the calculator assumes complete dissociation of the salt providing the common ion, which may not be true for weak electrolytes. Complex ion formation and ion pairing effects are also not considered.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
