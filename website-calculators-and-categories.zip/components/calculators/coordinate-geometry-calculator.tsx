"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, Compass, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type Operation = "distance" | "midpoint" | "slope" | "line-equation" | "circle" | "ellipse" | "parabola" | "hyperbola"
type Dimension = "2d" | "3d"

interface Result {
  operation: Operation
  values: Record<string, string | number>
  steps: string[]
}

export function CoordinateGeometryCalculator() {
  const [operation, setOperation] = useState<Operation>("distance")
  const [dimension, setDimension] = useState<Dimension>("2d")
  const [showSteps, setShowSteps] = useState(false)
  const [stepsExpanded, setStepsExpanded] = useState(false)

  // Point inputs
  const [x1, setX1] = useState("")
  const [y1, setY1] = useState("")
  const [z1, setZ1] = useState("")
  const [x2, setX2] = useState("")
  const [y2, setY2] = useState("")
  const [z2, setZ2] = useState("")

  // Circle inputs
  const [centerX, setCenterX] = useState("")
  const [centerY, setCenterY] = useState("")
  const [radius, setRadius] = useState("")

  // Ellipse inputs
  const [semiMajorA, setSemiMajorA] = useState("")
  const [semiMinorB, setSemiMinorB] = useState("")

  // Parabola inputs
  const [vertexX, setVertexX] = useState("")
  const [vertexY, setVertexY] = useState("")
  const [focusDistance, setFocusDistance] = useState("")
  const [parabolaOrientation, setParabolaOrientation] = useState<"vertical" | "horizontal">("vertical")

  // Hyperbola inputs
  const [hyperbolaA, setHyperbolaA] = useState("")
  const [hyperbolaB, setHyperbolaB] = useState("")
  const [hyperbolaOrientation, setHyperbolaOrientation] = useState<"horizontal" | "vertical">("horizontal")

  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDistance = (): Result | null => {
    const p1x = Number.parseFloat(x1)
    const p1y = Number.parseFloat(y1)
    const p2x = Number.parseFloat(x2)
    const p2y = Number.parseFloat(y2)

    if ([p1x, p1y, p2x, p2y].some(isNaN)) {
      setError("Please enter valid coordinates for both points")
      return null
    }

    const steps: string[] = []
    let distance: number

    if (dimension === "2d") {
      const dx = p2x - p1x
      const dy = p2y - p1y
      distance = Math.sqrt(dx * dx + dy * dy)

      steps.push(`Given points: P₁(${p1x}, ${p1y}) and P₂(${p2x}, ${p2y})`)
      steps.push(`Distance formula: d = √((x₂ - x₁)² + (y₂ - y₁)²)`)
      steps.push(`Substitute: d = √((${p2x} - ${p1x})² + (${p2y} - ${p1y})²)`)
      steps.push(`Calculate: d = √((${dx})² + (${dy})²)`)
      steps.push(`Simplify: d = √(${dx * dx} + ${dy * dy})`)
      steps.push(`Result: d = √${dx * dx + dy * dy} = ${distance.toFixed(6)}`)
    } else {
      const p1z = Number.parseFloat(z1)
      const p2z = Number.parseFloat(z2)

      if (isNaN(p1z) || isNaN(p2z)) {
        setError("Please enter valid z-coordinates for 3D mode")
        return null
      }

      const dx = p2x - p1x
      const dy = p2y - p1y
      const dz = p2z - p1z
      distance = Math.sqrt(dx * dx + dy * dy + dz * dz)

      steps.push(`Given points: P₁(${p1x}, ${p1y}, ${p1z}) and P₂(${p2x}, ${p2y}, ${p2z})`)
      steps.push(`Distance formula: d = √((x₂ - x₁)² + (y₂ - y₁)² + (z₂ - z₁)²)`)
      steps.push(`Substitute: d = √((${p2x} - ${p1x})² + (${p2y} - ${p1y})² + (${p2z} - ${p1z})²)`)
      steps.push(`Calculate: d = √((${dx})² + (${dy})² + (${dz})²)`)
      steps.push(`Result: d = ${distance.toFixed(6)}`)
    }

    return {
      operation: "distance",
      values: { distance: distance.toFixed(6) },
      steps,
    }
  }

  const calculateMidpoint = (): Result | null => {
    const p1x = Number.parseFloat(x1)
    const p1y = Number.parseFloat(y1)
    const p2x = Number.parseFloat(x2)
    const p2y = Number.parseFloat(y2)

    if ([p1x, p1y, p2x, p2y].some(isNaN)) {
      setError("Please enter valid coordinates for both points")
      return null
    }

    const steps: string[] = []
    const mx = (p1x + p2x) / 2
    const my = (p1y + p2y) / 2

    if (dimension === "2d") {
      steps.push(`Given points: P₁(${p1x}, ${p1y}) and P₂(${p2x}, ${p2y})`)
      steps.push(`Midpoint formula: M = ((x₁ + x₂)/2, (y₁ + y₂)/2)`)
      steps.push(`Substitute: M = ((${p1x} + ${p2x})/2, (${p1y} + ${p2y})/2)`)
      steps.push(`Calculate: M = (${p1x + p2x}/2, ${p1y + p2y}/2)`)
      steps.push(`Result: M = (${mx.toFixed(4)}, ${my.toFixed(4)})`)

      return {
        operation: "midpoint",
        values: { midpointX: mx.toFixed(4), midpointY: my.toFixed(4) },
        steps,
      }
    } else {
      const p1z = Number.parseFloat(z1)
      const p2z = Number.parseFloat(z2)

      if (isNaN(p1z) || isNaN(p2z)) {
        setError("Please enter valid z-coordinates for 3D mode")
        return null
      }

      const mz = (p1z + p2z) / 2
      steps.push(`Given points: P₁(${p1x}, ${p1y}, ${p1z}) and P₂(${p2x}, ${p2y}, ${p2z})`)
      steps.push(`Midpoint formula: M = ((x₁ + x₂)/2, (y₁ + y₂)/2, (z₁ + z₂)/2)`)
      steps.push(`Result: M = (${mx.toFixed(4)}, ${my.toFixed(4)}, ${mz.toFixed(4)})`)

      return {
        operation: "midpoint",
        values: { midpointX: mx.toFixed(4), midpointY: my.toFixed(4), midpointZ: mz.toFixed(4) },
        steps,
      }
    }
  }

  const calculateSlope = (): Result | null => {
    const p1x = Number.parseFloat(x1)
    const p1y = Number.parseFloat(y1)
    const p2x = Number.parseFloat(x2)
    const p2y = Number.parseFloat(y2)

    if ([p1x, p1y, p2x, p2y].some(isNaN)) {
      setError("Please enter valid coordinates for both points")
      return null
    }

    const steps: string[] = []
    steps.push(`Given points: P₁(${p1x}, ${p1y}) and P₂(${p2x}, ${p2y})`)
    steps.push(`Slope formula: m = (y₂ - y₁)/(x₂ - x₁)`)

    if (p2x - p1x === 0) {
      steps.push(`Since x₂ - x₁ = ${p2x} - ${p1x} = 0`)
      steps.push(`The slope is undefined (vertical line)`)
      return {
        operation: "slope",
        values: { slope: "undefined", angle: "90°" },
        steps,
      }
    }

    const slope = (p2y - p1y) / (p2x - p1x)
    const angle = (Math.atan(slope) * 180) / Math.PI

    steps.push(`Substitute: m = (${p2y} - ${p1y})/(${p2x} - ${p1x})`)
    steps.push(`Calculate: m = ${p2y - p1y}/${p2x - p1x}`)
    steps.push(`Result: m = ${slope.toFixed(6)}`)
    steps.push(`Angle with x-axis: θ = arctan(${slope.toFixed(4)}) = ${angle.toFixed(2)}°`)

    return {
      operation: "slope",
      values: { slope: slope.toFixed(6), angle: angle.toFixed(2) + "°" },
      steps,
    }
  }

  const calculateLineEquation = (): Result | null => {
    const p1x = Number.parseFloat(x1)
    const p1y = Number.parseFloat(y1)
    const p2x = Number.parseFloat(x2)
    const p2y = Number.parseFloat(y2)

    if ([p1x, p1y, p2x, p2y].some(isNaN)) {
      setError("Please enter valid coordinates for both points")
      return null
    }

    const steps: string[] = []
    steps.push(`Given points: P₁(${p1x}, ${p1y}) and P₂(${p2x}, ${p2y})`)

    if (p2x - p1x === 0) {
      steps.push(`Since x₂ = x₁ = ${p1x}, this is a vertical line`)
      steps.push(`Equation: x = ${p1x}`)
      return {
        operation: "line-equation",
        values: {
          slopeIntercept: `x = ${p1x}`,
          standard: `x = ${p1x}`,
          pointSlope: `x = ${p1x}`,
        },
        steps,
      }
    }

    const m = (p2y - p1y) / (p2x - p1x)
    const b = p1y - m * p1x

    steps.push(`Calculate slope: m = (${p2y} - ${p1y})/(${p2x} - ${p1x}) = ${m.toFixed(4)}`)
    steps.push(`Using point-slope form: y - y₁ = m(x - x₁)`)
    steps.push(`y - ${p1y} = ${m.toFixed(4)}(x - ${p1x})`)
    steps.push(`Convert to slope-intercept: y = ${m.toFixed(4)}x + ${b.toFixed(4)}`)

    const A = -m
    const B = 1
    const C = -b

    return {
      operation: "line-equation",
      values: {
        slopeIntercept: `y = ${m.toFixed(4)}x ${b >= 0 ? "+" : ""} ${b.toFixed(4)}`,
        pointSlope: `y - ${p1y} = ${m.toFixed(4)}(x - ${p1x})`,
        standard: `${A.toFixed(4)}x + ${B}y ${C >= 0 ? "+" : ""} ${C.toFixed(4)} = 0`,
        slope: m.toFixed(4),
        yIntercept: b.toFixed(4),
      },
      steps,
    }
  }

  const calculateCircle = (): Result | null => {
    const cx = Number.parseFloat(centerX)
    const cy = Number.parseFloat(centerY)
    const r = Number.parseFloat(radius)

    if ([cx, cy, r].some(isNaN)) {
      setError("Please enter valid center coordinates and radius")
      return null
    }

    if (r <= 0) {
      setError("Radius must be greater than 0")
      return null
    }

    const steps: string[] = []
    steps.push(`Given: Center (${cx}, ${cy}) and radius r = ${r}`)
    steps.push(`Standard form: (x - h)² + (y - k)² = r²`)
    steps.push(`Substitute: (x - ${cx})² + (y - ${cy})² = ${r}²`)

    const standardForm = `(x ${cx >= 0 ? "-" : "+"} ${Math.abs(cx)})² + (y ${cy >= 0 ? "-" : "+"} ${Math.abs(cy)})² = ${r * r}`
    const D = -2 * cx
    const E = -2 * cy
    const F = cx * cx + cy * cy - r * r
    const generalForm = `x² + y² ${D >= 0 ? "+" : ""} ${D}x ${E >= 0 ? "+" : ""} ${E}y ${F >= 0 ? "+" : ""} ${F} = 0`

    steps.push(`General form: x² + y² + Dx + Ey + F = 0`)
    steps.push(`Where D = -2h = ${D}, E = -2k = ${E}, F = h² + k² - r² = ${F}`)
    steps.push(`Result: ${generalForm}`)

    return {
      operation: "circle",
      values: {
        standardForm,
        generalForm,
        center: `(${cx}, ${cy})`,
        radius: r,
        diameter: 2 * r,
        area: (Math.PI * r * r).toFixed(4),
        circumference: (2 * Math.PI * r).toFixed(4),
      },
      steps,
    }
  }

  const calculateEllipse = (): Result | null => {
    const cx = Number.parseFloat(centerX)
    const cy = Number.parseFloat(centerY)
    const a = Number.parseFloat(semiMajorA)
    const b = Number.parseFloat(semiMinorB)

    if ([cx, cy, a, b].some(isNaN)) {
      setError("Please enter valid center coordinates and axes lengths")
      return null
    }

    if (a <= 0 || b <= 0) {
      setError("Axes lengths must be greater than 0")
      return null
    }

    const steps: string[] = []
    const major = Math.max(a, b)
    const minor = Math.min(a, b)
    const c = Math.sqrt(major * major - minor * minor)
    const e = c / major

    steps.push(`Given: Center (${cx}, ${cy}), a = ${a}, b = ${b}`)
    steps.push(`Standard form: (x - h)²/a² + (y - k)²/b² = 1`)

    const isHorizontal = a >= b
    let foci: string
    if (isHorizontal) {
      foci = `(${(cx - c).toFixed(4)}, ${cy}) and (${(cx + c).toFixed(4)}, ${cy})`
      steps.push(`Since a ≥ b, the major axis is horizontal`)
    } else {
      foci = `(${cx}, ${(cy - c).toFixed(4)}) and (${cx}, ${(cy + c).toFixed(4)})`
      steps.push(`Since b > a, the major axis is vertical`)
    }

    steps.push(`c = √(a² - b²) = √(${major * major} - ${minor * minor}) = ${c.toFixed(4)}`)
    steps.push(`Eccentricity e = c/a = ${e.toFixed(4)}`)

    const area = Math.PI * a * b
    const perimeter = Math.PI * (3 * (a + b) - Math.sqrt((3 * a + b) * (a + 3 * b)))

    return {
      operation: "ellipse",
      values: {
        standardForm: `(x ${cx >= 0 ? "-" : "+"} ${Math.abs(cx)})²/${a * a} + (y ${cy >= 0 ? "-" : "+"} ${Math.abs(cy)})²/${b * b} = 1`,
        center: `(${cx}, ${cy})`,
        semiMajorAxis: major,
        semiMinorAxis: minor,
        foci,
        eccentricity: e.toFixed(4),
        area: area.toFixed(4),
        perimeter: perimeter.toFixed(4),
      },
      steps,
    }
  }

  const calculateParabola = (): Result | null => {
    const vx = Number.parseFloat(vertexX)
    const vy = Number.parseFloat(vertexY)
    const p = Number.parseFloat(focusDistance)

    if ([vx, vy, p].some(isNaN)) {
      setError("Please enter valid vertex coordinates and focus distance")
      return null
    }

    if (p === 0) {
      setError("Focus distance cannot be 0")
      return null
    }

    const steps: string[] = []
    steps.push(`Given: Vertex (${vx}, ${vy}), p = ${p}`)

    let standardForm: string
    let focus: string
    let directrix: string
    let axis: string

    if (parabolaOrientation === "vertical") {
      standardForm = `(x ${vx >= 0 ? "-" : "+"} ${Math.abs(vx)})² = ${4 * p}(y ${vy >= 0 ? "-" : "+"} ${Math.abs(vy)})`
      focus = `(${vx}, ${vy + p})`
      directrix = `y = ${vy - p}`
      axis = `x = ${vx}`
      steps.push(`Vertical parabola: (x - h)² = 4p(y - k)`)
      steps.push(`Focus: (h, k + p) = (${vx}, ${vy + p})`)
      steps.push(`Directrix: y = k - p = ${vy - p}`)
    } else {
      standardForm = `(y ${vy >= 0 ? "-" : "+"} ${Math.abs(vy)})² = ${4 * p}(x ${vx >= 0 ? "-" : "+"} ${Math.abs(vx)})`
      focus = `(${vx + p}, ${vy})`
      directrix = `x = ${vx - p}`
      axis = `y = ${vy}`
      steps.push(`Horizontal parabola: (y - k)² = 4p(x - h)`)
      steps.push(`Focus: (h + p, k) = (${vx + p}, ${vy})`)
      steps.push(`Directrix: x = h - p = ${vx - p}`)
    }

    steps.push(`Axis of symmetry: ${axis}`)
    steps.push(`Latus rectum length: |4p| = ${Math.abs(4 * p)}`)

    return {
      operation: "parabola",
      values: {
        standardForm,
        vertex: `(${vx}, ${vy})`,
        focus,
        directrix,
        axisOfSymmetry: axis,
        focalLength: Math.abs(p),
        latusRectum: Math.abs(4 * p),
        opening:
          p > 0
            ? parabolaOrientation === "vertical"
              ? "Upward"
              : "Right"
            : parabolaOrientation === "vertical"
              ? "Downward"
              : "Left",
      },
      steps,
    }
  }

  const calculateHyperbola = (): Result | null => {
    const cx = Number.parseFloat(centerX)
    const cy = Number.parseFloat(centerY)
    const a = Number.parseFloat(hyperbolaA)
    const b = Number.parseFloat(hyperbolaB)

    if ([cx, cy, a, b].some(isNaN)) {
      setError("Please enter valid center coordinates and axes lengths")
      return null
    }

    if (a <= 0 || b <= 0) {
      setError("Axes lengths must be greater than 0")
      return null
    }

    const steps: string[] = []
    const c = Math.sqrt(a * a + b * b)
    const e = c / a

    steps.push(`Given: Center (${cx}, ${cy}), a = ${a}, b = ${b}`)
    steps.push(`c = √(a² + b²) = √(${a * a} + ${b * b}) = ${c.toFixed(4)}`)
    steps.push(`Eccentricity e = c/a = ${e.toFixed(4)}`)

    let standardForm: string
    let vertices: string
    let foci: string
    let asymptotes: string

    if (hyperbolaOrientation === "horizontal") {
      standardForm = `(x ${cx >= 0 ? "-" : "+"} ${Math.abs(cx)})²/${a * a} - (y ${cy >= 0 ? "-" : "+"} ${Math.abs(cy)})²/${b * b} = 1`
      vertices = `(${cx - a}, ${cy}) and (${cx + a}, ${cy})`
      foci = `(${(cx - c).toFixed(4)}, ${cy}) and (${(cx + c).toFixed(4)}, ${cy})`
      asymptotes = `y - ${cy} = ±${(b / a).toFixed(4)}(x - ${cx})`
      steps.push(`Horizontal hyperbola: (x - h)²/a² - (y - k)²/b² = 1`)
    } else {
      standardForm = `(y ${cy >= 0 ? "-" : "+"} ${Math.abs(cy)})²/${a * a} - (x ${cx >= 0 ? "-" : "+"} ${Math.abs(cx)})²/${b * b} = 1`
      vertices = `(${cx}, ${cy - a}) and (${cx}, ${cy + a})`
      foci = `(${cx}, ${(cy - c).toFixed(4)}) and (${cx}, ${(cy + c).toFixed(4)})`
      asymptotes = `y - ${cy} = ±${(a / b).toFixed(4)}(x - ${cx})`
      steps.push(`Vertical hyperbola: (y - k)²/a² - (x - h)²/b² = 1`)
    }

    return {
      operation: "hyperbola",
      values: {
        standardForm,
        center: `(${cx}, ${cy})`,
        vertices,
        foci,
        asymptotes,
        eccentricity: e.toFixed(4),
        transverseAxis: 2 * a,
        conjugateAxis: 2 * b,
      },
      steps,
    }
  }

  const handleCalculate = () => {
    setError("")
    setResult(null)

    let calculatedResult: Result | null = null

    switch (operation) {
      case "distance":
        calculatedResult = calculateDistance()
        break
      case "midpoint":
        calculatedResult = calculateMidpoint()
        break
      case "slope":
        calculatedResult = calculateSlope()
        break
      case "line-equation":
        calculatedResult = calculateLineEquation()
        break
      case "circle":
        calculatedResult = calculateCircle()
        break
      case "ellipse":
        calculatedResult = calculateEllipse()
        break
      case "parabola":
        calculatedResult = calculateParabola()
        break
      case "hyperbola":
        calculatedResult = calculateHyperbola()
        break
    }

    if (calculatedResult) {
      setResult(calculatedResult)
    }
  }

  const handleReset = () => {
    setX1("")
    setY1("")
    setZ1("")
    setX2("")
    setY2("")
    setZ2("")
    setCenterX("")
    setCenterY("")
    setRadius("")
    setSemiMajorA("")
    setSemiMinorB("")
    setVertexX("")
    setVertexY("")
    setFocusDistance("")
    setHyperbolaA("")
    setHyperbolaB("")
    setResult(null)
    setError("")
    setCopied(false)
    setStepsExpanded(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = Object.entries(result.values)
        .map(([key, value]) => `${key}: ${value}`)
        .join("\n")
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const renderInputs = () => {
    switch (operation) {
      case "distance":
      case "midpoint":
      case "slope":
      case "line-equation":
        return (
          <div className="space-y-4">
            {(operation === "distance" || operation === "midpoint") && (
              <div className="flex items-center justify-between">
                <Label>Dimension</Label>
                <div className="flex items-center gap-2">
                  <span className={`text-sm ${dimension === "2d" ? "font-medium" : "text-muted-foreground"}`}>2D</span>
                  <Switch
                    checked={dimension === "3d"}
                    onCheckedChange={(checked) => setDimension(checked ? "3d" : "2d")}
                  />
                  <span className={`text-sm ${dimension === "3d" ? "font-medium" : "text-muted-foreground"}`}>3D</span>
                </div>
              </div>
            )}
            <div className="space-y-3">
              <Label>Point 1 (x₁, y₁{dimension === "3d" ? ", z₁" : ""})</Label>
              <div className={`grid gap-2 ${dimension === "3d" ? "grid-cols-3" : "grid-cols-2"}`}>
                <Input type="number" placeholder="x₁" value={x1} onChange={(e) => setX1(e.target.value)} />
                <Input type="number" placeholder="y₁" value={y1} onChange={(e) => setY1(e.target.value)} />
                {dimension === "3d" && (
                  <Input type="number" placeholder="z₁" value={z1} onChange={(e) => setZ1(e.target.value)} />
                )}
              </div>
            </div>
            <div className="space-y-3">
              <Label>Point 2 (x₂, y₂{dimension === "3d" ? ", z₂" : ""})</Label>
              <div className={`grid gap-2 ${dimension === "3d" ? "grid-cols-3" : "grid-cols-2"}`}>
                <Input type="number" placeholder="x₂" value={x2} onChange={(e) => setX2(e.target.value)} />
                <Input type="number" placeholder="y₂" value={y2} onChange={(e) => setY2(e.target.value)} />
                {dimension === "3d" && (
                  <Input type="number" placeholder="z₂" value={z2} onChange={(e) => setZ2(e.target.value)} />
                )}
              </div>
            </div>
          </div>
        )

      case "circle":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Center (h, k)</Label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="h (center x)"
                  value={centerX}
                  onChange={(e) => setCenterX(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="k (center y)"
                  value={centerY}
                  onChange={(e) => setCenterY(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Radius (r)</Label>
              <Input
                type="number"
                placeholder="Enter radius"
                value={radius}
                onChange={(e) => setRadius(e.target.value)}
                min="0"
                step="any"
              />
            </div>
          </div>
        )

      case "ellipse":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Center (h, k)</Label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="h (center x)"
                  value={centerX}
                  onChange={(e) => setCenterX(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="k (center y)"
                  value={centerY}
                  onChange={(e) => setCenterY(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Semi-axes</Label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="a (semi-major)"
                  value={semiMajorA}
                  onChange={(e) => setSemiMajorA(e.target.value)}
                  min="0"
                  step="any"
                />
                <Input
                  type="number"
                  placeholder="b (semi-minor)"
                  value={semiMinorB}
                  onChange={(e) => setSemiMinorB(e.target.value)}
                  min="0"
                  step="any"
                />
              </div>
            </div>
          </div>
        )

      case "parabola":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Vertex (h, k)</Label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="h (vertex x)"
                  value={vertexX}
                  onChange={(e) => setVertexX(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="k (vertex y)"
                  value={vertexY}
                  onChange={(e) => setVertexY(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Focus Distance (p)</Label>
              <Input
                type="number"
                placeholder="Enter p (positive or negative)"
                value={focusDistance}
                onChange={(e) => setFocusDistance(e.target.value)}
                step="any"
              />
              <p className="text-xs text-muted-foreground">Positive p opens up/right, negative opens down/left</p>
            </div>
            <div className="space-y-2">
              <Label>Orientation</Label>
              <Select
                value={parabolaOrientation}
                onValueChange={(v) => setParabolaOrientation(v as "vertical" | "horizontal")}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vertical">Vertical (opens up/down)</SelectItem>
                  <SelectItem value="horizontal">Horizontal (opens left/right)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )

      case "hyperbola":
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Center (h, k)</Label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="h (center x)"
                  value={centerX}
                  onChange={(e) => setCenterX(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="k (center y)"
                  value={centerY}
                  onChange={(e) => setCenterY(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Semi-axes</Label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="a (transverse)"
                  value={hyperbolaA}
                  onChange={(e) => setHyperbolaA(e.target.value)}
                  min="0"
                  step="any"
                />
                <Input
                  type="number"
                  placeholder="b (conjugate)"
                  value={hyperbolaB}
                  onChange={(e) => setHyperbolaB(e.target.value)}
                  min="0"
                  step="any"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Orientation</Label>
              <Select
                value={hyperbolaOrientation}
                onValueChange={(v) => setHyperbolaOrientation(v as "horizontal" | "vertical")}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="horizontal">Horizontal (opens left/right)</SelectItem>
                  <SelectItem value="vertical">Vertical (opens up/down)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )
    }
  }

  const getOperationLabel = (op: Operation): string => {
    const labels: Record<Operation, string> = {
      distance: "Distance Between Points",
      midpoint: "Midpoint",
      slope: "Slope",
      "line-equation": "Line Equation",
      circle: "Circle",
      ellipse: "Ellipse",
      parabola: "Parabola",
      hyperbola: "Hyperbola",
    }
    return labels[op]
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Compass className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Coordinate Geometry Calculator</CardTitle>
                    <CardDescription>Advanced geometric calculations</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <Select
                    value={operation}
                    onValueChange={(v) => {
                      setOperation(v as Operation)
                      handleReset()
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="distance">Distance Between Points</SelectItem>
                      <SelectItem value="midpoint">Midpoint</SelectItem>
                      <SelectItem value="slope">Slope</SelectItem>
                      <SelectItem value="line-equation">Line Equation</SelectItem>
                      <SelectItem value="circle">Circle</SelectItem>
                      <SelectItem value="ellipse">Ellipse</SelectItem>
                      <SelectItem value="parabola">Parabola</SelectItem>
                      <SelectItem value="hyperbola">Hyperbola</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {renderInputs()}

                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="show-steps">Show Step-by-Step</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                <Button onClick={handleCalculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">{getOperationLabel(result.operation)}</p>
                      <div className="space-y-2">
                        {Object.entries(result.values).map(([key, value]) => (
                          <div key={key} className="flex justify-between items-center p-2 bg-white rounded-lg">
                            <span className="text-sm font-medium text-muted-foreground capitalize">
                              {key.replace(/([A-Z])/g, " $1").trim()}
                            </span>
                            <span className="font-mono font-semibold text-blue-600">{value}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 border-t border-blue-200 pt-4">
                        <button
                          onClick={() => setStepsExpanded(!stepsExpanded)}
                          className="flex items-center justify-between w-full text-left"
                        >
                          <span className="font-medium text-sm">Step-by-Step Solution</span>
                          {stepsExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>
                        {stepsExpanded && (
                          <div className="mt-3 space-y-2">
                            {result.steps.map((step, index) => (
                              <div key={index} className="flex gap-2 text-sm">
                                <span className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-200 text-blue-700 flex items-center justify-center text-xs font-medium">
                                  {index + 1}
                                </span>
                                <span className="text-muted-foreground">{step}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Operations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Distance</p>
                      <p className="text-muted-foreground font-mono text-xs mt-1">d = √((x₂-x₁)² + (y₂-y₁)²)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Midpoint</p>
                      <p className="text-muted-foreground font-mono text-xs mt-1">M = ((x₁+x₂)/2, (y₁+y₂)/2)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Slope</p>
                      <p className="text-muted-foreground font-mono text-xs mt-1">m = (y₂-y₁)/(x₂-x₁)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Circle</p>
                      <p className="text-muted-foreground font-mono text-xs mt-1">(x-h)² + (y-k)² = r²</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conic Sections</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Ellipse</p>
                      <p className="text-muted-foreground font-mono text-xs mt-1">(x-h)²/a² + (y-k)²/b² = 1</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Parabola</p>
                      <p className="text-muted-foreground font-mono text-xs mt-1">(x-h)² = 4p(y-k)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Hyperbola</p>
                      <p className="text-muted-foreground font-mono text-xs mt-1">(x-h)²/a² - (y-k)²/b² = 1</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Coordinate Geometry?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Coordinate geometry, also known as analytic geometry, is a branch of mathematics that uses algebraic
                  equations to describe geometric shapes and their properties. It establishes a connection between
                  algebra and geometry through the use of a coordinate system, allowing geometric problems to be solved
                  using algebraic methods and vice versa.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Cartesian coordinate system, developed by René Descartes, is the most commonly used system. It
                  represents points in a plane using ordered pairs (x, y) or in space using ordered triples (x, y, z).
                  This powerful mathematical tool is fundamental to many fields including physics, engineering, computer
                  graphics, and data visualization.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Coordinate geometry calculations follow standard mathematical formulas. Results depend on correct
                  input values and selected operation. This calculator is intended for educational purposes and should
                  be verified for critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
