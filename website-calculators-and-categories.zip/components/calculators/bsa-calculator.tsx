"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, User, Info, Calculator, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type BSAFormula = "mosteller" | "dubois" | "haycock" | "gehan"

interface BSAResult {
  bsa: number
  formula: string
  formulaName: string
  category: string
  color: string
  bgColor: string
}

export function BSACalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [formula, setFormula] = useState<BSAFormula>("mosteller")
  const [result, setResult] = useState<BSAResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const formulaNames: Record<BSAFormula, string> = {
    mosteller: "Mosteller",
    dubois: "DuBois & DuBois",
    haycock: "Haycock",
    gehan: "Gehan & George",
  }

  const formulaDescriptions: Record<BSAFormula, string> = {
    mosteller: "√[(Height × Weight) / 3600]",
    dubois: "0.007184 × Height^0.725 × Weight^0.425",
    haycock: "0.024265 × Height^0.3964 × Weight^0.5378",
    gehan: "0.0235 × Height^0.42246 × Weight^0.51456",
  }

  const calculateBSA = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    let bsa: number
    let formulaUsed: string

    switch (formula) {
      case "mosteller":
        bsa = Math.sqrt((heightInCm * weightInKg) / 3600)
        formulaUsed = `√[(${heightInCm.toFixed(1)} × ${weightInKg.toFixed(1)}) / 3600]`
        break
      case "dubois":
        bsa = 0.007184 * Math.pow(heightInCm, 0.725) * Math.pow(weightInKg, 0.425)
        formulaUsed = `0.007184 × ${heightInCm.toFixed(1)}^0.725 × ${weightInKg.toFixed(1)}^0.425`
        break
      case "haycock":
        bsa = 0.024265 * Math.pow(heightInCm, 0.3964) * Math.pow(weightInKg, 0.5378)
        formulaUsed = `0.024265 × ${heightInCm.toFixed(1)}^0.3964 × ${weightInKg.toFixed(1)}^0.5378`
        break
      case "gehan":
        bsa = 0.0235 * Math.pow(heightInCm, 0.42246) * Math.pow(weightInKg, 0.51456)
        formulaUsed = `0.0235 × ${heightInCm.toFixed(1)}^0.42246 × ${weightInKg.toFixed(1)}^0.51456`
        break
    }

    const roundedBSA = Math.round(bsa * 100) / 100

    // Categorize BSA
    let category: string
    let color: string
    let bgColor: string

    if (roundedBSA < 1.5) {
      category = "Below Average"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (roundedBSA < 1.9) {
      category = "Average"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (roundedBSA < 2.2) {
      category = "Above Average"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "High"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    }

    setResult({
      bsa: roundedBSA,
      formula: formulaUsed,
      formulaName: formulaNames[formula],
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setFormula("mosteller")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My Body Surface Area (BSA) is ${result.bsa} m² (${result.category}) using the ${result.formulaName} formula`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <User className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Body Surface Area Calculator</CardTitle>
                    <CardDescription>Calculate your BSA for medical purposes</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Formula Selection */}
                <div className="space-y-2">
                  <Label htmlFor="formula">BSA Formula</Label>
                  <Select value={formula} onValueChange={(v) => setFormula(v as BSAFormula)}>
                    <SelectTrigger id="formula">
                      <SelectValue placeholder="Select formula" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mosteller">Mosteller (Most Common)</SelectItem>
                      <SelectItem value="dubois">DuBois & DuBois</SelectItem>
                      <SelectItem value="haycock">Haycock (Pediatric)</SelectItem>
                      <SelectItem value="gehan">Gehan & George</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">{formulaDescriptions[formula]}</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBSA} className="w-full" size="lg">
                  Calculate BSA
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Body Surface Area</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>
                        {result.bsa} <span className="text-2xl">m²</span>
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-xs text-muted-foreground mt-1">Using {result.formulaName} formula</p>
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-1 mt-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          Hide Details <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Details <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Formula Used:</span>
                          <span className="font-medium">{result.formulaName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Calculation:</span>
                          <span className="font-mono text-xs">{result.formula}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Result:</span>
                          <span className="font-medium">{result.bsa} m²</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BSA Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Below Average</span>
                      <span className="text-sm text-blue-600">{"< 1.5 m²"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Average</span>
                      <span className="text-sm text-green-600">1.5 – 1.9 m²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Above Average</span>
                      <span className="text-sm text-yellow-600">1.9 – 2.2 m²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">High</span>
                      <span className="text-sm text-orange-600">≥ 2.2 m²</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BSA Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Mosteller (1987)</p>
                    <p className="font-mono text-xs">BSA = √[(H × W) / 3600]</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">DuBois & DuBois (1916)</p>
                    <p className="font-mono text-xs">BSA = 0.007184 × H^0.725 × W^0.425</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Haycock (1978)</p>
                    <p className="font-mono text-xs">BSA = 0.024265 × H^0.3964 × W^0.5378</p>
                  </div>
                  <p className="text-xs">H = Height (cm), W = Weight (kg)</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Body Surface Area (BSA)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Body Surface Area (BSA) is a measurement of the total surface area of the human body. It is an
                  important physiological parameter used extensively in medicine for calculating drug dosages,
                  especially for chemotherapy and other medications where precise dosing is critical. BSA provides a
                  more accurate measure of metabolic mass than body weight alone because it accounts for both height and
                  weight.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The average adult BSA is approximately 1.7 to 1.9 m² for women and 1.9 to 2.1 m² for men. However, BSA
                  can vary significantly based on body composition, with athletes and larger individuals typically
                  having higher BSA values. Understanding your BSA can be helpful for medical consultations and
                  understanding medication dosing.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Medical Applications of BSA</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  BSA is commonly used in clinical settings for several important applications:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Chemotherapy Dosing:</strong> Most chemotherapy drugs are dosed based on BSA to ensure
                    appropriate drug exposure while minimizing toxicity.
                  </li>
                  <li>
                    <strong>Cardiac Index Calculation:</strong> The cardiac index (CI) is calculated by dividing cardiac
                    output by BSA, providing a normalized measure of heart function.
                  </li>
                  <li>
                    <strong>Renal Function Assessment:</strong> Glomerular filtration rate (GFR) is often normalized to
                    BSA for accurate comparison across patients.
                  </li>
                  <li>
                    <strong>Burn Assessment:</strong> The extent of burn injuries is often described as a percentage of
                    total BSA to guide fluid resuscitation and treatment.
                  </li>
                  <li>
                    <strong>Nutritional Assessment:</strong> BSA can be used to estimate caloric requirements and
                    nutritional needs in clinical settings.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Medical Disclaimer</p>
                    <p>
                      BSA calculations are estimates and should be used for informational purposes only. Consult a
                      healthcare professional for accurate dosing or clinical decisions. Different formulas may yield
                      slightly different results, and the appropriate formula may vary based on patient population and
                      clinical context.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
