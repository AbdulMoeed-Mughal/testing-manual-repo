"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TreePine,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  DollarSign,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type CostBasis = "per-piece" | "per-length" | "per-volume"

interface LumberResult {
  volumePerPiece: number
  totalVolume: number
  totalVolumeWithWaste: number
  totalCost: number
  costPerUnit: number
  wasteAmount: number
}

const commonLumberSizes = [
  { label: '2×4 (1.5" × 3.5")', width: 1.5, thickness: 3.5 },
  { label: '2×6 (1.5" × 5.5")', width: 1.5, thickness: 5.5 },
  { label: '2×8 (1.5" × 7.25")', width: 1.5, thickness: 7.25 },
  { label: '2×10 (1.5" × 9.25")', width: 1.5, thickness: 9.25 },
  { label: '2×12 (1.5" × 11.25")', width: 1.5, thickness: 11.25 },
  { label: '4×4 (3.5" × 3.5")', width: 3.5, thickness: 3.5 },
  { label: '1×4 (0.75" × 3.5")', width: 0.75, thickness: 3.5 },
  { label: '1×6 (0.75" × 5.5")', width: 0.75, thickness: 5.5 },
]

export function LumberCostEstimator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("imperial")
  const [costBasis, setCostBasis] = useState<CostBasis>("per-piece")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [thickness, setThickness] = useState("")
  const [quantity, setQuantity] = useState("1")
  const [costPerUnit, setCostPerUnit] = useState("")
  const [waste, setWaste] = useState("10")
  const [lumberType, setLumberType] = useState("")
  const [result, setResult] = useState<LumberResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const thicknessNum = Number.parseFloat(thickness)
    const quantityNum = Number.parseInt(quantity)
    const costNum = Number.parseFloat(costPerUnit)
    const wasteNum = Number.parseFloat(waste) || 0

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }
    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }
    if (isNaN(thicknessNum) || thicknessNum <= 0) {
      setError("Please enter a valid thickness greater than 0")
      return
    }
    if (isNaN(quantityNum) || quantityNum < 1) {
      setError("Please enter a quantity of at least 1")
      return
    }
    if (isNaN(costNum) || costNum <= 0) {
      setError("Please enter a valid cost greater than 0")
      return
    }

    let lengthInFt: number
    let widthInIn: number
    let thicknessInIn: number

    if (unitSystem === "metric") {
      lengthInFt = lengthNum * 3.28084
      widthInIn = widthNum * 10 * 0.393701
      thicknessInIn = thicknessNum * 10 * 0.393701
    } else {
      lengthInFt = lengthNum
      widthInIn = widthNum
      thicknessInIn = thicknessNum
    }

    // Volume per piece in cubic feet
    const volumePerPiece = (widthInIn * thicknessInIn * lengthInFt * 12) / 1728

    // Total volume
    const totalVolume = volumePerPiece * quantityNum

    // Volume with waste
    const wasteFactor = 1 + wasteNum / 100
    const totalVolumeWithWaste = totalVolume * wasteFactor

    // Calculate cost based on cost basis
    let totalCost: number
    const quantityWithWaste = Math.ceil(quantityNum * wasteFactor)

    switch (costBasis) {
      case "per-piece":
        totalCost = costNum * quantityWithWaste
        break
      case "per-length":
        const totalLength = lengthNum * quantityWithWaste
        totalCost = costNum * totalLength
        break
      case "per-volume":
        totalCost = costNum * totalVolumeWithWaste
        break
      default:
        totalCost = costNum * quantityWithWaste
    }

    const wasteAmount = totalCost - totalCost / wasteFactor

    setResult({
      volumePerPiece,
      totalVolume,
      totalVolumeWithWaste,
      totalCost,
      costPerUnit: totalCost / quantityWithWaste,
      wasteAmount,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setThickness("")
    setQuantity("1")
    setCostPerUnit("")
    setWaste("10")
    setLumberType("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Lumber Cost Estimate: ${result.totalCost.toFixed(2)} for ${quantity} pieces (${result.totalVolumeWithWaste.toFixed(3)} ft³ with ${waste}% waste)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Lumber Cost Estimate",
          text: `Lumber Cost Estimate: $${result.totalCost.toFixed(2)} for ${quantity} pieces`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setThickness("")
    setResult(null)
    setError("")
  }

  const applyPreset = (preset: (typeof commonLumberSizes)[0]) => {
    if (unitSystem === "imperial") {
      setWidth(preset.width.toString())
      setThickness(preset.thickness.toString())
    } else {
      setWidth((preset.width * 2.54).toFixed(2))
      setThickness((preset.thickness * 2.54).toFixed(2))
    }
    setLumberType(preset.label)
  }

  const formatNumber = (num: number, decimals = 2) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <TreePine className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Lumber Cost Estimator</CardTitle>
                    <CardDescription>Estimate lumber costs by dimensions</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Common Lumber Sizes */}
                <div className="space-y-2">
                  <Label>Quick Select Lumber Size</Label>
                  <div className="flex flex-wrap gap-2">
                    {commonLumberSizes.slice(0, 6).map((preset) => (
                      <Button
                        key={preset.label}
                        variant="outline"
                        size="sm"
                        onClick={() => applyPreset(preset)}
                        className={`text-xs ${lumberType === preset.label ? "bg-amber-50 border-amber-300" : ""}`}
                      >
                        {preset.label.split(" ")[0]}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Dimensions */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder="8"
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="width">Width ({unitSystem === "metric" ? "cm" : "in"})</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder="1.5"
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="thickness">Thickness ({unitSystem === "metric" ? "cm" : "in"})</Label>
                    <Input
                      id="thickness"
                      type="number"
                      placeholder="3.5"
                      value={thickness}
                      onChange={(e) => setThickness(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Quantity */}
                <div className="space-y-2">
                  <Label htmlFor="quantity">Number of Pieces</Label>
                  <Input
                    id="quantity"
                    type="number"
                    placeholder="10"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Cost Basis */}
                <div className="space-y-2">
                  <Label>Cost Basis</Label>
                  <Select value={costBasis} onValueChange={(v) => setCostBasis(v as CostBasis)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="per-piece">Per Piece</SelectItem>
                      <SelectItem value="per-length">Per {unitSystem === "metric" ? "Meter" : "Foot"}</SelectItem>
                      <SelectItem value="per-volume">Per Cubic {unitSystem === "metric" ? "Meter" : "Foot"}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Cost Input */}
                <div className="space-y-2">
                  <Label htmlFor="cost">
                    Cost per{" "}
                    {costBasis === "per-piece"
                      ? "Piece"
                      : costBasis === "per-length"
                        ? unitSystem === "metric"
                          ? "Meter"
                          : "Foot"
                        : unitSystem === "metric"
                          ? "m³"
                          : "ft³"}{" "}
                    ($)
                  </Label>
                  <Input
                    id="cost"
                    type="number"
                    placeholder="5.00"
                    value={costPerUnit}
                    onChange={(e) => setCostPerUnit(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="waste">Waste Allowance (%)</Label>
                  <Input
                    id="waste"
                    type="number"
                    placeholder="10"
                    value={waste}
                    onChange={(e) => setWaste(e.target.value)}
                    min="0"
                    max="50"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">
                    Typical: 5-10% for straight cuts, 10-15% for complex projects
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Cost
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Estimated Cost</p>
                      <p className="text-5xl font-bold text-amber-600">${formatNumber(result.totalCost)}</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        {Math.ceil(Number.parseInt(quantity) * (1 + Number.parseFloat(waste) / 100))} pieces with{" "}
                        {waste}% waste
                      </p>
                    </div>

                    {/* Summary */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Volume per Piece</p>
                        <p className="font-semibold">{formatNumber(result.volumePerPiece, 4)} ft³</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Volume</p>
                        <p className="font-semibold">{formatNumber(result.totalVolume, 3)} ft³</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Volume + Waste</p>
                        <p className="font-semibold">{formatNumber(result.totalVolumeWithWaste, 3)} ft³</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Waste Cost</p>
                        <p className="font-semibold text-orange-600">${formatNumber(result.wasteAmount)}</p>
                      </div>
                    </div>

                    {/* Step-by-step */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full flex items-center justify-between p-2 text-sm font-medium text-amber-700 hover:bg-amber-100 rounded-lg transition-colors"
                    >
                      <span>Calculation Steps</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg border text-sm space-y-2">
                        <p>
                          <strong>1. Volume per piece:</strong> ({width}" × {thickness}" × {length}' × 12) ÷ 1728 ={" "}
                          {formatNumber(result.volumePerPiece, 4)} ft³
                        </p>
                        <p>
                          <strong>2. Base quantity:</strong> {quantity} pieces
                        </p>
                        <p>
                          <strong>3. Quantity with {waste}% waste:</strong> {quantity} ×{" "}
                          {(1 + Number.parseFloat(waste) / 100).toFixed(2)} ={" "}
                          {Math.ceil(Number.parseInt(quantity) * (1 + Number.parseFloat(waste) / 100))} pieces
                        </p>
                        <p>
                          <strong>4. Total volume:</strong> {formatNumber(result.volumePerPiece, 4)} ×{" "}
                          {Math.ceil(Number.parseInt(quantity) * (1 + Number.parseFloat(waste) / 100))} ={" "}
                          {formatNumber(result.totalVolumeWithWaste, 3)} ft³
                        </p>
                        <p>
                          <strong>5. Total cost:</strong> ${formatNumber(result.totalCost)}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Lumber Prices</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>2×4×8' (SPF)</span>
                      <span className="font-medium">$3 - $6</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>2×6×8' (SPF)</span>
                      <span className="font-medium">$5 - $9</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>2×4×8' (Treated)</span>
                      <span className="font-medium">$5 - $10</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>4×4×8' (Treated)</span>
                      <span className="font-medium">$12 - $20</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1×6×8' (Cedar)</span>
                      <span className="font-medium">$8 - $15</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">* Prices vary by region and market conditions</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Waste Allowance Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-green-50 border border-green-200 rounded">
                      <span className="text-green-700">Simple straight cuts</span>
                      <span className="font-medium text-green-700">5%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-yellow-50 border border-yellow-200 rounded">
                      <span className="text-yellow-700">Standard framing</span>
                      <span className="font-medium text-yellow-700">10%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-orange-50 border border-orange-200 rounded">
                      <span className="text-orange-700">Complex angles/joints</span>
                      <span className="font-medium text-orange-700">15%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-red-50 border border-red-200 rounded">
                      <span className="text-red-700">Decorative/trim work</span>
                      <span className="font-medium text-red-700">20%+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Lumber Sizing</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p className="mb-3">
                    Lumber is sold by nominal dimensions, but actual dimensions are smaller due to drying and planing.
                  </p>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span>Nominal 2×4</span>
                      <span className="font-medium text-foreground">1.5" × 3.5" actual</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Nominal 2×6</span>
                      <span className="font-medium text-foreground">1.5" × 5.5" actual</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Nominal 4×4</span>
                      <span className="font-medium text-foreground">3.5" × 3.5" actual</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Lumber Cost Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Estimating lumber costs accurately is essential for budgeting construction and woodworking projects.
                  This calculator helps you determine the total cost of lumber based on the dimensions, quantity, and
                  unit price of the material. Whether you're building a deck, framing a wall, or creating furniture,
                  understanding your lumber costs upfront helps prevent budget overruns.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The calculator accounts for waste allowance, which is crucial because cutting lumber inevitably
                  produces unusable pieces. By factoring in waste, you can purchase the right amount of material and
                  avoid multiple trips to the lumber yard.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Cost Calculation Methods</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Per Piece Pricing</h4>
                    <p className="text-muted-foreground text-sm">
                      Most common for standard lumber sizes at retail stores. Each piece has a fixed price regardless of
                      minor variations. Simply multiply the per-piece cost by the number of pieces needed.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Linear Foot Pricing</h4>
                    <p className="text-muted-foreground text-sm">
                      Common for trim, molding, and custom lengths. Price is based on the total length of lumber needed.
                      Calculate total linear feet and multiply by the per-foot cost.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Board Foot Pricing</h4>
                    <p className="text-muted-foreground text-sm">
                      Used for hardwoods and specialty lumber. One board foot equals 144 cubic inches (12" × 12" × 1").
                      This method accounts for the actual volume of wood being purchased.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TreePine className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Measure twice:</strong> Double-check all dimensions before calculating to avoid costly
                    mistakes.
                  </li>
                  <li>
                    <strong>Account for defects:</strong> Some boards may have knots, warping, or other defects that
                    make portions unusable.
                  </li>
                  <li>
                    <strong>Consider delivery costs:</strong> For large orders, factor in delivery fees which can add
                    significantly to total cost.
                  </li>
                  <li>
                    <strong>Buy in bulk:</strong> Many suppliers offer discounts for purchasing full bundles or large
                    quantities.
                  </li>
                  <li>
                    <strong>Check for alternatives:</strong> Different wood species or grades may offer cost savings
                    while meeting project requirements.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Results are estimates. Actual lumber requirements and costs may vary due to cutting waste,
                      defects, market prices, and local availability. Always verify prices with your lumber supplier and
                      add appropriate contingency for your specific project.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
