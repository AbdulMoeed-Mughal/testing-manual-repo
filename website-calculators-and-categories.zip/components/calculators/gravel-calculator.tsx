"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Mountain,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface GravelResult {
  area: number
  volume: number
  volumeWithWaste: number
  weight: number
  areaUnit: string
  volumeUnit: string
  weightUnit: string
}

export function GravelCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [depth, setDepth] = useState("")
  const [depthUnit, setDepthUnit] = useState<"m" | "cm" | "in">("cm")
  const [density, setDensity] = useState("1500")
  const [wastePercentage, setWastePercentage] = useState("5")
  const [result, setResult] = useState<GravelResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Common gravel densities (kg/m³)
  const gravelTypes = [
    { name: "Pea Gravel", density: 1680 },
    { name: "Crushed Stone", density: 1500 },
    { name: "River Rock", density: 1550 },
    { name: "Limestone", density: 1650 },
    { name: "Decomposed Granite", density: 1400 },
  ]

  const calculate = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const depthNum = Number.parseFloat(depth)
    const densityNum = Number.parseFloat(density)
    const wasteNum = Number.parseFloat(wastePercentage) || 0

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }
    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }
    if (isNaN(depthNum) || depthNum <= 0) {
      setError("Please enter a valid depth greater than 0")
      return
    }
    if (isNaN(densityNum) || densityNum <= 0) {
      setError("Please enter a valid density greater than 0")
      return
    }
    if (wasteNum < 0) {
      setError("Waste percentage cannot be negative")
      return
    }

    let lengthInMeters: number
    let widthInMeters: number
    let depthInMeters: number
    let densityInKgPerM3: number

    if (unitSystem === "metric") {
      lengthInMeters = lengthNum
      widthInMeters = widthNum
      densityInKgPerM3 = densityNum
    } else {
      lengthInMeters = lengthNum * 0.3048 // ft to m
      widthInMeters = widthNum * 0.3048
      densityInKgPerM3 = densityNum * 16.0185 // lb/ft³ to kg/m³
    }

    // Convert depth to meters
    if (depthUnit === "m") {
      depthInMeters = depthNum
    } else if (depthUnit === "cm") {
      depthInMeters = depthNum / 100
    } else {
      depthInMeters = depthNum * 0.0254 // inches to m
    }

    const areaM2 = lengthInMeters * widthInMeters
    const volumeM3 = areaM2 * depthInMeters
    const volumeWithWasteM3 = volumeM3 * (1 + wasteNum / 100)
    const weightKg = volumeWithWasteM3 * densityInKgPerM3

    if (unitSystem === "metric") {
      setResult({
        area: Math.round(areaM2 * 100) / 100,
        volume: Math.round(volumeM3 * 1000) / 1000,
        volumeWithWaste: Math.round(volumeWithWasteM3 * 1000) / 1000,
        weight: Math.round(weightKg),
        areaUnit: "m²",
        volumeUnit: "m³",
        weightUnit: "kg",
      })
    } else {
      const areaFt2 = areaM2 * 10.7639
      const volumeFt3 = volumeM3 * 35.3147
      const volumeWithWasteFt3 = volumeWithWasteM3 * 35.3147
      const weightLb = weightKg * 2.20462

      setResult({
        area: Math.round(areaFt2 * 100) / 100,
        volume: Math.round(volumeFt3 * 100) / 100,
        volumeWithWaste: Math.round(volumeWithWasteFt3 * 100) / 100,
        weight: Math.round(weightLb),
        areaUnit: "ft²",
        volumeUnit: "ft³",
        weightUnit: "lb",
      })
    }
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setDepth("")
    setDepthUnit("cm")
    setDensity("1500")
    setWastePercentage("5")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Gravel Calculation Results:
Area: ${result.area} ${result.areaUnit}
Volume: ${result.volume} ${result.volumeUnit}
Volume with Waste: ${result.volumeWithWaste} ${result.volumeUnit}
Weight: ${result.weight.toLocaleString()} ${result.weightUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Gravel Calculation Results",
          text: `I calculated my gravel needs using CalcHub! Volume: ${result.volumeWithWaste} ${result.volumeUnit}, Weight: ${result.weight.toLocaleString()} ${result.weightUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setDepth("")
    setDepthUnit(unitSystem === "metric" ? "in" : "cm")
    setDensity(unitSystem === "metric" ? "94" : "1500")
    setResult(null)
    setError("")
  }

  const selectGravelType = (densityValue: number) => {
    if (unitSystem === "metric") {
      setDensity(densityValue.toString())
    } else {
      // Convert kg/m³ to lb/ft³
      setDensity(Math.round(densityValue / 16.0185).toString())
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Mountain className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gravel Calculator</CardTitle>
                    <CardDescription>Calculate gravel volume and weight</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Width Input */}
                <div className="space-y-2">
                  <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="width"
                    type="number"
                    placeholder={`Enter width in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={width}
                    onChange={(e) => setWidth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Depth Input */}
                <div className="space-y-2">
                  <Label htmlFor="depth">Depth / Thickness</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-2">
                      <Input
                        id="depth"
                        type="number"
                        placeholder="Enter depth"
                        value={depth}
                        onChange={(e) => setDepth(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <Select value={depthUnit} onValueChange={(v) => setDepthUnit(v as "m" | "cm" | "in")}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {unitSystem === "metric" ? (
                          <>
                            <SelectItem value="m">m</SelectItem>
                            <SelectItem value="cm">cm</SelectItem>
                          </>
                        ) : (
                          <SelectItem value="in">inches</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Gravel Type Quick Select */}
                <div className="space-y-2">
                  <Label>Gravel Type (optional)</Label>
                  <div className="flex flex-wrap gap-2">
                    {gravelTypes.map((type) => (
                      <Button
                        key={type.name}
                        variant="outline"
                        size="sm"
                        onClick={() => selectGravelType(type.density)}
                        className="text-xs"
                      >
                        {type.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Density Input */}
                <div className="space-y-2">
                  <Label htmlFor="density">Gravel Density ({unitSystem === "metric" ? "kg/m³" : "lb/ft³"})</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder={`Enter density (default: ${unitSystem === "metric" ? "1500 kg/m³" : "94 lb/ft³"})`}
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="10"
                  />
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="waste">Waste Percentage (%)</Label>
                  <Input
                    id="waste"
                    type="number"
                    placeholder="Enter waste % (default: 5-10%)"
                    value={wastePercentage}
                    onChange={(e) => setWastePercentage(e.target.value)}
                    min="0"
                    max="50"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">Recommended: 5-10% for compaction and spillage</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Gravel
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Area Covered</p>
                        <p className="text-2xl font-bold text-amber-700">
                          {result.area.toLocaleString()} {result.areaUnit}
                        </p>
                      </div>
                      <div className="grid grid-cols-2 gap-4 pt-2 border-t border-amber-200">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Volume (with waste)</p>
                          <p className="text-xl font-bold text-amber-700">
                            {result.volumeWithWaste.toLocaleString()} {result.volumeUnit}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Base: {result.volume} {result.volumeUnit}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Weight</p>
                          <p className="text-xl font-bold text-amber-700">
                            {result.weight.toLocaleString()} {result.weightUnit}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            ≈{" "}
                            {unitSystem === "metric"
                              ? `${(result.weight / 1000).toFixed(2)} tonnes`
                              : `${(result.weight / 2000).toFixed(2)} tons`}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Step-by-step breakdown */}
                    <div className="mt-4 pt-4 border-t border-amber-200">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="flex items-center justify-between w-full text-sm font-medium text-amber-700"
                      >
                        <span>Calculation Breakdown</span>
                        {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                      {showSteps && (
                        <div className="mt-3 space-y-2 text-sm text-amber-800">
                          <p>
                            <strong>Step 1:</strong> Area = Length × Width = {length} × {width} = {result.area}{" "}
                            {result.areaUnit}
                          </p>
                          <p>
                            <strong>Step 2:</strong> Volume = Area × Depth = {result.volume} {result.volumeUnit}
                          </p>
                          <p>
                            <strong>Step 3:</strong> Volume with {wastePercentage}% waste = {result.volume} × (1 +{" "}
                            {wastePercentage}/100) = {result.volumeWithWaste} {result.volumeUnit}
                          </p>
                          <p>
                            <strong>Step 4:</strong> Weight = Volume × Density = {result.volumeWithWaste} × {density} ={" "}
                            {result.weight.toLocaleString()} {result.weightUnit}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gravel Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Volume = Length × Width × Depth</p>
                    <p className="font-semibold text-foreground mt-2">Weight = Volume × Density</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Gravel Densities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {gravelTypes.map((type) => (
                      <div
                        key={type.name}
                        className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border"
                      >
                        <span className="font-medium">{type.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {type.density} kg/m³ ({Math.round(type.density / 16.0185)} lb/ft³)
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recommended Depths</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Driveways</span>
                      <span className="text-muted-foreground">10-15 cm (4-6 in)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Pathways</span>
                      <span className="text-muted-foreground">5-10 cm (2-4 in)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Decorative Areas</span>
                      <span className="text-muted-foreground">5-7 cm (2-3 in)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Drainage Base</span>
                      <span className="text-muted-foreground">15-30 cm (6-12 in)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-amber-800">
                <p className="font-medium mb-1">Important Note</p>
                <p>
                  Results are estimates. Actual gravel requirements may vary due to compaction, site conditions, and
                  settling. Always order 5-10% extra to account for waste and ensure complete coverage.
                </p>
              </div>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Gravel?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gravel is a loose aggregation of small rock fragments that has been naturally or mechanically
                  produced. It is one of the most commonly used materials in construction and landscaping projects due
                  to its versatility, durability, and relatively low cost. Gravel comes in various sizes, colors, and
                  types, each suited for different applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Common uses of gravel include driveways, walkways, drainage systems, landscaping beds, and as a base
                  material for concrete and asphalt. The type of gravel you choose depends on your specific project
                  requirements, including load-bearing needs, drainage requirements, and aesthetic preferences.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Mountain className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Gravel</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Pea Gravel</h4>
                    <p className="text-sm text-muted-foreground">
                      Small, rounded stones ideal for walkways, patios, and decorative landscaping. Easy to walk on and
                      provides excellent drainage.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Crushed Stone</h4>
                    <p className="text-sm text-muted-foreground">
                      Angular pieces that compact well, making them ideal for driveways, road base, and construction
                      projects requiring stability.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">River Rock</h4>
                    <p className="text-sm text-muted-foreground">
                      Smooth, rounded stones in various colors. Popular for decorative landscaping, water features, and
                      dry creek beds.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Decomposed Granite</h4>
                    <p className="text-sm text-muted-foreground">
                      Granite that has weathered into small particles. Creates a natural-looking surface for paths and
                      patios.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="space-y-3 text-muted-foreground">
                  <li>
                    <strong>Account for compaction:</strong> Gravel can compact by 10-20% after installation, so
                    consider ordering extra material.
                  </li>
                  <li>
                    <strong>Consider the base:</strong> If installing over soft soil, you may need a deeper layer or a
                    fabric barrier.
                  </li>
                  <li>
                    <strong>Check delivery options:</strong> Gravel is typically sold by the cubic yard or ton. Know
                    your local supplier's pricing method.
                  </li>
                  <li>
                    <strong>Plan for edging:</strong> Edge restraints help keep gravel in place and maintain clean
                    borders.
                  </li>
                  <li>
                    <strong>Factor in irregular shapes:</strong> For non-rectangular areas, divide into smaller sections
                    and calculate each separately.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
