"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Flame,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Activity,
  Calculator,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type Formula = "mifflin" | "harris" | "katch"
type ActivityLevel = "sedentary" | "light" | "moderate" | "active" | "very-active"

interface RMRResult {
  rmr: number
  formula: string
  tdee: number | null
  activityMultiplier: number | null
}

const activityMultipliers: Record<ActivityLevel, { multiplier: number; label: string; description: string }> = {
  sedentary: { multiplier: 1.2, label: "Sedentary", description: "Little or no exercise" },
  light: { multiplier: 1.375, label: "Lightly Active", description: "Light exercise 1-3 days/week" },
  moderate: { multiplier: 1.55, label: "Moderately Active", description: "Moderate exercise 3-5 days/week" },
  active: { multiplier: 1.725, label: "Very Active", description: "Hard exercise 6-7 days/week" },
  "very-active": { multiplier: 1.9, label: "Extra Active", description: "Very hard exercise, physical job" },
}

export function RMRCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [formula, setFormula] = useState<Formula>("mifflin")
  const [bodyFat, setBodyFat] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel | "">("")
  const [result, setResult] = useState<RMRResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateRMR = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const weightNum = Number.parseFloat(weight)

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    let rmr: number
    let formulaName: string

    if (formula === "katch") {
      const bodyFatNum = Number.parseFloat(bodyFat)
      if (isNaN(bodyFatNum) || bodyFatNum < 0 || bodyFatNum > 100) {
        setError("Katch-McArdle formula requires a valid body fat percentage (0-100%)")
        return
      }
      const leanBodyMass = weightInKg * (1 - bodyFatNum / 100)
      rmr = 370 + 21.6 * leanBodyMass
      formulaName = "Katch-McArdle"
    } else if (formula === "harris") {
      if (gender === "male") {
        rmr = 66.47 + 13.75 * weightInKg + 5 * heightInCm - 6.76 * ageNum
      } else {
        rmr = 655.1 + 9.563 * weightInKg + 1.85 * heightInCm - 4.676 * ageNum
      }
      formulaName = "Harris-Benedict"
    } else {
      // Mifflin-St Jeor (default)
      if (gender === "male") {
        rmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
      } else {
        rmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
      }
      formulaName = "Mifflin-St Jeor"
    }

    const roundedRMR = Math.round(rmr)

    let tdee: number | null = null
    let activityMultiplier: number | null = null

    if (activityLevel) {
      activityMultiplier = activityMultipliers[activityLevel].multiplier
      tdee = Math.round(roundedRMR * activityMultiplier)
    }

    setResult({
      rmr: roundedRMR,
      formula: formulaName,
      tdee,
      activityMultiplier,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setBodyFat("")
    setActivityLevel("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.tdee
        ? `My RMR is ${result.rmr} calories/day and TDEE is ${result.tdee} calories/day (${result.formula})`
        : `My RMR is ${result.rmr} calories/day (${result.formula})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = result.tdee
          ? `I calculated my RMR using CalcHub! My RMR is ${result.rmr} calories/day and TDEE is ${result.tdee} calories/day`
          : `I calculated my RMR using CalcHub! My RMR is ${result.rmr} calories/day`
        await navigator.share({
          title: "My RMR Result",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">RMR Calculator</CardTitle>
                    <CardDescription>Calculate your Resting Metabolic Rate</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="Feet"
                        value={heightFeet}
                        onChange={(e) => setHeightFeet(e.target.value)}
                        min="0"
                      />
                      <Input
                        type="number"
                        placeholder="Inches"
                        value={heightInches}
                        onChange={(e) => setHeightInches(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                )}

                {/* Formula Selection */}
                <div className="space-y-2">
                  <Label>Formula</Label>
                  <Select value={formula} onValueChange={(value: Formula) => setFormula(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select formula" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mifflin">Mifflin-St Jeor (Recommended)</SelectItem>
                      <SelectItem value="harris">Harris-Benedict</SelectItem>
                      <SelectItem value="katch">Katch-McArdle (Requires Body Fat %)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Body Fat Input (for Katch-McArdle) */}
                {formula === "katch" && (
                  <div className="space-y-2">
                    <Label htmlFor="bodyFat">Body Fat Percentage (%)</Label>
                    <Input
                      id="bodyFat"
                      type="number"
                      placeholder="Enter body fat percentage"
                      value={bodyFat}
                      onChange={(e) => setBodyFat(e.target.value)}
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  </div>
                )}

                {/* Activity Level (Optional) */}
                <div className="space-y-2">
                  <Label>Activity Level (Optional - for TDEE)</Label>
                  <Select
                    value={activityLevel}
                    onValueChange={(value: ActivityLevel | "") => setActivityLevel(value as ActivityLevel)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary (Little or no exercise)</SelectItem>
                      <SelectItem value="light">Lightly Active (1-3 days/week)</SelectItem>
                      <SelectItem value="moderate">Moderately Active (3-5 days/week)</SelectItem>
                      <SelectItem value="active">Very Active (6-7 days/week)</SelectItem>
                      <SelectItem value="very-active">Extra Active (Physical job + exercise)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRMR} className="w-full" size="lg">
                  Calculate RMR
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Resting Metabolic Rate</p>
                      <p className="text-5xl font-bold text-orange-600 mb-1">{result.rmr.toLocaleString()}</p>
                      <p className="text-lg text-orange-600">calories/day</p>

                      {result.tdee && (
                        <div className="mt-4 pt-4 border-t border-orange-200">
                          <p className="text-sm text-muted-foreground mb-1">Total Daily Energy Expenditure (TDEE)</p>
                          <p className="text-3xl font-bold text-green-600">{result.tdee.toLocaleString()}</p>
                          <p className="text-sm text-green-600">calories/day</p>
                        </div>
                      )}
                    </div>

                    {/* Breakdown */}
                    <button
                      onClick={() => setShowBreakdown(!showBreakdown)}
                      className="flex items-center justify-center gap-1 w-full mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showBreakdown ? (
                        <>
                          Hide Details <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Details <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showBreakdown && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Formula Used:</span>
                          <span className="font-medium">{result.formula}</span>
                        </div>
                        {result.activityMultiplier && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Activity Multiplier:</span>
                            <span className="font-medium">×{result.activityMultiplier}</span>
                          </div>
                        )}
                        {result.tdee && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">TDEE Calculation:</span>
                            <span className="font-medium">
                              {result.rmr} × {result.activityMultiplier} = {result.tdee}
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">RMR Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Mifflin-St Jeor</p>
                    <p className="text-xs text-muted-foreground font-mono">Male: (10 × W) + (6.25 × H) − (5 × A) + 5</p>
                    <p className="text-xs text-muted-foreground font-mono">
                      Female: (10 × W) + (6.25 × H) − (5 × A) − 161
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Harris-Benedict</p>
                    <p className="text-xs text-muted-foreground font-mono">
                      Male: 66.47 + (13.75 × W) + (5 × H) − (6.76 × A)
                    </p>
                    <p className="text-xs text-muted-foreground font-mono">
                      Female: 655.1 + (9.563 × W) + (1.85 × H) − (4.676 × A)
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Katch-McArdle</p>
                    <p className="text-xs text-muted-foreground font-mono">RMR = 370 + (21.6 × LBM)</p>
                    <p className="text-xs text-muted-foreground mt-1">Requires body fat percentage</p>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    W = Weight (kg), H = Height (cm), A = Age (years), LBM = Lean Body Mass (kg)
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Activity Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {Object.entries(activityMultipliers).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <div>
                          <span className="font-medium">{value.label}</span>
                          <p className="text-xs text-muted-foreground">{value.description}</p>
                        </div>
                        <span className="font-mono text-sm">×{value.multiplier}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Resting Metabolic Rate (RMR)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Resting Metabolic Rate (RMR) represents the number of calories your body burns while at complete rest
                  to maintain vital functions such as breathing, circulation, cell production, and nutrient processing.
                  It accounts for approximately 60-75% of your total daily energy expenditure, making it the largest
                  component of your metabolism.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Unlike Basal Metabolic Rate (BMR), which is measured under strict conditions after fasting and
                  sleeping, RMR is measured under less restrictive conditions and is slightly higher. For practical
                  purposes, the terms are often used interchangeably since the difference is typically only 10-20%.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>RMR vs BMR vs TDEE</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">BMR</h4>
                    <p className="text-blue-700 text-sm">
                      Basal Metabolic Rate - measured in a completely rested state after 8 hours of sleep and 12 hours
                      of fasting.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">RMR</h4>
                    <p className="text-orange-700 text-sm">
                      Resting Metabolic Rate - similar to BMR but measured under less strict conditions, typically 3-4
                      hours after eating.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">TDEE</h4>
                    <p className="text-green-700 text-sm">
                      Total Daily Energy Expenditure - your RMR multiplied by an activity factor to account for daily
                      movement and exercise.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting RMR</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Muscle Mass:</strong> More muscle tissue requires more energy to maintain, increasing RMR.
                  </li>
                  <li>
                    <strong>Age:</strong> RMR typically decreases with age, partly due to loss of muscle mass.
                  </li>
                  <li>
                    <strong>Gender:</strong> Men generally have higher RMR due to greater muscle mass and less body fat.
                  </li>
                  <li>
                    <strong>Body Size:</strong> Larger bodies require more energy to maintain basic functions.
                  </li>
                  <li>
                    <strong>Hormones:</strong> Thyroid hormones significantly affect metabolic rate.
                  </li>
                  <li>
                    <strong>Temperature:</strong> Cold environments can increase RMR as the body works to maintain
                    temperature.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm">
                  RMR calculations are estimates based on standard formulas and may vary depending on individual
                  metabolism, health factors, and body composition. These values should be used as a starting point and
                  adjusted based on real-world results. For personalized nutrition and fitness advice, consult with a
                  healthcare provider or registered dietitian.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
