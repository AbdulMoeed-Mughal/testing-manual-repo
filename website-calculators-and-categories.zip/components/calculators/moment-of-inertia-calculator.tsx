"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Cog, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type MassUnit = "kg" | "g" | "lb"
type LengthUnit = "m" | "cm" | "mm" | "ft" | "in"
type InertiaUnit = "kg·m²" | "g·cm²" | "lb·ft²"
type ShapeType =
  | "solid-cylinder"
  | "hollow-cylinder"
  | "solid-sphere"
  | "hollow-sphere"
  | "thin-rod-center"
  | "thin-rod-end"
  | "rectangular-plate"
  | "thin-disk"
  | "thin-ring"
  | "point-mass"

interface InertiaResult {
  value: number
  category: string
  color: string
  bgColor: string
  formula: string
}

const shapeFormulas: Record<ShapeType, { name: string; formula: string; description: string }> = {
  "solid-cylinder": {
    name: "Solid Cylinder (axis through center)",
    formula: "I = ½mr²",
    description: "Axis along cylinder height",
  },
  "hollow-cylinder": {
    name: "Hollow Cylinder (thin-walled)",
    formula: "I = mr²",
    description: "Axis along cylinder height",
  },
  "solid-sphere": { name: "Solid Sphere", formula: "I = ⅖mr²", description: "Axis through center" },
  "hollow-sphere": { name: "Hollow Sphere (thin shell)", formula: "I = ⅔mr²", description: "Axis through center" },
  "thin-rod-center": {
    name: "Thin Rod (axis at center)",
    formula: "I = (1/12)mL²",
    description: "Axis perpendicular to rod",
  },
  "thin-rod-end": { name: "Thin Rod (axis at end)", formula: "I = ⅓mL²", description: "Axis perpendicular to rod" },
  "rectangular-plate": {
    name: "Rectangular Plate",
    formula: "I = (1/12)m(a² + b²)",
    description: "Axis through center",
  },
  "thin-disk": { name: "Thin Disk", formula: "I = ½mr²", description: "Axis perpendicular through center" },
  "thin-ring": { name: "Thin Ring (hoop)", formula: "I = mr²", description: "Axis perpendicular through center" },
  "point-mass": { name: "Point Mass", formula: "I = mr²", description: "At distance r from axis" },
}

export function MomentOfInertiaCalculator() {
  const [shape, setShape] = useState<ShapeType>("solid-cylinder")
  const [mass, setMass] = useState("")
  const [massUnit, setMassUnit] = useState<MassUnit>("kg")
  const [radius, setRadius] = useState("")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [lengthUnit, setLengthUnit] = useState<LengthUnit>("m")
  const [inertiaUnit, setInertiaUnit] = useState<InertiaUnit>("kg·m²")
  const [result, setResult] = useState<InertiaResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const convertMassToKg = (value: number, unit: MassUnit): number => {
    switch (unit) {
      case "kg":
        return value
      case "g":
        return value / 1000
      case "lb":
        return value * 0.453592
    }
  }

  const convertLengthToM = (value: number, unit: LengthUnit): number => {
    switch (unit) {
      case "m":
        return value
      case "cm":
        return value / 100
      case "mm":
        return value / 1000
      case "ft":
        return value * 0.3048
      case "in":
        return value * 0.0254
    }
  }

  const convertInertiaFromKgM2 = (value: number, unit: InertiaUnit): number => {
    switch (unit) {
      case "kg·m²":
        return value
      case "g·cm²":
        return value * 10000000
      case "lb·ft²":
        return value * 23.7304
    }
  }

  const calculateInertia = () => {
    setError("")
    setResult(null)

    const massNum = Number.parseFloat(mass)
    if (isNaN(massNum) || massNum <= 0) {
      setError("Please enter a valid mass greater than 0")
      return
    }

    const massKg = convertMassToKg(massNum, massUnit)

    let inertiaKgM2: number
    let formula: string

    // Shapes requiring radius
    if (
      [
        "solid-cylinder",
        "hollow-cylinder",
        "solid-sphere",
        "hollow-sphere",
        "thin-disk",
        "thin-ring",
        "point-mass",
      ].includes(shape)
    ) {
      const radiusNum = Number.parseFloat(radius)
      if (isNaN(radiusNum) || radiusNum <= 0) {
        setError("Please enter a valid radius greater than 0")
        return
      }
      const radiusM = convertLengthToM(radiusNum, lengthUnit)

      switch (shape) {
        case "solid-cylinder":
        case "thin-disk":
          inertiaKgM2 = 0.5 * massKg * radiusM * radiusM
          formula = `I = ½ × ${massKg.toFixed(4)} × ${radiusM.toFixed(4)}²`
          break
        case "hollow-cylinder":
        case "thin-ring":
        case "point-mass":
          inertiaKgM2 = massKg * radiusM * radiusM
          formula = `I = ${massKg.toFixed(4)} × ${radiusM.toFixed(4)}²`
          break
        case "solid-sphere":
          inertiaKgM2 = 0.4 * massKg * radiusM * radiusM
          formula = `I = ⅖ × ${massKg.toFixed(4)} × ${radiusM.toFixed(4)}²`
          break
        case "hollow-sphere":
          inertiaKgM2 = (2 / 3) * massKg * radiusM * radiusM
          formula = `I = ⅔ × ${massKg.toFixed(4)} × ${radiusM.toFixed(4)}²`
          break
        default:
          inertiaKgM2 = 0
          formula = ""
      }
    }
    // Shapes requiring length
    else if (["thin-rod-center", "thin-rod-end"].includes(shape)) {
      const lengthNum = Number.parseFloat(length)
      if (isNaN(lengthNum) || lengthNum <= 0) {
        setError("Please enter a valid length greater than 0")
        return
      }
      const lengthM = convertLengthToM(lengthNum, lengthUnit)

      if (shape === "thin-rod-center") {
        inertiaKgM2 = (1 / 12) * massKg * lengthM * lengthM
        formula = `I = (1/12) × ${massKg.toFixed(4)} × ${lengthM.toFixed(4)}²`
      } else {
        inertiaKgM2 = (1 / 3) * massKg * lengthM * lengthM
        formula = `I = ⅓ × ${massKg.toFixed(4)} × ${lengthM.toFixed(4)}²`
      }
    }
    // Rectangular plate
    else if (shape === "rectangular-plate") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)
      if (isNaN(lengthNum) || lengthNum <= 0) {
        setError("Please enter a valid length greater than 0")
        return
      }
      if (isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter a valid width greater than 0")
        return
      }
      const lengthM = convertLengthToM(lengthNum, lengthUnit)
      const widthM = convertLengthToM(widthNum, lengthUnit)

      inertiaKgM2 = (1 / 12) * massKg * (lengthM * lengthM + widthM * widthM)
      formula = `I = (1/12) × ${massKg.toFixed(4)} × (${lengthM.toFixed(4)}² + ${widthM.toFixed(4)}²)`
    } else {
      inertiaKgM2 = 0
      formula = ""
    }

    const inertiaConverted = convertInertiaFromKgM2(inertiaKgM2, inertiaUnit)

    let category: string
    let color: string
    let bgColor: string

    // Categorize based on magnitude (using kg·m²)
    if (inertiaKgM2 < 0.01) {
      category = "Very Low"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (inertiaKgM2 < 1) {
      category = "Low"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (inertiaKgM2 < 100) {
      category = "Moderate"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "High"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({ value: inertiaConverted, category, color, bgColor, formula })
  }

  const handleReset = () => {
    setMass("")
    setRadius("")
    setLength("")
    setWidth("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Moment of Inertia: ${result.value.toExponential(4)} ${inertiaUnit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Moment of Inertia Result",
          text: `I calculated moment of inertia using CalcHub! Result: ${result.value.toExponential(4)} ${inertiaUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const needsRadius = [
    "solid-cylinder",
    "hollow-cylinder",
    "solid-sphere",
    "hollow-sphere",
    "thin-disk",
    "thin-ring",
    "point-mass",
  ].includes(shape)
  const needsLength = ["thin-rod-center", "thin-rod-end", "rectangular-plate"].includes(shape)
  const needsWidth = shape === "rectangular-plate"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Cog className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Moment of Inertia Calculator</CardTitle>
                    <CardDescription>Calculate rotational inertia for various shapes</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Shape Selection */}
                <div className="space-y-2">
                  <Label htmlFor="shape">Shape</Label>
                  <Select
                    value={shape}
                    onValueChange={(value: ShapeType) => {
                      setShape(value)
                      setResult(null)
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select shape" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(shapeFormulas).map(([key, { name }]) => (
                        <SelectItem key={key} value={key}>
                          {name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">{shapeFormulas[shape].description}</p>
                </div>

                {/* Mass Input */}
                <div className="space-y-2">
                  <Label htmlFor="mass">Mass</Label>
                  <div className="flex gap-2">
                    <Input
                      id="mass"
                      type="number"
                      placeholder="Enter mass"
                      value={mass}
                      onChange={(e) => setMass(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={massUnit} onValueChange={(value: MassUnit) => setMassUnit(value)}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="kg">kg</SelectItem>
                        <SelectItem value="g">g</SelectItem>
                        <SelectItem value="lb">lb</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Radius Input (conditional) */}
                {needsRadius && (
                  <div className="space-y-2">
                    <Label htmlFor="radius">Radius</Label>
                    <div className="flex gap-2">
                      <Input
                        id="radius"
                        type="number"
                        placeholder="Enter radius"
                        value={radius}
                        onChange={(e) => setRadius(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={lengthUnit} onValueChange={(value: LengthUnit) => setLengthUnit(value)}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="m">m</SelectItem>
                          <SelectItem value="cm">cm</SelectItem>
                          <SelectItem value="mm">mm</SelectItem>
                          <SelectItem value="ft">ft</SelectItem>
                          <SelectItem value="in">in</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Length Input (conditional) */}
                {needsLength && (
                  <div className="space-y-2">
                    <Label htmlFor="length">Length {needsWidth ? "(a)" : "(L)"}</Label>
                    <div className="flex gap-2">
                      <Input
                        id="length"
                        type="number"
                        placeholder="Enter length"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={lengthUnit} onValueChange={(value: LengthUnit) => setLengthUnit(value)}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="m">m</SelectItem>
                          <SelectItem value="cm">cm</SelectItem>
                          <SelectItem value="mm">mm</SelectItem>
                          <SelectItem value="ft">ft</SelectItem>
                          <SelectItem value="in">in</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Width Input (conditional) */}
                {needsWidth && (
                  <div className="space-y-2">
                    <Label htmlFor="width">Width (b)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="width"
                        type="number"
                        placeholder="Enter width"
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={lengthUnit} onValueChange={(value: LengthUnit) => setLengthUnit(value)}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="m">m</SelectItem>
                          <SelectItem value="cm">cm</SelectItem>
                          <SelectItem value="mm">mm</SelectItem>
                          <SelectItem value="ft">ft</SelectItem>
                          <SelectItem value="in">in</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="inertiaUnit">Output Unit</Label>
                  <Select value={inertiaUnit} onValueChange={(value: InertiaUnit) => setInertiaUnit(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg·m²">kg·m²</SelectItem>
                      <SelectItem value="g·cm²">g·cm²</SelectItem>
                      <SelectItem value="lb·ft²">lb·ft²</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateInertia} className="w-full" size="lg">
                  Calculate Moment of Inertia
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Moment of Inertia (I)</p>
                      <p className={`text-3xl font-bold ${result.color} mb-2`}>
                        {result.value.toExponential(4)} {inertiaUnit}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category} Inertia</p>
                    </div>

                    {/* Step-by-step toggle */}
                    <div className="mt-4">
                      <Button variant="outline" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full">
                        {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                      </Button>
                      {showSteps && (
                        <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                          <p>
                            <strong>Formula:</strong> {shapeFormulas[shape].formula}
                          </p>
                          <p>
                            <strong>Calculation:</strong> {result.formula}
                          </p>
                          <p>
                            <strong>Result:</strong> I = {result.value.toExponential(4)} {inertiaUnit}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Solid Cylinder</span>
                      <span className="text-purple-600 font-mono">I = ½mr²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Solid Sphere</span>
                      <span className="text-blue-600 font-mono">I = ⅖mr²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Thin Rod (center)</span>
                      <span className="text-green-600 font-mono">I = (1/12)mL²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Point Mass</span>
                      <span className="text-yellow-600 font-mono">I = mr²</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Parallel Axis Theorem</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">I = I_cm + md²</p>
                  </div>
                  <p>
                    Where <strong>I_cm</strong> is the moment of inertia about the center of mass, <strong>m</strong> is
                    the mass, and <strong>d</strong> is the perpendicular distance between axes.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Moment of Inertia */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Moment of Inertia?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Moment of inertia, also known as rotational inertia or angular mass, is a quantity that determines the
                  amount of torque needed for a desired angular acceleration about a rotational axis. It is the
                  rotational analog of mass in linear motion. Just as mass resists linear acceleration, moment of
                  inertia resists angular acceleration.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The moment of inertia depends not only on the mass of an object but also on how that mass is
                  distributed relative to the axis of rotation. Objects with more mass concentrated farther from the
                  axis have larger moments of inertia. This is why figure skaters spin faster when they pull their arms
                  in - they're reducing their moment of inertia.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Moment of inertia calculations are based on idealized formulas assuming uniform density and perfect
                  geometric shapes. Actual values may vary due to non-uniform mass distribution, shape imperfections,
                  and axis placement. Consult engineering references and perform physical testing for precise analysis
                  in critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
