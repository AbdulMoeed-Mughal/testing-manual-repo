"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, BriefcaseIcon, Info, Calendar, Clock } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface RetirementResult {
  daysRemaining: number
  retirementDate: string
  years: number
  months: number
  days: number
  isToday: boolean
}

export function DaysUntilRetirementCalculator() {
  const [birthDate, setBirthDate] = useState("")
  const [retirementAge, setRetirementAge] = useState("65")
  const [includeToday, setIncludeToday] = useState(true)
  const [result, setResult] = useState<RetirementResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateRetirement = () => {
    setError("")
    setResult(null)

    if (!birthDate) {
      setError("Please select your date of birth")
      return
    }

    const retirementAgeNum = Number.parseInt(retirementAge)
    if (isNaN(retirementAgeNum) || retirementAgeNum <= 0 || retirementAgeNum > 120) {
      setError("Please enter a valid retirement age (1-120)")
      return
    }

    const birth = new Date(birthDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (birth >= today) {
      setError("Date of birth must be in the past")
      return
    }

    // Calculate retirement date
    const retirement = new Date(birth)
    retirement.setFullYear(retirement.getFullYear() + retirementAgeNum)

    // Calculate days remaining
    let daysRemaining = Math.floor((retirement.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    
    if (!includeToday) {
      daysRemaining += 1
    }

    const isToday = daysRemaining === 0

    if (daysRemaining < 0) {
      setError("You have already reached retirement age")
      return
    }

    // Calculate breakdown
    const years = Math.floor(daysRemaining / 365)
    const remainingDays = daysRemaining % 365
    const months = Math.floor(remainingDays / 30)
    const days = remainingDays % 30

    setResult({
      daysRemaining,
      retirementDate: retirement.toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      years,
      months,
      days,
      isToday,
    })
  }

  const handleReset = () => {
    setBirthDate("")
    setRetirementAge("65")
    setIncludeToday(true)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `${result.daysRemaining} days until retirement on ${result.retirementDate}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Days Until Retirement",
          text: `I have ${result.daysRemaining} days until retirement on ${result.retirementDate}!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <BriefcaseIcon className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Days Until Retirement</CardTitle>
                    <CardDescription>Calculate days remaining until retirement</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Birth Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="birthDate">Date of Birth</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                {/* Retirement Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="retirementAge">Retirement Age (years)</Label>
                  <Input
                    id="retirementAge"
                    type="number"
                    placeholder="Enter retirement age"
                    value={retirementAge}
                    onChange={(e) => setRetirementAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Include Today Checkbox */}
                <div className="flex items-center space-x-2">
                  <Checkbox id="includeToday" checked={includeToday} onCheckedChange={(checked) => setIncludeToday(checked === true)} />
                  <Label htmlFor="includeToday" className="text-sm font-normal cursor-pointer">
                    Include current day in calculation
                  </Label>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRetirement} className="w-full" size="lg">
                  Calculate Days
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.isToday ? "bg-cyan-50 border-cyan-200" : "bg-cyan-50 border-cyan-200"} transition-all duration-300`}>
                    <div className="text-center">
                      {result.isToday ? (
                        <>
                          <p className="text-2xl font-bold text-cyan-600 mb-2">🎉 Today is your retirement day!</p>
                          <p className="text-sm text-muted-foreground">Congratulations on reaching retirement!</p>
                        </>
                      ) : (
                        <>
                          <p className="text-sm text-muted-foreground mb-1">Days Until Retirement</p>
                          <p className="text-5xl font-bold text-cyan-600 mb-2">{result.daysRemaining.toLocaleString()}</p>
                          <p className="text-sm text-muted-foreground mb-3">
                            {result.years} years, {result.months} months, {result.days} days
                          </p>
                          <div className="p-3 bg-white rounded-lg">
                            <p className="text-sm text-muted-foreground">Retirement Date</p>
                            <p className="text-base font-semibold text-cyan-600">{result.retirementDate}</p>
                          </div>
                        </>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Retirement Ages</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Early Retirement</span>
                      <span className="text-sm text-muted-foreground">55-59 years</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Standard Retirement (US)</span>
                      <span className="text-sm text-muted-foreground">65-67 years</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Late Retirement</span>
                      <span className="text-sm text-muted-foreground">70+ years</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    The calculator determines your retirement date by adding the retirement age (in years) to your date of birth.
                  </p>
                  <div className="p-4 bg-muted rounded-lg font-mono text-xs">
                    <p className="font-semibold text-foreground">Retirement Date = Birth Date + Retirement Age</p>
                    <p className="mt-2 font-semibold text-foreground">Days = Retirement Date − Current Date</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Retirement Planning */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Retirement Planning?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Retirement planning is the process of determining retirement income goals and the actions and decisions necessary to achieve those goals. It involves identifying sources of income, estimating expenses, implementing a savings program, and managing assets and risk. Knowing how many days remain until retirement can help you stay motivated and track your progress toward financial goals.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The retirement age varies by country, profession, and individual circumstances. In the United States, the full retirement age for Social Security benefits ranges from 65 to 67, depending on your birth year. However, many people choose to retire earlier or later based on their financial situation, health, and personal preferences.
                </p>
              </CardContent>
            </Card>

            {/* Why Calculate Days Until Retirement */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Why Calculate Days Until Retirement?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating the exact number of days until retirement serves multiple purposes in your financial and personal planning. First, it provides a concrete timeline that can help you set and achieve specific savings goals. Knowing you have X number of days allows you to calculate exactly how much you need to save per day, week, or month to reach your retirement savings target.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Second, this countdown can serve as a powerful motivator. Watching the number decrease can encourage you to stay committed to your retirement savings plan and make smart financial decisions. It can also help you visualize the reality of retirement, making it feel more tangible and encouraging you to prepare adequately for this major life transition.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What is the standard retirement age?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The standard retirement age varies by country. In the US, it's typically 65-67 years for full Social Security benefits. However, you can retire earlier (with reduced benefits) or later (with increased benefits).
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Can I retire early?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Yes, early retirement is possible if you have sufficient savings and income sources. Some people retire in their 50s or even earlier through careful financial planning and aggressive saving strategies.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How accurate is this calculator?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      This calculator provides an accurate day count based on your inputs. However, actual retirement dates may vary based on personal circumstances, financial readiness, and individual retirement plans.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground">
                  <strong>Disclaimer:</strong> Retirement countdown is based on the entered date of birth and retirement age. Results may vary due to calendar differences and time zones. This calculator is for planning purposes only and does not constitute financial advice.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
