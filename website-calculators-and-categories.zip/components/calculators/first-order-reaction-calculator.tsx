"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Activity,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type CalculationMode = "concentration" | "time" | "rateConstant" | "halfLife"
type ConcentrationUnit = "M" | "mM" | "μM" | "mol/L"
type TimeUnit = "s" | "min" | "hr" | "days"

interface FirstOrderResult {
  calculatedValue: number
  unit: string
  halfLife: number
  halfLifeUnit: string
  rateConstant: number
  rateConstantUnit: string
}

export function FirstOrderReactionCalculator() {
  const [mode, setMode] = useState<CalculationMode>("concentration")
  const [initialConcentration, setInitialConcentration] = useState("")
  const [finalConcentration, setFinalConcentration] = useState("")
  const [time, setTime] = useState("")
  const [rateConstant, setRateConstant] = useState("")
  const [concentrationUnit, setConcentrationUnit] = useState<ConcentrationUnit>("M")
  const [timeUnit, setTimeUnit] = useState<TimeUnit>("s")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<FirstOrderResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const timeUnitLabels: Record<TimeUnit, string> = {
    s: "seconds",
    min: "minutes",
    hr: "hours",
    days: "days",
  }

  const concentrationUnitLabels: Record<ConcentrationUnit, string> = {
    M: "Molar (M)",
    mM: "Millimolar (mM)",
    μM: "Micromolar (μM)",
    "mol/L": "mol/L",
  }

  const modeLabels: Record<CalculationMode, string> = {
    concentration: "Final Concentration",
    time: "Time Elapsed",
    rateConstant: "Rate Constant (k)",
    halfLife: "Half-Life",
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const A0 = Number.parseFloat(initialConcentration)
    const A = Number.parseFloat(finalConcentration)
    const t = Number.parseFloat(time)
    const k = Number.parseFloat(rateConstant)

    // Validation based on mode
    if (mode === "concentration") {
      // Calculate final concentration: [A] = [A]₀ × e^(-kt)
      if (isNaN(A0) || A0 <= 0) {
        setError("Please enter a valid initial concentration greater than 0")
        return
      }
      if (isNaN(k) || k <= 0) {
        setError("Please enter a valid rate constant greater than 0")
        return
      }
      if (isNaN(t) || t < 0) {
        setError("Please enter a valid time (0 or greater)")
        return
      }

      const calculatedA = A0 * Math.exp(-k * t)
      const halfLife = Math.LN2 / k

      setResult({
        calculatedValue: calculatedA,
        unit: concentrationUnit,
        halfLife,
        halfLifeUnit: timeUnit,
        rateConstant: k,
        rateConstantUnit: `${timeUnit}⁻¹`,
      })
    } else if (mode === "time") {
      // Calculate time: t = ln([A]₀ / [A]) / k
      if (isNaN(A0) || A0 <= 0) {
        setError("Please enter a valid initial concentration greater than 0")
        return
      }
      if (isNaN(A) || A <= 0) {
        setError("Please enter a valid final concentration greater than 0")
        return
      }
      if (A >= A0) {
        setError("Final concentration must be less than initial concentration")
        return
      }
      if (isNaN(k) || k <= 0) {
        setError("Please enter a valid rate constant greater than 0")
        return
      }

      const calculatedTime = Math.log(A0 / A) / k
      const halfLife = Math.LN2 / k

      setResult({
        calculatedValue: calculatedTime,
        unit: timeUnit,
        halfLife,
        halfLifeUnit: timeUnit,
        rateConstant: k,
        rateConstantUnit: `${timeUnit}⁻¹`,
      })
    } else if (mode === "rateConstant") {
      // Calculate rate constant: k = ln([A]₀ / [A]) / t
      if (isNaN(A0) || A0 <= 0) {
        setError("Please enter a valid initial concentration greater than 0")
        return
      }
      if (isNaN(A) || A <= 0) {
        setError("Please enter a valid final concentration greater than 0")
        return
      }
      if (A >= A0) {
        setError("Final concentration must be less than initial concentration")
        return
      }
      if (isNaN(t) || t <= 0) {
        setError("Please enter a valid time greater than 0")
        return
      }

      const calculatedK = Math.log(A0 / A) / t
      const halfLife = Math.LN2 / calculatedK

      setResult({
        calculatedValue: calculatedK,
        unit: `${timeUnit}⁻¹`,
        halfLife,
        halfLifeUnit: timeUnit,
        rateConstant: calculatedK,
        rateConstantUnit: `${timeUnit}⁻¹`,
      })
    } else if (mode === "halfLife") {
      // Calculate half-life: t₁/₂ = 0.693 / k
      if (isNaN(k) || k <= 0) {
        setError("Please enter a valid rate constant greater than 0")
        return
      }

      const halfLife = Math.LN2 / k

      setResult({
        calculatedValue: halfLife,
        unit: timeUnit,
        halfLife,
        halfLifeUnit: timeUnit,
        rateConstant: k,
        rateConstantUnit: `${timeUnit}⁻¹`,
      })
    }
  }

  const handleReset = () => {
    setInitialConcentration("")
    setFinalConcentration("")
    setTime("")
    setRateConstant("")
    setShowSteps(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `First-Order Reaction Result:
Mode: ${modeLabels[mode]}
${mode !== "halfLife" ? `Initial Concentration: ${initialConcentration} ${concentrationUnit}` : ""}
${mode === "time" || mode === "rateConstant" ? `Final Concentration: ${finalConcentration} ${concentrationUnit}` : ""}
${mode === "concentration" || mode === "rateConstant" ? `Time: ${time} ${timeUnit}` : ""}
${mode !== "rateConstant" && mode !== "halfLife" ? `Rate Constant: ${rateConstant} ${timeUnit}⁻¹` : ""}
Result: ${formatNumber(result.calculatedValue)} ${result.unit}
Half-Life: ${formatNumber(result.halfLife)} ${result.halfLifeUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "First-Order Reaction Calculator Result",
          text: `${modeLabels[mode]}: ${formatNumber(result.calculatedValue)} ${result.unit} | Half-Life: ${formatNumber(result.halfLife)} ${result.halfLifeUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number, decimals = 6): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.000001 || Math.abs(num) >= 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: decimals })
  }

  const getStepByStepCalculation = () => {
    if (!result) return []
    const steps: string[] = []

    if (mode === "concentration") {
      steps.push("Integrated Rate Law for First-Order Reactions:")
      steps.push("ln([A]₀/[A]) = k × t")
      steps.push("Or equivalently: [A] = [A]₀ × e^(-k×t)")
      steps.push("")
      steps.push(`Given: [A]₀ = ${initialConcentration} ${concentrationUnit}`)
      steps.push(`Given: k = ${rateConstant} ${timeUnit}⁻¹`)
      steps.push(`Given: t = ${time} ${timeUnit}`)
      steps.push("")
      steps.push(`[A] = ${initialConcentration} × e^(-${rateConstant} × ${time})`)
      steps.push(`[A] = ${initialConcentration} × e^(-${formatNumber(Number.parseFloat(rateConstant) * Number.parseFloat(time), 4)})`)
      steps.push(`[A] = ${initialConcentration} × ${formatNumber(Math.exp(-Number.parseFloat(rateConstant) * Number.parseFloat(time)), 6)}`)
      steps.push(`[A] = ${formatNumber(result.calculatedValue)} ${concentrationUnit}`)
    } else if (mode === "time") {
      steps.push("Rearranging the integrated rate law for time:")
      steps.push("t = ln([A]₀/[A]) / k")
      steps.push("")
      steps.push(`Given: [A]₀ = ${initialConcentration} ${concentrationUnit}`)
      steps.push(`Given: [A] = ${finalConcentration} ${concentrationUnit}`)
      steps.push(`Given: k = ${rateConstant} ${timeUnit}⁻¹`)
      steps.push("")
      steps.push(`t = ln(${initialConcentration}/${finalConcentration}) / ${rateConstant}`)
      steps.push(`t = ln(${formatNumber(Number.parseFloat(initialConcentration) / Number.parseFloat(finalConcentration), 4)}) / ${rateConstant}`)
      steps.push(`t = ${formatNumber(Math.log(Number.parseFloat(initialConcentration) / Number.parseFloat(finalConcentration)), 4)} / ${rateConstant}`)
      steps.push(`t = ${formatNumber(result.calculatedValue)} ${timeUnit}`)
    } else if (mode === "rateConstant") {
      steps.push("Rearranging the integrated rate law for k:")
      steps.push("k = ln([A]₀/[A]) / t")
      steps.push("")
      steps.push(`Given: [A]₀ = ${initialConcentration} ${concentrationUnit}`)
      steps.push(`Given: [A] = ${finalConcentration} ${concentrationUnit}`)
      steps.push(`Given: t = ${time} ${timeUnit}`)
      steps.push("")
      steps.push(`k = ln(${initialConcentration}/${finalConcentration}) / ${time}`)
      steps.push(`k = ln(${formatNumber(Number.parseFloat(initialConcentration) / Number.parseFloat(finalConcentration), 4)}) / ${time}`)
      steps.push(`k = ${formatNumber(Math.log(Number.parseFloat(initialConcentration) / Number.parseFloat(finalConcentration)), 4)} / ${time}`)
      steps.push(`k = ${formatNumber(result.calculatedValue)} ${timeUnit}⁻¹`)
    } else if (mode === "halfLife") {
      steps.push("Half-Life Formula for First-Order Reactions:")
      steps.push("t₁/₂ = ln(2) / k = 0.693 / k")
      steps.push("")
      steps.push(`Given: k = ${rateConstant} ${timeUnit}⁻¹`)
      steps.push("")
      steps.push(`t₁/₂ = 0.693 / ${rateConstant}`)
      steps.push(`t₁/₂ = ${formatNumber(result.calculatedValue)} ${timeUnit}`)
    }

    steps.push("")
    steps.push(`Half-Life: t₁/₂ = 0.693 / k = ${formatNumber(result.halfLife)} ${result.halfLifeUnit}`)

    return steps
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">First-Order Reaction Calculator</CardTitle>
                    <CardDescription>Analyze first-order reaction kinetics</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Mode */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select value={mode} onValueChange={(v) => setMode(v as CalculationMode)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select calculation mode" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concentration">Final Concentration</SelectItem>
                      <SelectItem value="time">Time Elapsed</SelectItem>
                      <SelectItem value="rateConstant">Rate Constant (k)</SelectItem>
                      <SelectItem value="halfLife">Half-Life</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Unit Selectors */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Concentration Unit</Label>
                    <Select value={concentrationUnit} onValueChange={(v) => setConcentrationUnit(v as ConcentrationUnit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="M">Molar (M)</SelectItem>
                        <SelectItem value="mM">Millimolar (mM)</SelectItem>
                        <SelectItem value="μM">Micromolar (μM)</SelectItem>
                        <SelectItem value="mol/L">mol/L</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Time Unit</Label>
                    <Select value={timeUnit} onValueChange={(v) => setTimeUnit(v as TimeUnit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="s">Seconds (s)</SelectItem>
                        <SelectItem value="min">Minutes (min)</SelectItem>
                        <SelectItem value="hr">Hours (hr)</SelectItem>
                        <SelectItem value="days">Days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Initial Concentration - not needed for halfLife mode */}
                {mode !== "halfLife" && (
                  <div className="space-y-2">
                    <Label htmlFor="initialConcentration">Initial Concentration [A]₀ ({concentrationUnit})</Label>
                    <Input
                      id="initialConcentration"
                      type="number"
                      placeholder={`Enter initial concentration in ${concentrationUnit}`}
                      value={initialConcentration}
                      onChange={(e) => setInitialConcentration(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Final Concentration - only for time and rateConstant modes */}
                {(mode === "time" || mode === "rateConstant") && (
                  <div className="space-y-2">
                    <Label htmlFor="finalConcentration">Final Concentration [A] ({concentrationUnit})</Label>
                    <Input
                      id="finalConcentration"
                      type="number"
                      placeholder={`Enter final concentration in ${concentrationUnit}`}
                      value={finalConcentration}
                      onChange={(e) => setFinalConcentration(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Time - for concentration and rateConstant modes */}
                {(mode === "concentration" || mode === "rateConstant") && (
                  <div className="space-y-2">
                    <Label htmlFor="time">Time (t) in {timeUnitLabels[timeUnit]}</Label>
                    <Input
                      id="time"
                      type="number"
                      placeholder={`Enter time in ${timeUnitLabels[timeUnit]}`}
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Rate Constant - for concentration, time, and halfLife modes */}
                {(mode === "concentration" || mode === "time" || mode === "halfLife") && (
                  <div className="space-y-2">
                    <Label htmlFor="rateConstant">Rate Constant (k) in {timeUnit}⁻¹</Label>
                    <Input
                      id="rateConstant"
                      type="number"
                      placeholder={`Enter rate constant in ${timeUnit}⁻¹`}
                      value={rateConstant}
                      onChange={(e) => setRateConstant(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show Step-by-Step Solution</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {modeLabels[mode]}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">{modeLabels[mode]}</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">
                        {formatNumber(result.calculatedValue)}
                        <span className="text-lg ml-1">{result.unit}</span>
                      </p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Half-Life (t₁/₂)</p>
                        <p className="font-semibold text-purple-600">
                          {formatNumber(result.halfLife, 4)} {result.halfLifeUnit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Rate Constant (k)</p>
                        <p className="font-semibold text-purple-600">
                          {formatNumber(result.rateConstant, 6)} {result.rateConstantUnit}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-Step Breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-purple-100">
                        <p className="font-medium text-sm mb-2 text-purple-700">Step-by-Step Solution:</p>
                        <div className="text-xs space-y-1 text-muted-foreground font-mono">
                          {getStepByStepCalculation().map((step, index) => (
                            <p
                              key={index}
                              className={
                                step.startsWith("[A] =") || step.startsWith("t =") || step.startsWith("k =") || step.startsWith("t₁/₂ =") || step.startsWith("Half-Life:")
                                  ? "text-purple-600 font-semibold"
                                  : step === ""
                                  ? "h-2"
                                  : ""
                              }
                            >
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">First-Order Rate Law</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-mono font-semibold text-purple-700 text-center text-sm">
                      ln([A]₀ / [A]) = k × t
                    </p>
                    <p className="text-xs text-purple-600 text-center mt-1">Integrated Rate Law</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-mono font-semibold text-purple-700 text-center text-sm">
                      t₁/₂ = 0.693 / k
                    </p>
                    <p className="text-xs text-purple-600 text-center mt-1">Half-Life Formula</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p><strong>[A]₀</strong> = Initial concentration</p>
                    <p><strong>[A]</strong> = Concentration at time t</p>
                    <p><strong>k</strong> = Rate constant (time⁻¹)</p>
                    <p><strong>t</strong> = Time elapsed</p>
                    <p><strong>t₁/₂</strong> = Half-life</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Info className="h-5 w-5" />
                    Understanding First-Order Kinetics
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div>
                    <p className="font-medium text-foreground mb-1">What is a First-Order Reaction?</p>
                    <p>
                      A first-order reaction is one where the rate of reaction is directly proportional to the
                      concentration of a single reactant. The rate law is: Rate = k[A].
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Characteristic Half-Life</p>
                    <p>
                      For first-order reactions, the half-life is constant and independent of the initial concentration.
                      This makes it easy to predict how long it takes for any given fraction to react.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Common Examples</p>
                    <p>
                      Radioactive decay, many enzyme reactions, drug metabolism in the body, and the decomposition of
                      hydrogen peroxide are examples of first-order kinetics.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Key Properties
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Rate depends on</span>
                    <span className="font-mono">[A]¹</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Units of k</span>
                    <span className="font-mono">time⁻¹</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Half-life depends on</span>
                    <span className="font-mono">k only</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Plot for straight line</span>
                    <span className="font-mono">ln[A] vs t</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="space-y-2 text-sm text-amber-900">
                      <p className="font-medium">Important Note</p>
                      <p>
                        First-order kinetics assume the reaction rate depends on the concentration of a single reactant.
                        Real systems may deviate under non-ideal conditions such as temperature changes, competing
                        reactions, or concentration extremes.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Information Section */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is First-Order Reaction Kinetics?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  First-order reaction kinetics describes chemical reactions where the reaction rate is directly
                  proportional to the concentration of only one reactant. This means that if you double the concentration
                  of the reactant, the reaction rate will also double. The mathematical treatment of first-order reactions
                  is fundamental to understanding chemical kinetics and has widespread applications in chemistry, biology,
                  pharmacology, and nuclear physics.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The integrated rate law for first-order reactions, ln([A]₀/[A]) = kt, allows us to calculate
                  concentration changes over time, determine how long a reaction will take to reach a certain point, or
                  find the rate constant from experimental data. This equation shows that a plot of ln[A] versus time will
                  yield a straight line with a slope equal to -k for a true first-order reaction.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of First-Order Kinetics</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  First-order kinetics plays a crucial role in many scientific and practical applications. In
                  pharmacology, drug elimination from the body often follows first-order kinetics, which is essential for
                  determining proper dosing schedules. The half-life of a drug tells healthcare providers how often a
                  medication needs to be administered to maintain therapeutic levels in the bloodstream.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In nuclear chemistry, radioactive decay is a perfect example of first-order kinetics. The half-life
                  concept originated from studying radioactive isotopes, where it represents the time required for half
                  of the radioactive nuclei in a sample to decay. This principle is used in carbon-14 dating,
                  nuclear medicine, and understanding nuclear reactor behavior. Environmental scientists also use
                  first-order kinetics to model the degradation of pollutants in ecosystems.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
