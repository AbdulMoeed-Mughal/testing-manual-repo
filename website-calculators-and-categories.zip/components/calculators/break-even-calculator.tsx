"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Target,
  Info,
  AlertTriangle,
  TrendingUp,
  DollarSign,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface BreakEvenResult {
  breakEvenUnits: number
  breakEvenRevenue: number
  contributionMargin: number
  contributionMarginRatio: number
  marginOfSafety?: number
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
]

export function BreakEvenCalculator() {
  const [currency, setCurrency] = useState("USD")
  const [fixedCosts, setFixedCosts] = useState("")
  const [variableCostPerUnit, setVariableCostPerUnit] = useState("")
  const [sellingPricePerUnit, setSellingPricePerUnit] = useState("")
  const [actualSales, setActualSales] = useState("")
  const [result, setResult] = useState<BreakEvenResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const currencySymbol = currencies.find((c) => c.code === currency)?.symbol || "$"

  const formatCurrency = (value: number): string => {
    if (currency === "INR") {
      if (value >= 10000000) return `${currencySymbol}${(value / 10000000).toFixed(2)} Cr`
      if (value >= 100000) return `${currencySymbol}${(value / 100000).toFixed(2)} L`
      return `${currencySymbol}${value.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`
    }
    if (value >= 1000000000) return `${currencySymbol}${(value / 1000000000).toFixed(2)}B`
    if (value >= 1000000) return `${currencySymbol}${(value / 1000000).toFixed(2)}M`
    if (value >= 1000) return `${currencySymbol}${(value / 1000).toFixed(2)}K`
    return `${currencySymbol}${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`
  }

  const formatNumber = (value: number): string => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`
    if (value >= 1000) return `${(value / 1000).toFixed(2)}K`
    return value.toLocaleString(undefined, { maximumFractionDigits: 0 })
  }

  const calculateBreakEven = () => {
    setError("")
    setResult(null)

    const fixed = Number.parseFloat(fixedCosts)
    const variable = Number.parseFloat(variableCostPerUnit)
    const selling = Number.parseFloat(sellingPricePerUnit)
    const sales = actualSales ? Number.parseFloat(actualSales) : undefined

    if (isNaN(fixed) || fixed < 0) {
      setError("Please enter valid fixed costs (0 or greater)")
      return
    }

    if (isNaN(variable) || variable < 0) {
      setError("Please enter valid variable cost per unit (0 or greater)")
      return
    }

    if (isNaN(selling) || selling <= 0) {
      setError("Please enter a valid selling price per unit (greater than 0)")
      return
    }

    if (selling <= variable) {
      setError("Selling price must be greater than variable cost per unit")
      return
    }

    // Calculate contribution margin
    const contributionMargin = selling - variable
    const contributionMarginRatio = (contributionMargin / selling) * 100

    // Calculate break-even point
    const breakEvenUnits = fixed / contributionMargin
    const breakEvenRevenue = breakEvenUnits * selling

    // Calculate margin of safety if actual sales provided
    let marginOfSafety: number | undefined
    if (sales !== undefined && !isNaN(sales) && sales > 0) {
      const actualRevenue = sales * selling
      if (actualRevenue > breakEvenRevenue) {
        marginOfSafety = ((actualRevenue - breakEvenRevenue) / actualRevenue) * 100
      } else {
        marginOfSafety = ((actualRevenue - breakEvenRevenue) / actualRevenue) * 100
      }
    }

    setResult({
      breakEvenUnits: Math.ceil(breakEvenUnits),
      breakEvenRevenue,
      contributionMargin,
      contributionMarginRatio,
      marginOfSafety,
    })
  }

  const handleReset = () => {
    setFixedCosts("")
    setVariableCostPerUnit("")
    setSellingPricePerUnit("")
    setActualSales("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Break-Even Analysis:\n- Break-Even Units: ${formatNumber(result.breakEvenUnits)} units\n- Break-Even Revenue: ${formatCurrency(result.breakEvenRevenue)}\n- Contribution Margin: ${formatCurrency(result.contributionMargin)}/unit\n- Contribution Margin Ratio: ${result.contributionMarginRatio.toFixed(1)}%${result.marginOfSafety !== undefined ? `\n- Margin of Safety: ${result.marginOfSafety.toFixed(1)}%` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Break-Even Analysis",
          text: `My Break-Even Point: ${formatNumber(result.breakEvenUnits)} units (${formatCurrency(result.breakEvenRevenue)} revenue)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Target className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Break-Even Calculator</CardTitle>
                    <CardDescription>Calculate your break-even point</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {currencies.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.symbol})
                      </option>
                    ))}
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Fixed Costs Input */}
                <div className="space-y-2">
                  <Label htmlFor="fixedCosts">Fixed Costs ({currencySymbol})</Label>
                  <Input
                    id="fixedCosts"
                    type="number"
                    placeholder="e.g., 50000"
                    value={fixedCosts}
                    onChange={(e) => setFixedCosts(e.target.value)}
                    min="0"
                    step="100"
                  />
                  <p className="text-xs text-muted-foreground">Total fixed costs (rent, salaries, etc.)</p>
                </div>

                {/* Variable Cost Per Unit Input */}
                <div className="space-y-2">
                  <Label htmlFor="variableCost">Variable Cost Per Unit ({currencySymbol})</Label>
                  <Input
                    id="variableCost"
                    type="number"
                    placeholder="e.g., 25"
                    value={variableCostPerUnit}
                    onChange={(e) => setVariableCostPerUnit(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">Cost to produce one unit</p>
                </div>

                {/* Selling Price Per Unit Input */}
                <div className="space-y-2">
                  <Label htmlFor="sellingPrice">Selling Price Per Unit ({currencySymbol})</Label>
                  <Input
                    id="sellingPrice"
                    type="number"
                    placeholder="e.g., 50"
                    value={sellingPricePerUnit}
                    onChange={(e) => setSellingPricePerUnit(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">Price at which you sell one unit</p>
                </div>

                {/* Actual Sales Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="actualSales">Actual/Expected Sales (units) - Optional</Label>
                  <Input
                    id="actualSales"
                    type="number"
                    placeholder="e.g., 3000"
                    value={actualSales}
                    onChange={(e) => setActualSales(e.target.value)}
                    min="0"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">Enter to calculate margin of safety</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBreakEven} className="w-full" size="lg">
                  Calculate Break-Even Point
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Break-Even Point</p>
                      <p className="text-4xl font-bold text-green-600 mb-1">
                        {formatNumber(result.breakEvenUnits)} units
                      </p>
                      <p className="text-lg font-semibold text-green-700">
                        {formatCurrency(result.breakEvenRevenue)} revenue
                      </p>
                    </div>

                    {/* Additional Metrics */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Contribution Margin</p>
                        <p className="text-lg font-semibold text-foreground">
                          {formatCurrency(result.contributionMargin)}/unit
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">CM Ratio</p>
                        <p className="text-lg font-semibold text-foreground">
                          {result.contributionMarginRatio.toFixed(1)}%
                        </p>
                      </div>
                    </div>

                    {/* Margin of Safety */}
                    {result.marginOfSafety !== undefined && (
                      <div
                        className={`p-3 rounded-lg border mb-4 ${result.marginOfSafety >= 0 ? "bg-blue-50 border-blue-200" : "bg-red-50 border-red-200"}`}
                      >
                        <p className="text-xs text-muted-foreground">Margin of Safety</p>
                        <p
                          className={`text-lg font-semibold ${result.marginOfSafety >= 0 ? "text-blue-600" : "text-red-600"}`}
                        >
                          {result.marginOfSafety.toFixed(1)}%
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {result.marginOfSafety >= 0
                            ? "Sales can drop by this much before reaching break-even"
                            : "You need to increase sales to reach break-even"}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Break-Even Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-sm">
                      BEP (units) = Fixed Costs ÷ (Price − Variable Cost)
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-sm">BEP (revenue) = BEP units × Selling Price</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Terms</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-foreground">Contribution Margin</p>
                      <p className="text-muted-foreground">Selling price minus variable cost per unit</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-foreground">Fixed Costs</p>
                      <p className="text-muted-foreground">Costs that remain constant regardless of production</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-foreground">Variable Costs</p>
                      <p className="text-muted-foreground">Costs that change with production volume</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium text-foreground">Margin of Safety</p>
                      <p className="text-muted-foreground">How much sales can drop before losing money</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Actual break-even point may vary based on market
                        conditions, pricing changes, and other business factors.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Break-Even Analysis?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Break-even analysis is a fundamental financial tool that helps businesses determine the point at which
                  total revenue equals total costs, resulting in neither profit nor loss. This critical metric, known as
                  the break-even point (BEP), represents the minimum level of sales a business must achieve to cover all
                  its expenses. Understanding your break-even point is essential for making informed decisions about
                  pricing, production volumes, and overall business strategy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept applies to both startups evaluating the viability of a new venture and established
                  businesses considering product launches, price changes, or cost restructuring. By knowing exactly how
                  many units you need to sell or how much revenue you need to generate to break even, you can set
                  realistic sales targets, evaluate pricing strategies, and assess the financial risk of business
                  decisions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Costs in Break-Even Analysis</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Accurate break-even analysis requires a clear understanding of the two main cost categories: fixed
                  costs and variable costs. Fixed costs remain constant regardless of production or sales volume and
                  include expenses like rent, insurance, salaries of permanent staff, equipment depreciation, and loan
                  payments. These costs must be paid whether you sell one unit or one million units.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Variable costs, on the other hand, change directly with production or sales volume. These include raw
                  materials, direct labor costs, packaging, shipping, and sales commissions. For each additional unit
                  produced, variable costs increase proportionally. Understanding this distinction is crucial because
                  the break-even formula relies on the contribution margin, which is the difference between the selling
                  price and variable cost per unit.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Some costs may have both fixed and variable components, known as mixed or semi-variable costs. For
                  example, utilities might have a base charge (fixed) plus usage charges (variable). When performing
                  break-even analysis, it's important to properly allocate these costs to ensure accurate calculations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Contribution Margin and Its Importance</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The contribution margin is perhaps the most important concept in break-even analysis. It represents
                  the portion of each sale that contributes toward covering fixed costs and, eventually, generating
                  profit. Calculated as the selling price minus the variable cost per unit, the contribution margin
                  tells you how much each unit sold contributes to your bottom line.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The contribution margin ratio expresses this relationship as a percentage of the selling price. A
                  higher contribution margin ratio means that a larger portion of each sale goes toward covering fixed
                  costs and profit. Businesses with high contribution margin ratios typically reach break-even faster
                  and generate more profit per sale, making them more resilient to sales fluctuations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding your contribution margin helps with various business decisions, including pricing
                  strategy, product mix optimization, and cost control. Products with higher contribution margins should
                  generally receive more marketing focus, while low-margin products may need price adjustments or cost
                  reductions to remain viable.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Using Break-Even Analysis for Business Decisions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Break-even analysis serves as a powerful decision-making tool across various business scenarios. When
                  launching a new product, calculating the break-even point helps determine whether projected sales
                  volumes are realistic and how long it will take to recover initial investments. For existing products,
                  it helps evaluate the impact of price changes or cost modifications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The margin of safety metric extends break-even analysis by showing how much cushion exists between
                  current sales and the break-even point. A healthy margin of safety (typically 20% or more) indicates
                  that the business can withstand sales declines without incurring losses. This metric is particularly
                  valuable during economic uncertainty or when planning for seasonal fluctuations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Remember that break-even analysis has limitations. It assumes linear relationships between costs and
                  volume, which may not hold at extreme production levels. It also assumes that all units produced are
                  sold and that product mix remains constant. Despite these limitations, break-even analysis remains an
                  essential tool for financial planning and strategic decision-making in businesses of all sizes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
