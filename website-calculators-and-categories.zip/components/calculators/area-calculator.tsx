"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Square,
  Info,
  AlertTriangle,
  Triangle,
  Circle,
  Hexagon,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Shape =
  | "rectangle"
  | "square"
  | "triangle"
  | "circle"
  | "trapezoid"
  | "parallelogram"
  | "ellipse"
  | "rhombus"
  | "sector"
  | "regular-polygon"

type Unit = "cm" | "m" | "in" | "ft" | "mm" | "km" | "yd"

interface ShapeConfig {
  name: string
  icon: React.ReactNode
  fields: { key: string; label: string; placeholder: string }[]
  formula: string
  calculate: (values: Record<string, number>) => number
}

const unitLabels: Record<Unit, string> = {
  cm: "Centimeters",
  m: "Meters",
  in: "Inches",
  ft: "Feet",
  mm: "Millimeters",
  km: "Kilometers",
  yd: "Yards",
}

const areaUnitLabels: Record<Unit, string> = {
  cm: "cm²",
  m: "m²",
  in: "in²",
  ft: "ft²",
  mm: "mm²",
  km: "km²",
  yd: "yd²",
}

const shapeConfigs: Record<Shape, ShapeConfig> = {
  rectangle: {
    name: "Rectangle",
    icon: <Square className="h-4 w-4" />,
    fields: [
      { key: "length", label: "Length", placeholder: "Enter length" },
      { key: "width", label: "Width", placeholder: "Enter width" },
    ],
    formula: "Area = Length × Width",
    calculate: (v) => v.length * v.width,
  },
  square: {
    name: "Square",
    icon: <Square className="h-4 w-4" />,
    fields: [{ key: "side", label: "Side", placeholder: "Enter side length" }],
    formula: "Area = Side²",
    calculate: (v) => v.side * v.side,
  },
  triangle: {
    name: "Triangle",
    icon: <Triangle className="h-4 w-4" />,
    fields: [
      { key: "base", label: "Base", placeholder: "Enter base" },
      { key: "height", label: "Height", placeholder: "Enter height" },
    ],
    formula: "Area = ½ × Base × Height",
    calculate: (v) => 0.5 * v.base * v.height,
  },
  circle: {
    name: "Circle",
    icon: <Circle className="h-4 w-4" />,
    fields: [{ key: "radius", label: "Radius", placeholder: "Enter radius" }],
    formula: "Area = π × Radius²",
    calculate: (v) => Math.PI * v.radius * v.radius,
  },
  trapezoid: {
    name: "Trapezoid",
    icon: <Hexagon className="h-4 w-4" />,
    fields: [
      { key: "base1", label: "Base 1 (a)", placeholder: "Enter first base" },
      { key: "base2", label: "Base 2 (b)", placeholder: "Enter second base" },
      { key: "height", label: "Height", placeholder: "Enter height" },
    ],
    formula: "Area = ½ × (Base₁ + Base₂) × Height",
    calculate: (v) => 0.5 * (v.base1 + v.base2) * v.height,
  },
  parallelogram: {
    name: "Parallelogram",
    icon: <Square className="h-4 w-4" />,
    fields: [
      { key: "base", label: "Base", placeholder: "Enter base" },
      { key: "height", label: "Height", placeholder: "Enter height" },
    ],
    formula: "Area = Base × Height",
    calculate: (v) => v.base * v.height,
  },
  ellipse: {
    name: "Ellipse",
    icon: <Circle className="h-4 w-4" />,
    fields: [
      { key: "majorAxis", label: "Semi-major axis (a)", placeholder: "Enter semi-major axis" },
      { key: "minorAxis", label: "Semi-minor axis (b)", placeholder: "Enter semi-minor axis" },
    ],
    formula: "Area = π × a × b",
    calculate: (v) => Math.PI * v.majorAxis * v.minorAxis,
  },
  rhombus: {
    name: "Rhombus",
    icon: <Square className="h-4 w-4" />,
    fields: [
      { key: "d1", label: "Diagonal 1", placeholder: "Enter first diagonal" },
      { key: "d2", label: "Diagonal 2", placeholder: "Enter second diagonal" },
    ],
    formula: "Area = ½ × d₁ × d₂",
    calculate: (v) => 0.5 * v.d1 * v.d2,
  },
  sector: {
    name: "Sector",
    icon: <Circle className="h-4 w-4" />,
    fields: [
      { key: "radius", label: "Radius", placeholder: "Enter radius" },
      { key: "angle", label: "Angle (degrees)", placeholder: "Enter angle in degrees" },
    ],
    formula: "Area = (θ/360) × π × r²",
    calculate: (v) => (v.angle / 360) * Math.PI * v.radius * v.radius,
  },
  "regular-polygon": {
    name: "Regular Polygon",
    icon: <Hexagon className="h-4 w-4" />,
    fields: [
      { key: "sides", label: "Number of sides", placeholder: "Enter number of sides" },
      { key: "sideLength", label: "Side length", placeholder: "Enter side length" },
    ],
    formula: "Area = (n × s²) / (4 × tan(π/n))",
    calculate: (v) => (v.sides * v.sideLength * v.sideLength) / (4 * Math.tan(Math.PI / v.sides)),
  },
}

export function AreaCalculator() {
  const [shape, setShape] = useState<Shape>("rectangle")
  const [unit, setUnit] = useState<Unit>("cm")
  const [values, setValues] = useState<Record<string, string>>({})
  const [result, setResult] = useState<number | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const config = shapeConfigs[shape]

  const calculateArea = () => {
    setError("")
    setResult(null)

    const numericValues: Record<string, number> = {}

    for (const field of config.fields) {
      const val = Number.parseFloat(values[field.key] || "")
      if (isNaN(val) || val <= 0) {
        setError(`Please enter a valid positive number for ${field.label}`)
        return
      }
      numericValues[field.key] = val
    }

    // Special validation for regular polygon
    if (shape === "regular-polygon" && numericValues.sides < 3) {
      setError("A polygon must have at least 3 sides")
      return
    }

    // Special validation for sector angle
    if (shape === "sector" && (numericValues.angle <= 0 || numericValues.angle > 360)) {
      setError("Angle must be between 0 and 360 degrees")
      return
    }

    const area = config.calculate(numericValues)
    setResult(area)
  }

  const handleReset = () => {
    setValues({})
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result !== null) {
      await navigator.clipboard.writeText(`${config.name} Area: ${formatNumber(result)} ${areaUnitLabels[unit]}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result !== null && navigator.share) {
      try {
        await navigator.share({
          title: "Area Calculation Result",
          text: `I calculated the area of a ${config.name.toLowerCase()} using CalcHub! Area: ${formatNumber(result)} ${areaUnitLabels[unit]}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const handleShapeChange = (newShape: Shape) => {
    setShape(newShape)
    setValues({})
    setResult(null)
    setError("")
    setShowSteps(false)
  }

  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 4 })
  }

  const getStepByStep = (): string[] => {
    if (result === null) return []

    const steps: string[] = []
    const numericValues: Record<string, number> = {}
    for (const field of config.fields) {
      numericValues[field.key] = Number.parseFloat(values[field.key] || "0")
    }

    steps.push(`Shape: ${config.name}`)
    steps.push(`Formula: ${config.formula}`)

    switch (shape) {
      case "rectangle":
        steps.push(`Substituting values: ${numericValues.length} × ${numericValues.width}`)
        break
      case "square":
        steps.push(`Substituting values: ${numericValues.side}² = ${numericValues.side} × ${numericValues.side}`)
        break
      case "triangle":
        steps.push(`Substituting values: ½ × ${numericValues.base} × ${numericValues.height}`)
        break
      case "circle":
        steps.push(
          `Substituting values: π × ${numericValues.radius}² = 3.14159... × ${numericValues.radius * numericValues.radius}`,
        )
        break
      case "trapezoid":
        steps.push(
          `Substituting values: ½ × (${numericValues.base1} + ${numericValues.base2}) × ${numericValues.height}`,
        )
        break
      case "parallelogram":
        steps.push(`Substituting values: ${numericValues.base} × ${numericValues.height}`)
        break
      case "ellipse":
        steps.push(`Substituting values: π × ${numericValues.majorAxis} × ${numericValues.minorAxis}`)
        break
      case "rhombus":
        steps.push(`Substituting values: ½ × ${numericValues.d1} × ${numericValues.d2}`)
        break
      case "sector":
        steps.push(`Substituting values: (${numericValues.angle}/360) × π × ${numericValues.radius}²`)
        break
      case "regular-polygon":
        steps.push(
          `Substituting values: (${numericValues.sides} × ${numericValues.sideLength}²) / (4 × tan(π/${numericValues.sides}))`,
        )
        break
    }

    steps.push(`Result: ${formatNumber(result)} ${areaUnitLabels[unit]}`)

    return steps
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Square className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Area Calculator</CardTitle>
                    <CardDescription>Calculate area of 2D shapes</CardDescription>
                  </div>
                </div>

                {/* Shape Selector */}
                <div className="pt-2 space-y-3">
                  <div className="space-y-2">
                    <Label>Select Shape</Label>
                    <Select value={shape} onValueChange={(v) => handleShapeChange(v as Shape)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(shapeConfigs).map(([key, cfg]) => (
                          <SelectItem key={key} value={key}>
                            <span className="flex items-center gap-2">
                              {cfg.icon}
                              {cfg.name}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Unit</Label>
                    <Select value={unit} onValueChange={(v) => setUnit(v as Unit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(unitLabels).map(([key, label]) => (
                          <SelectItem key={key} value={key}>
                            {label} ({key})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Dynamic Input Fields */}
                {config.fields.map((field) => (
                  <div key={field.key} className="space-y-2">
                    <Label htmlFor={field.key}>
                      {field.label} ({unit})
                    </Label>
                    <Input
                      id={field.key}
                      type="number"
                      placeholder={field.placeholder}
                      value={values[field.key] || ""}
                      onChange={(e) => setValues({ ...values, [field.key]: e.target.value })}
                      min="0"
                      step="any"
                    />
                  </div>
                ))}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateArea} className="w-full" size="lg">
                  Calculate Area
                </Button>

                {/* Result */}
                {result !== null && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{config.name} Area</p>
                      <p className="text-4xl font-bold text-blue-600 mb-1">{formatNumber(result)}</p>
                      <p className="text-lg font-semibold text-blue-600">{areaUnitLabels[unit]}</p>
                    </div>

                    {/* Step by Step Toggle */}
                    <div className="mt-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowSteps(!showSteps)}
                        className="w-full text-blue-600"
                      >
                        {showSteps ? "Hide Steps" : "Show Step-by-Step"}
                      </Button>

                      {showSteps && (
                        <div className="mt-3 p-3 bg-white rounded-lg border border-blue-100">
                          <ol className="space-y-2 text-sm">
                            {getStepByStep().map((step, i) => (
                              <li key={i} className="flex gap-2">
                                <span className="font-semibold text-blue-600">{i + 1}.</span>
                                <span>{step}</span>
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-semibold text-blue-700 mb-1">{config.name}</p>
                      <p className="text-sm font-mono text-blue-600">{config.formula}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">All Shape Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2 max-h-64 overflow-y-auto">
                  {Object.entries(shapeConfigs).map(([key, cfg]) => (
                    <div
                      key={key}
                      className={`p-2 rounded-lg border ${
                        key === shape ? "bg-blue-50 border-blue-200" : "bg-muted/50 border-border"
                      }`}
                    >
                      <p className="font-medium">{cfg.name}</p>
                      <p className="text-muted-foreground font-mono text-xs">{cfg.formula}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-amber-800 mb-1">Disclaimer</p>
                      <p className="text-sm text-amber-700">
                        This calculator provides estimates only. Verify manually for critical measurements.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Area?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Area is a fundamental concept in geometry that measures the amount of two-dimensional space enclosed
                  within a shape or boundary. It quantifies the size of a surface and is expressed in square units, such
                  as square meters (m²), square centimeters (cm²), or square feet (ft²). Understanding area is essential
                  in numerous real-world applications, from calculating the amount of paint needed for a wall to
                  determining land sizes for construction projects.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of area dates back to ancient civilizations, where it was crucial for land measurement,
                  agriculture, and architecture. The Egyptians and Babylonians developed early methods for calculating
                  areas of simple shapes, and these techniques have been refined over millennia into the precise
                  mathematical formulas we use today. Every two-dimensional shape has a specific formula for calculating
                  its area based on its unique geometric properties.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Square className="h-5 w-5 text-primary" />
                  <CardTitle>Common Shape Formulas Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Rectangles and Squares</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The rectangle is perhaps the most straightforward shape to calculate. Its area equals length
                      multiplied by width (A = l × w). A square, being a special rectangle with all sides equal, has an
                      even simpler formula: side squared (A = s²). These shapes are fundamental in construction,
                      flooring, and many everyday measurements.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Triangles</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      A triangle's area is calculated as half the product of its base and height (A = ½ × b × h). This
                      formula works for all triangles regardless of whether they're equilateral, isosceles, or scalene.
                      The key is identifying the perpendicular height from the base to the opposite vertex.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Circles and Ellipses</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The circle's area formula involves the mathematical constant pi (π ≈ 3.14159): A = πr², where r is
                      the radius. For ellipses, which are stretched circles, the formula becomes A = πab, where a and b
                      are the semi-major and semi-minor axes respectively. These formulas are essential in engineering,
                      physics, and design.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Trapezoids and Parallelograms</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      A trapezoid has two parallel bases of different lengths. Its area is the average of the two bases
                      multiplied by the height: A = ½(b₁ + b₂)h. A parallelogram, with opposite sides parallel and
                      equal, uses the simple formula A = b × h, where h is the perpendicular height.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Hexagon className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Area calculations are indispensable in countless practical situations. In construction and home
                  improvement, knowing the area helps determine how much material is needed—whether it's tiles for a
                  floor, paint for walls, or carpet for a room. Real estate professionals use area measurements to value
                  properties and determine land prices. Farmers calculate field areas to estimate crop yields and plan
                  irrigation systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In manufacturing and design, area calculations are crucial for material optimization and cost
                  estimation. Engineers use area formulas to calculate surface areas for heat transfer analysis, while
                  architects rely on them for spatial planning and building design. Even in everyday life, understanding
                  area helps with tasks like determining if furniture will fit in a room or calculating how much mulch
                  is needed for a garden bed.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Triangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To ensure accurate area calculations, always use consistent units throughout your measurements. If you
                  measure length in meters, measure width in meters too—mixing units leads to errors. When measuring
                  irregular spaces, break them down into simpler shapes, calculate each area separately, then add them
                  together for the total.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For physical measurements, take multiple readings and use the average to minimize measurement errors.
                  When dealing with real-world shapes that aren't perfectly geometric, consider using approximations or
                  measuring the closest standard shape that encompasses the area. Always add a small buffer (typically
                  5-10%) when ordering materials to account for waste, cuts, and measurement variations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
