"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Periodic table data with atomic weights
const ELEMENTS: Record<string, { name: string; weight: number }> = {
  H: { name: "Hydrogen", weight: 1.008 },
  He: { name: "Helium", weight: 4.003 },
  Li: { name: "Lithium", weight: 6.941 },
  Be: { name: "Beryllium", weight: 9.012 },
  B: { name: "Boron", weight: 10.81 },
  C: { name: "Carbon", weight: 12.01 },
  N: { name: "Nitrogen", weight: 14.01 },
  O: { name: "Oxygen", weight: 16.0 },
  F: { name: "Fluorine", weight: 19.0 },
  Ne: { name: "Neon", weight: 20.18 },
  Na: { name: "Sodium", weight: 22.99 },
  Mg: { name: "Magnesium", weight: 24.31 },
  Al: { name: "Aluminum", weight: 26.98 },
  Si: { name: "Silicon", weight: 28.09 },
  P: { name: "Phosphorus", weight: 30.97 },
  S: { name: "Sulfur", weight: 32.07 },
  Cl: { name: "Chlorine", weight: 35.45 },
  Ar: { name: "Argon", weight: 39.95 },
  K: { name: "Potassium", weight: 39.1 },
  Ca: { name: "Calcium", weight: 40.08 },
  Sc: { name: "Scandium", weight: 44.96 },
  Ti: { name: "Titanium", weight: 47.87 },
  V: { name: "Vanadium", weight: 50.94 },
  Cr: { name: "Chromium", weight: 52.0 },
  Mn: { name: "Manganese", weight: 54.94 },
  Fe: { name: "Iron", weight: 55.85 },
  Co: { name: "Cobalt", weight: 58.93 },
  Ni: { name: "Nickel", weight: 58.69 },
  Cu: { name: "Copper", weight: 63.55 },
  Zn: { name: "Zinc", weight: 65.38 },
  Ga: { name: "Gallium", weight: 69.72 },
  Ge: { name: "Germanium", weight: 72.63 },
  As: { name: "Arsenic", weight: 74.92 },
  Se: { name: "Selenium", weight: 78.97 },
  Br: { name: "Bromine", weight: 79.9 },
  Kr: { name: "Krypton", weight: 83.8 },
  Rb: { name: "Rubidium", weight: 85.47 },
  Sr: { name: "Strontium", weight: 87.62 },
  Y: { name: "Yttrium", weight: 88.91 },
  Zr: { name: "Zirconium", weight: 91.22 },
  Nb: { name: "Niobium", weight: 92.91 },
  Mo: { name: "Molybdenum", weight: 95.95 },
  Ru: { name: "Ruthenium", weight: 101.1 },
  Rh: { name: "Rhodium", weight: 102.9 },
  Pd: { name: "Palladium", weight: 106.4 },
  Ag: { name: "Silver", weight: 107.9 },
  Cd: { name: "Cadmium", weight: 112.4 },
  In: { name: "Indium", weight: 114.8 },
  Sn: { name: "Tin", weight: 118.7 },
  Sb: { name: "Antimony", weight: 121.8 },
  Te: { name: "Tellurium", weight: 127.6 },
  I: { name: "Iodine", weight: 126.9 },
  Xe: { name: "Xenon", weight: 131.3 },
  Cs: { name: "Cesium", weight: 132.9 },
  Ba: { name: "Barium", weight: 137.3 },
  La: { name: "Lanthanum", weight: 138.9 },
  Ce: { name: "Cerium", weight: 140.1 },
  Pr: { name: "Praseodymium", weight: 140.9 },
  Nd: { name: "Neodymium", weight: 144.2 },
  Sm: { name: "Samarium", weight: 150.4 },
  Eu: { name: "Europium", weight: 152.0 },
  Gd: { name: "Gadolinium", weight: 157.3 },
  Tb: { name: "Terbium", weight: 158.9 },
  Dy: { name: "Dysprosium", weight: 162.5 },
  Ho: { name: "Holmium", weight: 164.9 },
  Er: { name: "Erbium", weight: 167.3 },
  Tm: { name: "Thulium", weight: 168.9 },
  Yb: { name: "Ytterbium", weight: 173.0 },
  Lu: { name: "Lutetium", weight: 175.0 },
  Hf: { name: "Hafnium", weight: 178.5 },
  Ta: { name: "Tantalum", weight: 180.9 },
  W: { name: "Tungsten", weight: 183.8 },
  Re: { name: "Rhenium", weight: 186.2 },
  Os: { name: "Osmium", weight: 190.2 },
  Ir: { name: "Iridium", weight: 192.2 },
  Pt: { name: "Platinum", weight: 195.1 },
  Au: { name: "Gold", weight: 197.0 },
  Hg: { name: "Mercury", weight: 200.6 },
  Tl: { name: "Thallium", weight: 204.4 },
  Pb: { name: "Lead", weight: 207.2 },
  Bi: { name: "Bismuth", weight: 209.0 },
  U: { name: "Uranium", weight: 238.0 },
}

type InputMode = "percent" | "mass"

interface ElementEntry {
  id: string
  element: string
  value: string
}

interface CalculationStep {
  element: string
  mass: number
  moles: number
  ratio: number
  roundedRatio: number
}

interface Result {
  formula: string
  steps: CalculationStep[]
  percentSum: number
}

export function EmpiricalFormulaCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("percent")
  const [elements, setElements] = useState<ElementEntry[]>([
    { id: "1", element: "C", value: "" },
    { id: "2", element: "H", value: "" },
    { id: "3", element: "O", value: "" },
  ])
  const [sampleMass, setSampleMass] = useState("100")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  const addElement = () => {
    const newId = (Math.max(...elements.map((e) => Number.parseInt(e.id))) + 1).toString()
    setElements([...elements, { id: newId, element: "N", value: "" }])
  }

  const removeElement = (id: string) => {
    if (elements.length > 2) {
      setElements(elements.filter((e) => e.id !== id))
    }
  }

  const updateElement = (id: string, field: "element" | "value", value: string) => {
    setElements(elements.map((e) => (e.id === id ? { ...e, [field]: value } : e)))
  }

  const calculate = () => {
    setError("")
    setResult(null)

    // Filter out elements with empty values
    const validElements = elements.filter((e) => e.value.trim() !== "" && e.element)

    if (validElements.length < 2) {
      setError("Please enter at least 2 elements with values")
      return
    }

    // Parse values
    const parsedElements: { element: string; value: number }[] = []
    for (const el of validElements) {
      const val = Number.parseFloat(el.value)
      if (isNaN(val) || val <= 0) {
        setError(`Invalid value for ${el.element}`)
        return
      }
      if (!ELEMENTS[el.element]) {
        setError(`Unknown element: ${el.element}`)
        return
      }
      parsedElements.push({ element: el.element, value: val })
    }

    // Check for duplicate elements
    const uniqueElements = new Set(parsedElements.map((e) => e.element))
    if (uniqueElements.size !== parsedElements.length) {
      setError("Duplicate elements are not allowed")
      return
    }

    // Calculate total for percent mode
    let percentSum = 0
    if (inputMode === "percent") {
      percentSum = parsedElements.reduce((sum, e) => sum + e.value, 0)
      if (percentSum < 95 || percentSum > 105) {
        // Allow some tolerance
        setError(`Percentages sum to ${percentSum.toFixed(1)}%, which is not approximately 100%`)
        return
      }
    }

    // Convert to mass (if percent mode, use sample mass)
    const totalMass = inputMode === "percent" ? Number.parseFloat(sampleMass) || 100 : 1
    const masses: { element: string; mass: number }[] = parsedElements.map((e) => ({
      element: e.element,
      mass: inputMode === "percent" ? (e.value / 100) * totalMass : e.value,
    }))

    // Calculate moles for each element
    const moles: { element: string; mass: number; moles: number }[] = masses.map((m) => ({
      ...m,
      moles: m.mass / ELEMENTS[m.element].weight,
    }))

    // Find smallest mole value
    const smallestMoles = Math.min(...moles.map((m) => m.moles))

    if (smallestMoles <= 0) {
      setError("Invalid calculation - moles cannot be zero or negative")
      return
    }

    // Calculate mole ratios
    const ratios = moles.map((m) => ({
      ...m,
      ratio: m.moles / smallestMoles,
    }))

    // Function to find multiplier for whole numbers
    const findMultiplier = (ratios: number[]): number => {
      const multipliers = [1, 2, 3, 4, 5, 6]
      for (const mult of multipliers) {
        const allClose = ratios.every((r) => {
          const scaled = r * mult
          return Math.abs(scaled - Math.round(scaled)) < 0.1
        })
        if (allClose) return mult
      }
      return 1
    }

    const multiplier = findMultiplier(ratios.map((r) => r.ratio))

    // Round to whole numbers
    const steps: CalculationStep[] = ratios.map((r) => ({
      element: r.element,
      mass: r.mass,
      moles: r.moles,
      ratio: r.ratio,
      roundedRatio: Math.round(r.ratio * multiplier),
    }))

    // Build empirical formula
    let formula = ""
    for (const step of steps) {
      formula += step.element
      if (step.roundedRatio > 1) {
        formula += step.roundedRatio
      }
    }

    setResult({
      formula,
      steps,
      percentSum: inputMode === "percent" ? percentSum : 0,
    })
  }

  const handleReset = () => {
    setElements([
      { id: "1", element: "C", value: "" },
      { id: "2", element: "H", value: "" },
      { id: "3", element: "O", value: "" },
    ])
    setSampleMass("100")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Empirical Formula: ${result.formula}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Empirical Formula Result",
          text: `I calculated the empirical formula using CalcHub! The empirical formula is ${result.formula}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const loadExample = (example: { elements: ElementEntry[]; mode: InputMode }) => {
    setElements(example.elements)
    setInputMode(example.mode)
    setResult(null)
    setError("")
  }

  const examples = [
    {
      name: "Glucose (C₆H₁₂O₆)",
      elements: [
        { id: "1", element: "C", value: "40.00" },
        { id: "2", element: "H", value: "6.71" },
        { id: "3", element: "O", value: "53.29" },
      ],
      mode: "percent" as InputMode,
    },
    {
      name: "Water (H₂O)",
      elements: [
        { id: "1", element: "H", value: "11.19" },
        { id: "2", element: "O", value: "88.81" },
      ],
      mode: "percent" as InputMode,
    },
    {
      name: "Ammonia (NH₃)",
      elements: [
        { id: "1", element: "N", value: "82.24" },
        { id: "2", element: "H", value: "17.76" },
      ],
      mode: "percent" as InputMode,
    },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Empirical Formula Calculator</CardTitle>
                    <CardDescription>Determine empirical formula from composition</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={() => {
                      setInputMode((prev) => (prev === "percent" ? "mass" : "percent"))
                      setResult(null)
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "mass" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "percent" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Percent (%)
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "mass" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Mass (g)
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Quick Examples */}
                <div className="space-y-2">
                  <Label className="text-sm text-muted-foreground">Quick Examples</Label>
                  <div className="flex flex-wrap gap-2">
                    {examples.map((example, idx) => (
                      <Button
                        key={idx}
                        variant="outline"
                        size="sm"
                        onClick={() => loadExample(example)}
                        className="text-xs"
                      >
                        {example.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Element Inputs */}
                <div className="space-y-3">
                  <Label>Element Composition</Label>
                  {elements.map((el, idx) => (
                    <div key={el.id} className="flex gap-2 items-center">
                      <Select value={el.element} onValueChange={(value) => updateElement(el.id, "element", value)}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="max-h-60">
                          {Object.entries(ELEMENTS).map(([symbol, data]) => (
                            <SelectItem key={symbol} value={symbol}>
                              {symbol} - {data.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        placeholder={inputMode === "percent" ? "%" : "grams"}
                        value={el.value}
                        onChange={(e) => updateElement(el.id, "value", e.target.value)}
                        min="0"
                        step="0.01"
                        className="flex-1"
                      />
                      {elements.length > 2 && (
                        <Button variant="ghost" size="icon" onClick={() => removeElement(el.id)} className="shrink-0">
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button variant="outline" size="sm" onClick={addElement} className="w-full bg-transparent">
                    <Plus className="h-4 w-4 mr-1" />
                    Add Element
                  </Button>
                </div>

                {/* Sample Mass (for percent mode) */}
                {inputMode === "percent" && (
                  <div className="space-y-2">
                    <Label htmlFor="sampleMass">Sample Mass (optional, default 100g)</Label>
                    <Input
                      id="sampleMass"
                      type="number"
                      placeholder="100"
                      value={sampleMass}
                      onChange={(e) => setSampleMass(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Empirical Formula
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Empirical Formula</p>
                      <p className="text-4xl font-bold text-purple-600 mb-2 font-mono">{result.formula}</p>
                      {inputMode === "percent" && (
                        <p className="text-sm text-muted-foreground">Percent sum: {result.percentSum.toFixed(1)}%</p>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-step breakdown */}
                {result && (
                  <div className="space-y-2">
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors w-full"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </button>

                    {showSteps && (
                      <div className="p-4 bg-muted/50 rounded-lg space-y-3 text-sm">
                        <div className="overflow-x-auto">
                          <table className="w-full text-left">
                            <thead>
                              <tr className="border-b">
                                <th className="pb-2 font-medium">Element</th>
                                <th className="pb-2 font-medium">Mass (g)</th>
                                <th className="pb-2 font-medium">Moles</th>
                                <th className="pb-2 font-medium">Ratio</th>
                                <th className="pb-2 font-medium">Subscript</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.steps.map((step, idx) => (
                                <tr key={idx} className="border-b border-muted">
                                  <td className="py-2 font-mono font-medium">{step.element}</td>
                                  <td className="py-2">{step.mass.toFixed(4)}</td>
                                  <td className="py-2">{step.moles.toFixed(4)}</td>
                                  <td className="py-2">{step.ratio.toFixed(3)}</td>
                                  <td className="py-2 font-bold text-purple-600">{step.roundedRatio}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>

                        <div className="pt-2 space-y-1 text-muted-foreground">
                          <p>
                            <strong>Step 1:</strong> Convert {inputMode === "percent" ? "percentages to mass" : "mass"}{" "}
                            to moles using atomic weights
                          </p>
                          <p>
                            <strong>Step 2:</strong> Divide each mole value by the smallest mole value
                          </p>
                          <p>
                            <strong>Step 3:</strong> Round ratios to nearest whole numbers (multiply if needed)
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-muted-foreground">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">1. Convert to Moles</p>
                    <p className="font-mono text-xs">moles = mass ÷ atomic weight</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">2. Find Mole Ratio</p>
                    <p className="font-mono text-xs">ratio = moles ÷ smallest moles</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">3. Round to Whole Numbers</p>
                    <p className="font-mono text-xs">Multiply if needed (×2, ×3, etc.)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Atomic Weights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {[
                      ["H", 1.008],
                      ["C", 12.01],
                      ["N", 14.01],
                      ["O", 16.0],
                      ["S", 32.07],
                      ["Cl", 35.45],
                      ["Na", 22.99],
                      ["Fe", 55.85],
                    ].map(([el, wt]) => (
                      <div key={el as string} className="flex justify-between p-2 bg-muted/50 rounded">
                        <span className="font-mono font-medium">{el}</span>
                        <span className="text-muted-foreground">{wt} g/mol</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are rounded to the nearest simple whole-number ratio and assume ideal composition.
                        Always verify with actual experimental data.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an Empirical Formula?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The empirical formula represents the simplest whole-number ratio of atoms of each element in a
                  compound. Unlike the molecular formula, which shows the actual number of atoms in a molecule, the
                  empirical formula shows only the relative proportions. For example, glucose has a molecular formula of
                  C₆H₁₂O₆, but its empirical formula is CH₂O, showing that carbon, hydrogen, and oxygen are present in a
                  1:2:1 ratio.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Empirical formulas are particularly useful in analytical chemistry when determining the composition of
                  unknown compounds. By measuring the mass or percentage of each element in a sample, chemists can
                  calculate the mole ratio and derive the empirical formula, which provides fundamental information
                  about the compound's composition.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>How to Determine Empirical Formula</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The process of determining an empirical formula involves several systematic steps. First, you need to
                  know either the mass or the percent composition of each element in the compound. If given percentages,
                  assume a 100-gram sample so that the percentage values directly convert to grams.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Step 1: Convert to Moles</h4>
                    <p className="text-purple-700 text-sm">
                      Divide the mass of each element by its atomic weight (from the periodic table) to get the number
                      of moles. For example, 40g of carbon ÷ 12.01 g/mol = 3.33 mol.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Step 2: Find the Mole Ratio</h4>
                    <p className="text-purple-700 text-sm">
                      Divide each mole value by the smallest number of moles calculated. This gives you the relative
                      mole ratio of each element.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Step 3: Round to Whole Numbers</h4>
                    <p className="text-purple-700 text-sm">
                      Round the ratios to the nearest whole number. If a ratio is close to 0.5, multiply all ratios by
                      2. If close to 0.33, multiply by 3, and so on.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Empirical vs Molecular Formula</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding the difference between empirical and molecular formulas is essential in chemistry. The
                  empirical formula gives the simplest ratio, while the molecular formula shows the actual number of
                  atoms in a single molecule of the compound.
                </p>
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 font-medium">Compound</th>
                        <th className="text-left py-2 font-medium">Empirical</th>
                        <th className="text-left py-2 font-medium">Molecular</th>
                        <th className="text-left py-2 font-medium">Multiplier</th>
                      </tr>
                    </thead>
                    <tbody className="text-muted-foreground">
                      <tr className="border-b">
                        <td className="py-2">Glucose</td>
                        <td className="py-2 font-mono">CH₂O</td>
                        <td className="py-2 font-mono">C₆H₁₂O₆</td>
                        <td className="py-2">×6</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Acetic Acid</td>
                        <td className="py-2 font-mono">CH₂O</td>
                        <td className="py-2 font-mono">C₂H₄O₂</td>
                        <td className="py-2">×2</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Benzene</td>
                        <td className="py-2 font-mono">CH</td>
                        <td className="py-2 font-mono">C₆H₆</td>
                        <td className="py-2">×6</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Water</td>
                        <td className="py-2 font-mono">H₂O</td>
                        <td className="py-2 font-mono">H₂O</td>
                        <td className="py-2">×1</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To determine the molecular formula from the empirical formula, you need to know the molar mass of the
                  compound (from techniques like mass spectrometry). Divide the molecular mass by the empirical formula
                  mass to find the multiplier, then multiply each subscript in the empirical formula.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Empirical formula determination has numerous practical applications in chemistry and related fields:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Analytical Chemistry:</strong> Identifying unknown compounds by analyzing their elemental
                    composition through combustion analysis or other methods.
                  </li>
                  <li>
                    <strong>Quality Control:</strong> Verifying the purity and composition of synthesized compounds in
                    pharmaceutical and chemical industries.
                  </li>
                  <li>
                    <strong>Research:</strong> Characterizing newly synthesized materials or compounds discovered in
                    natural sources.
                  </li>
                  <li>
                    <strong>Environmental Science:</strong> Analyzing pollutants and determining the composition of
                    environmental samples.
                  </li>
                  <li>
                    <strong>Food Chemistry:</strong> Analyzing the composition of food additives and nutritional
                    compounds.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
