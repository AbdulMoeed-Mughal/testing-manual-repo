"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Cog, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type GearType = "spur" | "helical" | "bevel" | "worm"

interface GearResult {
  gearRatio: number
  ratioText: string
  outputSpeed: number | null
  outputTorque: number | null
  mechanicalAdvantage: string
  gearType: string
}

export function GearRatioCalculator() {
  const [drivingTeeth, setDrivingTeeth] = useState("")
  const [drivenTeeth, setDrivenTeeth] = useState("")
  const [inputSpeed, setInputSpeed] = useState("")
  const [inputTorque, setInputTorque] = useState("")
  const [gearType, setGearType] = useState<GearType>("spur")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<GearResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const gearTypeLabels: Record<GearType, string> = {
    spur: "Spur Gear",
    helical: "Helical Gear",
    bevel: "Bevel Gear",
    worm: "Worm Gear",
  }

  const calculateGearRatio = () => {
    setError("")
    setResult(null)

    const t1 = Number.parseFloat(drivingTeeth)
    const t2 = Number.parseFloat(drivenTeeth)

    if (isNaN(t1) || t1 <= 0) {
      setError("Please enter a valid number of teeth for the driving gear (greater than 0)")
      return
    }

    if (isNaN(t2) || t2 <= 0) {
      setError("Please enter a valid number of teeth for the driven gear (greater than 0)")
      return
    }

    if (!Number.isInteger(t1) || !Number.isInteger(t2)) {
      setError("Number of teeth must be whole numbers")
      return
    }

    // Calculate gear ratio: GR = T2 / T1
    const gr = t2 / t1
    const roundedGR = Math.round(gr * 1000) / 1000

    // Create ratio text (simplified)
    const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b))
    const divisor = gcd(t2, t1)
    const ratioText = `${t2 / divisor}:${t1 / divisor}`

    // Calculate output speed and torque if input values are provided
    let outputSpeed: number | null = null
    let outputTorque: number | null = null

    const speedNum = Number.parseFloat(inputSpeed)
    if (!isNaN(speedNum) && speedNum > 0) {
      outputSpeed = Math.round((speedNum / gr) * 100) / 100
    }

    const torqueNum = Number.parseFloat(inputTorque)
    if (!isNaN(torqueNum) && torqueNum > 0) {
      outputTorque = Math.round(torqueNum * gr * 100) / 100
    }

    // Determine mechanical advantage
    let mechanicalAdvantage: string
    if (gr > 1) {
      mechanicalAdvantage = "Speed Reduction / Torque Multiplication"
    } else if (gr < 1) {
      mechanicalAdvantage = "Speed Increase / Torque Reduction"
    } else {
      mechanicalAdvantage = "1:1 Direct Drive"
    }

    setResult({
      gearRatio: roundedGR,
      ratioText,
      outputSpeed,
      outputTorque,
      mechanicalAdvantage,
      gearType: gearTypeLabels[gearType],
    })
  }

  const handleReset = () => {
    setDrivingTeeth("")
    setDrivenTeeth("")
    setInputSpeed("")
    setInputTorque("")
    setGearType("spur")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Gear Ratio: ${result.gearRatio} (${result.ratioText})${result.outputSpeed ? `, Output Speed: ${result.outputSpeed} RPM` : ""}${result.outputTorque ? `, Output Torque: ${result.outputTorque} Nm` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Gear Ratio Result",
          text: `I calculated a gear ratio using CalcHub! Gear Ratio: ${result.gearRatio} (${result.ratioText})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Cog className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gear Ratio Calculator</CardTitle>
                    <CardDescription>Calculate gear ratio, speed, and torque</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gear Type Selection */}
                <div className="space-y-2">
                  <Label>Gear Type</Label>
                  <Select value={gearType} onValueChange={(v) => setGearType(v as GearType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="spur">Spur Gear</SelectItem>
                      <SelectItem value="helical">Helical Gear</SelectItem>
                      <SelectItem value="bevel">Bevel Gear</SelectItem>
                      <SelectItem value="worm">Worm Gear</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Driving Gear Teeth */}
                <div className="space-y-2">
                  <Label htmlFor="drivingTeeth">Driving Gear Teeth (T₁)</Label>
                  <Input
                    id="drivingTeeth"
                    type="number"
                    placeholder="Enter number of teeth on driving gear"
                    value={drivingTeeth}
                    onChange={(e) => setDrivingTeeth(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Driven Gear Teeth */}
                <div className="space-y-2">
                  <Label htmlFor="drivenTeeth">Driven Gear Teeth (T₂)</Label>
                  <Input
                    id="drivenTeeth"
                    type="number"
                    placeholder="Enter number of teeth on driven gear"
                    value={drivenTeeth}
                    onChange={(e) => setDrivenTeeth(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Optional: Input Speed */}
                <div className="space-y-2">
                  <Label htmlFor="inputSpeed">Input Speed (RPM) - Optional</Label>
                  <Input
                    id="inputSpeed"
                    type="number"
                    placeholder="Enter input rotational speed"
                    value={inputSpeed}
                    onChange={(e) => setInputSpeed(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Optional: Input Torque */}
                <div className="space-y-2">
                  <Label htmlFor="inputTorque">Input Torque (Nm) - Optional</Label>
                  <Input
                    id="inputTorque"
                    type="number"
                    placeholder="Enter input torque"
                    value={inputTorque}
                    onChange={(e) => setInputTorque(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="showSteps" className="cursor-pointer">
                    Show Step-by-Step Solution
                  </Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateGearRatio} className="w-full" size="lg">
                  Calculate Gear Ratio
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Gear Ratio</p>
                      <p className="text-5xl font-bold text-orange-600 mb-1">{result.gearRatio}</p>
                      <p className="text-lg font-semibold text-orange-600 mb-2">{result.ratioText}</p>
                      <p className="text-sm text-muted-foreground">{result.mechanicalAdvantage}</p>
                    </div>

                    {/* Additional Results */}
                    {(result.outputSpeed !== null || result.outputTorque !== null) && (
                      <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-orange-200">
                        {result.outputSpeed !== null && (
                          <div className="text-center p-2 bg-white rounded-lg">
                            <p className="text-xs text-muted-foreground">Output Speed</p>
                            <p className="text-lg font-bold text-orange-600">{result.outputSpeed} RPM</p>
                          </div>
                        )}
                        {result.outputTorque !== null && (
                          <div className="text-center p-2 bg-white rounded-lg">
                            <p className="text-xs text-muted-foreground">Output Torque</p>
                            <p className="text-lg font-bold text-orange-600">{result.outputTorque} Nm</p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Step-by-Step Solution */}
                    {showSteps && (
                      <Collapsible defaultOpen className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            Step-by-Step Solution
                            <Info className="h-4 w-4" />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2 p-3 bg-white rounded-lg text-sm space-y-2">
                          <p>
                            <strong>Step 1:</strong> Identify the gear teeth
                          </p>
                          <p className="pl-4 text-muted-foreground">
                            Driving gear (T₁) = {drivingTeeth} teeth
                            <br />
                            Driven gear (T₂) = {drivenTeeth} teeth
                          </p>
                          <p>
                            <strong>Step 2:</strong> Apply the gear ratio formula
                          </p>
                          <p className="pl-4 font-mono text-muted-foreground">GR = T₂ / T₁</p>
                          <p>
                            <strong>Step 3:</strong> Calculate
                          </p>
                          <p className="pl-4 font-mono text-muted-foreground">
                            GR = {drivenTeeth} / {drivingTeeth} = {result.gearRatio}
                          </p>
                          {result.outputSpeed !== null && (
                            <>
                              <p>
                                <strong>Step 4:</strong> Calculate output speed
                              </p>
                              <p className="pl-4 font-mono text-muted-foreground">
                                ω_out = ω_in / GR = {inputSpeed} / {result.gearRatio} = {result.outputSpeed} RPM
                              </p>
                            </>
                          )}
                          {result.outputTorque !== null && (
                            <>
                              <p>
                                <strong>Step {result.outputSpeed !== null ? 5 : 4}:</strong> Calculate output torque
                              </p>
                              <p className="pl-4 font-mono text-muted-foreground">
                                τ_out = τ_in × GR = {inputTorque} × {result.gearRatio} = {result.outputTorque} Nm
                              </p>
                            </>
                          )}
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gear Ratio Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">GR = T₂ / T₁</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>GR</strong> = Gear Ratio
                    </p>
                    <p>
                      <strong>T₁</strong> = Teeth on driving gear (input)
                    </p>
                    <p>
                      <strong>T₂</strong> = Teeth on driven gear (output)
                    </p>
                  </div>
                  <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg mt-3">
                    <p className="text-orange-700 text-xs">
                      <strong>Speed:</strong> ω_out = ω_in / GR
                      <br />
                      <strong>Torque:</strong> τ_out = τ_in × GR
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Gear Ratios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">1:1 (Direct Drive)</span>
                      <span className="text-sm text-blue-600">No change</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">2:1 (Speed Reduction)</span>
                      <span className="text-sm text-green-600">½ speed, 2× torque</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">3:1 (High Reduction)</span>
                      <span className="text-sm text-yellow-600">⅓ speed, 3× torque</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">1:2 (Speed Increase)</span>
                      <span className="text-sm text-purple-600">2× speed, ½ torque</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gear Types</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Spur:</strong> Straight teeth, parallel shafts, simple design
                  </p>
                  <p>
                    <strong>Helical:</strong> Angled teeth, smoother operation, less noise
                  </p>
                  <p>
                    <strong>Bevel:</strong> Conical shape, intersecting shafts (typically 90°)
                  </p>
                  <p>
                    <strong>Worm:</strong> Screw-like driver, high reduction ratios, self-locking
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="mt-8">
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Gear ratio calculations are estimates. Actual performance may vary due to friction, backlash, and
                      mechanical tolerances. Consult engineering references for precise design.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Gear Ratio?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gear ratio is the relationship between the number of teeth on two meshing gears. It determines how
                  rotational speed and torque are transferred between the gears. When a smaller driving gear meshes with
                  a larger driven gear, the output speed decreases while the torque increases proportionally.
                  Conversely, when a larger gear drives a smaller one, speed increases while torque decreases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding gear ratios is essential in mechanical engineering, automotive design, robotics, and
                  industrial machinery. Engineers use gear ratios to optimize power transmission, match motor speeds to
                  load requirements, and achieve desired mechanical advantages in various applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Cog className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Gear Ratios</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gear ratios are fundamental to countless mechanical systems. In automobiles, the transmission uses
                  multiple gear ratios to provide optimal torque for acceleration and efficient cruising speeds. The
                  differential gear allows wheels to rotate at different speeds during turns while maintaining power
                  delivery.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In bicycles, the gear ratio between the chainring and sprocket determines pedaling effort versus
                  speed. Industrial machinery uses gear trains to achieve precise speed reductions for heavy-duty
                  applications. Robotics relies on gear ratios to convert high-speed motor outputs into slower, more
                  powerful movements for actuators and joints.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
