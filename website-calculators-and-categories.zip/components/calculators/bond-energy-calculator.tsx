"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Flame, Info, TrendingUp, Plus, Trash2, FlaskConical } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

// Common bond energies in kJ/mol
const BOND_ENERGIES: Record<string, number> = {
  "H-H": 436,
  "C-H": 413,
  "C-C": 348,
  "C=C": 614,
  "C≡C": 839,
  "C-O": 358,
  "C=O": 799,
  "C≡O": 1072,
  "O-H": 463,
  "O-O": 146,
  "O=O": 495,
  "N-H": 391,
  "N-N": 163,
  "N=N": 418,
  "N≡N": 945,
  "C-N": 305,
  "C=N": 615,
  "C≡N": 891,
  "Cl-Cl": 242,
  "Br-Br": 193,
  "I-I": 151,
  "H-Cl": 431,
  "H-Br": 366,
  "H-I": 299,
  "H-F": 567,
  "C-Cl": 328,
  "C-Br": 276,
  "C-I": 240,
  "C-F": 484,
  "S-S": 266,
  "S=O": 523,
  "P-O": 335,
  "Si-O": 452,
}

const BOND_TYPES = Object.keys(BOND_ENERGIES)

interface Bond {
  id: string
  type: string
  energy: number
  count: number
}

interface BondEnergyResult {
  totalBondsBroken: number
  totalBondsFormed: number
  reactionEnthalpy: number
  color: string
  bgColor: string
  type: string
}

export function BondEnergyCalculator() {
  const [bondsBroken, setBondsBroken] = useState<Bond[]>([{ id: "1", type: "", energy: 0, count: 1 }])
  const [bondsFormed, setBondsFormed] = useState<Bond[]>([{ id: "2", type: "", energy: 0, count: 1 }])
  const [result, setResult] = useState<BondEnergyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const addBondBroken = () => {
    setBondsBroken([...bondsBroken, { id: Date.now().toString(), type: "", energy: 0, count: 1 }])
  }

  const addBondFormed = () => {
    setBondsFormed([...bondsFormed, { id: Date.now().toString(), type: "", energy: 0, count: 1 }])
  }

  const removeBondBroken = (id: string) => {
    if (bondsBroken.length > 1) {
      setBondsBroken(bondsBroken.filter(b => b.id !== id))
    }
  }

  const removeBondFormed = (id: string) => {
    if (bondsFormed.length > 1) {
      setBondsFormed(bondsFormed.filter(b => b.id !== id))
    }
  }

  const updateBondBroken = (id: string, field: keyof Bond, value: string | number) => {
    setBondsBroken(bondsBroken.map(b => {
      if (b.id === id) {
        if (field === "type") {
          const bondType = value as string
          return { ...b, type: bondType, energy: BOND_ENERGIES[bondType] || 0 }
        }
        return { ...b, [field]: value }
      }
      return b
    }))
  }

  const updateBondFormed = (id: string, field: keyof Bond, value: string | number) => {
    setBondsFormed(bondsFormed.map(b => {
      if (b.id === id) {
        if (field === "type") {
          const bondType = value as string
          return { ...b, type: bondType, energy: BOND_ENERGIES[bondType] || 0 }
        }
        return { ...b, [field]: value }
      }
      return b
    }))
  }

  const calculateBondEnergy = () => {
    setError("")
    setResult(null)

    // Validate bonds broken
    for (const bond of bondsBroken) {
      if (!bond.type || bond.energy <= 0 || bond.count <= 0) {
        setError("Please complete all bond information for bonds broken")
        return
      }
    }

    // Validate bonds formed
    for (const bond of bondsFormed) {
      if (!bond.type || bond.energy <= 0 || bond.count <= 0) {
        setError("Please complete all bond information for bonds formed")
        return
      }
    }

    // Calculate total energy of bonds broken (positive - energy absorbed)
    const totalBroken = bondsBroken.reduce((sum, bond) => sum + (bond.energy * bond.count), 0)

    // Calculate total energy of bonds formed (negative - energy released)
    const totalFormed = bondsFormed.reduce((sum, bond) => sum + (bond.energy * bond.count), 0)

    // ΔH = Energy required to break bonds - Energy released when forming bonds
    const reactionEnthalpy = totalBroken - totalFormed

    let color: string
    let bgColor: string
    let type: string

    if (reactionEnthalpy < 0) {
      type = "Exothermic"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else if (reactionEnthalpy > 0) {
      type = "Endothermic"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else {
      type = "Thermoneutral"
      color = "text-gray-600"
      bgColor = "bg-gray-50 border-gray-200"
    }

    setResult({
      totalBondsBroken: Math.round(totalBroken),
      totalBondsFormed: Math.round(totalFormed),
      reactionEnthalpy: Math.round(reactionEnthalpy),
      color,
      bgColor,
      type
    })
  }

  const handleReset = () => {
    setBondsBroken([{ id: "1", type: "", energy: 0, count: 1 }])
    setBondsFormed([{ id: "2", type: "", energy: 0, count: 1 }])
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Reaction Enthalpy: ΔH = ${result.reactionEnthalpy > 0 ? '+' : ''}${result.reactionEnthalpy} kJ/mol (${result.type})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Bond Energy Calculation Result",
          text: `I calculated reaction enthalpy using CalcHub! ΔH = ${result.reactionEnthalpy > 0 ? '+' : ''}${result.reactionEnthalpy} kJ/mol (${result.type})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Bond Energy Calculator</CardTitle>
                    <CardDescription>Calculate reaction enthalpy (ΔH)</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Bonds Broken Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Bonds Broken (Reactants)</Label>
                    <Button variant="outline" size="sm" onClick={addBondBroken}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {bondsBroken.map((bond) => (
                    <div key={bond.id} className="flex gap-2 items-end">
                      <div className="flex-1 space-y-1">
                        <Label className="text-xs">Bond Type</Label>
                        <Select value={bond.type} onValueChange={(value) => updateBondBroken(bond.id, "type", value)}>
                          <SelectTrigger className="h-9">
                            <SelectValue placeholder="Select bond" />
                          </SelectTrigger>
                          <SelectContent>
                            {BOND_TYPES.map((type) => (
                              <SelectItem key={type} value={type}>
                                {type} ({BOND_ENERGIES[type]} kJ/mol)
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="w-20 space-y-1">
                        <Label className="text-xs">Count</Label>
                        <Input
                          type="number"
                          min="1"
                          value={bond.count}
                          onChange={(e) => updateBondBroken(bond.id, "count", Number.parseInt(e.target.value) || 1)}
                          className="h-9"
                        />
                      </div>
                      {bondsBroken.length > 1 && (
                        <Button variant="ghost" size="sm" onClick={() => removeBondBroken(bond.id)} className="h-9 px-2">
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                {/* Bonds Formed Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Bonds Formed (Products)</Label>
                    <Button variant="outline" size="sm" onClick={addBondFormed}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>

                  {bondsFormed.map((bond) => (
                    <div key={bond.id} className="flex gap-2 items-end">
                      <div className="flex-1 space-y-1">
                        <Label className="text-xs">Bond Type</Label>
                        <Select value={bond.type} onValueChange={(value) => updateBondFormed(bond.id, "type", value)}>
                          <SelectTrigger className="h-9">
                            <SelectValue placeholder="Select bond" />
                          </SelectTrigger>
                          <SelectContent>
                            {BOND_TYPES.map((type) => (
                              <SelectItem key={type} value={type}>
                                {type} ({BOND_ENERGIES[type]} kJ/mol)
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="w-20 space-y-1">
                        <Label className="text-xs">Count</Label>
                        <Input
                          type="number"
                          min="1"
                          value={bond.count}
                          onChange={(e) => updateBondFormed(bond.id, "count", Number.parseInt(e.target.value) || 1)}
                          className="h-9"
                        />
                      </div>
                      {bondsFormed.length > 1 && (
                        <Button variant="ghost" size="sm" onClick={() => removeBondFormed(bond.id)} className="h-9 px-2">
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBondEnergy} className="w-full" size="lg">
                  Calculate ΔH
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Reaction Enthalpy</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>
                        {result.reactionEnthalpy > 0 ? '+' : ''}{result.reactionEnthalpy}
                      </p>
                      <p className="text-sm text-muted-foreground mb-1">kJ/mol</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.type}</p>
                      
                      {/* Energy Breakdown */}
                      <div className="mt-4 pt-4 border-t border-current/20 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Bonds Broken:</span>
                          <span className="font-mono font-medium">+{result.totalBondsBroken} kJ/mol</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Bonds Formed:</span>
                          <span className="font-mono font-medium">−{result.totalBondsFormed} kJ/mol</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Reaction Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Exothermic</span>
                      <span className="text-sm text-red-600">ΔH {"< 0"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <span className="font-medium text-gray-700">Thermoneutral</span>
                      <span className="text-sm text-gray-600">ΔH = 0</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Endothermic</span>
                      <span className="text-sm text-blue-600">ΔH {">"} 0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Enthalpy Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ΔH = Σ(Broken) − Σ(Formed)</p>
                  </div>
                  <p>
                    Reaction enthalpy equals the total energy of bonds broken minus the total energy of bonds formed.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Bond Strengths</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>H-H:</span>
                      <span className="font-mono">436 kJ/mol</span>
                    </div>
                    <div className="flex justify-between">
                      <span>C=C:</span>
                      <span className="font-mono">614 kJ/mol</span>
                    </div>
                    <div className="flex justify-between">
                      <span>O=O:</span>
                      <span className="font-mono">495 kJ/mol</span>
                    </div>
                    <div className="flex justify-between">
                      <span>N≡N:</span>
                      <span className="font-mono">945 kJ/mol</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Bond Energy */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Bond Energy?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bond energy, also called bond dissociation energy or bond enthalpy, is the amount of energy required to break one mole of a particular chemical bond in the gas phase. It represents the strength of a chemical bond and is always a positive value because energy must be supplied to break bonds. Bond energies are typically measured in kilojoules per mole (kJ/mol) or kilocalories per mole (kcal/mol).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Different types of bonds have characteristic energy values. Triple bonds (like C≡C or N≡N) are generally stronger than double bonds (C=C, O=O), which are stronger than single bonds (C-C, O-O). The bond energy depends on the types of atoms involved, the bond order, and the molecular environment. Understanding bond energies is fundamental to predicting reaction energetics and molecular stability.
                </p>
              </CardContent>
            </Card>

            {/* Calculating Reaction Enthalpy */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Calculating Reaction Enthalpy Using Bond Energies</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The enthalpy change (ΔH) of a chemical reaction can be estimated using average bond energies. The fundamental principle is that energy is required to break bonds (endothermic process) and energy is released when bonds form (exothermic process). The overall reaction enthalpy is the difference between these two quantities.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Exothermic Reactions (ΔH {"< 0"})</h4>
                    <p className="text-red-700 text-sm">
                      When more energy is released during bond formation than is consumed during bond breaking, the reaction is exothermic and releases heat to the surroundings. Combustion reactions, many oxidation reactions, and neutralization reactions are typically exothermic. The negative ΔH value indicates net energy release.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Endothermic Reactions (ΔH {">"} 0)</h4>
                    <p className="text-blue-700 text-sm">
                      When more energy is required to break bonds than is released during bond formation, the reaction is endothermic and absorbs heat from the surroundings. Photosynthesis, thermal decomposition reactions, and many dissociation reactions are endothermic. The positive ΔH value indicates net energy absorption.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Bond Energy Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bond energy calculations have numerous practical applications across chemistry and engineering. They help predict whether reactions will be thermodynamically favorable, estimate heat released or absorbed in industrial processes, and design energy-efficient chemical syntheses. In fuel chemistry, bond energies help calculate the energy content of different fuels and compare their efficiency.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Chemical engineers use bond energy data to design reactors with appropriate heating or cooling systems. Environmental scientists apply these principles to understand atmospheric chemistry and pollution reactions. In biochemistry, bond energy considerations help explain metabolic pathways and how organisms extract energy from nutrients. Material scientists use bond energies to predict the stability and reactivity of new compounds and polymers.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Note:</strong> Bond energy calculations are approximate and based on average values. Actual energies depend on molecular environment, resonance, and other factors. Results provide estimates rather than precise thermodynamic values. For accurate enthalpy changes, use experimentally determined values or more sophisticated computational methods.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
