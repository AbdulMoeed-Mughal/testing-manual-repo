"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Target,
  Info,
  CheckCircle2,
  XCircle,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface GradeScale {
  grade: string
  minPercentage: number
  color: string
}

const defaultGradeScale: GradeScale[] = [
  { grade: "A+", minPercentage: 97, color: "text-emerald-600" },
  { grade: "A", minPercentage: 93, color: "text-emerald-600" },
  { grade: "A-", minPercentage: 90, color: "text-emerald-500" },
  { grade: "B+", minPercentage: 87, color: "text-blue-600" },
  { grade: "B", minPercentage: 83, color: "text-blue-600" },
  { grade: "B-", minPercentage: 80, color: "text-blue-500" },
  { grade: "C+", minPercentage: 77, color: "text-yellow-600" },
  { grade: "C", minPercentage: 73, color: "text-yellow-600" },
  { grade: "C-", minPercentage: 70, color: "text-yellow-500" },
  { grade: "D+", minPercentage: 67, color: "text-orange-600" },
  { grade: "D", minPercentage: 63, color: "text-orange-600" },
  { grade: "D-", minPercentage: 60, color: "text-orange-500" },
  { grade: "F", minPercentage: 0, color: "text-red-600" },
]

export function RequiredFinalScoreCalculator() {
  const [currentGrade, setCurrentGrade] = useState<string>("85")
  const [desiredGrade, setDesiredGrade] = useState<string>("90")
  const [finalWeight, setFinalWeight] = useState<string>("30")
  const [showGradeScale, setShowGradeScale] = useState(false)
  const [showBreakdown, setShowBreakdown] = useState(false)
  const [copied, setCopied] = useState(false)

  const current = Number.parseFloat(currentGrade) || 0
  const desired = Number.parseFloat(desiredGrade) || 0
  const weight = Number.parseFloat(finalWeight) || 0

  const calculateRequiredScore = () => {
    if (weight <= 0 || weight > 100) return null
    const weightDecimal = weight / 100
    return (desired - current * (1 - weightDecimal)) / weightDecimal
  }

  const requiredScore = calculateRequiredScore()

  const getFeasibilityStatus = () => {
    if (requiredScore === null)
      return { status: "invalid", message: "Invalid inputs", color: "text-muted-foreground", bgColor: "bg-muted" }
    if (requiredScore <= 0)
      return {
        status: "guaranteed",
        message: "Already achieved!",
        color: "text-green-600",
        bgColor: "bg-green-50 border-green-200",
      }
    if (requiredScore <= 60)
      return {
        status: "easy",
        message: "Easily achievable",
        color: "text-green-600",
        bgColor: "bg-green-50 border-green-200",
      }
    if (requiredScore <= 80)
      return {
        status: "moderate",
        message: "Achievable with effort",
        color: "text-blue-600",
        bgColor: "bg-blue-50 border-blue-200",
      }
    if (requiredScore <= 100)
      return {
        status: "challenging",
        message: "Challenging but possible",
        color: "text-yellow-600",
        bgColor: "bg-yellow-50 border-yellow-200",
      }
    if (requiredScore <= 110)
      return {
        status: "difficult",
        message: "Very difficult",
        color: "text-orange-600",
        bgColor: "bg-orange-50 border-orange-200",
      }
    return {
      status: "impossible",
      message: "Not achievable",
      color: "text-red-600",
      bgColor: "bg-red-50 border-red-200",
    }
  }

  const feasibility = getFeasibilityStatus()

  const getLetterGrade = (percentage: number) => {
    for (const grade of defaultGradeScale) {
      if (percentage >= grade.minPercentage) {
        return grade
      }
    }
    return defaultGradeScale[defaultGradeScale.length - 1]
  }

  const currentLetterGrade = getLetterGrade(current)
  const desiredLetterGrade = getLetterGrade(desired)

  const handleReset = () => {
    setCurrentGrade("85")
    setDesiredGrade("90")
    setFinalWeight("30")
    setShowGradeScale(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (requiredScore === null) return
    const text = `Required Final Score: ${requiredScore <= 0 ? "Already achieved!" : `${requiredScore.toFixed(2)}%`}`
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShare = async () => {
    if (requiredScore === null) return
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Required Final Score",
          text: `I need to score ${requiredScore <= 0 ? "nothing more" : `${requiredScore.toFixed(1)}%`} on my final exam to get ${desired}%!`,
          url: window.location.href,
        })
      } catch {
        // User cancelled
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/education-learning">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Education & Learning
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                    <Target className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Required Final Score</CardTitle>
                    <CardDescription>Calculate score needed on final exam</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Inputs */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="current" className="text-xs">
                      Current Grade (%)
                    </Label>
                    <Input
                      id="current"
                      type="number"
                      value={currentGrade}
                      onChange={(e) => setCurrentGrade(e.target.value)}
                      placeholder="85"
                      min="0"
                      max="100"
                    />
                    {current > 0 && <p className={`text-xs ${currentLetterGrade.color}`}>{currentLetterGrade.grade}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="desired" className="text-xs">
                      Desired Grade (%)
                    </Label>
                    <Input
                      id="desired"
                      type="number"
                      value={desiredGrade}
                      onChange={(e) => setDesiredGrade(e.target.value)}
                      placeholder="90"
                      min="0"
                      max="100"
                    />
                    {desired > 0 && <p className={`text-xs ${desiredLetterGrade.color}`}>{desiredLetterGrade.grade}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weight" className="text-xs">
                      Final Weight (%)
                    </Label>
                    <Input
                      id="weight"
                      type="number"
                      value={finalWeight}
                      onChange={(e) => setFinalWeight(e.target.value)}
                      placeholder="30"
                      min="1"
                      max="100"
                    />
                    <p className="text-xs text-muted-foreground">Coursework: {100 - weight}%</p>
                  </div>
                </div>

                {/* Grade Scale Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Info className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Show grade scale reference</span>
                  </div>
                  <Switch checked={showGradeScale} onCheckedChange={setShowGradeScale} />
                </div>

                {showGradeScale && (
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="grid grid-cols-4 gap-2 text-xs">
                      {defaultGradeScale.slice(0, 8).map((grade) => (
                        <div key={grade.grade} className={`p-2 bg-background rounded text-center ${grade.color}`}>
                          <div className="font-semibold">{grade.grade}</div>
                          <div className="text-muted-foreground">{grade.minPercentage}%+</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Result */}
                {requiredScore !== null && (
                  <div className={`p-4 rounded-xl border-2 ${feasibility.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        {feasibility.status === "guaranteed" || feasibility.status === "easy" ? (
                          <CheckCircle2 className="h-5 w-5 text-green-600" />
                        ) : feasibility.status === "impossible" ? (
                          <XCircle className="h-5 w-5 text-red-600" />
                        ) : (
                          <AlertTriangle className={`h-5 w-5 ${feasibility.color}`} />
                        )}
                        <span className={`text-sm font-medium ${feasibility.color}`}>{feasibility.message}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">Required Final Exam Score</p>
                      <p className={`text-5xl font-bold ${feasibility.color} mb-2`}>
                        {requiredScore <= 0
                          ? "0%"
                          : requiredScore > 100
                            ? `${requiredScore.toFixed(1)}%`
                            : `${requiredScore.toFixed(1)}%`}
                      </p>
                      {requiredScore > 0 && requiredScore <= 100 && (
                        <p className="text-sm text-muted-foreground">
                          Letter grade needed:{" "}
                          <span className={getLetterGrade(requiredScore).color}>
                            {getLetterGrade(requiredScore).grade}
                          </span>
                        </p>
                      )}
                    </div>

                    {/* Progress Bar */}
                    <div className="mt-4 space-y-1">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>0%</span>
                        <span>50%</span>
                        <span>100%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            requiredScore <= 60
                              ? "bg-green-500"
                              : requiredScore <= 80
                                ? "bg-blue-500"
                                : requiredScore <= 100
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                          }`}
                          style={{ width: `${Math.min(Math.max(requiredScore, 0), 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3 text-muted-foreground">
                          {showBreakdown ? "Hide" : "Show"} Calculation
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="p-3 bg-background/50 rounded text-sm space-y-2">
                          <p className="font-mono text-xs">Required = (Desired - Current × (1 - Weight)) ÷ Weight</p>
                          <p className="font-mono text-xs">
                            = ({desired} - {current} × {(1 - weight / 100).toFixed(2)}) ÷ {(weight / 100).toFixed(2)}
                          </p>
                          <p className="font-mono text-xs font-semibold">= {requiredScore.toFixed(2)}%</p>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* What-If Scenarios */}
                {requiredScore !== null && requiredScore > 0 && requiredScore <= 100 && (
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <h4 className="text-sm font-medium mb-2">What-If Scenarios</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      {[60, 70, 80, 90, 100].map((score) => {
                        const finalGrade = current * (1 - weight / 100) + score * (weight / 100)
                        const gradeInfo = getLetterGrade(finalGrade)
                        return (
                          <div
                            key={score}
                            className={`p-2 bg-background rounded border flex justify-between items-center ${
                              Math.ceil(requiredScore) === score ? "ring-2 ring-indigo-500" : ""
                            }`}
                          >
                            <span className="text-muted-foreground">Score {score}%:</span>
                            <span className={`font-medium ${gradeInfo.color}`}>
                              {finalGrade.toFixed(1)}% ({gradeInfo.grade})
                            </span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Current grade represents coursework done so far</p>
                  <p>• Final exam weight is % it counts toward total grade</p>
                  <p>• Formula calculates exact score needed for your goal</p>
                  <p>• Scores above 100% may not be achievable</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tips for Success</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Start studying early to reduce stress</p>
                  <p>• Focus on topics that carry more weight</p>
                  <p>• Check if extra credit opportunities exist</p>
                  <p>• Ask about grade rounding policies</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-xs">
                    <p className="font-semibold text-foreground">
                      Required = (Desired - Current × (1 - Weight)) ÷ Weight
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Final Exam Impact</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Your final exam can significantly impact your overall course grade, especially when it carries
                  substantial weight (20-40% is common). This calculator helps you understand exactly what score you
                  need to achieve your desired grade, allowing you to set realistic goals and plan your study time
                  effectively.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  If the required score is above 100%, it means achieving your desired grade is mathematically
                  impossible with the final exam alone. In such cases, consider speaking with your instructor about
                  extra credit opportunities or reassessing your grade expectations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
