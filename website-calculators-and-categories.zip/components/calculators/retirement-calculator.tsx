"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, PiggyBank, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const CURRENCIES = [
  { code: "USD", symbol: "$", name: "US Dollar", locale: "en-US" },
  { code: "EUR", symbol: "€", name: "Euro", locale: "de-DE" },
  { code: "GBP", symbol: "£", name: "British Pound", locale: "en-GB" },
  { code: "INR", symbol: "₹", name: "Indian Rupee", locale: "en-IN" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen", locale: "ja-JP" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar", locale: "en-CA" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar", locale: "en-AU" },
]

interface RetirementResult {
  yearsToRetirement: number
  retirementDuration: number
  monthlyExpenseAtRetirement: number
  annualExpenseAtRetirement: number
  requiredCorpus: number
  futureValueCurrentSavings: number
  futureValueContributions: number
  totalSavingsAtRetirement: number
  surplus: number
  isShortfall: boolean
  monthlyIncomePostRetirement: number
}

export function RetirementCalculator() {
  const [currentAge, setCurrentAge] = useState("")
  const [retirementAge, setRetirementAge] = useState("")
  const [lifeExpectancy, setLifeExpectancy] = useState("")
  const [monthlyExpenses, setMonthlyExpenses] = useState("")
  const [inflationRate, setInflationRate] = useState("6")
  const [currentSavings, setCurrentSavings] = useState("")
  const [monthlyContribution, setMonthlyContribution] = useState("")
  const [preRetirementReturn, setPreRetirementReturn] = useState("10")
  const [postRetirementReturn, setPostRetirementReturn] = useState("6")
  const [currency, setCurrency] = useState("USD")
  const [result, setResult] = useState<RetirementResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatCurrency = (value: number): string => {
    const currencyConfig = CURRENCIES.find((c) => c.code === currency) || CURRENCIES[0]

    // Special formatting for Indian Rupee (lakhs and crores)
    if (currency === "INR") {
      if (value >= 10000000) {
        return `${currencyConfig.symbol}${(value / 10000000).toFixed(2)} Cr`
      } else if (value >= 100000) {
        return `${currencyConfig.symbol}${(value / 100000).toFixed(2)} L`
      }
      return `${currencyConfig.symbol}${value.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`
    }

    // Standard formatting for other currencies
    if (value >= 1000000000) {
      return `${currencyConfig.symbol}${(value / 1000000000).toFixed(2)}B`
    } else if (value >= 1000000) {
      return `${currencyConfig.symbol}${(value / 1000000).toFixed(2)}M`
    } else if (value >= 1000) {
      return `${currencyConfig.symbol}${(value / 1000).toFixed(2)}K`
    }
    return `${currencyConfig.symbol}${value.toLocaleString(currencyConfig.locale, { maximumFractionDigits: 0 })}`
  }

  const getCurrencySymbol = (): string => {
    const currencyConfig = CURRENCIES.find((c) => c.code === currency) || CURRENCIES[0]
    return currencyConfig.symbol
  }

  const calculateRetirement = () => {
    setError("")
    setResult(null)

    const currentAgeNum = Number.parseInt(currentAge)
    const retirementAgeNum = Number.parseInt(retirementAge)
    const lifeExpectancyNum = Number.parseInt(lifeExpectancy)
    const monthlyExpensesNum = Number.parseFloat(monthlyExpenses)
    const inflationRateNum = Number.parseFloat(inflationRate) / 100
    const currentSavingsNum = Number.parseFloat(currentSavings) || 0
    const monthlyContributionNum = Number.parseFloat(monthlyContribution) || 0
    const preRetirementReturnNum = Number.parseFloat(preRetirementReturn) / 100
    const postRetirementReturnNum = Number.parseFloat(postRetirementReturn) / 100

    // Validation
    if (isNaN(currentAgeNum) || currentAgeNum < 18 || currentAgeNum > 100) {
      setError("Please enter a valid current age (18-100)")
      return
    }
    if (isNaN(retirementAgeNum) || retirementAgeNum <= currentAgeNum) {
      setError("Retirement age must be greater than current age")
      return
    }
    if (isNaN(lifeExpectancyNum) || lifeExpectancyNum <= retirementAgeNum) {
      setError("Life expectancy must be greater than retirement age")
      return
    }
    if (isNaN(monthlyExpensesNum) || monthlyExpensesNum <= 0) {
      setError("Please enter valid monthly expenses")
      return
    }
    if (inflationRateNum < 0) {
      setError("Inflation rate cannot be negative")
      return
    }
    if (preRetirementReturnNum < 0 || postRetirementReturnNum < 0) {
      setError("Return rates cannot be negative")
      return
    }

    // Calculations
    const yearsToRetirement = retirementAgeNum - currentAgeNum
    const retirementDuration = lifeExpectancyNum - retirementAgeNum

    // Inflation-adjusted monthly expense at retirement
    const monthlyExpenseAtRetirement = monthlyExpensesNum * Math.pow(1 + inflationRateNum, yearsToRetirement)
    const annualExpenseAtRetirement = monthlyExpenseAtRetirement * 12

    // Required retirement corpus (considering post-retirement inflation and returns)
    // Using present value of annuity formula for retirement duration
    const realReturnRate = (1 + postRetirementReturnNum) / (1 + inflationRateNum) - 1
    let requiredCorpus: number
    if (realReturnRate === 0) {
      requiredCorpus = annualExpenseAtRetirement * retirementDuration
    } else {
      requiredCorpus =
        annualExpenseAtRetirement * ((1 - Math.pow(1 + realReturnRate, -retirementDuration)) / realReturnRate)
    }

    // Future value of current savings
    const futureValueCurrentSavings = currentSavingsNum * Math.pow(1 + preRetirementReturnNum, yearsToRetirement)

    // Future value of monthly contributions (using monthly compounding)
    const monthlyRate = preRetirementReturnNum / 12
    const totalMonths = yearsToRetirement * 12
    let futureValueContributions = 0
    if (monthlyRate > 0) {
      futureValueContributions =
        monthlyContributionNum * ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate) * (1 + monthlyRate)
    } else {
      futureValueContributions = monthlyContributionNum * totalMonths
    }

    const totalSavingsAtRetirement = futureValueCurrentSavings + futureValueContributions
    const surplus = totalSavingsAtRetirement - requiredCorpus
    const isShortfall = surplus < 0

    // Post-retirement monthly income estimate
    const monthlyIncomePostRetirement = totalSavingsAtRetirement * (postRetirementReturnNum / 12)

    setResult({
      yearsToRetirement,
      retirementDuration,
      monthlyExpenseAtRetirement,
      annualExpenseAtRetirement,
      requiredCorpus,
      futureValueCurrentSavings,
      futureValueContributions,
      totalSavingsAtRetirement,
      surplus,
      isShortfall,
      monthlyIncomePostRetirement,
    })
  }

  const handleReset = () => {
    setCurrentAge("")
    setRetirementAge("")
    setLifeExpectancy("")
    setMonthlyExpenses("")
    setInflationRate("6")
    setCurrentSavings("")
    setMonthlyContribution("")
    setPreRetirementReturn("10")
    setPostRetirementReturn("6")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Retirement Plan Summary:
Years to Retirement: ${result.yearsToRetirement}
Required Corpus: ${formatCurrency(result.requiredCorpus)}
Estimated Savings: ${formatCurrency(result.totalSavingsAtRetirement)}
${result.isShortfall ? "Shortfall" : "Surplus"}: ${formatCurrency(Math.abs(result.surplus))}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Retirement Plan",
          text: `I calculated my retirement plan using CalcHub! Required corpus: ${formatCurrency(result.requiredCorpus)}, Estimated savings: ${formatCurrency(result.totalSavingsAtRetirement)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <PiggyBank className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Retirement Calculator</CardTitle>
                    <CardDescription>Plan your retirement corpus and savings</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Currency</Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CURRENCIES.map((curr) => (
                        <SelectItem key={curr.code} value={curr.code}>
                          {curr.symbol} - {curr.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Age Inputs */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="currentAge">Current Age</Label>
                    <Input
                      id="currentAge"
                      type="number"
                      placeholder="30"
                      value={currentAge}
                      onChange={(e) => setCurrentAge(e.target.value)}
                      min="18"
                      max="100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="retirementAge">Retire At</Label>
                    <Input
                      id="retirementAge"
                      type="number"
                      placeholder="60"
                      value={retirementAge}
                      onChange={(e) => setRetirementAge(e.target.value)}
                      min="18"
                      max="100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lifeExpectancy">Life Exp.</Label>
                    <Input
                      id="lifeExpectancy"
                      type="number"
                      placeholder="85"
                      value={lifeExpectancy}
                      onChange={(e) => setLifeExpectancy(e.target.value)}
                      min="18"
                      max="120"
                    />
                  </div>
                </div>

                {/* Monthly Expenses */}
                <div className="space-y-2">
                  <Label htmlFor="monthlyExpenses">Current Monthly Expenses ({getCurrencySymbol()})</Label>
                  <Input
                    id="monthlyExpenses"
                    type="number"
                    placeholder="5000"
                    value={monthlyExpenses}
                    onChange={(e) => setMonthlyExpenses(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Inflation Rate */}
                <div className="space-y-2">
                  <Label htmlFor="inflationRate">Expected Inflation Rate (%)</Label>
                  <Input
                    id="inflationRate"
                    type="number"
                    placeholder="6"
                    value={inflationRate}
                    onChange={(e) => setInflationRate(e.target.value)}
                    min="0"
                    max="20"
                    step="0.1"
                  />
                </div>

                {/* Current Savings & Contribution */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="currentSavings">Current Savings ({getCurrencySymbol()})</Label>
                    <Input
                      id="currentSavings"
                      type="number"
                      placeholder="50000"
                      value={currentSavings}
                      onChange={(e) => setCurrentSavings(e.target.value)}
                      min="0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="monthlyContribution">Monthly SIP ({getCurrencySymbol()})</Label>
                    <Input
                      id="monthlyContribution"
                      type="number"
                      placeholder="1000"
                      value={monthlyContribution}
                      onChange={(e) => setMonthlyContribution(e.target.value)}
                      min="0"
                    />
                  </div>
                </div>

                {/* Return Rates */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="preRetirementReturn">Pre-Retirement Return (%)</Label>
                    <Input
                      id="preRetirementReturn"
                      type="number"
                      placeholder="10"
                      value={preRetirementReturn}
                      onChange={(e) => setPreRetirementReturn(e.target.value)}
                      min="0"
                      max="30"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="postRetirementReturn">Post-Retirement Return (%)</Label>
                    <Input
                      id="postRetirementReturn"
                      type="number"
                      placeholder="6"
                      value={postRetirementReturn}
                      onChange={(e) => setPostRetirementReturn(e.target.value)}
                      min="0"
                      max="20"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRetirement} className="w-full" size="lg">
                  Calculate Retirement Plan
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.isShortfall ? "bg-red-50 border-red-200" : "bg-green-50 border-green-200"
                    }`}
                  >
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.isShortfall ? "Retirement Shortfall" : "Retirement Surplus"}
                      </p>
                      <p className={`text-4xl font-bold ${result.isShortfall ? "text-red-600" : "text-green-600"}`}>
                        {formatCurrency(Math.abs(result.surplus))}
                      </p>
                    </div>

                    {/* Key Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Required Corpus</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.requiredCorpus)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Estimated Savings</p>
                        <p className="font-semibold text-foreground">
                          {formatCurrency(result.totalSavingsAtRetirement)}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Monthly at Retirement</p>
                        <p className="font-semibold text-foreground">
                          {formatCurrency(result.monthlyExpenseAtRetirement)}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Years to Retire</p>
                        <p className="font-semibold text-foreground">{result.yearsToRetirement} years</p>
                      </div>
                    </div>

                    {/* Breakdown */}
                    <div className="p-3 bg-white rounded-lg space-y-2 text-sm mb-4">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Current Savings Growth</span>
                        <span className="font-medium">{formatCurrency(result.futureValueCurrentSavings)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">SIP Contributions Growth</span>
                        <span className="font-medium">{formatCurrency(result.futureValueContributions)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Retirement Duration</span>
                        <span className="font-medium">{result.retirementDuration} years</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Est. Monthly Income (Interest)</span>
                        <span className="font-medium">{formatCurrency(result.monthlyIncomePostRetirement)}</span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Assumptions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-700 text-sm">Pre-Retirement Growth</p>
                      <p className="text-xs text-green-600 mt-1">
                        Higher returns expected from equity-heavy portfolio during accumulation phase
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700 text-sm">Post-Retirement Growth</p>
                      <p className="text-xs text-blue-600 mt-1">
                        Conservative returns from debt-heavy portfolio for capital preservation
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-700 text-sm">Inflation Impact</p>
                      <p className="text-xs text-amber-600 mt-1">
                        Your expenses will grow with inflation over time, eroding purchasing power
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Retirement Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-mono text-xs">Future Expense = Current × (1 + inflation)^years</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-mono text-xs">Corpus = Expense × ((1 - (1+r)^-n) / r)</p>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Where r = real return rate (post-retirement return adjusted for inflation) and n = retirement
                      duration in years
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
                    <div>
                      <p className="font-medium text-amber-800 text-sm">Disclaimer</p>
                      <p className="text-xs text-amber-700 mt-1">
                        This calculator provides estimates only. Actual results may vary based on market conditions,
                        personal circumstances, and other factors. Consult a financial advisor for personalized advice.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <Card className="mt-8 shadow-lg border-0">
            <CardHeader>
              <CardTitle className="text-2xl">Understanding Retirement Planning</CardTitle>
              <CardDescription>Everything you need to know about planning for a secure retirement</CardDescription>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none">
              <h3 className="text-lg font-semibold mt-4 mb-2">What is Retirement Planning?</h3>
              <p className="text-muted-foreground mb-4">
                Retirement planning is the process of determining your retirement income goals and the actions necessary
                to achieve those goals. It involves identifying sources of income, estimating expenses, implementing a
                savings program, and managing assets and risk. The earlier you start planning, the more time your money
                has to grow through the power of compound interest.
              </p>

              <h3 className="text-lg font-semibold mt-6 mb-2">How is Retirement Corpus Calculated?</h3>
              <p className="text-muted-foreground mb-4">
                The retirement corpus is calculated based on your expected expenses at retirement, adjusted for
                inflation, and the duration you need those funds to last. The calculator uses the present value of
                annuity formula to determine how much you need at retirement to sustain your lifestyle. It considers
                both the growth of your expenses due to inflation and the returns you can earn on your corpus
                post-retirement.
              </p>

              <h3 className="text-lg font-semibold mt-6 mb-2">Key Factors Affecting Retirement Planning</h3>
              <p className="text-muted-foreground mb-2">Several factors influence your retirement plan:</p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-1 mb-4">
                <li>
                  <strong>Time Horizon:</strong> The number of years until retirement significantly impacts how much you
                  need to save monthly
                </li>
                <li>
                  <strong>Inflation Rate:</strong> Even moderate inflation can dramatically increase your future
                  expenses over decades
                </li>
                <li>
                  <strong>Expected Returns:</strong> Higher returns during accumulation phase can reduce required
                  monthly savings
                </li>
                <li>
                  <strong>Life Expectancy:</strong> Planning for a longer retirement ensures you don't outlive your
                  savings
                </li>
                <li>
                  <strong>Lifestyle Expenses:</strong> Your current and expected lifestyle determines the corpus needed
                </li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-2">The 4% Rule Explained</h3>
              <p className="text-muted-foreground mb-4">
                A popular retirement guideline is the 4% rule, which suggests you can withdraw 4% of your retirement
                corpus annually (adjusted for inflation) without running out of money over a 30-year retirement. For
                example, if you have a corpus of $1,000,000, you could withdraw $40,000 in the first year. However, this
                rule has limitations and may need adjustment based on market conditions, personal circumstances, and
                your specific retirement duration.
              </p>

              <h3 className="text-lg font-semibold mt-6 mb-2">Tips for Successful Retirement Planning</h3>
              <ul className="list-disc pl-6 text-muted-foreground space-y-1">
                <li>
                  <strong>Start Early:</strong> Even small contributions in your 20s can grow significantly due to
                  compound interest
                </li>
                <li>
                  <strong>Maximize Tax-Advantaged Accounts:</strong> Use 401(k), IRA, or equivalent accounts in your
                  country for tax benefits
                </li>
                <li>
                  <strong>Diversify Investments:</strong> Spread your investments across different asset classes to
                  manage risk
                </li>
                <li>
                  <strong>Review Regularly:</strong> Reassess your retirement plan annually and adjust contributions as
                  needed
                </li>
                <li>
                  <strong>Consider Healthcare Costs:</strong> Factor in rising healthcare expenses, especially in later
                  years
                </li>
                <li>
                  <strong>Plan for Contingencies:</strong> Maintain an emergency fund separate from retirement savings
                </li>
                <li>
                  <strong>Reduce Debt:</strong> Aim to enter retirement debt-free, especially high-interest debt
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
