"use client"

import { useState, useCallback } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  Plus,
  Trash2,
  Hash,
  Grid3X3,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type OperationType = "lcm" | "gcd" | "both"

interface Result {
  lcm: bigint | null
  gcd: bigint | null
  primeFactors: Map<number, Map<number, number>>
  steps: string[]
}

export function LCMGCDCalculator() {
  const [numbers, setNumbers] = useState<string[]>(["", ""])
  const [operation, setOperation] = useState<OperationType>("both")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Prime factorization
  const primeFactorize = useCallback((n: number): Map<number, number> => {
    const factors = new Map<number, number>()
    let num = Math.abs(n)

    for (let i = 2; i * i <= num; i++) {
      while (num % i === 0) {
        factors.set(i, (factors.get(i) || 0) + 1)
        num = Math.floor(num / i)
      }
    }

    if (num > 1) {
      factors.set(num, 1)
    }

    return factors
  }, [])

  // Euclidean algorithm for GCD
  const gcdTwo = useCallback((a: bigint, b: bigint): bigint => {
    a = a < 0n ? -a : a
    b = b < 0n ? -b : b
    while (b !== 0n) {
      const temp = b
      b = a % b
      a = temp
    }
    return a
  }, [])

  // LCM using GCD
  const lcmTwo = useCallback(
    (a: bigint, b: bigint): bigint => {
      if (a === 0n || b === 0n) return 0n
      const absA = a < 0n ? -a : a
      const absB = b < 0n ? -b : b
      return (absA * absB) / gcdTwo(absA, absB)
    },
    [gcdTwo],
  )

  // GCD of multiple numbers
  const gcdMultiple = useCallback(
    (nums: bigint[]): bigint => {
      return nums.reduce((acc, num) => gcdTwo(acc, num), nums[0])
    },
    [gcdTwo],
  )

  // LCM of multiple numbers
  const lcmMultiple = useCallback(
    (nums: bigint[]): bigint => {
      return nums.reduce((acc, num) => lcmTwo(acc, num), nums[0])
    },
    [lcmTwo],
  )

  const calculate = () => {
    setError("")
    setResult(null)

    // Parse and validate numbers
    const parsedNumbers: number[] = []
    const bigIntNumbers: bigint[] = []

    for (let i = 0; i < numbers.length; i++) {
      const trimmed = numbers[i].trim()
      if (trimmed === "") {
        setError(`Please enter a value for number ${i + 1}`)
        return
      }

      const num = Number.parseInt(trimmed, 10)
      if (isNaN(num)) {
        setError(`"${trimmed}" is not a valid integer`)
        return
      }

      if (num <= 0) {
        setError("All numbers must be positive integers greater than 0")
        return
      }

      if (num > 1e15) {
        setError("Numbers must be less than or equal to 1,000,000,000,000,000")
        return
      }

      parsedNumbers.push(num)
      bigIntNumbers.push(BigInt(num))
    }

    // Calculate GCD and LCM
    const steps: string[] = []
    let gcdResult: bigint | null = null
    let lcmResult: bigint | null = null
    const primeFactors = new Map<number, Map<number, number>>()

    // Get prime factorization for each number
    parsedNumbers.forEach((num, idx) => {
      const factors = primeFactorize(num)
      primeFactors.set(num, factors)

      if (factors.size > 0) {
        const factorStr = Array.from(factors.entries())
          .map(([prime, exp]) => (exp > 1 ? `${prime}^${exp}` : `${prime}`))
          .join(" × ")
        steps.push(`${num} = ${factorStr}`)
      } else {
        steps.push(`${num} = 1`)
      }
    })

    if (operation === "gcd" || operation === "both") {
      gcdResult = gcdMultiple(bigIntNumbers)

      // Add GCD steps using Euclidean algorithm
      if (bigIntNumbers.length === 2) {
        const [a, b] = bigIntNumbers
        let tempA = a < 0n ? -a : a
        let tempB = b < 0n ? -b : b
        steps.push("")
        steps.push("GCD using Euclidean algorithm:")
        while (tempB !== 0n) {
          const quotient = tempA / tempB
          const remainder = tempA % tempB
          steps.push(`${tempA} = ${quotient} × ${tempB} + ${remainder}`)
          tempA = tempB
          tempB = remainder
        }
        steps.push(`GCD = ${gcdResult}`)
      }
    }

    if (operation === "lcm" || operation === "both") {
      lcmResult = lcmMultiple(bigIntNumbers)

      steps.push("")
      steps.push("LCM using formula: LCM(a,b) = |a × b| / GCD(a,b)")
      if (bigIntNumbers.length === 2) {
        const [a, b] = bigIntNumbers
        const gcd = gcdTwo(a, b)
        steps.push(`LCM = |${a} × ${b}| / ${gcd}`)
        steps.push(`LCM = ${a * b < 0n ? -(a * b) : a * b} / ${gcd}`)
        steps.push(`LCM = ${lcmResult}`)
      }
    }

    setResult({
      lcm: lcmResult,
      gcd: gcdResult,
      primeFactors,
      steps,
    })
  }

  const addNumber = () => {
    if (numbers.length < 10) {
      setNumbers([...numbers, ""])
    }
  }

  const removeNumber = (index: number) => {
    if (numbers.length > 2) {
      const newNumbers = numbers.filter((_, i) => i !== index)
      setNumbers(newNumbers)
    }
  }

  const updateNumber = (index: number, value: string) => {
    const newNumbers = [...numbers]
    newNumbers[index] = value
    setNumbers(newNumbers)
  }

  const handleReset = () => {
    setNumbers(["", ""])
    setOperation("both")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = `Numbers: ${numbers.filter((n) => n.trim()).join(", ")}\n`
      if (result.gcd !== null) text += `GCD: ${result.gcd}\n`
      if (result.lcm !== null) text += `LCM: ${result.lcm}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      let text = `LCM/GCD Calculator Result\nNumbers: ${numbers.filter((n) => n.trim()).join(", ")}\n`
      if (result.gcd !== null) text += `GCD: ${result.gcd}\n`
      if (result.lcm !== null) text += `LCM: ${result.lcm}`
      try {
        await navigator.share({
          title: "LCM/GCD Result",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const formatBigInt = (n: bigint): string => {
    const str = n.toString()
    if (str.length > 20) {
      return str.slice(0, 10) + "..." + str.slice(-5) + ` (${str.length} digits)`
    }
    return str.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Hash className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">LCM/GCD Calculator</CardTitle>
                    <CardDescription>Find Least Common Multiple & Greatest Common Divisor</CardDescription>
                  </div>
                </div>

                {/* Operation Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculate</span>
                  <div className="flex rounded-full bg-muted p-1">
                    {(["lcm", "gcd", "both"] as OperationType[]).map((op) => (
                      <button
                        key={op}
                        onClick={() => setOperation(op)}
                        className={`px-3 py-1.5 text-sm font-medium rounded-full transition-colors ${
                          operation === op
                            ? "bg-primary text-primary-foreground shadow-sm"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {op === "both" ? "Both" : op.toUpperCase()}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Number Inputs */}
                <div className="space-y-3">
                  <Label>Numbers (positive integers)</Label>
                  {numbers.map((num, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground w-6">#{index + 1}</span>
                      <Input
                        type="number"
                        placeholder={`Number ${index + 1}`}
                        value={num}
                        onChange={(e) => updateNumber(index, e.target.value)}
                        min="1"
                        step="1"
                        className="flex-1"
                      />
                      {numbers.length > 2 && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeNumber(index)}
                          className="h-9 w-9 text-muted-foreground hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}

                  {numbers.length < 10 && (
                    <Button variant="outline" size="sm" onClick={addNumber} className="w-full bg-transparent">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Number
                    </Button>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {operation === "both" ? "LCM & GCD" : operation.toUpperCase()}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="space-y-4">
                      {result.gcd !== null && (
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground mb-1">Greatest Common Divisor (GCD)</p>
                          <p className="text-3xl font-bold text-blue-600 break-all">{formatBigInt(result.gcd)}</p>
                        </div>
                      )}

                      {result.lcm !== null && result.gcd !== null && <div className="border-t border-blue-200 pt-4" />}

                      {result.lcm !== null && (
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground mb-1">Least Common Multiple (LCM)</p>
                          <p className="text-3xl font-bold text-green-600 break-all">{formatBigInt(result.lcm)}</p>
                        </div>
                      )}

                      {/* Prime Factorization Table */}
                      {result.primeFactors.size > 0 && (
                        <div className="mt-4 pt-4 border-t border-blue-200">
                          <button
                            onClick={() => setShowSteps(!showSteps)}
                            className="w-full flex items-center justify-between text-sm font-medium text-blue-700 hover:text-blue-800"
                          >
                            <span>Prime Factorization & Steps</span>
                            <span>{showSteps ? "−" : "+"}</span>
                          </button>

                          {showSteps && (
                            <div className="mt-3 space-y-2 text-sm text-muted-foreground bg-white/50 p-3 rounded-lg">
                              {result.steps.map((step, idx) => (
                                <p key={idx} className={step === "" ? "h-2" : "font-mono"}>
                                  {step}
                                </p>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t border-blue-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Understanding LCM & GCD</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-medium text-green-700 mb-1">LCM (Least Common Multiple)</p>
                    <p className="text-sm text-green-600">
                      The smallest positive integer that is divisible by all given numbers.
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-medium text-blue-700 mb-1">GCD (Greatest Common Divisor)</p>
                    <p className="text-sm text-blue-600">
                      The largest positive integer that divides all given numbers without a remainder.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas Used</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">LCM(a, b) = |a × b| / GCD(a, b)</p>
                    <p className="font-semibold text-foreground">GCD uses Euclidean Algorithm</p>
                  </div>
                  <p>
                    The Euclidean algorithm finds GCD by repeatedly replacing the larger number with the remainder of
                    dividing the larger by the smaller until one number becomes zero.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Note</p>
                      <p className="text-sm text-amber-700 mt-1">
                        This calculator provides estimates only. Verify manually for critical calculations.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are LCM and GCD?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Least Common Multiple (LCM) and Greatest Common Divisor (GCD) are fundamental concepts in number
                  theory that have practical applications in mathematics, computer science, and everyday
                  problem-solving. The GCD, also known as the Greatest Common Factor (GCF) or Highest Common Factor
                  (HCF), represents the largest number that divides two or more integers without leaving a remainder.
                  Meanwhile, the LCM is the smallest positive integer that is evenly divisible by all the given numbers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  These concepts are closely related through a beautiful mathematical relationship: for any two positive
                  integers a and b, the product of their LCM and GCD equals the product of the numbers themselves (LCM ×
                  GCD = a × b). This relationship allows us to calculate one value if we know the other, making
                  computations more efficient.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>The Euclidean Algorithm</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Euclidean algorithm is one of the oldest algorithms still in use today, dating back to around 300
                  BC. Named after the Greek mathematician Euclid, this elegant method finds the GCD of two numbers
                  through a series of divisions. The algorithm works by repeatedly replacing the larger number with the
                  remainder of dividing it by the smaller number until the remainder becomes zero. The last non-zero
                  remainder is the GCD.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, to find GCD(48, 18): 48 ÷ 18 = 2 remainder 12, then 18 ÷ 12 = 1 remainder 6, then 12 ÷ 6
                  = 2 remainder 0. Since the remainder is now 0, the GCD is 6, the last non-zero remainder. This
                  algorithm is remarkably efficient, even for very large numbers, which is why it remains the preferred
                  method for computing GCD in modern computing.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Grid3X3 className="h-5 w-5 text-primary" />
                  <CardTitle>Prime Factorization Method</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Another approach to finding LCM and GCD is through prime factorization, which expresses each number as
                  a product of prime numbers. For GCD, we take the product of the lowest powers of common prime factors.
                  For LCM, we take the product of the highest powers of all prime factors present in any of the numbers.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For instance, with 12 = 2² × 3 and 18 = 2 × 3², the GCD is 2¹ × 3¹ = 6 (taking minimum powers of
                  common factors) and the LCM is 2² × 3² = 36 (taking maximum powers of all factors). While this method
                  provides insight into the mathematical structure, the Euclidean algorithm is generally more efficient
                  for computational purposes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Hash className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  LCM and GCD have numerous practical applications. The GCD is used in simplifying fractions to their
                  lowest terms, cryptography (RSA encryption relies heavily on GCD calculations), and determining common
                  measurement intervals. The LCM is essential for finding common denominators when adding fractions,
                  scheduling problems (when will two events coincide?), and gear ratio calculations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In programming, GCD is used in graphics for aspect ratio calculations, in music for rhythm patterns,
                  and in manufacturing for optimizing cutting patterns. Understanding these concepts is fundamental to
                  many areas of mathematics and has practical implications in fields ranging from architecture to
                  computer science.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
