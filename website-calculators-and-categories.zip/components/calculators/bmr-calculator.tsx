"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Flame, Info, Activity, Heart, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"

interface BMRResult {
  value: number
  tdeeValues: { name: string; calories: number; description: string }[]
}

const activityLevels = [
  { name: "Sedentary", multiplier: 1.2, description: "Little or no exercise" },
  { name: "Lightly Active", multiplier: 1.375, description: "Light exercise 1-3 days/week" },
  { name: "Moderately Active", multiplier: 1.55, description: "Moderate exercise 3-5 days/week" },
  { name: "Very Active", multiplier: 1.725, description: "Hard exercise 6-7 days/week" },
  { name: "Extra Active", multiplier: 1.9, description: "Very hard exercise, physical job" },
]

export function BMRCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender | null>(null)
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [result, setResult] = useState<BMRResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBMR = () => {
    setError("")
    setResult(null)

    if (!gender) {
      setError("Please select your gender")
      return
    }

    const ageNum = Number.parseInt(age)
    if (isNaN(ageNum) || ageNum < 10 || ageNum > 120) {
      setError("Please enter a valid age between 10 and 120")
      return
    }

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number
    let weightInKg: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
      weightInKg = weightNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
      weightInKg = weightNum * 0.453592
    }

    // Mifflin-St Jeor Equation
    let bmr: number
    if (gender === "male") {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
    } else {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
    }

    const roundedBMR = Math.round(bmr)

    const tdeeValues = activityLevels.map((level) => ({
      name: level.name,
      calories: Math.round(bmr * level.multiplier),
      description: level.description,
    }))

    setResult({ value: roundedBMR, tdeeValues })
  }

  const handleReset = () => {
    setGender(null)
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`My BMR is ${result.value} kcal/day`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My BMR Result",
          text: `I calculated my BMR using CalcHub! My BMR is ${result.value} kcal/day`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">BMR Calculator</CardTitle>
                    <CardDescription>Calculate your Basal Metabolic Rate</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      className="h-11"
                      onClick={() => setGender("male")}
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      className="h-11"
                      onClick={() => setGender("female")}
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                    max="120"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBMR} className="w-full" size="lg">
                  Calculate BMR
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Basal Metabolic Rate</p>
                      <p className="text-5xl font-bold text-orange-600 mb-1">{result.value}</p>
                      <p className="text-lg font-semibold text-orange-600">kcal/day</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Daily Calorie Needs (TDEE)</CardTitle>
                </CardHeader>
                <CardContent>
                  {result ? (
                    <div className="space-y-3">
                      {result.tdeeValues.map((level, index) => (
                        <div
                          key={level.name}
                          className={`flex items-center justify-between p-3 rounded-lg ${
                            index === 0
                              ? "bg-slate-50 border border-slate-200"
                              : index === 1
                                ? "bg-blue-50 border border-blue-200"
                                : index === 2
                                  ? "bg-green-50 border border-green-200"
                                  : index === 3
                                    ? "bg-yellow-50 border border-yellow-200"
                                    : "bg-orange-50 border border-orange-200"
                          }`}
                        >
                          <div>
                            <span className="font-medium text-foreground">{level.name}</span>
                            <p className="text-xs text-muted-foreground">{level.description}</p>
                          </div>
                          <span className="text-sm font-semibold text-foreground">{level.calories} kcal</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {activityLevels.map((level) => (
                        <div
                          key={level.name}
                          className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-muted"
                        >
                          <div>
                            <span className="font-medium text-foreground">{level.name}</span>
                            <p className="text-xs text-muted-foreground">{level.description}</p>
                          </div>
                          <span className="text-sm text-muted-foreground">--</span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BMR Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground text-xs">Mifflin-St Jeor Equation</p>
                    <p className="text-xs">
                      <strong>Men:</strong> (10 × weight) + (6.25 × height) - (5 × age) + 5
                    </p>
                    <p className="text-xs">
                      <strong>Women:</strong> (10 × weight) + (6.25 × height) - (5 × age) - 161
                    </p>
                  </div>
                  <p>Weight in kg, height in cm, age in years</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is BMR */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Basal Metabolic Rate (BMR)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Basal Metabolic Rate (BMR) represents the number of calories your body needs to maintain basic
                  life-sustaining functions while at complete rest. These essential functions include breathing, blood
                  circulation, cell production, nutrient processing, protein synthesis, and ion transport. In essence,
                  BMR is the minimum amount of energy your body requires to stay alive if you were to spend an entire
                  day doing absolutely nothing—not even digesting food.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Your BMR typically accounts for about 60-75% of your total daily energy expenditure, making it the
                  largest component of your metabolism. Understanding your BMR is crucial for anyone looking to manage
                  their weight effectively, whether the goal is to lose fat, gain muscle, or maintain current body
                  composition. It serves as the foundation upon which all caloric calculations are built and helps you
                  make informed decisions about nutrition and fitness.
                </p>
              </CardContent>
            </Card>

            {/* How BMR is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>The Mifflin-St Jeor Equation Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator uses the Mifflin-St Jeor Equation, which is considered the most accurate BMR formula
                  for most individuals according to the American Dietetic Association. Developed in 1990 by MD Mifflin
                  and ST St Jeor, this equation has been validated through numerous studies and is preferred over older
                  formulas like the Harris-Benedict equation, which tends to overestimate caloric needs.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equation considers four key variables: weight, height, age, and biological sex. For men, the
                  formula is: BMR = (10 × weight in kg) + (6.25 × height in cm) - (5 × age in years) + 5. For women, the
                  formula is: BMR = (10 × weight in kg) + (6.25 × height in cm) - (5 × age in years) - 161. The
                  difference between the male and female equations accounts for the fact that men typically have more
                  lean muscle mass and less body fat than women of the same height and weight.
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting BMR */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Factors That Affect Your BMR</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the Mifflin-St Jeor equation provides an excellent estimate, several factors can cause your
                  actual BMR to differ from the calculated value. Muscle mass plays a significant role—muscle tissue is
                  metabolically active and burns more calories at rest than fat tissue. People with higher muscle mass
                  will have a higher BMR, which is why strength training can boost your metabolism over time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Age naturally decreases BMR, typically by about 1-2% per decade after age 20, partly due to loss of
                  muscle mass and hormonal changes. Genetics also influence your metabolic rate—some people naturally
                  have faster metabolisms due to inherited traits. Thyroid hormones have a major impact on BMR;
                  conditions like hypothyroidism can significantly lower it, while hyperthyroidism can increase it.
                  Other factors include body temperature, climate, pregnancy, and certain medications.
                </p>
              </CardContent>
            </Card>

            {/* BMR vs TDEE */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>BMR vs. TDEE: What is the Difference?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While BMR tells you how many calories you burn at rest, Total Daily Energy Expenditure (TDEE)
                  represents the total number of calories you burn in a day including all activities. TDEE is calculated
                  by multiplying your BMR by an activity factor that reflects your lifestyle and exercise habits. The
                  activity multipliers range from 1.2 for sedentary individuals to 1.9 for extremely active people.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For weight management, TDEE is the more practical number to use. To lose weight, create a caloric
                  deficit by consuming 300-500 calories less than your TDEE—this promotes gradual, sustainable fat loss
                  of about 0.5-1 pound per week. To gain weight, create a caloric surplus by consuming 300-500 calories
                  more than your TDEE. For maintenance, consume calories approximately equal to your TDEE. Never eat
                  below your BMR for extended periods, as this can slow your metabolism and lead to muscle loss.
                </p>
              </CardContent>
            </Card>

            {/* Tips for Boosting Metabolism */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Naturally Boosting Your Metabolism</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While you cannot dramatically change your BMR overnight, there are several evidence-based strategies
                  to gradually increase your metabolic rate. Building lean muscle through regular strength training is
                  one of the most effective methods—each pound of muscle burns approximately 6-10 calories per day at
                  rest, compared to just 2-3 calories per pound of fat. Aim for at least 2-3 resistance training
                  sessions per week.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Stay well hydrated, as water is essential for all metabolic processes. Eating adequate protein (around
                  0.7-1g per pound of body weight) can increase your metabolic rate due to the thermic effect of food—
                  protein requires more energy to digest than carbs or fats. Get 7-9 hours of quality sleep, as sleep
                  deprivation can lower BMR and increase hunger hormones. Finally, avoid extreme caloric restriction, as
                  this can trigger adaptive thermogenesis, causing your body to lower its BMR to conserve energy.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
