"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { formatCurrency, currencySymbols, type Currency, currencyOptions } from "@/lib/currency"

type ContributionFrequency = "weekly" | "biweekly" | "monthly" | "quarterly"
type CompoundingFrequency = "monthly" | "quarterly" | "annually"

interface DCAResult {
  totalContributions: number
  finalValue: number
  totalGain: number
  roiPercent: number
  averageCostPerShare: number
  totalShares: number
  schedule: {
    period: number
    contribution: number
    totalContributed: number
    value: number
    shares: number
    totalShares: number
    pricePerShare: number
  }[]
}

export function DCACalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [initialInvestment, setInitialInvestment] = useState("")
  const [contributionAmount, setContributionAmount] = useState("")
  const [contributionFrequency, setContributionFrequency] = useState<ContributionFrequency>("monthly")
  const [duration, setDuration] = useState("")
  const [expectedReturn, setExpectedReturn] = useState("")
  const [initialSharePrice, setInitialSharePrice] = useState("")
  const [priceVolatility, setPriceVolatility] = useState("")
  const [result, setResult] = useState<DCAResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showSchedule, setShowSchedule] = useState(false)

  const getPeriodsPerYear = (freq: ContributionFrequency): number => {
    switch (freq) {
      case "weekly":
        return 52
      case "biweekly":
        return 26
      case "monthly":
        return 12
      case "quarterly":
        return 4
      default:
        return 12
    }
  }

  const getFrequencyLabel = (freq: ContributionFrequency): string => {
    switch (freq) {
      case "weekly":
        return "Week"
      case "biweekly":
        return "Bi-week"
      case "monthly":
        return "Month"
      case "quarterly":
        return "Quarter"
      default:
        return "Period"
    }
  }

  const calculateDCA = () => {
    setError("")
    setResult(null)

    const initial = Number.parseFloat(initialInvestment) || 0
    const contribution = Number.parseFloat(contributionAmount)
    const years = Number.parseFloat(duration)
    const returnRate = Number.parseFloat(expectedReturn)
    const sharePrice = Number.parseFloat(initialSharePrice) || 100
    const volatility = Number.parseFloat(priceVolatility) || 0

    if (isNaN(contribution) || contribution <= 0) {
      setError("Please enter a valid contribution amount greater than 0")
      return
    }
    if (isNaN(years) || years <= 0) {
      setError("Please enter a valid investment duration greater than 0")
      return
    }
    if (isNaN(returnRate)) {
      setError("Please enter a valid expected return rate")
      return
    }

    const periodsPerYear = getPeriodsPerYear(contributionFrequency)
    const totalPeriods = Math.floor(years * periodsPerYear)
    const periodReturn = returnRate / 100 / periodsPerYear

    let totalContributions = initial
    let totalShares = initial > 0 ? initial / sharePrice : 0
    let currentPrice = sharePrice
    const schedule: DCAResult["schedule"] = []

    // Initial investment
    if (initial > 0) {
      schedule.push({
        period: 0,
        contribution: initial,
        totalContributed: initial,
        value: initial,
        shares: totalShares,
        totalShares: totalShares,
        pricePerShare: sharePrice,
      })
    }

    // Simulate DCA over time
    for (let i = 1; i <= totalPeriods; i++) {
      // Simulate price change with growth and volatility
      const growthFactor = 1 + periodReturn
      const volatilityFactor =
        volatility > 0 ? 1 + (Math.random() - 0.5) * 2 * (volatility / 100 / Math.sqrt(periodsPerYear)) : 1
      currentPrice = currentPrice * growthFactor * volatilityFactor

      // Buy shares with contribution
      const sharesBought = contribution / currentPrice
      totalShares += sharesBought
      totalContributions += contribution

      const currentValue = totalShares * currentPrice

      schedule.push({
        period: i,
        contribution: contribution,
        totalContributed: totalContributions,
        value: currentValue,
        shares: sharesBought,
        totalShares: totalShares,
        pricePerShare: currentPrice,
      })
    }

    const finalValue = totalShares * currentPrice
    const totalGain = finalValue - totalContributions
    const roiPercent = totalContributions > 0 ? (totalGain / totalContributions) * 100 : 0
    const averageCostPerShare = totalContributions / totalShares

    setResult({
      totalContributions,
      finalValue,
      totalGain,
      roiPercent,
      averageCostPerShare,
      totalShares,
      schedule,
    })
  }

  const handleReset = () => {
    setInitialInvestment("")
    setContributionAmount("")
    setContributionFrequency("monthly")
    setDuration("")
    setExpectedReturn("")
    setInitialSharePrice("")
    setPriceVolatility("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `DCA Investment Summary:
Total Contributions: ${formatCurrency(result.totalContributions, currency)}
Final Value: ${formatCurrency(result.finalValue, currency)}
Total Gain: ${formatCurrency(result.totalGain, currency)}
ROI: ${result.roiPercent.toFixed(2)}%
Average Cost/Share: ${formatCurrency(result.averageCostPerShare, currency)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "DCA Calculator Result",
          text: `My DCA investment projection shows a final value of ${formatCurrency(result.finalValue, currency)} with ${result.roiPercent.toFixed(2)}% ROI`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Dollar Cost Averaging Calculator</CardTitle>
                    <CardDescription>Estimate periodic investment performance over time</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <Select value={currency} onValueChange={(value) => setCurrency(value as Currency)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencyOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.symbol} - {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Investment */}
                <div className="space-y-2">
                  <Label htmlFor="initialInvestment">Initial Investment ({symbol}) - Optional</Label>
                  <Input
                    id="initialInvestment"
                    type="number"
                    placeholder="e.g., 1000"
                    value={initialInvestment}
                    onChange={(e) => setInitialInvestment(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Contribution Amount */}
                <div className="space-y-2">
                  <Label htmlFor="contributionAmount">Periodic Contribution ({symbol})</Label>
                  <Input
                    id="contributionAmount"
                    type="number"
                    placeholder="e.g., 500"
                    value={contributionAmount}
                    onChange={(e) => setContributionAmount(e.target.value)}
                    min="0"
                    step="50"
                  />
                </div>

                {/* Contribution Frequency */}
                <div className="space-y-2">
                  <Label>Contribution Frequency</Label>
                  <Select
                    value={contributionFrequency}
                    onValueChange={(value) => setContributionFrequency(value as ContributionFrequency)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="biweekly">Bi-weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Investment Duration (Years)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="e.g., 10"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Expected Return */}
                <div className="space-y-2">
                  <Label htmlFor="expectedReturn">Expected Annual Return (%)</Label>
                  <Input
                    id="expectedReturn"
                    type="number"
                    placeholder="e.g., 8"
                    value={expectedReturn}
                    onChange={(e) => setExpectedReturn(e.target.value)}
                    step="0.5"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto font-medium">
                      Advanced Options (Optional)
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="initialSharePrice">Initial Share/Unit Price ({symbol})</Label>
                      <Input
                        id="initialSharePrice"
                        type="number"
                        placeholder="e.g., 100 (default)"
                        value={initialSharePrice}
                        onChange={(e) => setInitialSharePrice(e.target.value)}
                        min="0.01"
                        step="1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="priceVolatility">Price Volatility (%) - For Simulation</Label>
                      <Input
                        id="priceVolatility"
                        type="number"
                        placeholder="e.g., 20 (0 for smooth growth)"
                        value={priceVolatility}
                        onChange={(e) => setPriceVolatility(e.target.value)}
                        min="0"
                        max="100"
                        step="5"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDCA} className="w-full" size="lg">
                  Calculate DCA
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Final Portfolio Value</p>
                      <p className="text-4xl font-bold text-green-600 mb-1">
                        {formatCurrency(result.finalValue, currency)}
                      </p>
                      <p
                        className={`text-lg font-semibold ${result.totalGain >= 0 ? "text-green-600" : "text-red-600"}`}
                      >
                        {result.totalGain >= 0 ? "+" : ""}
                        {formatCurrency(result.totalGain, currency)} ({result.roiPercent.toFixed(2)}% ROI)
                      </p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Contributions</p>
                        <p className="font-semibold">{formatCurrency(result.totalContributions, currency)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Shares</p>
                        <p className="font-semibold">{result.totalShares.toFixed(4)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border col-span-2">
                        <p className="text-xs text-muted-foreground">Average Cost Per Share</p>
                        <p className="font-semibold">{formatCurrency(result.averageCostPerShare, currency)}</p>
                      </div>
                    </div>

                    {/* Visual Breakdown */}
                    <div className="mb-4">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Contributions</span>
                        <span>Gains</span>
                      </div>
                      <div className="h-4 rounded-full overflow-hidden bg-gray-200 flex">
                        <div
                          className="bg-blue-500 h-full"
                          style={{ width: `${(result.totalContributions / result.finalValue) * 100}%` }}
                        />
                        <div
                          className={`h-full ${result.totalGain >= 0 ? "bg-green-500" : "bg-red-500"}`}
                          style={{ width: `${Math.abs(result.totalGain / result.finalValue) * 100}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span className="text-blue-600">
                          {((result.totalContributions / result.finalValue) * 100).toFixed(1)}%
                        </span>
                        <span className={result.totalGain >= 0 ? "text-green-600" : "text-red-600"}>
                          {((Math.abs(result.totalGain) / result.finalValue) * 100).toFixed(1)}%
                        </span>
                      </div>
                    </div>

                    {/* Schedule Breakdown */}
                    <Collapsible open={showSchedule} onOpenChange={setShowSchedule}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full mb-2 bg-transparent">
                          {showSchedule ? "Hide" : "Show"} Investment Schedule
                          {showSchedule ? (
                            <ChevronUp className="h-4 w-4 ml-2" />
                          ) : (
                            <ChevronDown className="h-4 w-4 ml-2" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="max-h-60 overflow-y-auto border rounded-lg">
                          <table className="w-full text-xs">
                            <thead className="bg-muted sticky top-0">
                              <tr>
                                <th className="p-2 text-left">{getFrequencyLabel(contributionFrequency)}</th>
                                <th className="p-2 text-right">Contributed</th>
                                <th className="p-2 text-right">Value</th>
                                <th className="p-2 text-right">Shares</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.schedule
                                .filter(
                                  (_, i) =>
                                    i % Math.max(1, Math.floor(result.schedule.length / 20)) === 0 ||
                                    i === result.schedule.length - 1,
                                )
                                .map((entry) => (
                                  <tr key={entry.period} className="border-t">
                                    <td className="p-2">{entry.period}</td>
                                    <td className="p-2 text-right">
                                      {formatCurrency(entry.totalContributed, currency)}
                                    </td>
                                    <td className="p-2 text-right">{formatCurrency(entry.value, currency)}</td>
                                    <td className="p-2 text-right">{entry.totalShares.toFixed(2)}</td>
                                  </tr>
                                ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How DCA Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-blue-600 text-xs font-bold">
                        1
                      </div>
                      <div>
                        <p className="font-medium text-blue-700">Invest Regularly</p>
                        <p className="text-sm text-blue-600">Contribute fixed amounts at consistent intervals</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 text-xs font-bold">
                        2
                      </div>
                      <div>
                        <p className="font-medium text-green-700">Buy More When Low</p>
                        <p className="text-sm text-green-600">Same amount buys more shares at lower prices</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-purple-100 text-purple-600 text-xs font-bold">
                        3
                      </div>
                      <div>
                        <p className="font-medium text-purple-700">Average Your Cost</p>
                        <p className="text-sm text-purple-600">Reduces impact of market volatility over time</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">DCA Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      Average Cost = Total Invested / Total Shares
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      ROI = (Final Value - Total Invested) / Total Invested x 100
                    </p>
                  </div>
                  <p>
                    DCA reduces the risk of investing a large amount at an unfavorable time by spreading purchases
                    across multiple periods.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Benefits of DCA</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>Reduces emotional decision-making</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>Lowers average cost in volatile markets</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>Builds disciplined investing habits</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <span>Works well for long-term wealth building</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Dollar Cost Averaging?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Dollar Cost Averaging (DCA) is an investment strategy where you invest a fixed amount of money at
                  regular intervals, regardless of the asset's price. Instead of trying to time the market by making a
                  single large investment, DCA spreads your purchases over time. This approach helps reduce the impact
                  of volatility on your overall investment by averaging out the purchase price of your holdings.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When prices are high, your fixed investment amount buys fewer shares. When prices are low, the same
                  amount buys more shares. Over time, this typically results in a lower average cost per share compared
                  to making random lump-sum investments. DCA is particularly popular for retirement accounts, index fund
                  investing, and cryptocurrency accumulation strategies.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>When to Use DCA</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  DCA is most effective in volatile markets where timing the bottom is difficult or impossible. It's
                  ideal for long-term investors who want to build wealth gradually without the stress of market timing.
                  Common use cases include regular contributions to 401(k) plans, systematic investment in index funds,
                  and accumulating positions in cryptocurrencies or individual stocks over extended periods.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  While DCA may underperform lump-sum investing in consistently rising markets, it provides
                  psychological benefits by removing the pressure of timing decisions. It's especially valuable for new
                  investors or those with irregular income who prefer a methodical approach to building their portfolio.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Dollar Cost Averaging calculations are estimates based on entered values and assumed returns. Actual
                  investment outcomes may vary significantly due to market fluctuations, fees, taxes, and other factors.
                  Past performance does not guarantee future results. This calculator is for educational purposes only
                  and should not be considered financial advice. Consult a qualified financial advisor for personalized
                  investment guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
