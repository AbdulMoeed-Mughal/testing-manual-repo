"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Droplet, Info, Beaker } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface Solvent {
  name: string
  kb: number
  kf: number
  normalBp: number
  normalFp: number
}

const SOLVENTS: Record<string, Solvent> = {
  water: { name: "Water", kb: 0.512, kf: 1.86, normalBp: 100, normalFp: 0 },
  benzene: { name: "Benzene", kb: 2.53, kf: 5.12, normalBp: 80.1, normalFp: 5.5 },
  cyclohexane: { name: "Cyclohexane", kb: 2.79, kf: 20.0, normalBp: 80.7, normalFp: 6.5 },
  ethanol: { name: "Ethanol", kb: 1.22, kf: 1.99, normalBp: 78.4, normalFp: -114.1 },
  chloroform: { name: "Chloroform", kb: 3.63, kf: 4.68, normalBp: 61.2, normalFp: -63.5 },
  acetic_acid: { name: "Acetic Acid", kb: 3.07, kf: 3.90, normalBp: 118.1, normalFp: 16.6 },
  camphor: { name: "Camphor", kb: 5.95, kf: 37.7, normalBp: 204, normalFp: 179 },
}

const R = 0.0821

interface Results {
  boilingPointElevation: number
  newBoilingPoint: number
  freezingPointDepression: number
  newFreezingPoint: number
  osmoticPressure: number
  category: string
  color: string
  bgColor: string
}

export function ColligativePropertiesCalculator() {
  const [solvent, setSolvent] = useState<string>("water")
  const [molality, setMolality] = useState("")
  const [vanHoffFactor, setVanHoffFactor] = useState("1")
  const [temperature, setTemperature] = useState("25")
  const [molarity, setMolarity] = useState("")
  const [result, setResult] = useState<Results | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateProperties = () => {
    setError("")
    setResult(null)

    const m = Number.parseFloat(molality)
    const i = Number.parseFloat(vanHoffFactor)
    const M = Number.parseFloat(molarity)
    const T = Number.parseFloat(temperature) + 273.15

    if (isNaN(m) || m <= 0) {
      setError("Please enter a valid molality greater than 0")
      return
    }

    if (isNaN(i) || i < 1) {
      setError("Van't Hoff factor must be ≥ 1")
      return
    }

    const selectedSolvent = SOLVENTS[solvent]

    const boilingPointElevation = i * selectedSolvent.kb * m
    const newBoilingPoint = selectedSolvent.normalBp + boilingPointElevation
    const freezingPointDepression = i * selectedSolvent.kf * m
    const newFreezingPoint = selectedSolvent.normalFp - freezingPointDepression

    let osmoticPressure = 0
    if (!isNaN(M) && M > 0) {
      osmoticPressure = i * M * R * T
    }

    let category: string
    let color: string
    let bgColor: string

    const totalEffect = boilingPointElevation + freezingPointDepression
    if (totalEffect < 2) {
      category = "Negligible Effect"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (totalEffect < 10) {
      category = "Moderate Effect"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (totalEffect < 30) {
      category = "Significant Effect"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Large Effect"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      boilingPointElevation,
      newBoilingPoint,
      freezingPointDepression,
      newFreezingPoint,
      osmoticPressure,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setSolvent("water")
    setMolality("")
    setVanHoffFactor("1")
    setTemperature("25")
    setMolarity("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Colligative Properties: ΔTb=${result.boilingPointElevation.toFixed(3)}°C, ΔTf=${result.freezingPointDepression.toFixed(3)}°C${result.osmoticPressure > 0 ? `, π=${result.osmoticPressure.toFixed(3)} atm` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Colligative Properties Results",
          text: `Calculated colligative properties using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Droplet className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Colligative Properties Calculator</CardTitle>
                    <CardDescription>Calculate all solution properties at once</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Solvent Selection */}
                <div className="space-y-2">
                  <Label htmlFor="solvent">Solvent</Label>
                  <Select value={solvent} onValueChange={setSolvent}>
                    <SelectTrigger id="solvent">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(SOLVENTS).map(([key, solv]) => (
                        <SelectItem key={key} value={key}>
                          {solv.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Molality Input */}
                <div className="space-y-2">
                  <Label htmlFor="molality">Molality (mol/kg)</Label>
                  <Input
                    id="molality"
                    type="number"
                    placeholder="Enter molality"
                    value={molality}
                    onChange={(e) => setMolality(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Van't Hoff Factor */}
                <div className="space-y-2">
                  <Label htmlFor="vanhoff">Van't Hoff Factor (i)</Label>
                  <Input
                    id="vanhoff"
                    type="number"
                    placeholder="1 for nonelectrolytes"
                    value={vanHoffFactor}
                    onChange={(e) => setVanHoffFactor(e.target.value)}
                    min="1"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">1 for sugar, 2 for NaCl, 3 for CaCl₂</p>
                </div>

                {/* Optional: Molarity for Osmotic Pressure */}
                <div className="space-y-2">
                  <Label htmlFor="molarity">Molarity (M) - Optional</Label>
                  <Input
                    id="molarity"
                    type="number"
                    placeholder="For osmotic pressure calculation"
                    value={molarity}
                    onChange={(e) => setMolarity(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Temperature for Osmotic Pressure */}
                <div className="space-y-2">
                  <Label htmlFor="temperature">Temperature (°C)</Label>
                  <Input
                    id="temperature"
                    type="number"
                    placeholder="Enter temperature"
                    value={temperature}
                    onChange={(e) => setTemperature(e.target.value)}
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateProperties} className="w-full bg-purple-600 hover:bg-purple-700" size="lg">
                  Calculate All Properties
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="space-y-3">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Boiling Point Elevation</p>
                        <p className={`text-2xl font-bold ${result.color}`}>+{result.boilingPointElevation.toFixed(3)}°C</p>
                        <p className="text-sm text-muted-foreground">New BP: {result.newBoilingPoint.toFixed(2)}°C</p>
                      </div>
                      
                      <div className="border-t pt-2">
                        <p className="text-xs text-muted-foreground mb-1">Freezing Point Depression</p>
                        <p className={`text-2xl font-bold ${result.color}`}>-{result.freezingPointDepression.toFixed(3)}°C</p>
                        <p className="text-sm text-muted-foreground">New FP: {result.newFreezingPoint.toFixed(2)}°C</p>
                      </div>

                      {result.osmoticPressure > 0 && (
                        <div className="border-t pt-2">
                          <p className="text-xs text-muted-foreground mb-1">Osmotic Pressure</p>
                          <p className={`text-2xl font-bold ${result.color}`}>{result.osmoticPressure.toFixed(3)} atm</p>
                          <p className="text-sm text-muted-foreground">{(result.osmoticPressure * 101.325).toFixed(2)} kPa</p>
                        </div>
                      )}

                      <div className="border-t pt-2">
                        <p className={`text-sm font-semibold ${result.color}`}>{result.category}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset} className="bg-transparent">
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy} className="bg-transparent">
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare} className="bg-transparent">
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Solvent Properties</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex justify-between p-2 rounded bg-muted">
                    <span className="text-muted-foreground">K<sub>b</sub>:</span>
                    <span className="font-medium">{SOLVENTS[solvent].kb} °C·kg/mol</span>
                  </div>
                  <div className="flex justify-between p-2 rounded bg-muted">
                    <span className="text-muted-foreground">K<sub>f</sub>:</span>
                    <span className="font-medium">{SOLVENTS[solvent].kf} °C·kg/mol</span>
                  </div>
                  <div className="flex justify-between p-2 rounded bg-muted">
                    <span className="text-muted-foreground">Normal BP:</span>
                    <span className="font-medium">{SOLVENTS[solvent].normalBp} °C</span>
                  </div>
                  <div className="flex justify-between p-2 rounded bg-muted">
                    <span className="text-muted-foreground">Normal FP:</span>
                    <span className="font-medium">{SOLVENTS[solvent].normalFp} °C</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <p className="font-semibold text-purple-900 mb-1">Boiling Point Elevation</p>
                    <p className="font-mono text-purple-700">ΔT<sub>b</sub> = i × K<sub>b</sub> × m</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="font-semibold text-blue-900 mb-1">Freezing Point Depression</p>
                    <p className="font-mono text-blue-700">ΔT<sub>f</sub> = i × K<sub>f</sub> × m</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="font-semibold text-green-900 mb-1">Osmotic Pressure</p>
                    <p className="font-mono text-green-700">π = i × M × R × T</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What are Colligative Properties */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-purple-600" />
                  <CardTitle>What are Colligative Properties?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Colligative properties are physical properties of solutions that depend only on the number of solute
                  particles present, not on the chemical identity of those particles. The four main colligative
                  properties are boiling point elevation, freezing point depression, osmotic pressure, and vapor pressure
                  lowering. These properties arise because the presence of solute particles disrupts the normal behavior
                  of the solvent molecules.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding colligative properties is crucial in many practical applications, from adding antifreeze
                  to car radiators (freezing point depression) to understanding how salt melts ice on roads. In
                  biological systems, osmotic pressure plays a vital role in maintaining cell structure and function.
                  These properties are also essential in food preservation, pharmaceutical formulations, and industrial
                  chemical processes.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-purple-600" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Automotive Antifreeze</h4>
                    <p className="text-purple-700 text-sm">
                      Ethylene glycol is added to car radiators to lower the freezing point and raise the boiling point
                      of water, preventing engine damage in extreme temperatures. This is a direct application of
                      colligative properties in everyday life.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">De-icing Roads</h4>
                    <p className="text-blue-700 text-sm">
                      Salt (NaCl) is spread on icy roads because it lowers the freezing point of water. The salt
                      dissolves in the thin layer of liquid water on ice, creating a solution with a lower freezing
                      point than pure water, causing the ice to melt even below 0°C.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Medical IV Solutions</h4>
                    <p className="text-green-700 text-sm">
                      Intravenous fluids must be carefully formulated to match the osmotic pressure of blood (isotonic
                      solutions). If the osmotic pressure is too high or too low, it can cause cells to shrink or burst,
                      leading to serious medical complications.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
