"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Battery, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface RuntimeResult {
  hours: number
  minutes: number
  totalHours: number
  energyWh: number
  effectiveCapacity: number
}

export function BatteryRuntimeCalculator() {
  const [capacity, setCapacity] = useState("")
  const [capacityUnit, setCapacityUnit] = useState<"Ah" | "mAh" | "Wh">("mAh")
  const [voltage, setVoltage] = useState("")
  const [consumptionType, setConsumptionType] = useState<"power" | "current">("power")
  const [power, setPower] = useState("")
  const [current, setCurrent] = useState("")
  const [currentUnit, setCurrentUnit] = useState<"A" | "mA">("mA")
  const [efficiency, setEfficiency] = useState("85")
  const [result, setResult] = useState<RuntimeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const capacityNum = Number.parseFloat(capacity)
    const voltageNum = Number.parseFloat(voltage)
    const efficiencyNum = Number.parseFloat(efficiency) / 100

    if (isNaN(capacityNum) || capacityNum <= 0) {
      setError("Please enter a valid battery capacity greater than 0")
      return
    }

    if (capacityUnit !== "Wh" && (isNaN(voltageNum) || voltageNum <= 0)) {
      setError("Please enter a valid voltage greater than 0")
      return
    }

    if (isNaN(efficiencyNum) || efficiencyNum <= 0 || efficiencyNum > 1) {
      setError("Please enter a valid efficiency between 1 and 100%")
      return
    }

    // Convert capacity to Ah
    let capacityAh: number
    let energyWh: number

    if (capacityUnit === "mAh") {
      capacityAh = capacityNum / 1000
      energyWh = capacityAh * voltageNum
    } else if (capacityUnit === "Ah") {
      capacityAh = capacityNum
      energyWh = capacityAh * voltageNum
    } else {
      // Wh
      energyWh = capacityNum
      capacityAh = capacityNum / voltageNum
    }

    let deviceCurrentA: number

    if (consumptionType === "power") {
      const powerNum = Number.parseFloat(power)
      if (isNaN(powerNum) || powerNum <= 0) {
        setError("Please enter a valid power consumption greater than 0")
        return
      }
      deviceCurrentA = powerNum / voltageNum
    } else {
      const currentNum = Number.parseFloat(current)
      if (isNaN(currentNum) || currentNum <= 0) {
        setError("Please enter a valid current draw greater than 0")
        return
      }
      deviceCurrentA = currentUnit === "mA" ? currentNum / 1000 : currentNum
    }

    const effectiveCapacity = capacityAh * efficiencyNum
    const runtimeHours = effectiveCapacity / deviceCurrentA
    const hours = Math.floor(runtimeHours)
    const minutes = Math.round((runtimeHours - hours) * 60)

    setResult({
      hours,
      minutes,
      totalHours: runtimeHours,
      energyWh: energyWh * efficiencyNum,
      effectiveCapacity,
    })
  }

  const handleReset = () => {
    setCapacity("")
    setVoltage("")
    setPower("")
    setCurrent("")
    setEfficiency("85")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Battery Runtime: ${result.hours}h ${result.minutes}m (${result.totalHours.toFixed(2)} hours)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Battery Runtime Result",
          text: `Estimated battery runtime: ${result.hours}h ${result.minutes}m`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Battery className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Battery Runtime Calculator</CardTitle>
                    <CardDescription>Estimate battery life based on capacity and load</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Battery Capacity */}
                <div className="space-y-2">
                  <Label>Battery Capacity</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-2">
                      <Input
                        type="number"
                        placeholder="Enter capacity"
                        value={capacity}
                        onChange={(e) => setCapacity(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <Select value={capacityUnit} onValueChange={(v) => setCapacityUnit(v as "Ah" | "mAh" | "Wh")}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mAh">mAh</SelectItem>
                        <SelectItem value="Ah">Ah</SelectItem>
                        <SelectItem value="Wh">Wh</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Voltage */}
                <div className="space-y-2">
                  <Label htmlFor="voltage">Battery Voltage (V)</Label>
                  <Input
                    id="voltage"
                    type="number"
                    placeholder="e.g., 3.7, 12, 24"
                    value={voltage}
                    onChange={(e) => setVoltage(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Consumption Type Toggle */}
                <div className="space-y-2">
                  <Label>Device Consumption</Label>
                  <div className="flex rounded-lg bg-muted p-1">
                    <button
                      onClick={() => setConsumptionType("power")}
                      className={`flex-1 rounded-md py-2 text-sm font-medium transition-colors ${
                        consumptionType === "power"
                          ? "bg-background text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Power (W)
                    </button>
                    <button
                      onClick={() => setConsumptionType("current")}
                      className={`flex-1 rounded-md py-2 text-sm font-medium transition-colors ${
                        consumptionType === "current"
                          ? "bg-background text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Current (A)
                    </button>
                  </div>
                </div>

                {/* Power or Current Input */}
                {consumptionType === "power" ? (
                  <div className="space-y-2">
                    <Label htmlFor="power">Power Consumption (W)</Label>
                    <Input
                      id="power"
                      type="number"
                      placeholder="Enter power in watts"
                      value={power}
                      onChange={(e) => setPower(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Current Draw</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="col-span-2">
                        <Input
                          type="number"
                          placeholder="Enter current"
                          value={current}
                          onChange={(e) => setCurrent(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <Select value={currentUnit} onValueChange={(v) => setCurrentUnit(v as "A" | "mA")}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mA">mA</SelectItem>
                          <SelectItem value="A">A</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Efficiency */}
                <div className="space-y-2">
                  <Label htmlFor="efficiency">Battery Efficiency (%)</Label>
                  <Input
                    id="efficiency"
                    type="number"
                    placeholder="e.g., 85"
                    value={efficiency}
                    onChange={(e) => setEfficiency(e.target.value)}
                    min="1"
                    max="100"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">Typical: 80-90% for Li-ion, 70-80% for Lead-acid</p>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Runtime
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Runtime</p>
                      <p className="text-4xl font-bold text-green-600 mb-1">
                        {result.hours}h {result.minutes}m
                      </p>
                      <p className="text-sm text-muted-foreground">({result.totalHours.toFixed(2)} hours)</p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground">Effective Capacity</p>
                        <p className="font-semibold">{(result.effectiveCapacity * 1000).toFixed(0)} mAh</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground">Available Energy</p>
                        <p className="font-semibold">{result.energyWh.toFixed(2)} Wh</p>
                      </div>
                    </div>

                    {/* Step-by-Step Solution */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-green-700 hover:text-green-800"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide Steps" : "Show Calculation Steps"}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Apply efficiency factor to capacity
                        </p>
                        <p>
                          <strong>Step 2:</strong> Runtime = Effective Capacity / Current Draw
                        </p>
                        <p>
                          <strong>Step 3:</strong> Convert to hours and minutes
                        </p>
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Runtime Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Runtime (h) = (Capacity × Efficiency) / Current</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Energy (Wh) = Capacity (Ah) × Voltage (V)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Battery Voltages</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Li-ion Cell</span>
                      <span className="font-mono">3.7V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Li-Po Cell</span>
                      <span className="font-mono">3.7V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Lead-Acid</span>
                      <span className="font-mono">12V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>USB Power Bank</span>
                      <span className="font-mono">5V</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>E-bike Battery</span>
                      <span className="font-mono">36-48V</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Battery Runtime</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Battery runtime depends on the battery's capacity (measured in Ah or mAh), the voltage, and the
                  device's power consumption. The efficiency factor accounts for energy losses during discharge, which
                  vary by battery chemistry and temperature.
                </p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Battery runtime calculations are estimates. Actual runtime may vary due
                  to battery age, temperature, load fluctuations, and device efficiency. Consult manufacturer
                  specifications for precise runtime.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
