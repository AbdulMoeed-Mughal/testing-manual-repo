"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Beaker,
  Droplets,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "molarity" | "moles" | "volume"
type VolumeUnit = "L" | "mL"

interface Result {
  molarity: number
  moles: number
  volume: number
  volumeUnit: VolumeUnit
}

export function MolarityCalculator() {
  const [mode, setMode] = useState<CalculationMode>("molarity")
  const [moles, setMoles] = useState("")
  const [volume, setVolume] = useState("")
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("L")
  const [molarity, setMolarity] = useState("")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const molesNum = Number.parseFloat(moles)
    const volumeNum = Number.parseFloat(volume)
    const molarityNum = Number.parseFloat(molarity)

    // Convert volume to liters for calculation
    const volumeInLiters = volumeUnit === "mL" ? volumeNum / 1000 : volumeNum

    if (mode === "molarity") {
      if (isNaN(molesNum) || molesNum < 0) {
        setError("Please enter a valid amount of moles (≥ 0)")
        return
      }
      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }

      const calculatedMolarity = molesNum / volumeInLiters
      setResult({
        molarity: calculatedMolarity,
        moles: molesNum,
        volume: volumeNum,
        volumeUnit,
      })
    } else if (mode === "moles") {
      if (isNaN(molarityNum) || molarityNum < 0) {
        setError("Please enter a valid molarity (≥ 0)")
        return
      }
      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }

      const calculatedMoles = molarityNum * volumeInLiters
      setResult({
        molarity: molarityNum,
        moles: calculatedMoles,
        volume: volumeNum,
        volumeUnit,
      })
    } else if (mode === "volume") {
      if (isNaN(molesNum) || molesNum < 0) {
        setError("Please enter a valid amount of moles (≥ 0)")
        return
      }
      if (isNaN(molarityNum) || molarityNum <= 0) {
        setError("Please enter a valid molarity greater than 0")
        return
      }

      const calculatedVolumeInLiters = molesNum / molarityNum
      const calculatedVolume = volumeUnit === "mL" ? calculatedVolumeInLiters * 1000 : calculatedVolumeInLiters
      setResult({
        molarity: molarityNum,
        moles: molesNum,
        volume: calculatedVolume,
        volumeUnit,
      })
    }
  }

  const handleReset = () => {
    setMoles("")
    setVolume("")
    setMolarity("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = ""
      if (mode === "molarity") {
        text = `Molarity: ${formatNumber(result.molarity)} M (mol/L)`
      } else if (mode === "moles") {
        text = `Moles: ${formatNumber(result.moles)} mol`
      } else {
        text = `Volume: ${formatNumber(result.volume)} ${result.volumeUnit}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        let text = ""
        if (mode === "molarity") {
          text = `Molarity Calculation: ${formatNumber(result.moles)} mol in ${formatNumber(result.volume)} ${result.volumeUnit} = ${formatNumber(result.molarity)} M`
        } else if (mode === "moles") {
          text = `Moles Calculation: ${formatNumber(result.molarity)} M × ${formatNumber(result.volume)} ${result.volumeUnit} = ${formatNumber(result.moles)} mol`
        } else {
          text = `Volume Calculation: ${formatNumber(result.moles)} mol ÷ ${formatNumber(result.molarity)} M = ${formatNumber(result.volume)} ${result.volumeUnit}`
        }
        await navigator.share({
          title: "Molarity Calculation Result",
          text: `Calculated using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 6 })
  }

  const getModeTitle = () => {
    switch (mode) {
      case "molarity":
        return "Calculate Molarity"
      case "moles":
        return "Calculate Moles"
      case "volume":
        return "Calculate Volume"
    }
  }

  const getResultLabel = () => {
    switch (mode) {
      case "molarity":
        return "Molarity (M)"
      case "moles":
        return "Amount (mol)"
      case "volume":
        return `Volume (${volumeUnit})`
    }
  }

  const getResultValue = () => {
    if (!result) return ""
    switch (mode) {
      case "molarity":
        return formatNumber(result.molarity)
      case "moles":
        return formatNumber(result.moles)
      case "volume":
        return formatNumber(result.volume)
    }
  }

  const getResultUnit = () => {
    switch (mode) {
      case "molarity":
        return "mol/L (M)"
      case "moles":
        return "mol"
      case "volume":
        return volumeUnit
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Molarity Calculator</CardTitle>
                    <CardDescription>Calculate concentration of solutions</CardDescription>
                  </div>
                </div>

                {/* Mode Selector */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Calculation Mode</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant={mode === "molarity" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setMode("molarity")
                        setResult(null)
                        setError("")
                      }}
                      className="text-xs"
                    >
                      Molarity
                    </Button>
                    <Button
                      variant={mode === "moles" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setMode("moles")
                        setResult(null)
                        setError("")
                      }}
                      className="text-xs"
                    >
                      Moles
                    </Button>
                    <Button
                      variant={mode === "volume" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setMode("volume")
                        setResult(null)
                        setError("")
                      }}
                      className="text-xs"
                    >
                      Volume
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Moles Input - shown for molarity and volume modes */}
                {(mode === "molarity" || mode === "volume") && (
                  <div className="space-y-2">
                    <Label htmlFor="moles">Amount of Substance (mol)</Label>
                    <Input
                      id="moles"
                      type="number"
                      placeholder="Enter moles"
                      value={moles}
                      onChange={(e) => setMoles(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Volume Input - shown for molarity and moles modes */}
                {(mode === "molarity" || mode === "moles") && (
                  <div className="space-y-2">
                    <Label htmlFor="volume">Solution Volume</Label>
                    <div className="flex gap-2">
                      <Input
                        id="volume"
                        type="number"
                        placeholder="Enter volume"
                        value={volume}
                        onChange={(e) => setVolume(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={volumeUnit} onValueChange={(v) => setVolumeUnit(v as VolumeUnit)}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="L">L</SelectItem>
                          <SelectItem value="mL">mL</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Molarity Input - shown for moles and volume modes */}
                {(mode === "moles" || mode === "volume") && (
                  <div className="space-y-2">
                    <Label htmlFor="molarity">Molarity (mol/L or M)</Label>
                    <Input
                      id="molarity"
                      type="number"
                      placeholder="Enter molarity"
                      value={molarity}
                      onChange={(e) => setMolarity(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Volume Unit for volume mode */}
                {mode === "volume" && (
                  <div className="space-y-2">
                    <Label>Result Volume Unit</Label>
                    <Select value={volumeUnit} onValueChange={(v) => setVolumeUnit(v as VolumeUnit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="L">Liters (L)</SelectItem>
                        <SelectItem value="mL">Milliliters (mL)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  {getModeTitle()}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{getResultLabel()}</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">{getResultValue()}</p>
                      <p className="text-sm text-purple-500">{getResultUnit()}</p>
                    </div>

                    {/* Show Steps Toggle */}
                    <div className="mt-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowSteps(!showSteps)}
                        className="w-full text-purple-600"
                      >
                        {showSteps ? "Hide Steps" : "Show Steps"}
                      </Button>

                      {showSteps && (
                        <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                          {mode === "molarity" && (
                            <>
                              <p className="font-medium">Formula: M = n ÷ V</p>
                              <p>n (moles) = {formatNumber(result.moles)} mol</p>
                              <p>
                                V (volume) = {formatNumber(result.volume)} {result.volumeUnit}
                                {result.volumeUnit === "mL" && ` = ${formatNumber(result.volume / 1000)} L`}
                              </p>
                              <p className="font-medium text-purple-600">
                                M = {formatNumber(result.moles)} ÷{" "}
                                {formatNumber(result.volumeUnit === "mL" ? result.volume / 1000 : result.volume)} ={" "}
                                {formatNumber(result.molarity)} M
                              </p>
                            </>
                          )}
                          {mode === "moles" && (
                            <>
                              <p className="font-medium">Formula: n = M × V</p>
                              <p>M (molarity) = {formatNumber(result.molarity)} mol/L</p>
                              <p>
                                V (volume) = {formatNumber(result.volume)} {result.volumeUnit}
                                {result.volumeUnit === "mL" && ` = ${formatNumber(result.volume / 1000)} L`}
                              </p>
                              <p className="font-medium text-purple-600">
                                n = {formatNumber(result.molarity)} ×{" "}
                                {formatNumber(result.volumeUnit === "mL" ? result.volume / 1000 : result.volume)} ={" "}
                                {formatNumber(result.moles)} mol
                              </p>
                            </>
                          )}
                          {mode === "volume" && (
                            <>
                              <p className="font-medium">Formula: V = n ÷ M</p>
                              <p>n (moles) = {formatNumber(result.moles)} mol</p>
                              <p>M (molarity) = {formatNumber(result.molarity)} mol/L</p>
                              <p className="font-medium text-purple-600">
                                V = {formatNumber(result.moles)} ÷ {formatNumber(result.molarity)} ={" "}
                                {formatNumber(result.volumeUnit === "mL" ? result.volume / 1000 : result.volume)} L
                                {result.volumeUnit === "mL" && ` = ${formatNumber(result.volume)} mL`}
                              </p>
                            </>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Molarity Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-mono font-semibold text-purple-700 text-center">M = n ÷ V</p>
                      <p className="text-xs text-purple-600 text-center mt-1">Molarity = Moles ÷ Volume</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-mono font-semibold text-blue-700 text-center">n = M × V</p>
                      <p className="text-xs text-blue-600 text-center mt-1">Moles = Molarity × Volume</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-mono font-semibold text-green-700 text-center">V = n ÷ M</p>
                      <p className="text-xs text-green-600 text-center mt-1">Volume = Moles ÷ Molarity</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Reference</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between">
                    <span>Molarity (M)</span>
                    <span className="font-mono">mol/L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Moles (n)</span>
                    <span className="font-mono">mol</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Volume (V)</span>
                    <span className="font-mono">L or mL</span>
                  </div>
                  <div className="pt-2 border-t">
                    <p className="text-xs">1 L = 1000 mL</p>
                    <p className="text-xs">1 M = 1 mol/L = 1 mmol/mL</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results assume ideal solutions and accurate measurements. Always verify calculations for
                        critical laboratory work.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Molarity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Molarity (M) is one of the most commonly used units of concentration in chemistry. It measures the
                  number of moles of a solute (the substance being dissolved) per liter of solution. Molarity is
                  expressed in moles per liter (mol/L), which is often abbreviated simply as M. For example, a 1 M
                  solution contains exactly one mole of solute dissolved in enough solvent to make one liter of total
                  solution.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding molarity is fundamental to chemistry laboratory work, as it allows scientists to prepare
                  solutions with precise concentrations for experiments, calculate reaction stoichiometry, and compare
                  the strengths of different solutions. Whether you're preparing a buffer solution, performing a
                  titration, or diluting a stock solution, molarity calculations are essential.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Molarity Formula</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The molarity formula M = n/V is elegantly simple yet powerful. Here, M represents molarity in mol/L, n
                  represents the number of moles of solute, and V represents the volume of the solution in liters. This
                  formula can be rearranged to solve for any of the three variables when the other two are known.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Calculating Molarity</h4>
                    <p className="text-purple-700 text-sm">
                      When you know the moles of solute and volume of solution, divide moles by volume (in liters) to
                      get molarity. For example: 0.5 mol in 0.25 L = 2 M solution.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Calculating Moles</h4>
                    <p className="text-blue-700 text-sm">
                      When you know the molarity and volume, multiply them together to find moles. For example: 2 M ×
                      0.1 L = 0.2 mol of solute needed.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Calculating Volume</h4>
                    <p className="text-green-700 text-sm">
                      When you know the moles and desired molarity, divide moles by molarity to find the required
                      volume. For example: 0.5 mol ÷ 2 M = 0.25 L of solution.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Molarity calculations are used throughout chemistry and related fields. In analytical chemistry,
                  precise molar solutions are essential for titrations and standardization procedures. In biochemistry
                  and molecular biology, buffers and reagent solutions must be prepared at exact molarities for
                  reproducible experimental results.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Pharmaceutical and clinical laboratories rely on molarity for drug formulations and diagnostic tests.
                  Industrial chemistry uses these calculations for large-scale production processes. Even in educational
                  settings, understanding molarity is crucial for students learning to prepare solutions and perform
                  quantitative experiments safely and accurately.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Always use liters for volume:</strong> The molarity formula requires volume in liters.
                    Convert mL to L by dividing by 1000.
                  </li>
                  <li>
                    <strong>Solution vs. Solvent:</strong> Remember that molarity is based on the total solution volume,
                    not just the solvent volume. When preparing solutions, add solute first, then bring to final volume.
                  </li>
                  <li>
                    <strong>Temperature effects:</strong> Volume changes with temperature, so molarity can vary slightly
                    at different temperatures. For precise work, note the temperature at which the solution was
                    prepared.
                  </li>
                  <li>
                    <strong>Significant figures:</strong> Report your answer with the appropriate number of significant
                    figures based on your input measurements.
                  </li>
                  <li>
                    <strong>Unit conversion:</strong> When working with millimoles (mmol) and milliliters (mL), note
                    that mmol/mL equals mol/L, so the molarity value remains the same.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
