"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Box, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface MixRatio {
  cement: number
  sand: number
  aggregate: number
}

interface RCCResult {
  cementBags: number
  cementKg: number
  sandM3: number
  sandKg: number
  aggregateM3: number
  aggregateKg: number
}

const mixRatios: Record<string, MixRatio> = {
  M10: { cement: 1, sand: 3, aggregate: 6 },
  M15: { cement: 1, sand: 2, aggregate: 4 },
  M20: { cement: 1, sand: 1.5, aggregate: 3 },
  M25: { cement: 1, sand: 1, aggregate: 2 },
  M30: { cement: 1, sand: 1, aggregate: 1.5 },
  "1:3:6": { cement: 1, sand: 3, aggregate: 6 },
  "1:2:4": { cement: 1, sand: 2, aggregate: 4 },
  "1:1.5:3": { cement: 1, sand: 1.5, aggregate: 3 },
}

export function RCCMaterialCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [volume, setVolume] = useState("")
  const [selectedMix, setSelectedMix] = useState("M20")
  const [customCement, setCustomCement] = useState("1")
  const [customSand, setCustomSand] = useState("1.5")
  const [customAggregate, setCustomAggregate] = useState("3")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [cementBagSize, setCementBagSize] = useState("50")
  const [wastagePercent, setWastagePercent] = useState("5")
  const [result, setResult] = useState<RCCResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateMaterials = () => {
    setError("")
    setResult(null)

    const volumeNum = parseFloat(volume)
    if (isNaN(volumeNum) || volumeNum <= 0) {
      setError("Please enter a valid concrete volume greater than 0")
      return
    }

    const dryFactor = parseFloat(dryVolumeFactor)
    if (isNaN(dryFactor) || dryFactor <= 0) {
      setError("Please enter a valid dry volume factor")
      return
    }

    const bagSize = parseFloat(cementBagSize)
    if (isNaN(bagSize) || bagSize <= 0) {
      setError("Please enter a valid cement bag size")
      return
    }

    const wastage = parseFloat(wastagePercent)
    if (isNaN(wastage) || wastage < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }

    // Get mix ratio
    let ratio: MixRatio
    if (selectedMix === "custom") {
      const c = parseFloat(customCement)
      const s = parseFloat(customSand)
      const a = parseFloat(customAggregate)
      if (isNaN(c) || isNaN(s) || isNaN(a) || c <= 0 || s <= 0 || a <= 0) {
        setError("Please enter valid custom mix ratios")
        return
      }
      ratio = { cement: c, sand: s, aggregate: a }
    } else {
      ratio = mixRatios[selectedMix]
    }

    // Convert volume to m³ if needed
    const volumeM3 = unitSystem === "imperial" ? volumeNum * 0.0283168 : volumeNum

    // Calculate dry volume
    const dryVolume = volumeM3 * dryFactor

    // Calculate total ratio
    const totalRatio = ratio.cement + ratio.sand + ratio.aggregate

    // Calculate individual volumes
    const cementVolume = (dryVolume * ratio.cement) / totalRatio
    const sandVolume = (dryVolume * ratio.sand) / totalRatio
    const aggregateVolume = (dryVolume * ratio.aggregate) / totalRatio

    // Apply wastage
    const wastageMultiplier = 1 + wastage / 100

    // Calculate weights (densities in kg/m³)
    const cementDensity = 1440
    const sandDensity = 1600
    const aggregateDensity = 1500

    const cementKg = cementVolume * cementDensity * wastageMultiplier
    const sandKg = sandVolume * sandDensity * wastageMultiplier
    const aggregateKg = aggregateVolume * aggregateDensity * wastageMultiplier

    // Calculate cement bags
    const cementBags = cementKg / bagSize

    setResult({
      cementBags: Math.round(cementBags * 10) / 10,
      cementKg: Math.round(cementKg * 10) / 10,
      sandM3: Math.round(sandVolume * wastageMultiplier * 100) / 100,
      sandKg: Math.round(sandKg * 10) / 10,
      aggregateM3: Math.round(aggregateVolume * wastageMultiplier * 100) / 100,
      aggregateKg: Math.round(aggregateKg * 10) / 10,
    })
  }

  const handleReset = () => {
    setVolume("")
    setSelectedMix("M20")
    setCustomCement("1")
    setCustomSand("1.5")
    setCustomAggregate("3")
    setDryVolumeFactor("1.54")
    setCementBagSize("50")
    setWastagePercent("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `RCC Material Requirements:\nCement: ${result.cementBags} bags (${result.cementKg} kg)\nSand: ${result.sandM3} m³ (${result.sandKg} kg)\nAggregate: ${result.aggregateM3} m³ (${result.aggregateKg} kg)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "RCC Material Requirements",
          text: `Cement: ${result.cementBags} bags, Sand: ${result.sandM3} m³, Aggregate: ${result.aggregateM3} m³`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setVolume("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Box className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">RCC Material Calculator</CardTitle>
                    <CardDescription>Calculate cement, sand, and aggregate quantities</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="volume">
                    Concrete Volume ({unitSystem === "metric" ? "m³" : "ft³"})
                  </Label>
                  <Input
                    id="volume"
                    type="number"
                    placeholder="Enter concrete volume"
                    value={volume}
                    onChange={(e) => setVolume(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mix">Concrete Grade / Mix Ratio</Label>
                  <Select value={selectedMix} onValueChange={setSelectedMix}>
                    <SelectTrigger id="mix">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M10">M10 (1:3:6)</SelectItem>
                      <SelectItem value="M15">M15 (1:2:4)</SelectItem>
                      <SelectItem value="M20">M20 (1:1.5:3)</SelectItem>
                      <SelectItem value="M25">M25 (1:1:2)</SelectItem>
                      <SelectItem value="M30">M30 (1:1:1.5)</SelectItem>
                      <SelectItem value="1:3:6">1:3:6</SelectItem>
                      <SelectItem value="1:2:4">1:2:4</SelectItem>
                      <SelectItem value="1:1.5:3">1:1.5:3</SelectItem>
                      <SelectItem value="custom">Custom Ratio</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {selectedMix === "custom" && (
                  <div className="space-y-2">
                    <Label>Custom Mix Ratio (Cement:Sand:Aggregate)</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Input
                        type="number"
                        placeholder="Cement"
                        value={customCement}
                        onChange={(e) => setCustomCement(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                      <Input
                        type="number"
                        placeholder="Sand"
                        value={customSand}
                        onChange={(e) => setCustomSand(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                      <Input
                        type="number"
                        placeholder="Aggregate"
                        value={customAggregate}
                        onChange={(e) => setCustomAggregate(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="dryFactor">Dry Volume Factor</Label>
                    <Input
                      id="dryFactor"
                      type="number"
                      value={dryVolumeFactor}
                      onChange={(e) => setDryVolumeFactor(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bagSize">Cement Bag Size (kg)</Label>
                    <Input
                      id="bagSize"
                      type="number"
                      value={cementBagSize}
                      onChange={(e) => setCementBagSize(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="wastage">Wastage Percentage (%)</Label>
                  <Input
                    id="wastage"
                    type="number"
                    placeholder="Enter wastage percentage"
                    value={wastagePercent}
                    onChange={(e) => setWastagePercent(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculateMaterials} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Materials
                </Button>

                {result && (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Cement Required</p>
                          <p className="text-2xl font-bold text-amber-600">
                            {result.cementBags} bags
                          </p>
                          <p className="text-sm text-amber-700">({result.cementKg} kg)</p>
                        </div>
                        <div className="border-t border-amber-200 pt-3 space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Sand:</span>
                            <div className="text-right">
                              <p className="font-semibold text-amber-700">{result.sandM3} m³</p>
                              <p className="text-xs text-amber-600">({result.sandKg} kg)</p>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Aggregate:</span>
                            <div className="text-right">
                              <p className="font-semibold text-amber-700">{result.aggregateM3} m³</p>
                              <p className="text-xs text-amber-600">({result.aggregateKg} kg)</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-xs">
                      <p className="font-medium mb-1">Note:</p>
                      <p>
                        Material quantities are approximate. Site conditions, compaction, and wastage may affect actual
                        consumption.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Mix Ratios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-amber-800">M10</span>
                        <span className="text-sm text-amber-600">1:3:6</span>
                      </div>
                      <p className="text-xs text-amber-700 mt-1">Low strength, PCC work</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-amber-800">M20</span>
                        <span className="text-sm text-amber-600">1:1.5:3</span>
                      </div>
                      <p className="text-xs text-amber-700 mt-1">Standard RCC, slabs, beams</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-amber-800">M25</span>
                        <span className="text-sm text-amber-600">1:1:2</span>
                      </div>
                      <p className="text-xs text-amber-700 mt-1">High strength structures</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Material Densities</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Cement:</span>
                    <span className="font-medium">1440 kg/m³</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Sand:</span>
                    <span className="font-medium">1600 kg/m³</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Aggregate:</span>
                    <span className="font-medium">1500 kg/m³</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is RCC Material Calculation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  RCC (Reinforced Cement Concrete) material calculation is essential for determining the exact quantities
                  of cement, sand, and coarse aggregate required for any concrete construction project. This calculation
                  ensures optimal material procurement, cost estimation, and reduces wastage on construction sites. The
                  process involves converting wet concrete volume to dry volume using a factor of 1.54, then distributing
                  this dry volume according to the specified mix ratio.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Different concrete grades (M10, M15, M20, M25, M30) have specific mix ratios that determine the strength
                  and durability of the concrete. M20 grade concrete (1:1.5:3 ratio) is commonly used for residential
                  construction including slabs, beams, and columns. Higher grades like M25 and M30 are used for structures
                  requiring greater strength such as high-rise buildings and bridges. Understanding these ratios helps
                  engineers and contractors prepare accurate material requirements and maintain construction quality.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How RCC Materials are Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation begins with the wet volume of concrete required, which is then multiplied by 1.54 to get
                  the dry volume. This factor accounts for the voids between aggregates and the volume reduction that
                  occurs during mixing. For example, if you need 1 m³ of concrete, you'll need 1.54 m³ of dry materials.
                  The dry volume is then divided according to the mix ratio to determine individual material volumes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For M20 concrete with a 1:1.5:3 ratio, the total ratio is 5.5 (1+1.5+3). If the dry volume is 1.54 m³,
                  cement volume would be (1.54 × 1) ÷ 5.5 = 0.28 m³. This is then converted to weight using cement density
                  (1440 kg/m³), giving approximately 403 kg or about 8 bags of 50 kg cement. Similarly, sand and aggregate
                  quantities are calculated using their respective densities of 1600 kg/m³ and 1500 kg/m³. Adding 5-10%
                  wastage ensures adequate materials are available on site to account for spillage, moisture content, and
                  handling losses.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While these calculations provide accurate estimates, several factors can affect actual material
                  consumption on site. The moisture content in sand and aggregate can add 15-25% to the measured volume,
                  requiring adjustment in material procurement. Proper storage of cement is crucial as it can lose strength
                  when exposed to moisture. Sand should be free from clay, silt, and organic matter to ensure good bonding
                  with cement.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The quality of materials directly impacts concrete strength. Use clean, potable water for mixing, and
                  ensure coarse aggregates are of proper size (typically 10mm, 20mm, or 40mm). On-site testing and quality
                  checks help maintain consistency. For critical structures, it's recommended to consult with structural
                  engineers and use ready-mix concrete from certified suppliers to ensure compliance with design
                  specifications and building codes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
