"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Beaker } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type MassUnit = "g" | "mg" | "kg"

interface FaradayResult {
  mass: number
  charge: number
  moles: number
  displayUnit: string
}

const FARADAY_CONSTANT = 96485 // C/mol

export function FaradaysLawCalculator() {
  const [massUnit, setMassUnit] = useState<MassUnit>("g")
  const [current, setCurrent] = useState("")
  const [time, setTime] = useState("")
  const [electrons, setElectrons] = useState("")
  const [molarMass, setMolarMass] = useState("")
  const [result, setResult] = useState<FaradayResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const I = Number.parseFloat(current)
    const t = Number.parseFloat(time)
    const n = Number.parseFloat(electrons)
    const M = Number.parseFloat(molarMass)

    if (isNaN(I) || I <= 0) {
      setError("Please enter a valid current greater than 0")
      return
    }
    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid time greater than 0")
      return
    }
    if (isNaN(n) || n < 1) {
      setError("Number of electrons must be at least 1")
      return
    }
    if (isNaN(M) || M <= 0) {
      setError("Please enter a valid molar mass greater than 0")
      return
    }

    // Calculate charge: Q = I × t
    const Q = I * t

    // Calculate mass: m = (Q × M) / (n × F)
    const massInGrams = (Q * M) / (n * FARADAY_CONSTANT)

    // Calculate moles
    const moles = Q / (n * FARADAY_CONSTANT)

    // Convert mass based on selected unit
    let displayMass: number
    let displayUnit: string

    switch (massUnit) {
      case "mg":
        displayMass = massInGrams * 1000
        displayUnit = "mg"
        break
      case "kg":
        displayMass = massInGrams / 1000
        displayUnit = "kg"
        break
      default:
        displayMass = massInGrams
        displayUnit = "g"
    }

    setResult({
      mass: displayMass,
      charge: Q,
      moles: moles,
      displayUnit: displayUnit,
    })
  }

  const handleReset = () => {
    setCurrent("")
    setTime("")
    setElectrons("")
    setMolarMass("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Mass deposited: ${result.mass.toExponential(4)} ${result.displayUnit}, Charge passed: ${result.charge.toFixed(2)} C`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Faraday's Law Calculation",
          text: `Mass deposited: ${result.mass.toExponential(4)} ${result.displayUnit}, Charge passed: ${result.charge.toFixed(2)} C`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 10000) {
      return num.toExponential(4)
    }
    return num.toFixed(6).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Faraday's Law Calculator</CardTitle>
                    <CardDescription>Calculate mass deposited during electrolysis</CardDescription>
                  </div>
                </div>

                {/* Mass Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Mass Unit</span>
                  <div className="flex gap-1 p-1 bg-muted rounded-lg">
                    {(["g", "mg", "kg"] as MassUnit[]).map((unit) => (
                      <button
                        key={unit}
                        onClick={() => setMassUnit(unit)}
                        className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                          massUnit === unit
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {unit}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Current Input */}
                <div className="space-y-2">
                  <Label htmlFor="current">Current (A)</Label>
                  <Input
                    id="current"
                    type="number"
                    placeholder="Enter current in amperes"
                    value={current}
                    onChange={(e) => setCurrent(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Time Input */}
                <div className="space-y-2">
                  <Label htmlFor="time">Time (s)</Label>
                  <Input
                    id="time"
                    type="number"
                    placeholder="Enter time in seconds"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Electrons Input */}
                <div className="space-y-2">
                  <Label htmlFor="electrons">Number of Electrons Transferred (n)</Label>
                  <Input
                    id="electrons"
                    type="number"
                    placeholder="e.g., 2 for Cu²⁺, 3 for Al³⁺"
                    value={electrons}
                    onChange={(e) => setElectrons(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Molar Mass Input */}
                <div className="space-y-2">
                  <Label htmlFor="molarMass">Molar Mass (g/mol)</Label>
                  <Input
                    id="molarMass"
                    type="number"
                    placeholder="e.g., 63.55 for Cu, 26.98 for Al"
                    value={molarMass}
                    onChange={(e) => setMolarMass(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Mass
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Mass Deposited</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">{formatNumber(result.mass)}</p>
                      <p className="text-lg font-semibold text-purple-600">{result.displayUnit}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 pt-4 border-t border-purple-200 grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-xs text-muted-foreground">Charge Passed</p>
                        <p className="text-lg font-semibold text-purple-700">{result.charge.toFixed(2)} C</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Moles Deposited</p>
                        <p className="text-lg font-semibold text-purple-700">{formatNumber(result.moles)} mol</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Faraday's Law Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Q = I × t</p>
                    <p className="font-semibold text-foreground">m = (Q × M) / (n × F)</p>
                  </div>
                  <p>
                    Where <strong>Q</strong> = charge (C), <strong>I</strong> = current (A), <strong>t</strong> = time
                    (s), <strong>M</strong> = molar mass (g/mol), <strong>n</strong> = electrons transferred,{" "}
                    <strong>F</strong> = 96,485 C/mol
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Electrodeposition Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span>Copper (Cu²⁺)</span>
                      <span className="font-mono">n=2, M=63.55</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span>Silver (Ag⁺)</span>
                      <span className="font-mono">n=1, M=107.87</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span>Aluminum (Al³⁺)</span>
                      <span className="font-mono">n=3, M=26.98</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span>Gold (Au³⁺)</span>
                      <span className="font-mono">n=3, M=196.97</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span>Zinc (Zn²⁺)</span>
                      <span className="font-mono">n=2, M=65.38</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Content Cards */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Faraday's Law of Electrolysis?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Faraday's laws of electrolysis are quantitative relationships discovered by Michael Faraday in 1834
                  that describe the amount of substance deposited or liberated at an electrode during electrolysis.
                  These laws form the foundation of electrochemistry and are essential for understanding and predicting
                  the outcomes of electrochemical processes used in industries such as electroplating, metal refining,
                  and battery technology.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The first law states that the mass of a substance deposited at an electrode is directly proportional
                  to the quantity of electricity (charge) passed through the electrolyte. The second law states that
                  when the same quantity of electricity passes through different electrolytes, the masses of substances
                  deposited are proportional to their chemical equivalent weights.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>How Does Electrolysis Work?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrolysis is a process that uses electrical energy to drive a non-spontaneous chemical reaction.
                  When an electric current passes through an electrolyte (a solution or molten substance containing
                  ions), cations migrate toward the cathode (negative electrode) where they gain electrons (reduction),
                  while anions migrate toward the anode (positive electrode) where they lose electrons (oxidation).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The number of electrons transferred (n) in the equation corresponds to the charge of the ion being
                  deposited. For example, Cu²⁺ requires 2 electrons to become Cu metal, so n=2. The Faraday constant
                  (96,485 C/mol) represents the charge of one mole of electrons, linking the macroscopic measurement
                  of current to the microscopic world of atoms and electrons.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Faraday's Law</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Faraday's law has numerous practical applications in industry and research. Electroplating uses
                  electrolysis to coat objects with thin layers of metals for corrosion protection, decorative
                  finishes, or improved wear resistance. Industries electroplate jewelry with gold or silver, protect
                  car parts with chrome, and coat electronic connectors with nickel or tin.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Electrorefining purifies metals by electrolyzing impure metals as anodes and depositing pure metal at
                  the cathode. This process is essential for producing high-purity copper for electrical wiring.
                  Additionally, electrolysis is used in the production of chlorine and sodium hydroxide (chlor-alkali
                  process), aluminum extraction (Hall-Héroult process), and hydrogen generation from water.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations & Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator assumes ideal electrolysis conditions with 100% current efficiency. In practice,
                  several factors can reduce the actual mass deposited: competing side reactions (such as hydrogen
                  evolution at the cathode), energy losses due to solution resistance, incomplete dissolution of the
                  anode material, and formation of oxide layers or impurities.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Disclaimer:</strong> Calculations assume ideal electrolysis and 100% efficiency. Actual
                    deposition may vary due to side reactions, incomplete current utilization, temperature effects, and
                    concentration gradients. For precise industrial applications, experimental calibration is
                    recommended.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
