"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Layers, Info, AlertTriangle, Calculator, Ruler } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type WallThickness = "single" | "double" | "custom"

interface BrickResult {
  wallArea: number
  brickFaceArea: number
  bricksRequired: number
  totalBricksWithWaste: number
  bricksPerUnit: number
  mortarVolume: number
}

export function BrickCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [wallLength, setWallLength] = useState("")
  const [wallHeight, setWallHeight] = useState("")
  const [wallThickness, setWallThickness] = useState<WallThickness>("single")
  const [customThickness, setCustomThickness] = useState("")
  const [brickLength, setBrickLength] = useState(unitSystem === "metric" ? "230" : "8")
  const [brickWidth, setBrickWidth] = useState(unitSystem === "metric" ? "110" : "3.625")
  const [brickHeight, setBrickHeight] = useState(unitSystem === "metric" ? "76" : "2.25")
  const [mortarThickness, setMortarThickness] = useState(unitSystem === "metric" ? "10" : "0.375")
  const [openingsArea, setOpeningsArea] = useState("")
  const [wastePercentage, setWastePercentage] = useState("7")
  const [result, setResult] = useState<BrickResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateBricks = () => {
    setError("")
    setResult(null)

    const length = Number.parseFloat(wallLength)
    const height = Number.parseFloat(wallHeight)
    const bLength = Number.parseFloat(brickLength)
    const bWidth = Number.parseFloat(brickWidth)
    const bHeight = Number.parseFloat(brickHeight)
    const mortar = Number.parseFloat(mortarThickness)
    const openings = Number.parseFloat(openingsArea) || 0
    const waste = Number.parseFloat(wastePercentage) || 0

    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid wall length greater than 0")
      return
    }
    if (isNaN(height) || height <= 0) {
      setError("Please enter a valid wall height greater than 0")
      return
    }
    if (isNaN(bLength) || bLength <= 0 || isNaN(bWidth) || bWidth <= 0 || isNaN(bHeight) || bHeight <= 0) {
      setError("Please enter valid brick dimensions greater than 0")
      return
    }
    if (isNaN(mortar) || mortar < 0) {
      setError("Mortar thickness cannot be negative")
      return
    }

    // Calculate wall area
    const wallArea = length * height - openings

    if (wallArea <= 0) {
      setError("Opening area cannot exceed or equal wall area")
      return
    }

    // Convert brick dimensions to consistent units for calculation
    let brickLengthM: number, brickHeightM: number, brickWidthM: number, mortarM: number

    if (unitSystem === "metric") {
      // Convert mm to meters
      brickLengthM = bLength / 1000
      brickHeightM = bHeight / 1000
      brickWidthM = bWidth / 1000
      mortarM = mortar / 1000
    } else {
      // Convert inches to feet
      brickLengthM = bLength / 12
      brickHeightM = bHeight / 12
      brickWidthM = bWidth / 12
      mortarM = mortar / 12
    }

    // Brick face area including mortar joint
    const brickFaceArea = (brickLengthM + mortarM) * (brickHeightM + mortarM)

    // Determine wall thickness multiplier
    let thicknessMultiplier = 1
    if (wallThickness === "double") {
      thicknessMultiplier = 2
    } else if (wallThickness === "custom") {
      const customT = Number.parseFloat(customThickness)
      if (isNaN(customT) || customT <= 0) {
        setError("Please enter a valid custom thickness")
        return
      }
      const brickWidthInUnits = unitSystem === "metric" ? brickWidthM * 1000 : brickWidthM * 12
      thicknessMultiplier = Math.ceil(customT / brickWidthInUnits)
    }

    // Number of bricks required
    const bricksRequired = Math.ceil((wallArea / brickFaceArea) * thicknessMultiplier)

    // Total bricks with waste
    const totalBricksWithWaste = Math.ceil(bricksRequired * (1 + waste / 100))

    // Bricks per square unit
    const bricksPerUnit = (1 / brickFaceArea) * thicknessMultiplier

    // Estimate mortar volume (approximate: 30% of brick volume per brick)
    const brickVolume = brickLengthM * brickWidthM * brickHeightM
    const mortarVolume = totalBricksWithWaste * brickVolume * 0.3

    setResult({
      wallArea,
      brickFaceArea,
      bricksRequired,
      totalBricksWithWaste,
      bricksPerUnit,
      mortarVolume,
    })
  }

  const handleReset = () => {
    setWallLength("")
    setWallHeight("")
    setWallThickness("single")
    setCustomThickness("")
    setBrickLength(unitSystem === "metric" ? "230" : "8")
    setBrickWidth(unitSystem === "metric" ? "110" : "3.625")
    setBrickHeight(unitSystem === "metric" ? "76" : "2.25")
    setMortarThickness(unitSystem === "metric" ? "10" : "0.375")
    setOpeningsArea("")
    setWastePercentage("7")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Brick Calculator Results:\nWall Area: ${result.wallArea.toFixed(2)} ${unitSystem === "metric" ? "m²" : "ft²"}\nBricks Required: ${result.bricksRequired}\nTotal with Waste: ${result.totalBricksWithWaste}\nMortar Volume: ${result.mortarVolume.toFixed(3)} ${unitSystem === "metric" ? "m³" : "ft³"}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Brick Calculator Results",
          text: `I calculated brick requirements using CalcHub! Total bricks needed: ${result.totalBricksWithWaste}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    const newSystem = unitSystem === "metric" ? "imperial" : "metric"
    setUnitSystem(newSystem)
    // Update default brick dimensions
    if (newSystem === "metric") {
      setBrickLength("230")
      setBrickWidth("110")
      setBrickHeight("76")
      setMortarThickness("10")
    } else {
      setBrickLength("8")
      setBrickWidth("3.625")
      setBrickHeight("2.25")
      setMortarThickness("0.375")
    }
    setWallLength("")
    setWallHeight("")
    setOpeningsArea("")
    setCustomThickness("")
    setResult(null)
    setError("")
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"
  const areaUnit = unitSystem === "metric" ? "m²" : "ft²"
  const volumeUnit = unitSystem === "metric" ? "m³" : "ft³"
  const brickDimUnit = unitSystem === "metric" ? "mm" : "in"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Brick Calculator</CardTitle>
                    <CardDescription>Calculate bricks and mortar needed</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Wall Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="wallLength">Wall Length ({lengthUnit})</Label>
                    <Input
                      id="wallLength"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "10" : "30"}`}
                      value={wallLength}
                      onChange={(e) => setWallLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wallHeight">Wall Height ({lengthUnit})</Label>
                    <Input
                      id="wallHeight"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "3" : "10"}`}
                      value={wallHeight}
                      onChange={(e) => setWallHeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Wall Thickness */}
                <div className="space-y-2">
                  <Label>Wall Thickness</Label>
                  <Select value={wallThickness} onValueChange={(v) => setWallThickness(v as WallThickness)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single">Single Brick (Half Brick)</SelectItem>
                      <SelectItem value="double">Double Brick (Full Brick)</SelectItem>
                      <SelectItem value="custom">Custom Thickness</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {wallThickness === "custom" && (
                  <div className="space-y-2">
                    <Label htmlFor="customThickness">Custom Thickness ({brickDimUnit})</Label>
                    <Input
                      id="customThickness"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "220" : "9"}`}
                      value={customThickness}
                      onChange={(e) => setCustomThickness(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                )}

                {/* Brick Dimensions */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Brick Dimensions ({brickDimUnit})</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label htmlFor="brickLength" className="text-xs text-muted-foreground">
                        Length
                      </Label>
                      <Input
                        id="brickLength"
                        type="number"
                        value={brickLength}
                        onChange={(e) => setBrickLength(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="brickWidth" className="text-xs text-muted-foreground">
                        Width
                      </Label>
                      <Input
                        id="brickWidth"
                        type="number"
                        value={brickWidth}
                        onChange={(e) => setBrickWidth(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="brickHeight" className="text-xs text-muted-foreground">
                        Height
                      </Label>
                      <Input
                        id="brickHeight"
                        type="number"
                        value={brickHeight}
                        onChange={(e) => setBrickHeight(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                </div>

                {/* Mortar Thickness */}
                <div className="space-y-2">
                  <Label htmlFor="mortarThickness">Mortar Joint Thickness ({brickDimUnit})</Label>
                  <Input
                    id="mortarThickness"
                    type="number"
                    value={mortarThickness}
                    onChange={(e) => setMortarThickness(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Optional Fields */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="openingsArea">Openings Area ({areaUnit})</Label>
                    <Input
                      id="openingsArea"
                      type="number"
                      placeholder="Doors/windows"
                      value={openingsArea}
                      onChange={(e) => setOpeningsArea(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wastePercentage">Waste (%)</Label>
                    <Input
                      id="wastePercentage"
                      type="number"
                      value={wastePercentage}
                      onChange={(e) => setWastePercentage(e.target.value)}
                      min="0"
                      max="50"
                      step="1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBricks} className="w-full" size="lg">
                  Calculate Bricks
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Bricks Required</p>
                      <p className="text-5xl font-bold text-amber-600 mb-1">
                        {result.totalBricksWithWaste.toLocaleString()}
                      </p>
                      <p className="text-sm text-muted-foreground">(including {wastePercentage}% waste)</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Net Bricks</p>
                        <p className="font-semibold">{result.bricksRequired.toLocaleString()}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Wall Area</p>
                        <p className="font-semibold">
                          {result.wallArea.toFixed(2)} {areaUnit}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Bricks/{areaUnit}</p>
                        <p className="font-semibold">{result.bricksPerUnit.toFixed(1)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Mortar Volume</p>
                        <p className="font-semibold">
                          {result.mortarVolume.toFixed(3)} {volumeUnit}
                        </p>
                      </div>
                    </div>

                    {/* Show Steps Toggle */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mb-3 text-amber-700"
                    >
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {showSteps && (
                      <div className="p-3 bg-white rounded-lg text-sm space-y-2 mb-4">
                        <p>
                          <strong>Step 1:</strong> Wall Area = {wallLength} × {wallHeight} - {openingsArea || 0} ={" "}
                          {result.wallArea.toFixed(2)} {areaUnit}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Brick Face Area (with mortar) = ({brickLength} + {mortarThickness}) ×
                          ({brickHeight} + {mortarThickness}) ={" "}
                          {(result.brickFaceArea * (unitSystem === "metric" ? 1000000 : 144)).toFixed(2)}{" "}
                          {unitSystem === "metric" ? "mm²" : "in²"}
                        </p>
                        <p>
                          <strong>Step 3:</strong> Net Bricks = Wall Area ÷ Brick Face Area × Thickness Factor ={" "}
                          {result.bricksRequired}
                        </p>
                        <p>
                          <strong>Step 4:</strong> Total with Waste = {result.bricksRequired} × (1 + {wastePercentage}%)
                          = {result.totalBricksWithWaste}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Brick Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <p className="font-medium text-amber-800">Modular Brick (US)</p>
                      <p className="text-sm text-amber-700">8" × 3⅝" × 2¼" (203 × 92 × 57 mm)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <p className="font-medium text-orange-800">Standard Brick (UK)</p>
                      <p className="text-sm text-orange-700">215 × 102.5 × 65 mm (8.5" × 4" × 2.5")</p>
                    </div>
                    <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                      <p className="font-medium text-red-800">Standard Brick (India)</p>
                      <p className="text-sm text-red-700">230 × 110 × 76 mm (9" × 4.3" × 3")</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Brick Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Wall Area = L × H − Openings</p>
                    <p className="font-semibold text-foreground">Bricks = Area ÷ (Brick Face Area)</p>
                    <p className="font-semibold text-foreground">Total = Bricks × (1 + Waste%)</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual brick and mortar requirements may vary based on workmanship, brick
                        quality, and site conditions. Always consult a professional for critical projects.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Brick Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Accurate brick calculation is essential for any masonry project, whether you're building a garden
                  wall, a boundary fence, or an entire house. Underestimating can lead to project delays and additional
                  costs, while overestimating results in wasted materials and money. This calculator helps you determine
                  the exact number of bricks needed based on your wall dimensions, brick size, and mortar joint
                  thickness.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The calculation takes into account several factors: the total wall area minus any openings for doors
                  and windows, the face area of each brick including mortar joints, and a waste percentage to account
                  for breakage and cutting. Different wall thicknesses (single or double brick) are also considered, as
                  they significantly affect the total number of bricks required.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Wall Thickness Options</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Single Brick (Half Brick Wall)</h4>
                    <p className="text-amber-700 text-sm">
                      Also known as a half-brick wall, this is the thinnest brick wall type. Bricks are laid lengthwise
                      along the wall face. Commonly used for garden walls, partitions, and non-load-bearing
                      applications. Thickness equals the brick width (typically 100-115mm or 4 inches).
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Double Brick (Full Brick Wall)</h4>
                    <p className="text-orange-700 text-sm">
                      A full-brick wall with bricks laid in two rows. Provides better structural strength, insulation,
                      and sound reduction. Used for load-bearing walls and exterior walls. Thickness equals the brick
                      length (typically 215-230mm or 9 inches).
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-3 list-disc pl-5">
                  <li>
                    <strong>Measure Carefully:</strong> Always double-check your wall dimensions. Small measurement
                    errors can lead to significant differences in material quantities.
                  </li>
                  <li>
                    <strong>Account for All Openings:</strong> Don't forget to subtract the area of doors, windows, and
                    any other openings from the total wall area.
                  </li>
                  <li>
                    <strong>Include Waste Percentage:</strong> A waste factor of 5-10% is standard. Use the higher end
                    for complex designs with more cutting required.
                  </li>
                  <li>
                    <strong>Consider Mortar Joints:</strong> Standard mortar joint thickness is 10mm (metric) or 3/8
                    inch (imperial). Thicker or thinner joints will affect brick count.
                  </li>
                  <li>
                    <strong>Buy Extra:</strong> It's wise to order 5-10% more bricks than calculated to account for
                    breakage during delivery and construction, plus extras for future repairs.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
