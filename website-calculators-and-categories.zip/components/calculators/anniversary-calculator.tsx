"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Heart,
  Info,
  Calendar,
  Gift,
  PartyPopper,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface AnniversaryResult {
  yearsElapsed: number
  monthsElapsed: number
  daysElapsed: number
  totalDays: number
  totalWeeks: number
  totalMonths: number
  nextAnniversaryDate: Date
  daysUntilNext: number
  nextAnniversaryNumber: number
  milestones: { number: number; date: Date; passed: boolean }[]
}

export function AnniversaryCalculator() {
  const [originalDate, setOriginalDate] = useState("")
  const [referenceDate, setReferenceDate] = useState("")
  const [result, setResult] = useState<AnniversaryResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateAnniversary = () => {
    setError("")
    setResult(null)

    if (!originalDate) {
      setError("Please enter the original date")
      return
    }

    const original = new Date(originalDate)
    const reference = referenceDate ? new Date(referenceDate) : new Date()

    if (isNaN(original.getTime())) {
      setError("Please enter a valid original date")
      return
    }

    if (original > reference) {
      setError("Original date must be earlier than reference date")
      return
    }

    // Calculate elapsed time
    let years = reference.getFullYear() - original.getFullYear()
    let months = reference.getMonth() - original.getMonth()
    let days = reference.getDate() - original.getDate()

    if (days < 0) {
      months--
      const prevMonth = new Date(reference.getFullYear(), reference.getMonth(), 0)
      days += prevMonth.getDate()
    }

    if (months < 0) {
      years--
      months += 12
    }

    // Calculate totals
    const msPerDay = 1000 * 60 * 60 * 24
    const totalDays = Math.floor((reference.getTime() - original.getTime()) / msPerDay)
    const totalWeeks = Math.floor(totalDays / 7)
    const totalMonths = years * 12 + months

    // Calculate next anniversary
    let nextAnniversaryYear = reference.getFullYear()
    let nextAnniversaryDate = new Date(nextAnniversaryYear, original.getMonth(), original.getDate())

    if (nextAnniversaryDate <= reference) {
      nextAnniversaryYear++
      nextAnniversaryDate = new Date(nextAnniversaryYear, original.getMonth(), original.getDate())
    }

    const daysUntilNext = Math.ceil((nextAnniversaryDate.getTime() - reference.getTime()) / msPerDay)
    const nextAnniversaryNumber = nextAnniversaryYear - original.getFullYear()

    // Calculate milestone anniversaries
    const milestoneNumbers = [1, 5, 10, 15, 20, 25, 30, 40, 50, 75, 100]
    const milestones = milestoneNumbers.map((num) => {
      const milestoneDate = new Date(original.getFullYear() + num, original.getMonth(), original.getDate())
      return {
        number: num,
        date: milestoneDate,
        passed: milestoneDate <= reference,
      }
    })

    setResult({
      yearsElapsed: years,
      monthsElapsed: months,
      daysElapsed: days,
      totalDays,
      totalWeeks,
      totalMonths,
      nextAnniversaryDate,
      daysUntilNext,
      nextAnniversaryNumber,
      milestones,
    })
  }

  const handleReset = () => {
    setOriginalDate("")
    setReferenceDate("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Anniversary: ${result.yearsElapsed} years, ${result.monthsElapsed} months, ${result.daysElapsed} days. Next anniversary (#${result.nextAnniversaryNumber}) in ${result.daysUntilNext} days.`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Anniversary Calculator Result",
          text: `It's been ${result.yearsElapsed} years, ${result.monthsElapsed} months, and ${result.daysElapsed} days! Next anniversary (#${result.nextAnniversaryNumber}) is in ${result.daysUntilNext} days.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const getOrdinalSuffix = (num: number) => {
    const s = ["th", "st", "nd", "rd"]
    const v = num % 100
    return num + (s[(v - 20) % 10] || s[v] || s[0])
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Heart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Anniversary Calculator</CardTitle>
                    <CardDescription>Calculate time since an event and upcoming anniversaries</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Original Date */}
                <div className="space-y-2">
                  <Label htmlFor="original-date">Original Date (Event/Anniversary Start)</Label>
                  <Input
                    id="original-date"
                    type="date"
                    value={originalDate}
                    onChange={(e) => setOriginalDate(e.target.value)}
                  />
                </div>

                {/* Reference Date */}
                <div className="space-y-2">
                  <Label htmlFor="reference-date">Reference Date (Optional, defaults to today)</Label>
                  <Input
                    id="reference-date"
                    type="date"
                    value={referenceDate}
                    onChange={(e) => setReferenceDate(e.target.value)}
                    placeholder="Leave empty for today"
                  />
                  <p className="text-xs text-muted-foreground">Leave empty to calculate from today</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAnniversary} className="w-full" size="lg">
                  <Sparkles className="mr-2 h-4 w-4" />
                  Calculate Anniversary
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-gradient-to-br from-pink-50 to-purple-50 border-pink-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <div className="flex justify-center mb-2">
                        <PartyPopper className="h-8 w-8 text-pink-500" />
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">Time Elapsed</p>
                      <p className="text-3xl font-bold text-pink-600">
                        {result.yearsElapsed > 0 &&
                          `${result.yearsElapsed} year${result.yearsElapsed !== 1 ? "s" : ""}`}
                        {result.yearsElapsed > 0 && result.monthsElapsed > 0 && ", "}
                        {result.monthsElapsed > 0 &&
                          `${result.monthsElapsed} month${result.monthsElapsed !== 1 ? "s" : ""}`}
                        {(result.yearsElapsed > 0 || result.monthsElapsed > 0) && result.daysElapsed > 0 && ", "}
                        {result.daysElapsed > 0 && `${result.daysElapsed} day${result.daysElapsed !== 1 ? "s" : ""}`}
                        {result.yearsElapsed === 0 &&
                          result.monthsElapsed === 0 &&
                          result.daysElapsed === 0 &&
                          "Today!"}
                      </p>
                    </div>

                    {/* Next Anniversary */}
                    <div className="p-3 bg-white/80 rounded-lg mb-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Gift className="h-4 w-4 text-purple-500" />
                        <span className="text-sm font-medium text-purple-700">Next Anniversary</span>
                      </div>
                      <p className="text-lg font-semibold text-purple-600">
                        {getOrdinalSuffix(result.nextAnniversaryNumber)} Anniversary
                      </p>
                      <p className="text-sm text-muted-foreground">{formatDate(result.nextAnniversaryDate)}</p>
                      <p className="text-sm font-medium text-purple-500 mt-1">
                        {result.daysUntilNext === 0
                          ? "Today!"
                          : result.daysUntilNext === 1
                            ? "Tomorrow!"
                            : `${result.daysUntilNext} days away`}
                      </p>
                    </div>

                    {/* Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-between mb-2">
                          <span>View Breakdown</span>
                          {showBreakdown ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-2">
                        <div className="grid grid-cols-3 gap-2 text-center">
                          <div className="p-2 bg-white/80 rounded-lg">
                            <p className="text-xs text-muted-foreground">Total Days</p>
                            <p className="font-bold text-foreground">{result.totalDays.toLocaleString()}</p>
                          </div>
                          <div className="p-2 bg-white/80 rounded-lg">
                            <p className="text-xs text-muted-foreground">Total Weeks</p>
                            <p className="font-bold text-foreground">{result.totalWeeks.toLocaleString()}</p>
                          </div>
                          <div className="p-2 bg-white/80 rounded-lg">
                            <p className="text-xs text-muted-foreground">Total Months</p>
                            <p className="font-bold text-foreground">{result.totalMonths.toLocaleString()}</p>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-3">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              {/* Milestone Anniversaries */}
              {result && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-amber-500" />
                      Milestone Anniversaries
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {result.milestones.map((milestone) => (
                        <div
                          key={milestone.number}
                          className={`flex items-center justify-between p-2 rounded-lg ${
                            milestone.passed
                              ? "bg-green-50 border border-green-200"
                              : "bg-amber-50 border border-amber-200"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {milestone.passed ? (
                              <Check className="h-4 w-4 text-green-500" />
                            ) : (
                              <Calendar className="h-4 w-4 text-amber-500" />
                            )}
                            <span className={`font-medium ${milestone.passed ? "text-green-700" : "text-amber-700"}`}>
                              {getOrdinalSuffix(milestone.number)} Anniversary
                            </span>
                          </div>
                          <span className={`text-sm ${milestone.passed ? "text-green-600" : "text-amber-600"}`}>
                            {milestone.date.toLocaleDateString("en-US", {
                              month: "short",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Formula Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Time Elapsed Calculation</p>
                    <p>
                      The calculator computes the exact difference between the original date and reference date,
                      accounting for varying month lengths and leap years.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Next Anniversary</p>
                    <p>
                      Determined by finding the next occurrence of the original date's month and day after the reference
                      date.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Common Anniversary Types */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Anniversary Milestone Names</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1st - Paper</span>
                      <span>25th - Silver</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>5th - Wood</span>
                      <span>30th - Pearl</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>10th - Tin/Aluminum</span>
                      <span>40th - Ruby</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>15th - Crystal</span>
                      <span>50th - Gold</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>20th - China</span>
                      <span>75th - Diamond</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an Anniversary?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An anniversary marks the annual recurrence of a significant date, commemorating an event that occurred
                  on that same date in a previous year. The word comes from the Latin "anniversarius," meaning
                  "returning yearly." Anniversaries are celebrated for various milestones including weddings, business
                  founding dates, historical events, and personal achievements.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Throughout history, different cultures have assigned special significance to certain anniversary
                  years. The most well-known tradition is the wedding anniversary system, where each year is associated
                  with a traditional gift material, from paper for the first year to diamond for the 75th. These
                  traditions serve as symbols of the growing strength and value of long-term commitments.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Anniversary Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating the time between two dates involves more than simple subtraction. The varying lengths of
                  months (28-31 days) and the presence of leap years add complexity to these calculations. A leap year
                  occurs every four years (with exceptions for century years not divisible by 400), adding an extra day
                  to February.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When calculating anniversaries for dates like February 29th (leap day), special consideration is
                  needed. In non-leap years, those celebrating a leap day anniversary might observe it on February 28th
                  or March 1st, depending on personal preference or local convention.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gift className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Anniversary calculators serve many purposes beyond personal celebrations. Businesses track company
                  founding anniversaries for marketing and milestone events. Legal and financial professionals calculate
                  dates for contract renewals, policy anniversaries, and benefit eligibility. Healthcare providers track
                  treatment anniversaries and recovery milestones.
                </p>
                <div className="mt-4 grid sm:grid-cols-2 gap-4">
                  <div className="p-4 bg-pink-50 border border-pink-200 rounded-lg">
                    <h4 className="font-semibold text-pink-800 mb-2">Personal Uses</h4>
                    <ul className="text-pink-700 text-sm space-y-1">
                      <li>Wedding anniversaries</li>
                      <li>Dating milestones</li>
                      <li>Sobriety dates</li>
                      <li>Memorial dates</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Professional Uses</h4>
                    <ul className="text-purple-700 text-sm space-y-1">
                      <li>Company milestones</li>
                      <li>Employee work anniversaries</li>
                      <li>Contract renewals</li>
                      <li>Subscription tracking</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Note:</strong> Anniversary calculations are based on calendar dates and may vary due to leap
                  years and date conventions. For leap day birthdays/anniversaries, celebrations in non-leap years are
                  typically observed on February 28th or March 1st based on personal preference.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
