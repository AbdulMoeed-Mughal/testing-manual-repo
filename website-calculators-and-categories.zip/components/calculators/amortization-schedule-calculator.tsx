"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calendar,
  Info,
  AlertTriangle,
  TrendingDown,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface AmortizationEntry {
  paymentNumber: number
  paymentDate: string
  paymentAmount: number
  principal: number
  interest: number
  balance: number
}

interface AmortizationResult {
  schedule: AmortizationEntry[]
  monthlyPayment: number
  totalPayment: number
  totalInterest: number
  totalInterestWithExtra: number
  monthsSaved: number
}

export function AmortizationScheduleCalculator() {
  const [loanAmount, setLoanAmount] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [loanTerm, setLoanTerm] = useState("")
  const [termUnit, setTermUnit] = useState<"years" | "months">("years")
  const [paymentFrequency, setPaymentFrequency] = useState<"monthly" | "biweekly" | "weekly">("monthly")
  const [extraPayment, setExtraPayment] = useState("")
  const [startDate, setStartDate] = useState("")
  const [result, setResult] = useState<AmortizationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showFullSchedule, setShowFullSchedule] = useState(false)

  const calculateAmortization = () => {
    setError("")
    setResult(null)

    const principal = Number.parseFloat(loanAmount)
    const annualRate = Number.parseFloat(interestRate)
    let termMonths = Number.parseFloat(loanTerm)
    const extra = Number.parseFloat(extraPayment) || 0

    if (isNaN(principal) || principal <= 0) {
      setError("Please enter a valid loan amount greater than 0")
      return
    }
    if (isNaN(annualRate) || annualRate <= 0 || annualRate > 100) {
      setError("Please enter a valid interest rate between 0 and 100")
      return
    }
    if (isNaN(termMonths) || termMonths <= 0) {
      setError("Please enter a valid loan term greater than 0")
      return
    }

    if (termUnit === "years") {
      termMonths = termMonths * 12
    }

    // Adjust for payment frequency
    let periodsPerYear = 12
    let periodRate = annualRate / 100 / 12
    let totalPeriods = termMonths

    if (paymentFrequency === "biweekly") {
      periodsPerYear = 26
      periodRate = annualRate / 100 / 26
      totalPeriods = Math.ceil(termMonths * (26 / 12))
    } else if (paymentFrequency === "weekly") {
      periodsPerYear = 52
      periodRate = annualRate / 100 / 52
      totalPeriods = Math.ceil(termMonths * (52 / 12))
    }

    // Calculate payment using loan formula
    const payment =
      (principal * (periodRate * Math.pow(1 + periodRate, totalPeriods))) / (Math.pow(1 + periodRate, totalPeriods) - 1)

    const schedule: AmortizationEntry[] = []
    let balance = principal
    let totalInterest = 0
    let totalInterestWithExtra = 0
    let balanceWithExtra = principal
    let periodsWithExtra = 0

    const start = startDate ? new Date(startDate) : new Date()

    for (let i = 1; i <= totalPeriods && balance > 0; i++) {
      const interestPayment = balance * periodRate
      let principalPayment = payment - interestPayment

      if (principalPayment > balance) {
        principalPayment = balance
      }

      balance -= principalPayment
      totalInterest += interestPayment

      // Calculate payment date
      const paymentDate = new Date(start)
      if (paymentFrequency === "monthly") {
        paymentDate.setMonth(paymentDate.getMonth() + i)
      } else if (paymentFrequency === "biweekly") {
        paymentDate.setDate(paymentDate.getDate() + i * 14)
      } else {
        paymentDate.setDate(paymentDate.getDate() + i * 7)
      }

      schedule.push({
        paymentNumber: i,
        paymentDate: paymentDate.toLocaleDateString(),
        paymentAmount: Math.round((payment + (balance > 0 ? 0 : balance + payment)) * 100) / 100,
        principal: Math.round(principalPayment * 100) / 100,
        interest: Math.round(interestPayment * 100) / 100,
        balance: Math.max(0, Math.round(balance * 100) / 100),
      })

      // Calculate with extra payments
      if (balanceWithExtra > 0) {
        const extraInterest = balanceWithExtra * periodRate
        let extraPrincipal = payment - extraInterest + extra
        if (extraPrincipal > balanceWithExtra) {
          extraPrincipal = balanceWithExtra
        }
        balanceWithExtra -= extraPrincipal
        totalInterestWithExtra += extraInterest
        if (balanceWithExtra > 0) {
          periodsWithExtra = i
        }
      }
    }

    // If extra payments, count remaining periods
    if (extra > 0 && balanceWithExtra <= 0) {
      periodsWithExtra =
        schedule.findIndex((s) => {
          let bal = principal
          for (let j = 0; j <= schedule.indexOf(s); j++) {
            const int = bal * periodRate
            bal -= payment - int + extra
            if (bal <= 0) return true
          }
          return false
        }) + 1
    }

    setResult({
      schedule,
      monthlyPayment: Math.round(payment * 100) / 100,
      totalPayment: Math.round(payment * schedule.length * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
      totalInterestWithExtra: Math.round(totalInterestWithExtra * 100) / 100,
      monthsSaved: extra > 0 ? schedule.length - periodsWithExtra : 0,
    })
  }

  const handleReset = () => {
    setLoanAmount("")
    setInterestRate("")
    setLoanTerm("")
    setTermUnit("years")
    setPaymentFrequency("monthly")
    setExtraPayment("")
    setStartDate("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowFullSchedule(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Amortization Schedule: Monthly Payment: $${result.monthlyPayment.toLocaleString()}, Total Interest: $${result.totalInterest.toLocaleString()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Amortization Schedule",
          text: `Monthly Payment: $${result.monthlyPayment.toLocaleString()}, Total Interest: $${result.totalInterest.toLocaleString()}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Amortization Schedule</CardTitle>
                    <CardDescription>Generate detailed loan repayment schedule</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Loan Amount */}
                <div className="space-y-2">
                  <Label htmlFor="loanAmount">Loan Amount ($)</Label>
                  <Input
                    id="loanAmount"
                    type="number"
                    placeholder="Enter loan amount"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Enter interest rate"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Loan Term */}
                <div className="space-y-2">
                  <Label htmlFor="loanTerm">Loan Term</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      id="loanTerm"
                      type="number"
                      placeholder="Enter term"
                      value={loanTerm}
                      onChange={(e) => setLoanTerm(e.target.value)}
                      min="0"
                    />
                    <Select value={termUnit} onValueChange={(v) => setTermUnit(v as "years" | "months")}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="years">Years</SelectItem>
                        <SelectItem value="months">Months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Payment Frequency */}
                <div className="space-y-2">
                  <Label htmlFor="frequency">Payment Frequency</Label>
                  <Select
                    value={paymentFrequency}
                    onValueChange={(v) => setPaymentFrequency(v as "monthly" | "biweekly" | "weekly")}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="biweekly">Biweekly</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="extraPayment">Extra Payment per Period ($)</Label>
                      <Input
                        id="extraPayment"
                        type="number"
                        placeholder="Optional extra payment"
                        value={extraPayment}
                        onChange={(e) => setExtraPayment(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="startDate">Start Date</Label>
                      <Input
                        id="startDate"
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAmortization} className="w-full" size="lg">
                  Generate Schedule
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">
                        {paymentFrequency === "monthly"
                          ? "Monthly"
                          : paymentFrequency === "biweekly"
                            ? "Biweekly"
                            : "Weekly"}{" "}
                        Payment
                      </p>
                      <p className="text-4xl font-bold text-green-600">{formatCurrency(result.monthlyPayment)}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Total Payments</p>
                        <p className="font-semibold">{formatCurrency(result.totalPayment)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Total Interest</p>
                        <p className="font-semibold">{formatCurrency(result.totalInterest)}</p>
                      </div>
                    </div>

                    {Number.parseFloat(extraPayment) > 0 && (
                      <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm text-blue-700">
                          With ${extraPayment} extra payment, you save{" "}
                          <strong>{formatCurrency(result.totalInterest - result.totalInterestWithExtra)}</strong> in
                          interest
                        </p>
                      </div>
                    )}

                    {/* Schedule Table */}
                    <Collapsible open={showFullSchedule} onOpenChange={setShowFullSchedule} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" className="w-full bg-transparent">
                          {showFullSchedule ? "Hide" : "Show"} Full Schedule ({result.schedule.length} payments)
                          {showFullSchedule ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="max-h-64 overflow-y-auto rounded-lg border">
                          <table className="w-full text-xs">
                            <thead className="bg-muted sticky top-0">
                              <tr>
                                <th className="p-2 text-left">#</th>
                                <th className="p-2 text-left">Date</th>
                                <th className="p-2 text-right">Payment</th>
                                <th className="p-2 text-right">Principal</th>
                                <th className="p-2 text-right">Interest</th>
                                <th className="p-2 text-right">Balance</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.schedule.map((entry) => (
                                <tr key={entry.paymentNumber} className="border-t">
                                  <td className="p-2">{entry.paymentNumber}</td>
                                  <td className="p-2">{entry.paymentDate}</td>
                                  <td className="p-2 text-right">{formatCurrency(entry.paymentAmount)}</td>
                                  <td className="p-2 text-right">{formatCurrency(entry.principal)}</td>
                                  <td className="p-2 text-right">{formatCurrency(entry.interest)}</td>
                                  <td className="p-2 text-right">{formatCurrency(entry.balance)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How Amortization Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-600 text-white text-xs font-bold">
                        1
                      </div>
                      <div>
                        <p className="font-medium text-green-700">Early Payments</p>
                        <p className="text-sm text-green-600">Most of your payment goes to interest</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-bold">
                        2
                      </div>
                      <div>
                        <p className="font-medium text-blue-700">Middle Payments</p>
                        <p className="text-sm text-blue-600">Principal and interest become more balanced</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-purple-600 text-white text-xs font-bold">
                        3
                      </div>
                      <div>
                        <p className="font-medium text-purple-700">Later Payments</p>
                        <p className="text-sm text-purple-600">Most of your payment goes to principal</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Payment Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">M = P × [r(1+r)ⁿ] / [(1+r)ⁿ - 1]</p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>M</strong> = Monthly payment
                    </p>
                    <p>
                      <strong>P</strong> = Principal loan amount
                    </p>
                    <p>
                      <strong>r</strong> = Monthly interest rate
                    </p>
                    <p>
                      <strong>n</strong> = Total number of payments
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an Amortization Schedule?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An amortization schedule is a complete table of periodic loan payments showing the amount of principal
                  and interest that comprise each payment until the loan is paid off. Each periodic payment is the same
                  amount in total, but the breakdown between principal and interest changes over time. Early in the loan
                  term, a larger portion goes to interest, while later payments apply more to the principal balance.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>Benefits of Extra Payments</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Making extra payments toward your loan principal can significantly reduce the total interest paid and
                  shorten your loan term. Even small additional payments made consistently can save thousands of dollars
                  over the life of your loan. This calculator helps you visualize the impact of extra payments on your
                  amortization schedule.
                </p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Amortization schedules are estimates based on entered values and standard formulas. Actual loan terms
                  may include additional fees, variable rates, or different compounding methods. Consult a lender for
                  exact payment schedules and personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
