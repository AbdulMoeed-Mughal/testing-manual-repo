"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Circle, Info, ChevronDown } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type InputMode = "center-radius" | "general"
type Orientation = "horizontal" | "vertical"

interface EllipseResult {
  centerH: number
  centerK: number
  semiMajorA: number
  semiMinorB: number
  orientation: Orientation
  fociDistance: number
  focus1: { x: number; y: number }
  focus2: { x: number; y: number }
  eccentricity: number
  perimeter: number
  area: number
  standardForm: string
  generalForm: string
}

export function EllipseCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("center-radius")
  const [centerH, setCenterH] = useState("")
  const [centerK, setCenterK] = useState("")
  const [semiMajorA, setSemiMajorA] = useState("")
  const [semiMinorB, setSemiMinorB] = useState("")
  const [orientation, setOrientation] = useState<Orientation>("horizontal")

  // General form inputs: Ax² + Bxy + Cy² + Dx + Ey + F = 0
  const [coeffA, setCoeffA] = useState("")
  const [coeffC, setCoeffC] = useState("")
  const [coeffD, setCoeffD] = useState("")
  const [coeffE, setCoeffE] = useState("")
  const [coeffF, setCoeffF] = useState("")

  const [result, setResult] = useState<EllipseResult | null>(null)
  const [showSteps, setShowSteps] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatNumber = (num: number, decimals = 4): string => {
    if (Number.isInteger(num)) return num.toString()
    return num.toFixed(decimals).replace(/\.?0+$/, "")
  }

  const calculateEllipse = () => {
    setError("")
    setResult(null)

    let h: number, k: number, a: number, b: number, orient: Orientation

    if (inputMode === "center-radius") {
      h = Number.parseFloat(centerH) || 0
      k = Number.parseFloat(centerK) || 0
      a = Number.parseFloat(semiMajorA)
      b = Number.parseFloat(semiMinorB)
      orient = orientation

      if (isNaN(a) || a <= 0) {
        setError("Semi-major axis (a) must be a positive number")
        return
      }
      if (isNaN(b) || b <= 0) {
        setError("Semi-minor axis (b) must be a positive number")
        return
      }
      if (a < b) {
        setError("Semi-major axis (a) must be greater than or equal to semi-minor axis (b)")
        return
      }
    } else {
      // General form: Ax² + Cy² + Dx + Ey + F = 0 (B = 0 for axis-aligned ellipse)
      const A = Number.parseFloat(coeffA)
      const C = Number.parseFloat(coeffC)
      const D = Number.parseFloat(coeffD) || 0
      const E = Number.parseFloat(coeffE) || 0
      const F = Number.parseFloat(coeffF) || 0

      if (isNaN(A) || isNaN(C)) {
        setError("Coefficients A and C are required")
        return
      }
      if (A <= 0 || C <= 0) {
        setError("For an ellipse, both A and C must be positive")
        return
      }
      if (A === C) {
        setError("For an ellipse, A and C must be different (if equal, it's a circle)")
        return
      }

      // Convert to standard form by completing the square
      // Ax² + Dx + Cy² + Ey + F = 0
      // A(x² + (D/A)x) + C(y² + (E/C)y) + F = 0
      // A(x + D/(2A))² - D²/(4A) + C(y + E/(2C))² - E²/(4C) + F = 0

      h = -D / (2 * A)
      k = -E / (2 * C)

      const rightSide = (D * D) / (4 * A) + (E * E) / (4 * C) - F

      if (rightSide <= 0) {
        setError("Invalid ellipse parameters: the equation does not represent a real ellipse")
        return
      }

      // A(x-h)² + C(y-k)² = rightSide
      // (x-h)²/(rightSide/A) + (y-k)²/(rightSide/C) = 1

      const aSquared = rightSide / A
      const bSquared = rightSide / C

      if (aSquared > bSquared) {
        a = Math.sqrt(aSquared)
        b = Math.sqrt(bSquared)
        orient = "horizontal"
      } else {
        a = Math.sqrt(bSquared)
        b = Math.sqrt(aSquared)
        orient = "vertical"
      }
    }

    // Calculate foci distance: c = √(a² - b²)
    const c = Math.sqrt(a * a - b * b)

    // Calculate foci coordinates
    let focus1: { x: number; y: number }
    let focus2: { x: number; y: number }

    if (orient === "horizontal") {
      focus1 = { x: h - c, y: k }
      focus2 = { x: h + c, y: k }
    } else {
      focus1 = { x: h, y: k - c }
      focus2 = { x: h, y: k + c }
    }

    // Calculate eccentricity: e = c / a
    const eccentricity = c / a

    // Calculate area: π × a × b
    const area = Math.PI * a * b

    // Calculate perimeter using Ramanujan's approximation
    const h_param = ((a - b) * (a - b)) / ((a + b) * (a + b))
    const perimeter = Math.PI * (a + b) * (1 + (3 * h_param) / (10 + Math.sqrt(4 - 3 * h_param)))

    // Generate standard form equation
    let standardForm: string
    const hStr = h === 0 ? "x" : h > 0 ? `(x - ${formatNumber(h)})` : `(x + ${formatNumber(Math.abs(h))})`
    const kStr = k === 0 ? "y" : k > 0 ? `(y - ${formatNumber(k)})` : `(y + ${formatNumber(Math.abs(k))})`

    if (orient === "horizontal") {
      standardForm = `${hStr}²/${formatNumber(a * a)} + ${kStr}²/${formatNumber(b * b)} = 1`
    } else {
      standardForm = `${hStr}²/${formatNumber(b * b)} + ${kStr}²/${formatNumber(a * a)} = 1`
    }

    // Generate general form: Ax² + Cy² + Dx + Ey + F = 0
    const A_gen = orient === "horizontal" ? 1 / (a * a) : 1 / (b * b)
    const C_gen = orient === "horizontal" ? 1 / (b * b) : 1 / (a * a)
    const D_gen = -2 * h * A_gen
    const E_gen = -2 * k * C_gen
    const F_gen = h * h * A_gen + k * k * C_gen - 1

    // Normalize to make coefficients cleaner
    const scale = Math.min(A_gen, C_gen)
    const generalForm = `${formatNumber(A_gen / scale)}x² + ${formatNumber(C_gen / scale)}y² + ${formatNumber(D_gen / scale)}x + ${formatNumber(E_gen / scale)}y + ${formatNumber(F_gen / scale)} = 0`

    setResult({
      centerH: h,
      centerK: k,
      semiMajorA: a,
      semiMinorB: b,
      orientation: orient,
      fociDistance: c,
      focus1,
      focus2,
      eccentricity,
      perimeter,
      area,
      standardForm,
      generalForm,
    })
  }

  const handleReset = () => {
    setCenterH("")
    setCenterK("")
    setSemiMajorA("")
    setSemiMinorB("")
    setOrientation("horizontal")
    setCoeffA("")
    setCoeffC("")
    setCoeffD("")
    setCoeffE("")
    setCoeffF("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Ellipse Properties:
Standard Form: ${result.standardForm}
Center: (${formatNumber(result.centerH)}, ${formatNumber(result.centerK)})
Semi-major axis (a): ${formatNumber(result.semiMajorA)}
Semi-minor axis (b): ${formatNumber(result.semiMinorB)}
Orientation: ${result.orientation}
Foci: (${formatNumber(result.focus1.x)}, ${formatNumber(result.focus1.y)}) and (${formatNumber(result.focus2.x)}, ${formatNumber(result.focus2.y)})
Eccentricity: ${formatNumber(result.eccentricity)}
Area: ${formatNumber(result.area)}
Perimeter: ≈${formatNumber(result.perimeter)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Ellipse Calculation",
          text: `Ellipse: ${result.standardForm}\nCenter: (${formatNumber(result.centerH)}, ${formatNumber(result.centerK)})\nEccentricity: ${formatNumber(result.eccentricity)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleInputMode = () => {
    setInputMode((prev) => (prev === "center-radius" ? "general" : "center-radius"))
    handleReset()
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Circle className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Ellipse Calculator</CardTitle>
                    <CardDescription>Calculate ellipse equations and properties</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={toggleInputMode}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "general" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "center-radius" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Center & Axes
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "general" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      General Form
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {inputMode === "center-radius" ? (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="centerH">Center h</Label>
                        <Input
                          id="centerH"
                          type="number"
                          placeholder="0"
                          value={centerH}
                          onChange={(e) => setCenterH(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="centerK">Center k</Label>
                        <Input
                          id="centerK"
                          type="number"
                          placeholder="0"
                          value={centerK}
                          onChange={(e) => setCenterK(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="semiMajorA">Semi-major axis (a)</Label>
                        <Input
                          id="semiMajorA"
                          type="number"
                          placeholder="e.g., 5"
                          value={semiMajorA}
                          onChange={(e) => setSemiMajorA(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="semiMinorB">Semi-minor axis (b)</Label>
                        <Input
                          id="semiMinorB"
                          type="number"
                          placeholder="e.g., 3"
                          value={semiMinorB}
                          onChange={(e) => setSemiMinorB(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Orientation</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          type="button"
                          variant={orientation === "horizontal" ? "default" : "outline"}
                          onClick={() => setOrientation("horizontal")}
                          className="w-full"
                        >
                          Horizontal
                        </Button>
                        <Button
                          type="button"
                          variant={orientation === "vertical" ? "default" : "outline"}
                          onClick={() => setOrientation("vertical")}
                          className="w-full"
                        >
                          Vertical
                        </Button>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="text-sm text-muted-foreground">Enter coefficients for: Ax² + Cy² + Dx + Ey + F = 0</p>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="coeffA">A (x² coefficient)</Label>
                        <Input
                          id="coeffA"
                          type="number"
                          placeholder="e.g., 1"
                          value={coeffA}
                          onChange={(e) => setCoeffA(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="coeffC">C (y² coefficient)</Label>
                        <Input
                          id="coeffC"
                          type="number"
                          placeholder="e.g., 4"
                          value={coeffC}
                          onChange={(e) => setCoeffC(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="coeffD">D (x coefficient)</Label>
                        <Input
                          id="coeffD"
                          type="number"
                          placeholder="0"
                          value={coeffD}
                          onChange={(e) => setCoeffD(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="coeffE">E (y coefficient)</Label>
                        <Input
                          id="coeffE"
                          type="number"
                          placeholder="0"
                          value={coeffE}
                          onChange={(e) => setCoeffE(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="coeffF">F (constant)</Label>
                        <Input
                          id="coeffF"
                          type="number"
                          placeholder="e.g., -1"
                          value={coeffF}
                          onChange={(e) => setCoeffF(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                  </>
                )}

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="showSteps"
                    checked={showSteps}
                    onChange={(e) => setShowSteps(e.target.checked)}
                    className="rounded border-gray-300"
                  />
                  <Label htmlFor="showSteps" className="text-sm font-normal cursor-pointer">
                    Show step-by-step solution
                  </Label>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateEllipse} className="w-full" size="lg">
                  Calculate Ellipse
                </Button>

                {result && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Standard Form</p>
                        <p className="text-lg font-mono font-semibold text-blue-700 break-all">{result.standardForm}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Center</p>
                        <p className="font-semibold">
                          ({formatNumber(result.centerH)}, {formatNumber(result.centerK)})
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Orientation</p>
                        <p className="font-semibold capitalize">{result.orientation}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Semi-major (a)</p>
                        <p className="font-semibold">{formatNumber(result.semiMajorA)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Semi-minor (b)</p>
                        <p className="font-semibold">{formatNumber(result.semiMinorB)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Eccentricity</p>
                        <p className="font-semibold">{formatNumber(result.eccentricity)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Foci Distance (c)</p>
                        <p className="font-semibold">{formatNumber(result.fociDistance)}</p>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="text-xs text-muted-foreground mb-1">Foci Coordinates</p>
                      <p className="font-semibold text-sm">
                        F₁ = ({formatNumber(result.focus1.x)}, {formatNumber(result.focus1.y)})
                      </p>
                      <p className="font-semibold text-sm">
                        F₂ = ({formatNumber(result.focus2.x)}, {formatNumber(result.focus2.y)})
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                        <p className="text-xs text-green-600">Area</p>
                        <p className="font-semibold text-green-700">{formatNumber(result.area)} sq units</p>
                      </div>
                      <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                        <p className="text-xs text-purple-600">Perimeter (approx)</p>
                        <p className="font-semibold text-purple-700">≈{formatNumber(result.perimeter)} units</p>
                      </div>
                    </div>

                    {showSteps && (
                      <Collapsible defaultOpen>
                        <CollapsibleTrigger asChild>
                          <Button variant="outline" className="w-full justify-between bg-transparent">
                            Step-by-Step Solution
                            <ChevronDown className="h-4 w-4" />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-3 space-y-3">
                          <div className="p-3 rounded-lg bg-muted/50 text-sm space-y-2">
                            <p className="font-medium">1. Identify the parameters:</p>
                            <p className="ml-4">
                              Center (h, k) = ({formatNumber(result.centerH)}, {formatNumber(result.centerK)})
                            </p>
                            <p className="ml-4">Semi-major axis a = {formatNumber(result.semiMajorA)}</p>
                            <p className="ml-4">Semi-minor axis b = {formatNumber(result.semiMinorB)}</p>

                            <p className="font-medium mt-3">2. Calculate foci distance (c):</p>
                            <p className="ml-4 font-mono">
                              c = √(a² - b²) = √({formatNumber(result.semiMajorA)}² - {formatNumber(result.semiMinorB)}
                              ²)
                            </p>
                            <p className="ml-4 font-mono">
                              c = √({formatNumber(result.semiMajorA * result.semiMajorA)} -{" "}
                              {formatNumber(result.semiMinorB * result.semiMinorB)}) ={" "}
                              {formatNumber(result.fociDistance)}
                            </p>

                            <p className="font-medium mt-3">3. Calculate eccentricity (e):</p>
                            <p className="ml-4 font-mono">
                              e = c/a = {formatNumber(result.fociDistance)}/{formatNumber(result.semiMajorA)} ={" "}
                              {formatNumber(result.eccentricity)}
                            </p>

                            <p className="font-medium mt-3">4. Calculate area:</p>
                            <p className="ml-4 font-mono">
                              Area = π × a × b = π × {formatNumber(result.semiMajorA)} ×{" "}
                              {formatNumber(result.semiMinorB)} = {formatNumber(result.area)}
                            </p>

                            <p className="font-medium mt-3">5. Calculate perimeter (Ramanujan's approximation):</p>
                            <p className="ml-4 font-mono">P ≈ π(a+b)(1 + 3h/(10+√(4-3h)))</p>
                            <p className="ml-4 font-mono">where h = (a-b)²/(a+b)²</p>
                            <p className="ml-4 font-mono">P ≈ {formatNumber(result.perimeter)}</p>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Ellipse Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm font-medium mb-1">Standard Form (Horizontal)</p>
                    <p className="font-mono text-sm">(x-h)²/a² + (y-k)²/b² = 1</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm font-medium mb-1">Standard Form (Vertical)</p>
                    <p className="font-mono text-sm">(x-h)²/b² + (y-k)²/a² = 1</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm font-medium mb-1">Foci Distance</p>
                    <p className="font-mono text-sm">c = √(a² - b²)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-sm font-medium mb-1">Eccentricity</p>
                    <p className="font-mono text-sm">e = c/a (0 ≤ e {"<"} 1)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Properties</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>a</strong> = semi-major axis (longer)
                    </p>
                    <p>
                      <strong>b</strong> = semi-minor axis (shorter)
                    </p>
                    <p>
                      <strong>c</strong> = distance from center to focus
                    </p>
                    <p>
                      <strong>e</strong> = eccentricity (0 = circle, 1 = parabola)
                    </p>
                    <p>
                      <strong>Foci</strong> = two special points on major axis
                    </p>
                    <p>
                      <strong>Area</strong> = π × a × b
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700 text-sm">Unit Ellipse</p>
                      <p className="text-xs text-blue-600">a=2, b=1, center (0,0)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-700 text-sm">Planetary Orbit</p>
                      <p className="text-xs text-green-600">e ≈ 0.017 (Earth's orbit)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-700 text-sm">Near-Circle</p>
                      <p className="text-xs text-purple-600">e → 0 as a → b</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an Ellipse?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An ellipse is a closed curve that resembles a stretched or compressed circle. It is defined as the set
                  of all points in a plane where the sum of the distances from two fixed points (called foci) is
                  constant. This elegant definition leads to the familiar oval shape that appears throughout nature,
                  from planetary orbits to the cross-section of a cylinder cut at an angle.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The ellipse has two axes: the major axis (the longest diameter) and the minor axis (the shortest
                  diameter). The semi-major axis (a) and semi-minor axis (b) are half of these respective lengths. The
                  eccentricity (e) measures how "stretched" the ellipse is - a value of 0 gives a perfect circle, while
                  values approaching 1 create increasingly elongated ellipses.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Circle className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Ellipses</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ellipses have numerous applications in science and engineering. In astronomy, Kepler's first law
                  states that planets orbit the Sun in elliptical paths with the Sun at one focus. This discovery
                  revolutionized our understanding of celestial mechanics and laid the foundation for Newton's theory of
                  gravitation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In architecture and engineering, elliptical shapes are used in dome construction, bridge arches, and
                  optical systems. The reflective properties of ellipses are particularly useful - sound or light
                  emitted from one focus will reflect to the other focus, a principle used in whispering galleries and
                  medical lithotripsy machines that use shock waves to break up kidney stones.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-yellow-50 border-yellow-200">
              <CardHeader>
                <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Ellipse calculations follow standard mathematical formulas. Results depend on correct input values and
                  axis configuration. The perimeter calculation uses Ramanujan's approximation, which is highly accurate
                  but not exact. For critical applications, verify results with additional methods.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
