"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

interface IntegralResult {
  indefiniteIntegral: string
  definiteIntegralValue: number
  upperEvaluation: number
  lowerEvaluation: number
  steps: string[]
}

export function DefiniteIntegralCalculator() {
  const [functionInput, setFunctionInput] = useState("")
  const [variable, setVariable] = useState("x")
  const [lowerLimit, setLowerLimit] = useState("")
  const [upperLimit, setUpperLimit] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<IntegralResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [showStepsPanel, setShowStepsPanel] = useState(false)

  const parseFunction = (input: string): { coefficient: number; power: number }[] | null => {
    const terms: { coefficient: number; power: number }[] = []
    const cleanInput = input.replace(/\s+/g, "").replace(/-/g, "+-")
    const termStrings = cleanInput.split("+").filter((t) => t !== "")

    for (const termStr of termStrings) {
      let term = termStr

      // Handle constant
      if (!term.includes(variable)) {
        const coef = Number.parseFloat(term)
        if (isNaN(coef)) return null
        terms.push({ coefficient: coef, power: 0 })
        continue
      }

      // Handle x^n, ax^n, x, ax
      let coefficient = 1
      let power = 1

      if (term.startsWith("-")) {
        coefficient = -1
        term = term.substring(1)
      }

      if (term.includes("^")) {
        const parts = term.split("^")
        const base = parts[0]
        power = Number.parseFloat(parts[1])
        if (isNaN(power)) return null

        if (base === variable) {
          // x^n
        } else if (base.endsWith(variable)) {
          // ax^n
          const coefStr = base.replace(variable, "").replace("*", "")
          if (coefStr === "" || coefStr === "-") {
            coefficient *= coefStr === "-" ? -1 : 1
          } else {
            coefficient *= Number.parseFloat(coefStr)
            if (isNaN(coefficient)) return null
          }
        } else {
          return null
        }
      } else {
        // No power, so power is 1
        if (term === variable) {
          // x
        } else if (term.endsWith(variable)) {
          // ax
          const coefStr = term.replace(variable, "").replace("*", "")
          if (coefStr === "" || coefStr === "-") {
            coefficient *= coefStr === "-" ? -1 : 1
          } else {
            coefficient *= Number.parseFloat(coefStr)
            if (isNaN(coefficient)) return null
          }
        } else {
          return null
        }
      }

      terms.push({ coefficient, power })
    }

    return terms.length > 0 ? terms : null
  }

  const integrateTerm = (coef: number, power: number): { newCoef: number; newPower: number; isLog: boolean } => {
    if (power === -1) {
      return { newCoef: coef, newPower: 0, isLog: true }
    }
    const newPower = power + 1
    const newCoef = coef / newPower
    return { newCoef, newPower, isLog: false }
  }

  const formatCoefficient = (coef: number): string => {
    if (Number.isInteger(coef)) return coef.toString()
    // Try to express as fraction
    const tolerance = 1e-9
    for (let denom = 1; denom <= 100; denom++) {
      const numer = coef * denom
      if (Math.abs(numer - Math.round(numer)) < tolerance) {
        return `${Math.round(numer)}/${denom}`
      }
    }
    return coef.toFixed(6).replace(/\.?0+$/, "")
  }

  const formatTerm = (coef: number, power: number, isLog: boolean, varName: string): string => {
    if (isLog) {
      const coefStr = coef === 1 ? "" : coef === -1 ? "-" : formatCoefficient(coef)
      return `${coefStr}ln|${varName}|`
    }
    if (power === 0) {
      return formatCoefficient(coef)
    }
    const coefStr = coef === 1 ? "" : coef === -1 ? "-" : formatCoefficient(coef)
    if (power === 1) {
      return `${coefStr}${varName}`
    }
    return `${coefStr}${varName}^${power}`
  }

  const evaluateTerm = (coef: number, power: number, isLog: boolean, value: number): number => {
    if (isLog) {
      return coef * Math.log(Math.abs(value))
    }
    return coef * Math.pow(value, power)
  }

  const calculateIntegral = () => {
    setError("")
    setResult(null)

    if (!functionInput.trim()) {
      setError("Please enter a function to integrate")
      return
    }

    const lower = Number.parseFloat(lowerLimit)
    const upper = Number.parseFloat(upperLimit)

    if (isNaN(lower) || isNaN(upper)) {
      setError("Please enter valid numeric limits")
      return
    }

    if (lower > upper) {
      setError("Lower limit must be less than or equal to upper limit")
      return
    }

    const terms = parseFunction(functionInput)
    if (!terms) {
      setError("Invalid function format. Use polynomial form like: 3x^2 + 2x - 5")
      return
    }

    // Check for division by zero in logarithmic case
    for (const term of terms) {
      if (term.power === -1 && (lower <= 0 || upper <= 0)) {
        setError("For 1/x terms, limits must be positive (logarithm is undefined for non-positive values)")
        return
      }
    }

    const steps: string[] = []
    const integratedTerms: { newCoef: number; newPower: number; isLog: boolean }[] = []

    steps.push(`Step 1: Identify the function to integrate`)
    steps.push(`f(${variable}) = ${functionInput}`)
    steps.push(``)
    steps.push(`Step 2: Apply the power rule to each term`)
    steps.push(`For ∫${variable}^n d${variable} = ${variable}^(n+1)/(n+1) + C`)
    steps.push(``)

    let stepNum = 3
    for (let i = 0; i < terms.length; i++) {
      const { coefficient, power } = terms[i]
      const integrated = integrateTerm(coefficient, power)
      integratedTerms.push(integrated)

      const originalTerm =
        power === 0
          ? formatCoefficient(coefficient)
          : `${coefficient === 1 ? "" : coefficient === -1 ? "-" : formatCoefficient(coefficient)}${variable}${power !== 1 ? `^${power}` : ""}`

      if (integrated.isLog) {
        steps.push(`∫${originalTerm} d${variable} = ${formatCoefficient(coefficient)}·ln|${variable}|`)
      } else {
        steps.push(
          `∫${originalTerm} d${variable} = ${formatTerm(integrated.newCoef, integrated.newPower, false, variable)}`,
        )
      }
    }

    // Build indefinite integral string
    const indefiniteTerms = integratedTerms.map((t, i) => {
      const sign = i > 0 && t.newCoef >= 0 ? " + " : i > 0 ? " " : ""
      return sign + formatTerm(t.newCoef, t.newPower, t.isLog, variable)
    })
    const indefiniteIntegral = indefiniteTerms.join("") + " + C"

    steps.push(``)
    steps.push(`Step ${stepNum}: Write the indefinite integral`)
    steps.push(`F(${variable}) = ${indefiniteIntegral.replace(" + C", "")}`)
    stepNum++

    // Evaluate at limits
    let upperEvaluation = 0
    let lowerEvaluation = 0

    for (const term of integratedTerms) {
      upperEvaluation += evaluateTerm(term.newCoef, term.newPower, term.isLog, upper)
      lowerEvaluation += evaluateTerm(term.newCoef, term.newPower, term.isLog, lower)
    }

    steps.push(``)
    steps.push(`Step ${stepNum}: Evaluate at the upper limit (${variable} = ${upper})`)
    steps.push(`F(${upper}) = ${upperEvaluation.toFixed(6).replace(/\.?0+$/, "")}`)
    stepNum++

    steps.push(``)
    steps.push(`Step ${stepNum}: Evaluate at the lower limit (${variable} = ${lower})`)
    steps.push(`F(${lower}) = ${lowerEvaluation.toFixed(6).replace(/\.?0+$/, "")}`)
    stepNum++

    const definiteIntegralValue = upperEvaluation - lowerEvaluation

    steps.push(``)
    steps.push(`Step ${stepNum}: Calculate the definite integral`)
    steps.push(`∫[${lower} to ${upper}] f(${variable}) d${variable} = F(${upper}) - F(${lower})`)
    steps.push(
      `= ${upperEvaluation.toFixed(6).replace(/\.?0+$/, "")} - ${lowerEvaluation.toFixed(6).replace(/\.?0+$/, "")}`,
    )
    steps.push(`= ${definiteIntegralValue.toFixed(6).replace(/\.?0+$/, "")}`)

    setResult({
      indefiniteIntegral,
      definiteIntegralValue,
      upperEvaluation,
      lowerEvaluation,
      steps,
    })
  }

  const handleReset = () => {
    setFunctionInput("")
    setLowerLimit("")
    setUpperLimit("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
    setShowStepsPanel(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `∫[${lowerLimit} to ${upperLimit}] ${functionInput} d${variable} = ${result.definiteIntegralValue.toFixed(6).replace(/\.?0+$/, "")}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      const latex = `\\int_{${lowerLimit}}^{${upperLimit}} ${functionInput.replace(/\^/g, "^{")} \\, d${variable} = ${result.definiteIntegralValue.toFixed(6).replace(/\.?0+$/, "")}`
      await navigator.clipboard.writeText(latex)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Definite Integral Result",
          text: `∫[${lowerLimit} to ${upperLimit}] ${functionInput} d${variable} = ${result.definiteIntegralValue.toFixed(6).replace(/\.?0+$/, "")}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Definite Integral Calculator</CardTitle>
                    <CardDescription>Calculate definite integrals with step-by-step solutions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Function Input */}
                <div className="space-y-2">
                  <Label htmlFor="function">Function f({variable})</Label>
                  <Input
                    id="function"
                    type="text"
                    placeholder="e.g., 3x^2 + 2x - 5"
                    value={functionInput}
                    onChange={(e) => setFunctionInput(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Use polynomial format: 3x^2 + 2x - 5, x^3 - 1, etc.</p>
                </div>

                {/* Variable Selection */}
                <div className="space-y-2">
                  <Label htmlFor="variable">Variable of Integration</Label>
                  <Select value={variable} onValueChange={setVariable}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select variable" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="x">x</SelectItem>
                      <SelectItem value="y">y</SelectItem>
                      <SelectItem value="t">t</SelectItem>
                      <SelectItem value="z">z</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Limits */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="lower">Lower Limit (a)</Label>
                    <Input
                      id="lower"
                      type="number"
                      placeholder="e.g., 0"
                      value={lowerLimit}
                      onChange={(e) => setLowerLimit(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="upper">Upper Limit (b)</Label>
                    <Input
                      id="upper"
                      type="number"
                      placeholder="e.g., 2"
                      value={upperLimit}
                      onChange={(e) => setUpperLimit(e.target.value)}
                    />
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <Label htmlFor="show-steps" className="cursor-pointer">
                    Show step-by-step solution
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateIntegral} className="w-full" size="lg">
                  Calculate Integral
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    {/* Main Result */}
                    <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Definite Integral</p>
                        <div className="text-lg font-mono mb-2">
                          ∫<sub>{lowerLimit}</sub>
                          <sup>{upperLimit}</sup> {functionInput} d{variable}
                        </div>
                        <p className="text-4xl font-bold text-blue-600 mb-2">
                          {result.definiteIntegralValue.toFixed(6).replace(/\.?0+$/, "")}
                        </p>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4 flex-wrap">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                          {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copiedLatex ? "Copied" : "LaTeX"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>

                    {/* Indefinite Integral */}
                    <div className="p-4 rounded-lg bg-muted/50 border">
                      <p className="text-sm font-medium mb-2">Indefinite Integral (Antiderivative)</p>
                      <p className="font-mono text-center">
                        F({variable}) = {result.indefiniteIntegral}
                      </p>
                    </div>

                    {/* Evaluation at Limits */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                        <p className="text-xs text-green-600 mb-1">F({upperLimit})</p>
                        <p className="font-mono font-semibold text-green-700">
                          {result.upperEvaluation.toFixed(6).replace(/\.?0+$/, "")}
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                        <p className="text-xs text-orange-600 mb-1">F({lowerLimit})</p>
                        <p className="font-mono font-semibold text-orange-700">
                          {result.lowerEvaluation.toFixed(6).replace(/\.?0+$/, "")}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="border rounded-lg overflow-hidden">
                        <button
                          onClick={() => setShowStepsPanel(!showStepsPanel)}
                          className="w-full flex items-center justify-between p-3 bg-muted/50 hover:bg-muted/70 transition-colors"
                        >
                          <span className="font-medium">Step-by-Step Solution</span>
                          {showStepsPanel ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>
                        {showStepsPanel && (
                          <div className="p-4 space-y-1 bg-background">
                            {result.steps.map((step, index) => (
                              <p
                                key={index}
                                className={`font-mono text-sm ${step === "" ? "h-2" : ""} ${step.startsWith("Step") ? "font-semibold text-primary mt-3" : "text-muted-foreground"}`}
                              >
                                {step}
                              </p>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Definite Integral Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">
                      ∫<sub>a</sub>
                      <sup>b</sup> f(x) dx = F(b) − F(a)
                    </p>
                  </div>
                  <div className="mt-4 text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>F(x)</strong> = Antiderivative of f(x)
                    </p>
                    <p>
                      <strong>a</strong> = Lower limit of integration
                    </p>
                    <p>
                      <strong>b</strong> = Upper limit of integration
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Power Rule for Integration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <span className="font-mono text-blue-700">∫x^n dx</span>
                    <span className="text-sm text-blue-600">x^(n+1)/(n+1) + C</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                    <span className="font-mono text-green-700">∫k dx</span>
                    <span className="text-sm text-green-600">kx + C</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <span className="font-mono text-purple-700">∫x^(-1) dx</span>
                    <span className="text-sm text-purple-600">ln|x| + C</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-muted/50 border">
                    <p className="font-mono text-sm">
                      ∫<sub>0</sub>
                      <sup>1</sup> x^2 dx = 1/3
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50 border">
                    <p className="font-mono text-sm">
                      ∫<sub>0</sub>
                      <sup>2</sup> (3x^2 + 2x) dx = 12
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50 border">
                    <p className="font-mono text-sm">
                      ∫<sub>1</sub>
                      <sup>4</sup> x dx = 7.5
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Definite Integral?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A definite integral is a fundamental concept in calculus that represents the signed area between a
                  function and the x-axis over a specific interval [a, b]. Unlike indefinite integrals, which give a
                  family of functions, definite integrals produce a single numerical value. This value can represent
                  physical quantities like area, volume, displacement, work, or accumulated quantities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The definite integral is evaluated using the Fundamental Theorem of Calculus, which connects
                  differentiation and integration. It states that if F(x) is an antiderivative of f(x), then the
                  definite integral from a to b equals F(b) − F(a). This powerful theorem allows us to compute areas and
                  accumulated quantities efficiently.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Definite Integrals</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate a definite integral, follow these steps: First, find the indefinite integral
                  (antiderivative) of the function using integration rules like the power rule, sum rule, and constant
                  multiple rule. Second, evaluate the antiderivative at the upper limit (b) and lower limit (a).
                  Finally, subtract the lower evaluation from the upper evaluation to get the definite integral value.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Step 1: Find the Antiderivative</h4>
                    <p className="text-blue-700 text-sm">
                      Apply integration rules to find F(x), the antiderivative of f(x). For polynomials, use the power
                      rule: increase the exponent by 1 and divide by the new exponent.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Step 2: Evaluate at Limits</h4>
                    <p className="text-green-700 text-sm">
                      Substitute the upper limit (b) into F(x) to get F(b), and the lower limit (a) to get F(a).
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Step 3: Subtract</h4>
                    <p className="text-purple-700 text-sm">
                      Calculate the final answer by computing F(b) − F(a). This gives the definite integral value.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Definite integral calculations follow standard calculus rules. Results depend on correct function
                  input, variable selection, and limit values. This calculator supports polynomial functions. For more
                  complex functions involving trigonometric, exponential, or logarithmic terms, results may require
                  verification using specialized mathematical software.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
