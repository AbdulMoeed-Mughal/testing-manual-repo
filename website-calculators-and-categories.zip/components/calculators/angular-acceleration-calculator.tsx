"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Gauge, Info, AlertTriangle, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type AngleUnit = "rad" | "deg"

interface AccelerationResult {
  alphaRadS2: number
  alphaDegS2: number
  deltaOmega: number
  category: string
  color: string
  bgColor: string
}

export function AngularAccelerationCalculator() {
  const [angleUnit, setAngleUnit] = useState<AngleUnit>("rad")
  const [omega0, setOmega0] = useState("")
  const [omega, setOmega] = useState("")
  const [time, setTime] = useState("")
  const [result, setResult] = useState<AccelerationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateAcceleration = () => {
    setError("")
    setResult(null)

    const omega0Num = Number.parseFloat(omega0)
    const omegaNum = Number.parseFloat(omega)
    const timeNum = Number.parseFloat(time)

    if (isNaN(omega0Num)) {
      setError("Please enter a valid initial angular velocity")
      return
    }

    if (isNaN(omegaNum)) {
      setError("Please enter a valid final angular velocity")
      return
    }

    if (isNaN(timeNum) || timeNum <= 0) {
      setError("Please enter a valid time greater than 0")
      return
    }

    // Convert to rad/s if needed
    let omega0RadS = omega0Num
    let omegaRadS = omegaNum

    if (angleUnit === "deg") {
      omega0RadS = omega0Num * (Math.PI / 180)
      omegaRadS = omegaNum * (Math.PI / 180)
    }

    // Calculate angular acceleration: α = (ω − ω₀) / t
    const alphaRadS2 = (omegaRadS - omega0RadS) / timeNum
    const alphaDegS2 = alphaRadS2 * (180 / Math.PI)
    const deltaOmega = omegaRadS - omega0RadS

    // Categorize the acceleration
    const absAlpha = Math.abs(alphaRadS2)
    let category: string
    let color: string
    let bgColor: string

    if (absAlpha === 0) {
      category = "No Acceleration"
      color = "text-gray-600"
      bgColor = "bg-gray-50 border-gray-200"
    } else if (absAlpha < 1) {
      category = "Low Acceleration"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (absAlpha < 10) {
      category = "Moderate Acceleration"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (absAlpha < 50) {
      category = "High Acceleration"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Acceleration"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    if (alphaRadS2 < 0) {
      category += " (Deceleration)"
    }

    setResult({
      alphaRadS2,
      alphaDegS2,
      deltaOmega,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setOmega0("")
    setOmega("")
    setTime("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Angular Acceleration: ${result.alphaRadS2.toFixed(4)} rad/s² (${result.alphaDegS2.toFixed(4)} °/s²)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Angular Acceleration Result",
          text: `I calculated angular acceleration using CalcHub! α = ${result.alphaRadS2.toFixed(4)} rad/s²`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleAngleUnit = () => {
    setAngleUnit((prev) => (prev === "rad" ? "deg" : "rad"))
    setOmega0("")
    setOmega("")
    setResult(null)
    setError("")
  }

  const formatNumber = (num: number, decimals = 4) => {
    if (Math.abs(num) < 0.0001 && num !== 0) {
      return num.toExponential(decimals)
    }
    return num.toFixed(decimals)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Angular Acceleration Calculator</CardTitle>
                    <CardDescription>Calculate rotational acceleration (α)</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Angular Velocity Unit</span>
                  <button
                    onClick={toggleAngleUnit}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        angleUnit === "deg" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        angleUnit === "rad" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      rad/s
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        angleUnit === "deg" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      °/s
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Angular Velocity Input */}
                <div className="space-y-2">
                  <Label htmlFor="omega0">Initial Angular Velocity ω₀ ({angleUnit === "rad" ? "rad/s" : "°/s"})</Label>
                  <Input
                    id="omega0"
                    type="number"
                    placeholder={`Enter initial velocity in ${angleUnit === "rad" ? "rad/s" : "°/s"}`}
                    value={omega0}
                    onChange={(e) => setOmega0(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Final Angular Velocity Input */}
                <div className="space-y-2">
                  <Label htmlFor="omega">Final Angular Velocity ω ({angleUnit === "rad" ? "rad/s" : "°/s"})</Label>
                  <Input
                    id="omega"
                    type="number"
                    placeholder={`Enter final velocity in ${angleUnit === "rad" ? "rad/s" : "°/s"}`}
                    value={omega}
                    onChange={(e) => setOmega(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Time Input */}
                <div className="space-y-2">
                  <Label htmlFor="time">Time Interval (seconds)</Label>
                  <Input
                    id="time"
                    type="number"
                    placeholder="Enter time in seconds"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAcceleration} className="w-full" size="lg">
                  Calculate Angular Acceleration
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Angular Acceleration (α)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {formatNumber(result.alphaRadS2)} rad/s²
                      </p>
                      <p className="text-lg text-muted-foreground mb-2">{formatNumber(result.alphaDegS2)} °/s²</p>
                      <p className={`text-base font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Additional Info */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg">
                      <p className="text-sm text-muted-foreground">
                        <span className="font-medium">Change in Angular Velocity:</span>{" "}
                        {formatNumber(result.deltaOmega)} rad/s
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Angular Acceleration Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">α = (ω − ω₀) / t</p>
                  </div>
                  <p>Where:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>
                      <strong>α</strong> = Angular acceleration (rad/s² or °/s²)
                    </li>
                    <li>
                      <strong>ω</strong> = Final angular velocity
                    </li>
                    <li>
                      <strong>ω₀</strong> = Initial angular velocity
                    </li>
                    <li>
                      <strong>t</strong> = Time interval (seconds)
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">1 rad/s²</span>
                      <span className="text-sm text-blue-600">= 57.2958 °/s²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">1 °/s²</span>
                      <span className="text-sm text-green-600">= 0.01745 rad/s²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">1 rev/s²</span>
                      <span className="text-sm text-purple-600">= 2π rad/s²</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Angular Acceleration?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Angular acceleration is the rate of change of angular velocity over time. It measures how quickly a
                  rotating object speeds up or slows down its rotation. Just as linear acceleration describes changes in
                  linear velocity, angular acceleration describes changes in rotational motion. It is a fundamental
                  concept in rotational dynamics and is essential for understanding the behavior of rotating machinery,
                  wheels, gears, and celestial bodies.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Angular acceleration is denoted by the Greek letter alpha (α) and is measured in radians per second
                  squared (rad/s²) in the SI system. A positive angular acceleration indicates that the object is
                  speeding up its rotation, while a negative value (sometimes called angular deceleration) indicates
                  that it is slowing down. Understanding angular acceleration is crucial in engineering applications
                  such as motor control, robotics, and vehicle dynamics.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Rotational Kinematics Equations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Angular acceleration is part of a set of rotational kinematics equations that are analogous to linear
                  kinematics. These equations relate angular displacement (θ), angular velocity (ω), angular
                  acceleration (α), and time (t) for objects undergoing constant angular acceleration.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p>
                      <strong>ω = ω₀ + αt</strong> (Final angular velocity)
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p>
                      <strong>θ = ω₀t + ½αt²</strong> (Angular displacement)
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p>
                      <strong>ω² = ω₀² + 2αθ</strong> (Velocity-displacement relation)
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Common Examples</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Electric Motors</h4>
                    <p className="text-orange-700 text-sm">
                      Industrial motors typically have angular accelerations of 10-100 rad/s² during startup, depending
                      on load and motor specifications.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Car Wheels</h4>
                    <p className="text-blue-700 text-sm">
                      During hard braking, car wheels can experience angular decelerations of 20-50 rad/s², depending on
                      vehicle speed and brake force.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">CD/DVD Drives</h4>
                    <p className="text-green-700 text-sm">
                      Optical disc drives can achieve angular accelerations up to 1000 rad/s² when seeking different
                      tracks on the disc.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Figure Skating</h4>
                    <p className="text-purple-700 text-sm">
                      When a figure skater pulls their arms in during a spin, they can achieve angular accelerations of
                      5-15 rad/s² due to conservation of angular momentum.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-yellow-800 mb-1">Disclaimer</h4>
                    <p className="text-sm text-yellow-700">
                      Angular acceleration calculations are estimates based on ideal motion. Actual acceleration may
                      vary due to friction, external forces, or system constraints. This calculator assumes constant
                      angular acceleration over the time interval.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
