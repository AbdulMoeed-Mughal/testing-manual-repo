"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Heart, Info, AlertTriangle, Activity } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

interface BPResult {
  systolic: number
  diastolic: number
  category: string
  color: string
  bgColor: string
  description: string
  recommendation: string
  severity: number
}

export function BloodPressureCategoryCalculator() {
  const [systolic, setSystolic] = useState("")
  const [diastolic, setDiastolic] = useState("")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [result, setResult] = useState<BPResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateCategory = () => {
    setError("")
    setResult(null)

    const sys = Number.parseFloat(systolic)
    const dia = Number.parseFloat(diastolic)

    if (isNaN(sys) || sys <= 0) {
      setError("Please enter a valid systolic pressure greater than 0")
      return
    }

    if (isNaN(dia) || dia <= 0) {
      setError("Please enter a valid diastolic pressure greater than 0")
      return
    }

    if (sys < dia) {
      setError("Systolic pressure should be greater than or equal to diastolic pressure")
      return
    }

    if (sys < 60 || sys > 250) {
      setError("Please enter a realistic systolic pressure (60-250 mmHg)")
      return
    }

    if (dia < 40 || dia > 150) {
      setError("Please enter a realistic diastolic pressure (40-150 mmHg)")
      return
    }

    let category: string
    let color: string
    let bgColor: string
    let description: string
    let recommendation: string
    let severity: number

    // ACC/AHA Guidelines Classification
    if (sys > 180 || dia > 120) {
      category = "Hypertensive Crisis"
      color = "text-purple-600"
      bgColor = "bg-purple-50 border-purple-200"
      description = "Dangerously high blood pressure requiring immediate medical attention"
      recommendation =
        "Seek emergency medical care immediately. Do not wait to see if your pressure comes down on its own."
      severity = 5
    } else if (sys >= 140 || dia >= 90) {
      category = "Hypertension Stage 2"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
      description = "High blood pressure that typically requires medication and lifestyle changes"
      recommendation = "Consult your doctor promptly. Medication is likely needed along with lifestyle modifications."
      severity = 4
    } else if ((sys >= 130 && sys <= 139) || (dia >= 80 && dia <= 89)) {
      category = "Hypertension Stage 1"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
      description = "Moderately elevated blood pressure that may require lifestyle changes or medication"
      recommendation =
        "Lifestyle changes are recommended. Your doctor may consider medication based on cardiovascular risk."
      severity = 3
    } else if (sys >= 120 && sys <= 129 && dia < 80) {
      category = "Elevated"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
      description = "Blood pressure higher than normal but not yet hypertension"
      recommendation = "Adopt healthy lifestyle changes to prevent progression to hypertension."
      severity = 2
    } else if (sys < 120 && dia < 80) {
      category = "Normal"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      description = "Healthy blood pressure levels"
      recommendation = "Maintain a healthy lifestyle to keep your blood pressure in the normal range."
      severity = 1
    } else {
      category = "Check Values"
      color = "text-gray-600"
      bgColor = "bg-gray-50 border-gray-200"
      description = "Unable to categorize with provided values"
      recommendation = "Please verify your readings and try again."
      severity = 0
    }

    setResult({
      systolic: sys,
      diastolic: dia,
      category,
      color,
      bgColor,
      description,
      recommendation,
      severity,
    })
  }

  const handleReset = () => {
    setSystolic("")
    setDiastolic("")
    setAge("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My Blood Pressure: ${result.systolic}/${result.diastolic} mmHg (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Blood Pressure Result",
          text: `I checked my blood pressure using CalcHub! My reading is ${result.systolic}/${result.diastolic} mmHg (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Heart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Blood Pressure Category</CardTitle>
                    <CardDescription>Check your blood pressure category</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Systolic Input */}
                <div className="space-y-2">
                  <Label htmlFor="systolic">Systolic Pressure (mmHg)</Label>
                  <Input
                    id="systolic"
                    type="number"
                    placeholder="e.g., 120"
                    value={systolic}
                    onChange={(e) => setSystolic(e.target.value)}
                    min="60"
                    max="250"
                  />
                  <p className="text-xs text-muted-foreground">Top number - pressure when heart beats</p>
                </div>

                {/* Diastolic Input */}
                <div className="space-y-2">
                  <Label htmlFor="diastolic">Diastolic Pressure (mmHg)</Label>
                  <Input
                    id="diastolic"
                    type="number"
                    placeholder="e.g., 80"
                    value={diastolic}
                    onChange={(e) => setDiastolic(e.target.value)}
                    min="40"
                    max="150"
                  />
                  <p className="text-xs text-muted-foreground">Bottom number - pressure between beats</p>
                </div>

                {/* Optional: Age */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (optional)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="e.g., 35"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Optional: Gender */}
                <div className="space-y-2">
                  <Label>Gender (optional)</Label>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      className="flex-1"
                      onClick={() => setGender("male")}
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      className="flex-1"
                      onClick={() => setGender("female")}
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCategory} className="w-full" size="lg">
                  Check Blood Pressure Category
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Blood Pressure</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.systolic}/{result.diastolic}
                      </p>
                      <p className="text-sm text-muted-foreground mb-2">mmHg</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-sm text-muted-foreground mt-2">{result.description}</p>
                    </div>

                    {/* Severity Indicator */}
                    <div className="mt-4">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Normal</span>
                        <span>Crisis</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            result.severity === 1
                              ? "bg-green-500 w-[20%]"
                              : result.severity === 2
                                ? "bg-yellow-500 w-[40%]"
                                : result.severity === 3
                                  ? "bg-orange-500 w-[60%]"
                                  : result.severity === 4
                                    ? "bg-red-500 w-[80%]"
                                    : result.severity === 5
                                      ? "bg-purple-500 w-full"
                                      : "bg-gray-400 w-0"
                          }`}
                        />
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-between">
                          <span>Recommendation</span>
                          <ChevronDown className={`h-4 w-4 transition-transform ${showDetails ? "rotate-180" : ""}`} />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2 space-y-2 text-sm">
                        <div className="p-3 bg-background rounded-lg">
                          <p className="font-medium mb-1">What You Should Do:</p>
                          <p className="text-muted-foreground">{result.recommendation}</p>
                        </div>
                        {age && Number(age) > 0 && (
                          <div className="p-3 bg-background rounded-lg">
                            <p className="font-medium mb-1">Age Consideration:</p>
                            <p className="text-muted-foreground">
                              {Number(age) >= 65
                                ? "For adults 65 and older, blood pressure targets may be adjusted. Discuss with your healthcare provider."
                                : Number(age) < 18
                                  ? "Blood pressure standards for children and adolescents differ from adults. Consult a pediatrician."
                                  : "Standard adult blood pressure guidelines apply to your age group."}
                            </p>
                          </div>
                        )}
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Blood Pressure Categories (ACC/AHA)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Normal</span>
                      <span className="text-sm text-green-600">{"<120 / <80"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Elevated</span>
                      <span className="text-sm text-yellow-600">120-129 / {"<80"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Hypertension Stage 1</span>
                      <span className="text-sm text-orange-600">130-139 / 80-89</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Hypertension Stage 2</span>
                      <span className="text-sm text-red-600">{"≥140 / ≥90"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Hypertensive Crisis</span>
                      <span className="text-sm text-purple-600">{">180 / >120"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How to Measure</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <ul className="list-disc list-inside space-y-1">
                    <li>Rest for 5 minutes before measuring</li>
                    <li>Sit with back supported, feet flat on floor</li>
                    <li>Place arm at heart level</li>
                    <li>Avoid caffeine, exercise, and smoking 30 min prior</li>
                    <li>Take 2-3 readings, 1 minute apart</li>
                    <li>Record the average of your readings</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Blood Pressure</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Blood pressure is the force of blood pushing against the walls of your arteries as your heart pumps
                  blood throughout your body. It is measured in millimeters of mercury (mmHg) and recorded as two
                  numbers: systolic pressure (the top number) represents the pressure when your heart beats, while
                  diastolic pressure (the bottom number) represents the pressure when your heart rests between beats.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  High blood pressure, or hypertension, is often called the "silent killer" because it typically has no
                  symptoms but can lead to serious health problems including heart disease, stroke, kidney disease, and
                  vision loss. Regular monitoring is essential for early detection and management.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Managing Your Blood Pressure</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Lifestyle modifications can significantly impact blood pressure levels. Key strategies include
                  maintaining a healthy weight, following the DASH diet (rich in fruits, vegetables, whole grains, and
                  low-fat dairy), reducing sodium intake to less than 2,300 mg per day, engaging in regular physical
                  activity (at least 150 minutes of moderate exercise weekly), limiting alcohol consumption, managing
                  stress, and quitting smoking.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For those with hypertension, medication may be necessary in addition to lifestyle changes. Common
                  classes of blood pressure medications include diuretics, ACE inhibitors, ARBs, calcium channel
                  blockers, and beta-blockers. Your healthcare provider will determine the best treatment plan based on
                  your individual health profile.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Medical Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-800 text-sm">
                  Blood pressure categories are based on standard ACC/AHA guidelines and are for informational purposes
                  only. This calculator is not a substitute for professional medical advice, diagnosis, or treatment.
                  Always consult a qualified healthcare provider for proper evaluation and management of your blood
                  pressure. If you experience symptoms of hypertensive crisis (severe headache, chest pain, difficulty
                  breathing, vision changes), seek emergency medical care immediately.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
