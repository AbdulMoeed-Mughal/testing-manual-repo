"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Scale,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, formatCurrency, currencySymbols } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

type LotType = "standard" | "mini" | "micro" | "nano"

interface ForexPair {
  pair: string
  name: string
  contractSize: number
  pipValue: number
}

const forexPairs: ForexPair[] = [
  { pair: "EUR/USD", name: "Euro / US Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "GBP/USD", name: "British Pound / US Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "USD/JPY", name: "US Dollar / Japanese Yen", contractSize: 100000, pipValue: 0.01 },
  { pair: "USD/CHF", name: "US Dollar / Swiss Franc", contractSize: 100000, pipValue: 0.0001 },
  { pair: "AUD/USD", name: "Australian Dollar / US Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "USD/CAD", name: "US Dollar / Canadian Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "NZD/USD", name: "New Zealand Dollar / US Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "EUR/GBP", name: "Euro / British Pound", contractSize: 100000, pipValue: 0.0001 },
  { pair: "EUR/JPY", name: "Euro / Japanese Yen", contractSize: 100000, pipValue: 0.01 },
  { pair: "GBP/JPY", name: "British Pound / Japanese Yen", contractSize: 100000, pipValue: 0.01 },
  { pair: "EUR/AUD", name: "Euro / Australian Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "EUR/CAD", name: "Euro / Canadian Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "AUD/JPY", name: "Australian Dollar / Japanese Yen", contractSize: 100000, pipValue: 0.01 },
  { pair: "CHF/JPY", name: "Swiss Franc / Japanese Yen", contractSize: 100000, pipValue: 0.01 },
  { pair: "AUD/CAD", name: "Australian Dollar / Canadian Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "AUD/NZD", name: "Australian Dollar / New Zealand Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "EUR/NZD", name: "Euro / New Zealand Dollar", contractSize: 100000, pipValue: 0.0001 },
  { pair: "GBP/AUD", name: "British Pound / Australian Dollar", contractSize: 100000, pipValue: 0.0001 },
]

const lotSizes: Record<LotType, number> = {
  standard: 1,
  mini: 0.1,
  micro: 0.01,
  nano: 0.001,
}

const leverageOptions = [
  { value: "10", label: "1:10" },
  { value: "20", label: "1:20" },
  { value: "30", label: "1:30" },
  { value: "50", label: "1:50" },
  { value: "100", label: "1:100" },
  { value: "200", label: "1:200" },
  { value: "300", label: "1:300" },
  { value: "400", label: "1:400" },
  { value: "500", label: "1:500" },
]

interface LeverageResult {
  leverageUsed: number
  leverageRatio: string
  positionValue: number
  requiredMargin: number
  marginUtilization: number
  maxPositionValue: number
  maxLots: number
  riskCategory: string
  riskColor: string
  riskBgColor: string
}

export function ForexLeverageCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [accountBalance, setAccountBalance] = useState("")
  const [currencyPair, setCurrencyPair] = useState("EUR/USD")
  const [lotType, setLotType] = useState<LotType>("standard")
  const [lots, setLots] = useState("1")
  const [exchangeRate, setExchangeRate] = useState("1.10")
  const [maxLeverage, setMaxLeverage] = useState("100")
  const [result, setResult] = useState<LeverageResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)

  const calculateLeverage = () => {
    setError("")
    setResult(null)

    const balance = Number.parseFloat(accountBalance)
    const lotsNum = Number.parseFloat(lots)
    const rate = Number.parseFloat(exchangeRate)
    const maxLev = Number.parseFloat(maxLeverage)

    if (isNaN(balance) || balance <= 0) {
      setError("Please enter a valid account balance greater than 0")
      return
    }

    if (isNaN(lotsNum) || lotsNum <= 0) {
      setError("Please enter a valid number of lots greater than 0")
      return
    }

    if (isNaN(rate) || rate <= 0) {
      setError("Please enter a valid exchange rate greater than 0")
      return
    }

    const selectedPair = forexPairs.find((p) => p.pair === currencyPair)
    if (!selectedPair) {
      setError("Please select a valid currency pair")
      return
    }

    // Calculate position value
    const lotMultiplier = lotSizes[lotType]
    const actualLots = lotsNum * lotMultiplier
    const contractSize = selectedPair.contractSize
    const positionValue = actualLots * contractSize * rate

    // Calculate leverage used
    const leverageUsed = positionValue / balance

    // Calculate required margin at max leverage
    const requiredMargin = positionValue / maxLev

    // Calculate margin utilization
    const marginUtilization = (requiredMargin / balance) * 100

    // Calculate max position value and lots at max leverage
    const maxPositionValue = balance * maxLev
    const maxLots = maxPositionValue / (contractSize * rate) / lotMultiplier

    // Determine risk category
    let riskCategory: string
    let riskColor: string
    let riskBgColor: string

    if (leverageUsed < 10) {
      riskCategory = "Conservative"
      riskColor = "text-green-600"
      riskBgColor = "bg-green-50 border-green-200"
    } else if (leverageUsed < 30) {
      riskCategory = "Moderate"
      riskColor = "text-blue-600"
      riskBgColor = "bg-blue-50 border-blue-200"
    } else if (leverageUsed < 100) {
      riskCategory = "Aggressive"
      riskColor = "text-yellow-600"
      riskBgColor = "bg-yellow-50 border-yellow-200"
    } else if (leverageUsed < 200) {
      riskCategory = "High Risk"
      riskColor = "text-orange-600"
      riskBgColor = "bg-orange-50 border-orange-200"
    } else {
      riskCategory = "Extreme Risk"
      riskColor = "text-red-600"
      riskBgColor = "bg-red-50 border-red-200"
    }

    setResult({
      leverageUsed: Math.round(leverageUsed * 100) / 100,
      leverageRatio: `1:${Math.round(leverageUsed)}`,
      positionValue,
      requiredMargin,
      marginUtilization: Math.round(marginUtilization * 100) / 100,
      maxPositionValue,
      maxLots: Math.round(maxLots * 100) / 100,
      riskCategory,
      riskColor,
      riskBgColor,
    })
  }

  const handleReset = () => {
    setAccountBalance("")
    setCurrencyPair("EUR/USD")
    setLotType("standard")
    setLots("1")
    setExchangeRate("1.10")
    setMaxLeverage("100")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Forex Leverage Analysis: ${result.leverageRatio} leverage used. Position Value: ${formatCurrency(result.positionValue, currency)}, Required Margin: ${formatCurrency(result.requiredMargin, currency)}, Margin Utilization: ${result.marginUtilization}%. Risk Category: ${result.riskCategory}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Forex Leverage Analysis",
          text: `My forex leverage analysis: ${result.leverageRatio} leverage used with ${result.riskCategory} risk level.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Forex Leverage Calculator</CardTitle>
                    <CardDescription>Calculate leverage and risk for forex trades</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Account Balance */}
                <div className="space-y-2">
                  <Label htmlFor="accountBalance">Account Balance ({currencySymbols[currency]})</Label>
                  <Input
                    id="accountBalance"
                    type="number"
                    placeholder="Enter account balance"
                    value={accountBalance}
                    onChange={(e) => setAccountBalance(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Currency Pair */}
                <div className="space-y-2">
                  <Label>Currency Pair</Label>
                  <Select value={currencyPair} onValueChange={setCurrencyPair}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select currency pair" />
                    </SelectTrigger>
                    <SelectContent>
                      {forexPairs.map((pair) => (
                        <SelectItem key={pair.pair} value={pair.pair}>
                          {pair.pair} - {pair.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Lot Type */}
                <div className="space-y-2">
                  <Label>Lot Type</Label>
                  <Select value={lotType} onValueChange={(v) => setLotType(v as LotType)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select lot type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard (100,000 units)</SelectItem>
                      <SelectItem value="mini">Mini (10,000 units)</SelectItem>
                      <SelectItem value="micro">Micro (1,000 units)</SelectItem>
                      <SelectItem value="nano">Nano (100 units)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Number of Lots */}
                <div className="space-y-2">
                  <Label htmlFor="lots">Number of Lots</Label>
                  <Input
                    id="lots"
                    type="number"
                    placeholder="Enter number of lots"
                    value={lots}
                    onChange={(e) => setLots(e.target.value)}
                    min="0.01"
                    step="0.01"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    {/* Exchange Rate */}
                    <div className="space-y-2">
                      <Label htmlFor="exchangeRate">Exchange Rate</Label>
                      <Input
                        id="exchangeRate"
                        type="number"
                        placeholder="Enter exchange rate"
                        value={exchangeRate}
                        onChange={(e) => setExchangeRate(e.target.value)}
                        min="0.0001"
                        step="0.0001"
                      />
                      <p className="text-xs text-muted-foreground">
                        Current exchange rate for the selected currency pair
                      </p>
                    </div>

                    {/* Max Leverage */}
                    <div className="space-y-2">
                      <Label>Maximum Broker Leverage</Label>
                      <Select value={maxLeverage} onValueChange={setMaxLeverage}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select max leverage" />
                        </SelectTrigger>
                        <SelectContent>
                          {leverageOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">Maximum leverage allowed by your broker</p>
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLeverage} className="w-full" size="lg">
                  Calculate Leverage
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.riskBgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Leverage Used</p>
                      <p className={`text-4xl font-bold ${result.riskColor} mb-2`}>{result.leverageRatio}</p>
                      <p className={`text-lg font-semibold ${result.riskColor}`}>{result.riskCategory}</p>
                    </div>

                    {/* Visual Leverage Bar */}
                    <div className="mt-4 space-y-2">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>1:1</span>
                        <span>1:{maxLeverage}</span>
                      </div>
                      <div className="h-3 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            result.leverageUsed < 10
                              ? "bg-green-500"
                              : result.leverageUsed < 30
                                ? "bg-blue-500"
                                : result.leverageUsed < 100
                                  ? "bg-yellow-500"
                                  : result.leverageUsed < 200
                                    ? "bg-orange-500"
                                    : "bg-red-500"
                          }`}
                          style={{
                            width: `${Math.min((result.leverageUsed / Number.parseFloat(maxLeverage)) * 100, 100)}%`,
                          }}
                        />
                      </div>
                    </div>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="text-center p-2 bg-background/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Position Value</p>
                        <p className="font-semibold">{formatCurrency(result.positionValue, currency)}</p>
                      </div>
                      <div className="text-center p-2 bg-background/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Required Margin</p>
                        <p className="font-semibold">{formatCurrency(result.requiredMargin, currency)}</p>
                      </div>
                    </div>

                    {/* Margin Utilization */}
                    <div className="mt-3 p-2 bg-background/50 rounded-lg">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Margin Utilization</span>
                        <span
                          className={`font-semibold ${
                            result.marginUtilization < 50
                              ? "text-green-600"
                              : result.marginUtilization < 80
                                ? "text-yellow-600"
                                : "text-red-600"
                          }`}
                        >
                          {result.marginUtilization}%
                        </span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden mt-1">
                        <div
                          className={`h-full transition-all duration-500 ${
                            result.marginUtilization < 50
                              ? "bg-green-500"
                              : result.marginUtilization < 80
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                          style={{ width: `${Math.min(result.marginUtilization, 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3">
                          {showDetails ? "Hide Details" : "Show Details"}
                          {showDetails ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2 text-sm">
                        <div className="p-3 bg-background/50 rounded-lg space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Currency Pair</span>
                            <span className="font-medium">{currencyPair}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Lot Size</span>
                            <span className="font-medium">
                              {lots} {lotType} lot{Number.parseFloat(lots) !== 1 ? "s" : ""}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Exchange Rate</span>
                            <span className="font-medium">{exchangeRate}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Max Leverage</span>
                            <span className="font-medium">1:{maxLeverage}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Max Position at 1:{maxLeverage}</span>
                            <span className="font-medium">{formatCurrency(result.maxPositionValue, currency)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Max {lotType} Lots</span>
                            <span className="font-medium">{result.maxLots}</span>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Leverage Risk Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Conservative</span>
                      <span className="text-sm text-green-600">{"< 1:10"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Moderate</span>
                      <span className="text-sm text-blue-600">1:10 - 1:30</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Aggressive</span>
                      <span className="text-sm text-yellow-600">1:30 - 1:100</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">High Risk</span>
                      <span className="text-sm text-orange-600">1:100 - 1:200</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Extreme Risk</span>
                      <span className="text-sm text-red-600">{"> 1:200"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Leverage Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Leverage = Position Value / Account Balance</p>
                    <p className="font-semibold text-foreground">Required Margin = Position Value / Leverage</p>
                  </div>
                  <p>
                    <strong>Position Value</strong> = Lot Size x Contract Size x Exchange Rate
                  </p>
                  <p>
                    Higher leverage amplifies both profits and losses. A 1:100 leverage means controlling $100,000 with
                    just $1,000.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Lot Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Standard Lot</span>
                      <span className="font-medium">100,000 units</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Mini Lot</span>
                      <span className="font-medium">10,000 units</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Micro Lot</span>
                      <span className="font-medium">1,000 units</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Nano Lot</span>
                      <span className="font-medium">100 units</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Forex Leverage?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Forex leverage is a powerful trading tool that allows you to control a larger position in the market
                  with a smaller amount of capital. It essentially amplifies your trading power by borrowing funds from
                  your broker to open positions larger than your account balance would normally allow.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, with 1:100 leverage, you can control a $100,000 position with just $1,000 of your own
                  capital. This means both your potential profits and losses are magnified by a factor of 100. While
                  leverage can significantly increase returns on successful trades, it equally amplifies losses on
                  unsuccessful ones.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Leverage Risk</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The key to successful forex trading is understanding and managing leverage risk. Professional traders
                  typically use conservative leverage ratios (1:10 or less) to protect their capital from sudden market
                  movements. Higher leverage increases the risk of margin calls and account liquidation.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-green-800 text-sm">
                      <strong>Conservative (1:10 or less):</strong> Suitable for beginners and long-term traders. Allows
                      for larger price swings without risking margin calls.
                    </p>
                  </div>
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-yellow-800 text-sm">
                      <strong>Moderate (1:10 to 1:30):</strong> Common among experienced traders. Requires disciplined
                      risk management and stop-loss orders.
                    </p>
                  </div>
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-red-800 text-sm">
                      <strong>High (1:100+):</strong> Only for professional traders with extensive experience. Small
                      price movements can result in significant losses or total account liquidation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-800 text-sm leading-relaxed">
                  Leverage calculations are estimates based on entered values. Actual leverage and margin requirements
                  may vary due to broker policies, account type, and market conditions. Forex trading involves
                  substantial risk of loss and is not suitable for all investors. Past performance is not indicative of
                  future results. Consult your broker or a trading professional for precise guidance before making any
                  trading decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
