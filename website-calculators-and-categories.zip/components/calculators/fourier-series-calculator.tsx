"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Info,
  AlertTriangle,
  Calculator,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type SeriesType = "full" | "sine" | "cosine"

interface FourierCoefficient {
  n: number
  an: number
  bn: number
}

interface FourierResult {
  a0: number
  coefficients: FourierCoefficient[]
  seriesExpression: string
  latexExpression: string
}

export function FourierSeriesCalculator() {
  const [functionInput, setFunctionInput] = useState("")
  const [variable, setVariable] = useState("x")
  const [periodL, setPeriodL] = useState("")
  const [seriesType, setSeriesType] = useState<SeriesType>("full")
  const [numTerms, setNumTerms] = useState("5")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<FourierResult | null>(null)
  const [steps, setSteps] = useState<string[]>([])
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [showStepsPanel, setShowStepsPanel] = useState(false)

  // Parse and evaluate function at a given x value
  const evaluateFunction = (expr: string, varName: string, value: number): number => {
    try {
      // Replace variable with value
      const evaluated = expr
        .toLowerCase()
        .replace(new RegExp(`\\b${varName}\\b`, "g"), `(${value})`)
        .replace(/\^/g, "**")
        .replace(/pi/g, String(Math.PI))
        .replace(/e(?![x])/g, String(Math.E))
        .replace(/sin\(/g, "Math.sin(")
        .replace(/cos\(/g, "Math.cos(")
        .replace(/tan\(/g, "Math.tan(")
        .replace(/exp\(/g, "Math.exp(")
        .replace(/ln\(/g, "Math.log(")
        .replace(/log\(/g, "Math.log10(")
        .replace(/sqrt\(/g, "Math.sqrt(")
        .replace(/abs\(/g, "Math.abs(")

      // eslint-disable-next-line no-eval
      return eval(evaluated)
    } catch {
      return Number.NaN
    }
  }

  // Numerical integration using Simpson's rule
  const integrate = (f: (x: number) => number, a: number, b: number, n = 1000): number => {
    if (n % 2 !== 0) n++
    const h = (b - a) / n
    let sum = f(a) + f(b)

    for (let i = 1; i < n; i++) {
      const x = a + i * h
      sum += (i % 2 === 0 ? 2 : 4) * f(x)
    }

    return (h / 3) * sum
  }

  const calculateFourierSeries = () => {
    setError("")
    setResult(null)
    setSteps([])

    if (!functionInput.trim()) {
      setError("Please enter a function")
      return
    }

    const L = Number.parseFloat(periodL)
    if (isNaN(L) || L <= 0) {
      setError("Please enter a valid positive period (L)")
      return
    }

    const n = Number.parseInt(numTerms)
    if (isNaN(n) || n < 1 || n > 20) {
      setError("Number of terms must be between 1 and 20")
      return
    }

    // Test function evaluation
    const testVal = evaluateFunction(functionInput, variable, 0)
    if (isNaN(testVal)) {
      setError("Invalid function expression. Please check your input.")
      return
    }

    const calculationSteps: string[] = []
    calculationSteps.push(`Function: f(${variable}) = ${functionInput}`)
    calculationSteps.push(`Period: 2L = 2 × ${L} = ${2 * L}`)
    calculationSteps.push(
      `Series type: ${seriesType === "full" ? "Full Fourier Series" : seriesType === "sine" ? "Fourier Sine Series" : "Fourier Cosine Series"}`,
    )
    calculationSteps.push(`Number of terms: ${n}`)
    calculationSteps.push("")

    // Calculate a₀
    let a0 = 0
    if (seriesType !== "sine") {
      const f_a0 = (x: number) => evaluateFunction(functionInput, variable, x)
      a0 = (1 / (2 * L)) * integrate(f_a0, -L, L)
      calculationSteps.push("Calculating a₀:")
      calculationSteps.push(`a₀ = (1/2L) ∫₋ₗᴸ f(${variable}) d${variable}`)
      calculationSteps.push(`a₀ = (1/${2 * L}) × ∫₋${L}^${L} f(${variable}) d${variable}`)
      calculationSteps.push(`a₀ ≈ ${a0.toFixed(6)}`)
      calculationSteps.push("")
    }

    // Calculate coefficients
    const coefficients: FourierCoefficient[] = []

    for (let k = 1; k <= n; k++) {
      let an = 0
      let bn = 0

      if (seriesType !== "sine") {
        // Calculate aₙ
        const f_an = (x: number) => {
          const fx = evaluateFunction(functionInput, variable, x)
          return fx * Math.cos((k * Math.PI * x) / L)
        }
        an = (1 / L) * integrate(f_an, -L, L)

        if (showSteps && k <= 3) {
          calculationSteps.push(`Calculating a${k}:`)
          calculationSteps.push(`a${k} = (1/L) ∫₋ₗᴸ f(${variable}) cos(${k}π${variable}/L) d${variable}`)
          calculationSteps.push(`a${k} ≈ ${an.toFixed(6)}`)
          calculationSteps.push("")
        }
      }

      if (seriesType !== "cosine") {
        // Calculate bₙ
        const f_bn = (x: number) => {
          const fx = evaluateFunction(functionInput, variable, x)
          return fx * Math.sin((k * Math.PI * x) / L)
        }
        bn = (1 / L) * integrate(f_bn, -L, L)

        if (showSteps && k <= 3) {
          calculationSteps.push(`Calculating b${k}:`)
          calculationSteps.push(`b${k} = (1/L) ∫₋ₗᴸ f(${variable}) sin(${k}π${variable}/L) d${variable}`)
          calculationSteps.push(`b${k} ≈ ${bn.toFixed(6)}`)
          calculationSteps.push("")
        }
      }

      coefficients.push({ n: k, an, bn })
    }

    // Build series expression
    let seriesExpr = ""
    let latexExpr = ""

    if (seriesType !== "sine" && Math.abs(a0) > 1e-10) {
      seriesExpr = formatCoeff(a0, true)
      latexExpr = formatCoeff(a0, true)
    }

    coefficients.forEach((coeff, idx) => {
      const k = coeff.n

      if (seriesType !== "sine" && Math.abs(coeff.an) > 1e-10) {
        const sign = coeff.an >= 0 && seriesExpr ? " + " : coeff.an < 0 ? " - " : seriesExpr ? " + " : ""
        const absAn = Math.abs(coeff.an)
        seriesExpr += `${sign}${formatCoeff(absAn, !seriesExpr)}cos(${k}π${variable}/${L})`
        latexExpr += `${sign}${formatCoeff(absAn, !latexExpr)}\\cos\\left(\\frac{${k}\\pi ${variable}}{${L}}\\right)`
      }

      if (seriesType !== "cosine" && Math.abs(coeff.bn) > 1e-10) {
        const sign = coeff.bn >= 0 && seriesExpr ? " + " : coeff.bn < 0 ? " - " : seriesExpr ? " + " : ""
        const absBn = Math.abs(coeff.bn)
        seriesExpr += `${sign}${formatCoeff(absBn, !seriesExpr)}sin(${k}π${variable}/${L})`
        latexExpr += `${sign}${formatCoeff(absBn, !latexExpr)}\\sin\\left(\\frac{${k}\\pi ${variable}}{${L}}\\right)`
      }
    })

    if (!seriesExpr) {
      seriesExpr = "0"
      latexExpr = "0"
    }

    calculationSteps.push("Fourier Series:")
    calculationSteps.push(`f(${variable}) ≈ ${seriesExpr}`)

    setResult({
      a0,
      coefficients,
      seriesExpression: seriesExpr,
      latexExpression: `f(${variable}) \\approx ${latexExpr}`,
    })
    setSteps(calculationSteps)
  }

  const formatCoeff = (value: number, isFirst: boolean): string => {
    const rounded = Math.round(value * 10000) / 10000
    if (Math.abs(rounded - 1) < 1e-10) return isFirst ? "" : ""
    if (Math.abs(rounded + 1) < 1e-10) return "-"
    return rounded.toFixed(4).replace(/\.?0+$/, "")
  }

  const handleReset = () => {
    setFunctionInput("")
    setPeriodL("")
    setNumTerms("5")
    setSeriesType("full")
    setResult(null)
    setSteps([])
    setError("")
    setCopied(false)
    setCopiedLatex(false)
    setShowStepsPanel(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`f(${variable}) ≈ ${result.seriesExpression}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      await navigator.clipboard.writeText(result.latexExpression)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Fourier Series Calculator</CardTitle>
                    <CardDescription>Compute Fourier series representation</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Function Input */}
                <div className="space-y-2">
                  <Label htmlFor="function">Function f({variable})</Label>
                  <Input
                    id="function"
                    type="text"
                    placeholder="e.g., x, x^2, sin(x), x*cos(x)"
                    value={functionInput}
                    onChange={(e) => setFunctionInput(e.target.value)}
                  />
                </div>

                {/* Variable and Period */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="variable">Variable</Label>
                    <Select value={variable} onValueChange={setVariable}>
                      <SelectTrigger id="variable">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="x">x</SelectItem>
                        <SelectItem value="t">t</SelectItem>
                        <SelectItem value="θ">θ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="period">Half-Period (L)</Label>
                    <Input
                      id="period"
                      type="number"
                      placeholder="e.g., π or 1"
                      value={periodL}
                      onChange={(e) => setPeriodL(e.target.value)}
                      step="any"
                    />
                  </div>
                </div>

                {/* Series Type */}
                <div className="space-y-2">
                  <Label htmlFor="seriesType">Series Type</Label>
                  <Select value={seriesType} onValueChange={(v) => setSeriesType(v as SeriesType)}>
                    <SelectTrigger id="seriesType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="full">Full Fourier Series</SelectItem>
                      <SelectItem value="sine">Fourier Sine Series (odd extension)</SelectItem>
                      <SelectItem value="cosine">Fourier Cosine Series (even extension)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Number of Terms */}
                <div className="space-y-2">
                  <Label htmlFor="terms">Number of Terms (n)</Label>
                  <Input
                    id="terms"
                    type="number"
                    placeholder="1-20"
                    value={numTerms}
                    onChange={(e) => setNumTerms(e.target.value)}
                    min="1"
                    max="20"
                  />
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show step-by-step calculations</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFourierSeries} className="w-full" size="lg">
                  Calculate Fourier Series
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Fourier Series</p>
                      <div className="p-3 bg-white rounded-lg border overflow-x-auto">
                        <p className="font-mono text-sm text-blue-700 whitespace-nowrap">
                          f({variable}) ≈ {result.seriesExpression}
                        </p>
                      </div>
                    </div>

                    {/* Coefficients Table */}
                    <div className="mb-4">
                      <p className="text-sm font-medium mb-2">Coefficients:</p>
                      <div className="bg-white rounded-lg border overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b bg-muted/50">
                              <th className="p-2 text-left">n</th>
                              {seriesType !== "sine" && <th className="p-2 text-left">aₙ</th>}
                              {seriesType !== "cosine" && <th className="p-2 text-left">bₙ</th>}
                            </tr>
                          </thead>
                          <tbody>
                            {seriesType !== "sine" && (
                              <tr className="border-b">
                                <td className="p-2 font-mono">0</td>
                                <td className="p-2 font-mono">{result.a0.toFixed(6)}</td>
                                {seriesType !== "cosine" && <td className="p-2 font-mono">-</td>}
                              </tr>
                            )}
                            {result.coefficients.slice(0, 5).map((coeff) => (
                              <tr key={coeff.n} className="border-b last:border-b-0">
                                <td className="p-2 font-mono">{coeff.n}</td>
                                {seriesType !== "sine" && <td className="p-2 font-mono">{coeff.an.toFixed(6)}</td>}
                                {seriesType !== "cosine" && <td className="p-2 font-mono">{coeff.bn.toFixed(6)}</td>}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Step-by-step Panel */}
                    {showSteps && steps.length > 0 && (
                      <div className="mb-4">
                        <button
                          onClick={() => setShowStepsPanel(!showStepsPanel)}
                          className="flex items-center gap-2 text-sm font-medium text-blue-700 hover:text-blue-800"
                        >
                          {showStepsPanel ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          {showStepsPanel ? "Hide" : "Show"} Step-by-Step Solution
                        </button>
                        {showStepsPanel && (
                          <div className="mt-2 p-3 bg-white rounded-lg border text-sm space-y-1">
                            {steps.map((step, idx) => (
                              <p key={idx} className={`font-mono ${step === "" ? "h-2" : ""}`}>
                                {step}
                              </p>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fourier Series Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p className="font-semibold mb-2">Full Fourier Series:</p>
                    <p>f(x) = a₀ + Σ [aₙcos(nπx/L) + bₙsin(nπx/L)]</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p className="font-semibold mb-2">Coefficients:</p>
                    <p>a₀ = (1/2L) ∫₋ₗᴸ f(x) dx</p>
                    <p>aₙ = (1/L) ∫₋ₗᴸ f(x) cos(nπx/L) dx</p>
                    <p>bₙ = (1/L) ∫₋ₗᴸ f(x) sin(nπx/L) dx</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Series Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="font-medium text-blue-700">Full Series</p>
                      <p className="text-blue-600">Contains both sine and cosine terms</p>
                    </div>
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <p className="font-medium text-green-700">Sine Series (odd)</p>
                      <p className="text-green-600">Only sine terms, bₙ coefficients</p>
                    </div>
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                      <p className="font-medium text-purple-700">Cosine Series (even)</p>
                      <p className="text-purple-600">Only cosine terms, a₀ and aₙ coefficients</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>Supported operations:</strong>
                    </p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>+, -, *, /, ^ (power)</li>
                      <li>sin(x), cos(x), tan(x)</li>
                      <li>exp(x), ln(x), sqrt(x)</li>
                      <li>abs(x), pi, e</li>
                    </ul>
                    <p className="mt-2">
                      <strong>Examples:</strong>
                    </p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>x (sawtooth wave)</li>
                      <li>x^2 (parabola)</li>
                      <li>abs(x) (triangle wave)</li>
                      <li>sin(x) + cos(2*x)</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Fourier Series?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A Fourier series is a mathematical tool that represents a periodic function as an infinite sum of sine
                  and cosine functions. Named after French mathematician Joseph Fourier, this powerful concept allows us
                  to decompose complex periodic signals into simpler harmonic components. The Fourier series is
                  fundamental in signal processing, physics, engineering, and many other fields where periodic phenomena
                  need to be analyzed or synthesized.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key insight is that any reasonably well-behaved periodic function can be expressed as a weighted
                  sum of sinusoids at different frequencies. The weights (Fourier coefficients) determine how much each
                  harmonic contributes to the overall shape of the function.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Fourier Series</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Fourier series have wide-ranging applications across science and engineering. In signal processing,
                  they are used to analyze audio signals, filter noise, and compress data. In electrical engineering,
                  they help analyze AC circuits and design filters. In physics, Fourier analysis is essential for
                  studying heat conduction, wave propagation, and quantum mechanics.
                </p>
                <div className="mt-4 grid gap-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Signal Processing</p>
                    <p className="text-sm text-muted-foreground">Audio analysis, image compression, filtering</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Communications</p>
                    <p className="text-sm text-muted-foreground">Modulation, bandwidth analysis, spectral analysis</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium">Physics & Engineering</p>
                    <p className="text-sm text-muted-foreground">
                      Heat transfer, vibration analysis, quantum mechanics
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Fourier series calculations follow standard mathematical formulas. Results depend on correct function
                  input, period, and number of terms. This calculator uses numerical integration (Simpson&apos;s rule)
                  which provides approximations. For exact analytical solutions, manual calculation or symbolic
                  computation software is recommended. Always verify critical calculations with additional methods.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
