"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Receipt,
  Info,
  Users,
  DollarSign,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface TipResult {
  tipAmount: number
  totalBill: number
  perPersonAmount: number
  perPersonTip: number
}

const TIP_PRESETS = [5, 10, 15, 18, 20, 25]

export function TipCalculator() {
  const [billAmount, setBillAmount] = useState("")
  const [tipPercentage, setTipPercentage] = useState("15")
  const [numPeople, setNumPeople] = useState("1")
  const [roundUp, setRoundUp] = useState(false)
  const [result, setResult] = useState<TipResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateTip = () => {
    setError("")
    setResult(null)

    const bill = Number.parseFloat(billAmount)
    const tip = Number.parseFloat(tipPercentage)
    const people = Number.parseInt(numPeople)

    if (isNaN(bill) || bill <= 0) {
      setError("Please enter a valid bill amount greater than 0")
      return
    }

    if (isNaN(tip) || tip < 0) {
      setError("Please enter a valid tip percentage (0 or greater)")
      return
    }

    if (isNaN(people) || people < 1) {
      setError("Please enter at least 1 person")
      return
    }

    let tipAmount = bill * (tip / 100)
    let totalBill = bill + tipAmount

    if (roundUp) {
      totalBill = Math.ceil(totalBill)
      tipAmount = totalBill - bill
    }

    const perPersonAmount = totalBill / people
    const perPersonTip = tipAmount / people

    setResult({
      tipAmount: Math.round(tipAmount * 100) / 100,
      totalBill: Math.round(totalBill * 100) / 100,
      perPersonAmount: Math.round(perPersonAmount * 100) / 100,
      perPersonTip: Math.round(perPersonTip * 100) / 100,
    })
  }

  const handleReset = () => {
    setBillAmount("")
    setTipPercentage("15")
    setNumPeople("1")
    setRoundUp(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Bill: $${billAmount}\nTip (${tipPercentage}%): $${result.tipAmount.toFixed(2)}\nTotal: $${result.totalBill.toFixed(2)}\nPer Person: $${result.perPersonAmount.toFixed(2)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Tip Calculation",
          text: `Bill: $${billAmount}, Tip (${tipPercentage}%): $${result.tipAmount.toFixed(2)}, Total: $${result.totalBill.toFixed(2)}, Per Person: $${result.perPersonAmount.toFixed(2)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const handlePresetClick = (preset: number) => {
    setTipPercentage(preset.toString())
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/lifestyle-daily">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Lifestyle & Daily Use
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Receipt className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Tip Calculator</CardTitle>
                    <CardDescription>Calculate tip and split the bill</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Bill Amount Input */}
                <div className="space-y-2">
                  <Label htmlFor="bill">Bill Amount ($)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="bill"
                      type="number"
                      placeholder="Enter bill amount"
                      value={billAmount}
                      onChange={(e) => setBillAmount(e.target.value)}
                      min="0"
                      step="0.01"
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* Tip Percentage */}
                <div className="space-y-2">
                  <Label>Tip Percentage (%)</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {TIP_PRESETS.map((preset) => (
                      <Button
                        key={preset}
                        type="button"
                        variant={tipPercentage === preset.toString() ? "default" : "outline"}
                        size="sm"
                        onClick={() => handlePresetClick(preset)}
                        className="flex-1 min-w-[50px]"
                      >
                        {preset}%
                      </Button>
                    ))}
                  </div>
                  <Input
                    type="number"
                    placeholder="Custom tip %"
                    value={tipPercentage}
                    onChange={(e) => setTipPercentage(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Number of People */}
                <div className="space-y-2">
                  <Label htmlFor="people">Number of People</Label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="people"
                      type="number"
                      placeholder="Enter number of people"
                      value={numPeople}
                      onChange={(e) => setNumPeople(e.target.value)}
                      min="1"
                      step="1"
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* Round Up Toggle */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <Label htmlFor="round-up" className="cursor-pointer">
                    Round up total
                  </Label>
                  <Switch id="round-up" checked={roundUp} onCheckedChange={setRoundUp} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTip} className="w-full" size="lg">
                  Calculate Tip
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Tip Amount</p>
                        <p className="text-2xl font-bold text-amber-700">${result.tipAmount.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Total Bill</p>
                        <p className="text-2xl font-bold text-amber-700">${result.totalBill.toFixed(2)}</p>
                      </div>
                    </div>

                    {Number.parseInt(numPeople) > 1 && (
                      <div className="mt-4 pt-4 border-t border-amber-200">
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Per Person Total</p>
                            <p className="text-xl font-bold text-amber-600">${result.perPersonAmount.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Per Person Tip</p>
                            <p className="text-xl font-bold text-amber-600">${result.perPersonTip.toFixed(2)}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Breakdown Toggle */}
                    <button
                      onClick={() => setShowBreakdown(!showBreakdown)}
                      className="w-full mt-4 pt-3 border-t border-amber-200 flex items-center justify-center gap-2 text-sm text-amber-700 hover:text-amber-800 transition-colors"
                    >
                      {showBreakdown ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Breakdown
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Breakdown
                        </>
                      )}
                    </button>

                    {showBreakdown && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Bill Amount:</span>
                          <span className="font-medium">${Number.parseFloat(billAmount).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Tip ({tipPercentage}%):</span>
                          <span className="font-medium">${result.tipAmount.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between border-t border-amber-200 pt-2">
                          <span className="text-muted-foreground">Total:</span>
                          <span className="font-bold">${result.totalBill.toFixed(2)}</span>
                        </div>
                        {Number.parseInt(numPeople) > 1 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Split {numPeople} ways:</span>
                            <span className="font-medium">${result.perPersonAmount.toFixed(2)} each</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tip Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Poor Service</span>
                      <span className="text-sm text-red-600">5-10%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Average Service</span>
                      <span className="text-sm text-yellow-600">15%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Good Service</span>
                      <span className="text-sm text-green-600">18-20%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Excellent Service</span>
                      <span className="text-sm text-blue-600">25%+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tip Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Tip = Bill × (Tip% ÷ 100)</p>
                    <p className="font-semibold text-foreground">Total = Bill + Tip</p>
                    <p className="font-semibold text-foreground">Per Person = Total ÷ People</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Tipping */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Tipping?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Tipping is the practice of leaving a voluntary sum of money for service workers, particularly in the
                  hospitality industry. While tipping customs vary significantly around the world, it has become an
                  integral part of dining culture in many countries, especially in the United States where it often
                  constitutes a significant portion of servers' income.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The practice dates back centuries and has evolved from a way to reward exceptional service to an
                  expected part of the dining experience. Understanding how to calculate tips properly ensures fair
                  compensation for service workers while helping diners manage their expenses effectively.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Tips */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Receipt className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Tips</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating tips is straightforward once you understand the basic formula. Simply multiply your bill
                  amount by the tip percentage you wish to leave, then divide by 100. For example, a 20% tip on a $50
                  bill would be: $50 × 20 ÷ 100 = $10. Add this to your original bill for the total amount.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Quick Mental Math Tips</h4>
                    <ul className="text-muted-foreground text-sm space-y-2">
                      <li>
                        <strong>10% tip:</strong> Move the decimal point one place left ($50 → $5.00)
                      </li>
                      <li>
                        <strong>15% tip:</strong> Calculate 10%, then add half of that amount
                      </li>
                      <li>
                        <strong>20% tip:</strong> Calculate 10%, then double it ($50 → $5 × 2 = $10)
                      </li>
                      <li>
                        <strong>25% tip:</strong> Calculate 20%, then add 5% (or half of 10%)
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* When to Tip */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  <CardTitle>When and How Much to Tip</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Tipping expectations vary by service type and location. Here's a general guide for common situations:
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Restaurants</h4>
                    <p className="text-amber-700 text-sm">
                      15-20% is standard for sit-down service. Consider 20-25% for exceptional service or large parties.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Delivery</h4>
                    <p className="text-amber-700 text-sm">
                      15-20% or a minimum of $3-5, depending on distance and weather conditions.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Bars</h4>
                    <p className="text-amber-700 text-sm">
                      $1-2 per drink or 15-20% of the total tab for more complex orders.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Takeout</h4>
                    <p className="text-amber-700 text-sm">
                      Not always expected, but 10-15% is appreciated, especially for large or complex orders.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground text-center">
                  <strong>Note:</strong> Tip amounts are estimates and may vary depending on local tipping practices,
                  cultural norms, and service quality. Always consider the specific context when deciding on tip
                  amounts.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
