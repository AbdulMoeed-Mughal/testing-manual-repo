"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Paintbrush,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type SurfaceType = "wall" | "ceiling" | "exterior"

interface PaintResult {
  paintableArea: number
  paintRequired: number
  paintWithWaste: number
  cansNeeded: number
  areaUnit: string
  volumeUnit: string
}

export function PaintCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [surfaceType, setSurfaceType] = useState<SurfaceType>("wall")
  const [length, setLength] = useState("")
  const [height, setHeight] = useState("")
  const [coats, setCoats] = useState("2")
  const [coverage, setCoverage] = useState("")
  const [openings, setOpenings] = useState("")
  const [waste, setWaste] = useState("10")
  const [canSize, setCanSize] = useState("")
  const [result, setResult] = useState<PaintResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Default coverage values (m²/L for metric, ft²/gal for imperial)
  const defaultCoverage = unitSystem === "metric" ? "10" : "350"

  const calculatePaint = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const heightNum = Number.parseFloat(height)
    const coatsNum = Number.parseInt(coats)
    const coverageNum = Number.parseFloat(coverage) || Number.parseFloat(defaultCoverage)
    const openingsNum = Number.parseFloat(openings) || 0
    const wasteNum = Number.parseFloat(waste) || 0
    const canSizeNum = Number.parseFloat(canSize) || 0

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }

    if (isNaN(heightNum) || heightNum <= 0) {
      setError("Please enter a valid height/width greater than 0")
      return
    }

    if (isNaN(coatsNum) || coatsNum <= 0) {
      setError("Please enter at least 1 coat")
      return
    }

    if (coverageNum <= 0) {
      setError("Please enter a valid coverage value greater than 0")
      return
    }

    // Calculate total area
    const totalArea = lengthNum * heightNum

    if (openingsNum >= totalArea) {
      setError("Openings area cannot exceed total surface area")
      return
    }

    // Calculate paintable area
    const paintableArea = totalArea - openingsNum

    // Calculate paint required (area × coats ÷ coverage)
    const paintRequired = (paintableArea * coatsNum) / coverageNum

    // Add waste percentage
    const paintWithWaste = paintRequired * (1 + wasteNum / 100)

    // Calculate cans needed
    const cansNeeded = canSizeNum > 0 ? Math.ceil(paintWithWaste / canSizeNum) : 0

    setResult({
      paintableArea: Math.round(paintableArea * 100) / 100,
      paintRequired: Math.round(paintRequired * 100) / 100,
      paintWithWaste: Math.round(paintWithWaste * 100) / 100,
      cansNeeded,
      areaUnit: unitSystem === "metric" ? "m²" : "ft²",
      volumeUnit: unitSystem === "metric" ? "L" : "gal",
    })
  }

  const handleReset = () => {
    setLength("")
    setHeight("")
    setCoats("2")
    setCoverage("")
    setOpenings("")
    setWaste("10")
    setCanSize("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Paint Calculation: ${result.paintWithWaste} ${result.volumeUnit} needed for ${result.paintableArea} ${result.areaUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Paint Calculator Result",
          text: `I need ${result.paintWithWaste} ${result.volumeUnit} of paint for ${result.paintableArea} ${result.areaUnit} using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setHeight("")
    setCoverage("")
    setOpenings("")
    setCanSize("")
    setResult(null)
    setError("")
  }

  const getSurfaceLabel = () => {
    switch (surfaceType) {
      case "wall":
        return { dim1: "Wall Length", dim2: "Wall Height" }
      case "ceiling":
        return { dim1: "Length", dim2: "Width" }
      case "exterior":
        return { dim1: "Wall Length", dim2: "Wall Height" }
    }
  }

  const labels = getSurfaceLabel()
  const lengthUnit = unitSystem === "metric" ? "m" : "ft"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Paintbrush className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Paint Calculator</CardTitle>
                    <CardDescription>Estimate paint needed for your project</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Surface Type */}
                <div className="space-y-2">
                  <Label>Surface Type</Label>
                  <Select value={surfaceType} onValueChange={(v) => setSurfaceType(v as SurfaceType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="wall">Wall</SelectItem>
                      <SelectItem value="ceiling">Ceiling</SelectItem>
                      <SelectItem value="exterior">Exterior</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">
                      {labels.dim1} ({lengthUnit})
                    </Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "5" : "16"}`}
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="height">
                      {labels.dim2} ({lengthUnit})
                    </Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "2.5" : "8"}`}
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Coats and Coverage */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="coats">Number of Coats</Label>
                    <Select value={coats} onValueChange={setCoats}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 coat</SelectItem>
                        <SelectItem value="2">2 coats</SelectItem>
                        <SelectItem value="3">3 coats</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="coverage">Coverage ({unitSystem === "metric" ? "m²/L" : "ft²/gal"})</Label>
                    <Input
                      id="coverage"
                      type="number"
                      placeholder={defaultCoverage}
                      value={coverage}
                      onChange={(e) => setCoverage(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                {/* Openings */}
                <div className="space-y-2">
                  <Label htmlFor="openings">
                    Openings Area - Doors/Windows ({unitSystem === "metric" ? "m²" : "ft²"})
                  </Label>
                  <Input
                    id="openings"
                    type="number"
                    placeholder="Optional - e.g., 3"
                    value={openings}
                    onChange={(e) => setOpenings(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Waste and Can Size */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="waste">Waste Percentage (%)</Label>
                    <Select value={waste} onValueChange={setWaste}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="5">5%</SelectItem>
                        <SelectItem value="10">10% (Recommended)</SelectItem>
                        <SelectItem value="15">15%</SelectItem>
                        <SelectItem value="20">20%</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="canSize">Can Size ({unitSystem === "metric" ? "L" : "gal"})</Label>
                    <Input
                      id="canSize"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "4" : "1"}`}
                      value={canSize}
                      onChange={(e) => setCanSize(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePaint} className="w-full" size="lg">
                  Calculate Paint
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Paint Required (with waste)</p>
                      <p className="text-5xl font-bold text-cyan-600 mb-2">
                        {result.paintWithWaste} <span className="text-2xl">{result.volumeUnit}</span>
                      </p>
                      {result.cansNeeded > 0 && (
                        <p className="text-lg font-semibold text-cyan-700">
                          {result.cansNeeded} can{result.cansNeeded > 1 ? "s" : ""} needed
                        </p>
                      )}
                    </div>

                    {/* Additional Results */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Paintable Area</p>
                        <p className="font-semibold text-foreground">
                          {result.paintableArea} {result.areaUnit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Paint (no waste)</p>
                        <p className="font-semibold text-foreground">
                          {result.paintRequired} {result.volumeUnit}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-center gap-1 w-full mt-4 text-sm text-cyan-700 hover:text-cyan-800"
                    >
                      {showSteps ? (
                        <>
                          Hide calculation steps <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show calculation steps <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Total Area = {length} × {height} ={" "}
                          {(Number.parseFloat(length) * Number.parseFloat(height)).toFixed(2)} {result.areaUnit}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Paintable Area ={" "}
                          {(Number.parseFloat(length) * Number.parseFloat(height)).toFixed(2)} - {openings || 0} ={" "}
                          {result.paintableArea} {result.areaUnit}
                        </p>
                        <p>
                          <strong>Step 3:</strong> Paint Required = ({result.paintableArea} × {coats}) ÷{" "}
                          {coverage || defaultCoverage} = {result.paintRequired} {result.volumeUnit}
                        </p>
                        <p>
                          <strong>Step 4:</strong> With {waste}% waste = {result.paintRequired} ×{" "}
                          {(1 + Number.parseFloat(waste) / 100).toFixed(2)} = {result.paintWithWaste}{" "}
                          {result.volumeUnit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Paint Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Paintable Area = (L × H) − Openings</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Paint = (Area × Coats) ÷ Coverage</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Total = Paint × (1 + Waste%)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Coverage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Latex/Emulsion Paint</span>
                      <span className="font-medium">{unitSystem === "metric" ? "10-12 m²/L" : "350-400 ft²/gal"}</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Primer</span>
                      <span className="font-medium">{unitSystem === "metric" ? "8-10 m²/L" : "300-350 ft²/gal"}</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Textured Surfaces</span>
                      <span className="font-medium">{unitSystem === "metric" ? "6-8 m²/L" : "200-300 ft²/gal"}</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Exterior Paint</span>
                      <span className="font-medium">{unitSystem === "metric" ? "8-10 m²/L" : "300-400 ft²/gal"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual paint usage may vary based on surface texture, porosity, and
                        application method. Always purchase slightly more than calculated.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Paint Coverage</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Paint coverage refers to how much surface area a specific quantity of paint can cover. This is
                  typically expressed in square meters per liter (m²/L) for metric units or square feet per gallon
                  (ft²/gal) for imperial units. Understanding coverage is crucial for accurately estimating how much
                  paint you need for your project and avoiding waste or shortages.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Most standard interior latex paints cover approximately 10-12 m² per liter (350-400 ft² per gallon) on
                  smooth, primed surfaces. However, actual coverage can vary significantly based on the paint type,
                  surface condition, application method, and the color being applied. Dark colors over light surfaces or
                  vice versa may require additional coats for proper coverage.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Paintbrush className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Paint Requirements</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Surface Texture</h4>
                    <p className="text-cyan-700 text-sm">
                      Rough or textured surfaces absorb more paint than smooth surfaces. Brick, stucco, and textured
                      drywall may require 20-50% more paint than smooth walls.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Surface Porosity</h4>
                    <p className="text-blue-700 text-sm">
                      New drywall, bare wood, and unpainted surfaces are more porous and absorb more paint. Using a
                      primer first helps seal the surface and reduces topcoat requirements.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Color Change</h4>
                    <p className="text-green-700 text-sm">
                      Dramatic color changes (light to dark or vice versa) typically require more coats. A tinted primer
                      matching your topcoat color can help reduce the number of finish coats needed.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Application Method</h4>
                    <p className="text-amber-700 text-sm">
                      Spray application typically uses 20-30% more paint than brush or roller application due to
                      overspray. Rollers are generally the most efficient method for large, flat surfaces.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Paint Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-3">
                  <li>
                    <strong>Measure accurately:</strong> Take precise measurements of all surfaces to be painted.
                    Include all walls, ceilings, and trim work separately as they may have different coverage rates.
                  </li>
                  <li>
                    <strong>Account for openings:</strong> Subtract door and window areas from your total. A standard
                    door is about 2 m² (21 ft²) and a standard window is about 1.5 m² (15 ft²).
                  </li>
                  <li>
                    <strong>Plan for multiple coats:</strong> Most projects require 2 coats for best results. Factor
                    this into your calculations from the start.
                  </li>
                  <li>
                    <strong>Add waste allowance:</strong> Always add 10-15% extra for waste, touch-ups, and future
                    repairs. Paint from the same batch ensures color consistency.
                  </li>
                  <li>
                    <strong>Consider surface prep:</strong> If using primer, calculate primer requirements separately as
                    coverage rates differ from topcoat paint.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
