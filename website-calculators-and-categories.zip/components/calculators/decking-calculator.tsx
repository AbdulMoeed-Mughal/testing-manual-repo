"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, ChevronDown, ChevronUp, Layers } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface DeckingResult {
  deckArea: number
  totalBoards: number
  totalBoardsWithWaste: number
  boardsPerRow: number
  rowsNeeded: number
  deckingVolume: number | null
  deckingWeight: number | null
}

export function DeckingCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [deckLength, setDeckLength] = useState("")
  const [deckWidth, setDeckWidth] = useState("")
  const [boardWidth, setBoardWidth] = useState(unitSystem === "metric" ? "140" : "5.5")
  const [boardLength, setBoardLength] = useState(unitSystem === "metric" ? "2.4" : "8")
  const [boardThickness, setBoardThickness] = useState(unitSystem === "metric" ? "25" : "1")
  const [boardGap, setBoardGap] = useState(unitSystem === "metric" ? "5" : "0.2")
  const [numberOfDecks, setNumberOfDecks] = useState("1")
  const [wastePercentage, setWastePercentage] = useState("10")
  const [density, setDensity] = useState(unitSystem === "metric" ? "700" : "44")
  const [result, setResult] = useState<DeckingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const length = Number.parseFloat(deckLength)
    const width = Number.parseFloat(deckWidth)
    const bWidth = Number.parseFloat(boardWidth)
    const bLength = Number.parseFloat(boardLength)
    const bThickness = Number.parseFloat(boardThickness)
    const gap = Number.parseFloat(boardGap)
    const decks = Number.parseInt(numberOfDecks) || 1
    const waste = Number.parseFloat(wastePercentage) || 0
    const dens = Number.parseFloat(density) || 0

    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid deck length greater than 0")
      return
    }
    if (isNaN(width) || width <= 0) {
      setError("Please enter a valid deck width greater than 0")
      return
    }
    if (isNaN(bWidth) || bWidth <= 0) {
      setError("Please enter a valid board width greater than 0")
      return
    }
    if (isNaN(bLength) || bLength <= 0) {
      setError("Please enter a valid board length greater than 0")
      return
    }

    // Convert all to consistent units for calculation
    let lengthM: number, widthM: number, bWidthM: number, bLengthM: number, bThicknessM: number, gapM: number

    if (unitSystem === "metric") {
      lengthM = length
      widthM = width
      bWidthM = bWidth / 1000 // mm to m
      bLengthM = bLength
      bThicknessM = bThickness / 1000 // mm to m
      gapM = gap / 1000 // mm to m
    } else {
      lengthM = length * 0.3048 // ft to m
      widthM = width * 0.3048 // ft to m
      bWidthM = bWidth * 0.0254 // inches to m
      bLengthM = bLength * 0.3048 // ft to m
      bThicknessM = bThickness * 0.0254 // inches to m
      gapM = gap * 0.0254 // inches to m
    }

    // Calculate deck area
    const deckArea = lengthM * widthM * decks

    // Effective board width (including gap)
    const effectiveBoardWidth = bWidthM + gapM

    // Number of boards per row (across the width)
    const boardsPerRow = Math.ceil(widthM / effectiveBoardWidth)

    // Number of rows needed (along the length)
    const rowsNeeded = Math.ceil(lengthM / bLengthM)

    // Total boards
    const totalBoards = boardsPerRow * rowsNeeded * decks

    // Total boards with waste
    const totalBoardsWithWaste = Math.ceil(totalBoards * (1 + waste / 100))

    // Calculate volume and weight if thickness is provided
    let deckingVolume: number | null = null
    let deckingWeight: number | null = null

    if (!isNaN(bThickness) && bThickness > 0) {
      deckingVolume = totalBoardsWithWaste * bLengthM * bWidthM * bThicknessM

      if (dens > 0) {
        // Convert density to kg/m³ if imperial
        const densityKgM3 = unitSystem === "imperial" ? dens * 16.0185 : dens
        deckingWeight = deckingVolume * densityKgM3
      }
    }

    setResult({
      deckArea,
      totalBoards,
      totalBoardsWithWaste,
      boardsPerRow,
      rowsNeeded,
      deckingVolume,
      deckingWeight,
    })
  }

  const handleReset = () => {
    setDeckLength("")
    setDeckWidth("")
    setBoardWidth(unitSystem === "metric" ? "140" : "5.5")
    setBoardLength(unitSystem === "metric" ? "2.4" : "8")
    setBoardThickness(unitSystem === "metric" ? "25" : "1")
    setBoardGap(unitSystem === "metric" ? "5" : "0.2")
    setNumberOfDecks("1")
    setWastePercentage("10")
    setDensity(unitSystem === "metric" ? "700" : "44")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Decking Calculation Results:
- Total Boards Needed: ${result.totalBoardsWithWaste} boards
- Deck Area: ${result.deckArea.toFixed(2)} m² (${(result.deckArea * 10.764).toFixed(2)} ft²)
${result.deckingVolume ? `- Total Volume: ${result.deckingVolume.toFixed(4)} m³` : ""}
${result.deckingWeight ? `- Total Weight: ${result.deckingWeight.toFixed(1)} kg` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleUnitSystem = () => {
    const newSystem = unitSystem === "metric" ? "imperial" : "metric"
    setUnitSystem(newSystem)
    setBoardWidth(newSystem === "metric" ? "140" : "5.5")
    setBoardLength(newSystem === "metric" ? "2.4" : "8")
    setBoardThickness(newSystem === "metric" ? "25" : "1")
    setBoardGap(newSystem === "metric" ? "5" : "0.2")
    setDensity(newSystem === "metric" ? "700" : "44")
    setDeckLength("")
    setDeckWidth("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Decking Calculator</CardTitle>
                    <CardDescription>Calculate decking materials needed</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="deckLength">Deck Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="deckLength"
                      type="number"
                      placeholder="e.g. 6"
                      value={deckLength}
                      onChange={(e) => setDeckLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="deckWidth">Deck Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="deckWidth"
                      type="number"
                      placeholder="e.g. 4"
                      value={deckWidth}
                      onChange={(e) => setDeckWidth(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="boardWidth">Board Width ({unitSystem === "metric" ? "mm" : "in"})</Label>
                    <Input
                      id="boardWidth"
                      type="number"
                      placeholder={unitSystem === "metric" ? "e.g. 140" : "e.g. 5.5"}
                      value={boardWidth}
                      onChange={(e) => setBoardWidth(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="boardLength">Board Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="boardLength"
                      type="number"
                      placeholder={unitSystem === "metric" ? "e.g. 2.4" : "e.g. 8"}
                      value={boardLength}
                      onChange={(e) => setBoardLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="boardThickness">Board Thickness ({unitSystem === "metric" ? "mm" : "in"})</Label>
                    <Input
                      id="boardThickness"
                      type="number"
                      placeholder={unitSystem === "metric" ? "e.g. 25" : "e.g. 1"}
                      value={boardThickness}
                      onChange={(e) => setBoardThickness(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="boardGap">Board Gap ({unitSystem === "metric" ? "mm" : "in"})</Label>
                    <Input
                      id="boardGap"
                      type="number"
                      placeholder={unitSystem === "metric" ? "e.g. 5" : "e.g. 0.2"}
                      value={boardGap}
                      onChange={(e) => setBoardGap(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="numberOfDecks">Number of Decks</Label>
                    <Input
                      id="numberOfDecks"
                      type="number"
                      placeholder="e.g. 1"
                      value={numberOfDecks}
                      onChange={(e) => setNumberOfDecks(e.target.value)}
                      min="1"
                      step="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wastePercentage">Waste (%)</Label>
                    <Input
                      id="wastePercentage"
                      type="number"
                      placeholder="e.g. 10"
                      value={wastePercentage}
                      onChange={(e) => setWastePercentage(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="density">
                    Wood Density ({unitSystem === "metric" ? "kg/m³" : "lb/ft³"}) - Optional
                  </Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder={unitSystem === "metric" ? "e.g. 700" : "e.g. 44"}
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Decking
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Boards Needed</p>
                      <p className="text-5xl font-bold text-amber-600 mb-1">{result.totalBoardsWithWaste}</p>
                      <p className="text-sm text-muted-foreground">boards (including {wastePercentage}% waste)</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Deck Area</p>
                        <p className="font-semibold">
                          {result.deckArea.toFixed(2)} m²
                          <span className="text-xs text-muted-foreground ml-1">
                            ({(result.deckArea * 10.764).toFixed(2)} ft²)
                          </span>
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Boards (no waste)</p>
                        <p className="font-semibold">{result.totalBoards} boards</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Boards per Row</p>
                        <p className="font-semibold">{result.boardsPerRow}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Rows Needed</p>
                        <p className="font-semibold">{result.rowsNeeded}</p>
                      </div>
                    </div>

                    {(result.deckingVolume || result.deckingWeight) && (
                      <div className="grid grid-cols-2 gap-3 mt-3">
                        {result.deckingVolume && (
                          <div className="p-3 bg-white rounded-lg border">
                            <p className="text-xs text-muted-foreground">Total Volume</p>
                            <p className="font-semibold">
                              {result.deckingVolume.toFixed(4)} m³
                              <span className="text-xs text-muted-foreground ml-1">
                                ({(result.deckingVolume * 35.315).toFixed(3)} ft³)
                              </span>
                            </p>
                          </div>
                        )}
                        {result.deckingWeight && (
                          <div className="p-3 bg-white rounded-lg border">
                            <p className="text-xs text-muted-foreground">Total Weight</p>
                            <p className="font-semibold">
                              {result.deckingWeight.toFixed(1)} kg
                              <span className="text-xs text-muted-foreground ml-1">
                                ({(result.deckingWeight * 2.205).toFixed(1)} lb)
                              </span>
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-between w-full mt-4 p-3 bg-white rounded-lg border hover:bg-gray-50 transition-colors"
                    >
                      <span className="text-sm font-medium">Calculation Breakdown</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg border text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Calculate deck area
                        </p>
                        <p className="text-muted-foreground pl-4">
                          Area = {deckLength} × {deckWidth} × {numberOfDecks} = {result.deckArea.toFixed(2)}{" "}
                          {unitSystem === "metric" ? "m²" : "ft²"}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Calculate effective board width
                        </p>
                        <p className="text-muted-foreground pl-4">
                          Effective Width = {boardWidth} + {boardGap} ={" "}
                          {(Number.parseFloat(boardWidth) + Number.parseFloat(boardGap)).toFixed(1)}{" "}
                          {unitSystem === "metric" ? "mm" : "in"}
                        </p>
                        <p>
                          <strong>Step 3:</strong> Calculate boards per row
                        </p>
                        <p className="text-muted-foreground pl-4">
                          Boards/Row = Deck Width ÷ Effective Board Width = {result.boardsPerRow} boards
                        </p>
                        <p>
                          <strong>Step 4:</strong> Calculate rows needed
                        </p>
                        <p className="text-muted-foreground pl-4">
                          Rows = Deck Length ÷ Board Length = {result.rowsNeeded} rows
                        </p>
                        <p>
                          <strong>Step 5:</strong> Calculate total boards
                        </p>
                        <p className="text-muted-foreground pl-4">
                          Total = {result.boardsPerRow} × {result.rowsNeeded} × {numberOfDecks} = {result.totalBoards}{" "}
                          boards
                        </p>
                        <p>
                          <strong>Step 6:</strong> Add waste allowance
                        </p>
                        <p className="text-muted-foreground pl-4">
                          With Waste = {result.totalBoards} × (1 + {wastePercentage}%) = {result.totalBoardsWithWaste}{" "}
                          boards
                        </p>
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Board Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Standard Deck Board</span>
                      <span className="font-medium">140mm × 25mm × 2.4m</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Wide Deck Board</span>
                      <span className="font-medium">190mm × 32mm × 3.6m</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Composite Board</span>
                      <span className="font-medium">150mm × 25mm × 3.0m</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>US 5/4 × 6</span>
                      <span className="font-medium">5.5" × 1" × 8ft</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recommended Waste %</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-green-50 border border-green-200 rounded">
                      <span className="text-green-700">Straight Layout</span>
                      <span className="font-medium text-green-600">5-10%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-yellow-50 border border-yellow-200 rounded">
                      <span className="text-yellow-700">Diagonal Layout</span>
                      <span className="font-medium text-yellow-600">10-15%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-orange-50 border border-orange-200 rounded">
                      <span className="text-orange-700">Complex/Herringbone</span>
                      <span className="font-medium text-orange-600">15-20%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Wood Densities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Pressure-Treated Pine</span>
                      <span className="font-medium">550-700 kg/m³</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Cedar</span>
                      <span className="font-medium">350-450 kg/m³</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Redwood</span>
                      <span className="font-medium">400-500 kg/m³</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Ipe (Brazilian Hardwood)</span>
                      <span className="font-medium">1,000-1,100 kg/m³</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Composite Decking</span>
                      <span className="font-medium">800-1,200 kg/m³</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex gap-3">
              <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-yellow-800">
                <p className="font-medium mb-1">Disclaimer</p>
                <p>
                  Results are estimates. Actual decking requirements may vary due to cuts, spacing adjustments, board
                  defects, and site conditions. Always order extra material to account for waste and mistakes.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Decking Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating decking materials accurately is essential for any deck project, whether you're building a
                  small backyard patio or a large multi-level outdoor living space. Proper estimation ensures you
                  purchase enough materials without excessive waste, saving both money and time on your project.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key to accurate decking calculations lies in understanding the relationship between your deck
                  dimensions and board sizes. You need to account for board width, length, and the spacing gaps between
                  boards that allow for drainage and wood expansion. Most decking installations require a 5-8mm
                  (3/16"-1/4") gap between boards.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Decking Material Types</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Pressure-Treated Wood</h4>
                    <p className="text-amber-700 text-sm">
                      The most economical option, pressure-treated pine is chemically treated to resist rot and insects.
                      It requires regular maintenance including staining or sealing every 1-2 years. Typical lifespan is
                      15-20 years with proper care.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Cedar & Redwood</h4>
                    <p className="text-orange-700 text-sm">
                      Natural woods that contain oils resistant to decay and insects. More expensive than treated lumber
                      but offer beautiful natural color and grain. Cedar is lighter weight while redwood is known for
                      exceptional durability. Both weather to a silver-gray if left untreated.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Composite Decking</h4>
                    <p className="text-purple-700 text-sm">
                      Made from a mixture of wood fibers and plastic polymers. Requires minimal maintenance, resists
                      rot, insects, and fading. Higher initial cost but lower long-term maintenance expenses. Available
                      in many colors and textures that mimic natural wood.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Tropical Hardwoods (Ipe, Tigerwood)</h4>
                    <p className="text-green-700 text-sm">
                      Extremely dense and durable exotic woods that can last 40+ years. Naturally resistant to rot,
                      insects, and fire. Very heavy and harder to work with. The most expensive option but offers
                      unmatched beauty and longevity.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-3">
                  <li>
                    <strong>Measure twice, order once:</strong> Double-check all measurements before ordering materials.
                    It's much easier to verify dimensions than to return or re-order materials.
                  </li>
                  <li>
                    <strong>Account for joist spacing:</strong> Standard joist spacing is 16" on center for most
                    decking, but some materials require 12" spacing. Check manufacturer specifications.
                  </li>
                  <li>
                    <strong>Consider board direction:</strong> Boards running parallel to the house may require
                    different quantities than those running perpendicular. Plan your layout before ordering.
                  </li>
                  <li>
                    <strong>Factor in stairs and railings:</strong> Don't forget to calculate materials for stairs,
                    risers, and any railing components if they use the same decking material.
                  </li>
                  <li>
                    <strong>Buy from the same lot:</strong> Wood color and grain can vary between production batches.
                    Order all your decking at once to ensure consistent appearance.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
