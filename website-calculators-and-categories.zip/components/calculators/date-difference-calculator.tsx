"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calendar,
  Info,
  Clock,
  ChevronDown,
  ChevronUp,
  ArrowRightLeft,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface DateDifferenceResult {
  years: number
  months: number
  days: number
  totalDays: number
  totalWeeks: number
  totalMonths: number
  totalHours: number
  totalMinutes: number
  totalSeconds: number
  workingDays: number
  weekendDays: number
}

export function DateDifferenceCalculator() {
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [includeTime, setIncludeTime] = useState(false)
  const [startTime, setStartTime] = useState("00:00")
  const [endTime, setEndTime] = useState("00:00")
  const [includeEndDate, setIncludeEndDate] = useState(false)
  const [result, setResult] = useState<DateDifferenceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const isLeapYear = (year: number): boolean => {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0
  }

  const getDaysInMonth = (year: number, month: number): number => {
    const daysInMonths = [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return daysInMonths[month]
  }

  const calculateWorkingDays = (start: Date, end: Date): { working: number; weekend: number } => {
    let workingDays = 0
    let weekendDays = 0
    const current = new Date(start)

    while (current <= end) {
      const dayOfWeek = current.getDay()
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        weekendDays++
      } else {
        workingDays++
      }
      current.setDate(current.getDate() + 1)
    }

    return { working: workingDays, weekend: weekendDays }
  }

  const calculateDateDifference = () => {
    setError("")
    setResult(null)

    if (!startDate || !endDate) {
      setError("Please select both start and end dates")
      return
    }

    let start = new Date(startDate)
    let end = new Date(endDate)

    if (includeTime) {
      const [startHours, startMinutes] = startTime.split(":").map(Number)
      const [endHours, endMinutes] = endTime.split(":").map(Number)
      start.setHours(startHours, startMinutes, 0, 0)
      end.setHours(endHours, endMinutes, 0, 0)
    }

    if (start > end) {
      // Swap dates if start is after end
      const temp = start
      start = end
      end = temp
    }

    // Include end date if selected
    const adjustedEnd = includeEndDate ? new Date(end.getTime() + 24 * 60 * 60 * 1000) : end

    // Calculate exact difference in years, months, days
    let years = end.getFullYear() - start.getFullYear()
    let months = end.getMonth() - start.getMonth()
    let days = end.getDate() - start.getDate()

    if (includeEndDate) {
      days += 1
    }

    if (days < 0) {
      months--
      const prevMonth = end.getMonth() === 0 ? 11 : end.getMonth() - 1
      const prevMonthYear = end.getMonth() === 0 ? end.getFullYear() - 1 : end.getFullYear()
      days += getDaysInMonth(prevMonthYear, prevMonth)
    }

    if (months < 0) {
      years--
      months += 12
    }

    // Calculate total differences
    const diffMs = adjustedEnd.getTime() - start.getTime()
    const totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const totalWeeks = Math.floor(totalDays / 7)
    const totalMonths = years * 12 + months
    const totalHours = Math.floor(diffMs / (1000 * 60 * 60))
    const totalMinutes = Math.floor(diffMs / (1000 * 60))
    const totalSeconds = Math.floor(diffMs / 1000)

    // Calculate working days
    const { working, weekend } = calculateWorkingDays(start, includeEndDate ? adjustedEnd : end)

    setResult({
      years,
      months,
      days,
      totalDays,
      totalWeeks,
      totalMonths,
      totalHours,
      totalMinutes,
      totalSeconds,
      workingDays: working,
      weekendDays: weekend,
    })
  }

  const handleReset = () => {
    setStartDate("")
    setEndDate("")
    setStartTime("00:00")
    setEndTime("00:00")
    setIncludeTime(false)
    setIncludeEndDate(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleSwapDates = () => {
    const tempDate = startDate
    const tempTime = startTime
    setStartDate(endDate)
    setEndDate(tempDate)
    setStartTime(endTime)
    setEndTime(tempTime)
    setResult(null)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Date Difference: ${result.years} years, ${result.months} months, ${result.days} days (${result.totalDays} total days)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Date Difference Result",
          text: `Date Difference: ${result.years} years, ${result.months} months, ${result.days} days (${result.totalDays} total days)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    return num.toLocaleString()
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Date Difference Calculator</CardTitle>
                    <CardDescription>Calculate the difference between two dates</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Start Date */}
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input id="startDate" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                </div>

                {/* End Date */}
                <div className="space-y-2">
                  <Label htmlFor="endDate">End Date</Label>
                  <Input id="endDate" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                </div>

                {/* Swap Dates Button */}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSwapDates}
                  className="w-full bg-transparent"
                  disabled={!startDate && !endDate}
                >
                  <ArrowRightLeft className="h-4 w-4 mr-2" />
                  Swap Dates
                </Button>

                {/* Include Time Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <Label htmlFor="includeTime" className="cursor-pointer">
                      Include Time
                    </Label>
                  </div>
                  <Switch id="includeTime" checked={includeTime} onCheckedChange={setIncludeTime} />
                </div>

                {/* Time Inputs */}
                {includeTime && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="startTime">Start Time</Label>
                      <Input
                        id="startTime"
                        type="time"
                        value={startTime}
                        onChange={(e) => setStartTime(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="endTime">End Time</Label>
                      <Input id="endTime" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
                    </div>
                  </div>
                )}

                {/* Include End Date Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <Label htmlFor="includeEndDate" className="cursor-pointer">
                    Count End Date
                  </Label>
                  <Switch id="includeEndDate" checked={includeEndDate} onCheckedChange={setIncludeEndDate} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDateDifference} className="w-full" size="lg">
                  Calculate Difference
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Date Difference</p>
                      <p className="text-3xl font-bold text-cyan-600">
                        {result.years > 0 && `${result.years} ${result.years === 1 ? "year" : "years"}`}
                        {result.years > 0 && (result.months > 0 || result.days > 0) && ", "}
                        {result.months > 0 && `${result.months} ${result.months === 1 ? "month" : "months"}`}
                        {result.months > 0 && result.days > 0 && ", "}
                        {result.days > 0 && `${result.days} ${result.days === 1 ? "day" : "days"}`}
                        {result.years === 0 && result.months === 0 && result.days === 0 && "Same day"}
                      </p>
                      <p className="text-sm text-cyan-700 mt-1">{formatNumber(result.totalDays)} total days</p>
                    </div>

                    {/* Expandable Breakdown */}
                    <button
                      onClick={() => setShowBreakdown(!showBreakdown)}
                      className="w-full flex items-center justify-center gap-2 text-sm text-cyan-700 hover:text-cyan-800 transition-colors"
                    >
                      {showBreakdown ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Breakdown
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Full Breakdown
                        </>
                      )}
                    </button>

                    {showBreakdown && (
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="grid grid-cols-2 gap-2">
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Total Weeks</p>
                            <p className="font-semibold">{formatNumber(result.totalWeeks)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Total Months</p>
                            <p className="font-semibold">{formatNumber(result.totalMonths)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Total Hours</p>
                            <p className="font-semibold">{formatNumber(result.totalHours)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Total Minutes</p>
                            <p className="font-semibold">{formatNumber(result.totalMinutes)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Working Days</p>
                            <p className="font-semibold text-green-600">{formatNumber(result.workingDays)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Weekend Days</p>
                            <p className="font-semibold text-orange-600">{formatNumber(result.weekendDays)}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">1 Week</span>
                      <span className="text-sm text-cyan-600">7 days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">1 Month (avg)</span>
                      <span className="text-sm text-blue-600">30.44 days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">1 Year</span>
                      <span className="text-sm text-purple-600">365 days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">1 Leap Year</span>
                      <span className="text-sm text-green-600">366 days</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Options Explained</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Include Time</p>
                    <p>Enable for more precise calculations when exact hours and minutes matter.</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Count End Date</p>
                    <p>Include the end date in the count (useful for inclusive date ranges like events).</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Working Days</p>
                    <p>Automatically excludes weekends (Saturday and Sunday) from the count.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Date Differences</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating the difference between two dates might seem straightforward, but it involves several
                  considerations that can affect the result. The most common way to express a date difference is in
                  years, months, and days, but this can be ambiguous since months have varying lengths (28-31 days). Our
                  calculator handles these variations by accounting for the actual number of days in each month,
                  including leap years.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The total number of days provides an unambiguous measure of time elapsed. From this, we can derive
                  other useful units like weeks, hours, and minutes. The working days calculation is particularly useful
                  for business planning, project management, and payroll calculations, as it excludes weekends from the
                  count.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Leap Years and Calendar Rules</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Leap years occur every 4 years with some exceptions: years divisible by 100 are not leap years unless
                  they are also divisible by 400. This rule keeps our calendar aligned with the Earth's orbit around the
                  sun. For example, 2000 was a leap year (divisible by 400), but 1900 was not (divisible by 100 but not
                  400).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Our calculator automatically accounts for leap years when calculating date differences, ensuring
                  February has 29 days in leap years and 28 days in regular years. This precision is essential for
                  accurate age calculations, contract durations, and historical date research.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4 mt-2">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Project Management</h4>
                    <p className="text-sm text-muted-foreground">
                      Calculate project durations, deadline tracking, and sprint planning with working day counts.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Legal & Contracts</h4>
                    <p className="text-sm text-muted-foreground">
                      Determine contract periods, notice periods, and statute of limitations calculations.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Event Planning</h4>
                    <p className="text-sm text-muted-foreground">
                      Count down to events, calculate event durations, and plan schedules effectively.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Personal Milestones</h4>
                    <p className="text-sm text-muted-foreground">
                      Track anniversaries, relationship durations, sobriety dates, and other personal milestones.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-cyan-200 bg-cyan-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground">
                  <strong>Note:</strong> Date difference calculations depend on calendar rules and may vary slightly due
                  to leap years and time zone settings. Working day calculations exclude weekends (Saturday and Sunday)
                  but do not account for public holidays, which vary by location.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
