"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Droplets, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface HardnessResult {
  totalHardness: number
  caContribution: number
  mgContribution: number
  classification: string
  color: string
  bgColor: string
  unit: string
}

export function WaterHardnessCalculator() {
  const [calcium, setCalcium] = useState("")
  const [magnesium, setMagnesium] = useState("")
  const [unit, setUnit] = useState<string>("mg/L")
  const [result, setResult] = useState<HardnessResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateHardness = () => {
    setError("")
    setResult(null)

    const ca = Number.parseFloat(calcium)
    const mg = Number.parseFloat(magnesium)

    // Validate inputs
    if (calcium === "" || magnesium === "") {
      setError("Please enter both Ca²⁺ and Mg²⁺ concentrations")
      return
    }

    if (isNaN(ca) || ca < 0) {
      setError("Ca²⁺ concentration must be a non-negative number")
      return
    }

    if (isNaN(mg) || mg < 0) {
      setError("Mg²⁺ concentration must be a non-negative number")
      return
    }

    // Calculate total hardness as CaCO₃
    // Total Hardness = (Ca²⁺ × 2.5) + (Mg²⁺ × 4.1)
    const caContribution = ca * 2.5
    const mgContribution = mg * 4.1
    let totalHardnessMgL = caContribution + mgContribution

    // Convert to selected unit
    let displayHardness = totalHardnessMgL
    let displayUnit = "mg/L CaCO₃"

    if (unit === "ppm") {
      displayHardness = totalHardnessMgL // Same as mg/L
      displayUnit = "ppm CaCO₃"
    } else if (unit === "°dH") {
      displayHardness = totalHardnessMgL / 17.848 // German degrees
      displayUnit = "°dH"
    } else if (unit === "meq/L") {
      displayHardness = totalHardnessMgL / 50 // milliequivalents per liter
      displayUnit = "meq/L"
    }

    // Classify water hardness (based on mg/L CaCO₃)
    let classification: string
    let color: string
    let bgColor: string

    if (totalHardnessMgL < 60) {
      classification = "Soft"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (totalHardnessMgL < 120) {
      classification = "Moderately Hard"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (totalHardnessMgL < 180) {
      classification = "Hard"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      classification = "Very Hard"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      totalHardness: displayHardness,
      caContribution,
      mgContribution,
      classification,
      color,
      bgColor,
      unit: displayUnit,
    })
  }

  const handleReset = () => {
    setCalcium("")
    setMagnesium("")
    setUnit("mg/L")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Water Hardness: ${formatNumber(result.totalHardness)} ${result.unit} (${result.classification}). Ca²⁺ Contribution: ${formatNumber(result.caContribution)} mg/L CaCO₃, Mg²⁺ Contribution: ${formatNumber(result.mgContribution)} mg/L CaCO₃`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Water Hardness Calculation",
          text: `I calculated water hardness using CalcHub! Hardness: ${formatNumber(result.totalHardness)} ${result.unit} (${result.classification})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num === 0) return "0"
    if (num < 0.01 || num >= 10000) {
      return num.toExponential(2)
    }
    return num.toFixed(2).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Water Hardness Calculator</CardTitle>
                    <CardDescription>Calculate total hardness based on Ca²⁺ and Mg²⁺</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Ion Concentrations */}
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="calcium" className="text-sm">
                      Ca²⁺ Concentration (mg/L or ppm)
                    </Label>
                    <Input
                      id="calcium"
                      type="number"
                      placeholder="e.g., 40"
                      value={calcium}
                      onChange={(e) => setCalcium(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="magnesium" className="text-sm">
                      Mg²⁺ Concentration (mg/L or ppm)
                    </Label>
                    <Input
                      id="magnesium"
                      type="number"
                      placeholder="e.g., 10"
                      value={magnesium}
                      onChange={(e) => setMagnesium(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Unit Selection */}
                <div>
                  <Label className="text-sm">Hardness Unit</Label>
                  <Select value={unit} onValueChange={setUnit}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mg/L">mg/L CaCO₃</SelectItem>
                      <SelectItem value="ppm">ppm CaCO₃</SelectItem>
                      <SelectItem value="°dH">°dH (German degrees)</SelectItem>
                      <SelectItem value="meq/L">meq/L</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateHardness} className="w-full" size="lg">
                  Calculate Hardness
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Water Hardness</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{formatNumber(result.totalHardness)}</p>
                      <p className="text-sm text-muted-foreground mb-2">{result.unit}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.classification}</p>
                    </div>

                    {/* Contributions Breakdown */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg">
                      <p className="text-sm font-medium mb-2 text-center">Hardness Contributions</p>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-muted-foreground">Ca²⁺ Contribution:</span>
                          <span className="font-mono font-medium">
                            {formatNumber(result.caContribution)} mg/L CaCO₃
                          </span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-muted-foreground">Mg²⁺ Contribution:</span>
                          <span className="font-mono font-medium">
                            {formatNumber(result.mgContribution)} mg/L CaCO₃
                          </span>
                        </div>
                        <div className="pt-2 border-t border-gray-200">
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-muted-foreground">Ca²⁺ Percentage:</span>
                            <span className="font-mono font-medium">
                              {((result.caContribution / (result.caContribution + result.mgContribution)) * 100).toFixed(1)}%
                            </span>
                          </div>
                          <div className="flex justify-between items-center text-sm mt-1">
                            <span className="text-muted-foreground">Mg²⁺ Percentage:</span>
                            <span className="font-mono font-medium">
                              {((result.mgContribution / (result.caContribution + result.mgContribution)) * 100).toFixed(1)}%
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Hardness Classification</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Soft</span>
                      <span className="text-sm text-blue-600">{"< 60 mg/L"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Moderately Hard</span>
                      <span className="text-sm text-green-600">60 – 120 mg/L</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Hard</span>
                      <span className="text-sm text-yellow-600">120 – 180 mg/L</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very Hard</span>
                      <span className="text-sm text-red-600">≥ 180 mg/L</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Hardness Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-1">
                    <p className="font-semibold text-foreground">Total Hardness =</p>
                    <p className="font-semibold text-foreground">(Ca²⁺ × 2.5) + (Mg²⁺ × 4.1)</p>
                  </div>
                  <p>
                    Where <strong>Ca²⁺</strong> and <strong>Mg²⁺</strong> concentrations are in mg/L. The result is
                    expressed as mg/L CaCO₃ equivalent.
                  </p>
                  <p className="text-xs">
                    Conversion factors: 2.5 for Ca²⁺ and 4.1 for Mg²⁺ convert ion concentrations to CaCO₃ equivalents.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 mg/L CaCO₃</span>
                      <span className="font-mono">= 1 ppm</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 °dH</span>
                      <span className="font-mono">= 17.848 mg/L</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1 meq/L</span>
                      <span className="font-mono">= 50 mg/L</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Water Hardness */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Water Hardness?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Water hardness is a measure of the concentration of calcium (Ca²⁺) and magnesium (Mg²⁺) ions in water.
                  Hard water contains high levels of these dissolved minerals, which are picked up as water flows through
                  limestone and chalk deposits. Water hardness is typically expressed as calcium carbonate (CaCO₃)
                  equivalent, allowing different ions to be compared on a common scale.
                </p>
              </CardContent>
            </Card>

            {/* How It Works */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>How the Calculator Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4 text-muted-foreground">
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Step 1: Input Ion Concentrations</h3>
                    <p className="leading-relaxed">
                      Enter the concentrations of calcium (Ca²⁺) and magnesium (Mg²⁺) ions in mg/L or ppm. These values
                      are typically obtained from water quality test reports.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Step 2: Calculate Contributions</h3>
                    <p className="leading-relaxed">
                      The calculator multiplies Ca²⁺ by 2.5 and Mg²⁺ by 4.1 to convert them to CaCO₃ equivalents. These
                      factors account for the different atomic weights and charges of the ions.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Step 3: Total and Classify</h3>
                    <p className="leading-relaxed">
                      The individual contributions are summed to get total hardness, which is then classified as soft,
                      moderately hard, hard, or very hard based on standard water quality guidelines.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Effects of Hard Water */}
            <Card>
              <CardHeader>
                <CardTitle>Effects of Hard Water</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                    <h3 className="font-semibold text-red-700 mb-2">Challenges</h3>
                    <ul className="space-y-2 text-sm text-red-600">
                      <li>• Scale buildup in pipes and appliances</li>
                      <li>• Reduced soap and detergent effectiveness</li>
                      <li>• Spotted dishes and glassware</li>
                      <li>• Dry skin and dull hair after washing</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <h3 className="font-semibold text-green-700 mb-2">Benefits</h3>
                    <ul className="space-y-2 text-sm text-green-600">
                      <li>• Essential minerals for health</li>
                      <li>• Better taste than soft water</li>
                      <li>• Protective scale in metal pipes</li>
                      <li>• Natural buffering capacity</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <CardTitle>Common Questions</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-foreground text-base">What causes water hardness?</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mt-1">
                      Water hardness is caused by dissolved calcium and magnesium salts, primarily from limestone, chalk,
                      and dolomite rock formations. As water percolates through these geological formations, it dissolves
                      these minerals.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-base">How can I soften hard water?</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mt-1">
                      Water can be softened using ion exchange systems (water softeners), reverse osmosis, or chemical
                      treatment with washing soda. For drinking water, boiling can remove temporary hardness caused by
                      bicarbonates.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-base">Is hard water safe to drink?</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mt-1">
                      Yes, hard water is generally safe to drink and provides beneficial minerals like calcium and
                      magnesium. However, very hard water may have an unpleasant taste and can cause scale buildup in
                      plumbing systems.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-base">What is the ideal water hardness?</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mt-1">
                      For household use, water with hardness between 60-120 mg/L (moderately hard) is often considered
                      ideal. It provides beneficial minerals without causing excessive scale buildup.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-900">Important Note</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-amber-800 leading-relaxed">
                  Calculations assume all hardness is due to Ca²⁺ and Mg²⁺. Other ions (such as iron, manganese, or
                  strontium) or impurities may affect actual water hardness. For precise water quality assessment, consult
                  a certified water testing laboratory.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
