"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calculator, Info, AlertTriangle, Hash } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

interface SequenceResult {
  firstTerm: number
  commonDifference: number
  termNumber: number
  nthTerm: number
  sum: number
  sequence: number[]
  steps: string[]
}

export function ArithmeticSequenceCalculator() {
  const [firstTerm, setFirstTerm] = useState("")
  const [commonDifference, setCommonDifference] = useState("")
  const [termNumber, setTermNumber] = useState("")
  const [showSteps, setShowSteps] = useState(true)
  const [showSequence, setShowSequence] = useState(true)
  const [result, setResult] = useState<SequenceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)

  const calculateSequence = () => {
    setError("")
    setResult(null)

    const a1 = Number.parseFloat(firstTerm)
    const d = Number.parseFloat(commonDifference)
    const n = Number.parseInt(termNumber)

    if (isNaN(a1)) {
      setError("Please enter a valid first term")
      return
    }

    if (isNaN(d)) {
      setError("Please enter a valid common difference")
      return
    }

    if (isNaN(n) || n <= 0 || !Number.isInteger(n)) {
      setError("Term number must be a positive integer")
      return
    }

    if (n > 1000) {
      setError("Term number cannot exceed 1000")
      return
    }

    // Calculate n-th term: aₙ = a₁ + (n − 1) × d
    const nthTerm = a1 + (n - 1) * d

    // Calculate sum: Sₙ = n/2 × (2a₁ + (n − 1)d)
    const sum = (n / 2) * (2 * a1 + (n - 1) * d)

    // Generate sequence (limit to 50 terms for display)
    const displayTerms = Math.min(n, 50)
    const sequence: number[] = []
    for (let i = 0; i < displayTerms; i++) {
      sequence.push(a1 + i * d)
    }

    // Generate steps
    const steps: string[] = [
      `Given: First term (a₁) = ${a1}, Common difference (d) = ${d}, Term number (n) = ${n}`,
      ``,
      `Step 1: Calculate the n-th term using aₙ = a₁ + (n − 1) × d`,
      `a${n} = ${a1} + (${n} − 1) × ${d}`,
      `a${n} = ${a1} + ${n - 1} × ${d}`,
      `a${n} = ${a1} + ${(n - 1) * d}`,
      `a${n} = ${nthTerm}`,
      ``,
      `Step 2: Calculate the sum using Sₙ = n/2 × (2a₁ + (n − 1)d)`,
      `S${n} = ${n}/2 × (2 × ${a1} + (${n} − 1) × ${d})`,
      `S${n} = ${n / 2} × (${2 * a1} + ${(n - 1) * d})`,
      `S${n} = ${n / 2} × ${2 * a1 + (n - 1) * d}`,
      `S${n} = ${sum}`,
    ]

    setResult({
      firstTerm: a1,
      commonDifference: d,
      termNumber: n,
      nthTerm,
      sum,
      sequence,
      steps,
    })
  }

  const handleReset = () => {
    setFirstTerm("")
    setCommonDifference("")
    setTermNumber("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Arithmetic Sequence:\nFirst term (a₁) = ${result.firstTerm}\nCommon difference (d) = ${result.commonDifference}\nTerm ${result.termNumber} (a${result.termNumber}) = ${result.nthTerm}\nSum of ${result.termNumber} terms (S${result.termNumber}) = ${result.sum}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      const latex = `a_{${result.termNumber}} = ${result.firstTerm} + (${result.termNumber} - 1) \\times ${result.commonDifference} = ${result.nthTerm}\n\nS_{${result.termNumber}} = \\frac{${result.termNumber}}{2} \\times (2 \\times ${result.firstTerm} + (${result.termNumber} - 1) \\times ${result.commonDifference}) = ${result.sum}`
      await navigator.clipboard.writeText(latex)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Arithmetic Sequence Result",
          text: `Arithmetic Sequence: a₁=${result.firstTerm}, d=${result.commonDifference}, a${result.termNumber}=${result.nthTerm}, S${result.termNumber}=${result.sum}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Number.isInteger(num)) {
      return num.toLocaleString()
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 6 })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Hash className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Arithmetic Sequence Calculator</CardTitle>
                    <CardDescription>Calculate terms, sums, and properties</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* First Term Input */}
                <div className="space-y-2">
                  <Label htmlFor="firstTerm">First Term (a₁)</Label>
                  <Input
                    id="firstTerm"
                    type="number"
                    placeholder="Enter first term (e.g., 2)"
                    value={firstTerm}
                    onChange={(e) => setFirstTerm(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Common Difference Input */}
                <div className="space-y-2">
                  <Label htmlFor="commonDifference">Common Difference (d)</Label>
                  <Input
                    id="commonDifference"
                    type="number"
                    placeholder="Enter common difference (e.g., 3)"
                    value={commonDifference}
                    onChange={(e) => setCommonDifference(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Term Number Input */}
                <div className="space-y-2">
                  <Label htmlFor="termNumber">Term Number (n)</Label>
                  <Input
                    id="termNumber"
                    type="number"
                    placeholder="Enter term number (e.g., 10)"
                    value={termNumber}
                    onChange={(e) => setTermNumber(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Options */}
                <div className="flex flex-col sm:flex-row gap-4 pt-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                    <Label htmlFor="showSteps" className="text-sm">
                      Show steps
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="showSequence" checked={showSequence} onCheckedChange={setShowSequence} />
                    <Label htmlFor="showSequence" className="text-sm">
                      Show sequence
                    </Label>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSequence} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300 space-y-4">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">n-th Term (a{result.termNumber})</p>
                      <p className="text-4xl font-bold text-blue-600 mb-2">{formatNumber(result.nthTerm)}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-white/80 p-3 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Sum (S{result.termNumber})</p>
                        <p className="text-lg font-semibold text-blue-700">{formatNumber(result.sum)}</p>
                      </div>
                      <div className="bg-white/80 p-3 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Terms</p>
                        <p className="text-lg font-semibold text-blue-700">{result.termNumber}</p>
                      </div>
                    </div>

                    {/* Sequence Display */}
                    {showSequence && (
                      <Collapsible open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" className="w-full justify-between p-2 h-auto">
                            <span className="text-sm font-medium">Sequence List</span>
                            <ChevronDown
                              className={`h-4 w-4 transition-transform ${isDetailsOpen ? "rotate-180" : ""}`}
                            />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="bg-white/80 p-3 rounded-lg mt-2">
                            <p className="text-sm font-mono break-all">
                              {result.sequence.map((t, i) => formatNumber(t)).join(", ")}
                              {result.termNumber > 50 && ", ..."}
                            </p>
                            {result.termNumber > 50 && (
                              <p className="text-xs text-muted-foreground mt-1">
                                (Showing first 50 of {result.termNumber} terms)
                              </p>
                            )}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Step-by-step */}
                    {showSteps && (
                      <div className="bg-white/80 p-3 rounded-lg">
                        <p className="text-sm font-semibold mb-2">Step-by-Step Solution</p>
                        <div className="text-xs font-mono space-y-1">
                          {result.steps.map((step, i) => (
                            <p key={i} className={step === "" ? "h-2" : ""}>
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-semibold mb-2">n-th Term Formula</p>
                    <p className="font-mono text-center text-lg">aₙ = a₁ + (n − 1) × d</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm font-semibold mb-2">Sum of n Terms</p>
                    <p className="font-mono text-center text-lg">Sₙ = n/2 × (2a₁ + (n − 1)d)</p>
                    <p className="font-mono text-center text-sm text-muted-foreground mt-1">or Sₙ = n/2 × (a₁ + aₙ)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Variables</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">a₁</span>
                      <span className="text-muted-foreground">First term</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">d</span>
                      <span className="text-muted-foreground">Common difference</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">n</span>
                      <span className="text-muted-foreground">Term number / count</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">aₙ</span>
                      <span className="text-muted-foreground">n-th term value</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">Sₙ</span>
                      <span className="text-muted-foreground">Sum of first n terms</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-medium text-foreground">2, 5, 8, 11, 14, ...</p>
                    <p>a₁ = 2, d = 3</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-medium text-foreground">10, 7, 4, 1, -2, ...</p>
                    <p>a₁ = 10, d = -3</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="font-medium text-foreground">1, 1.5, 2, 2.5, 3, ...</p>
                    <p>a₁ = 1, d = 0.5</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an Arithmetic Sequence?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An arithmetic sequence (also called an arithmetic progression) is a sequence of numbers in which the
                  difference between any two consecutive terms is constant. This constant difference is called the
                  "common difference" and is denoted by 'd'. For example, in the sequence 2, 5, 8, 11, 14, each term is
                  obtained by adding 3 to the previous term, so d = 3.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Arithmetic sequences appear frequently in real-world situations, such as calculating monthly savings
                  with fixed deposits, counting seats in a theater where each row has more seats than the previous one,
                  or determining the total distance traveled when speed increases at a constant rate.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To use this calculator, enter the first term of your sequence, the common difference (which can be
                  positive, negative, or a decimal), and the term number you want to find. The calculator will compute
                  the n-th term using the formula aₙ = a₁ + (n − 1) × d, and the sum of the first n terms using Sₙ = n/2
                  × (2a₁ + (n − 1)d).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Toggle the options to show step-by-step calculations and the sequence list. You can copy the results
                  in plain text or LaTeX format for use in documents, homework, or presentations.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">
                    Arithmetic sequence calculations follow standard mathematical formulas. Results depend on correct
                    input values and assumptions. This calculator is intended for educational purposes and should be
                    verified for critical applications.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
