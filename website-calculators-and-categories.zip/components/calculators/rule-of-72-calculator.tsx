"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calculator, Info, TrendingUp, Target } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"
import { formatCurrency, currencySymbols, type Currency } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

interface Rule72Result {
  yearsToDouble: number
  futureValue: number
  targetMultiple: number
  effectiveRate: number
  growthSchedule: { year: number; value: number; multiple: number }[]
}

export function RuleOf72Calculator() {
  const [interestRate, setInterestRate] = useState("")
  const [initialInvestment, setInitialInvestment] = useState("")
  const [targetMultiple, setTargetMultiple] = useState("2")
  const [currency, setCurrency] = useState<Currency>("USD")
  const [result, setResult] = useState<Rule72Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSchedule, setShowSchedule] = useState(false)

  const calculateRule72 = () => {
    setError("")
    setResult(null)

    const rate = Number.parseFloat(interestRate)
    if (isNaN(rate) || rate <= 0 || rate > 100) {
      setError("Please enter a valid interest rate between 0 and 100%")
      return
    }

    const multiple = Number.parseFloat(targetMultiple) || 2
    if (multiple <= 1) {
      setError("Target multiple must be greater than 1")
      return
    }

    const initial = Number.parseFloat(initialInvestment) || 0

    // Rule of 72 calculation
    // For doubling: Time = 72 / rate
    // For other multiples: Time = (72 * log(multiple)) / (log(2) * rate)
    let yearsToDouble: number
    if (multiple === 2) {
      yearsToDouble = 72 / rate
    } else {
      yearsToDouble = (72 * Math.log(multiple)) / (Math.log(2) * rate)
    }

    // Calculate future value if initial investment provided
    const futureValue = initial > 0 ? initial * multiple : 0

    // Generate growth schedule
    const growthSchedule: { year: number; value: number; multiple: number }[] = []
    if (initial > 0) {
      const yearsToShow = Math.ceil(yearsToDouble) + 5
      for (let year = 0; year <= yearsToShow; year++) {
        const value = initial * Math.pow(1 + rate / 100, year)
        const currentMultiple = value / initial
        growthSchedule.push({
          year,
          value,
          multiple: currentMultiple,
        })
      }
    }

    setResult({
      yearsToDouble: Math.round(yearsToDouble * 10) / 10,
      futureValue,
      targetMultiple: multiple,
      effectiveRate: rate,
      growthSchedule,
    })
  }

  const handleReset = () => {
    setInterestRate("")
    setInitialInvestment("")
    setTargetMultiple("2")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSchedule(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Rule of 72 Result: At ${result.effectiveRate}% annual return, your investment will ${result.targetMultiple}x in approximately ${result.yearsToDouble} years.`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Rule of 72 Calculator Result",
          text: `At ${result.effectiveRate}% annual return, my investment will ${result.targetMultiple}x in approximately ${result.yearsToDouble} years!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Rule of 72 Calculator</CardTitle>
                    <CardDescription>Estimate time to double your investment</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Interest Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Enter expected annual return"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0.1"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Initial Investment (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="initialInvestment">
                    Initial Investment ({currencySymbols[currency]}){" "}
                    <span className="text-muted-foreground text-xs">(Optional)</span>
                  </Label>
                  <Input
                    id="initialInvestment"
                    type="number"
                    placeholder="Enter initial investment amount"
                    value={initialInvestment}
                    onChange={(e) => setInitialInvestment(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Target Multiple */}
                <div className="space-y-2">
                  <Label htmlFor="targetMultiple">
                    Target Multiple <span className="text-muted-foreground text-xs">(Default: 2x for doubling)</span>
                  </Label>
                  <Input
                    id="targetMultiple"
                    type="number"
                    placeholder="2 for doubling, 3 for tripling, etc."
                    value={targetMultiple}
                    onChange={(e) => setTargetMultiple(e.target.value)}
                    min="1.1"
                    step="0.5"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRule72} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        Time to {result.targetMultiple}x Your Investment
                      </p>
                      <p className="text-5xl font-bold text-green-600 mb-2">
                        {result.yearsToDouble} <span className="text-2xl">years</span>
                      </p>
                      <p className="text-sm text-muted-foreground">At {result.effectiveRate}% annual return</p>
                    </div>

                    {/* Future Value */}
                    {result.futureValue > 0 && (
                      <div className="mt-4 p-3 bg-white/60 rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Future Value</span>
                          <span className="font-semibold text-green-700">
                            {formatCurrency(result.futureValue, currency)}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Growth Schedule */}
                    {result.growthSchedule.length > 0 && (
                      <Collapsible open={showSchedule} onOpenChange={setShowSchedule} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            <span>View Growth Schedule</span>
                            <ChevronDown
                              className={`h-4 w-4 transition-transform ${showSchedule ? "rotate-180" : ""}`}
                            />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="max-h-48 overflow-y-auto rounded-lg border bg-white">
                            <table className="w-full text-sm">
                              <thead className="bg-muted/50 sticky top-0">
                                <tr>
                                  <th className="px-3 py-2 text-left font-medium">Year</th>
                                  <th className="px-3 py-2 text-right font-medium">Value</th>
                                  <th className="px-3 py-2 text-right font-medium">Multiple</th>
                                </tr>
                              </thead>
                              <tbody>
                                {result.growthSchedule.map((row) => (
                                  <tr
                                    key={row.year}
                                    className={`border-t ${row.multiple >= result.targetMultiple ? "bg-green-50" : ""}`}
                                  >
                                    <td className="px-3 py-2">{row.year}</td>
                                    <td className="px-3 py-2 text-right">{formatCurrency(row.value, currency)}</td>
                                    <td className="px-3 py-2 text-right">{row.multiple.toFixed(2)}x</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">2% Return</span>
                      <span className="text-sm text-green-600">~36 years to double</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">6% Return</span>
                      <span className="text-sm text-blue-600">~12 years to double</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">8% Return</span>
                      <span className="text-sm text-purple-600">~9 years to double</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">12% Return</span>
                      <span className="text-sm text-orange-600">~6 years to double</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">The Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Years to Double = 72 ÷ Interest Rate</p>
                  </div>
                  <p>
                    For other multiples: <strong>Years = (72 × ln(Multiple)) ÷ (ln(2) × Rate)</strong>
                  </p>
                  <p className="text-xs">The Rule of 72 is most accurate for rates between 6% and 10%.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Rule of 72?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Rule of 72 is a simple, powerful mental math shortcut used to estimate the number of years
                  required to double an investment at a fixed annual rate of return. By dividing 72 by the expected
                  annual return percentage, investors can quickly approximate how long their money will take to grow
                  twofold. This rule has been used by financial professionals and everyday investors for centuries as a
                  quick estimation tool.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Rule of 72 works because of the mathematical properties of compound interest. While not perfectly
                  accurate (especially at very high or very low interest rates), it provides remarkably close estimates
                  for rates between 6% and 10%, making it invaluable for quick financial planning and comparing
                  investment options without needing a calculator.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use the Rule of 72</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Using the Rule of 72 is straightforward: simply divide 72 by your expected annual rate of return. For
                  example, if you expect an 8% annual return on your investment, divide 72 by 8 to get 9 years. This
                  means your investment should approximately double in 9 years at that rate.
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-sm">Compare Investments</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Quickly compare how fast different investments will grow
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-sm">Set Goals</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Determine what return rate you need to reach your goals
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-sm">Understand Inflation</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Calculate how fast inflation erodes purchasing power
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-sm">Evaluate Debt</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      See how quickly debt doubles at various interest rates
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Variations of the Rule</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the Rule of 72 is the most common, there are variations for different accuracy levels and use
                  cases:
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-800">Rule of 69.3</p>
                    <p className="text-sm text-blue-700 mt-1">
                      More mathematically accurate for continuous compounding. Use for academic or precise calculations.
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-800">Rule of 70</p>
                    <p className="text-sm text-green-700 mt-1">
                      Often used for lower interest rates (2-5%). Easier to divide mentally for some numbers.
                    </p>
                  </div>
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-medium text-purple-800">Rule of 114 (Tripling)</p>
                    <p className="text-sm text-purple-700 mt-1">
                      Divide 114 by the interest rate to find years to triple your investment.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Rule of 72 calculations are estimates and assume a fixed annual return.
                  Actual investment growth may vary due to market fluctuations, inflation, fees, and taxes. This
                  calculator is for educational purposes only. Consult a qualified financial advisor for personalized
                  investment guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
