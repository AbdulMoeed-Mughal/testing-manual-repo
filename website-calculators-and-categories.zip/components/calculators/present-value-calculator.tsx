"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  DollarSign,
  Info,
  Calculator,
  TrendingDown,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, currencySymbols, formatCurrency } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

type CalculationType = "single" | "series"

interface CashFlow {
  id: string
  amount: string
  period: string
}

interface PVResult {
  presentValue: number
  futureValue: number
  totalDiscount: number
  discountPercentage: number
  inflationAdjustedPV: number | null
  cashFlowBreakdown: { period: number; futureValue: number; presentValue: number; discountFactor: number }[]
}

export function PresentValueCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [calculationType, setCalculationType] = useState<CalculationType>("single")
  const [futureValue, setFutureValue] = useState("")
  const [discountRate, setDiscountRate] = useState("")
  const [periods, setPeriods] = useState("")
  const [periodType, setPeriodType] = useState<"years" | "months" | "quarters">("years")
  const [inflationRate, setInflationRate] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [cashFlows, setCashFlows] = useState<CashFlow[]>([{ id: "1", amount: "", period: "1" }])
  const [result, setResult] = useState<PVResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const currencySymbol = currencySymbols[currency]

  const addCashFlow = () => {
    const newId = (Math.max(...cashFlows.map((cf) => Number.parseInt(cf.id))) + 1).toString()
    const newPeriod = (Math.max(...cashFlows.map((cf) => Number.parseInt(cf.period) || 0)) + 1).toString()
    setCashFlows([...cashFlows, { id: newId, amount: "", period: newPeriod }])
  }

  const removeCashFlow = (id: string) => {
    if (cashFlows.length > 1) {
      setCashFlows(cashFlows.filter((cf) => cf.id !== id))
    }
  }

  const updateCashFlow = (id: string, field: "amount" | "period", value: string) => {
    setCashFlows(cashFlows.map((cf) => (cf.id === id ? { ...cf, [field]: value } : cf)))
  }

  const calculatePresentValue = () => {
    setError("")
    setResult(null)

    const rate = Number.parseFloat(discountRate)
    if (isNaN(rate) || rate < 0) {
      setError("Please enter a valid discount rate (0 or greater)")
      return
    }

    // Convert rate based on period type
    let periodicRate = rate / 100
    if (periodType === "months") {
      periodicRate = periodicRate / 12
    } else if (periodType === "quarters") {
      periodicRate = periodicRate / 4
    }

    const inflation = Number.parseFloat(inflationRate) || 0

    if (calculationType === "single") {
      const fv = Number.parseFloat(futureValue)
      const n = Number.parseFloat(periods)

      if (isNaN(fv) || fv <= 0) {
        setError("Please enter a valid future value greater than 0")
        return
      }
      if (isNaN(n) || n <= 0) {
        setError("Please enter a valid number of periods greater than 0")
        return
      }

      // PV = FV / (1 + r)^n
      const pv = fv / Math.pow(1 + periodicRate, n)
      const totalDiscount = fv - pv
      const discountPercentage = (totalDiscount / fv) * 100

      // Inflation-adjusted PV
      let inflationAdjustedPV: number | null = null
      if (inflation > 0) {
        const realRate =
          (1 + periodicRate) /
            (1 + inflation / 100 / (periodType === "months" ? 12 : periodType === "quarters" ? 4 : 1)) -
          1
        inflationAdjustedPV = fv / Math.pow(1 + realRate, n)
      }

      // Generate breakdown
      const breakdown: PVResult["cashFlowBreakdown"] = []
      for (let i = 1; i <= Math.min(n, 30); i++) {
        const discountFactor = 1 / Math.pow(1 + periodicRate, i)
        const pvAtPeriod = fv * discountFactor
        breakdown.push({
          period: i,
          futureValue: fv,
          presentValue: pvAtPeriod,
          discountFactor: discountFactor,
        })
      }

      setResult({
        presentValue: pv,
        futureValue: fv,
        totalDiscount,
        discountPercentage,
        inflationAdjustedPV,
        cashFlowBreakdown: breakdown,
      })
    } else {
      // Series of cash flows
      const validCashFlows = cashFlows.filter((cf) => {
        const amount = Number.parseFloat(cf.amount)
        const period = Number.parseFloat(cf.period)
        return !isNaN(amount) && amount > 0 && !isNaN(period) && period > 0
      })

      if (validCashFlows.length === 0) {
        setError("Please enter at least one valid cash flow")
        return
      }

      let totalPV = 0
      let totalFV = 0
      const breakdown: PVResult["cashFlowBreakdown"] = []

      validCashFlows.forEach((cf) => {
        const amount = Number.parseFloat(cf.amount)
        const period = Number.parseFloat(cf.period)
        const discountFactor = 1 / Math.pow(1 + periodicRate, period)
        const pv = amount * discountFactor

        totalPV += pv
        totalFV += amount

        breakdown.push({
          period,
          futureValue: amount,
          presentValue: pv,
          discountFactor,
        })
      })

      breakdown.sort((a, b) => a.period - b.period)

      const totalDiscount = totalFV - totalPV
      const discountPercentage = (totalDiscount / totalFV) * 100

      // Inflation-adjusted PV for series
      let inflationAdjustedPV: number | null = null
      if (inflation > 0) {
        let adjPV = 0
        validCashFlows.forEach((cf) => {
          const amount = Number.parseFloat(cf.amount)
          const period = Number.parseFloat(cf.period)
          const realRate =
            (1 + periodicRate) /
              (1 + inflation / 100 / (periodType === "months" ? 12 : periodType === "quarters" ? 4 : 1)) -
            1
          adjPV += amount / Math.pow(1 + realRate, period)
        })
        inflationAdjustedPV = adjPV
      }

      setResult({
        presentValue: totalPV,
        futureValue: totalFV,
        totalDiscount,
        discountPercentage,
        inflationAdjustedPV,
        cashFlowBreakdown: breakdown,
      })
    }
  }

  const handleReset = () => {
    setFutureValue("")
    setDiscountRate("")
    setPeriods("")
    setPeriodType("years")
    setInflationRate("")
    setCashFlows([{ id: "1", amount: "", period: "1" }])
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Present Value: ${formatCurrency(result.presentValue, currency)}\nFuture Value: ${formatCurrency(result.futureValue, currency)}\nTotal Discount: ${formatCurrency(result.totalDiscount, currency)} (${result.discountPercentage.toFixed(2)}%)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingDown className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Present Value Calculator</CardTitle>
                    <CardDescription>Calculate the current worth of future money</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <CurrencySelector value={currency} onChange={setCurrency} />

                {/* Calculation Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Type</span>
                  <button
                    onClick={() => {
                      setCalculationType((prev) => (prev === "single" ? "series" : "single"))
                      setResult(null)
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        calculationType === "series" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        calculationType === "single" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Single
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        calculationType === "series" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Cash Flows
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {calculationType === "single" ? (
                  <>
                    {/* Future Value Input */}
                    <div className="space-y-2">
                      <Label htmlFor="futureValue">Future Value ({currencySymbol})</Label>
                      <Input
                        id="futureValue"
                        type="number"
                        placeholder="Enter future value"
                        value={futureValue}
                        onChange={(e) => setFutureValue(e.target.value)}
                        min="0"
                        step="100"
                      />
                    </div>

                    {/* Number of Periods */}
                    <div className="space-y-2">
                      <Label htmlFor="periods">Number of Periods</Label>
                      <div className="flex gap-2">
                        <Input
                          id="periods"
                          type="number"
                          placeholder="Enter periods"
                          value={periods}
                          onChange={(e) => setPeriods(e.target.value)}
                          min="0"
                          step="1"
                          className="flex-1"
                        />
                        <Select
                          value={periodType}
                          onValueChange={(value: "years" | "months" | "quarters") => setPeriodType(value)}
                        >
                          <SelectTrigger className="w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="years">Years</SelectItem>
                            <SelectItem value="months">Months</SelectItem>
                            <SelectItem value="quarters">Quarters</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Cash Flows */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label>Cash Flows</Label>
                        <Button variant="outline" size="sm" onClick={addCashFlow}>
                          <Plus className="h-4 w-4 mr-1" />
                          Add
                        </Button>
                      </div>
                      {cashFlows.map((cf, index) => (
                        <div key={cf.id} className="flex items-center gap-2">
                          <div className="flex-1">
                            <Input
                              type="number"
                              placeholder={`Amount (${currencySymbol})`}
                              value={cf.amount}
                              onChange={(e) => updateCashFlow(cf.id, "amount", e.target.value)}
                              min="0"
                            />
                          </div>
                          <div className="w-24">
                            <Input
                              type="number"
                              placeholder="Period"
                              value={cf.period}
                              onChange={(e) => updateCashFlow(cf.id, "period", e.target.value)}
                              min="1"
                            />
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeCashFlow(cf.id)}
                            disabled={cashFlows.length === 1}
                            className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                      <p className="text-xs text-muted-foreground">Period unit: {periodType}</p>
                    </div>

                    {/* Period Type */}
                    <div className="space-y-2">
                      <Label>Period Type</Label>
                      <Select
                        value={periodType}
                        onValueChange={(value: "years" | "months" | "quarters") => setPeriodType(value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="years">Years</SelectItem>
                          <SelectItem value="months">Months</SelectItem>
                          <SelectItem value="quarters">Quarters</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {/* Discount Rate */}
                <div className="space-y-2">
                  <Label htmlFor="discountRate">Annual Discount Rate (%)</Label>
                  <Input
                    id="discountRate"
                    type="number"
                    placeholder="Enter discount rate"
                    value={discountRate}
                    onChange={(e) => setDiscountRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between" size="sm">
                      Advanced Options
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="inflationRate">Inflation Rate (% per year, optional)</Label>
                      <Input
                        id="inflationRate"
                        type="number"
                        placeholder="Enter inflation rate"
                        value={inflationRate}
                        onChange={(e) => setInflationRate(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePresentValue} className="w-full" size="lg">
                  Calculate Present Value
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Present Value</p>
                      <p className="text-4xl font-bold text-green-600 mb-2">
                        {formatCurrency(result.presentValue, currency)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        of {formatCurrency(result.futureValue, currency)} future value
                      </p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Discount</p>
                        <p className="text-lg font-semibold text-red-600">
                          {formatCurrency(result.totalDiscount, currency)}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Discount %</p>
                        <p className="text-lg font-semibold text-orange-600">{result.discountPercentage.toFixed(2)}%</p>
                      </div>
                    </div>

                    {result.inflationAdjustedPV !== null && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Inflation-Adjusted PV</p>
                        <p className="text-lg font-semibold text-blue-600">
                          {formatCurrency(result.inflationAdjustedPV, currency)}
                        </p>
                      </div>
                    )}

                    {/* Breakdown */}
                    {result.cashFlowBreakdown.length > 0 && (
                      <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="outline" size="sm" className="w-full bg-transparent">
                            {showBreakdown ? "Hide" : "Show"} Period Breakdown
                            {showBreakdown ? (
                              <ChevronUp className="ml-2 h-4 w-4" />
                            ) : (
                              <ChevronDown className="ml-2 h-4 w-4" />
                            )}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-3">
                          <div className="max-h-48 overflow-y-auto">
                            <table className="w-full text-sm">
                              <thead className="bg-white sticky top-0">
                                <tr className="border-b">
                                  <th className="text-left py-2 px-2">Period</th>
                                  <th className="text-right py-2 px-2">FV</th>
                                  <th className="text-right py-2 px-2">PV</th>
                                  <th className="text-right py-2 px-2">Factor</th>
                                </tr>
                              </thead>
                              <tbody>
                                {result.cashFlowBreakdown.map((row) => (
                                  <tr key={row.period} className="border-b border-green-100">
                                    <td className="py-2 px-2">{row.period}</td>
                                    <td className="text-right py-2 px-2">
                                      {formatCurrency(row.futureValue, currency)}
                                    </td>
                                    <td className="text-right py-2 px-2 text-green-600 font-medium">
                                      {formatCurrency(row.presentValue, currency)}
                                    </td>
                                    <td className="text-right py-2 px-2 text-muted-foreground">
                                      {row.discountFactor.toFixed(4)}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Discount Rate Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low Risk</span>
                      <span className="text-sm text-green-600">3-5%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Moderate Risk</span>
                      <span className="text-sm text-blue-600">6-10%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Higher Risk</span>
                      <span className="text-sm text-yellow-600">10-15%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">High Risk</span>
                      <span className="text-sm text-red-600">15%+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Present Value Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">PV = FV / (1 + r)^n</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>PV</strong> = Present Value
                    </p>
                    <p>
                      <strong>FV</strong> = Future Value
                    </p>
                    <p>
                      <strong>r</strong> = Discount rate per period
                    </p>
                    <p>
                      <strong>n</strong> = Number of periods
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Present Value?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Present Value (PV) is a fundamental concept in finance that determines the current worth of a future
                  sum of money or stream of cash flows, given a specified rate of return. It is based on the time value
                  of money principle, which states that a dollar today is worth more than a dollar in the future due to
                  its potential earning capacity.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding present value is essential for making informed investment decisions, comparing different
                  financial opportunities, and evaluating the true cost or benefit of future cash flows. It helps
                  investors and businesses determine whether an investment is worthwhile by comparing its present value
                  to its current cost.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Single Amount:</strong> Use this mode when you have a single future payment. Enter the future
                  value you expect to receive, the number of periods until you receive it, and the discount rate that
                  represents your required rate of return or opportunity cost.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Cash Flow Series:</strong> Use this mode for multiple future payments occurring at different
                  times. Add each expected cash flow with its amount and the period in which it will be received. The
                  calculator will discount each cash flow individually and sum them to give you the total present value.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Inflation Adjustment:</strong> Enable the inflation rate option to see the real present value
                  adjusted for expected inflation, which shows the purchasing power of future money in today's terms.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Present Value</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Investment Analysis</h4>
                    <p className="text-sm text-muted-foreground">
                      Compare the present value of expected returns to the initial investment cost to determine if an
                      investment is worthwhile.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Bond Valuation</h4>
                    <p className="text-sm text-muted-foreground">
                      Calculate the fair price of bonds by discounting future coupon payments and the face value to
                      their present values.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Lease vs Buy Decisions</h4>
                    <p className="text-sm text-muted-foreground">
                      Compare the present value of lease payments versus the purchase price to make optimal financing
                      decisions.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Retirement Planning</h4>
                    <p className="text-sm text-muted-foreground">
                      Determine how much you need to save today to achieve a specific retirement goal in the future.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Present value calculations are estimates based on entered values and assumed discount rates.
                      Actual results may vary due to market conditions, inflation, and other factors. Consult a
                      financial advisor for personalized guidance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
