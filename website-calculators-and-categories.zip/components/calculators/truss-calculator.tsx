"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Triangle,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type TrussType = "king-post" | "queen-post" | "fink" | "howe"

interface TrussResult {
  topChordLength: number
  bottomChordLength: number
  kingPostLength: number
  webMemberLengths: number[]
  totalMemberLength: number
  totalVolume: number
  totalVolumeWithWaste: number
  totalWeight: number | null
  numberOfTrusses: number
  pitchAngle: number
}

export function TrussCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [trussType, setTrussType] = useState<TrussType>("king-post")
  const [span, setSpan] = useState("")
  const [rise, setRise] = useState("")
  const [spacing, setSpacing] = useState("")
  const [roofLength, setRoofLength] = useState("")
  const [memberWidth, setMemberWidth] = useState("")
  const [memberHeight, setMemberHeight] = useState("")
  const [waste, setWaste] = useState("10")
  const [density, setDensity] = useState("")
  const [result, setResult] = useState<TrussResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const trussTypes = [
    { value: "king-post", label: "King Post", description: "Simple design with central vertical post" },
    { value: "queen-post", label: "Queen Post", description: "Two vertical posts for wider spans" },
    { value: "fink", label: "Fink (W-Truss)", description: "W-shaped web pattern, most common" },
    { value: "howe", label: "Howe", description: "Vertical and diagonal members" },
  ]

  const calculateTruss = () => {
    setError("")
    setResult(null)

    const spanNum = Number.parseFloat(span)
    const riseNum = Number.parseFloat(rise)
    const spacingNum = Number.parseFloat(spacing)
    const roofLengthNum = Number.parseFloat(roofLength)
    const memberWidthNum = Number.parseFloat(memberWidth) || 0
    const memberHeightNum = Number.parseFloat(memberHeight) || 0
    const wasteNum = Number.parseFloat(waste) || 10
    const densityNum = Number.parseFloat(density) || 0

    if (isNaN(spanNum) || spanNum <= 0) {
      setError("Please enter a valid span greater than 0")
      return
    }

    if (isNaN(riseNum) || riseNum <= 0) {
      setError("Please enter a valid rise greater than 0")
      return
    }

    if (isNaN(spacingNum) || spacingNum <= 0) {
      setError("Please enter a valid truss spacing greater than 0")
      return
    }

    if (isNaN(roofLengthNum) || roofLengthNum <= 0) {
      setError("Please enter a valid roof length greater than 0")
      return
    }

    // Convert to meters for calculation
    const spanM = unitSystem === "imperial" ? spanNum * 0.3048 : spanNum
    const riseM = unitSystem === "imperial" ? riseNum * 0.3048 : riseNum
    const spacingM = unitSystem === "imperial" ? spacingNum * 0.3048 : spacingNum
    const roofLengthM = unitSystem === "imperial" ? roofLengthNum * 0.3048 : roofLengthNum

    // Member dimensions in meters
    let memberWidthM = 0
    let memberHeightM = 0
    if (memberWidthNum > 0 && memberHeightNum > 0) {
      memberWidthM = unitSystem === "imperial" ? memberWidthNum * 0.0254 : memberWidthNum / 1000
      memberHeightM = unitSystem === "imperial" ? memberHeightNum * 0.0254 : memberHeightNum / 1000
    }

    // Calculate pitch angle
    const halfSpan = spanM / 2
    const pitchAngle = Math.atan(riseM / halfSpan) * (180 / Math.PI)

    // Calculate top chord length (rafter length) - each side
    const topChordLength = Math.sqrt(halfSpan * halfSpan + riseM * riseM)
    const totalTopChordLength = topChordLength * 2 // Both sides

    // Bottom chord is the span
    const bottomChordLength = spanM

    // King post (vertical center post)
    const kingPostLength = riseM

    // Calculate web member lengths based on truss type
    let webMemberLengths: number[] = []

    switch (trussType) {
      case "king-post":
        // Simple king post: just the central vertical
        webMemberLengths = [kingPostLength]
        break

      case "queen-post":
        // Two vertical posts at 1/3 points, plus horizontal tie
        const queenPostHeight = riseM * 0.67
        const horizontalTie = spanM / 3
        webMemberLengths = [queenPostHeight, queenPostHeight, horizontalTie]
        break

      case "fink":
        // W-pattern web members
        const finkDiag1 = Math.sqrt((halfSpan / 2) ** 2 + (riseM / 2) ** 2) * 2
        const finkDiag2 = Math.sqrt((halfSpan / 4) ** 2 + (riseM / 4) ** 2) * 4
        webMemberLengths = [finkDiag1, finkDiag2, kingPostLength]
        break

      case "howe":
        // Vertical and diagonal members
        const howeVertical1 = riseM * 0.5
        const howeVertical2 = riseM * 0.75
        const howeDiagonal = Math.sqrt((halfSpan / 3) ** 2 + (riseM * 0.5) ** 2) * 2
        webMemberLengths = [howeVertical1 * 2, howeVertical2 * 2, kingPostLength, howeDiagonal]
        break
    }

    // Total member length for one truss
    const totalMemberLength = totalTopChordLength + bottomChordLength + webMemberLengths.reduce((a, b) => a + b, 0)

    // Number of trusses needed
    const numberOfTrusses = Math.ceil(roofLengthM / spacingM) + 1

    // Calculate volume if member dimensions provided
    let totalVolume = 0
    let totalVolumeWithWaste = 0
    let totalWeight: number | null = null

    if (memberWidthM > 0 && memberHeightM > 0) {
      const crossSection = memberWidthM * memberHeightM
      const volumePerTruss = totalMemberLength * crossSection
      totalVolume = volumePerTruss * numberOfTrusses
      totalVolumeWithWaste = totalVolume * (1 + wasteNum / 100)

      if (densityNum > 0) {
        // Density in kg/m³ for metric, lb/ft³ for imperial
        const densityKgM3 = unitSystem === "imperial" ? densityNum * 16.0185 : densityNum
        totalWeight = totalVolumeWithWaste * densityKgM3
      }
    }

    // Convert results back to display units
    const displayFactor = unitSystem === "imperial" ? 3.28084 : 1
    const volumeFactor = unitSystem === "imperial" ? 35.3147 : 1

    setResult({
      topChordLength: topChordLength * displayFactor,
      bottomChordLength: bottomChordLength * displayFactor,
      kingPostLength: kingPostLength * displayFactor,
      webMemberLengths: webMemberLengths.map((l) => l * displayFactor),
      totalMemberLength: totalMemberLength * displayFactor,
      totalVolume: totalVolume * volumeFactor,
      totalVolumeWithWaste: totalVolumeWithWaste * volumeFactor,
      totalWeight: totalWeight,
      numberOfTrusses,
      pitchAngle,
    })
  }

  const handleReset = () => {
    setSpan("")
    setRise("")
    setSpacing("")
    setRoofLength("")
    setMemberWidth("")
    setMemberHeight("")
    setWaste("10")
    setDensity("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const lengthUnit = unitSystem === "metric" ? "m" : "ft"
      const volumeUnit = unitSystem === "metric" ? "m³" : "ft³"
      const weightUnit = unitSystem === "metric" ? "kg" : "lb"
      const text = `Truss Calculator Results:
Type: ${trussTypes.find((t) => t.value === trussType)?.label}
Number of Trusses: ${result.numberOfTrusses}
Top Chord Length: ${result.topChordLength.toFixed(2)} ${lengthUnit} (each side)
Bottom Chord: ${result.bottomChordLength.toFixed(2)} ${lengthUnit}
Total Member Length per Truss: ${result.totalMemberLength.toFixed(2)} ${lengthUnit}
Pitch Angle: ${result.pitchAngle.toFixed(1)}°${result.totalVolume > 0 ? `\nTotal Volume: ${result.totalVolumeWithWaste.toFixed(3)} ${volumeUnit} (with waste)` : ""}${result.totalWeight ? `\nTotal Weight: ${(unitSystem === "imperial" ? result.totalWeight * 2.20462 : result.totalWeight).toFixed(1)} ${weightUnit}` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Truss Calculator Results",
          text: `I calculated my roof truss requirements using CalcHub! ${result.numberOfTrusses} trusses needed.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    handleReset()
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"
  const smallLengthUnit = unitSystem === "metric" ? "mm" : "in"
  const volumeUnit = unitSystem === "metric" ? "m³" : "ft³"
  const weightUnit = unitSystem === "metric" ? "kg" : "lb"
  const densityUnit = unitSystem === "metric" ? "kg/m³" : "lb/ft³"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <Triangle className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Truss Calculator</CardTitle>
                    <CardDescription>Calculate roof truss dimensions and materials</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Truss Type */}
                <div className="space-y-2">
                  <Label>Truss Type</Label>
                  <Select value={trussType} onValueChange={(v) => setTrussType(v as TrussType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {trussTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div>
                            <div className="font-medium">{type.label}</div>
                            <div className="text-xs text-muted-foreground">{type.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Span and Rise */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="span">Span / Width ({lengthUnit})</Label>
                    <Input
                      id="span"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "6" : "20"}`}
                      value={span}
                      onChange={(e) => setSpan(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="rise">Rise / Height ({lengthUnit})</Label>
                    <Input
                      id="rise"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "1.5" : "5"}`}
                      value={rise}
                      onChange={(e) => setRise(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Spacing and Roof Length */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="spacing">Truss Spacing ({lengthUnit})</Label>
                    <Input
                      id="spacing"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "0.6" : "2"}`}
                      value={spacing}
                      onChange={(e) => setSpacing(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="roofLength">Roof Length ({lengthUnit})</Label>
                    <Input
                      id="roofLength"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "10" : "30"}`}
                      value={roofLength}
                      onChange={(e) => setRoofLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Member Dimensions (Optional) */}
                <div className="p-3 bg-muted/50 rounded-lg space-y-3">
                  <p className="text-sm font-medium">Member Dimensions (Optional)</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="memberWidth">Width ({smallLengthUnit})</Label>
                      <Input
                        id="memberWidth"
                        type="number"
                        placeholder={`e.g., ${unitSystem === "metric" ? "50" : "2"}`}
                        value={memberWidth}
                        onChange={(e) => setMemberWidth(e.target.value)}
                        min="0"
                        step="1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="memberHeight">Height ({smallLengthUnit})</Label>
                      <Input
                        id="memberHeight"
                        type="number"
                        placeholder={`e.g., ${unitSystem === "metric" ? "100" : "4"}`}
                        value={memberHeight}
                        onChange={(e) => setMemberHeight(e.target.value)}
                        min="0"
                        step="1"
                      />
                    </div>
                  </div>
                </div>

                {/* Waste and Density */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="waste">Waste (%)</Label>
                    <Input
                      id="waste"
                      type="number"
                      placeholder="10"
                      value={waste}
                      onChange={(e) => setWaste(e.target.value)}
                      min="0"
                      max="50"
                      step="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="density">
                      Density ({densityUnit}) <span className="text-muted-foreground text-xs">(optional)</span>
                    </Label>
                    <Input
                      id="density"
                      type="number"
                      placeholder={unitSystem === "metric" ? "500" : "31"}
                      value={density}
                      onChange={(e) => setDensity(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTruss} className="w-full" size="lg">
                  Calculate Truss
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-yellow-50 border-yellow-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Number of Trusses Required</p>
                      <p className="text-5xl font-bold text-yellow-600 mb-2">{result.numberOfTrusses}</p>
                      <p className="text-sm text-muted-foreground">
                        Pitch Angle: {result.pitchAngle.toFixed(1)}° |{" "}
                        {trussTypes.find((t) => t.value === trussType)?.label} Truss
                      </p>
                    </div>

                    {/* Key Measurements */}
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Top Chord (each)</p>
                        <p className="font-semibold text-yellow-700">
                          {result.topChordLength.toFixed(2)} {lengthUnit}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Bottom Chord</p>
                        <p className="font-semibold text-yellow-700">
                          {result.bottomChordLength.toFixed(2)} {lengthUnit}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">King Post</p>
                        <p className="font-semibold text-yellow-700">
                          {result.kingPostLength.toFixed(2)} {lengthUnit}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total per Truss</p>
                        <p className="font-semibold text-yellow-700">
                          {result.totalMemberLength.toFixed(2)} {lengthUnit}
                        </p>
                      </div>
                    </div>

                    {/* Volume and Weight */}
                    {result.totalVolume > 0 && (
                      <div className="grid grid-cols-2 gap-2 mb-4">
                        <div className="p-2 bg-white rounded-lg text-center">
                          <p className="text-xs text-muted-foreground">Total Volume (with waste)</p>
                          <p className="font-semibold text-yellow-700">
                            {result.totalVolumeWithWaste.toFixed(3)} {volumeUnit}
                          </p>
                        </div>
                        {result.totalWeight && (
                          <div className="p-2 bg-white rounded-lg text-center">
                            <p className="text-xs text-muted-foreground">Total Weight</p>
                            <p className="font-semibold text-yellow-700">
                              {(unitSystem === "imperial" ? result.totalWeight * 2.20462 : result.totalWeight).toFixed(
                                1,
                              )}{" "}
                              {weightUnit}
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-1 text-sm text-yellow-700 hover:text-yellow-800 mb-3"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" /> Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" /> Show Calculation Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="p-3 bg-white rounded-lg text-sm space-y-2 mb-4">
                        <p className="font-medium">Calculation Breakdown:</p>
                        <div className="space-y-1 text-muted-foreground">
                          <p>
                            • Half Span = {Number.parseFloat(span) / 2} {lengthUnit}
                          </p>
                          <p>
                            • Pitch Angle = atan({rise} ÷ {Number.parseFloat(span) / 2}) ={" "}
                            {result.pitchAngle.toFixed(1)}°
                          </p>
                          <p>
                            • Top Chord = √(({Number.parseFloat(span) / 2})² + ({rise})²) ={" "}
                            {result.topChordLength.toFixed(2)} {lengthUnit}
                          </p>
                          <p>
                            • Number of Trusses = ⌈{roofLength} ÷ {spacing}⌉ + 1 = {result.numberOfTrusses}
                          </p>
                          {result.totalVolume > 0 && (
                            <>
                              <p>
                                • Volume per Truss = {result.totalMemberLength.toFixed(2)} × ({memberWidth} ×{" "}
                                {memberHeight}) {smallLengthUnit}²
                              </p>
                              <p>
                                • Total Volume ={" "}
                                {(result.totalVolume / (1 + Number.parseFloat(waste) / 100)).toFixed(3)} {volumeUnit}
                              </p>
                              <p>
                                • With {waste}% Waste = {result.totalVolumeWithWaste.toFixed(3)} {volumeUnit}
                              </p>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              {/* Truss Diagram */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Truss Diagram</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg">
                    <svg viewBox="0 0 200 100" className="w-full h-auto">
                      {/* King Post Truss */}
                      {trussType === "king-post" && (
                        <>
                          {/* Bottom chord */}
                          <line x1="10" y1="80" x2="190" y2="80" stroke="currentColor" strokeWidth="3" />
                          {/* Left rafter */}
                          <line x1="10" y1="80" x2="100" y2="20" stroke="currentColor" strokeWidth="3" />
                          {/* Right rafter */}
                          <line x1="190" y1="80" x2="100" y2="20" stroke="currentColor" strokeWidth="3" />
                          {/* King post */}
                          <line x1="100" y1="80" x2="100" y2="20" stroke="#ca8a04" strokeWidth="2" />
                          {/* Labels */}
                          <text x="100" y="95" textAnchor="middle" className="text-[8px] fill-muted-foreground">
                            Span
                          </text>
                          <text x="50" y="45" textAnchor="middle" className="text-[8px] fill-muted-foreground">
                            Top Chord
                          </text>
                          <text x="108" y="55" className="text-[8px] fill-yellow-600">
                            King Post
                          </text>
                        </>
                      )}
                      {/* Queen Post Truss */}
                      {trussType === "queen-post" && (
                        <>
                          <line x1="10" y1="80" x2="190" y2="80" stroke="currentColor" strokeWidth="3" />
                          <line x1="10" y1="80" x2="100" y2="20" stroke="currentColor" strokeWidth="3" />
                          <line x1="190" y1="80" x2="100" y2="20" stroke="currentColor" strokeWidth="3" />
                          <line x1="70" y1="80" x2="70" y2="40" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="130" y1="80" x2="130" y2="40" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="70" y1="40" x2="130" y2="40" stroke="#ca8a04" strokeWidth="2" />
                          <text x="100" y="95" textAnchor="middle" className="text-[8px] fill-muted-foreground">
                            Span
                          </text>
                        </>
                      )}
                      {/* Fink Truss */}
                      {trussType === "fink" && (
                        <>
                          <line x1="10" y1="80" x2="190" y2="80" stroke="currentColor" strokeWidth="3" />
                          <line x1="10" y1="80" x2="100" y2="20" stroke="currentColor" strokeWidth="3" />
                          <line x1="190" y1="80" x2="100" y2="20" stroke="currentColor" strokeWidth="3" />
                          <line x1="100" y1="80" x2="100" y2="20" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="55" y1="50" x2="55" y2="80" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="145" y1="50" x2="145" y2="80" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="55" y1="50" x2="100" y2="80" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="145" y1="50" x2="100" y2="80" stroke="#ca8a04" strokeWidth="2" />
                          <text x="100" y="95" textAnchor="middle" className="text-[8px] fill-muted-foreground">
                            Span
                          </text>
                        </>
                      )}
                      {/* Howe Truss */}
                      {trussType === "howe" && (
                        <>
                          <line x1="10" y1="80" x2="190" y2="80" stroke="currentColor" strokeWidth="3" />
                          <line x1="10" y1="80" x2="100" y2="20" stroke="currentColor" strokeWidth="3" />
                          <line x1="190" y1="80" x2="100" y2="20" stroke="currentColor" strokeWidth="3" />
                          <line x1="100" y1="80" x2="100" y2="20" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="55" y1="80" x2="55" y2="50" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="145" y1="80" x2="145" y2="50" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="10" y1="80" x2="55" y2="50" stroke="#ca8a04" strokeWidth="2" />
                          <line x1="190" y1="80" x2="145" y2="50" stroke="#ca8a04" strokeWidth="2" />
                          <text x="100" y="95" textAnchor="middle" className="text-[8px] fill-muted-foreground">
                            Span
                          </text>
                        </>
                      )}
                    </svg>
                    <p className="text-xs text-center text-muted-foreground mt-2">
                      {trussTypes.find((t) => t.value === trussType)?.label} Truss
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Truss Types Reference */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Truss Types Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    {trussTypes.map((type) => (
                      <div
                        key={type.value}
                        className={`p-3 rounded-lg ${trussType === type.value ? "bg-yellow-50 border border-yellow-200" : "bg-muted"}`}
                      >
                        <p className="font-medium">{type.label}</p>
                        <p className="text-xs text-muted-foreground">{type.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Common Spacing */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Truss Spacing</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Residential</span>
                      <span className="font-medium">600mm / 24"</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Light Commercial</span>
                      <span className="font-medium">400-600mm / 16-24"</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Heavy Loads</span>
                      <span className="font-medium">400mm / 16"</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-yellow-200 bg-yellow-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-medium mb-1">Important Notice</p>
                      <p>
                        Results are estimates for planning purposes only. Actual truss dimensions and materials may vary
                        based on engineering specifications, local building codes, load requirements, and material
                        availability. Always consult a structural engineer for final designs.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Roof Trusses</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A roof truss is a structural framework designed to support the roof of a building. It consists of
                  interconnected triangular units that efficiently distribute the weight of the roof to the walls below.
                  Trusses are engineered to handle various loads including the weight of roofing materials, snow, wind,
                  and any equipment mounted on the roof.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The triangular shape is key to a truss's strength - triangles are inherently stable and resist
                  deformation under load. By combining multiple triangles, trusses can span large distances without
                  intermediate support, making them ideal for open floor plans and large buildings.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Triangle className="h-5 w-5 text-primary" />
                  <CardTitle>Truss Components</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Top Chord (Rafters)</h4>
                    <p className="text-sm text-muted-foreground">
                      The sloped upper members that follow the roof pitch. They support the roof decking and transfer
                      loads to the web members and bottom chord.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Bottom Chord</h4>
                    <p className="text-sm text-muted-foreground">
                      The horizontal lower member that spans between the walls. It acts as a tie, preventing the walls
                      from spreading under the roof load.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Web Members</h4>
                    <p className="text-sm text-muted-foreground">
                      The internal diagonal and vertical members that connect the top and bottom chords, creating the
                      triangular patterns that give the truss its strength.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">King/Queen Post</h4>
                    <p className="text-sm text-muted-foreground">
                      The central vertical member(s) that transfer loads from the apex to the bottom chord. King post
                      trusses have one; queen post trusses have two.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Choosing the Right Truss Type</CardTitle>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">King Post Truss</h4>
                    <p className="text-sm text-yellow-700">
                      Best for: Small spans up to 8m (26ft). Simple design, economical for garages, sheds, and small
                      residential buildings. Limited by span due to lack of intermediate support.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Queen Post Truss</h4>
                    <p className="text-sm text-blue-700">
                      Best for: Medium spans 8-12m (26-40ft). Two vertical posts provide more support than king post
                      design. Good for residential and light commercial buildings.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Fink (W-Truss)</h4>
                    <p className="text-sm text-green-700">
                      Best for: Most residential applications. The W-shaped web pattern provides excellent strength and
                      is the most common truss type. Economical and efficient for spans up to 15m (50ft).
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Howe Truss</h4>
                    <p className="text-sm text-purple-700">
                      Best for: Heavy load applications and longer spans. Vertical members in compression and diagonals
                      in tension make it suitable for bridges and industrial buildings.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
