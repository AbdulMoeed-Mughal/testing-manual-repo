"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Activity, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "SI" | "imperial"

interface LiveLoadResult {
  liveLoadPerFloor: number
  totalLiveLoad: number
  loadPerArea: number
  unit: string
}

interface LoadPreset {
  name: string
  load: number
  description: string
}

const loadPresetsSI: LoadPreset[] = [
  { name: "Residential - Bedrooms", load: 1.5, description: "Houses, apartments" },
  { name: "Residential - Living Areas", load: 2.0, description: "Living rooms, dining" },
  { name: "Office - General", load: 2.5, description: "General office space" },
  { name: "Office - Heavy", load: 5.0, description: "Computer rooms, filing" },
  { name: "Retail - Light", load: 4.0, description: "Shops, showrooms" },
  { name: "Retail - Heavy", load: 5.0, description: "Storage, warehouses" },
  { name: "Industrial - Light", load: 5.0, description: "Light manufacturing" },
  { name: "Industrial - Heavy", load: 7.5, description: "Heavy manufacturing" },
  { name: "Parking - Cars", load: 2.5, description: "Car parking areas" },
  { name: "Assembly - Fixed Seating", load: 4.0, description: "Theaters, churches" },
]

const loadPresetsImperial: LoadPreset[] = [
  { name: "Residential - Bedrooms", load: 30, description: "Houses, apartments" },
  { name: "Residential - Living Areas", load: 40, description: "Living rooms, dining" },
  { name: "Office - General", load: 50, description: "General office space" },
  { name: "Office - Heavy", load: 100, description: "Computer rooms, filing" },
  { name: "Retail - Light", load: 75, description: "Shops, showrooms" },
  { name: "Retail - Heavy", load: 100, description: "Storage, warehouses" },
  { name: "Industrial - Light", load: 125, description: "Light manufacturing" },
  { name: "Industrial - Heavy", load: 250, description: "Heavy manufacturing" },
  { name: "Parking - Cars", load: 50, description: "Car parking areas" },
  { name: "Assembly - Fixed Seating", load: 60, description: "Theaters, churches" },
]

export function LiveLoadCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("SI")
  const [area, setArea] = useState("")
  const [unitLoad, setUnitLoad] = useState("2.0")
  const [safetyFactor, setSafetyFactor] = useState("1.5")
  const [floors, setFloors] = useState("1")
  const [result, setResult] = useState<LiveLoadResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateLiveLoad = () => {
    setError("")
    setResult(null)

    const areaNum = Number.parseFloat(area)
    const unitLoadNum = Number.parseFloat(unitLoad)
    const sf = Number.parseFloat(safetyFactor)
    const floorsNum = Number.parseInt(floors) || 1

    if (isNaN(areaNum) || areaNum <= 0) {
      setError("Please enter a valid area greater than 0")
      return
    }
    if (isNaN(unitLoadNum) || unitLoadNum <= 0) {
      setError("Please enter a valid unit load greater than 0")
      return
    }
    if (isNaN(sf) || sf < 1) {
      setError("Safety factor must be at least 1")
      return
    }
    if (floorsNum < 1) {
      setError("Number of floors must be at least 1")
      return
    }

    // Calculate live load
    const liveLoadPerFloor = areaNum * unitLoadNum * sf
    const totalLiveLoad = liveLoadPerFloor * floorsNum

    const unit = unitSystem === "SI" ? "kN" : "lb"

    setResult({
      liveLoadPerFloor: Math.round(liveLoadPerFloor * 100) / 100,
      totalLiveLoad: Math.round(totalLiveLoad * 100) / 100,
      loadPerArea: Math.round(unitLoadNum * sf * 100) / 100,
      unit,
    })
  }

  const handleReset = () => {
    setArea("")
    setUnitLoad(unitSystem === "SI" ? "2.0" : "40")
    setSafetyFactor("1.5")
    setFloors("1")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Live Load: ${result.totalLiveLoad} ${result.unit} (${floors} floor${Number.parseInt(floors) > 1 ? "s" : ""})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Live Load Calculation",
          text: `I calculated live load using CalcHub! Total: ${result.totalLiveLoad} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "SI" ? "imperial" : "SI"))
    setArea("")
    setUnitLoad(unitSystem === "SI" ? "40" : "2.0")
    setResult(null)
    setError("")
  }

  const handleLoadPreset = (presetName: string) => {
    const presets = unitSystem === "SI" ? loadPresetsSI : loadPresetsImperial
    const preset = presets.find((p) => p.name === presetName)
    if (preset) {
      setUnitLoad(preset.load.toString())
    }
  }

  const areaUnit = unitSystem === "SI" ? "m²" : "ft²"
  const loadUnit = unitSystem === "SI" ? "kN/m²" : "lb/ft²"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Live Load Calculator</CardTitle>
                    <CardDescription>Calculate live load for structural design</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "SI" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      SI
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="area">Area ({areaUnit})</Label>
                  <Input
                    id="area"
                    type="number"
                    placeholder={`Enter area in ${areaUnit}`}
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Unit Load */}
                <div className="space-y-2">
                  <Label htmlFor="unitLoad">Unit Load ({loadUnit})</Label>
                  <div className="flex gap-2">
                    <Input
                      id="unitLoad"
                      type="number"
                      placeholder="0"
                      value={unitLoad}
                      onChange={(e) => setUnitLoad(e.target.value)}
                      min="0"
                      step="0.1"
                      className="flex-1"
                    />
                    <Select onValueChange={handleLoadPreset}>
                      <SelectTrigger className="w-[140px]">
                        <SelectValue placeholder="Preset" />
                      </SelectTrigger>
                      <SelectContent>
                        {(unitSystem === "SI" ? loadPresetsSI : loadPresetsImperial).map((preset) => (
                          <SelectItem key={preset.name} value={preset.name}>
                            {preset.name.split(" - ")[1]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Safety Factor and Floors */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="safetyFactor">Safety Factor</Label>
                    <Input
                      id="safetyFactor"
                      type="number"
                      placeholder="1.5"
                      value={safetyFactor}
                      onChange={(e) => setSafetyFactor(e.target.value)}
                      min="1"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="floors">Number of Floors</Label>
                    <Input
                      id="floors"
                      type="number"
                      placeholder="1"
                      value={floors}
                      onChange={(e) => setFloors(e.target.value)}
                      min="1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLiveLoad} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Live Load
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total Live Load</p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">{result.totalLiveLoad}</p>
                        <p className="text-lg font-semibold text-amber-700">{result.unit}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-amber-200">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Per Floor</p>
                          <p className="text-lg font-semibold text-amber-700">
                            {result.liveLoadPerFloor} {result.unit}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Load per Area</p>
                          <p className="text-lg font-semibold text-amber-700">
                            {result.loadPerArea} {loadUnit}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Live Loads (SI)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {loadPresetsSI.slice(0, 6).map((preset) => (
                      <div key={preset.name} className="flex items-center justify-between p-2 rounded bg-muted">
                        <div>
                          <p className="font-medium">{preset.name}</p>
                          <p className="text-xs text-muted-foreground">{preset.description}</p>
                        </div>
                        <span className="text-muted-foreground font-semibold">{preset.load} kN/m²</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Safety Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong className="text-foreground">Residential:</strong> 1.5
                  </p>
                  <p>
                    <strong className="text-foreground">Commercial/Office:</strong> 1.5 - 1.6
                  </p>
                  <p>
                    <strong className="text-foreground">Industrial:</strong> 1.6 - 1.8
                  </p>
                  <p className="text-xs pt-2 border-t">
                    Safety factors ensure structures can handle loads beyond normal usage. Verify with local codes.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Live Load */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Live Load?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Live load, also known as imposed load or variable load, refers to temporary and movable loads that a
                  structure must support during its service life. Unlike dead loads which are permanent, live loads can
                  change in magnitude and position over time. These include the weight of people, furniture, equipment,
                  vehicles, stored materials, and movable partitions. Live loads also encompass environmental factors
                  such as wind pressure, snow accumulation, and seismic forces in some design codes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The magnitude of live loads varies significantly depending on the building's intended use and
                  occupancy. Residential buildings typically have lower live loads (1.5-2.0 kN/m² or 30-40 lb/ft²)
                  compared to commercial offices (2.5-4.0 kN/m² or 50-80 lb/ft²) or industrial facilities (5.0-7.5
                  kN/m² or 100-150 lb/ft²). Building codes specify minimum live load values for different occupancy
                  types to ensure structural safety under normal and anticipated extreme loading conditions.
                </p>
              </CardContent>
            </Card>

            {/* How Live Load is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How is Live Load Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Live load calculation starts with determining the area over which the load will be applied and the
                  appropriate unit load for the building's use type. For example, an office space of 100 m² with a
                  standard live load of 2.5 kN/m² and a safety factor of 1.5 would have a total live load of: 100 m² ×
                  2.5 kN/m² × 1.5 = 375 kN. This represents the total variable load the floor structure must be
                  designed to support.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For multi-story buildings, live loads are often considered floor by floor, though some codes allow
                  for live load reduction in columns and foundations supporting multiple floors, as it's statistically
                  unlikely that all floors will experience maximum loading simultaneously. The calculated live loads,
                  combined with dead loads and other factors, determine the required strength and size of structural
                  elements including beams, slabs, columns, and foundations.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      How do live loads differ from dead loads?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Dead loads are permanent and constant (building materials, fixed equipment), while live loads are
                      temporary and variable (people, furniture, movable equipment). Both are critical for structural
                      design, but live loads require safety factors to account for potential variations and peak usage
                      scenarios.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      Can live loads be reduced for upper floors?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Yes, many building codes allow live load reduction for columns, walls, and foundations supporting
                      multiple floors, since maximum loading on all floors simultaneously is statistically improbable.
                      Reduction factors depend on the tributary area and number of floors supported. Specific reduction
                      formulas are provided in building codes.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What about special occupancies?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Special occupancies like libraries, archives, heavy storage, gymnasiums, and assembly halls may
                      require higher live loads (up to 10-12 kN/m² or 200-250 lb/ft²). Always consult building codes
                      and consider actual expected usage when determining appropriate live load values for design.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-900">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p className="leading-relaxed">
                      Live load values provided by this calculator are indicative and for preliminary estimation only.
                      Actual design loads must comply with local building codes, structural engineering standards, and
                      specific project requirements. Always consult with qualified structural engineers and verify all
                      calculations against applicable codes before final design implementation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
