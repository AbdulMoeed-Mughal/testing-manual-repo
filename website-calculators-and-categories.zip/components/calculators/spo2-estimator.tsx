"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Wind,
  Info,
  AlertTriangle,
  Activity,
  ChevronDown,
  ChevronUp,
  Mountain,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

type ActivityLevel = "resting" | "light" | "moderate" | "high"
type Gender = "male" | "female"

interface SpO2Result {
  value: number
  category: string
  color: string
  bgColor: string
  description: string
  recommendations: string[]
}

export function SpO2Estimator() {
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<Gender>("male")
  const [heartRate, setHeartRate] = useState("")
  const [respiratoryRate, setRespiratoryRate] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("resting")
  const [useAltitude, setUseAltitude] = useState(false)
  const [altitude, setAltitude] = useState("")
  const [altitudeUnit, setAltitudeUnit] = useState<"meters" | "feet">("meters")
  const [hasRespiratoryCondition, setHasRespiratoryCondition] = useState(false)
  const [result, setResult] = useState<SpO2Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const activityLevels: { value: ActivityLevel; label: string; description: string }[] = [
    { value: "resting", label: "Resting", description: "Sitting or lying down" },
    { value: "light", label: "Light", description: "Walking, light stretching" },
    { value: "moderate", label: "Moderate", description: "Brisk walking, cycling" },
    { value: "high", label: "High", description: "Running, intense exercise" },
  ]

  const calculateSpO2 = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const hrNum = Number.parseFloat(heartRate)
    const rrNum = Number.parseFloat(respiratoryRate)

    if (isNaN(ageNum) || ageNum < 1 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120 years")
      return
    }

    if (isNaN(hrNum) || hrNum < 30 || hrNum > 220) {
      setError("Please enter a valid heart rate between 30 and 220 bpm")
      return
    }

    if (isNaN(rrNum) || rrNum < 5 || rrNum > 60) {
      setError("Please enter a valid respiratory rate between 5 and 60 breaths/min")
      return
    }

    // Base SpO2 estimation (starting from normal baseline)
    let baseSpO2 = 98

    // Heart rate adjustment
    // Normal resting HR: 60-100 bpm
    // Higher HR at rest may indicate stress on the cardiovascular system
    if (activityLevel === "resting") {
      if (hrNum < 60) {
        baseSpO2 += 0.5 // Athletes often have lower resting HR with good oxygenation
      } else if (hrNum > 100) {
        baseSpO2 -= (hrNum - 100) * 0.05 // Higher resting HR may indicate issues
      }
    } else if (activityLevel === "light") {
      if (hrNum > 120) baseSpO2 -= (hrNum - 120) * 0.03
    } else if (activityLevel === "moderate") {
      if (hrNum > 150) baseSpO2 -= (hrNum - 150) * 0.02
    } else if (activityLevel === "high") {
      if (hrNum > 180) baseSpO2 -= (hrNum - 180) * 0.02
    }

    // Respiratory rate adjustment
    // Normal: 12-20 breaths/min at rest
    if (activityLevel === "resting") {
      if (rrNum < 12) {
        baseSpO2 -= 0.5 // Very low may indicate hypoventilation
      } else if (rrNum > 20) {
        baseSpO2 -= (rrNum - 20) * 0.1 // High at rest may indicate compensation
      }
    } else {
      // During activity, higher respiratory rates are normal
      const expectedRR = activityLevel === "light" ? 20 : activityLevel === "moderate" ? 25 : 30
      if (rrNum > expectedRR + 10) {
        baseSpO2 -= (rrNum - expectedRR - 10) * 0.08
      }
    }

    // Age adjustment
    if (ageNum > 60) {
      baseSpO2 -= (ageNum - 60) * 0.02 // Slight decline with age
    }

    // Gender adjustment (minor)
    if (gender === "female") {
      baseSpO2 += 0.2 // Women tend to have slightly higher SpO2
    }

    // Altitude adjustment
    if (useAltitude && altitude) {
      let altitudeMeters = Number.parseFloat(altitude)
      if (altitudeUnit === "feet") {
        altitudeMeters = altitudeMeters * 0.3048
      }

      if (!isNaN(altitudeMeters) && altitudeMeters > 0) {
        // SpO2 decreases with altitude
        // At sea level: ~98%, at 2500m: ~92%, at 5000m: ~85%
        if (altitudeMeters > 1500) {
          baseSpO2 -= (altitudeMeters - 1500) * 0.002
        }
        if (altitudeMeters > 3000) {
          baseSpO2 -= (altitudeMeters - 3000) * 0.003
        }
      }
    }

    // Respiratory condition adjustment
    if (hasRespiratoryCondition) {
      baseSpO2 -= 3 // Significant reduction for known conditions
    }

    // Clamp to realistic range
    const estimatedSpO2 = Math.max(70, Math.min(100, Math.round(baseSpO2 * 10) / 10))

    // Determine category
    let category: string
    let color: string
    let bgColor: string
    let description: string
    let recommendations: string[]

    if (estimatedSpO2 >= 95) {
      category = "Normal"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      description = "Your estimated oxygen saturation is within the normal healthy range."
      recommendations = [
        "Continue maintaining your current activity and lifestyle",
        "Stay hydrated and maintain good posture for optimal breathing",
        "Regular cardiovascular exercise can help maintain healthy oxygenation",
      ]
    } else if (estimatedSpO2 >= 90) {
      category = "Mild Hypoxemia"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
      description =
        "Your estimated oxygen saturation is slightly below normal. This may be normal at high altitude or during intense exercise."
      recommendations = [
        "Consider resting if you're not at high altitude",
        "Practice deep breathing exercises",
        "Monitor for symptoms like shortness of breath or fatigue",
        "Consult a healthcare provider if this persists at rest",
      ]
    } else if (estimatedSpO2 >= 85) {
      category = "Moderate Hypoxemia"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
      description = "Your estimated oxygen saturation suggests moderate hypoxemia. Medical evaluation is recommended."
      recommendations = [
        "Seek medical attention if experiencing symptoms",
        "Rest and avoid strenuous activity",
        "If at high altitude, consider descending",
        "Use supplemental oxygen if available and prescribed",
      ]
    } else {
      category = "Severe Hypoxemia"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
      description =
        "Your estimated oxygen saturation indicates severe hypoxemia. Immediate medical attention may be needed."
      recommendations = [
        "Seek immediate medical attention",
        "Call emergency services if experiencing severe symptoms",
        "Remain calm and try to breathe slowly and deeply",
        "Use supplemental oxygen immediately if available",
      ]
    }

    setResult({
      value: estimatedSpO2,
      category,
      color,
      bgColor,
      description,
      recommendations,
    })
  }

  const handleReset = () => {
    setAge("")
    setGender("male")
    setHeartRate("")
    setRespiratoryRate("")
    setActivityLevel("resting")
    setUseAltitude(false)
    setAltitude("")
    setAltitudeUnit("meters")
    setHasRespiratoryCondition(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Estimated SpO₂: ${result.value}% (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Estimated SpO₂ Result",
          text: `I estimated my blood oxygen saturation using CalcHub! Estimated SpO₂: ${result.value}% (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-50 text-sky-600">
                    <Wind className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">SpO₂ Estimator</CardTitle>
                    <CardDescription>Estimate blood oxygen saturation</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["male", "female"] as Gender[]).map((g) => (
                      <button
                        key={g}
                        onClick={() => setGender(g)}
                        className={`p-3 rounded-lg border-2 text-center transition-all ${
                          gender === g
                            ? "border-primary bg-primary/5 text-primary"
                            : "border-muted hover:border-muted-foreground/30"
                        }`}
                      >
                        <span className="font-medium capitalize">{g}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Heart Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="heartRate">Heart Rate (bpm)</Label>
                  <Input
                    id="heartRate"
                    type="number"
                    placeholder="Enter heart rate in beats per minute"
                    value={heartRate}
                    onChange={(e) => setHeartRate(e.target.value)}
                    min="30"
                    max="220"
                  />
                </div>

                {/* Respiratory Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="respiratoryRate">Respiratory Rate (breaths/min)</Label>
                  <Input
                    id="respiratoryRate"
                    type="number"
                    placeholder="Enter breaths per minute"
                    value={respiratoryRate}
                    onChange={(e) => setRespiratoryRate(e.target.value)}
                    min="5"
                    max="60"
                  />
                </div>

                {/* Activity Level Selection */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {activityLevels.map((level) => (
                      <button
                        key={level.value}
                        onClick={() => setActivityLevel(level.value)}
                        className={`p-3 rounded-lg border-2 text-left transition-all ${
                          activityLevel === level.value
                            ? "border-primary bg-primary/5"
                            : "border-muted hover:border-muted-foreground/30"
                        }`}
                      >
                        <span className="font-medium block">{level.label}</span>
                        <span className="text-xs text-muted-foreground">{level.description}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Altitude Toggle */}
                <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="altitude-toggle" className="flex items-center gap-2">
                      <Mountain className="h-4 w-4" />
                      Include Altitude
                    </Label>
                    <Switch id="altitude-toggle" checked={useAltitude} onCheckedChange={setUseAltitude} />
                  </div>

                  {useAltitude && (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          placeholder="Altitude"
                          value={altitude}
                          onChange={(e) => setAltitude(e.target.value)}
                          min="0"
                          className="flex-1"
                        />
                        <select
                          value={altitudeUnit}
                          onChange={(e) => setAltitudeUnit(e.target.value as "meters" | "feet")}
                          className="px-3 rounded-md border border-input bg-background"
                        >
                          <option value="meters">m</option>
                          <option value="feet">ft</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>

                {/* Respiratory Condition Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <Label htmlFor="respiratory-condition" className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Known Respiratory Condition
                  </Label>
                  <Switch
                    id="respiratory-condition"
                    checked={hasRespiratoryCondition}
                    onCheckedChange={setHasRespiratoryCondition}
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSpO2} className="w-full" size="lg">
                  Estimate SpO₂
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated SpO₂</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.value}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details & Recommendations
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-4">
                        <div className="text-sm text-muted-foreground">
                          <p className="mb-3">{result.description}</p>
                          <p className="font-medium text-foreground mb-2">Recommendations:</p>
                          <ul className="space-y-1">
                            {result.recommendations.map((rec, index) => (
                              <li key={index} className="flex items-start gap-2">
                                <span className="text-primary mt-1">•</span>
                                <span>{rec}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div className="p-2 bg-background/50 rounded">
                            <p className="text-muted-foreground">Heart Rate</p>
                            <p className="font-semibold">{heartRate} bpm</p>
                          </div>
                          <div className="p-2 bg-background/50 rounded">
                            <p className="text-muted-foreground">Respiratory Rate</p>
                            <p className="font-semibold">{respiratoryRate} /min</p>
                          </div>
                          <div className="p-2 bg-background/50 rounded">
                            <p className="text-muted-foreground">Activity</p>
                            <p className="font-semibold capitalize">{activityLevel}</p>
                          </div>
                          {useAltitude && altitude && (
                            <div className="p-2 bg-background/50 rounded">
                              <p className="text-muted-foreground">Altitude</p>
                              <p className="font-semibold">
                                {altitude} {altitudeUnit}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">SpO₂ Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Normal</span>
                      <span className="text-sm text-green-600">95–100%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Mild Hypoxemia</span>
                      <span className="text-sm text-yellow-600">90–94%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Moderate Hypoxemia</span>
                      <span className="text-sm text-orange-600">85–89%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Severe Hypoxemia</span>
                      <span className="text-sm text-red-600">{"< 85%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Normal Vital Signs</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Heart Rate (Resting)</p>
                    <p className="text-muted-foreground">60–100 beats per minute</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Respiratory Rate (Resting)</p>
                    <p className="text-muted-foreground">12–20 breaths per minute</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">SpO₂ at Sea Level</p>
                    <p className="text-muted-foreground">95–100%</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Altitude Effects</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 bg-muted rounded">
                      <p className="font-medium text-foreground">Sea Level</p>
                      <p>SpO₂: 95–100%</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-medium text-foreground">2,500m (8,200ft)</p>
                      <p>SpO₂: 90–95%</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-medium text-foreground">4,000m (13,100ft)</p>
                      <p>SpO₂: 85–90%</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-medium text-foreground">5,500m (18,000ft)</p>
                      <p>SpO₂: 80–85%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Blood Oxygen Saturation (SpO₂)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Blood oxygen saturation, measured as SpO₂ (peripheral capillary oxygen saturation), indicates the
                  percentage of hemoglobin in your blood that is bound to oxygen. Hemoglobin is the protein in red blood
                  cells responsible for carrying oxygen from your lungs to tissues throughout your body. A healthy SpO₂
                  level typically ranges from 95% to 100% at sea level, meaning that nearly all of your hemoglobin
                  molecules are carrying oxygen.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  SpO₂ is a vital sign that healthcare providers monitor to assess respiratory and cardiovascular
                  function. Low oxygen saturation (hypoxemia) can indicate various conditions including respiratory
                  disorders, heart problems, anemia, or altitude-related effects. Modern pulse oximeters measure SpO₂
                  non-invasively using light absorption through the fingertip or earlobe.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Oxygen Saturation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors can influence your blood oxygen saturation levels. Understanding these factors helps
                  interpret SpO₂ readings in the proper context and identify potential causes of low oxygen levels.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-sky-50 border border-sky-200 rounded-lg">
                    <h4 className="font-semibold text-sky-800 mb-2">Altitude</h4>
                    <p className="text-sky-700 text-sm">
                      At higher altitudes, atmospheric pressure decreases, reducing the amount of oxygen available for
                      breathing. SpO₂ levels naturally decrease at altitude, with acclimatization occurring over days to
                      weeks.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Physical Activity</h4>
                    <p className="text-blue-700 text-sm">
                      During exercise, oxygen demand increases. While healthy individuals maintain normal SpO₂ during
                      activity, those with respiratory or cardiovascular conditions may experience oxygen desaturation.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Respiratory Conditions</h4>
                    <p className="text-purple-700 text-sm">
                      Conditions like COPD, asthma, pneumonia, and COVID-19 can impair gas exchange in the lungs,
                      leading to lower oxygen saturation levels even at rest.
                    </p>
                  </div>
                  <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                    <h4 className="font-semibold text-indigo-800 mb-2">Age and Overall Health</h4>
                    <p className="text-indigo-700 text-sm">
                      Older adults may have slightly lower baseline SpO₂ levels. Cardiovascular health, anemia, and
                      other systemic conditions can also affect oxygenation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <CardTitle>When to Seek Medical Attention</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While this calculator provides estimates based on physiological parameters, actual SpO₂ should be
                  measured with a pulse oximeter for accuracy. Seek medical attention if you experience:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>• Shortness of breath or difficulty breathing</li>
                  <li>• Bluish discoloration of lips, face, or fingernails (cyanosis)</li>
                  <li>• Chest pain or tightness</li>
                  <li>• Confusion or altered mental status</li>
                  <li>• Rapid or irregular heartbeat</li>
                  <li>• Measured SpO₂ consistently below 92% at rest</li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Important Medical Disclaimer</p>
                    <p>
                      SpO₂ estimates are for informational purposes only and may not reflect actual blood oxygen levels.
                      This calculator cannot replace medical-grade pulse oximetry or clinical evaluation. Do not use
                      this tool to diagnose or treat any medical condition. Consult a healthcare professional for
                      accurate measurement and evaluation of your oxygen saturation, especially if you have symptoms of
                      respiratory distress or cardiovascular issues.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
