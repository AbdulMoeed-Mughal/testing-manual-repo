"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Building2, Info, Calculator, DollarSign } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type CurrencyType = "inr" | "usd"

interface CostResult {
  totalCost: number
  costPerFloor: number
  basicCost: number
  finishingCost: number
  currency: CurrencyType
}

export function ConstructionCostPerSqFtCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [currencyType, setCurrencyType] = useState<CurrencyType>("usd")
  const [area, setArea] = useState("")
  const [costPerUnit, setCostPerUnit] = useState("")
  const [numFloors, setNumFloors] = useState("1")
  const [finishingCost, setFinishingCost] = useState("")
  const [result, setResult] = useState<CostResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCost = () => {
    setError("")
    setResult(null)

    const areaNum = Number.parseFloat(area)
    const costNum = Number.parseFloat(costPerUnit)
    const floorsNum = Number.parseInt(numFloors) || 1
    const finishingNum = Number.parseFloat(finishingCost) || 0

    if (isNaN(areaNum) || areaNum <= 0) {
      setError("Please enter a valid area greater than 0")
      return
    }

    if (isNaN(costNum) || costNum <= 0) {
      setError("Please enter a valid cost per unit greater than 0")
      return
    }

    if (floorsNum < 1) {
      setError("Number of floors must be at least 1")
      return
    }

    const basicCost = areaNum * costNum
    const totalCostPerFloor = basicCost + finishingNum
    const totalCost = totalCostPerFloor * floorsNum

    setResult({
      totalCost,
      costPerFloor: totalCostPerFloor,
      basicCost,
      finishingCost: finishingNum,
      currency: currencyType,
    })
  }

  const handleReset = () => {
    setArea("")
    setCostPerUnit("")
    setNumFloors("1")
    setFinishingCost("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const formatCurrency = (value: number, currency: CurrencyType) => {
    if (currency === "inr") {
      return `₹${value.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`
    }
    return `$${value.toLocaleString("en-US", { maximumFractionDigits: 0 })}`
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Construction Cost Estimate:\nTotal Cost: ${formatCurrency(result.totalCost, result.currency)}\nCost per Floor: ${formatCurrency(result.costPerFloor, result.currency)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Construction Cost Estimate",
          text: `Total Construction Cost: ${formatCurrency(result.totalCost, result.currency)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setArea("")
    setCostPerUnit("")
    setResult(null)
    setError("")
  }

  const toggleCurrency = () => {
    setCurrencyType((prev) => (prev === "inr" ? "usd" : "inr"))
    setCostPerUnit("")
    setResult(null)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Construction Cost per Sq Ft</CardTitle>
                    <CardDescription>Estimate total construction cost</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      m²
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      ft²
                    </span>
                  </button>
                </div>

                {/* Currency Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <button
                    onClick={toggleCurrency}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        currencyType === "inr" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        currencyType === "usd" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      USD ($)
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        currencyType === "inr" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      INR (₹)
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="area">Plinth / Built-up Area ({unitSystem === "metric" ? "m²" : "ft²"})</Label>
                  <Input
                    id="area"
                    type="number"
                    placeholder={`Enter area in ${unitSystem === "metric" ? "square meters" : "square feet"}`}
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Cost per Unit Input */}
                <div className="space-y-2">
                  <Label htmlFor="costPerUnit">
                    Cost per Unit ({currencyType === "inr" ? "₹" : "$"}/{unitSystem === "metric" ? "m²" : "ft²"})
                  </Label>
                  <Input
                    id="costPerUnit"
                    type="number"
                    placeholder="Enter cost per unit area"
                    value={costPerUnit}
                    onChange={(e) => setCostPerUnit(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Number of Floors */}
                <div className="space-y-2">
                  <Label htmlFor="numFloors">Number of Floors</Label>
                  <Input
                    id="numFloors"
                    type="number"
                    placeholder="Enter number of floors"
                    value={numFloors}
                    onChange={(e) => setNumFloors(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Finishing Cost (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="finishingCost">
                    Finishing & Utilities Cost (Optional) ({currencyType === "inr" ? "₹" : "$"})
                  </Label>
                  <Input
                    id="finishingCost"
                    type="number"
                    placeholder="Enter additional finishing cost"
                    value={finishingCost}
                    onChange={(e) => setFinishingCost(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCost} className="w-full" size="lg">
                  Calculate Cost
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Construction Cost</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {formatCurrency(result.totalCost, result.currency)}
                        </p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Cost per Floor:</span>
                          <span className="font-semibold text-amber-700">
                            {formatCurrency(result.costPerFloor, result.currency)}
                          </span>
                        </div>
                        {result.finishingCost > 0 && (
                          <>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Basic Cost:</span>
                              <span className="font-medium text-amber-700">
                                {formatCurrency(result.basicCost, result.currency)}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Finishing Cost:</span>
                              <span className="font-medium text-amber-700">
                                {formatCurrency(result.finishingCost, result.currency)}
                              </span>
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Average Construction Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-muted">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Basic Construction</span>
                        <span className="text-sm text-muted-foreground">$80-120/ft²</span>
                      </div>
                      <p className="text-xs text-muted-foreground">Standard materials and finishes</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Mid-range Construction</span>
                        <span className="text-sm text-muted-foreground">$120-200/ft²</span>
                      </div>
                      <p className="text-xs text-muted-foreground">Quality materials and good finishes</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Premium Construction</span>
                        <span className="text-sm text-muted-foreground">$200-350/ft²</span>
                      </div>
                      <p className="text-xs text-muted-foreground">High-end materials and finishes</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Luxury Construction</span>
                        <span className="text-sm text-muted-foreground">$350+/ft²</span>
                      </div>
                      <p className="text-xs text-muted-foreground">Premium materials and custom work</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cost Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Location and accessibility of site</p>
                  <p>• Quality of materials used</p>
                  <p>• Labor rates in the region</p>
                  <p>• Complexity of design</p>
                  <p>• Building codes and permits</p>
                  <p>• Finishing level and fixtures</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Construction Cost */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Construction Cost per Square Foot</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Construction cost per square foot is a fundamental metric used in the building industry to estimate and
                  compare the total cost of constructing a building project. This measurement divides the total
                  construction cost by the total built-up area, providing a standardized way to evaluate project expenses
                  regardless of building size. Understanding this metric helps property owners, developers, and contractors
                  budget effectively and make informed decisions about construction projects.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The cost per square foot typically includes all major construction expenses such as materials, labor,
                  equipment, and basic finishes. However, it may not include land costs, architectural fees, permits,
                  utilities connection, landscaping, or premium finishes unless specifically stated. This metric varies
                  significantly based on geographic location, local labor rates, material costs, building type, quality of
                  construction, and current market conditions.
                </p>
              </CardContent>
            </Card>

            {/* Cost Components */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Components of Construction Cost</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Construction costs can be broken down into several major components. The structural work, including
                  foundation, columns, beams, and slab, typically accounts for 30-40% of total costs. Materials like
                  cement, steel, and aggregates form a significant portion of this expense. The quality and grade of
                  materials chosen directly impact both cost and building durability.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Labor costs usually represent 25-35% of total construction expenses and vary widely by region. Finishing
                  work, including flooring, painting, plastering, and tiling, accounts for another 20-25%. Electrical and
                  plumbing installations add 10-15%, while doors, windows, and fixtures contribute about 8-12% to the total
                  cost. Additional expenses include waterproofing, architectural fees, permits, and contingencies for
                  unforeseen issues.
                </p>
              </CardContent>
            </Card>

            {/* How to Use Calculator */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To estimate your construction cost, start by entering the plinth or built-up area of your planned
                  building in either square meters or square feet. Next, input your estimated cost per unit area based on
                  your location and quality requirements. You can refer to the average construction rates provided for
                  guidance, but remember that actual rates may vary based on your specific circumstances.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  If you're planning a multi-story building, enter the number of floors to calculate the total project
                  cost. Optionally, you can add finishing and utilities costs if you have separate estimates for these
                  items. The calculator will provide you with the total construction cost, cost per floor, and a breakdown
                  of basic versus finishing costs. Use these estimates as a starting point for your budget planning, and
                  always add a contingency of 10-20% for unforeseen expenses.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Construction cost estimates provided by this calculator are indicative and
                  for planning purposes only. Actual construction costs vary significantly based on material quality, labor
                  rates, design specifications, site conditions, local regulations, and market fluctuations. Always consult
                  with professional contractors and architects for accurate project estimates and detailed cost breakdowns.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
