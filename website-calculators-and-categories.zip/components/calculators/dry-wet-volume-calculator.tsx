"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, ArrowLeftRight, Info, Calculator, Hammer } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type ConversionDirection = "wet-to-dry" | "dry-to-wet"
type VolumeUnit = "m³" | "ft³"

interface ConversionResult {
  inputVolume: number
  convertedVolume: number
  conversionFactor: number
  direction: ConversionDirection
  unit: VolumeUnit
}

export function DryWetVolumeCalculator() {
  const [direction, setDirection] = useState<ConversionDirection>("wet-to-dry")
  const [volumeInput, setVolumeInput] = useState("")
  const [conversionFactor, setConversionFactor] = useState("1.54")
  const [unit, setUnit] = useState<VolumeUnit>("m³")
  const [result, setResult] = useState<ConversionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateConversion = () => {
    setError("")
    setResult(null)

    const volume = Number.parseFloat(volumeInput)
    const factor = Number.parseFloat(conversionFactor)

    if (isNaN(volume) || volume <= 0) {
      setError("Please enter a valid volume greater than 0")
      return
    }

    if (isNaN(factor) || factor <= 1) {
      setError("Conversion factor must be greater than 1")
      return
    }

    let convertedVolume: number
    if (direction === "wet-to-dry") {
      convertedVolume = volume * factor
    } else {
      convertedVolume = volume / factor
    }

    setResult({
      inputVolume: volume,
      convertedVolume: Math.round(convertedVolume * 1000) / 1000,
      conversionFactor: factor,
      direction,
      unit,
    })
  }

  const handleReset = () => {
    setVolumeInput("")
    setConversionFactor("1.54")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `${direction === "wet-to-dry" ? "Wet" : "Dry"} Volume: ${result.inputVolume} ${result.unit} → ${
        direction === "wet-to-dry" ? "Dry" : "Wet"
      } Volume: ${result.convertedVolume} ${result.unit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Dry/Wet Volume Conversion",
          text: `${direction === "wet-to-dry" ? "Wet" : "Dry"} Volume: ${result.inputVolume} ${result.unit} → ${
            direction === "wet-to-dry" ? "Dry" : "Wet"
          } Volume: ${result.convertedVolume} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleDirection = () => {
    setDirection((prev) => (prev === "wet-to-dry" ? "dry-to-wet" : "wet-to-dry"))
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <ArrowLeftRight className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Dry/Wet Volume Calculator</CardTitle>
                    <CardDescription>Convert between dry and wet volume</CardDescription>
                  </div>
                </div>

                {/* Direction Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Conversion</span>
                  <button
                    onClick={toggleDirection}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-amber-600 shadow-sm transition-transform duration-200 ${
                        direction === "dry-to-wet" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        direction === "wet-to-dry" ? "text-white" : "text-muted-foreground"
                      }`}
                    >
                      Wet → Dry
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        direction === "dry-to-wet" ? "text-white" : "text-muted-foreground"
                      }`}
                    >
                      Dry → Wet
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Volume Input */}
                <div className="space-y-2">
                  <Label htmlFor="volume">
                    {direction === "wet-to-dry" ? "Wet Volume" : "Dry Volume"} ({unit})
                  </Label>
                  <Input
                    id="volume"
                    type="number"
                    placeholder={`Enter ${direction === "wet-to-dry" ? "wet" : "dry"} volume`}
                    value={volumeInput}
                    onChange={(e) => setVolumeInput(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Conversion Factor */}
                <div className="space-y-2">
                  <Label htmlFor="factor">Dry Volume Factor</Label>
                  <Input
                    id="factor"
                    type="number"
                    placeholder="Enter conversion factor"
                    value={conversionFactor}
                    onChange={(e) => setConversionFactor(e.target.value)}
                    min="1"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">Standard factor: 1.54 (default)</p>
                </div>

                {/* Unit Selection */}
                <div className="space-y-2">
                  <Label>Volume Unit</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={unit === "m³" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setUnit("m³")}
                      className="flex-1"
                    >
                      m³
                    </Button>
                    <Button
                      variant={unit === "ft³" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setUnit("ft³")}
                      className="flex-1"
                    >
                      ft³
                    </Button>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateConversion} className="w-full" size="lg">
                  Convert Volume
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">
                          {result.direction === "wet-to-dry" ? "Dry Volume" : "Wet Volume"}
                        </p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">
                          {result.convertedVolume} {result.unit}
                        </p>
                        <p className="text-sm text-amber-700">Conversion Factor: {result.conversionFactor}</p>
                      </div>

                      <div className="pt-2 border-t border-amber-200 space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            {result.direction === "wet-to-dry" ? "Wet Volume:" : "Dry Volume:"}
                          </span>
                          <span className="font-medium">
                            {result.inputVolume} {result.unit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            {result.direction === "wet-to-dry" ? "Dry Volume:" : "Wet Volume:"}
                          </span>
                          <span className="font-medium">
                            {result.convertedVolume} {result.unit}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Dry Volume Factors</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Standard Concrete</span>
                      <span className="text-sm text-amber-600">1.54</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Loose Sand</span>
                      <span className="text-sm text-amber-600">1.25 - 1.30</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Compacted Soil</span>
                      <span className="text-sm text-amber-600">1.20 - 1.25</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conversion Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">Wet to Dry:</p>
                    <p className="font-mono text-center">Dry Volume = Wet Volume × 1.54</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">Dry to Wet:</p>
                    <p className="font-mono text-center">Wet Volume = Dry Volume ÷ 1.54</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Dry/Wet Volume */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-amber-600" />
                  <CardTitle>What is Dry and Wet Volume?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In construction and civil engineering, dry volume and wet volume are critical concepts for accurate
                  material estimation. Wet volume refers to the actual space that a concrete mix or mortar occupies after
                  all components (cement, sand, aggregate, and water) are mixed together. This is the volume you see in
                  the final product or in the formwork before pouring.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Dry volume, on the other hand, represents the total volume of all dry ingredients (cement, sand, and
                  aggregate) before water is added and before they are mixed. Due to the presence of voids between
                  particles in dry materials, the dry volume is always greater than the wet volume. When water is added
                  and materials are mixed, the water fills these voids, causing the volume to decrease. Understanding this
                  relationship is essential for calculating the correct quantities of materials needed for construction
                  projects.
                </p>
              </CardContent>
            </Card>

            {/* Why the Conversion Factor */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-amber-600" />
                  <CardTitle>Why Use a Conversion Factor of 1.54?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The standard conversion factor of 1.54 is derived from the volume increase caused by voids between
                  particles in dry materials. In concrete and mortar mixes, approximately 54% more dry material is needed
                  to achieve the desired wet volume. This factor accounts for the air spaces between cement particles,
                  sand grains, and aggregate stones before mixing.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When calculating material requirements for concrete, engineers multiply the required wet volume (the
                  volume of the structure) by 1.54 to determine how much dry material to order. For example, if you need
                  1 cubic meter of concrete (wet volume), you'll need to start with 1.54 cubic meters of dry materials.
                  This factor may vary slightly depending on the specific materials used, moisture content, and compaction
                  method, but 1.54 is the most commonly accepted standard in the construction industry.
                </p>
              </CardContent>
            </Card>

            {/* Practical Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Hammer className="h-5 w-5 text-amber-600" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The dry-wet volume conversion is used extensively in construction projects for material estimation. When
                  planning concrete pours for foundations, slabs, columns, or beams, contractors calculate the wet volume
                  needed from structural drawings. They then convert this to dry volume to determine how much cement, sand,
                  and aggregate to purchase. This ensures accurate ordering and minimizes waste.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Beyond concrete work, this conversion is also important for mortar calculations in masonry, plaster work,
                  and other construction activities. Accurate volume conversions help in cost estimation, project planning,
                  and resource allocation. Using the wrong conversion or ignoring it entirely can lead to material
                  shortages during construction or excessive waste and unnecessary costs.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Dry volume factor varies based on material type and compaction. Use
                  standard factor only for estimation. For critical structural projects, consult with a structural
                  engineer or material supplier for precise conversion factors specific to your materials.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
