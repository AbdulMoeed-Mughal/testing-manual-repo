"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  ShoppingCart,
  Info,
  Percent,
  Tag,
  DollarSign,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type Currency = "USD" | "EUR" | "GBP" | "INR" | "CAD" | "AUD" | "JPY" | "CNY"

interface DiscountResult {
  originalPrice: number
  discountPercent: number
  discountAmount: number
  priceAfterDiscount: number
  taxAmount: number
  finalPrice: number
  totalSavings: number
  quantity: number
  totalOriginal: number
  totalFinal: number
  totalSavingsAll: number
}

const currencySymbols: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  INR: "₹",
  CAD: "C$",
  AUD: "A$",
  JPY: "¥",
  CNY: "¥",
}

export function DiscountCalculator() {
  const [originalPrice, setOriginalPrice] = useState("")
  const [discountPercent, setDiscountPercent] = useState("")
  const [taxPercent, setTaxPercent] = useState("")
  const [quantity, setQuantity] = useState("1")
  const [includeTax, setIncludeTax] = useState(false)
  const [roundResult, setRoundResult] = useState(false)
  const [currency, setCurrency] = useState<Currency>("USD")
  const [result, setResult] = useState<DiscountResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateDiscount = () => {
    setError("")
    setResult(null)

    const price = Number.parseFloat(originalPrice)
    const discount = Number.parseFloat(discountPercent)
    const tax = includeTax ? Number.parseFloat(taxPercent) || 0 : 0
    const qty = Number.parseInt(quantity) || 1

    if (isNaN(price) || price <= 0) {
      setError("Please enter a valid original price greater than 0")
      return
    }

    if (isNaN(discount) || discount < 0 || discount > 100) {
      setError("Please enter a valid discount percentage between 0 and 100")
      return
    }

    if (includeTax && (isNaN(tax) || tax < 0)) {
      setError("Please enter a valid tax percentage (0 or greater)")
      return
    }

    if (qty < 1) {
      setError("Quantity must be at least 1")
      return
    }

    // Calculate discount
    const discountAmount = price * (discount / 100)
    let priceAfterDiscount = price - discountAmount

    // Calculate tax
    const taxAmount = includeTax ? priceAfterDiscount * (tax / 100) : 0
    let finalPrice = priceAfterDiscount + taxAmount

    // Round if enabled
    if (roundResult) {
      priceAfterDiscount = Math.round(priceAfterDiscount * 100) / 100
      finalPrice = Math.ceil(finalPrice)
    }

    const totalSavings = discountAmount
    const totalOriginal = price * qty
    const totalFinal = finalPrice * qty
    const totalSavingsAll = discountAmount * qty

    setResult({
      originalPrice: price,
      discountPercent: discount,
      discountAmount: roundResult ? Math.round(discountAmount * 100) / 100 : discountAmount,
      priceAfterDiscount,
      taxAmount: roundResult ? Math.round(taxAmount * 100) / 100 : taxAmount,
      finalPrice,
      totalSavings,
      quantity: qty,
      totalOriginal,
      totalFinal,
      totalSavingsAll: roundResult ? Math.round(totalSavingsAll * 100) / 100 : totalSavingsAll,
    })
  }

  const handleReset = () => {
    setOriginalPrice("")
    setDiscountPercent("")
    setTaxPercent("")
    setQuantity("1")
    setIncludeTax(false)
    setRoundResult(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Discount Calculation:
Original Price: ${currencySymbols[currency]}${result.originalPrice.toFixed(2)}
Discount: ${result.discountPercent}% (${currencySymbols[currency]}${result.discountAmount.toFixed(2)} off)
${includeTax ? `Tax: ${taxPercent}% (${currencySymbols[currency]}${result.taxAmount.toFixed(2)})\n` : ""}Final Price: ${currencySymbols[currency]}${result.finalPrice.toFixed(2)}
You Save: ${currencySymbols[currency]}${result.totalSavings.toFixed(2)}${result.quantity > 1 ? `\nQuantity: ${result.quantity}\nTotal: ${currencySymbols[currency]}${result.totalFinal.toFixed(2)}` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Discount Calculator Result",
          text: `I saved ${currencySymbols[currency]}${result.totalSavings.toFixed(2)} (${result.discountPercent}% off) on my purchase! Final price: ${currencySymbols[currency]}${result.finalPrice.toFixed(2)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return `${currencySymbols[currency]}${value.toFixed(2)}`
  }

  // Quick discount presets
  const discountPresets = [5, 10, 15, 20, 25, 30, 40, 50]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/lifestyle-daily">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Lifestyle & Daily Use
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Tag className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Discount Calculator</CardTitle>
                    <CardDescription>Calculate savings and final price</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="INR">INR (₹)</option>
                    <option value="CAD">CAD (C$)</option>
                    <option value="AUD">AUD (A$)</option>
                    <option value="JPY">JPY (¥)</option>
                    <option value="CNY">CNY (¥)</option>
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Original Price Input */}
                <div className="space-y-2">
                  <Label htmlFor="originalPrice">Original Price</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="originalPrice"
                      type="number"
                      placeholder="Enter original price"
                      value={originalPrice}
                      onChange={(e) => setOriginalPrice(e.target.value)}
                      className="pl-9"
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Discount Percentage Input */}
                <div className="space-y-2">
                  <Label htmlFor="discountPercent">Discount Percentage (%)</Label>
                  <div className="relative">
                    <Percent className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="discountPercent"
                      type="number"
                      placeholder="Enter discount percentage"
                      value={discountPercent}
                      onChange={(e) => setDiscountPercent(e.target.value)}
                      className="pl-9"
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  </div>
                  {/* Quick discount presets */}
                  <div className="flex flex-wrap gap-2 pt-1">
                    {discountPresets.map((preset) => (
                      <Button
                        key={preset}
                        type="button"
                        variant={discountPercent === preset.toString() ? "default" : "outline"}
                        size="sm"
                        className="h-7 px-2 text-xs"
                        onClick={() => setDiscountPercent(preset.toString())}
                      >
                        {preset}%
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Quantity Input */}
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity (optional)</Label>
                  <div className="relative">
                    <ShoppingCart className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="quantity"
                      type="number"
                      placeholder="1"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      className="pl-9"
                      min="1"
                      step="1"
                    />
                  </div>
                </div>

                {/* Tax Toggle and Input */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="includeTax" className="cursor-pointer">
                      Include Tax
                    </Label>
                    <Switch id="includeTax" checked={includeTax} onCheckedChange={setIncludeTax} />
                  </div>

                  {includeTax && (
                    <div className="space-y-2">
                      <Label htmlFor="taxPercent">Tax Percentage (%)</Label>
                      <Input
                        id="taxPercent"
                        type="number"
                        placeholder="Enter tax percentage"
                        value={taxPercent}
                        onChange={(e) => setTaxPercent(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  )}
                </div>

                {/* Round Result Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="roundResult" className="cursor-pointer">
                    Round Final Price Up
                  </Label>
                  <Switch id="roundResult" checked={roundResult} onCheckedChange={setRoundResult} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDiscount} className="w-full" size="lg">
                  Calculate Discount
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center space-y-4">
                      {/* Final Price */}
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Final Price</p>
                        <p className="text-4xl font-bold text-green-600">{formatCurrency(result.finalPrice)}</p>
                        {result.quantity > 1 && (
                          <p className="text-sm text-muted-foreground mt-1">
                            Total for {result.quantity} items: {formatCurrency(result.totalFinal)}
                          </p>
                        )}
                      </div>

                      {/* Savings */}
                      <div className="flex items-center justify-center gap-2">
                        <Tag className="h-5 w-5 text-pink-500" />
                        <span className="text-lg font-semibold text-pink-600">
                          You Save {formatCurrency(result.quantity > 1 ? result.totalSavingsAll : result.totalSavings)}{" "}
                          ({result.discountPercent}% off)
                        </span>
                      </div>

                      {/* Breakdown */}
                      <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full">
                            {showBreakdown ? (
                              <ChevronUp className="h-4 w-4 mr-2" />
                            ) : (
                              <ChevronDown className="h-4 w-4 mr-2" />
                            )}
                            {showBreakdown ? "Hide" : "Show"} Breakdown
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-3 p-3 bg-white/60 rounded-lg text-sm space-y-2">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Original Price:</span>
                              <span className="font-medium">{formatCurrency(result.originalPrice)}</span>
                            </div>
                            <div className="flex justify-between text-pink-600">
                              <span>Discount ({result.discountPercent}%):</span>
                              <span className="font-medium">-{formatCurrency(result.discountAmount)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Price After Discount:</span>
                              <span className="font-medium">{formatCurrency(result.priceAfterDiscount)}</span>
                            </div>
                            {includeTax && result.taxAmount > 0 && (
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Tax ({taxPercent}%):</span>
                                <span className="font-medium">+{formatCurrency(result.taxAmount)}</span>
                              </div>
                            )}
                            <div className="border-t pt-2 flex justify-between font-semibold">
                              <span>Final Price (per item):</span>
                              <span className="text-green-600">{formatCurrency(result.finalPrice)}</span>
                            </div>
                            {result.quantity > 1 && (
                              <>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Quantity:</span>
                                  <span className="font-medium">×{result.quantity}</span>
                                </div>
                                <div className="flex justify-between font-semibold">
                                  <span>Total:</span>
                                  <span className="text-green-600">{formatCurrency(result.totalFinal)}</span>
                                </div>
                                <div className="flex justify-between text-pink-600">
                                  <span>Total Savings:</span>
                                  <span className="font-medium">{formatCurrency(result.totalSavingsAll)}</span>
                                </div>
                              </>
                            )}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Discount Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Discount = Price × (% ÷ 100)</p>
                    <p className="font-semibold text-foreground">Final = Price − Discount + Tax</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Discount Scenarios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-pink-50 border border-pink-200">
                      <span className="font-medium text-pink-700">Flash Sale</span>
                      <span className="text-sm text-pink-600">20-50% off</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Clearance</span>
                      <span className="text-sm text-orange-600">50-70% off</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Member Discount</span>
                      <span className="text-sm text-blue-600">10-15% off</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Coupon Code</span>
                      <span className="text-sm text-green-600">5-25% off</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Tax Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-muted rounded">
                      <span className="font-medium">US (varies)</span>
                      <span className="text-muted-foreground block">0-10%</span>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-medium">UK VAT</span>
                      <span className="text-muted-foreground block">20%</span>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-medium">EU VAT</span>
                      <span className="text-muted-foreground block">17-27%</span>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-medium">India GST</span>
                      <span className="text-muted-foreground block">5-28%</span>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-medium">Canada GST</span>
                      <span className="text-muted-foreground block">5%</span>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-medium">Australia GST</span>
                      <span className="text-muted-foreground block">10%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Discounts</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Discounts are reductions in the original price of a product or service, typically expressed as a
                  percentage. They are commonly used in retail, e-commerce, and service industries to attract customers,
                  clear inventory, reward loyal customers, or promote special events. Understanding how discounts work
                  helps you make informed purchasing decisions and ensures you get the best value for your money.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The discount calculation is straightforward: multiply the original price by the discount percentage
                  (divided by 100) to get the discount amount, then subtract this from the original price. For example,
                  a 25% discount on a $100 item saves you $25, making the final price $75. When tax is involved, it's
                  typically calculated on the discounted price, not the original price.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Discounts</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Percentage Discount</h4>
                    <p className="text-sm text-muted-foreground">
                      The most common type, where a percentage is taken off the original price. Examples: "20% off",
                      "Save 30%", "Half price sale".
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Fixed Amount Discount</h4>
                    <p className="text-sm text-muted-foreground">
                      A specific dollar amount is subtracted from the price. Examples: "$10 off", "Save $50 on orders
                      over $200".
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">BOGO (Buy One Get One)</h4>
                    <p className="text-sm text-muted-foreground">
                      Buy one item and get another free or at a discount. Examples: "Buy 1 Get 1 Free", "Buy 2 Get 1 50%
                      off".
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Tiered Discount</h4>
                    <p className="text-sm text-muted-foreground">
                      Discount increases with quantity or spending. Examples: "10% off 2 items, 20% off 3 or more".
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Tag className="h-5 w-5 text-primary" />
                  <CardTitle>Smart Shopping Tips</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Compare Unit Prices:</strong> A higher discount doesn't always mean a better deal. Compare
                    the final price per unit across different products.
                  </li>
                  <li>
                    <strong>Check Original Prices:</strong> Some retailers inflate prices before sales. Research the
                    typical price to ensure you're getting a real discount.
                  </li>
                  <li>
                    <strong>Stack Discounts:</strong> Look for opportunities to combine coupons, loyalty rewards, and
                    sale prices for maximum savings.
                  </li>
                  <li>
                    <strong>Consider Total Cost:</strong> Factor in shipping, taxes, and any additional fees when
                    calculating your total savings.
                  </li>
                  <li>
                    <strong>Set a Budget:</strong> Don't buy items just because they're on sale. A discount on something
                    you don't need isn't really saving money.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Discount calculations are estimates. Actual prices may vary depending on store policies, taxes,
                      rounding practices, and any additional fees. Always verify the final price at checkout before
                      completing your purchase.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
