"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  DollarSign,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { formatCurrency, currencySymbols, type Currency } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

type LotType = "standard" | "mini" | "micro" | "nano"
type TradeType = "buy" | "sell"

interface MarginResult {
  positionValue: number
  requiredMargin: number
  freeMargin: number
  marginLevel: number
  usedMarginPercent: number
  lotSize: number
  leverageRatio: number
}

const currencyPairs = [
  { value: "EUR/USD", label: "EUR/USD", contractSize: 100000 },
  { value: "GBP/USD", label: "GBP/USD", contractSize: 100000 },
  { value: "USD/JPY", label: "USD/JPY", contractSize: 100000 },
  { value: "USD/CHF", label: "USD/CHF", contractSize: 100000 },
  { value: "AUD/USD", label: "AUD/USD", contractSize: 100000 },
  { value: "USD/CAD", label: "USD/CAD", contractSize: 100000 },
  { value: "NZD/USD", label: "NZD/USD", contractSize: 100000 },
  { value: "EUR/GBP", label: "EUR/GBP", contractSize: 100000 },
  { value: "EUR/JPY", label: "EUR/JPY", contractSize: 100000 },
  { value: "GBP/JPY", label: "GBP/JPY", contractSize: 100000 },
  { value: "AUD/JPY", label: "AUD/JPY", contractSize: 100000 },
  { value: "EUR/AUD", label: "EUR/AUD", contractSize: 100000 },
  { value: "EUR/CHF", label: "EUR/CHF", contractSize: 100000 },
  { value: "GBP/CHF", label: "GBP/CHF", contractSize: 100000 },
  { value: "CAD/JPY", label: "CAD/JPY", contractSize: 100000 },
  { value: "CHF/JPY", label: "CHF/JPY", contractSize: 100000 },
  { value: "NZD/JPY", label: "NZD/JPY", contractSize: 100000 },
  { value: "AUD/NZD", label: "AUD/NZD", contractSize: 100000 },
]

const lotSizes: Record<LotType, { label: string; multiplier: number }> = {
  standard: { label: "Standard (100,000)", multiplier: 1 },
  mini: { label: "Mini (10,000)", multiplier: 0.1 },
  micro: { label: "Micro (1,000)", multiplier: 0.01 },
  nano: { label: "Nano (100)", multiplier: 0.001 },
}

const leverageOptions = [
  { value: "10", label: "1:10" },
  { value: "20", label: "1:20" },
  { value: "30", label: "1:30" },
  { value: "50", label: "1:50" },
  { value: "100", label: "1:100" },
  { value: "200", label: "1:200" },
  { value: "300", label: "1:300" },
  { value: "400", label: "1:400" },
  { value: "500", label: "1:500" },
]

export function ForexMarginCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [accountBalance, setAccountBalance] = useState("")
  const [currencyPair, setCurrencyPair] = useState("EUR/USD")
  const [lotType, setLotType] = useState<LotType>("standard")
  const [lots, setLots] = useState("1")
  const [leverage, setLeverage] = useState("100")
  const [exchangeRate, setExchangeRate] = useState("1.0850")
  const [tradeType, setTradeType] = useState<TradeType>("buy")
  const [result, setResult] = useState<MarginResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateMargin = () => {
    setError("")
    setResult(null)

    const balance = Number.parseFloat(accountBalance)
    const lotsNum = Number.parseFloat(lots)
    const leverageNum = Number.parseFloat(leverage)
    const rate = Number.parseFloat(exchangeRate)

    if (isNaN(balance) || balance <= 0) {
      setError("Please enter a valid account balance greater than 0")
      return
    }

    if (isNaN(lotsNum) || lotsNum <= 0) {
      setError("Please enter a valid lot size greater than 0")
      return
    }

    if (isNaN(leverageNum) || leverageNum <= 0) {
      setError("Please enter a valid leverage ratio")
      return
    }

    if (isNaN(rate) || rate <= 0) {
      setError("Please enter a valid exchange rate greater than 0")
      return
    }

    // Calculate position value
    const contractSize = 100000 // Standard lot size
    const lotMultiplier = lotSizes[lotType].multiplier
    const actualLotSize = lotsNum * lotMultiplier * contractSize

    // Position value in quote currency
    const positionValue = actualLotSize * rate

    // Required margin
    const requiredMargin = positionValue / leverageNum

    // Free margin
    const freeMargin = balance - requiredMargin

    // Margin level (equity / margin * 100)
    const marginLevel = freeMargin > 0 ? (balance / requiredMargin) * 100 : 0

    // Used margin percentage
    const usedMarginPercent = (requiredMargin / balance) * 100

    setResult({
      positionValue,
      requiredMargin,
      freeMargin,
      marginLevel,
      usedMarginPercent,
      lotSize: actualLotSize,
      leverageRatio: leverageNum,
    })
  }

  const handleReset = () => {
    setAccountBalance("")
    setCurrencyPair("EUR/USD")
    setLotType("standard")
    setLots("1")
    setLeverage("100")
    setExchangeRate("1.0850")
    setTradeType("buy")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Forex Margin Calculation:
Position: ${currencyPair} ${tradeType.toUpperCase()}
Lot Size: ${lots} ${lotSizes[lotType].label}
Leverage: 1:${leverage}
Required Margin: ${formatCurrency(result.requiredMargin, currency)}
Free Margin: ${formatCurrency(result.freeMargin, currency)}
Margin Level: ${result.marginLevel.toFixed(2)}%`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getMarginCategory = (level: number): { label: string; color: string; bgColor: string } => {
    if (level >= 500) return { label: "Very Safe", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    if (level >= 200) return { label: "Safe", color: "text-emerald-600", bgColor: "bg-emerald-50 border-emerald-200" }
    if (level >= 100)
      return { label: "Moderate Risk", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    if (level >= 50) return { label: "High Risk", color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    return { label: "Margin Call Risk", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Forex Margin Calculator</CardTitle>
                    <CardDescription>Calculate required margin for forex positions</CardDescription>
                  </div>
                </div>
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Account Balance */}
                <div className="space-y-2">
                  <Label htmlFor="accountBalance">Account Balance ({currencySymbols[currency]})</Label>
                  <Input
                    id="accountBalance"
                    type="number"
                    placeholder="Enter account balance"
                    value={accountBalance}
                    onChange={(e) => setAccountBalance(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Currency Pair */}
                <div className="space-y-2">
                  <Label>Currency Pair</Label>
                  <Select value={currencyPair} onValueChange={setCurrencyPair}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select currency pair" />
                    </SelectTrigger>
                    <SelectContent>
                      {currencyPairs.map((pair) => (
                        <SelectItem key={pair.value} value={pair.value}>
                          {pair.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Lot Type and Size */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Lot Type</Label>
                    <Select value={lotType} onValueChange={(v) => setLotType(v as LotType)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(lotSizes).map(([key, value]) => (
                          <SelectItem key={key} value={key}>
                            {value.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lots">Number of Lots</Label>
                    <Input
                      id="lots"
                      type="number"
                      placeholder="1"
                      value={lots}
                      onChange={(e) => setLots(e.target.value)}
                      min="0.01"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Leverage and Trade Type */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Leverage</Label>
                    <Select value={leverage} onValueChange={setLeverage}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {leverageOptions.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Trade Type</Label>
                    <Select value={tradeType} onValueChange={(v) => setTradeType(v as TradeType)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="buy">Buy (Long)</SelectItem>
                        <SelectItem value="sell">Sell (Short)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Exchange Rate */}
                <div className="space-y-2">
                  <Label htmlFor="exchangeRate">Exchange Rate</Label>
                  <Input
                    id="exchangeRate"
                    type="number"
                    placeholder="1.0850"
                    value={exchangeRate}
                    onChange={(e) => setExchangeRate(e.target.value)}
                    min="0.0001"
                    step="0.0001"
                  />
                  <p className="text-xs text-muted-foreground">Current rate for {currencyPair}</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMargin} className="w-full" size="lg">
                  Calculate Margin
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getMarginCategory(result.marginLevel).bgColor} transition-all duration-300`}
                  >
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Required Margin</p>
                      <p className={`text-4xl font-bold ${getMarginCategory(result.marginLevel).color}`}>
                        {formatCurrency(result.requiredMargin, currency)}
                      </p>
                      <p className={`text-lg font-semibold ${getMarginCategory(result.marginLevel).color} mt-1`}>
                        {getMarginCategory(result.marginLevel).label}
                      </p>
                    </div>

                    {/* Margin Utilization Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Margin Usage</span>
                        <span className="font-medium">{Math.min(result.usedMarginPercent, 100).toFixed(1)}%</span>
                      </div>
                      <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            result.usedMarginPercent > 80
                              ? "bg-red-500"
                              : result.usedMarginPercent > 50
                                ? "bg-yellow-500"
                                : "bg-green-500"
                          }`}
                          style={{ width: `${Math.min(result.usedMarginPercent, 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Free Margin</p>
                        <p
                          className={`text-lg font-semibold ${result.freeMargin >= 0 ? "text-green-600" : "text-red-600"}`}
                        >
                          {formatCurrency(result.freeMargin, currency)}
                        </p>
                      </div>
                      <div className="p-3 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Margin Level</p>
                        <p className={`text-lg font-semibold ${getMarginCategory(result.marginLevel).color}`}>
                          {result.marginLevel.toFixed(2)}%
                        </p>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? "Hide" : "Show"} Details
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Position Size</span>
                          <span className="font-medium">{result.lotSize.toLocaleString()} units</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Position Value</span>
                          <span className="font-medium">{formatCurrency(result.positionValue, currency)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Leverage Used</span>
                          <span className="font-medium">1:{result.leverageRatio}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Currency Pair</span>
                          <span className="font-medium">{currencyPair}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Trade Direction</span>
                          <span className="font-medium">{tradeType === "buy" ? "Long" : "Short"}</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Margin Level Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Very Safe</span>
                      <span className="text-sm text-green-600">{"≥ 500%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                      <span className="font-medium text-emerald-700">Safe</span>
                      <span className="text-sm text-emerald-600">200% - 499%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Risk</span>
                      <span className="text-sm text-yellow-600">100% - 199%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">High Risk</span>
                      <span className="text-sm text-orange-600">50% - 99%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Margin Call Risk</span>
                      <span className="text-sm text-red-600">{"< 50%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Margin Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground text-xs">Required Margin =</p>
                    <p className="font-semibold text-foreground">Position Value ÷ Leverage</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground text-xs">Margin Level =</p>
                    <p className="font-semibold text-foreground">(Equity ÷ Margin) × 100</p>
                  </div>
                  <p>
                    <strong>Position Value</strong> = Lot Size × Contract Size × Exchange Rate
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Lot Sizes</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Standard Lot</span>
                    <span className="font-medium text-foreground">100,000 units</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Mini Lot</span>
                    <span className="font-medium text-foreground">10,000 units</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Micro Lot</span>
                    <span className="font-medium text-foreground">1,000 units</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Nano Lot</span>
                    <span className="font-medium text-foreground">100 units</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Forex Margin?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Forex margin is the amount of money required to open and maintain a leveraged trading position in the
                  foreign exchange market. It acts as a good faith deposit that allows traders to control larger
                  positions than their account balance would otherwise permit. Margin is not a fee or transaction cost;
                  rather, it's a portion of your account equity set aside as collateral for the trade.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding margin requirements is crucial for effective risk management in forex trading. When you
                  use leverage, you can amplify both profits and losses, making it essential to calculate your margin
                  requirements before entering any trade. Brokers typically require a certain percentage of the position
                  value as margin, which varies based on the leverage ratio offered.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Leverage and Margin</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Leverage and margin are inversely related in forex trading. Higher leverage means lower margin
                  requirements, allowing you to control larger positions with less capital. For example, with 1:100
                  leverage, you only need 1% of the position value as margin. With 1:500 leverage, the margin
                  requirement drops to just 0.2% of the position value.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Margin Level Explained</h4>
                    <p className="text-blue-700 text-sm">
                      Margin level is the ratio of your equity to used margin, expressed as a percentage. Most brokers
                      require a minimum margin level of 100% and will issue a margin call if it falls below this
                      threshold. Maintaining a higher margin level provides a buffer against market volatility.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Free Margin</h4>
                    <p className="text-yellow-700 text-sm">
                      Free margin is the amount of equity in your account that is not being used as margin for open
                      positions. This represents the funds available to open new trades or absorb losses on existing
                      positions without triggering a margin call.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Risk Management Tips</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Never risk more than 1-2%</strong> of your account balance on a single trade
                  </li>
                  <li>
                    <strong>Maintain adequate free margin</strong> to withstand market volatility and drawdowns
                  </li>
                  <li>
                    <strong>Use stop-loss orders</strong> to limit potential losses and protect your margin
                  </li>
                  <li>
                    <strong>Monitor margin level regularly</strong> and close positions before reaching margin call
                    levels
                  </li>
                  <li>
                    <strong>Consider lower leverage</strong> if you're new to trading or during high volatility periods
                  </li>
                  <li>
                    <strong>Diversify positions</strong> to avoid concentrating risk in a single currency pair
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p>
                      Margin requirement calculations are estimates based on entered values and current exchange rates.
                      Actual margin requirements may vary due to broker policies, leverage limits, and market
                      conditions. Forex trading involves significant risk of loss and is not suitable for all investors.
                      Consult your broker or a trading professional for precise calculations and risk assessment.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
