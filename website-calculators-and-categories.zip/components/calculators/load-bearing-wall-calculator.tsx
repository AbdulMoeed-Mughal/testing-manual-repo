"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Box, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface BlockPreset {
  name: string
  length: number
  height: number
  width: number
}

interface CalculationResult {
  wallVolume: number
  blockVolume: number
  numberOfBlocks: number
  mortarVolume: number
  cementBags: number
  sandVolume: number
}

const blockPresets: BlockPreset[] = [
  { name: "Standard Brick (metric)", length: 0.19, height: 0.09, width: 0.09 },
  { name: "Concrete Block 6\"", length: 0.4, height: 0.2, width: 0.15 },
  { name: "Concrete Block 8\"", length: 0.4, height: 0.2, width: 0.2 },
  { name: "Concrete Block 10\"", length: 0.4, height: 0.2, width: 0.25 },
  { name: "AAC Block", length: 0.6, height: 0.2, width: 0.2 },
]

export function LoadBearingWallCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [wallLength, setWallLength] = useState("")
  const [wallHeight, setWallHeight] = useState("")
  const [wallThickness, setWallThickness] = useState("")
  const [blockLength, setBlockLength] = useState("")
  const [blockHeight, setBlockHeight] = useState("")
  const [blockWidth, setBlockWidth] = useState("")
  const [wastagePercent, setWastagePercent] = useState("10")
  const [mortarRatio, setMortarRatio] = useState("1:6")
  const [result, setResult] = useState<CalculationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateMaterials = () => {
    setError("")
    setResult(null)

    const wLength = Number.parseFloat(wallLength)
    const wHeight = Number.parseFloat(wallHeight)
    const wThickness = Number.parseFloat(wallThickness)
    const bLength = Number.parseFloat(blockLength)
    const bHeight = Number.parseFloat(blockHeight)
    const bWidth = Number.parseFloat(blockWidth)
    const wastage = Number.parseFloat(wastagePercent)

    // Validation
    if (
      isNaN(wLength) ||
      wLength <= 0 ||
      isNaN(wHeight) ||
      wHeight <= 0 ||
      isNaN(wThickness) ||
      wThickness <= 0
    ) {
      setError("Please enter valid wall dimensions greater than 0")
      return
    }

    if (
      isNaN(bLength) ||
      bLength <= 0 ||
      isNaN(bHeight) ||
      bHeight <= 0 ||
      isNaN(bWidth) ||
      bWidth <= 0
    ) {
      setError("Please enter valid block dimensions greater than 0")
      return
    }

    if (wThickness < bWidth) {
      setError("Wall thickness must be greater than or equal to block width")
      return
    }

    if (isNaN(wastage) || wastage < 0 || wastage > 100) {
      setError("Wastage percentage must be between 0 and 100")
      return
    }

    // Convert to metric if imperial
    let wL = wLength
    let wH = wHeight
    let wT = wThickness
    let bL = bLength
    let bH = bHeight
    let bW = bWidth

    if (unitSystem === "imperial") {
      wL = wLength * 0.3048
      wH = wHeight * 0.3048
      wT = wThickness * 0.3048
      bL = bLength * 0.3048
      bH = bHeight * 0.3048
      bW = bWidth * 0.3048
    }

    // Calculations
    const wallVol = wL * wH * wT
    const blockVol = bL * bH * bW

    if (blockVol === 0) {
      setError("Block volume cannot be zero")
      return
    }

    const numBlocks = Math.ceil((wallVol / blockVol) * (1 + wastage / 100))

    // Mortar calculations (typical mortar volume is 25-30% of wall volume)
    const mortarFactor = 0.28
    const mortarVol = wallVol * mortarFactor

    // Cement and sand for mortar based on ratio
    let cementParts = 1
    let sandParts = 6
    if (mortarRatio === "1:4") {
      sandParts = 4
    } else if (mortarRatio === "1:5") {
      sandParts = 5
    } else if (mortarRatio === "1:8") {
      sandParts = 8
    }

    const totalParts = cementParts + sandParts
    const cementVolume = (mortarVol * cementParts) / totalParts
    const sandVolume = (mortarVol * sandParts) / totalParts

    // Cement bags (assuming 1 bag = 0.035 m³)
    const cementBags = Math.ceil(cementVolume / 0.035)

    setResult({
      wallVolume: wallVol,
      blockVolume: blockVol,
      numberOfBlocks: numBlocks,
      mortarVolume: mortarVol,
      cementBags: cementBags,
      sandVolume: sandVolume,
    })
  }

  const handleReset = () => {
    setWallLength("")
    setWallHeight("")
    setWallThickness("")
    setBlockLength("")
    setBlockHeight("")
    setBlockWidth("")
    setWastagePercent("10")
    setMortarRatio("1:6")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Load Bearing Wall Calculator Results:
Blocks Required: ${result.numberOfBlocks.toLocaleString()}
Mortar Volume: ${result.mortarVolume.toFixed(3)} m³
Cement: ${result.cementBags} bags
Sand: ${result.sandVolume.toFixed(3)} m³`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Load Bearing Wall Calculator Result",
          text: `I calculated wall materials using CalcHub! Blocks Required: ${result.numberOfBlocks.toLocaleString()}, Cement: ${result.cementBags} bags`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWallLength("")
    setWallHeight("")
    setWallThickness("")
    setBlockLength("")
    setBlockHeight("")
    setBlockWidth("")
    setResult(null)
    setError("")
  }

  const applyPreset = (preset: BlockPreset) => {
    if (unitSystem === "metric") {
      setBlockLength(preset.length.toString())
      setBlockHeight(preset.height.toString())
      setBlockWidth(preset.width.toString())
    } else {
      setBlockLength((preset.length / 0.3048).toFixed(3))
      setBlockHeight((preset.height / 0.3048).toFixed(3))
      setBlockWidth((preset.width / 0.3048).toFixed(3))
    }
  }

  const unit = unitSystem === "metric" ? "m" : "ft"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Box className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Load Bearing Wall Calculator</CardTitle>
                    <CardDescription>Calculate bricks/blocks and mortar required</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Wall Dimensions */}
                <div className="space-y-3 p-3 rounded-lg bg-muted/50">
                  <h4 className="font-semibold text-sm">Wall Dimensions</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="wallLength">Length ({unit})</Label>
                      <Input
                        id="wallLength"
                        type="number"
                        placeholder="Length"
                        value={wallLength}
                        onChange={(e) => setWallLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="wallHeight">Height ({unit})</Label>
                      <Input
                        id="wallHeight"
                        type="number"
                        placeholder="Height"
                        value={wallHeight}
                        onChange={(e) => setWallHeight(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="wallThickness">Thickness ({unit})</Label>
                      <Input
                        id="wallThickness"
                        type="number"
                        placeholder="Thickness"
                        value={wallThickness}
                        onChange={(e) => setWallThickness(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                </div>

                {/* Block Preset */}
                <div className="space-y-2">
                  <Label>Block/Brick Preset</Label>
                  <Select onValueChange={(value) => applyPreset(blockPresets[Number.parseInt(value)])}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a preset size" />
                    </SelectTrigger>
                    <SelectContent>
                      {blockPresets.map((preset, index) => (
                        <SelectItem key={index} value={index.toString()}>
                          {preset.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Block Dimensions */}
                <div className="space-y-3 p-3 rounded-lg bg-muted/50">
                  <h4 className="font-semibold text-sm">Block/Brick Dimensions</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="blockLength">Length ({unit})</Label>
                      <Input
                        id="blockLength"
                        type="number"
                        placeholder="Length"
                        value={blockLength}
                        onChange={(e) => setBlockLength(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="blockHeight">Height ({unit})</Label>
                      <Input
                        id="blockHeight"
                        type="number"
                        placeholder="Height"
                        value={blockHeight}
                        onChange={(e) => setBlockHeight(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="blockWidth">Width ({unit})</Label>
                      <Input
                        id="blockWidth"
                        type="number"
                        placeholder="Width"
                        value={blockWidth}
                        onChange={(e) => setBlockWidth(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                  </div>
                </div>

                {/* Additional Parameters */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="wastage">Wastage (%)</Label>
                    <Input
                      id="wastage"
                      type="number"
                      placeholder="Wastage %"
                      value={wastagePercent}
                      onChange={(e) => setWastagePercent(e.target.value)}
                      min="0"
                      max="100"
                      step="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mortarRatio">Mortar Mix Ratio</Label>
                    <Select value={mortarRatio} onValueChange={setMortarRatio}>
                      <SelectTrigger id="mortarRatio">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1:4">1:4 (Cement:Sand)</SelectItem>
                        <SelectItem value="1:5">1:5 (Cement:Sand)</SelectItem>
                        <SelectItem value="1:6">1:6 (Cement:Sand)</SelectItem>
                        <SelectItem value="1:8">1:8 (Cement:Sand)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMaterials} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Materials
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total Blocks/Bricks Required</p>
                        <p className="text-5xl font-bold text-amber-600 mb-2">
                          {result.numberOfBlocks.toLocaleString()}
                        </p>
                        <p className="text-sm text-amber-700">Including {wastagePercent}% wastage</p>
                      </div>
                    </div>

                    {/* Mortar Details */}
                    <div className="p-4 rounded-lg bg-muted/50 space-y-3">
                      <h4 className="font-semibold text-sm">Mortar Requirements ({mortarRatio})</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Total Mortar Volume:</span>
                          <span className="font-semibold">{result.mortarVolume.toFixed(3)} m³</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Cement Required:</span>
                          <span className="font-semibold text-amber-600">{result.cementBags} bags</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Sand Required:</span>
                          <span className="font-semibold">{result.sandVolume.toFixed(3)} m³</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Block Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Standard Clay Brick</h4>
                      <p className="text-sm text-amber-700">190 × 90 × 90 mm (metric)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Concrete Block</h4>
                      <p className="text-sm text-amber-700">400 × 200 × 150/200/250 mm</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">AAC Block</h4>
                      <p className="text-sm text-amber-700">600 × 200 × 200/250/300 mm</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mortar Mix Ratios</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-muted-foreground">
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-semibold text-foreground mb-1">1:4 (Strong)</p>
                    <p>For heavy load-bearing walls and foundations</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-semibold text-foreground mb-1">1:5 to 1:6 (Medium)</p>
                    <p>General purpose masonry and load-bearing walls</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-semibold text-foreground mb-1">1:8 (Light)</p>
                    <p>Non-load-bearing partition walls</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Load Bearing Wall */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Load Bearing Wall?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A load-bearing wall is a structural element in a building that carries the weight from above and
                  transfers it to the foundation below. Unlike partition walls that only divide space, load-bearing
                  walls support the entire structure including floors, roofs, and upper stories. These walls are
                  crucial for the structural integrity of a building and must be designed to handle significant
                  vertical loads.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Load-bearing walls are typically made from strong materials like brick, concrete blocks, or stone,
                  and are bonded together with mortar. The thickness of these walls depends on the height of the
                  building and the load they need to support. Proper calculation of materials is essential to ensure
                  the wall has adequate strength while avoiding material waste.
                </p>
              </CardContent>
            </Card>

            {/* Calculation Method */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How Materials are Calculated</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The calculation begins with determining the total volume of the wall by multiplying its length,
                  height, and thickness. Next, the volume of a single brick or block is calculated from its
                  dimensions. The number of blocks required is found by dividing the wall volume by the block volume,
                  then adding the wastage percentage to account for breakage and cutting during construction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Mortar volume is calculated as approximately 25-30% of the wall volume, accounting for the joints
                  between blocks. Based on the selected mix ratio (such as 1:6 for cement to sand), the calculator
                  determines how many cement bags and how much sand is needed. One cement bag is typically 50 kg,
                  which equals about 0.035 cubic meters when mixed.
                </p>
              </CardContent>
            </Card>

            {/* Important Considerations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Always add 5-10% wastage to account for material breakage, cutting, and construction variations.
                  The actual mortar thickness between blocks can vary based on workmanship and site conditions, so
                  these calculations provide estimates. For critical structural work, consult with a structural
                  engineer to ensure the wall design meets local building codes and can safely support the intended
                  loads.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Wall thickness must be at least equal to the block width being used. For taller walls or heavier
                  loads, thicker walls or reinforced construction may be required. The choice of mortar mix ratio
                  depends on the application—stronger 1:4 mixes for heavy loads and foundations, and lighter 1:8
                  mixes for non-structural partition walls.
                </p>
                <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-sm text-amber-800 font-medium">
                    ⚠️ Disclaimer: These calculations are approximate. Actual quantities vary with mortar thickness,
                    block size, workmanship, and site conditions. Always consult with professionals for structural
                    applications.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
