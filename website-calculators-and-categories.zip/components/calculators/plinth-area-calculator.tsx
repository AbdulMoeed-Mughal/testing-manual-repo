"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Layers, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface PlinthResult {
  singleFloorArea: number
  totalArea: number
  floors: number
  unit: string
}

export function PlinthAreaCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [floors, setFloors] = useState("1")
  const [wallThickness, setWallThickness] = useState("")
  const [includeWalls, setIncludeWalls] = useState(false)
  const [result, setResult] = useState<PlinthResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculatePlinthArea = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const floorsNum = Number.parseInt(floors)
    const wallThicknessNum = wallThickness ? Number.parseFloat(wallThickness) : 0

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }

    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }

    if (isNaN(floorsNum) || floorsNum < 1) {
      setError("Number of floors must be at least 1")
      return
    }

    if (includeWalls && wallThicknessNum <= 0) {
      setError("Please enter a valid wall thickness when including walls")
      return
    }

    let effectiveLength = lengthNum
    let effectiveWidth = widthNum

    if (includeWalls && wallThicknessNum > 0) {
      effectiveLength += 2 * wallThicknessNum
      effectiveWidth += 2 * wallThicknessNum
    }

    const singleFloorArea = effectiveLength * effectiveWidth
    const totalArea = singleFloorArea * floorsNum

    const unit = unitSystem === "metric" ? "m²" : "ft²"

    setResult({
      singleFloorArea: Math.round(singleFloorArea * 100) / 100,
      totalArea: Math.round(totalArea * 100) / 100,
      floors: floorsNum,
      unit,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setFloors("1")
    setWallThickness("")
    setIncludeWalls(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Plinth Area: ${result.singleFloorArea} ${result.unit} per floor, Total: ${result.totalArea} ${result.unit} (${result.floors} floor${result.floors > 1 ? "s" : ""})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Plinth Area Calculation",
          text: `Plinth Area: ${result.singleFloorArea} ${result.unit} per floor, Total: ${result.totalArea} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setWallThickness("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Plinth Area Calculator</CardTitle>
                    <CardDescription>Calculate building plinth area</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Width Input */}
                <div className="space-y-2">
                  <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="width"
                    type="number"
                    placeholder={`Enter width in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={width}
                    onChange={(e) => setWidth(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Number of Floors */}
                <div className="space-y-2">
                  <Label htmlFor="floors">Number of Floors</Label>
                  <Input
                    id="floors"
                    type="number"
                    placeholder="Enter number of floors"
                    value={floors}
                    onChange={(e) => setFloors(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Wall Thickness Toggle */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="includeWalls"
                    checked={includeWalls}
                    onChange={(e) => setIncludeWalls(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300"
                  />
                  <Label htmlFor="includeWalls" className="cursor-pointer">
                    Include wall thickness
                  </Label>
                </div>

                {/* Wall Thickness Input */}
                {includeWalls && (
                  <div className="space-y-2">
                    <Label htmlFor="wallThickness">
                      Wall Thickness ({unitSystem === "metric" ? "m" : "ft"})
                    </Label>
                    <Input
                      id="wallThickness"
                      type="number"
                      placeholder="Enter wall thickness"
                      value={wallThickness}
                      onChange={(e) => setWallThickness(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePlinthArea} className="w-full" size="lg">
                  Calculate Plinth Area
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Plinth Area per Floor</p>
                        <p className="text-4xl font-bold text-amber-600">{result.singleFloorArea}</p>
                        <p className="text-lg font-semibold text-amber-600">{result.unit}</p>
                      </div>

                      {result.floors > 1 && (
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground mb-1">Total Plinth Area ({result.floors} floors)</p>
                          <p className="text-3xl font-bold text-amber-600">{result.totalArea}</p>
                          <p className="text-base font-semibold text-amber-600">{result.unit}</p>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Plinth Area Basics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-muted-foreground">
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <p className="font-semibold text-amber-800 mb-1">Definition</p>
                    <p className="text-amber-700">
                      Plinth area is the covered built-up area measured at floor level of any building, including walls
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <p className="font-semibold text-amber-800 mb-1">Includes</p>
                    <p className="text-amber-700">Internal rooms, walls, staircases, lobbies, and corridors</p>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <p className="font-semibold text-amber-800 mb-1">Excludes</p>
                    <p className="text-amber-700">
                      External projections like balconies, porches not supported by walls
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Uses</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Cost estimation and budgeting</p>
                  <p>• Municipal approval and floor area ratio (FAR) calculations</p>
                  <p>• Property tax assessment</p>
                  <p>• Material requirement planning</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Plinth Area */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Plinth Area?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Plinth area is the covered built-up area measured at the floor level of any building, including the
                  thickness of walls. It represents the area enclosed within the external walls of a building at the plinth
                  level, which is typically the level of the ground floor or the basement floor. The plinth area is an
                  essential measurement in construction and real estate as it forms the basis for various calculations
                  including cost estimation, material requirements, and municipal approvals.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In construction terminology, the plinth refers to the base or platform upon which a building stands. The
                  plinth area measurement includes all internal walls, columns, and structural elements but excludes external
                  projections like open balconies, porches, and cantilevered extensions that are not supported by walls.
                  Understanding plinth area is crucial for architects, engineers, contractors, and property developers as it
                  directly impacts project planning, budgeting, and regulatory compliance.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Plinth Area */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Plinth Area</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating plinth area is straightforward for rectangular or square buildings. You simply multiply the
                  external length by the external width of the building at plinth level, including the thickness of external
                  walls. For example, if a building measures 20 meters in length and 15 meters in width (both measured from
                  the outer edge of external walls), the plinth area would be 20 × 15 = 300 square meters.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For multi-story buildings, you calculate the plinth area for each floor level and sum them up to get the
                  total plinth area. If wall thicknesses vary between floors or if there are setbacks, each floor must be
                  calculated separately. For irregular or complex building shapes, the plinth area is calculated by dividing
                  the floor plan into regular geometric shapes (rectangles, triangles, etc.), calculating each section's
                  area, and then adding them together. Wall thickness typically ranges from 0.2m to 0.4m (8 to 16 inches)
                  depending on structural requirements and building codes.
                </p>
              </CardContent>
            </Card>

            {/* Plinth Area vs Other Areas */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Plinth Area vs Carpet Area vs Built-Up Area</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding the difference between plinth area, carpet area, and built-up area is essential in real
                  estate and construction. Carpet area is the actual usable floor area of an apartment or building, excluding
                  the area covered by walls. It's the area where you can physically lay a carpet, hence the name. Carpet area
                  is typically 70-75% of the plinth area.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Plinth area includes the carpet area plus the area occupied by internal and external walls. Built-up area
                  goes a step further and includes the plinth area plus the proportionate area of common spaces like
                  staircases, lift lobbies, and corridors in multi-unit buildings. Super built-up area (also called saleable
                  area) includes the built-up area plus a proportionate share of common amenities like swimming pools, gyms,
                  and gardens. In real estate transactions, developers often quote prices based on super built-up area, which
                  is the largest measurement, so understanding these distinctions helps buyers make informed decisions. The
                  hierarchy is: Carpet Area {"<"} Plinth Area {"<"} Built-Up Area {"<"} Super Built-Up Area.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2 text-sm text-amber-800">
                    <p className="font-semibold">Important Note:</p>
                    <p className="leading-relaxed">
                      Plinth area calculations assume simple rectangular layouts. Actual areas may vary with projections,
                      recesses, or complex architectural shapes. Always consult with a licensed architect or structural
                      engineer for precise measurements and official documentation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
