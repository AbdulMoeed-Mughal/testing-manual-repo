"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type SystemType = "star" | "delta"
type VoltageType = "line" | "phase"

interface ThreePhaseResult {
  realPower: number
  reactivePower: number
  apparentPower: number
  phaseVoltage: number
  lineVoltage: number
  phaseCurrent: number
  lineCurrent: number
  phaseAngle: number
  steps: string[]
}

export function ThreePhasePowerCalculator() {
  const [systemType, setSystemType] = useState<SystemType>("star")
  const [voltageType, setVoltageType] = useState<VoltageType>("line")
  const [voltage, setVoltage] = useState("")
  const [current, setCurrent] = useState("")
  const [powerFactor, setPowerFactor] = useState("")
  const [voltageUnit, setVoltageUnit] = useState("V")
  const [currentUnit, setCurrentUnit] = useState("A")
  const [result, setResult] = useState<ThreePhaseResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const sqrt3 = Math.sqrt(3)

  const convertVoltageToVolts = (value: number, unit: string): number => {
    switch (unit) {
      case "kV":
        return value * 1000
      case "mV":
        return value / 1000
      default:
        return value
    }
  }

  const convertCurrentToAmps = (value: number, unit: string): number => {
    switch (unit) {
      case "kA":
        return value * 1000
      case "mA":
        return value / 1000
      default:
        return value
    }
  }

  const formatPower = (watts: number): string => {
    if (Math.abs(watts) >= 1e9) return `${(watts / 1e9).toFixed(3)} GW`
    if (Math.abs(watts) >= 1e6) return `${(watts / 1e6).toFixed(3)} MW`
    if (Math.abs(watts) >= 1e3) return `${(watts / 1e3).toFixed(3)} kW`
    return `${watts.toFixed(3)} W`
  }

  const formatVA = (va: number): string => {
    if (Math.abs(va) >= 1e9) return `${(va / 1e9).toFixed(3)} GVA`
    if (Math.abs(va) >= 1e6) return `${(va / 1e6).toFixed(3)} MVA`
    if (Math.abs(va) >= 1e3) return `${(va / 1e3).toFixed(3)} kVA`
    return `${va.toFixed(3)} VA`
  }

  const formatVAR = (var_: number): string => {
    if (Math.abs(var_) >= 1e9) return `${(var_ / 1e9).toFixed(3)} GVAR`
    if (Math.abs(var_) >= 1e6) return `${(var_ / 1e6).toFixed(3)} MVAR`
    if (Math.abs(var_) >= 1e3) return `${(var_ / 1e3).toFixed(3)} kVAR`
    return `${var_.toFixed(3)} VAR`
  }

  const calculatePower = () => {
    setError("")
    setResult(null)

    const voltageNum = Number.parseFloat(voltage)
    const currentNum = Number.parseFloat(current)
    const pfNum = Number.parseFloat(powerFactor)

    if (isNaN(voltageNum) || voltageNum <= 0) {
      setError("Please enter a valid voltage greater than 0")
      return
    }

    if (isNaN(currentNum) || currentNum <= 0) {
      setError("Please enter a valid current greater than 0")
      return
    }

    if (isNaN(pfNum) || pfNum <= 0 || pfNum > 1) {
      setError("Power factor must be between 0 and 1")
      return
    }

    const V = convertVoltageToVolts(voltageNum, voltageUnit)
    const I = convertCurrentToAmps(currentNum, currentUnit)
    const PF = pfNum

    const steps: string[] = []
    let V_L: number, V_Ph: number, I_L: number, I_Ph: number

    if (systemType === "star") {
      steps.push("System Type: Star (Wye) Connection")

      if (voltageType === "line") {
        V_L = V
        V_Ph = V / sqrt3
        steps.push(`Given Line Voltage: V_L = ${V.toFixed(2)} V`)
        steps.push(`Phase Voltage: V_Ph = V_L / √3 = ${V.toFixed(2)} / ${sqrt3.toFixed(4)} = ${V_Ph.toFixed(2)} V`)
      } else {
        V_Ph = V
        V_L = V * sqrt3
        steps.push(`Given Phase Voltage: V_Ph = ${V.toFixed(2)} V`)
        steps.push(`Line Voltage: V_L = V_Ph × √3 = ${V.toFixed(2)} × ${sqrt3.toFixed(4)} = ${V_L.toFixed(2)} V`)
      }

      I_L = I
      I_Ph = I
      steps.push(`Line Current: I_L = ${I.toFixed(3)} A`)
      steps.push(`Phase Current: I_Ph = I_L = ${I_Ph.toFixed(3)} A (Star connection)`)
    } else {
      steps.push("System Type: Delta Connection")

      if (voltageType === "line") {
        V_L = V
        V_Ph = V
        steps.push(`Given Line Voltage: V_L = ${V.toFixed(2)} V`)
        steps.push(`Phase Voltage: V_Ph = V_L = ${V_Ph.toFixed(2)} V (Delta connection)`)
      } else {
        V_Ph = V
        V_L = V
        steps.push(`Given Phase Voltage: V_Ph = ${V.toFixed(2)} V`)
        steps.push(`Line Voltage: V_L = V_Ph = ${V_L.toFixed(2)} V (Delta connection)`)
      }

      I_L = I
      I_Ph = I / sqrt3
      steps.push(`Line Current: I_L = ${I.toFixed(3)} A`)
      steps.push(`Phase Current: I_Ph = I_L / √3 = ${I.toFixed(3)} / ${sqrt3.toFixed(4)} = ${I_Ph.toFixed(3)} A`)
    }

    steps.push(`Power Factor: PF = ${PF}`)

    // Calculate powers
    const S = sqrt3 * V_L * I_L
    const P = S * PF
    const Q = Math.sqrt(S * S - P * P)
    const phaseAngle = Math.acos(PF) * (180 / Math.PI)

    steps.push("")
    steps.push("Power Calculations:")
    steps.push(`Apparent Power: S = √3 × V_L × I_L = √3 × ${V_L.toFixed(2)} × ${I_L.toFixed(3)} = ${S.toFixed(2)} VA`)
    steps.push(`Real Power: P = S × PF = ${S.toFixed(2)} × ${PF} = ${P.toFixed(2)} W`)
    steps.push(
      `Reactive Power: Q = √(S² − P²) = √(${(S * S).toFixed(2)} − ${(P * P).toFixed(2)}) = ${Q.toFixed(2)} VAR`,
    )
    steps.push(`Phase Angle: φ = arccos(${PF}) = ${phaseAngle.toFixed(2)}°`)

    setResult({
      realPower: P,
      reactivePower: Q,
      apparentPower: S,
      phaseVoltage: V_Ph,
      lineVoltage: V_L,
      phaseCurrent: I_Ph,
      lineCurrent: I_L,
      phaseAngle,
      steps,
    })
  }

  const handleReset = () => {
    setSystemType("star")
    setVoltageType("line")
    setVoltage("")
    setCurrent("")
    setPowerFactor("")
    setVoltageUnit("V")
    setCurrentUnit("A")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Three-Phase Power Results:\nReal Power (P): ${formatPower(result.realPower)}\nReactive Power (Q): ${formatVAR(result.reactivePower)}\nApparent Power (S): ${formatVA(result.apparentPower)}\nPhase Angle: ${result.phaseAngle.toFixed(2)}°`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Three-Phase Power Results",
          text: `Real Power: ${formatPower(result.realPower)}, Reactive Power: ${formatVAR(result.reactivePower)}, Apparent Power: ${formatVA(result.apparentPower)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Three-Phase Power Calculator</CardTitle>
                    <CardDescription>Calculate P, Q, S in 3-phase systems</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* System Type Selection */}
                <div className="space-y-2">
                  <Label>System Type</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={systemType === "star" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSystemType("star")}
                      className="flex-1"
                    >
                      Star (Wye)
                    </Button>
                    <Button
                      variant={systemType === "delta" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSystemType("delta")}
                      className="flex-1"
                    >
                      Delta
                    </Button>
                  </div>
                </div>

                {/* Voltage Type Selection */}
                <div className="space-y-2">
                  <Label>Voltage Type</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={voltageType === "line" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setVoltageType("line")}
                      className="flex-1"
                    >
                      Line-to-Line
                    </Button>
                    <Button
                      variant={voltageType === "phase" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setVoltageType("phase")}
                      className="flex-1"
                    >
                      Line-to-Neutral
                    </Button>
                  </div>
                </div>

                {/* Voltage Input */}
                <div className="space-y-2">
                  <Label htmlFor="voltage">
                    {voltageType === "line" ? "Line Voltage (V_L)" : "Phase Voltage (V_Ph)"}
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="voltage"
                      type="number"
                      placeholder="Enter voltage"
                      value={voltage}
                      onChange={(e) => setVoltage(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={voltageUnit} onValueChange={setVoltageUnit}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mV">mV</SelectItem>
                        <SelectItem value="V">V</SelectItem>
                        <SelectItem value="kV">kV</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Current Input */}
                <div className="space-y-2">
                  <Label htmlFor="current">Line Current (I_L)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="current"
                      type="number"
                      placeholder="Enter current"
                      value={current}
                      onChange={(e) => setCurrent(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={currentUnit} onValueChange={setCurrentUnit}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mA">mA</SelectItem>
                        <SelectItem value="A">A</SelectItem>
                        <SelectItem value="kA">kA</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Power Factor Input */}
                <div className="space-y-2">
                  <Label htmlFor="powerFactor">Power Factor (0 to 1)</Label>
                  <Input
                    id="powerFactor"
                    type="number"
                    placeholder="Enter power factor (e.g., 0.85)"
                    value={powerFactor}
                    onChange={(e) => setPowerFactor(e.target.value)}
                    min="0"
                    max="1"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePower} className="w-full" size="lg">
                  Calculate Power
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl border-2 bg-yellow-50 border-yellow-200 transition-all duration-300">
                      <div className="text-center space-y-3">
                        <div>
                          <p className="text-sm text-muted-foreground">Real Power (P)</p>
                          <p className="text-3xl font-bold text-yellow-700">{formatPower(result.realPower)}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="p-2 bg-white/60 rounded-lg">
                            <p className="text-xs text-muted-foreground">Reactive Power (Q)</p>
                            <p className="text-lg font-semibold text-yellow-600">{formatVAR(result.reactivePower)}</p>
                          </div>
                          <div className="p-2 bg-white/60 rounded-lg">
                            <p className="text-xs text-muted-foreground">Apparent Power (S)</p>
                            <p className="text-lg font-semibold text-yellow-600">{formatVA(result.apparentPower)}</p>
                          </div>
                        </div>
                        <div className="p-2 bg-white/60 rounded-lg">
                          <p className="text-xs text-muted-foreground">Phase Angle (φ)</p>
                          <p className="text-lg font-semibold text-yellow-600">{result.phaseAngle.toFixed(2)}°</p>
                        </div>
                      </div>

                      {/* Voltage/Current Details */}
                      <Collapsible className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full text-yellow-700">
                            Show Voltage & Current Details
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2 space-y-2">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div className="p-2 bg-white/60 rounded-lg">
                              <p className="text-xs text-muted-foreground">Line Voltage</p>
                              <p className="font-medium">{result.lineVoltage.toFixed(2)} V</p>
                            </div>
                            <div className="p-2 bg-white/60 rounded-lg">
                              <p className="text-xs text-muted-foreground">Phase Voltage</p>
                              <p className="font-medium">{result.phaseVoltage.toFixed(2)} V</p>
                            </div>
                            <div className="p-2 bg-white/60 rounded-lg">
                              <p className="text-xs text-muted-foreground">Line Current</p>
                              <p className="font-medium">{result.lineCurrent.toFixed(3)} A</p>
                            </div>
                            <div className="p-2 bg-white/60 rounded-lg">
                              <p className="text-xs text-muted-foreground">Phase Current</p>
                              <p className="font-medium">{result.phaseCurrent.toFixed(3)} A</p>
                            </div>
                          </div>
                        </CollapsibleContent>
                      </Collapsible>

                      {/* Action Buttons */}
                      <div className="flex items-center justify-center gap-2 mt-4">
                        <Button variant="outline" size="sm" onClick={handleReset}>
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Reset
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                          {copied ? "Copied" : "Copy"}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4 mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>

                    {/* Step-by-Step Solution */}
                    <Collapsible open={showSteps} onOpenChange={setShowSteps}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" className="w-full bg-transparent">
                          {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="p-4 bg-muted rounded-lg space-y-1 text-sm font-mono">
                          {result.steps.map((step, index) => (
                            <p key={index} className={step === "" ? "h-2" : ""}>
                              {step}
                            </p>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Power Triangle</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Real Power (P)</span>
                      <p className="text-sm text-yellow-600 mt-1">Actual power consumed (Watts)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Reactive Power (Q)</span>
                      <p className="text-sm text-blue-600 mt-1">Power stored/released (VAR)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Apparent Power (S)</span>
                      <p className="text-sm text-green-600 mt-1">Total power supplied (VA)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Three-Phase Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono space-y-2">
                    <p>
                      <strong>Apparent Power:</strong> S = √3 × V_L × I_L
                    </p>
                    <p>
                      <strong>Real Power:</strong> P = S × PF
                    </p>
                    <p>
                      <strong>Reactive Power:</strong> Q = √(S² − P²)
                    </p>
                  </div>
                  <div className="space-y-2 mt-3">
                    <p>
                      <strong>Star (Wye):</strong>
                    </p>
                    <p className="text-xs">V_Ph = V_L / √3, I_Ph = I_L</p>
                    <p>
                      <strong>Delta:</strong>
                    </p>
                    <p className="text-xs">V_Ph = V_L, I_Ph = I_L / √3</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Industrial (US)</span>
                      <span className="font-mono">480V, 60Hz</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Industrial (EU)</span>
                      <span className="font-mono">400V, 50Hz</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>High Voltage</span>
                      <span className="font-mono">11kV, 33kV</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Typical PF (Motors)</span>
                      <span className="font-mono">0.80 - 0.90</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Three-Phase Power?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Three-phase power is a common method of alternating current electric power generation, transmission,
                  and distribution. It is a type of polyphase system and is the most common method used by electrical
                  grids worldwide to transfer power. Three-phase systems use less conductor material to transmit
                  electrical power than equivalent single-phase systems at the same voltage.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In a three-phase system, three circuit conductors carry three alternating currents (of the same
                  frequency) which reach their instantaneous peak values at different times. Taking one conductor as the
                  reference, the other two currents are delayed in time by one-third and two-thirds of one cycle of the
                  electrical current. This delay between phases provides constant power transfer.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Star vs Delta Connections</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Star (Wye) Connection:</strong> In this configuration, one end of each winding is connected to
                  a common point called the neutral. The line voltage is √3 times the phase voltage, while the line
                  current equals the phase current. This connection is commonly used for power distribution as it
                  provides a neutral point for single-phase loads.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Delta Connection:</strong> In this configuration, the windings are connected end-to-end,
                  forming a closed loop. The line voltage equals the phase voltage, while the line current is √3 times
                  the phase current. Delta connections are often used for high-power industrial motors and transformers.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Three-phase power calculations are estimates based on ideal system conditions. Actual power may vary
                  due to harmonics, unbalanced loads, or measurement inaccuracies. Consult an electrical engineer for
                  precise system analysis. Always follow local electrical codes and safety regulations when working with
                  three-phase power systems.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
