"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Scale, Info, Activity, Target, Users } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type Formula = "devine" | "robinson" | "miller" | "hamwi"
type FrameSize = "small" | "medium" | "large"

interface IdealWeightResult {
  weightKg: number
  weightLb: number
  rangeMinKg: number
  rangeMaxKg: number
  rangeMinLb: number
  rangeMaxLb: number
  formula: string
}

export function IdealWeightCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender | null>(null)
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [formula, setFormula] = useState<Formula>("devine")
  const [frameSize, setFrameSize] = useState<FrameSize>("medium")
  const [result, setResult] = useState<IdealWeightResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formulaNames: Record<Formula, string> = {
    devine: "Devine Formula",
    robinson: "Robinson Formula",
    miller: "Miller Formula",
    hamwi: "Hamwi Formula",
  }

  const calculateIdealWeight = () => {
    setError("")
    setResult(null)

    if (!gender) {
      setError("Please select your gender")
      return
    }

    let heightInInches: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum < 120) {
        setError("Please enter a valid height (minimum 120 cm)")
        return
      }
      heightInInches = heightCmNum / 2.54
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height")
        return
      }
      heightInInches = feet * 12 + inches
      if (heightInInches < 47.24) {
        setError("Please enter a valid height (minimum 4 feet)")
        return
      }
    }

    let idealWeightKg: number
    const inchesOver60 = heightInInches - 60

    // Calculate based on selected formula
    if (formula === "devine") {
      if (gender === "male") {
        idealWeightKg = 50 + 2.3 * inchesOver60
      } else {
        idealWeightKg = 45.5 + 2.3 * inchesOver60
      }
    } else if (formula === "robinson") {
      if (gender === "male") {
        idealWeightKg = 52 + 1.9 * inchesOver60
      } else {
        idealWeightKg = 49 + 1.7 * inchesOver60
      }
    } else if (formula === "miller") {
      if (gender === "male") {
        idealWeightKg = 56.2 + 1.41 * inchesOver60
      } else {
        idealWeightKg = 53.1 + 1.36 * inchesOver60
      }
    } else {
      // Hamwi
      if (gender === "male") {
        idealWeightKg = 48 + 2.7 * inchesOver60
      } else {
        idealWeightKg = 45.5 + 2.2 * inchesOver60
      }
    }

    // Apply frame size adjustment
    if (frameSize === "small") {
      idealWeightKg *= 0.9
    } else if (frameSize === "large") {
      idealWeightKg *= 1.1
    }

    const idealWeightLb = idealWeightKg * 2.20462
    const rangeMinKg = idealWeightKg * 0.95
    const rangeMaxKg = idealWeightKg * 1.05
    const rangeMinLb = rangeMinKg * 2.20462
    const rangeMaxLb = rangeMaxKg * 2.20462

    setResult({
      weightKg: Math.round(idealWeightKg * 10) / 10,
      weightLb: Math.round(idealWeightLb * 10) / 10,
      rangeMinKg: Math.round(rangeMinKg * 10) / 10,
      rangeMaxKg: Math.round(rangeMaxKg * 10) / 10,
      rangeMinLb: Math.round(rangeMinLb * 10) / 10,
      rangeMaxLb: Math.round(rangeMaxLb * 10) / 10,
      formula: formulaNames[formula],
    })
  }

  const handleReset = () => {
    setGender(null)
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setFormula("devine")
    setFrameSize("medium")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My ideal weight is ${result.weightKg} kg (${result.weightLb} lb) using the ${result.formula}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Ideal Weight Result",
          text: `I calculated my ideal weight using CalcHub! My ideal weight is ${result.weightKg} kg (${result.weightLb} lb)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Ideal Weight Calculator</CardTitle>
                    <CardDescription>Estimate your healthy body weight range</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      className="w-full"
                      onClick={() => setGender("male")}
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      className="w-full"
                      onClick={() => setGender("female")}
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="120"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Formula Selection */}
                <div className="space-y-2">
                  <Label>Formula</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["devine", "robinson", "miller", "hamwi"] as Formula[]).map((f) => (
                      <Button
                        key={f}
                        type="button"
                        variant={formula === f ? "default" : "outline"}
                        size="sm"
                        className="w-full"
                        onClick={() => setFormula(f)}
                      >
                        {formulaNames[f].replace(" Formula", "")}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Frame Size Selection */}
                <div className="space-y-2">
                  <Label>Frame Size (Optional)</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["small", "medium", "large"] as FrameSize[]).map((size) => (
                      <Button
                        key={size}
                        type="button"
                        variant={frameSize === size ? "default" : "outline"}
                        size="sm"
                        className="w-full capitalize"
                        onClick={() => setFrameSize(size)}
                      >
                        {size}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateIdealWeight} className="w-full" size="lg">
                  Calculate Ideal Weight
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Ideal Weight</p>
                      <p className="text-4xl font-bold text-green-600 mb-1">
                        {unitSystem === "metric" ? `${result.weightKg} kg` : `${result.weightLb} lb`}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {unitSystem === "metric" ? `(${result.weightLb} lb)` : `(${result.weightKg} kg)`}
                      </p>
                    </div>

                    <div className="mt-4 p-3 bg-white/60 rounded-lg">
                      <p className="text-sm text-center text-muted-foreground mb-1">Healthy Range (±5%)</p>
                      <p className="text-lg font-semibold text-center text-green-700">
                        {unitSystem === "metric"
                          ? `${result.rangeMinKg} – ${result.rangeMaxKg} kg`
                          : `${result.rangeMinLb} – ${result.rangeMaxLb} lb`}
                      </p>
                      <p className="text-xs text-center text-muted-foreground mt-1">
                        Using {result.formula} • {frameSize.charAt(0).toUpperCase() + frameSize.slice(1)} frame
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Devine (1974)</span>
                      <p className="text-xs text-blue-600 mt-1">Most widely used in clinical settings</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Robinson (1983)</span>
                      <p className="text-xs text-green-600 mt-1">Modification of Devine formula</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Miller (1983)</span>
                      <p className="text-xs text-purple-600 mt-1">Tends to give higher estimates</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Hamwi (1964)</span>
                      <p className="text-xs text-amber-600 mt-1">One of the earliest formulas</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Frame Size Adjustment</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>Small frame</span>
                      <span className="font-mono text-xs bg-muted px-2 py-1 rounded">−10%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Medium frame</span>
                      <span className="font-mono text-xs bg-muted px-2 py-1 rounded">No change</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Large frame</span>
                      <span className="font-mono text-xs bg-muted px-2 py-1 rounded">+10%</span>
                    </div>
                  </div>
                  <p className="text-xs pt-2 border-t">
                    Wrist circumference or elbow breadth can help determine your frame size.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Ideal Weight */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Ideal Body Weight?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ideal body weight (IBW) is a term used to describe the optimal weight that a person should maintain
                  based on their height, gender, and body frame. Unlike arbitrary weight goals, ideal body weight
                  calculations are grounded in medical research and have been developed over decades to provide a
                  reasonable target weight range associated with good health outcomes. These formulas were originally
                  created for medical purposes, particularly for calculating drug dosages and assessing nutritional
                  needs.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  It's important to understand that ideal body weight is not a single number but rather a range.
                  Individual variations in muscle mass, bone density, body composition, and genetic factors mean that
                  the "ideal" weight can vary significantly from person to person, even among individuals of the same
                  height and gender. The formulas provide a useful starting point, but they should be considered
                  alongside other health indicators such as body fat percentage, waist circumference, and overall
                  fitness level.
                </p>
              </CardContent>
            </Card>

            {/* Understanding the Formulas */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Different Formulas</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several formulas have been developed over the years to estimate ideal body weight, each with its own
                  methodology and historical context. The Devine formula, created in 1974 by Dr. B.J. Devine, was
                  originally designed for calculating medication dosages but has since become the most commonly used
                  formula in clinical practice. It uses a base weight for someone who is 5 feet tall and adds a specific
                  amount for each inch above that height.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Robinson formula (1983) and Miller formula (1983) are modifications of the Devine formula that
                  attempt to provide more accurate estimates. Robinson's modification tends to give slightly lower
                  estimates for men and higher estimates for women compared to Devine, while Miller's formula generally
                  produces higher ideal weight estimates overall. The Hamwi formula, though one of the oldest (1964),
                  remains popular due to its simplicity and is often used as a quick reference in healthcare settings.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="font-semibold text-foreground mb-2">Devine Formula (Most Common)</p>
                  <p className="text-sm text-muted-foreground font-mono">
                    Male: 50 kg + 2.3 kg × (height in inches − 60)
                  </p>
                  <p className="text-sm text-muted-foreground font-mono">
                    Female: 45.5 kg + 2.3 kg × (height in inches − 60)
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Body Frame Size */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  <CardTitle>The Role of Body Frame Size</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Body frame size refers to the overall skeletal structure of an individual, which can significantly
                  influence what constitutes a healthy weight. People with larger frames naturally have bigger bones and
                  can healthily carry more weight than those with smaller frames. The traditional ideal weight formulas
                  assume a medium frame, so adjustments of approximately 10% are commonly applied for small or large
                  frames.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  You can estimate your frame size by measuring your wrist circumference or elbow breadth. For wrist
                  measurement, wrap your thumb and middle finger around your wrist at the smallest point. If your
                  fingers overlap, you likely have a small frame; if they just touch, a medium frame; and if they don't
                  meet, a large frame. Healthcare professionals may use more precise measurements, but this simple
                  method provides a reasonable estimate for personal use.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations and Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While ideal body weight formulas provide useful guidelines, they have significant limitations that
                  should be understood. These formulas do not account for individual differences in muscle mass, which
                  means athletes and physically active individuals may have "ideal" weights that appear higher due to
                  muscle being denser than fat. Similarly, body composition varies naturally among different ethnic
                  groups, and these formulas were primarily developed using data from Western populations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Age is another factor not directly considered in these calculations. As people age, body composition
                  naturally changes, with muscle mass typically decreasing and fat mass increasing. Additionally, these
                  formulas were not designed for children, adolescents, pregnant women, or individuals with certain
                  medical conditions. For a comprehensive assessment of healthy weight, it's advisable to consider
                  multiple metrics including BMI, body fat percentage, waist-to-hip ratio, and overall fitness level,
                  ideally under the guidance of a healthcare professional.
                </p>
                <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-amber-800 text-sm">
                    <strong>Note:</strong> Ideal weight formulas provide general guidance and may not reflect individual
                    health needs. Consult a healthcare provider for personalized advice on your target weight.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
