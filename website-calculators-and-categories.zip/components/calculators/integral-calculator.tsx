"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type IntegralType = "indefinite" | "definite"

interface IntegralResult {
  integral: string
  latex: string
  definiteValue?: number
  steps: string[]
}

export function IntegralCalculator() {
  const [functionInput, setFunctionInput] = useState("")
  const [variable, setVariable] = useState("x")
  const [integralType, setIntegralType] = useState<IntegralType>("indefinite")
  const [lowerLimit, setLowerLimit] = useState("")
  const [upperLimit, setUpperLimit] = useState("")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<IntegralResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(true)

  // Parse and integrate functions
  const integrate = (func: string, v: string): { result: string; latex: string; steps: string[] } => {
    const steps: string[] = []
    func = func.replace(/\s+/g, "").toLowerCase()

    // Handle constants
    if (!func.includes(v)) {
      const constant = Number.parseFloat(func)
      if (!isNaN(constant)) {
        steps.push(`Integrating constant ${constant}`)
        steps.push(`∫${constant} d${v} = ${constant}${v}`)
        return { result: `${constant}${v} + C`, latex: `${constant}${v} + C`, steps }
      }
    }

    // Handle polynomial terms: ax^n
    const polynomialRegex = new RegExp(`^([+-]?\\d*\\.?\\d*)\\*?${v}\\^?([+-]?\\d*\\.?\\d*)$`)
    const match = func.match(polynomialRegex)

    if (match || func === v || func === `-${v}`) {
      let coef = 1
      let power = 1

      if (func === v) {
        coef = 1
        power = 1
      } else if (func === `-${v}`) {
        coef = -1
        power = 1
      } else if (match) {
        coef = match[1] === "" || match[1] === "+" ? 1 : match[1] === "-" ? -1 : Number.parseFloat(match[1])
        power = match[2] === "" ? 1 : Number.parseFloat(match[2])
      }

      if (!isNaN(coef) && !isNaN(power)) {
        steps.push(`Applying power rule: ∫${v}^n d${v} = ${v}^(n+1)/(n+1)`)
        const newPower = power + 1
        const newCoef = coef / newPower

        if (newPower === 1) {
          steps.push(`∫${coef}${v}^${power} d${v} = ${newCoef.toFixed(4).replace(/\.?0+$/, "")}${v}`)
          return {
            result: `${newCoef.toFixed(4).replace(/\.?0+$/, "")}${v} + C`,
            latex: `${newCoef.toFixed(4).replace(/\.?0+$/, "")}${v} + C`,
            steps,
          }
        }
        steps.push(`∫${coef}${v}^${power} d${v} = ${newCoef.toFixed(4).replace(/\.?0+$/, "")}${v}^${newPower}`)
        return {
          result: `${newCoef.toFixed(4).replace(/\.?0+$/, "")}${v}^${newPower} + C`,
          latex: `${newCoef.toFixed(4).replace(/\.?0+$/, "")}${v}^{${newPower}} + C`,
          steps,
        }
      }
    }

    // Handle simple x (power of 1)
    if (func === v) {
      steps.push(`Applying power rule: ∫${v} d${v} = ${v}²/2`)
      return { result: `${v}²/2 + C`, latex: `\\frac{${v}^2}{2} + C`, steps }
    }

    // Handle x^n patterns
    const powerMatch = func.match(new RegExp(`^${v}\\^([+-]?\\d+\\.?\\d*)$`))
    if (powerMatch) {
      const n = Number.parseFloat(powerMatch[1])
      if (n === -1) {
        steps.push(`Special case: ∫${v}^(-1) d${v} = ln|${v}|`)
        return { result: `ln|${v}| + C`, latex: `\\ln|${v}| + C`, steps }
      }
      const newPower = n + 1
      const coef = 1 / newPower
      steps.push(`Applying power rule: ∫${v}^${n} d${v} = ${v}^${newPower}/${newPower}`)
      return {
        result: `${coef.toFixed(4).replace(/\.?0+$/, "")}${v}^${newPower} + C`,
        latex: `\\frac{${v}^{${newPower}}}{${newPower}} + C`,
        steps,
      }
    }

    // Handle trigonometric functions
    if (func === `sin(${v})` || func === `sin${v}`) {
      steps.push(`Trigonometric integral: ∫sin(${v}) d${v} = -cos(${v})`)
      return { result: `-cos(${v}) + C`, latex: `-\\cos(${v}) + C`, steps }
    }
    if (func === `cos(${v})` || func === `cos${v}`) {
      steps.push(`Trigonometric integral: ∫cos(${v}) d${v} = sin(${v})`)
      return { result: `sin(${v}) + C`, latex: `\\sin(${v}) + C`, steps }
    }
    if (func === `tan(${v})` || func === `tan${v}`) {
      steps.push(`Trigonometric integral: ∫tan(${v}) d${v} = -ln|cos(${v})|`)
      return { result: `-ln|cos(${v})| + C`, latex: `-\\ln|\\cos(${v})| + C`, steps }
    }
    if (func === `sec(${v})^2` || func === `sec^2(${v})` || func === `sec2(${v})`) {
      steps.push(`Trigonometric integral: ∫sec²(${v}) d${v} = tan(${v})`)
      return { result: `tan(${v}) + C`, latex: `\\tan(${v}) + C`, steps }
    }
    if (func === `csc(${v})^2` || func === `csc^2(${v})` || func === `csc2(${v})`) {
      steps.push(`Trigonometric integral: ∫csc²(${v}) d${v} = -cot(${v})`)
      return { result: `-cot(${v}) + C`, latex: `-\\cot(${v}) + C`, steps }
    }
    if (func === `sec(${v})tan(${v})` || func === `sec(${v})*tan(${v})`) {
      steps.push(`Trigonometric integral: ∫sec(${v})tan(${v}) d${v} = sec(${v})`)
      return { result: `sec(${v}) + C`, latex: `\\sec(${v}) + C`, steps }
    }
    if (func === `csc(${v})cot(${v})` || func === `csc(${v})*cot(${v})`) {
      steps.push(`Trigonometric integral: ∫csc(${v})cot(${v}) d${v} = -csc(${v})`)
      return { result: `-csc(${v}) + C`, latex: `-\\csc(${v}) + C`, steps }
    }

    // Handle exponential functions
    if (func === `e^${v}` || func === `e^(${v})` || func === `exp(${v})`) {
      steps.push(`Exponential integral: ∫e^${v} d${v} = e^${v}`)
      return { result: `e^${v} + C`, latex: `e^{${v}} + C`, steps }
    }

    // Handle a^x
    const expMatch = func.match(/^(\d+)\^(\w+)$/)
    if (expMatch && expMatch[2] === v) {
      const base = Number.parseFloat(expMatch[1])
      steps.push(`Exponential integral: ∫${base}^${v} d${v} = ${base}^${v}/ln(${base})`)
      return {
        result: `${base}^${v}/ln(${base}) + C`,
        latex: `\\frac{${base}^{${v}}}{\\ln(${base})} + C`,
        steps,
      }
    }

    // Handle logarithmic functions
    if (func === `ln(${v})` || func === `log(${v})`) {
      steps.push(`Logarithmic integral: ∫ln(${v}) d${v} = ${v}ln(${v}) - ${v}`)
      return { result: `${v}ln(${v}) - ${v} + C`, latex: `${v}\\ln(${v}) - ${v} + C`, steps }
    }

    // Handle 1/x
    if (func === `1/${v}` || func === `${v}^-1` || func === `${v}^(-1)`) {
      steps.push(`Special case: ∫1/${v} d${v} = ln|${v}|`)
      return { result: `ln|${v}| + C`, latex: `\\ln|${v}| + C`, steps }
    }

    // Handle sqrt(x) = x^(1/2)
    if (func === `sqrt(${v})` || func === `√${v}`) {
      steps.push(`Rewrite: √${v} = ${v}^(1/2)`)
      steps.push(`Apply power rule: ∫${v}^(1/2) d${v} = (2/3)${v}^(3/2)`)
      return { result: `(2/3)${v}^(3/2) + C`, latex: `\\frac{2}{3}${v}^{3/2} + C`, steps }
    }

    // Handle 1/sqrt(1-x^2) = arcsin
    if (func === `1/sqrt(1-${v}^2)` || func === `1/√(1-${v}^2)`) {
      steps.push(`Standard integral: ∫1/√(1-${v}²) d${v} = arcsin(${v})`)
      return { result: `arcsin(${v}) + C`, latex: `\\arcsin(${v}) + C`, steps }
    }

    // Handle 1/(1+x^2) = arctan
    if (func === `1/(1+${v}^2)`) {
      steps.push(`Standard integral: ∫1/(1+${v}²) d${v} = arctan(${v})`)
      return { result: `arctan(${v}) + C`, latex: `\\arctan(${v}) + C`, steps }
    }

    // Try to parse polynomial expression with multiple terms
    const terms = func.match(/[+-]?[^+-]+/g)
    if (terms && terms.length > 1) {
      steps.push(`Breaking into sum/difference of integrals`)
      const integratedTerms: string[] = []
      const latexTerms: string[] = []

      for (const term of terms) {
        const trimmed = term.trim()
        const termResult = integrate(trimmed, v)
        const resultWithoutC = termResult.result.replace(/ \+ C$/, "")
        const latexWithoutC = termResult.latex.replace(/ \+ C$/, "")
        integratedTerms.push(resultWithoutC)
        latexTerms.push(latexWithoutC)
        steps.push(...termResult.steps.map((s) => `  ${s}`))
      }

      const combined = integratedTerms.join(" + ").replace(/\+ -/g, "- ")
      const latexCombined = latexTerms.join(" + ").replace(/\+ -/g, "- ")
      steps.push(`Combining: ${combined} + C`)
      return { result: `${combined} + C`, latex: `${latexCombined} + C`, steps }
    }

    // If we can't integrate, return the integral notation
    steps.push(`Unable to find closed-form antiderivative`)
    return { result: `∫${func} d${v}`, latex: `\\int ${func} \\, d${v}`, steps }
  }

  // Evaluate definite integral
  const evaluateDefinite = (antiderivative: string, v: string, lower: number, upper: number): number | null => {
    try {
      // Remove + C from antiderivative
      const expr = antiderivative.replace(/ \+ C$/, "")

      // Simple evaluation for polynomial and common functions
      const evalAt = (val: number): number => {
        let evalExpr = expr
          .replace(new RegExp(`${v}\\^(\\d+)`, "g"), (_, p) => `Math.pow(${val},${p})`)
          .replace(new RegExp(`${v}²`, "g"), `Math.pow(${val},2)`)
          .replace(new RegExp(`${v}³`, "g"), `Math.pow(${val},3)`)
          .replace(new RegExp(v, "g"), `(${val})`)
          .replace(/sin\(/g, "Math.sin(")
          .replace(/cos\(/g, "Math.cos(")
          .replace(/tan\(/g, "Math.tan(")
          .replace(/ln\|?/g, "Math.log(")
          .replace(/\|/g, ")")
          .replace(/e\^/g, "Math.exp(")
          .replace(/sqrt\(/g, "Math.sqrt(")
          .replace(/arcsin\(/g, "Math.asin(")
          .replace(/arccos\(/g, "Math.acos(")
          .replace(/arctan\(/g, "Math.atan(")

        // Handle fractions like (2/3)
        evalExpr = evalExpr.replace(/$$(\d+)\/(\d+)$$/g, (_, a, b) => `(${a}/${b})`)

        return eval(evalExpr)
      }

      const upperVal = evalAt(upper)
      const lowerVal = evalAt(lower)
      return upperVal - lowerVal
    } catch {
      return null
    }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (!functionInput.trim()) {
      setError("Please enter a function to integrate")
      return
    }

    if (integralType === "definite") {
      const lower = Number.parseFloat(lowerLimit)
      const upper = Number.parseFloat(upperLimit)
      if (isNaN(lower) || isNaN(upper)) {
        setError("Please enter valid numeric limits for definite integral")
        return
      }
    }

    try {
      const { result: integral, latex, steps } = integrate(functionInput, variable)

      let definiteValue: number | undefined
      if (integralType === "definite") {
        const lower = Number.parseFloat(lowerLimit)
        const upper = Number.parseFloat(upperLimit)
        const value = evaluateDefinite(integral, variable, lower, upper)
        if (value !== null) {
          definiteValue = Math.round(value * 1000000) / 1000000
        }
      }

      setResult({ integral, latex, definiteValue, steps })
    } catch {
      setError("Error integrating function. Please check your input.")
    }
  }

  const handleReset = () => {
    setFunctionInput("")
    setVariable("x")
    setIntegralType("indefinite")
    setLowerLimit("")
    setUpperLimit("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        integralType === "definite" && result.definiteValue !== undefined
          ? `∫[${lowerLimit},${upperLimit}] ${functionInput} d${variable} = ${result.definiteValue}`
          : `∫${functionInput} d${variable} = ${result.integral}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      const latex =
        integralType === "definite"
          ? `\\int_{${lowerLimit}}^{${upperLimit}} ${functionInput} \\, d${variable} = ${result.definiteValue ?? result.latex}`
          : `\\int ${functionInput} \\, d${variable} = ${result.latex}`
      await navigator.clipboard.writeText(latex)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text =
          integralType === "definite" && result.definiteValue !== undefined
            ? `∫[${lowerLimit},${upperLimit}] ${functionInput} d${variable} = ${result.definiteValue}`
            : `∫${functionInput} d${variable} = ${result.integral}`
        await navigator.share({
          title: "Integral Calculation",
          text: `I calculated an integral using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Integral Calculator</CardTitle>
                    <CardDescription>Calculate definite and indefinite integrals</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Function Input */}
                <div className="space-y-2">
                  <Label htmlFor="function">Function f({variable})</Label>
                  <Input
                    id="function"
                    type="text"
                    placeholder="e.g., x^2, sin(x), e^x, 3x^2+2x-1"
                    value={functionInput}
                    onChange={(e) => setFunctionInput(e.target.value)}
                  />
                </div>

                {/* Variable and Type Selection */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="variable">Variable</Label>
                    <Select value={variable} onValueChange={setVariable}>
                      <SelectTrigger id="variable">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="x">x</SelectItem>
                        <SelectItem value="y">y</SelectItem>
                        <SelectItem value="t">t</SelectItem>
                        <SelectItem value="z">z</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Integral Type</Label>
                    <Select value={integralType} onValueChange={(v) => setIntegralType(v as IntegralType)}>
                      <SelectTrigger id="type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="indefinite">Indefinite</SelectItem>
                        <SelectItem value="definite">Definite</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Limits for Definite Integral */}
                {integralType === "definite" && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="lower">Lower Limit (a)</Label>
                      <Input
                        id="lower"
                        type="number"
                        placeholder="0"
                        value={lowerLimit}
                        onChange={(e) => setLowerLimit(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="upper">Upper Limit (b)</Label>
                      <Input
                        id="upper"
                        type="number"
                        placeholder="1"
                        value={upperLimit}
                        onChange={(e) => setUpperLimit(e.target.value)}
                      />
                    </div>
                  </div>
                )}

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show Step-by-Step Solution</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Integral
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {integralType === "indefinite" ? "Antiderivative" : "Definite Integral"}
                      </p>
                      {integralType === "definite" && result.definiteValue !== undefined ? (
                        <>
                          <p className="text-lg text-muted-foreground mb-2">
                            ∫[{lowerLimit},{upperLimit}] {functionInput} d{variable}
                          </p>
                          <p className="text-4xl font-bold text-blue-600 mb-2">{result.definiteValue}</p>
                        </>
                      ) : (
                        <>
                          <p className="text-lg text-muted-foreground mb-2">
                            ∫ {functionInput} d{variable} =
                          </p>
                          <p className="text-3xl font-bold text-blue-600 mb-2">{result.integral}</p>
                        </>
                      )}
                    </div>

                    {/* Step-by-Step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            <span>Solution Steps</span>
                            {stepsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="p-3 bg-white rounded-lg border space-y-2">
                            {result.steps.map((step, index) => (
                              <div key={index} className="flex gap-2 text-sm">
                                <span className="text-muted-foreground font-mono">
                                  {step.startsWith("  ") ? "  •" : `${index + 1}.`}
                                </span>
                                <span className="font-mono">{step.trim()}</span>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Basic Integration Rules</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">∫xⁿ dx</span>
                      <span className="font-mono text-muted-foreground">xⁿ⁺¹/(n+1) + C</span>
                    </div>
                    <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">∫eˣ dx</span>
                      <span className="font-mono text-muted-foreground">eˣ + C</span>
                    </div>
                    <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">∫sin(x) dx</span>
                      <span className="font-mono text-muted-foreground">-cos(x) + C</span>
                    </div>
                    <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">∫cos(x) dx</span>
                      <span className="font-mono text-muted-foreground">sin(x) + C</span>
                    </div>
                    <div className="flex justify-between p-3 rounded-lg bg-muted/50">
                      <span className="font-mono">∫1/x dx</span>
                      <span className="font-mono text-muted-foreground">ln|x| + C</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">Supported formats:</p>
                    <ul className="list-disc list-inside space-y-1 ml-2">
                      <li>
                        <span className="font-mono">x^2</span> for x²
                      </li>
                      <li>
                        <span className="font-mono">3x^2+2x-1</span> for polynomials
                      </li>
                      <li>
                        <span className="font-mono">sin(x), cos(x), tan(x)</span>
                      </li>
                      <li>
                        <span className="font-mono">e^x</span> or <span className="font-mono">exp(x)</span>
                      </li>
                      <li>
                        <span className="font-mono">ln(x)</span> for natural log
                      </li>
                      <li>
                        <span className="font-mono">sqrt(x)</span> for square root
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Definite vs Indefinite</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-semibold text-blue-700 mb-1">Indefinite Integral</p>
                    <p className="text-blue-600">
                      Finds the antiderivative F(x) such that F'(x) = f(x). Result includes + C for the constant of
                      integration.
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-semibold text-green-700 mb-1">Definite Integral</p>
                    <p className="text-green-600">
                      Calculates the exact area under the curve from x = a to x = b using the Fundamental Theorem of
                      Calculus: F(b) - F(a).
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Integration?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Integration is one of the two fundamental operations in calculus, alongside differentiation. While
                  differentiation finds the rate of change of a function, integration performs the reverse operation -
                  it finds the original function given its derivative. This process is also known as finding the
                  antiderivative or primitive function. Integration has countless applications in mathematics, physics,
                  engineering, and economics, from calculating areas and volumes to solving differential equations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The integral symbol ∫ was introduced by Leibniz and is an elongated "S" representing "summa" (sum).
                  This reflects the geometric interpretation of integration as the limit of a sum of infinitesimally
                  small rectangles under a curve. The constant C in indefinite integrals represents the family of all
                  antiderivatives, since any constant disappears when differentiated.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Integration Techniques</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several techniques exist for evaluating integrals depending on the form of the integrand. The power
                  rule is the most basic, stating that ∫xⁿ dx = xⁿ⁺¹/(n+1) + C for n ≠ -1. Substitution (u-substitution)
                  is used when the integrand contains a composite function, while integration by parts handles products
                  of functions using the formula ∫u dv = uv - ∫v du.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  More advanced techniques include partial fractions for rational functions, trigonometric substitution
                  for integrands containing square roots of quadratic expressions, and trigonometric identities for
                  products of trigonometric functions. Some integrals cannot be expressed in terms of elementary
                  functions and require numerical methods or special functions.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  This calculator uses symbolic integration rules for common function types. Results depend on correct
                  function input and supported formats. For complex integrals involving advanced techniques like
                  integration by parts or substitution, consider using specialized computer algebra systems. Always
                  verify results for academic or professional work.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
