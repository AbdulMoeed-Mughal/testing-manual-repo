"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "date-to-week" | "week-to-date"
type WeekStart = "monday" | "sunday"

interface WeekResult {
  weekNumber: number
  year: number
  startDate?: string
  endDate?: string
}

export function WeekNumberCalculator() {
  const [mode, setMode] = useState<CalculationMode>("date-to-week")
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])
  const [weekNumber, setWeekNumber] = useState("")
  const [year, setYear] = useState(new Date().getFullYear().toString())
  const [weekStart, setWeekStart] = useState<WeekStart>("monday")
  const [result, setResult] = useState<WeekResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const getWeekNumber = (date: Date, firstDayOfWeek: WeekStart): number => {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()))
    const dayNum = firstDayOfWeek === "monday" ? (d.getUTCDay() + 6) % 7 : d.getUTCDay()
    d.setUTCDate(d.getUTCDate() + 4 - dayNum)
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
    const weekNo = Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7)
    return weekNo
  }

  const getDateFromWeek = (yearNum: number, weekNum: number, firstDayOfWeek: WeekStart): { start: Date; end: Date } => {
    const jan1 = new Date(yearNum, 0, 1)
    const jan1Day = firstDayOfWeek === "monday" ? (jan1.getDay() + 6) % 7 : jan1.getDay()
    const daysToFirstWeek = jan1Day <= 3 ? -jan1Day : 7 - jan1Day
    const firstWeekStart = new Date(yearNum, 0, 1 + daysToFirstWeek)
    const targetWeekStart = new Date(firstWeekStart)
    targetWeekStart.setDate(firstWeekStart.getDate() + (weekNum - 1) * 7)
    const targetWeekEnd = new Date(targetWeekStart)
    targetWeekEnd.setDate(targetWeekStart.getDate() + 6)
    return { start: targetWeekStart, end: targetWeekEnd }
  }

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (mode === "date-to-week") {
      const date = new Date(selectedDate)
      if (isNaN(date.getTime())) {
        setError("Please enter a valid date")
        return
      }

      const week = getWeekNumber(date, weekStart)
      const dates = getDateFromWeek(date.getFullYear(), week, weekStart)

      setResult({
        weekNumber: week,
        year: date.getFullYear(),
        startDate: formatDate(dates.start),
        endDate: formatDate(dates.end),
      })
    } else {
      const yearNum = Number.parseInt(year)
      const weekNum = Number.parseInt(weekNumber)

      if (isNaN(yearNum) || yearNum < 1900 || yearNum > 2100) {
        setError("Please enter a valid year between 1900 and 2100")
        return
      }

      if (isNaN(weekNum) || weekNum < 1 || weekNum > 53) {
        setError("Please enter a valid week number between 1 and 53")
        return
      }

      const dates = getDateFromWeek(yearNum, weekNum, weekStart)

      setResult({
        weekNumber: weekNum,
        year: yearNum,
        startDate: formatDate(dates.start),
        endDate: formatDate(dates.end),
      })
    }
  }

  const handleReset = () => {
    setSelectedDate(new Date().toISOString().split("T")[0])
    setWeekNumber("")
    setYear(new Date().getFullYear().toString())
    setWeekStart("monday")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        mode === "date-to-week"
          ? `Week ${result.weekNumber} of ${result.year} (${result.startDate} - ${result.endDate})`
          : `Week ${result.weekNumber}, ${result.year}: ${result.startDate} - ${result.endDate}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text =
          mode === "date-to-week"
            ? `Week ${result.weekNumber} of ${result.year}`
            : `Week ${result.weekNumber}, ${result.year}: ${result.startDate} - ${result.endDate}`
        await navigator.share({
          title: "Week Number Result",
          text: `I calculated using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Week Number Calculator</CardTitle>
                    <CardDescription>Calculate week numbers and date ranges</CardDescription>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Mode</span>
                  <button
                    onClick={() => setMode(mode === "date-to-week" ? "week-to-date" : "date-to-week")}
                    className="relative inline-flex h-9 w-52 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "week-to-date" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "date-to-week" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Date to Week
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "week-to-date" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Week to Date
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {mode === "date-to-week" ? (
                  <div className="space-y-2">
                    <Label htmlFor="date">Select Date</Label>
                    <Input id="date" type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
                  </div>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="year">Year</Label>
                      <Input
                        id="year"
                        type="number"
                        placeholder="Enter year"
                        value={year}
                        onChange={(e) => setYear(e.target.value)}
                        min="1900"
                        max="2100"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="weekNumber">Week Number</Label>
                      <Input
                        id="weekNumber"
                        type="number"
                        placeholder="Enter week number (1-53)"
                        value={weekNumber}
                        onChange={(e) => setWeekNumber(e.target.value)}
                        min="1"
                        max="53"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="weekStart">Week Starts On</Label>
                  <Select value={weekStart} onValueChange={(value) => setWeekStart(value as WeekStart)}>
                    <SelectTrigger id="weekStart">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monday">Monday (ISO Standard)</SelectItem>
                      <SelectItem value="sunday">Sunday</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Week Number</p>
                        <p className="text-5xl font-bold text-cyan-600">{result.weekNumber}</p>
                        <p className="text-lg font-semibold text-cyan-600 mt-1">of {result.year}</p>
                      </div>

                      {result.startDate && result.endDate && (
                        <div className="pt-3 border-t border-cyan-200">
                          <p className="text-sm text-muted-foreground mb-1">Week Range</p>
                          <p className="text-sm font-medium text-cyan-700">
                            {result.startDate} – {result.endDate}
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">ISO Week Standards</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>The ISO 8601 standard defines the week as:</p>
                  <ul className="list-disc list-inside space-y-2 ml-2">
                    <li>Weeks start on Monday and end on Sunday</li>
                    <li>Week 1 is the first week with Thursday in the new year</li>
                    <li>Most years have 52 weeks, but some have 53</li>
                    <li>Years with 53 weeks: Last or first week spans into next year</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Uses</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong className="text-foreground">Business Planning:</strong> Schedule meetings and deadlines
                  </p>
                  <p>
                    <strong className="text-foreground">Project Management:</strong> Track sprint cycles and milestones
                  </p>
                  <p>
                    <strong className="text-foreground">Reporting:</strong> Generate weekly reports and analytics
                  </p>
                  <p>
                    <strong className="text-foreground">Payroll:</strong> Calculate weekly pay periods
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Week Numbers</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Week numbering systems are used worldwide for scheduling, planning, and organizing activities by week rather than by specific dates. The most common system is the ISO 8601 standard, which defines weeks as starting on Monday and ending on Sunday. This international standard ensures consistency across different countries and industries, making it easier to coordinate global operations and communications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Week numbers are particularly valuable in business environments where activities are organized on a weekly basis. Manufacturing companies use week numbers for production scheduling, retailers use them for promotional planning, and project managers use them to track sprint cycles. Understanding which week number corresponds to a specific date helps teams stay aligned and ensures everyone is working with the same temporal reference points.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>How Week Numbers Work</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The ISO 8601 standard uses specific rules to determine week numbers. Week 1 of any year is defined as the first week that contains at least four days of the new year, or equivalently, the week containing the first Thursday of January. This means that Week 1 can start as early as December 29 of the previous year or as late as January 4 of the current year. All subsequent weeks are numbered sequentially from this starting point.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Most years contain 52 weeks, but occasionally a year will have 53 weeks. This happens in years where January 1 falls on a Thursday, or in leap years where January 1 falls on a Wednesday. In these cases, the year extends into the first few days of the next calendar year to complete the 53rd week. This system ensures that each week is always complete with seven days, maintaining consistency in weekly planning and scheduling.
                </p>
              </CardContent>
            </Card>

            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-amber-800">
                  <p className="font-semibold mb-1">Note</p>
                  <p>
                    Week number calculations follow ISO standards and are based on entered dates. Results may vary depending on week start selection and calendar differences.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
