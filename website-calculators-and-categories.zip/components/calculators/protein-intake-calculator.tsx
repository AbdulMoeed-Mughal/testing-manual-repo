"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Beef,
  Info,
  Activity,
  Target,
  Dumbbell,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityLevel = "sedentary" | "light" | "moderate" | "very-active" | "athlete"
type FitnessGoal = "maintenance" | "fat-loss" | "muscle-gain"

interface ProteinResult {
  dailyProtein: number
  proteinPerKg: number
  proteinPerMeal: number
  minProtein: number
  maxProtein: number
}

const activityMultipliers: Record<ActivityLevel, number> = {
  sedentary: 0.8,
  light: 1.0,
  moderate: 1.2,
  "very-active": 1.5,
  athlete: 1.8,
}

const goalAdjustments: Record<FitnessGoal, number> = {
  maintenance: 0,
  "fat-loss": 0.2,
  "muscle-gain": 0.4,
}

const activityLabels: Record<ActivityLevel, string> = {
  sedentary: "Sedentary",
  light: "Lightly Active",
  moderate: "Moderately Active",
  "very-active": "Very Active",
  athlete: "Athlete",
}

const goalLabels: Record<FitnessGoal, string> = {
  maintenance: "Maintenance",
  "fat-loss": "Fat Loss",
  "muscle-gain": "Muscle Gain",
}

export function ProteinIntakeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")
  const [fitnessGoal, setFitnessGoal] = useState<FitnessGoal>("maintenance")
  const [mealsPerDay, setMealsPerDay] = useState("4")
  const [result, setResult] = useState<ProteinResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [warning, setWarning] = useState("")

  const calculateProtein = () => {
    setError("")
    setWarning("")
    setResult(null)

    const ageNum = Number.parseInt(age)
    const weightNum = Number.parseFloat(weight)
    const mealsNum = Number.parseInt(mealsPerDay)

    if (isNaN(ageNum) || ageNum < 10) {
      setError("Please enter a valid age (10 years or older)")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(mealsNum) || mealsNum < 1 || mealsNum > 10) {
      setError("Please enter a valid number of meals (1-10)")
      return
    }

    // Convert to kg if imperial
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Calculate protein multiplier
    const baseMultiplier = activityMultipliers[activityLevel]
    const goalAdjustment = goalAdjustments[fitnessGoal]
    const totalMultiplier = baseMultiplier + goalAdjustment

    // Calculate daily protein
    const dailyProtein = Math.round(weightInKg * totalMultiplier)
    const proteinPerKg = Math.round(totalMultiplier * 10) / 10
    const proteinPerMeal = Math.round(dailyProtein / mealsNum)

    // Calculate range (±10%)
    const minProtein = Math.round(dailyProtein * 0.9)
    const maxProtein = Math.round(dailyProtein * 1.1)

    // Warning for high intake
    if (dailyProtein > 200) {
      setWarning("This is a high protein intake. Consider consulting a healthcare professional.")
    }

    setResult({
      dailyProtein,
      proteinPerKg,
      proteinPerMeal,
      minProtein,
      maxProtein,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setActivityLevel("moderate")
    setFitnessGoal("maintenance")
    setMealsPerDay("4")
    setResult(null)
    setError("")
    setWarning("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My recommended daily protein intake is ${result.dailyProtein}g (${result.proteinPerKg}g/kg body weight)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Protein Intake",
          text: `I calculated my daily protein needs using CalcHub! I need ${result.dailyProtein}g of protein per day.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setResult(null)
    setError("")
    setWarning("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Beef className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Protein Intake Calculator</CardTitle>
                    <CardDescription>Calculate your daily protein needs</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender (optional)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setGender("male")}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        gender === "male"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted hover:border-muted-foreground/30"
                      }`}
                    >
                      <span className="font-medium">Male</span>
                    </button>
                    <button
                      onClick={() => setGender("female")}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        gender === "female"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted hover:border-muted-foreground/30"
                      }`}
                    >
                      <span className="font-medium">Female</span>
                    </button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {(Object.keys(activityMultipliers) as ActivityLevel[]).map((level) => (
                      <button
                        key={level}
                        onClick={() => setActivityLevel(level)}
                        className={`p-2 sm:p-3 rounded-lg border-2 transition-all text-xs sm:text-sm ${
                          activityLevel === level
                            ? "border-primary bg-primary/5 text-primary"
                            : "border-muted hover:border-muted-foreground/30"
                        }`}
                      >
                        <span className="font-medium">{activityLabels[level]}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Fitness Goal */}
                <div className="space-y-2">
                  <Label>Fitness Goal</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {(Object.keys(goalAdjustments) as FitnessGoal[]).map((goal) => (
                      <button
                        key={goal}
                        onClick={() => setFitnessGoal(goal)}
                        className={`p-2 sm:p-3 rounded-lg border-2 transition-all text-xs sm:text-sm ${
                          fitnessGoal === goal
                            ? goal === "fat-loss"
                              ? "border-blue-500 bg-blue-50 text-blue-600"
                              : goal === "muscle-gain"
                                ? "border-green-500 bg-green-50 text-green-600"
                                : "border-primary bg-primary/5 text-primary"
                            : "border-muted hover:border-muted-foreground/30"
                        }`}
                      >
                        <span className="font-medium">{goalLabels[goal]}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Meals Per Day */}
                <div className="space-y-2">
                  <Label htmlFor="meals">Meals Per Day</Label>
                  <Input
                    id="meals"
                    type="number"
                    placeholder="Number of meals (3-5)"
                    value={mealsPerDay}
                    onChange={(e) => setMealsPerDay(e.target.value)}
                    min="1"
                    max="10"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateProtein} className="w-full" size="lg">
                  Calculate Protein Intake
                </Button>

                {/* Warning */}
                {warning && (
                  <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200 text-yellow-700 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {warning}
                  </div>
                )}

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Daily Protein Intake</p>
                      <p className="text-5xl font-bold text-green-600 mb-2">{result.dailyProtein}g</p>
                      <p className="text-sm text-green-600">
                        Range: {result.minProtein}g - {result.maxProtein}g per day
                      </p>
                    </div>

                    {/* Additional Stats */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white/80 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Per Meal</p>
                        <p className="text-lg font-semibold text-foreground">{result.proteinPerMeal}g</p>
                      </div>
                      <div className="p-3 bg-white/80 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Per kg Body Weight</p>
                        <p className="text-lg font-semibold text-foreground">{result.proteinPerKg}g/kg</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Protein Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-200">
                      <span className="font-medium text-slate-700">Sedentary</span>
                      <span className="text-sm text-slate-600">0.8 g/kg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Lightly Active</span>
                      <span className="text-sm text-blue-600">1.0 g/kg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Moderately Active</span>
                      <span className="text-sm text-green-600">1.2 g/kg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Very Active</span>
                      <span className="text-sm text-orange-600">1.5 g/kg</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Athlete</span>
                      <span className="text-sm text-red-600">1.8 g/kg</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Goal Adjustments</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Maintenance</span>
                      <span className="text-sm text-muted-foreground">No adjustment</span>
                    </div>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-blue-700">Fat Loss</span>
                      <span className="text-sm text-blue-600">+0.2 g/kg</span>
                    </div>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-green-700">Muscle Gain</span>
                      <span className="text-sm text-green-600">+0.4 g/kg</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-yellow-50 border-yellow-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-yellow-800">
                      Protein needs vary by individual. Consult a healthcare professional for personalized advice,
                      especially if you have kidney conditions or other health concerns.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Protein */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Protein and Why Do You Need It?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Protein is one of the three essential macronutrients that your body requires in large amounts to
                  function properly, alongside carbohydrates and fats. It is made up of amino acids, often referred to
                  as the building blocks of life. These amino acids are crucial for building and repairing tissues,
                  making enzymes and hormones, and supporting immune function. Unlike carbohydrates and fats, your body
                  cannot store protein, which means you need to consume it regularly through your diet to meet your
                  body's needs.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Protein plays a vital role in muscle synthesis, which is the process of building new muscle tissue.
                  When you exercise, especially during resistance training, you create microscopic tears in your muscle
                  fibers. Protein provides the amino acids necessary to repair these tears and build stronger, larger
                  muscles. Beyond muscle health, protein is essential for maintaining healthy skin, hair, and nails,
                  producing antibodies that fight infections, and creating enzymes that drive thousands of chemical
                  reactions in your body every day.
                </p>
              </CardContent>
            </Card>

            {/* How Protein Requirements are Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How Protein Requirements are Calculated</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Protein requirements are typically calculated based on your body weight and activity level. The
                  standard recommendation from health organizations like the World Health Organization (WHO) is 0.8
                  grams of protein per kilogram of body weight for sedentary adults. However, this is a minimum
                  requirement to prevent deficiency, not an optimal intake for health and performance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Research has consistently shown that physically active individuals require significantly more protein
                  than sedentary people. Endurance athletes may need 1.2 to 1.4 grams per kilogram, while strength
                  athletes and those looking to build muscle may benefit from 1.6 to 2.2 grams per kilogram. The
                  calculation in this tool uses evidence-based multipliers that account for your activity level and
                  fitness goals, providing a personalized recommendation rather than a one-size-fits-all approach.
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting Protein Needs */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Factors That Affect Your Protein Needs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence how much protein your body requires. Your activity level is one of the most
                  significant factors—the more active you are, the more protein you need to support muscle repair and
                  growth. Athletes and individuals who engage in regular resistance training have substantially higher
                  protein requirements than those who lead sedentary lifestyles. The intensity and duration of your
                  workouts also play a role, with longer and more intense sessions creating greater protein demands.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Your fitness goals significantly impact your protein needs as well. If you're trying to lose fat while
                  preserving muscle mass, you'll need more protein to prevent muscle breakdown during a caloric deficit.
                  Similarly, if your goal is to build muscle, you'll need extra protein to support muscle protein
                  synthesis. Age is another important factor—older adults often need more protein to combat age-related
                  muscle loss (sarcopenia). Other factors include overall health status, recovery from illness or
                  surgery, and pregnancy or breastfeeding, all of which increase protein requirements.
                </p>
              </CardContent>
            </Card>

            {/* Best Protein Sources */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beef className="h-5 w-5 text-primary" />
                  <CardTitle>Best Sources of Dietary Protein</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Protein can be obtained from both animal and plant sources, each with their own advantages. Animal
                  proteins such as chicken, beef, fish, eggs, and dairy products are considered complete proteins
                  because they contain all nine essential amino acids in adequate proportions. These sources are also
                  highly bioavailable, meaning your body can efficiently absorb and utilize the protein they provide.
                  Fish offers the added benefit of omega-3 fatty acids, while lean poultry provides high-quality protein
                  with minimal saturated fat.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Plant-based proteins include legumes (beans, lentils, chickpeas), nuts and seeds, tofu, tempeh, and
                  whole grains. While most plant proteins are incomplete on their own, eating a variety of plant foods
                  throughout the day ensures you get all essential amino acids. Combining foods like rice and beans or
                  hummus with whole wheat pita creates complete protein combinations. Plant proteins also come with
                  fiber, vitamins, and antioxidants that support overall health. For those following vegetarian or vegan
                  diets, paying attention to protein variety is key to meeting nutritional needs.
                </p>
              </CardContent>
            </Card>

            {/* Tips for Meeting Protein Goals */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Dumbbell className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Meeting Your Daily Protein Goals</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Meeting your daily protein goals is easier when you distribute your intake evenly across meals rather
                  than consuming most of your protein in one sitting. Research suggests that your body can only
                  effectively utilize about 25-40 grams of protein per meal for muscle protein synthesis, so spreading
                  your intake helps maximize the benefits. Start your day with a protein-rich breakfast—eggs, Greek
                  yogurt, or a protein smoothie can provide 20-30 grams to kickstart your metabolism and muscle repair
                  processes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Meal prepping can help ensure you always have high-protein options available, reducing the temptation
                  to reach for lower-protein convenience foods. Keep protein-rich snacks on hand such as hard-boiled
                  eggs, cottage cheese, jerky, or protein bars for times between meals. If you struggle to meet your
                  goals through whole foods alone, protein supplements like whey, casein, or plant-based protein powders
                  can be convenient options. However, prioritize whole food sources when possible, as they provide
                  additional nutrients that supplements cannot replicate.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
