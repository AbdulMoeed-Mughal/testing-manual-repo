"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Building2, Info, Calculator, DollarSign } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Currency = "USD" | "INR"

interface BudgetResult {
  baseCost: number
  laborCost: number
  materialCost: number
  finishingCost: number
  contingency: number
  totalCost: number
}

export function ConstructionBudgetEstimator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [currency, setCurrency] = useState<Currency>("USD")
  const [area, setArea] = useState("")
  const [costPerUnit, setCostPerUnit] = useState("")
  const [laborCost, setLaborCost] = useState("")
  const [materialCost, setMaterialCost] = useState("")
  const [finishingCost, setFinishingCost] = useState("")
  const [contingencyPercent, setContingencyPercent] = useState("10")
  const [result, setResult] = useState<BudgetResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBudget = () => {
    setError("")
    setResult(null)

    const areaNum = Number.parseFloat(area)
    const costNum = Number.parseFloat(costPerUnit)
    const contingencyNum = Number.parseFloat(contingencyPercent)

    if (isNaN(areaNum) || areaNum <= 0) {
      setError("Please enter a valid area greater than 0")
      return
    }
    if (isNaN(costNum) || costNum <= 0) {
      setError("Please enter a valid cost per unit greater than 0")
      return
    }
    if (isNaN(contingencyNum) || contingencyNum < 0) {
      setError("Contingency percentage must be 0 or greater")
      return
    }

    const laborNum = Number.parseFloat(laborCost) || 0
    const materialNum = Number.parseFloat(materialCost) || 0
    const finishingNum = Number.parseFloat(finishingCost) || 0

    const baseCost = areaNum * costNum
    const subtotal = baseCost + laborNum + materialNum + finishingNum
    const contingency = subtotal * (contingencyNum / 100)
    const totalCost = subtotal + contingency

    setResult({
      baseCost,
      laborCost: laborNum,
      materialCost: materialNum,
      finishingCost: finishingNum,
      contingency,
      totalCost,
    })
  }

  const handleReset = () => {
    setArea("")
    setCostPerUnit("")
    setLaborCost("")
    setMaterialCost("")
    setFinishingCost("")
    setContingencyPercent("10")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const currencySymbol = currency === "USD" ? "$" : "₹"
      await navigator.clipboard.writeText(
        `Construction Budget Estimate: ${currencySymbol}${result.totalCost.toLocaleString(undefined, {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const currencySymbol = currency === "USD" ? "$" : "₹"
      try {
        await navigator.share({
          title: "Construction Budget Estimate",
          text: `Construction Budget: ${currencySymbol}${result.totalCost.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setArea("")
    setCostPerUnit("")
    setResult(null)
    setError("")
  }

  const currencySymbol = currency === "USD" ? "$" : "₹"
  const areaUnit = unitSystem === "metric" ? "m²" : "ft²"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Construction Budget Estimator</CardTitle>
                    <CardDescription>Estimate total construction costs</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Currency Selection */}
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select value={currency} onValueChange={(value) => setCurrency(value as Currency)}>
                    <SelectTrigger id="currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD ($)</SelectItem>
                      <SelectItem value="INR">INR (₹)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="area">
                    Plinth / Built-up Area ({areaUnit})
                  </Label>
                  <Input
                    id="area"
                    type="number"
                    placeholder={`Enter area in ${areaUnit}`}
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Cost per unit */}
                <div className="space-y-2">
                  <Label htmlFor="costPerUnit">
                    Construction Cost per {areaUnit} ({currencySymbol})
                  </Label>
                  <Input
                    id="costPerUnit"
                    type="number"
                    placeholder={`Enter cost per ${areaUnit}`}
                    value={costPerUnit}
                    onChange={(e) => setCostPerUnit(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Labor Cost */}
                <div className="space-y-2">
                  <Label htmlFor="laborCost">
                    Labor Cost ({currencySymbol}) - Optional
                  </Label>
                  <Input
                    id="laborCost"
                    type="number"
                    placeholder="Enter labor cost"
                    value={laborCost}
                    onChange={(e) => setLaborCost(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Material Cost */}
                <div className="space-y-2">
                  <Label htmlFor="materialCost">
                    Material Cost ({currencySymbol}) - Optional
                  </Label>
                  <Input
                    id="materialCost"
                    type="number"
                    placeholder="Enter material cost"
                    value={materialCost}
                    onChange={(e) => setMaterialCost(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Finishing Cost */}
                <div className="space-y-2">
                  <Label htmlFor="finishingCost">
                    Finishing/Fittings Cost ({currencySymbol}) - Optional
                  </Label>
                  <Input
                    id="finishingCost"
                    type="number"
                    placeholder="Enter finishing cost"
                    value={finishingCost}
                    onChange={(e) => setFinishingCost(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Contingency Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="contingency">Contingency (%)</Label>
                  <Input
                    id="contingency"
                    type="number"
                    placeholder="Enter contingency percentage"
                    value={contingencyPercent}
                    onChange={(e) => setContingencyPercent(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBudget} className="w-full" size="lg">
                  Calculate Budget
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Budget</p>
                      <p className="text-4xl font-bold text-amber-600">
                        {currencySymbol}
                        {result.totalCost.toLocaleString(undefined, {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </p>
                    </div>

                    {/* Cost Breakdown */}
                    <div className="space-y-2 mb-4 text-sm">
                      <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                        <span className="text-muted-foreground">Base Construction:</span>
                        <span className="font-semibold">
                          {currencySymbol}
                          {result.baseCost.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                      {result.laborCost > 0 && (
                        <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                          <span className="text-muted-foreground">Labor:</span>
                          <span className="font-semibold">
                            {currencySymbol}
                            {result.laborCost.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </span>
                        </div>
                      )}
                      {result.materialCost > 0 && (
                        <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                          <span className="text-muted-foreground">Materials:</span>
                          <span className="font-semibold">
                            {currencySymbol}
                            {result.materialCost.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </span>
                        </div>
                      )}
                      {result.finishingCost > 0 && (
                        <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                          <span className="text-muted-foreground">Finishing/Fittings:</span>
                          <span className="font-semibold">
                            {currencySymbol}
                            {result.finishingCost.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </span>
                        </div>
                      )}
                      <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                        <span className="text-muted-foreground">
                          Contingency ({contingencyPercent}%):
                        </span>
                        <span className="font-semibold">
                          {currencySymbol}
                          {result.contingency.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Budget Components</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-900 mb-1">Base Construction</h4>
                      <p className="text-amber-700">Area multiplied by cost per unit - core construction expenses</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-900 mb-1">Labor</h4>
                      <p className="text-amber-700">Wages for workers, contractors, and skilled labor</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-900 mb-1">Materials</h4>
                      <p className="text-amber-700">Cement, steel, bricks, sand, aggregate, and other supplies</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-900 mb-1">Finishing</h4>
                      <p className="text-amber-700">Paint, tiles, fittings, electrical, plumbing fixtures</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-900 mb-1">Contingency</h4>
                      <p className="text-amber-700">Buffer for unforeseen costs, typically 5-10% of total</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Construction Budget */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Construction Budget?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A construction budget is a comprehensive financial plan that outlines all anticipated costs for a
                  building project, from initial site preparation to final finishing touches. It serves as a critical
                  roadmap for managing expenses and ensuring that the project stays financially viable throughout the
                  construction process. A well-prepared budget includes direct costs like materials and labor, as well
                  as indirect costs such as permits, insurance, and contingencies for unexpected expenses.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Creating an accurate construction budget requires careful consideration of multiple factors including
                  regional cost variations, material quality, labor rates, project complexity, and timeline. Professional
                  contractors and builders typically add a contingency percentage of 5-10% to account for unforeseen
                  circumstances such as material price fluctuations, weather delays, or design changes. This buffer helps
                  prevent cost overruns and ensures the project can be completed even when unexpected challenges arise.
                </p>
              </CardContent>
            </Card>

            {/* How to Estimate Construction Costs */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Estimate Construction Costs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Estimating construction costs begins with calculating the base construction cost, which is determined by
                  multiplying the total area (in square meters or square feet) by the cost per unit area. This rate varies
                  significantly based on location, building type (residential vs. commercial), and quality of construction.
                  For example, basic residential construction might cost $100-150 per square foot in the United States,
                  while high-end construction can exceed $300 per square foot.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Beyond the base cost, additional expenses must be factored in. Labor costs typically account for 20-40%
                  of the total budget and vary by region and skill level. Material costs fluctuate based on market
                  conditions and quality requirements. Finishing costs including flooring, paint, fixtures, and fittings
                  can add 15-25% to the base cost. Finally, a contingency buffer of 5-10% helps absorb unexpected expenses
                  that commonly arise during construction, such as soil remediation, structural modifications, or code
                  compliance upgrades.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Common Construction Budgeting Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      What percentage should I allocate for contingency?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Most construction professionals recommend a contingency of 5-10% for new construction and 10-20% for
                      renovation projects. Renovations typically require higher contingencies because unexpected issues
                      like hidden structural problems, asbestos, or outdated electrical systems are more likely to be
                      discovered during work.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      How can I reduce construction costs without compromising quality?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Consider value engineering strategies such as optimizing design efficiency, selecting cost-effective
                      materials that meet quality standards, obtaining multiple contractor bids, timing construction to
                      avoid peak season pricing, and avoiding mid-project design changes. Simple architectural designs
                      with fewer custom features can also significantly reduce costs while maintaining quality.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      What hidden costs should I be aware of?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Hidden costs often include permit fees, site surveys, soil testing, utility connections, temporary
                      facilities during construction, landscaping, driveway paving, waste disposal, and potential
                      increases in property taxes. Additionally, financing costs, insurance, and interest on construction
                      loans should be factored into your overall budget planning.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Construction budget estimates are approximate. Actual costs vary depending
                  on material quality, labor rates, regional pricing, site conditions, and project complexity. Always
                  consult with licensed contractors and obtain detailed quotes before beginning construction.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
