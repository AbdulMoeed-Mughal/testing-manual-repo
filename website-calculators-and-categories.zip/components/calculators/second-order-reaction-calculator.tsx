"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Activity,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type CalculationMode = "concentration" | "time" | "rateConstant"
type ReactionType = "single" | "twoReactants"
type ConcentrationUnit = "M" | "mM" | "μM" | "mol/L"
type TimeUnit = "s" | "min" | "hr" | "days"

interface SecondOrderResult {
  calculatedValue: number
  unit: string
  halfLife: number
  halfLifeUnit: string
  rateConstant: number
  rateConstantUnit: string
}

export function SecondOrderReactionCalculator() {
  const [mode, setMode] = useState<CalculationMode>("concentration")
  const [reactionType, setReactionType] = useState<ReactionType>("single")
  const [initialConcentration, setInitialConcentration] = useState("")
  const [finalConcentration, setFinalConcentration] = useState("")
  const [time, setTime] = useState("")
  const [rateConstant, setRateConstant] = useState("")
  const [concentrationUnit, setConcentrationUnit] = useState<ConcentrationUnit>("M")
  const [timeUnit, setTimeUnit] = useState<TimeUnit>("s")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<SecondOrderResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const timeUnitLabels: Record<TimeUnit, string> = {
    s: "seconds",
    min: "minutes",
    hr: "hours",
    days: "days",
  }

  const modeLabels: Record<CalculationMode, string> = {
    concentration: "Final Concentration",
    time: "Time Elapsed",
    rateConstant: "Rate Constant (k)",
  }

  const reactionTypeLabels: Record<ReactionType, string> = {
    single: "Single Reactant (2A → products)",
    twoReactants: "Two Reactants (A + B → products)",
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const A0 = Number.parseFloat(initialConcentration)
    const A = Number.parseFloat(finalConcentration)
    const t = Number.parseFloat(time)
    const k = Number.parseFloat(rateConstant)

    // Validation based on mode
    if (mode === "concentration") {
      // Calculate final concentration: 1/[A] = 1/[A]₀ + kt => [A] = 1/(1/[A]₀ + kt)
      if (isNaN(A0) || A0 <= 0) {
        setError("Please enter a valid initial concentration greater than 0")
        return
      }
      if (isNaN(k) || k <= 0) {
        setError("Please enter a valid rate constant greater than 0")
        return
      }
      if (isNaN(t) || t < 0) {
        setError("Please enter a valid time (0 or greater)")
        return
      }

      const inverseA = 1 / A0 + k * t
      if (inverseA <= 0) {
        setError("Invalid calculation: result would be negative or zero")
        return
      }
      const calculatedA = 1 / inverseA
      const halfLife = 1 / (k * A0)

      setResult({
        calculatedValue: calculatedA,
        unit: concentrationUnit,
        halfLife,
        halfLifeUnit: timeUnit,
        rateConstant: k,
        rateConstantUnit: `${concentrationUnit}⁻¹·${timeUnit}⁻¹`,
      })
    } else if (mode === "time") {
      // Calculate time: t = (1/[A] - 1/[A]₀) / k
      if (isNaN(A0) || A0 <= 0) {
        setError("Please enter a valid initial concentration greater than 0")
        return
      }
      if (isNaN(A) || A <= 0) {
        setError("Please enter a valid final concentration greater than 0")
        return
      }
      if (A >= A0) {
        setError("Final concentration must be less than initial concentration")
        return
      }
      if (isNaN(k) || k <= 0) {
        setError("Please enter a valid rate constant greater than 0")
        return
      }

      const calculatedTime = (1 / A - 1 / A0) / k
      const halfLife = 1 / (k * A0)

      setResult({
        calculatedValue: calculatedTime,
        unit: timeUnit,
        halfLife,
        halfLifeUnit: timeUnit,
        rateConstant: k,
        rateConstantUnit: `${concentrationUnit}⁻¹·${timeUnit}⁻¹`,
      })
    } else if (mode === "rateConstant") {
      // Calculate rate constant: k = (1/[A] - 1/[A]₀) / t
      if (isNaN(A0) || A0 <= 0) {
        setError("Please enter a valid initial concentration greater than 0")
        return
      }
      if (isNaN(A) || A <= 0) {
        setError("Please enter a valid final concentration greater than 0")
        return
      }
      if (A >= A0) {
        setError("Final concentration must be less than initial concentration")
        return
      }
      if (isNaN(t) || t <= 0) {
        setError("Please enter a valid time greater than 0")
        return
      }

      const calculatedK = (1 / A - 1 / A0) / t
      const halfLife = 1 / (calculatedK * A0)

      setResult({
        calculatedValue: calculatedK,
        unit: `${concentrationUnit}⁻¹·${timeUnit}⁻¹`,
        halfLife,
        halfLifeUnit: timeUnit,
        rateConstant: calculatedK,
        rateConstantUnit: `${concentrationUnit}⁻¹·${timeUnit}⁻¹`,
      })
    }
  }

  const handleReset = () => {
    setInitialConcentration("")
    setFinalConcentration("")
    setTime("")
    setRateConstant("")
    setShowSteps(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Second-Order Reaction Result:
Mode: ${modeLabels[mode]}
Reaction Type: ${reactionTypeLabels[reactionType]}
Initial Concentration: ${initialConcentration} ${concentrationUnit}
${mode === "time" || mode === "rateConstant" ? `Final Concentration: ${finalConcentration} ${concentrationUnit}` : ""}
${mode === "concentration" || mode === "rateConstant" ? `Time: ${time} ${timeUnit}` : ""}
${mode !== "rateConstant" ? `Rate Constant: ${rateConstant} ${concentrationUnit}⁻¹·${timeUnit}⁻¹` : ""}
Result: ${formatNumber(result.calculatedValue)} ${result.unit}
Half-Life: ${formatNumber(result.halfLife)} ${result.halfLifeUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Second-Order Reaction Calculator Result",
          text: `${modeLabels[mode]}: ${formatNumber(result.calculatedValue)} ${result.unit} | Half-Life: ${formatNumber(result.halfLife)} ${result.halfLifeUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number, decimals = 6): string => {
    if (num === 0) return "0"
    if (Math.abs(num) < 0.000001 || Math.abs(num) >= 1000000) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: decimals })
  }

  const getStepByStepCalculation = () => {
    if (!result) return []
    const steps: string[] = []

    const A0 = Number.parseFloat(initialConcentration)
    const A = Number.parseFloat(finalConcentration)
    const t = Number.parseFloat(time)
    const k = Number.parseFloat(rateConstant)

    if (mode === "concentration") {
      steps.push("Integrated Rate Law for Second-Order Reactions:")
      steps.push("1/[A] = 1/[A]₀ + k × t")
      steps.push("")
      steps.push(`Given: [A]₀ = ${initialConcentration} ${concentrationUnit}`)
      steps.push(`Given: k = ${rateConstant} ${concentrationUnit}⁻¹·${timeUnit}⁻¹`)
      steps.push(`Given: t = ${time} ${timeUnit}`)
      steps.push("")
      steps.push(`Step 1: Calculate 1/[A]₀`)
      steps.push(`1/[A]₀ = 1/${initialConcentration} = ${formatNumber(1/A0, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 2: Calculate k × t`)
      steps.push(`k × t = ${rateConstant} × ${time} = ${formatNumber(k * t, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 3: Calculate 1/[A]`)
      steps.push(`1/[A] = ${formatNumber(1/A0, 6)} + ${formatNumber(k * t, 6)} = ${formatNumber(1/A0 + k * t, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 4: Calculate [A]`)
      steps.push(`[A] = 1 / ${formatNumber(1/A0 + k * t, 6)} = ${formatNumber(result.calculatedValue)} ${concentrationUnit}`)
    } else if (mode === "time") {
      steps.push("Rearranging the integrated rate law for time:")
      steps.push("t = (1/[A] - 1/[A]₀) / k")
      steps.push("")
      steps.push(`Given: [A]₀ = ${initialConcentration} ${concentrationUnit}`)
      steps.push(`Given: [A] = ${finalConcentration} ${concentrationUnit}`)
      steps.push(`Given: k = ${rateConstant} ${concentrationUnit}⁻¹·${timeUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 1: Calculate 1/[A]`)
      steps.push(`1/[A] = 1/${finalConcentration} = ${formatNumber(1/A, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 2: Calculate 1/[A]₀`)
      steps.push(`1/[A]₀ = 1/${initialConcentration} = ${formatNumber(1/A0, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 3: Calculate (1/[A] - 1/[A]₀)`)
      steps.push(`1/[A] - 1/[A]₀ = ${formatNumber(1/A, 6)} - ${formatNumber(1/A0, 6)} = ${formatNumber(1/A - 1/A0, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 4: Calculate t`)
      steps.push(`t = ${formatNumber(1/A - 1/A0, 6)} / ${rateConstant} = ${formatNumber(result.calculatedValue)} ${timeUnit}`)
    } else if (mode === "rateConstant") {
      steps.push("Rearranging the integrated rate law for k:")
      steps.push("k = (1/[A] - 1/[A]₀) / t")
      steps.push("")
      steps.push(`Given: [A]₀ = ${initialConcentration} ${concentrationUnit}`)
      steps.push(`Given: [A] = ${finalConcentration} ${concentrationUnit}`)
      steps.push(`Given: t = ${time} ${timeUnit}`)
      steps.push("")
      steps.push(`Step 1: Calculate 1/[A]`)
      steps.push(`1/[A] = 1/${finalConcentration} = ${formatNumber(1/A, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 2: Calculate 1/[A]₀`)
      steps.push(`1/[A]₀ = 1/${initialConcentration} = ${formatNumber(1/A0, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 3: Calculate (1/[A] - 1/[A]₀)`)
      steps.push(`1/[A] - 1/[A]₀ = ${formatNumber(1/A, 6)} - ${formatNumber(1/A0, 6)} = ${formatNumber(1/A - 1/A0, 6)} ${concentrationUnit}⁻¹`)
      steps.push("")
      steps.push(`Step 4: Calculate k`)
      steps.push(`k = ${formatNumber(1/A - 1/A0, 6)} / ${time} = ${formatNumber(result.calculatedValue)} ${concentrationUnit}⁻¹·${timeUnit}⁻¹`)
    }

    steps.push("")
    steps.push(`Half-Life: t₁/₂ = 1/(k × [A]₀) = ${formatNumber(result.halfLife)} ${result.halfLifeUnit}`)

    return steps
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Second-Order Reaction Calculator</CardTitle>
                    <CardDescription>Analyze second-order reaction kinetics</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Mode */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select value={mode} onValueChange={(v) => setMode(v as CalculationMode)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select calculation mode" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concentration">Final Concentration</SelectItem>
                      <SelectItem value="time">Time Elapsed</SelectItem>
                      <SelectItem value="rateConstant">Rate Constant (k)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Reaction Type */}
                <div className="space-y-2">
                  <Label>Reaction Type</Label>
                  <Select value={reactionType} onValueChange={(v) => setReactionType(v as ReactionType)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select reaction type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single">Single Reactant (2A → products)</SelectItem>
                      <SelectItem value="twoReactants">Two Reactants (A + B → products)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Unit Selectors */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Concentration Unit</Label>
                    <Select value={concentrationUnit} onValueChange={(v) => setConcentrationUnit(v as ConcentrationUnit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="M">Molar (M)</SelectItem>
                        <SelectItem value="mM">Millimolar (mM)</SelectItem>
                        <SelectItem value="μM">Micromolar (μM)</SelectItem>
                        <SelectItem value="mol/L">mol/L</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Time Unit</Label>
                    <Select value={timeUnit} onValueChange={(v) => setTimeUnit(v as TimeUnit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="s">Seconds (s)</SelectItem>
                        <SelectItem value="min">Minutes (min)</SelectItem>
                        <SelectItem value="hr">Hours (hr)</SelectItem>
                        <SelectItem value="days">Days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Initial Concentration */}
                <div className="space-y-2">
                  <Label htmlFor="initialConcentration">Initial Concentration [A]₀ ({concentrationUnit})</Label>
                  <Input
                    id="initialConcentration"
                    type="number"
                    placeholder={`Enter initial concentration in ${concentrationUnit}`}
                    value={initialConcentration}
                    onChange={(e) => setInitialConcentration(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Final Concentration - only for time and rateConstant modes */}
                {(mode === "time" || mode === "rateConstant") && (
                  <div className="space-y-2">
                    <Label htmlFor="finalConcentration">Final Concentration [A] ({concentrationUnit})</Label>
                    <Input
                      id="finalConcentration"
                      type="number"
                      placeholder={`Enter final concentration in ${concentrationUnit}`}
                      value={finalConcentration}
                      onChange={(e) => setFinalConcentration(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Time - for concentration and rateConstant modes */}
                {(mode === "concentration" || mode === "rateConstant") && (
                  <div className="space-y-2">
                    <Label htmlFor="time">Time (t) in {timeUnitLabels[timeUnit]}</Label>
                    <Input
                      id="time"
                      type="number"
                      placeholder={`Enter time in ${timeUnitLabels[timeUnit]}`}
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Rate Constant - for concentration and time modes */}
                {(mode === "concentration" || mode === "time") && (
                  <div className="space-y-2">
                    <Label htmlFor="rateConstant">Rate Constant (k) in {concentrationUnit}⁻¹·{timeUnit}⁻¹</Label>
                    <Input
                      id="rateConstant"
                      type="number"
                      placeholder={`Enter rate constant`}
                      value={rateConstant}
                      onChange={(e) => setRateConstant(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show Step-by-Step Solution</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {modeLabels[mode]}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">{modeLabels[mode]}</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">
                        {formatNumber(result.calculatedValue)}
                        <span className="text-lg ml-1">{result.unit}</span>
                      </p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Half-Life (t₁/₂)</p>
                        <p className="font-semibold text-purple-600">
                          {formatNumber(result.halfLife, 4)} {result.halfLifeUnit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Rate Constant (k)</p>
                        <p className="font-semibold text-purple-600 text-sm">
                          {formatNumber(result.rateConstant, 6)}
                        </p>
                        <p className="text-xs text-muted-foreground">{result.rateConstantUnit}</p>
                      </div>
                    </div>

                    {/* Step-by-Step Breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-purple-100">
                        <p className="font-medium text-sm mb-2 text-purple-700">Step-by-Step Solution:</p>
                        <div className="text-xs space-y-1 text-muted-foreground font-mono">
                          {getStepByStepCalculation().map((step, index) => (
                            <p
                              key={index}
                              className={
                                step.startsWith("[A] =") || step.startsWith("t =") || step.startsWith("k =") || step.startsWith("Half-Life:")
                                  ? "text-purple-600 font-semibold"
                                  : step === ""
                                  ? "h-2"
                                  : ""
                              }
                            >
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Second-Order Rate Law</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-mono font-semibold text-purple-700 text-center text-sm">
                      1/[A] = 1/[A]₀ + k × t
                    </p>
                    <p className="text-xs text-purple-600 text-center mt-1">Integrated Rate Law</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="font-mono font-semibold text-purple-700 text-center text-sm">
                      t₁/₂ = 1 / (k × [A]₀)
                    </p>
                    <p className="text-xs text-purple-600 text-center mt-1">Half-Life Formula</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p><strong>[A]₀</strong> = Initial concentration</p>
                    <p><strong>[A]</strong> = Concentration at time t</p>
                    <p><strong>k</strong> = Rate constant (M⁻¹·time⁻¹)</p>
                    <p><strong>t</strong> = Time elapsed</p>
                    <p><strong>t₁/₂</strong> = Half-life (depends on [A]₀)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Info className="h-5 w-5" />
                    Understanding Second-Order Kinetics
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div>
                    <p className="font-medium text-foreground mb-1">What is a Second-Order Reaction?</p>
                    <p>
                      A second-order reaction is one where the rate depends on the concentration of one reactant
                      squared (Rate = k[A]²) or on two reactants (Rate = k[A][B]).
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Variable Half-Life</p>
                    <p>
                      Unlike first-order reactions, the half-life of a second-order reaction depends on the initial
                      concentration. Higher initial concentrations lead to shorter half-lives.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-foreground mb-1">Common Examples</p>
                    <p>
                      Dimerization reactions, many bimolecular reactions, enzyme-substrate interactions at high
                      substrate concentrations, and some decomposition reactions follow second-order kinetics.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Key Properties
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Rate depends on</span>
                    <span className="font-mono">[A]² or [A][B]</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Units of k</span>
                    <span className="font-mono">M⁻¹·time⁻¹</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Half-life depends on</span>
                    <span className="font-mono">k and [A]₀</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Plot for straight line</span>
                    <span className="font-mono">1/[A] vs t</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="space-y-2 text-sm text-amber-900">
                      <p className="font-medium">Important Note</p>
                      <p>
                        Second-order kinetics assume rate depends on the concentration of one or two reactants.
                        Deviations may occur for complex reaction mechanisms or under non-ideal conditions.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Information Section */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Second-Order Reaction Kinetics?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Second-order reaction kinetics describes chemical reactions where the rate is proportional to either
                  the square of one reactant's concentration or the product of two reactants' concentrations. For a
                  reaction involving a single reactant A, the rate law is Rate = k[A]². For reactions involving two
                  reactants, the rate law is Rate = k[A][B]. This type of kinetics is commonly observed in bimolecular
                  reactions where two molecules must collide for the reaction to occur.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The integrated rate law for second-order reactions, 1/[A] = 1/[A]₀ + kt, allows us to calculate
                  concentration changes over time, determine how long a reaction will take to reach a certain point, or
                  find the rate constant from experimental data. A plot of 1/[A] versus time will yield a straight line
                  with a slope equal to k for a true second-order reaction, which is used to confirm reaction order.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Second-Order Kinetics</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Second-order kinetics plays a crucial role in many chemical and biochemical processes. In organic
                  chemistry, many bimolecular reactions such as SN2 substitutions and E2 eliminations follow second-order
                  kinetics. Understanding these kinetics helps chemists predict reaction rates and design efficient
                  synthetic routes for pharmaceutical and industrial chemical production.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In biochemistry, enzyme kinetics at high substrate concentrations can exhibit second-order behavior.
                  The study of protein-protein interactions, antigen-antibody binding, and drug-receptor interactions
                  often involves second-order kinetics. Environmental scientists also use second-order models to predict
                  the degradation of pollutants when two species react together or when a single pollutant undergoes
                  dimerization.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
