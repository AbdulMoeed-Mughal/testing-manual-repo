"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Baby,
  Info,
  Calendar,
  Heart,
  Clock,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMethod = "lmp" | "conception" | "ultrasound"

interface PregnancyResult {
  dueDate: Date
  gestationalWeeks: number
  gestationalDays: number
  trimester: string
  trimesterColor: string
  daysRemaining: number
  progressPercent: number
  conceptionDateRange: { start: Date; end: Date }
}

export function PregnancyDueDateCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("lmp")
  const [lmpDate, setLmpDate] = useState("")
  const [cycleLength, setCycleLength] = useState("28")
  const [conceptionDate, setConceptionDate] = useState("")
  const [ultrasoundDate, setUltrasoundDate] = useState("")
  const [gestationalWeeksAtUltrasound, setGestationalWeeksAtUltrasound] = useState("")
  const [gestationalDaysAtUltrasound, setGestationalDaysAtUltrasound] = useState("")
  const [result, setResult] = useState<PregnancyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDueDate = () => {
    setError("")
    setResult(null)

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    let dueDate: Date
    let lmpForCalculation: Date

    if (method === "lmp") {
      if (!lmpDate) {
        setError("Please enter your last menstrual period date")
        return
      }
      const lmp = new Date(lmpDate)
      if (lmp > today) {
        setError("Last menstrual period date cannot be in the future")
        return
      }
      const cycle = Number.parseInt(cycleLength)
      if (isNaN(cycle) || cycle < 21 || cycle > 35) {
        setError("Cycle length must be between 21 and 35 days")
        return
      }

      // Naegele's Rule with cycle adjustment
      dueDate = new Date(lmp)
      dueDate.setFullYear(dueDate.getFullYear() + 1)
      dueDate.setMonth(dueDate.getMonth() - 3)
      dueDate.setDate(dueDate.getDate() + 7)
      // Adjust for cycle length
      dueDate.setDate(dueDate.getDate() + (cycle - 28))
      lmpForCalculation = lmp
    } else if (method === "conception") {
      if (!conceptionDate) {
        setError("Please enter your conception date")
        return
      }
      const conception = new Date(conceptionDate)
      if (conception > today) {
        setError("Conception date cannot be in the future")
        return
      }

      // Due date = conception + 266 days
      dueDate = new Date(conception)
      dueDate.setDate(dueDate.getDate() + 266)
      // LMP would be approximately 14 days before conception
      lmpForCalculation = new Date(conception)
      lmpForCalculation.setDate(lmpForCalculation.getDate() - 14)
    } else {
      if (!ultrasoundDate) {
        setError("Please enter your ultrasound date")
        return
      }
      const ultrasound = new Date(ultrasoundDate)
      if (ultrasound > today) {
        setError("Ultrasound date cannot be in the future")
        return
      }
      const weeks = Number.parseInt(gestationalWeeksAtUltrasound) || 0
      const days = Number.parseInt(gestationalDaysAtUltrasound) || 0
      if (weeks < 1 || weeks > 42) {
        setError("Gestational weeks must be between 1 and 42")
        return
      }
      if (days < 0 || days > 6) {
        setError("Gestational days must be between 0 and 6")
        return
      }

      // Calculate due date from ultrasound
      const totalGestationalDays = weeks * 7 + days
      const daysRemaining = 280 - totalGestationalDays
      dueDate = new Date(ultrasound)
      dueDate.setDate(dueDate.getDate() + daysRemaining)
      // Calculate LMP for gestational age
      lmpForCalculation = new Date(ultrasound)
      lmpForCalculation.setDate(lmpForCalculation.getDate() - totalGestationalDays)
    }

    // Calculate gestational age
    const daysSinceLMP = Math.floor((today.getTime() - lmpForCalculation.getTime()) / (1000 * 60 * 60 * 24))
    const gestationalWeeks = Math.floor(daysSinceLMP / 7)
    const gestationalDays = daysSinceLMP % 7

    // Determine trimester
    let trimester: string
    let trimesterColor: string
    if (gestationalWeeks < 14) {
      trimester = "First Trimester"
      trimesterColor = "text-pink-600"
    } else if (gestationalWeeks < 28) {
      trimester = "Second Trimester"
      trimesterColor = "text-purple-600"
    } else {
      trimester = "Third Trimester"
      trimesterColor = "text-blue-600"
    }

    // Days remaining
    const daysRemaining = Math.max(0, Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)))

    // Progress percentage (280 days total)
    const progressPercent = Math.min(100, Math.round((daysSinceLMP / 280) * 100))

    // Conception date range (typically day 11-21 of cycle)
    const conceptionStart = new Date(lmpForCalculation)
    conceptionStart.setDate(conceptionStart.getDate() + 11)
    const conceptionEnd = new Date(lmpForCalculation)
    conceptionEnd.setDate(conceptionEnd.getDate() + 21)

    setResult({
      dueDate,
      gestationalWeeks,
      gestationalDays,
      trimester,
      trimesterColor,
      daysRemaining,
      progressPercent,
      conceptionDateRange: { start: conceptionStart, end: conceptionEnd },
    })
  }

  const handleReset = () => {
    setLmpDate("")
    setCycleLength("28")
    setConceptionDate("")
    setUltrasoundDate("")
    setGestationalWeeksAtUltrasound("")
    setGestationalDaysAtUltrasound("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My estimated due date is ${formatDate(result.dueDate)}. Currently ${result.gestationalWeeks} weeks and ${result.gestationalDays} days pregnant (${result.trimester}).`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Pregnancy Due Date",
          text: `I calculated my due date using CalcHub! Expected: ${formatDate(result.dueDate)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const milestones = [
    { week: 12, label: "End of 1st Trimester" },
    { week: 20, label: "Anatomy Scan" },
    { week: 28, label: "Start of 3rd Trimester" },
    { week: 36, label: "Full Term Soon" },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Baby className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Pregnancy Due Date Calculator</CardTitle>
                    <CardDescription>Estimate your expected delivery date</CardDescription>
                  </div>
                </div>

                {/* Method Toggle */}
                <div className="pt-2">
                  <span className="text-sm font-medium block mb-2">Calculation Method</span>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setMethod("lmp")}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        method === "lmp" ? "bg-pink-600 text-white" : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      LMP
                    </button>
                    <button
                      onClick={() => setMethod("conception")}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        method === "conception"
                          ? "bg-pink-600 text-white"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      Conception
                    </button>
                    <button
                      onClick={() => setMethod("ultrasound")}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        method === "ultrasound"
                          ? "bg-pink-600 text-white"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      Ultrasound
                    </button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* LMP Method Inputs */}
                {method === "lmp" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="lmp">Last Menstrual Period (LMP)</Label>
                      <Input
                        id="lmp"
                        type="date"
                        value={lmpDate}
                        onChange={(e) => setLmpDate(e.target.value)}
                        max={new Date().toISOString().split("T")[0]}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cycle">Average Cycle Length (days)</Label>
                      <Input
                        id="cycle"
                        type="number"
                        placeholder="28"
                        value={cycleLength}
                        onChange={(e) => setCycleLength(e.target.value)}
                        min="21"
                        max="35"
                      />
                      <p className="text-xs text-muted-foreground">Default is 28 days (range: 21-35)</p>
                    </div>
                  </>
                )}

                {/* Conception Method Inputs */}
                {method === "conception" && (
                  <div className="space-y-2">
                    <Label htmlFor="conception">Conception Date</Label>
                    <Input
                      id="conception"
                      type="date"
                      value={conceptionDate}
                      onChange={(e) => setConceptionDate(e.target.value)}
                      max={new Date().toISOString().split("T")[0]}
                    />
                    <p className="text-xs text-muted-foreground">If known from IVF or tracked ovulation</p>
                  </div>
                )}

                {/* Ultrasound Method Inputs */}
                {method === "ultrasound" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="ultrasound">Ultrasound Date</Label>
                      <Input
                        id="ultrasound"
                        type="date"
                        value={ultrasoundDate}
                        onChange={(e) => setUltrasoundDate(e.target.value)}
                        max={new Date().toISOString().split("T")[0]}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Gestational Age at Ultrasound</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Input
                            type="number"
                            placeholder="Weeks"
                            value={gestationalWeeksAtUltrasound}
                            onChange={(e) => setGestationalWeeksAtUltrasound(e.target.value)}
                            min="1"
                            max="42"
                          />
                        </div>
                        <div>
                          <Input
                            type="number"
                            placeholder="Days"
                            value={gestationalDaysAtUltrasound}
                            onChange={(e) => setGestationalDaysAtUltrasound(e.target.value)}
                            min="0"
                            max="6"
                          />
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDueDate} className="w-full bg-pink-600 hover:bg-pink-700" size="lg">
                  Calculate Due Date
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-pink-50 border-pink-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Due Date</p>
                      <p className="text-2xl sm:text-3xl font-bold text-pink-600 mb-1">{formatDate(result.dueDate)}</p>
                      <p className={`text-lg font-semibold ${result.trimesterColor}`}>{result.trimester}</p>
                    </div>

                    {/* Progress Bar */}
                    <div className="mt-4">
                      <div className="flex justify-between text-sm text-muted-foreground mb-1">
                        <span>
                          {result.gestationalWeeks}w {result.gestationalDays}d
                        </span>
                        <span>{result.progressPercent}% complete</span>
                      </div>
                      <div className="h-3 bg-pink-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-pink-400 to-pink-600 rounded-full transition-all duration-500"
                          style={{ width: `${result.progressPercent}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>0 weeks</span>
                        <span>40 weeks</span>
                      </div>
                    </div>

                    {/* Key Stats */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="bg-white rounded-lg p-3 text-center">
                        <p className="text-xs text-muted-foreground">Current Week</p>
                        <p className="text-xl font-bold text-pink-600">
                          {result.gestationalWeeks}w {result.gestationalDays}d
                        </p>
                      </div>
                      <div className="bg-white rounded-lg p-3 text-center">
                        <p className="text-xs text-muted-foreground">Days Remaining</p>
                        <p className="text-xl font-bold text-pink-600">{result.daysRemaining}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pregnancy Milestones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-pink-50 border border-pink-200">
                      <span className="font-medium text-pink-700">First Trimester</span>
                      <span className="text-sm text-pink-600">Weeks 1-13</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Second Trimester</span>
                      <span className="text-sm text-purple-600">Weeks 14-27</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Third Trimester</span>
                      <span className="text-sm text-blue-600">Weeks 28-40</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Full Term</span>
                      <span className="text-sm text-green-600">Weeks 39-40</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Methods</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Naegele's Rule (LMP)</p>
                    <p>Due Date = LMP + 1 year - 3 months + 7 days</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Conception Method</p>
                    <p>Due Date = Conception date + 266 days</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Ultrasound Method</p>
                    <p>Due Date = Ultrasound date + (280 - gestational age) days</p>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-4">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-amber-800">
                      This calculator provides an estimate only and should not replace medical advice. Please consult
                      your healthcare provider for accurate pregnancy dating.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Due Date Calculation */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-pink-600" />
                  <CardTitle>Understanding Pregnancy Due Date Calculation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating your pregnancy due date, also known as your estimated date of delivery (EDD), is one of
                  the first and most exciting steps in your pregnancy journey. The due date provides a target date
                  around which you and your healthcare provider can plan prenatal care, prepare for delivery, and
                  monitor your baby's development. While only about 4-5% of babies are born exactly on their due date,
                  this calculation gives you a 40-week window that helps track important milestones throughout your
                  pregnancy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The most commonly used method for calculating due dates is Naegele's Rule, developed by German
                  obstetrician Franz Karl Naegele in the early 19th century. This method assumes a 28-day menstrual
                  cycle and calculates the due date by adding one year to the first day of your last menstrual period
                  (LMP), subtracting three months, and then adding seven days. Modern calculators like ours also account
                  for variations in cycle length, making the estimate more accurate for women whose cycles differ from
                  the standard 28 days.
                </p>
              </CardContent>
            </Card>

            {/* Different Calculation Methods */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-pink-600" />
                  <CardTitle>Different Methods for Estimating Due Date</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  There are several methods healthcare providers use to estimate your due date, each with its own
                  advantages. The Last Menstrual Period (LMP) method is the most common starting point. It works by
                  counting 280 days (40 weeks) from the first day of your last period. This method assumes ovulation
                  occurred on day 14 of a 28-day cycle, which is why adjustments are made for women with shorter or
                  longer cycles.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Conception Date method is particularly accurate for women who know exactly when they conceived,
                  such as those who underwent in vitro fertilization (IVF) or who closely tracked their ovulation. Since
                  conception typically occurs about 266 days before delivery, this method adds 266 days to the known
                  conception date. For women who use ovulation predictor kits or basal body temperature tracking, this
                  method can provide a more precise estimate than the LMP method.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Ultrasound dating, especially when performed in the first trimester, is often considered the most
                  accurate method for establishing a due date. During an early ultrasound, the technician measures the
                  crown-rump length (CRL) of the embryo, which closely correlates with gestational age. First-trimester
                  ultrasounds are accurate within 5-7 days, while second-trimester ultrasounds are accurate within about
                  10-14 days. If there's a significant discrepancy between your LMP-based due date and the ultrasound
                  estimate, your healthcare provider may adjust your due date accordingly.
                </p>
              </CardContent>
            </Card>

            {/* Understanding Trimesters */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-pink-600" />
                  <CardTitle>Understanding the Three Trimesters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pregnancy is divided into three trimesters, each lasting approximately 13-14 weeks and characterized
                  by distinct developmental milestones and physical changes. The first trimester (weeks 1-13) is a
                  period of rapid development when all major organs and body systems begin to form. During this time,
                  many women experience symptoms like morning sickness, fatigue, and breast tenderness. This is also
                  when the risk of miscarriage is highest, which is why many couples choose to wait until after the
                  first trimester to announce their pregnancy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The second trimester (weeks 14-27) is often called the "golden period" of pregnancy, as many
                  uncomfortable first-trimester symptoms subside. Your baby grows significantly during this time, and
                  you'll likely feel the first movements (quickening) around weeks 18-22. The anatomy scan ultrasound,
                  typically performed around week 20, provides a detailed look at your baby's development and may reveal
                  the baby's sex if you wish to know. Many women find this trimester the most enjoyable, with increased
                  energy and a visible baby bump.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The third trimester (weeks 28-40) marks the final stretch of pregnancy as your baby gains weight and
                  prepares for life outside the womb. You may experience new symptoms like back pain, difficulty
                  sleeping, and Braxton Hicks contractions as your body prepares for labor. Regular prenatal visits
                  become more frequent to monitor both your health and your baby's position and growth. Babies born
                  after 37 weeks are considered full-term, though the ideal time for delivery is between 39 and 40 weeks
                  when possible.
                </p>
              </CardContent>
            </Card>

            {/* Important Milestones */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-pink-600" />
                  <CardTitle>Key Pregnancy Milestones to Track</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Throughout your pregnancy, several key milestones mark important points in your baby's development. At
                  around 6-7 weeks, a heartbeat can usually be detected via ultrasound, providing reassurance that the
                  pregnancy is progressing normally. By week 12, the risk of miscarriage drops significantly, and many
                  parents feel comfortable sharing their pregnancy news. The first-trimester screening, which includes
                  blood tests and a nuchal translucency ultrasound, is typically performed between weeks 11-14 to assess
                  the risk of chromosomal abnormalities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The anatomy scan at around 20 weeks is a major milestone that examines your baby's organs, limbs, and
                  overall development in detail. This is often when parents learn the baby's sex. Around 24 weeks, your
                  baby reaches the point of viability, meaning survival outside the womb becomes possible with intensive
                  medical care, though outcomes improve significantly with each additional week in utero. At 28 weeks,
                  you'll enter the third trimester and begin more frequent prenatal visits.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The final weeks bring additional monitoring, including Group B Strep testing around week 36 and
                  regular checks of your baby's position and your cervical changes. At 37 weeks, your baby is considered
                  early term, and by 39 weeks, your baby is full-term and ready for delivery. Remember that your due
                  date is an estimate—healthy babies can arrive anywhere from 37 to 42 weeks. Staying in close
                  communication with your healthcare provider ensures the best outcomes for both you and your baby
                  throughout this remarkable journey.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
