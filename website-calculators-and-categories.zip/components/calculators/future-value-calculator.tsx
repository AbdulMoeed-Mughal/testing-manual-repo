"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  ChevronDown,
  ChevronUp,
  Calculator,
  Target,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, currencySymbols, formatCurrency, currencyOptions } from "@/lib/currency"

interface FutureValueResult {
  futureValue: number
  totalContributions: number
  totalInterest: number
  principalGrowth: number
  contributionGrowth: number
  inflationAdjustedValue: number | null
  yearlyBreakdown: YearlyData[]
}

interface YearlyData {
  year: number
  principal: number
  contributions: number
  interest: number
  balance: number
  inflationAdjusted: number | null
}

export function FutureValueCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [principal, setPrincipal] = useState("")
  const [contribution, setContribution] = useState("")
  const [contributionFrequency, setContributionFrequency] = useState<"monthly" | "quarterly" | "annually">("monthly")
  const [interestRate, setInterestRate] = useState("")
  const [duration, setDuration] = useState("")
  const [compoundingFrequency, setCompoundingFrequency] = useState<"monthly" | "quarterly" | "annually">("monthly")
  const [inflationRate, setInflationRate] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<FutureValueResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const getCompoundingPeriods = (frequency: string): number => {
    switch (frequency) {
      case "monthly":
        return 12
      case "quarterly":
        return 4
      case "annually":
        return 1
      default:
        return 12
    }
  }

  const getContributionPeriods = (frequency: string): number => {
    switch (frequency) {
      case "monthly":
        return 12
      case "quarterly":
        return 4
      case "annually":
        return 1
      default:
        return 12
    }
  }

  const calculateFutureValue = () => {
    setError("")
    setResult(null)

    const p = Number.parseFloat(principal) || 0
    const c = Number.parseFloat(contribution) || 0
    const r = Number.parseFloat(interestRate)
    const t = Number.parseFloat(duration)
    const inf = Number.parseFloat(inflationRate) || 0

    if (p <= 0 && c <= 0) {
      setError("Please enter either an initial investment or periodic contribution")
      return
    }

    if (isNaN(r) || r < 0) {
      setError("Please enter a valid interest rate")
      return
    }

    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid duration greater than 0")
      return
    }

    const n = getCompoundingPeriods(compoundingFrequency)
    const contribPeriods = getContributionPeriods(contributionFrequency)
    const ratePerPeriod = r / 100 / n
    const totalPeriods = n * t

    // Future Value of Principal: FV = P × (1 + r/n)^(n×t)
    const principalFV = p * Math.pow(1 + ratePerPeriod, totalPeriods)

    // Future Value of Contributions (annuity)
    // Convert contribution to match compounding frequency
    const contributionPerCompound = (c * contribPeriods) / n
    let contributionFV = 0

    if (ratePerPeriod > 0) {
      contributionFV = contributionPerCompound * ((Math.pow(1 + ratePerPeriod, totalPeriods) - 1) / ratePerPeriod)
    } else {
      contributionFV = contributionPerCompound * totalPeriods
    }

    const futureValue = principalFV + contributionFV
    const totalContributions = p + c * contribPeriods * t
    const totalInterest = futureValue - totalContributions

    // Calculate inflation-adjusted value
    let inflationAdjustedValue: number | null = null
    if (inf > 0) {
      inflationAdjustedValue = futureValue / Math.pow(1 + inf / 100, t)
    }

    // Calculate yearly breakdown
    const yearlyBreakdown: YearlyData[] = []
    let runningBalance = p
    let runningContributions = p
    let runningInterest = 0

    for (let year = 1; year <= t; year++) {
      const yearlyContribution = c * contribPeriods
      const periodsThisYear = n

      // Calculate balance at end of year with contributions
      let yearEndBalance = runningBalance
      for (let period = 0; period < periodsThisYear; period++) {
        yearEndBalance *= 1 + ratePerPeriod
        yearEndBalance += contributionPerCompound
      }

      const interestThisYear = yearEndBalance - runningBalance - yearlyContribution
      runningContributions += yearlyContribution
      runningInterest += interestThisYear
      runningBalance = yearEndBalance

      let inflationAdjusted: number | null = null
      if (inf > 0) {
        inflationAdjusted = runningBalance / Math.pow(1 + inf / 100, year)
      }

      yearlyBreakdown.push({
        year,
        principal: p,
        contributions: runningContributions,
        interest: runningInterest,
        balance: runningBalance,
        inflationAdjusted,
      })
    }

    setResult({
      futureValue,
      totalContributions,
      totalInterest,
      principalGrowth: principalFV - p,
      contributionGrowth: contributionFV - c * contribPeriods * t + p,
      inflationAdjustedValue,
      yearlyBreakdown,
    })
  }

  const handleReset = () => {
    setPrincipal("")
    setContribution("")
    setContributionFrequency("monthly")
    setInterestRate("")
    setDuration("")
    setCompoundingFrequency("monthly")
    setInflationRate("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Future Value: ${formatCurrency(result.futureValue, currency)}\nTotal Contributions: ${formatCurrency(result.totalContributions, currency)}\nTotal Interest: ${formatCurrency(result.totalInterest, currency)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Future Value Calculation",
          text: `I calculated my investment's future value using CalcHub! Future Value: ${formatCurrency(result.futureValue, currency)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Future Value Calculator</CardTitle>
                    <CardDescription>Estimate the future value of your investments</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <Select value={currency} onValueChange={(value) => setCurrency(value as Currency)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencyOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.symbol} {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Principal Input */}
                <div className="space-y-2">
                  <Label htmlFor="principal">Initial Investment ({symbol})</Label>
                  <Input
                    id="principal"
                    type="number"
                    placeholder="Enter initial investment amount"
                    value={principal}
                    onChange={(e) => setPrincipal(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Contribution Input */}
                <div className="space-y-2">
                  <Label htmlFor="contribution">Periodic Contribution ({symbol})</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      id="contribution"
                      type="number"
                      placeholder="Amount"
                      value={contribution}
                      onChange={(e) => setContribution(e.target.value)}
                      min="0"
                      step="10"
                    />
                    <Select
                      value={contributionFrequency}
                      onValueChange={(value) => setContributionFrequency(value as "monthly" | "quarterly" | "annually")}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="quarterly">Quarterly</SelectItem>
                        <SelectItem value="annually">Annually</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Expected annual return"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Investment Duration (Years)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Number of years"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    {/* Compounding Frequency */}
                    <div className="space-y-2">
                      <Label htmlFor="compounding">Compounding Frequency</Label>
                      <Select
                        value={compoundingFrequency}
                        onValueChange={(value) =>
                          setCompoundingFrequency(value as "monthly" | "quarterly" | "annually")
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                          <SelectItem value="annually">Annually</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Inflation Rate */}
                    <div className="space-y-2">
                      <Label htmlFor="inflation">Inflation Rate (% per year)</Label>
                      <Input
                        id="inflation"
                        type="number"
                        placeholder="Optional: For real value calculation"
                        value={inflationRate}
                        onChange={(e) => setInflationRate(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFutureValue} className="w-full" size="lg">
                  Calculate Future Value
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Projected Future Value</p>
                      <p className="text-4xl font-bold text-green-600">
                        {formatCurrency(result.futureValue, currency)}
                      </p>
                      {result.inflationAdjustedValue && (
                        <p className="text-sm text-muted-foreground mt-1">
                          Inflation-adjusted: {formatCurrency(result.inflationAdjustedValue, currency)}
                        </p>
                      )}
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Contributions</p>
                        <p className="text-lg font-semibold text-foreground">
                          {formatCurrency(result.totalContributions, currency)}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Interest Earned</p>
                        <p className="text-lg font-semibold text-green-600">
                          {formatCurrency(result.totalInterest, currency)}
                        </p>
                      </div>
                    </div>

                    {/* Growth Breakdown */}
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Contributions</span>
                        <span>Interest</span>
                      </div>
                      <div className="h-4 bg-gray-200 rounded-full overflow-hidden flex">
                        <div
                          className="bg-blue-500 h-full"
                          style={{
                            width: `${(result.totalContributions / result.futureValue) * 100}%`,
                          }}
                        />
                        <div
                          className="bg-green-500 h-full"
                          style={{
                            width: `${(result.totalInterest / result.futureValue) * 100}%`,
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>{((result.totalContributions / result.futureValue) * 100).toFixed(1)}%</span>
                        <span>{((result.totalInterest / result.futureValue) * 100).toFixed(1)}%</span>
                      </div>
                    </div>

                    {/* Yearly Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full mb-2 bg-transparent">
                          {showBreakdown ? "Hide" : "Show"} Year-by-Year Breakdown
                          {showBreakdown ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="max-h-64 overflow-y-auto">
                          <table className="w-full text-xs">
                            <thead className="sticky top-0 bg-green-50">
                              <tr className="border-b">
                                <th className="text-left py-2 px-1">Year</th>
                                <th className="text-right py-2 px-1">Contributions</th>
                                <th className="text-right py-2 px-1">Interest</th>
                                <th className="text-right py-2 px-1">Balance</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.yearlyBreakdown.map((data) => (
                                <tr key={data.year} className="border-b border-green-100">
                                  <td className="py-2 px-1">{data.year}</td>
                                  <td className="text-right py-2 px-1">
                                    {formatCurrency(data.contributions, currency)}
                                  </td>
                                  <td className="text-right py-2 px-1 text-green-600">
                                    {formatCurrency(data.interest, currency)}
                                  </td>
                                  <td className="text-right py-2 px-1 font-medium">
                                    {formatCurrency(data.balance, currency)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Growth Milestones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">2x Growth</span>
                      <span className="text-sm text-blue-600">Double your money</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">5x Growth</span>
                      <span className="text-sm text-green-600">Quintuple your money</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">10x Growth</span>
                      <span className="text-sm text-purple-600">10-fold increase</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Future Value Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">FV = P × (1 + r/n)^(n×t)</p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>P</strong> = Initial principal
                    </p>
                    <p>
                      <strong>r</strong> = Annual interest rate (decimal)
                    </p>
                    <p>
                      <strong>n</strong> = Compounding periods per year
                    </p>
                    <p>
                      <strong>t</strong> = Time in years
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rule of 72</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p className="mb-2">Quick way to estimate how long it takes to double your money:</p>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center mb-2">
                    <p className="font-semibold text-foreground">Years to Double = 72 ÷ Interest Rate</p>
                  </div>
                  <p className="text-xs">
                    At 8% return, your money doubles in ~9 years. At 12%, it doubles in ~6 years.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Future Value?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Future Value (FV) is a fundamental concept in finance that represents the value of a current asset at
                  a specified date in the future based on an assumed rate of growth. It helps investors and savers
                  understand how their money will grow over time through compound interest, making it an essential tool
                  for financial planning and investment decisions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding future value is crucial for setting realistic financial goals, comparing investment
                  options, planning for retirement, and making informed decisions about saving versus spending today.
                  The concept accounts for the time value of money—the principle that a dollar today is worth more than
                  a dollar in the future due to its potential earning capacity.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Step 1: Enter Initial Amount</h4>
                    <p className="text-sm text-muted-foreground">
                      Input your starting investment or savings amount. This is your principal.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Step 2: Add Contributions</h4>
                    <p className="text-sm text-muted-foreground">
                      Enter any regular contributions you plan to make and how often.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Step 3: Set Return Rate</h4>
                    <p className="text-sm text-muted-foreground">
                      Enter your expected annual return rate based on your investment type.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Step 4: Choose Duration</h4>
                    <p className="text-sm text-muted-foreground">
                      Specify how many years you plan to keep the investment growing.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Future Value</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Time Horizon</h4>
                    <p className="text-green-700 text-sm">
                      The longer your money is invested, the more it can grow through compound interest. Even small
                      amounts can grow substantially over decades.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Interest Rate</h4>
                    <p className="text-blue-700 text-sm">
                      Higher returns accelerate growth, but typically come with higher risk. Consider your risk
                      tolerance when estimating expected returns.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Compounding Frequency</h4>
                    <p className="text-purple-700 text-sm">
                      More frequent compounding (monthly vs. annually) leads to slightly higher returns due to earning
                      interest on interest more often.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Regular Contributions</h4>
                    <p className="text-orange-700 text-sm">
                      Consistent contributions, even small ones, can dramatically increase your final balance compared
                      to a lump sum alone.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Future value calculations are estimates based on entered values and assumed rates of return. Actual
                  results may vary due to market conditions, inflation, taxes, fees, and other factors. Past performance
                  does not guarantee future results. This calculator is for educational and planning purposes only and
                  should not be considered financial advice. Consult a qualified financial advisor for personalized
                  investment guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
