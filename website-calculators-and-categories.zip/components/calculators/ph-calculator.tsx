"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Beaker,
  Droplets,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "ph-from-h" | "h-from-ph" | "poh-from-oh" | "oh-from-poh" | "ph-from-poh" | "poh-from-ph"

interface PHResult {
  pH: number
  pOH: number
  hConcentration: number
  ohConcentration: number
  classification: string
  color: string
  bgColor: string
}

export function PHCalculator() {
  const [mode, setMode] = useState<CalculationMode>("ph-from-h")
  const [hConcentration, setHConcentration] = useState("")
  const [ohConcentration, setOHConcentration] = useState("")
  const [phValue, setPHValue] = useState("")
  const [pohValue, setPOHValue] = useState("")
  const [result, setResult] = useState<PHResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const Kw = 1.0e-14 // Ion product of water at 25°C

  const calculatePH = () => {
    setError("")
    setResult(null)

    let pH: number
    let pOH: number
    let hConc: number
    let ohConc: number

    try {
      switch (mode) {
        case "ph-from-h": {
          const h = Number.parseFloat(hConcentration)
          if (isNaN(h) || h <= 0) {
            setError("Please enter a valid positive hydrogen ion concentration")
            return
          }
          pH = -Math.log10(h)
          pOH = 14 - pH
          hConc = h
          ohConc = Math.pow(10, -pOH)
          break
        }
        case "h-from-ph": {
          const ph = Number.parseFloat(phValue)
          if (isNaN(ph)) {
            setError("Please enter a valid pH value")
            return
          }
          pH = ph
          pOH = 14 - pH
          hConc = Math.pow(10, -pH)
          ohConc = Math.pow(10, -pOH)
          break
        }
        case "poh-from-oh": {
          const oh = Number.parseFloat(ohConcentration)
          if (isNaN(oh) || oh <= 0) {
            setError("Please enter a valid positive hydroxide ion concentration")
            return
          }
          pOH = -Math.log10(oh)
          pH = 14 - pOH
          ohConc = oh
          hConc = Math.pow(10, -pH)
          break
        }
        case "oh-from-poh": {
          const poh = Number.parseFloat(pohValue)
          if (isNaN(poh)) {
            setError("Please enter a valid pOH value")
            return
          }
          pOH = poh
          pH = 14 - pOH
          ohConc = Math.pow(10, -pOH)
          hConc = Math.pow(10, -pH)
          break
        }
        case "ph-from-poh": {
          const poh = Number.parseFloat(pohValue)
          if (isNaN(poh)) {
            setError("Please enter a valid pOH value")
            return
          }
          pOH = poh
          pH = 14 - pOH
          hConc = Math.pow(10, -pH)
          ohConc = Math.pow(10, -pOH)
          break
        }
        case "poh-from-ph": {
          const ph = Number.parseFloat(phValue)
          if (isNaN(ph)) {
            setError("Please enter a valid pH value")
            return
          }
          pH = ph
          pOH = 14 - pH
          hConc = Math.pow(10, -pH)
          ohConc = Math.pow(10, -pOH)
          break
        }
        default:
          return
      }

      // Classification and color
      let classification: string
      let color: string
      let bgColor: string

      if (pH < 7) {
        classification = "Acidic"
        color = "text-red-600"
        bgColor = "bg-red-50 border-red-200"
      } else if (pH === 7) {
        classification = "Neutral"
        color = "text-green-600"
        bgColor = "bg-green-50 border-green-200"
      } else {
        classification = "Basic (Alkaline)"
        color = "text-blue-600"
        bgColor = "bg-blue-50 border-blue-200"
      }

      // Warn if pH is outside typical range
      if (pH < 0 || pH > 14) {
        setError(
          "Warning: pH value is outside the typical 0-14 range. Results may not reflect standard aqueous solutions.",
        )
      }

      setResult({
        pH,
        pOH,
        hConcentration: hConc,
        ohConcentration: ohConc,
        classification,
        color,
        bgColor,
      })
    } catch {
      setError("An error occurred during calculation. Please check your inputs.")
    }
  }

  const handleReset = () => {
    setHConcentration("")
    setOHConcentration("")
    setPHValue("")
    setPOHValue("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `pH: ${result.pH.toFixed(4)}, pOH: ${result.pOH.toFixed(4)}, [H⁺]: ${result.hConcentration.toExponential(4)} M, [OH⁻]: ${result.ohConcentration.toExponential(4)} M (${result.classification})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "pH Calculator Result",
          text: `pH: ${result.pH.toFixed(4)} (${result.classification}) - Calculated using CalcHub`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const formatScientific = (num: number): string => {
    if (num === 0) return "0"
    return num.toExponential(4)
  }

  const getModeLabel = (m: CalculationMode): string => {
    switch (m) {
      case "ph-from-h":
        return "pH from [H⁺]"
      case "h-from-ph":
        return "[H⁺] from pH"
      case "poh-from-oh":
        return "pOH from [OH⁻]"
      case "oh-from-poh":
        return "[OH⁻] from pOH"
      case "ph-from-poh":
        return "pH from pOH"
      case "poh-from-ph":
        return "pOH from pH"
    }
  }

  const getSteps = (): string[] => {
    if (!result) return []
    const steps: string[] = []

    switch (mode) {
      case "ph-from-h":
        steps.push(`Given: [H⁺] = ${formatScientific(result.hConcentration)} M`)
        steps.push(`pH = −log₁₀[H⁺]`)
        steps.push(`pH = −log₁₀(${formatScientific(result.hConcentration)})`)
        steps.push(`pH = ${result.pH.toFixed(4)}`)
        steps.push(`pOH = 14 − pH = 14 − ${result.pH.toFixed(4)} = ${result.pOH.toFixed(4)}`)
        steps.push(`[OH⁻] = 10⁻ᵖᴼᴴ = 10⁻${result.pOH.toFixed(4)} = ${formatScientific(result.ohConcentration)} M`)
        break
      case "h-from-ph":
        steps.push(`Given: pH = ${result.pH.toFixed(4)}`)
        steps.push(`[H⁺] = 10⁻ᵖᴴ`)
        steps.push(`[H⁺] = 10⁻${result.pH.toFixed(4)}`)
        steps.push(`[H⁺] = ${formatScientific(result.hConcentration)} M`)
        steps.push(`pOH = 14 − pH = 14 − ${result.pH.toFixed(4)} = ${result.pOH.toFixed(4)}`)
        steps.push(`[OH⁻] = 10⁻ᵖᴼᴴ = ${formatScientific(result.ohConcentration)} M`)
        break
      case "poh-from-oh":
        steps.push(`Given: [OH⁻] = ${formatScientific(result.ohConcentration)} M`)
        steps.push(`pOH = −log₁₀[OH⁻]`)
        steps.push(`pOH = −log₁₀(${formatScientific(result.ohConcentration)})`)
        steps.push(`pOH = ${result.pOH.toFixed(4)}`)
        steps.push(`pH = 14 − pOH = 14 − ${result.pOH.toFixed(4)} = ${result.pH.toFixed(4)}`)
        steps.push(`[H⁺] = 10⁻ᵖᴴ = ${formatScientific(result.hConcentration)} M`)
        break
      case "oh-from-poh":
        steps.push(`Given: pOH = ${result.pOH.toFixed(4)}`)
        steps.push(`[OH⁻] = 10⁻ᵖᴼᴴ`)
        steps.push(`[OH⁻] = 10⁻${result.pOH.toFixed(4)}`)
        steps.push(`[OH⁻] = ${formatScientific(result.ohConcentration)} M`)
        steps.push(`pH = 14 − pOH = 14 − ${result.pOH.toFixed(4)} = ${result.pH.toFixed(4)}`)
        steps.push(`[H⁺] = 10⁻ᵖᴴ = ${formatScientific(result.hConcentration)} M`)
        break
      case "ph-from-poh":
        steps.push(`Given: pOH = ${result.pOH.toFixed(4)}`)
        steps.push(`pH = 14 − pOH`)
        steps.push(`pH = 14 − ${result.pOH.toFixed(4)}`)
        steps.push(`pH = ${result.pH.toFixed(4)}`)
        steps.push(`[H⁺] = 10⁻ᵖᴴ = ${formatScientific(result.hConcentration)} M`)
        steps.push(`[OH⁻] = 10⁻ᵖᴼᴴ = ${formatScientific(result.ohConcentration)} M`)
        break
      case "poh-from-ph":
        steps.push(`Given: pH = ${result.pH.toFixed(4)}`)
        steps.push(`pOH = 14 − pH`)
        steps.push(`pOH = 14 − ${result.pH.toFixed(4)}`)
        steps.push(`pOH = ${result.pOH.toFixed(4)}`)
        steps.push(`[H⁺] = 10⁻ᵖᴴ = ${formatScientific(result.hConcentration)} M`)
        steps.push(`[OH⁻] = 10⁻ᵖᴼᴴ = ${formatScientific(result.ohConcentration)} M`)
        break
    }

    return steps
  }

  // pH scale colors
  const getPHScaleColor = (pH: number): string => {
    if (pH <= 1) return "bg-red-600"
    if (pH <= 2) return "bg-red-500"
    if (pH <= 3) return "bg-orange-500"
    if (pH <= 4) return "bg-orange-400"
    if (pH <= 5) return "bg-yellow-400"
    if (pH <= 6) return "bg-yellow-300"
    if (pH <= 7) return "bg-green-400"
    if (pH <= 8) return "bg-green-500"
    if (pH <= 9) return "bg-teal-400"
    if (pH <= 10) return "bg-blue-400"
    if (pH <= 11) return "bg-blue-500"
    if (pH <= 12) return "bg-indigo-500"
    if (pH <= 13) return "bg-purple-500"
    return "bg-purple-600"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">pH Calculator</CardTitle>
                    <CardDescription>Calculate pH, pOH, and ion concentrations</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Mode */}
                <div className="space-y-2">
                  <Label>Calculation Mode</Label>
                  <Select
                    value={mode}
                    onValueChange={(value) => {
                      setMode(value as CalculationMode)
                      handleReset()
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ph-from-h">pH from [H⁺]</SelectItem>
                      <SelectItem value="h-from-ph">[H⁺] from pH</SelectItem>
                      <SelectItem value="poh-from-oh">pOH from [OH⁻]</SelectItem>
                      <SelectItem value="oh-from-poh">[OH⁻] from pOH</SelectItem>
                      <SelectItem value="ph-from-poh">pH from pOH</SelectItem>
                      <SelectItem value="poh-from-ph">pOH from pH</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dynamic Input Fields */}
                {mode === "ph-from-h" && (
                  <div className="space-y-2">
                    <Label htmlFor="hConc">[H⁺] Concentration (mol/L)</Label>
                    <Input
                      id="hConc"
                      type="text"
                      placeholder="e.g., 1e-7 or 0.0000001"
                      value={hConcentration}
                      onChange={(e) => setHConcentration(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Use scientific notation (e.g., 1e-7) for small values
                    </p>
                  </div>
                )}

                {(mode === "h-from-ph" || mode === "poh-from-ph") && (
                  <div className="space-y-2">
                    <Label htmlFor="ph">pH Value</Label>
                    <Input
                      id="ph"
                      type="number"
                      placeholder="Enter pH (typically 0-14)"
                      value={phValue}
                      onChange={(e) => setPHValue(e.target.value)}
                      step="0.01"
                    />
                  </div>
                )}

                {mode === "poh-from-oh" && (
                  <div className="space-y-2">
                    <Label htmlFor="ohConc">[OH⁻] Concentration (mol/L)</Label>
                    <Input
                      id="ohConc"
                      type="text"
                      placeholder="e.g., 1e-7 or 0.0000001"
                      value={ohConcentration}
                      onChange={(e) => setOHConcentration(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Use scientific notation (e.g., 1e-7) for small values
                    </p>
                  </div>
                )}

                {(mode === "oh-from-poh" || mode === "ph-from-poh") && (
                  <div className="space-y-2">
                    <Label htmlFor="poh">pOH Value</Label>
                    <Input
                      id="poh"
                      type="number"
                      placeholder="Enter pOH (typically 0-14)"
                      value={pohValue}
                      onChange={(e) => setPOHValue(e.target.value)}
                      step="0.01"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePH} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">pH Value</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.pH.toFixed(2)}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.classification}</p>
                    </div>

                    {/* pH Scale Visualization */}
                    <div className="mb-4">
                      <div className="flex h-6 rounded-full overflow-hidden">
                        {Array.from({ length: 14 }, (_, i) => (
                          <div
                            key={i}
                            className={`flex-1 ${getPHScaleColor(i + 1)} ${result.pH >= i && result.pH < i + 1 ? "ring-2 ring-foreground ring-inset" : ""}`}
                          />
                        ))}
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>0 (Acidic)</span>
                        <span>7 (Neutral)</span>
                        <span>14 (Basic)</span>
                      </div>
                    </div>

                    {/* All Values */}
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-background/50 rounded-lg">
                        <p className="text-muted-foreground text-xs">pH</p>
                        <p className="font-semibold">{result.pH.toFixed(4)}</p>
                      </div>
                      <div className="p-2 bg-background/50 rounded-lg">
                        <p className="text-muted-foreground text-xs">pOH</p>
                        <p className="font-semibold">{result.pOH.toFixed(4)}</p>
                      </div>
                      <div className="p-2 bg-background/50 rounded-lg">
                        <p className="text-muted-foreground text-xs">[H⁺]</p>
                        <p className="font-semibold font-mono text-xs">{formatScientific(result.hConcentration)} M</p>
                      </div>
                      <div className="p-2 bg-background/50 rounded-lg">
                        <p className="text-muted-foreground text-xs">[OH⁻]</p>
                        <p className="font-semibold font-mono text-xs">{formatScientific(result.ohConcentration)} M</p>
                      </div>
                    </div>

                    {/* Show Steps Toggle */}
                    <Button variant="ghost" size="sm" onClick={() => setShowSteps(!showSteps)} className="w-full mt-3">
                      {showSteps ? "Hide Steps" : "Show Steps"}
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-background/50 rounded-lg">
                        <p className="text-xs font-medium mb-2">Calculation Steps:</p>
                        <div className="space-y-1">
                          {getSteps().map((step, idx) => (
                            <p key={idx} className="text-xs font-mono">
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">pH Scale Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-red-50 border border-red-200">
                      <span className="text-sm font-medium text-red-700">Strong Acid</span>
                      <span className="text-xs text-red-600">pH 0-2</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="text-sm font-medium text-orange-700">Weak Acid</span>
                      <span className="text-xs text-orange-600">pH 3-6</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-green-50 border border-green-200">
                      <span className="text-sm font-medium text-green-700">Neutral</span>
                      <span className="text-xs text-green-600">pH 7</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-teal-50 border border-teal-200">
                      <span className="text-sm font-medium text-teal-700">Weak Base</span>
                      <span className="text-xs text-teal-600">pH 8-11</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="text-sm font-medium text-purple-700">Strong Base</span>
                      <span className="text-xs text-purple-600">pH 12-14</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm text-center">
                    <p>pH = −log₁₀[H⁺]</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm text-center">
                    <p>pOH = −log₁₀[OH⁻]</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm text-center">
                    <p>pH + pOH = 14 (at 25°C)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm text-center">
                    <p>Kw = [H⁺][OH⁻] = 10⁻¹⁴</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800 mb-1">Disclaimer</p>
                      <p className="text-sm text-amber-700">
                        Results assume ideal aqueous solutions at standard conditions (25°C) unless otherwise specified.
                        For accurate laboratory work, always verify with calibrated instruments.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is pH?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  pH is a measure of the acidity or basicity (alkalinity) of an aqueous solution. The term "pH" stands
                  for "potential of hydrogen" or "power of hydrogen." It quantifies the concentration of hydrogen ions
                  (H⁺) in a solution on a logarithmic scale ranging from 0 to 14. A pH of 7 is considered neutral (pure
                  water at 25°C), values below 7 indicate acidic solutions, and values above 7 indicate basic or
                  alkaline solutions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The pH scale was developed by Danish chemist Søren Peder Lauritz Sørensen in 1909 while working at the
                  Carlsberg Laboratory. Because pH is a logarithmic scale, each whole pH value below 7 is ten times more
                  acidic than the next higher value. For example, a solution with pH 4 is ten times more acidic than one
                  with pH 5, and 100 times more acidic than one with pH 6.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding pH and pOH</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In any aqueous solution at 25°C, the product of the hydrogen ion concentration [H⁺] and hydroxide ion
                  concentration [OH⁻] is constant: Kw = [H⁺][OH⁻] = 1.0 × 10⁻¹⁴. This relationship, known as the ion
                  product of water, means that as one concentration increases, the other must decrease proportionally.
                  This is why acidic solutions have high [H⁺] and low [OH⁻], while basic solutions have the opposite.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Acidic Solutions (pH &lt; 7)</h4>
                    <p className="text-red-700 text-sm">
                      Have higher [H⁺] than [OH⁻]. Examples include vinegar (pH ~2.5), lemon juice (pH ~2), and stomach
                      acid (pH ~1.5-3.5). Strong acids like HCl completely dissociate in water.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Basic Solutions (pH &gt; 7)</h4>
                    <p className="text-blue-700 text-sm">
                      Have higher [OH⁻] than [H⁺]. Examples include baking soda solution (pH ~8.5), soap (pH ~9-10), and
                      household ammonia (pH ~11-12). Strong bases like NaOH fully dissociate.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Common pH Values</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Acidic Substances</h4>
                    <div className="space-y-1 text-sm text-muted-foreground">
                      <p>• Battery acid: pH 0</p>
                      <p>• Stomach acid: pH 1.5-3.5</p>
                      <p>• Lemon juice: pH 2.0</p>
                      <p>• Vinegar: pH 2.5</p>
                      <p>• Orange juice: pH 3.5</p>
                      <p>• Coffee: pH 5.0</p>
                      <p>• Milk: pH 6.5</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Basic Substances</h4>
                    <div className="space-y-1 text-sm text-muted-foreground">
                      <p>• Pure water: pH 7.0</p>
                      <p>• Blood: pH 7.35-7.45</p>
                      <p>• Sea water: pH 8.0</p>
                      <p>• Baking soda: pH 8.5</p>
                      <p>• Soap: pH 9-10</p>
                      <p>• Ammonia: pH 11-12</p>
                      <p>• Bleach: pH 12.5</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  pH measurement is crucial in many fields. In medicine, blood pH must be maintained between 7.35-7.45;
                  deviations can indicate serious conditions like acidosis or alkalosis. In agriculture, soil pH affects
                  nutrient availability for plants. In swimming pools, pH is maintained between 7.2-7.8 for comfort and
                  chlorine effectiveness. Industrial processes, food production, and water treatment all rely on precise
                  pH control for safety and quality.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Environmental scientists monitor the pH of water bodies to detect pollution and assess ecosystem
                  health. Acid rain, with pH values as low as 4.2, can damage ecosystems and corrode buildings.
                  Understanding and controlling pH is fundamental to chemistry, biology, environmental science, and many
                  industrial applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
