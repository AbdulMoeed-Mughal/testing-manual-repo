"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Layers,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type SurfaceType = "wall" | "ceiling"

interface PlasterResult {
  surfaceArea: number
  plasterVolume: number
  volumeWithWaste: number
  plasterWeight: number
  weightInTonnes: number
}

export function PlasterCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [surfaceType, setSurfaceType] = useState<SurfaceType>("wall")
  const [length, setLength] = useState("")
  const [height, setHeight] = useState("")
  const [thickness, setThickness] = useState("")
  const [thicknessUnit, setThicknessUnit] = useState<"mm" | "inches">("mm")
  const [density, setDensity] = useState("")
  const [wastePercent, setWastePercent] = useState("5")
  const [numCoats, setNumCoats] = useState("1")
  const [result, setResult] = useState<PlasterResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Default densities
  const defaultDensityMetric = 1600 // kg/m³
  const defaultDensityImperial = 100 // lb/ft³

  const calculatePlaster = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const heightNum = Number.parseFloat(height)
    const thicknessNum = Number.parseFloat(thickness)
    const wasteNum = Number.parseFloat(wastePercent) || 0
    const coatsNum = Number.parseInt(numCoats) || 1
    const densityNum =
      Number.parseFloat(density) || (unitSystem === "metric" ? defaultDensityMetric : defaultDensityImperial)

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }
    if (isNaN(heightNum) || heightNum <= 0) {
      setError("Please enter a valid height/width greater than 0")
      return
    }
    if (isNaN(thicknessNum) || thicknessNum <= 0) {
      setError("Please enter a valid thickness greater than 0")
      return
    }
    if (wasteNum < 0) {
      setError("Waste percentage cannot be negative")
      return
    }
    if (coatsNum < 1) {
      setError("Number of coats must be at least 1")
      return
    }

    // Calculate surface area
    const surfaceArea = lengthNum * heightNum

    // Convert thickness to meters or feet
    let thicknessInUnit: number
    if (unitSystem === "metric") {
      thicknessInUnit = thicknessUnit === "mm" ? thicknessNum / 1000 : thicknessNum * 0.0254
    } else {
      thicknessInUnit = thicknessUnit === "inches" ? thicknessNum / 12 : thicknessNum * 0.00328084
    }

    // Calculate volume (area × thickness × coats)
    const plasterVolume = surfaceArea * thicknessInUnit * coatsNum

    // Add waste
    const volumeWithWaste = plasterVolume * (1 + wasteNum / 100)

    // Calculate weight
    const plasterWeight = volumeWithWaste * densityNum
    const weightInTonnes = unitSystem === "metric" ? plasterWeight / 1000 : plasterWeight / 2000

    setResult({
      surfaceArea,
      plasterVolume,
      volumeWithWaste,
      plasterWeight,
      weightInTonnes,
    })
  }

  const handleReset = () => {
    setLength("")
    setHeight("")
    setThickness("")
    setDensity("")
    setWastePercent("5")
    setNumCoats("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        unitSystem === "metric"
          ? `Plaster Required: ${result.volumeWithWaste.toFixed(4)} m³ (${result.plasterWeight.toFixed(2)} kg)`
          : `Plaster Required: ${result.volumeWithWaste.toFixed(4)} ft³ (${result.plasterWeight.toFixed(2)} lb)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Plaster Calculator Result",
          text: `Plaster Required: ${result.volumeWithWaste.toFixed(4)} ${unitSystem === "metric" ? "m³" : "ft³"} (${result.plasterWeight.toFixed(2)} ${unitSystem === "metric" ? "kg" : "lb"})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setThicknessUnit(unitSystem === "metric" ? "inches" : "mm")
    setDensity("")
    setResult(null)
    setError("")
  }

  const lengthNum = Number.parseFloat(length) || 0
  const heightNum = Number.parseFloat(height) || 0
  const thicknessNum = Number.parseFloat(thickness) || 0
  const wasteNum = Number.parseFloat(wastePercent) || 0
  const coatsNum = Number.parseInt(numCoats) || 1
  const densityNum =
    Number.parseFloat(density) || (unitSystem === "metric" ? defaultDensityMetric : defaultDensityImperial)

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Plaster Calculator</CardTitle>
                    <CardDescription>Calculate plaster requirements for surfaces</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Surface Type */}
                <div className="space-y-2">
                  <Label>Surface Type</Label>
                  <Select value={surfaceType} onValueChange={(v) => setSurfaceType(v as SurfaceType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="wall">Wall</SelectItem>
                      <SelectItem value="ceiling">Ceiling</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Surface Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder="e.g., 5"
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="height">
                      {surfaceType === "wall" ? "Height" : "Width"} ({unitSystem === "metric" ? "m" : "ft"})
                    </Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="e.g., 3"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Thickness */}
                <div className="space-y-2">
                  <Label>Plaster Thickness</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      type="number"
                      placeholder={thicknessUnit === "mm" ? "e.g., 12" : "e.g., 0.5"}
                      value={thickness}
                      onChange={(e) => setThickness(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                    <Select value={thicknessUnit} onValueChange={(v) => setThicknessUnit(v as "mm" | "inches")}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mm">mm</SelectItem>
                        <SelectItem value="inches">inches</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Number of Coats */}
                <div className="space-y-2">
                  <Label htmlFor="coats">Number of Coats</Label>
                  <Select value={numCoats} onValueChange={setNumCoats}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 coat</SelectItem>
                      <SelectItem value="2">2 coats</SelectItem>
                      <SelectItem value="3">3 coats</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Density */}
                <div className="space-y-2">
                  <Label htmlFor="density">Plaster Density ({unitSystem === "metric" ? "kg/m³" : "lb/ft³"})</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder={`Default: ${unitSystem === "metric" ? defaultDensityMetric : defaultDensityImperial}`}
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="waste">Waste Percentage (%)</Label>
                  <Input
                    id="waste"
                    type="number"
                    placeholder="e.g., 5"
                    value={wastePercent}
                    onChange={(e) => setWastePercent(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePlaster} className="w-full" size="lg">
                  Calculate Plaster
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Plaster Required</p>
                      <p className="text-4xl font-bold text-amber-700">
                        {result.volumeWithWaste.toFixed(4)} {unitSystem === "metric" ? "m³" : "ft³"}
                      </p>
                      <p className="text-lg font-semibold text-amber-600 mt-1">
                        {result.plasterWeight.toFixed(2)} {unitSystem === "metric" ? "kg" : "lb"}
                        <span className="text-sm font-normal text-muted-foreground ml-2">
                          ({result.weightInTonnes.toFixed(3)} {unitSystem === "metric" ? "tonnes" : "tons"})
                        </span>
                      </p>
                    </div>

                    {/* Detailed Results */}
                    <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Surface Area</p>
                        <p className="font-semibold">
                          {result.surfaceArea.toFixed(2)} {unitSystem === "metric" ? "m²" : "ft²"}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Volume (no waste)</p>
                        <p className="font-semibold">
                          {result.plasterVolume.toFixed(4)} {unitSystem === "metric" ? "m³" : "ft³"}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step breakdown */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full flex items-center justify-between p-2 bg-white rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors"
                    >
                      <span>Calculation Steps</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Surface Area = {lengthNum} × {heightNum} ={" "}
                          {result.surfaceArea.toFixed(2)} {unitSystem === "metric" ? "m²" : "ft²"}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Thickness = {thicknessNum} {thicknessUnit} ={" "}
                          {(thicknessUnit === "mm" ? thicknessNum / 1000 : thicknessNum / 12).toFixed(4)}{" "}
                          {unitSystem === "metric" ? "m" : "ft"}
                        </p>
                        <p>
                          <strong>Step 3:</strong> Volume = {result.surfaceArea.toFixed(2)} ×{" "}
                          {(thicknessUnit === "mm" ? thicknessNum / 1000 : thicknessNum / 12).toFixed(4)} × {coatsNum} ={" "}
                          {result.plasterVolume.toFixed(4)} {unitSystem === "metric" ? "m³" : "ft³"}
                        </p>
                        <p>
                          <strong>Step 4:</strong> Volume with {wasteNum}% waste = {result.plasterVolume.toFixed(4)} ×{" "}
                          {(1 + wasteNum / 100).toFixed(2)} = {result.volumeWithWaste.toFixed(4)}{" "}
                          {unitSystem === "metric" ? "m³" : "ft³"}
                        </p>
                        <p>
                          <strong>Step 5:</strong> Weight = {result.volumeWithWaste.toFixed(4)} × {densityNum} ={" "}
                          {result.plasterWeight.toFixed(2)} {unitSystem === "metric" ? "kg" : "lb"}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Plaster Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Volume = Area × Thickness × Coats</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Weight = Volume × Density</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Plaster Thickness</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Internal walls</span>
                      <span className="font-medium">10-15 mm</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>External walls</span>
                      <span className="font-medium">15-20 mm</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Ceiling</span>
                      <span className="font-medium">6-10 mm</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Concrete surfaces</span>
                      <span className="font-medium">12-15 mm</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Plaster Types & Densities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Cement plaster</span>
                      <span className="font-medium">1600-1800 kg/m³</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Gypsum plaster</span>
                      <span className="font-medium">1000-1200 kg/m³</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Lime plaster</span>
                      <span className="font-medium">1400-1600 kg/m³</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Plaster?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Plaster is a building material used for coating walls, ceilings, and other surfaces to provide a
                  smooth, durable, and aesthetically pleasing finish. It consists of a binder (such as cement, gypsum,
                  or lime) mixed with sand and water. When applied wet, plaster hardens through a chemical process,
                  creating a solid surface that can be painted or decorated.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Plastering serves multiple purposes: it protects walls from weather and moisture, improves thermal and
                  acoustic insulation, and provides a base for decorative finishes. The type of plaster used depends on
                  the application, with cement plaster being common for exterior walls and gypsum plaster preferred for
                  interior surfaces due to its smooth finish.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Plaster Coats</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Plastering is typically done in multiple coats, each serving a specific purpose. The number of coats
                  depends on the surface condition, type of plaster, and desired finish quality.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-1">First Coat (Scratch/Render Coat)</h4>
                    <p className="text-amber-700 text-sm">
                      The base coat applied directly to the wall surface. It fills gaps, provides adhesion, and creates
                      a rough surface for subsequent coats. Typically 10-15 mm thick.
                    </p>
                  </div>
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-1">Second Coat (Brown/Floating Coat)</h4>
                    <p className="text-amber-700 text-sm">
                      Applied over the scratch coat to level the surface and achieve the desired thickness. This coat is
                      floated to create an even surface. Usually 6-10 mm thick.
                    </p>
                  </div>
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-1">Third Coat (Finish/Set Coat)</h4>
                    <p className="text-amber-700 text-sm">
                      The final thin coat that provides a smooth, paintable surface. Applied at 2-3 mm thickness and
                      troweled to achieve the desired finish texture.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Account for openings:</strong> Subtract the area of doors, windows, and other openings from
                    the total wall area.
                  </li>
                  <li>
                    <strong>Surface condition:</strong> Rough or uneven surfaces require more plaster than smooth
                    surfaces.
                  </li>
                  <li>
                    <strong>Wastage factor:</strong> Always add 5-10% for spillage, waste, and uneven application.
                  </li>
                  <li>
                    <strong>Mixing ratio:</strong> For cement plaster, typical ratios are 1:4 to 1:6 (cement:sand)
                    depending on application.
                  </li>
                  <li>
                    <strong>Curing:</strong> Proper curing is essential for plaster strength; keep the surface moist for
                    at least 7 days.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-amber-800 mb-1">Disclaimer</h4>
                    <p className="text-sm text-amber-700">
                      Results are estimates. Actual plaster requirements may vary due to surface texture, workmanship,
                      and site conditions. Always consult with a professional contractor for accurate material
                      quantities and consider purchasing slightly more than calculated to account for unforeseen
                      variations.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
