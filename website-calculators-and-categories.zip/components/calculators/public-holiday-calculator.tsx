"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, CalendarDays, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Holiday {
  date: string
  name: string
  type: string
}

const holidayData: Record<string, Holiday[]> = {
  US: [
    { date: "2024-01-01", name: "New Year's Day", type: "National" },
    { date: "2024-01-15", name: "Martin Luther King Jr. Day", type: "National" },
    { date: "2024-02-19", name: "Presidents' Day", type: "National" },
    { date: "2024-05-27", name: "Memorial Day", type: "National" },
    { date: "2024-07-04", name: "Independence Day", type: "National" },
    { date: "2024-09-02", name: "Labor Day", type: "National" },
    { date: "2024-10-14", name: "Columbus Day", type: "National" },
    { date: "2024-11-11", name: "Veterans Day", type: "National" },
    { date: "2024-11-28", name: "Thanksgiving Day", type: "National" },
    { date: "2024-12-25", name: "Christmas Day", type: "National" },
  ],
  UK: [
    { date: "2024-01-01", name: "New Year's Day", type: "National" },
    { date: "2024-03-29", name: "Good Friday", type: "National" },
    { date: "2024-04-01", name: "Easter Monday", type: "National" },
    { date: "2024-05-06", name: "Early May Bank Holiday", type: "National" },
    { date: "2024-05-27", name: "Spring Bank Holiday", type: "National" },
    { date: "2024-08-26", name: "Summer Bank Holiday", type: "National" },
    { date: "2024-12-25", name: "Christmas Day", type: "National" },
    { date: "2024-12-26", name: "Boxing Day", type: "National" },
  ],
  CA: [
    { date: "2024-01-01", name: "New Year's Day", type: "National" },
    { date: "2024-03-29", name: "Good Friday", type: "National" },
    { date: "2024-05-20", name: "Victoria Day", type: "National" },
    { date: "2024-07-01", name: "Canada Day", type: "National" },
    { date: "2024-09-02", name: "Labour Day", type: "National" },
    { date: "2024-10-14", name: "Thanksgiving", type: "National" },
    { date: "2024-11-11", name: "Remembrance Day", type: "National" },
    { date: "2024-12-25", name: "Christmas Day", type: "National" },
    { date: "2024-12-26", name: "Boxing Day", type: "National" },
  ],
  AU: [
    { date: "2024-01-01", name: "New Year's Day", type: "National" },
    { date: "2024-01-26", name: "Australia Day", type: "National" },
    { date: "2024-03-29", name: "Good Friday", type: "National" },
    { date: "2024-03-30", name: "Easter Saturday", type: "National" },
    { date: "2024-04-01", name: "Easter Monday", type: "National" },
    { date: "2024-04-25", name: "ANZAC Day", type: "National" },
    { date: "2024-06-10", name: "Queen's Birthday", type: "National" },
    { date: "2024-12-25", name: "Christmas Day", type: "National" },
    { date: "2024-12-26", name: "Boxing Day", type: "National" },
  ],
}

const countries = [
  { code: "US", name: "United States" },
  { code: "UK", name: "United Kingdom" },
  { code: "CA", name: "Canada" },
  { code: "AU", name: "Australia" },
]

export function PublicHolidayCalculator() {
  const [country, setCountry] = useState("US")
  const [year] = useState("2024")
  const [holidays, setHolidays] = useState<Holiday[]>([])
  const [nextHoliday, setNextHoliday] = useState<Holiday | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const countryHolidays = holidayData[country] || []
    setHolidays(countryHolidays)

    const today = new Date()
    const upcoming = countryHolidays.find((holiday) => new Date(holiday.date) > today)
    setNextHoliday(upcoming || null)
  }, [country])

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr)
    return date.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })
  }

  const getDaysUntil = (dateStr: string): number => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const targetDate = new Date(dateStr)
    const diffTime = targetDate.getTime() - today.getTime()
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  }

  const handleReset = () => {
    setCountry("US")
    setCopied(false)
  }

  const handleCopy = async () => {
    const text = holidays.map((h) => `${formatDate(h.date)}: ${h.name}`).join("\n")
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        const countryName = countries.find((c) => c.code === country)?.name
        await navigator.share({
          title: "Public Holidays",
          text: `Public holidays in ${countryName} for ${year}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <CalendarDays className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Public Holiday Calculator</CardTitle>
                    <CardDescription>View public holidays by country</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="country">Select Country</Label>
                  <Select value={country} onValueChange={setCountry}>
                    <SelectTrigger id="country">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((c) => (
                        <SelectItem key={c.code} value={c.code}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {nextHoliday && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200">
                    <p className="text-sm text-muted-foreground mb-2">Next Upcoming Holiday</p>
                    <p className="text-xl font-bold text-cyan-600">{nextHoliday.name}</p>
                    <p className="text-sm text-cyan-700 mt-1">{formatDate(nextHoliday.date)}</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      {getDaysUntil(nextHoliday.date)} days from now
                    </p>
                  </div>
                )}

                <div className="flex items-center justify-center gap-2">
                  <Button variant="outline" size="sm" onClick={handleReset}>
                    <RotateCcw className="h-4 w-4 mr-1" />
                    Reset
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                    {copied ? "Copied" : "Copy"}
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleShare}>
                    <Share2 className="h-4 w-4 mr-1" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">All Holidays ({year})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-[400px] overflow-y-auto">
                    {holidays.map((holiday, index) => (
                      <div key={index} className="p-3 rounded-lg bg-muted border border-border">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <p className="font-medium text-foreground">{holiday.name}</p>
                            <p className="text-sm text-muted-foreground mt-0.5">
                              {new Date(holiday.date).toLocaleDateString("en-US", {
                                weekday: "short",
                                month: "short",
                                day: "numeric",
                              })}
                            </p>
                          </div>
                          <span className="text-xs px-2 py-1 rounded-full bg-cyan-50 text-cyan-600 border border-cyan-200">
                            {holiday.type}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>About Public Holidays</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Public holidays are designated days when most businesses, government offices, and schools are closed to commemorate significant historical, religious, or cultural events. These holidays vary widely by country and region, reflecting local traditions, history, and values. Understanding when public holidays occur is essential for planning travel, scheduling business activities, and coordinating international communications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Many countries have a mix of fixed-date holidays (like New Year's Day on January 1) and moveable holidays that change dates each year (like Easter or Thanksgiving). Some holidays are observed nationally, while others may be specific to certain regions or states within a country. This calculator helps you stay informed about upcoming holidays to better plan your personal and professional activities.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-5 w-5 text-primary" />
                  <CardTitle>Planning Around Holidays</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Being aware of public holidays is crucial for various aspects of planning. Businesses need to account for holidays when scheduling meetings, deadlines, and deliveries, especially when working with international partners across different holiday calendars. Travelers should check holiday dates to avoid crowded destinations or take advantage of long weekends for extended trips.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Many services, including banks, post offices, and government agencies, operate on reduced schedules or close entirely on public holidays. Online shopping and service delivery may also be affected. By checking public holidays in advance, you can better coordinate your activities, avoid scheduling conflicts, and ensure you're not caught off guard by unexpected closures or delays.
                </p>
              </CardContent>
            </Card>

            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-amber-800">
                  <p className="font-semibold mb-1">Disclaimer</p>
                  <p>
                    Public holiday information is based on available data and may vary by country, region, or updates. Verify
                    with official government sources for accuracy.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
