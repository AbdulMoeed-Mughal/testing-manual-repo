"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  Home,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Percent,
  Calculator,
  Building,
  TrendingUp,
  Activity,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface HomeAffordabilityResult {
  maxHomePrice: number
  maxLoanAmount: number
  downPaymentAmount: number
  monthlyPayment: number
  monthlyPrincipalInterest: number
  monthlyPropertyTax: number
  monthlyInsurance: number
  monthlyPMI: number
  frontEndRatio: number
  backEndRatio: number
  loanToValueRatio: number
  affordabilityCategory: "conservative" | "comfortable" | "stretched" | "risky"
}

const LOAN_TERMS = [
  { value: "15", label: "15 years" },
  { value: "20", label: "20 years" },
  { value: "30", label: "30 years" },
]

const INCOME_TYPES = [
  { value: "annual", label: "Annual" },
  { value: "monthly", label: "Monthly" },
]

export function HomeAffordabilityCalculator() {
  const [income, setIncome] = useState("")
  const [incomeType, setIncomeType] = useState("annual")
  const [monthlyDebts, setMonthlyDebts] = useState("")
  const [downPayment, setDownPayment] = useState("")
  const [downPaymentType, setDownPaymentType] = useState<"amount" | "percent">("percent")
  const [interestRate, setInterestRate] = useState("")
  const [loanTerm, setLoanTerm] = useState("30")
  const [propertyTaxRate, setPropertyTaxRate] = useState("1.2")
  const [homeInsurance, setHomeInsurance] = useState("")
  const [maxPaymentLimit, setMaxPaymentLimit] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<HomeAffordabilityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateAffordability = () => {
    setError("")
    setResult(null)

    const grossIncome = Number.parseFloat(income)
    const debts = monthlyDebts ? Number.parseFloat(monthlyDebts) : 0
    const downPay = Number.parseFloat(downPayment) || 20
    const rate = Number.parseFloat(interestRate)
    const term = Number.parseInt(loanTerm)
    const taxRate = Number.parseFloat(propertyTaxRate) || 1.2
    const insurance = homeInsurance ? Number.parseFloat(homeInsurance) : 0
    const paymentLimit = maxPaymentLimit ? Number.parseFloat(maxPaymentLimit) : 0

    // Validation
    if (!income || grossIncome <= 0) {
      setError("Please enter valid income")
      return
    }

    if (!interestRate || rate <= 0 || rate > 20) {
      setError("Please enter a valid interest rate (0-20%)")
      return
    }

    // Convert to monthly income if annual
    const monthlyIncome = incomeType === "annual" ? grossIncome / 12 : grossIncome

    // Apply 28/36 rule
    // Front-end ratio: Housing expenses should not exceed 28% of gross monthly income
    // Back-end ratio: Total debt should not exceed 36% of gross monthly income
    const maxHousingPayment = monthlyIncome * 0.28
    const maxTotalDebt = monthlyIncome * 0.36
    const maxHousingFromDebtRule = maxTotalDebt - debts

    // Use the lower of the two limits
    let effectiveMaxPayment = Math.min(maxHousingPayment, maxHousingFromDebtRule)

    // Apply user-specified payment limit if lower
    if (paymentLimit > 0 && paymentLimit < effectiveMaxPayment) {
      effectiveMaxPayment = paymentLimit
    }

    // Calculate monthly interest rate
    const monthlyRate = rate / 100 / 12
    const numberOfPayments = term * 12

    // Estimate property tax and insurance as percentage of home price
    // We need to iterate to find the max home price
    let maxHomePrice = 0
    let monthlyPITI = 0
    let monthlyPI = 0
    let monthlyTax = 0
    let monthlyIns = 0
    let monthlyPMI = 0

    // Iterative calculation to find max home price
    for (let price = 50000; price <= 5000000; price += 1000) {
      // Calculate down payment amount
      const dpAmount = downPaymentType === "percent" ? price * (downPay / 100) : downPay
      const loanAmount = price - dpAmount
      const ltv = (loanAmount / price) * 100

      // Calculate monthly P&I
      const monthlyPrincipalInterest =
        (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))) /
        (Math.pow(1 + monthlyRate, numberOfPayments) - 1)

      // Calculate monthly property tax
      const monthlyPropertyTax = (price * (taxRate / 100)) / 12

      // Calculate monthly insurance (estimate 0.5% of home price annually if not specified)
      const annualInsurance = insurance > 0 ? insurance : price * 0.005
      const monthlyInsurance = annualInsurance / 12

      // Calculate PMI if LTV > 80%
      const pmi = ltv > 80 ? (loanAmount * 0.005) / 12 : 0

      // Total monthly payment (PITI + PMI)
      const totalMonthly = monthlyPrincipalInterest + monthlyPropertyTax + monthlyInsurance + pmi

      if (totalMonthly <= effectiveMaxPayment) {
        maxHomePrice = price
        monthlyPITI = totalMonthly
        monthlyPI = monthlyPrincipalInterest
        monthlyTax = monthlyPropertyTax
        monthlyIns = monthlyInsurance
        monthlyPMI = pmi
      } else {
        break
      }
    }

    if (maxHomePrice === 0) {
      setError("Unable to calculate affordability with current inputs. Try adjusting your values.")
      return
    }

    // Calculate final values
    const finalDownPayment = downPaymentType === "percent" ? maxHomePrice * (downPay / 100) : downPay
    const finalLoanAmount = maxHomePrice - finalDownPayment
    const finalLTV = (finalLoanAmount / maxHomePrice) * 100

    // Calculate actual ratios
    const frontEndRatio = (monthlyPITI / monthlyIncome) * 100
    const backEndRatio = ((monthlyPITI + debts) / monthlyIncome) * 100

    // Determine affordability category
    let affordabilityCategory: "conservative" | "comfortable" | "stretched" | "risky" = "comfortable"
    if (frontEndRatio <= 20 && backEndRatio <= 28) {
      affordabilityCategory = "conservative"
    } else if (frontEndRatio <= 28 && backEndRatio <= 36) {
      affordabilityCategory = "comfortable"
    } else if (frontEndRatio <= 33 && backEndRatio <= 43) {
      affordabilityCategory = "stretched"
    } else {
      affordabilityCategory = "risky"
    }

    setResult({
      maxHomePrice,
      maxLoanAmount: finalLoanAmount,
      downPaymentAmount: finalDownPayment,
      monthlyPayment: monthlyPITI,
      monthlyPrincipalInterest: monthlyPI,
      monthlyPropertyTax: monthlyTax,
      monthlyInsurance: monthlyIns,
      monthlyPMI: monthlyPMI,
      frontEndRatio,
      backEndRatio,
      loanToValueRatio: finalLTV,
      affordabilityCategory,
    })
  }

  const handleReset = () => {
    setIncome("")
    setIncomeType("annual")
    setMonthlyDebts("")
    setDownPayment("")
    setDownPaymentType("percent")
    setInterestRate("")
    setLoanTerm("30")
    setPropertyTaxRate("1.2")
    setHomeInsurance("")
    setMaxPaymentLimit("")
    setShowAdvanced(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Home Affordability Summary:\nMax Home Price: ${formatCurrency(result.maxHomePrice)}\nLoan Amount: ${formatCurrency(result.maxLoanAmount)}\nDown Payment: ${formatCurrency(result.downPaymentAmount)}\nMonthly Payment: ${formatCurrency(result.monthlyPayment)}\nFront-End Ratio: ${result.frontEndRatio.toFixed(1)}%\nBack-End Ratio: ${result.backEndRatio.toFixed(1)}%`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Home Affordability",
          text: `I can afford a home up to ${formatCurrency(result.maxHomePrice)} with a monthly payment of ${formatCurrency(result.monthlyPayment)}!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "conservative":
        return "bg-green-50 border-green-200 text-green-700"
      case "comfortable":
        return "bg-blue-50 border-blue-200 text-blue-700"
      case "stretched":
        return "bg-yellow-50 border-yellow-200 text-yellow-700"
      case "risky":
        return "bg-red-50 border-red-200 text-red-700"
      default:
        return "bg-gray-50 border-gray-200 text-gray-700"
    }
  }

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "conservative":
        return "Conservative"
      case "comfortable":
        return "Comfortable"
      case "stretched":
        return "Stretched"
      case "risky":
        return "Risky"
      default:
        return "Unknown"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "conservative":
        return <TrendingUp className="h-5 w-5" />
      case "comfortable":
        return <Home className="h-5 w-5" />
      case "stretched":
        return <AlertTriangle className="h-5 w-5" />
      case "risky":
        return <AlertTriangle className="h-5 w-5" />
      default:
        return <Home className="h-5 w-5" />
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Home Affordability Calculator</CardTitle>
                    <CardDescription>Estimate how much home you can afford</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Income */}
                <div className="space-y-2">
                  <Label>Gross Income</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder="Enter income"
                      value={income}
                      onChange={(e) => setIncome(e.target.value)}
                      min="0"
                      step="1000"
                      className="flex-1"
                    />
                    <Select value={incomeType} onValueChange={setIncomeType}>
                      <SelectTrigger className="w-28">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {INCOME_TYPES.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Monthly Debts */}
                <div className="space-y-2">
                  <Label htmlFor="monthlyDebts">Monthly Debt Payments ($)</Label>
                  <Input
                    id="monthlyDebts"
                    type="number"
                    placeholder="Car loans, credit cards, student loans, etc."
                    value={monthlyDebts}
                    onChange={(e) => setMonthlyDebts(e.target.value)}
                    min="0"
                    step="50"
                  />
                </div>

                {/* Down Payment */}
                <div className="space-y-2">
                  <Label>Down Payment</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder={downPaymentType === "percent" ? "20" : "50000"}
                      value={downPayment}
                      onChange={(e) => setDownPayment(e.target.value)}
                      min="0"
                      className="flex-1"
                    />
                    <div className="flex border rounded-lg overflow-hidden">
                      <Button
                        type="button"
                        variant={downPaymentType === "percent" ? "default" : "ghost"}
                        size="sm"
                        className="rounded-none px-3"
                        onClick={() => setDownPaymentType("percent")}
                      >
                        <Percent className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant={downPaymentType === "amount" ? "default" : "ghost"}
                        size="sm"
                        className="rounded-none px-3"
                        onClick={() => setDownPaymentType("amount")}
                      >
                        <DollarSign className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="e.g., 6.5"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    max="20"
                    step="0.125"
                  />
                </div>

                {/* Loan Term */}
                <div className="space-y-2">
                  <Label>Loan Term</Label>
                  <Select value={loanTerm} onValueChange={setLoanTerm}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select loan term" />
                    </SelectTrigger>
                    <SelectContent>
                      {LOAN_TERMS.map((term) => (
                        <SelectItem key={term.value} value={term.value}>
                          {term.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options */}
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="w-full justify-between"
                  >
                    <span>Advanced Options</span>
                    {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>

                  {showAdvanced && (
                    <div className="space-y-3 p-3 border rounded-lg bg-muted/30">
                      <div className="space-y-2">
                        <Label htmlFor="propertyTaxRate">Property Tax Rate (% per year)</Label>
                        <Input
                          id="propertyTaxRate"
                          type="number"
                          placeholder="1.2"
                          value={propertyTaxRate}
                          onChange={(e) => setPropertyTaxRate(e.target.value)}
                          min="0"
                          max="5"
                          step="0.1"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="homeInsurance">Annual Home Insurance ($)</Label>
                        <Input
                          id="homeInsurance"
                          type="number"
                          placeholder="Leave blank to estimate"
                          value={homeInsurance}
                          onChange={(e) => setHomeInsurance(e.target.value)}
                          min="0"
                          step="100"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="maxPaymentLimit">Max Monthly Payment Limit ($)</Label>
                        <Input
                          id="maxPaymentLimit"
                          type="number"
                          placeholder="Optional limit"
                          value={maxPaymentLimit}
                          onChange={(e) => setMaxPaymentLimit(e.target.value)}
                          min="0"
                          step="100"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAffordability} className="w-full" size="lg">
                  Calculate Affordability
                </Button>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleReset} className="flex-1 bg-transparent">
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                  <Button variant="outline" onClick={handleCopy} disabled={!result} className="flex-1 bg-transparent">
                    {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                    {copied ? "Copied!" : "Copy"}
                  </Button>
                  <Button variant="outline" onClick={handleShare} disabled={!result} className="flex-1 bg-transparent">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${getCategoryColor(result.affordabilityCategory)}`}
                  >
                    <div className="text-center mb-4">
                      <div className="flex items-center justify-center gap-2 mb-1">
                        {getCategoryIcon(result.affordabilityCategory)}
                        <p className="text-sm font-medium">{getCategoryLabel(result.affordabilityCategory)}</p>
                      </div>
                      <p className="text-3xl font-bold mb-1">{formatCurrency(result.maxHomePrice)}</p>
                      <p className="text-sm opacity-80">Maximum Home Price</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white/80 rounded-lg text-center">
                        <p className="text-xs opacity-70 mb-1">Monthly Payment</p>
                        <p className="text-lg font-bold">{formatCurrency(result.monthlyPayment)}</p>
                      </div>
                      <div className="p-3 bg-white/80 rounded-lg text-center">
                        <p className="text-xs opacity-70 mb-1">Down Payment</p>
                        <p className="text-lg font-bold">{formatCurrency(result.downPaymentAmount)}</p>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full justify-between bg-white/50 hover:bg-white/70"
                    >
                      <span>View Payment Breakdown</span>
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>

                    {showDetails && (
                      <div className="mt-3 p-3 bg-white/80 rounded-lg space-y-3">
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="opacity-70">Principal & Interest</span>
                            <span className="font-semibold">{formatCurrency(result.monthlyPrincipalInterest)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="opacity-70">Property Tax</span>
                            <span className="font-semibold">{formatCurrency(result.monthlyPropertyTax)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="opacity-70">Insurance</span>
                            <span className="font-semibold">{formatCurrency(result.monthlyInsurance)}</span>
                          </div>
                          {result.monthlyPMI > 0 && (
                            <div className="flex justify-between">
                              <span className="opacity-70">PMI</span>
                              <span className="font-semibold">{formatCurrency(result.monthlyPMI)}</span>
                            </div>
                          )}
                          <div className="border-t pt-2 flex justify-between font-semibold">
                            <span>Total Monthly (PITI)</span>
                            <span>{formatCurrency(result.monthlyPayment)}</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-sm pt-2 border-t">
                          <div>
                            <p className="text-xs opacity-70">Loan Amount</p>
                            <p className="font-semibold">{formatCurrency(result.maxLoanAmount)}</p>
                          </div>
                          <div>
                            <p className="text-xs opacity-70">LTV Ratio</p>
                            <p className="font-semibold">{result.loanToValueRatio.toFixed(1)}%</p>
                          </div>
                          <div>
                            <p className="text-xs opacity-70">Front-End Ratio</p>
                            <p className="font-semibold">{result.frontEndRatio.toFixed(1)}%</p>
                          </div>
                          <div>
                            <p className="text-xs opacity-70">Back-End Ratio</p>
                            <p className="font-semibold">{result.backEndRatio.toFixed(1)}%</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-4">
              {/* 28/36 Rule Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Calculator className="h-4 w-4 text-green-600" />
                    The 28/36 Rule
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 p-2 rounded-lg bg-blue-50">
                      <div className="w-12 h-8 rounded bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-sm">
                        28%
                      </div>
                      <div className="text-sm">
                        <p className="font-medium text-blue-700">Front-End Ratio</p>
                        <p className="text-xs text-muted-foreground">Housing costs to income</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 p-2 rounded-lg bg-purple-50">
                      <div className="w-12 h-8 rounded bg-purple-100 flex items-center justify-center text-purple-700 font-bold text-sm">
                        36%
                      </div>
                      <div className="text-sm">
                        <p className="font-medium text-purple-700">Back-End Ratio</p>
                        <p className="text-xs text-muted-foreground">Total debt to income</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Affordability Categories Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Building className="h-4 w-4 text-green-600" />
                    Affordability Categories
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <span className="font-medium">Conservative:</span>
                      <span className="text-muted-foreground">
                        {"<"}20% / {"<"}28%
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                      <span className="font-medium">Comfortable:</span>
                      <span className="text-muted-foreground">20-28% / 28-36%</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <span className="font-medium">Stretched:</span>
                      <span className="text-muted-foreground">28-33% / 36-43%</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <span className="font-medium">Risky:</span>
                      <span className="text-muted-foreground">
                        {">"}33% / {">"}43%
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* PITI Breakdown Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-green-600" />
                    Monthly Payment (PITI)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="font-medium">P</span>
                      <span className="text-muted-foreground">Principal</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">I</span>
                      <span className="text-muted-foreground">Interest</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">T</span>
                      <span className="text-muted-foreground">Property Taxes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">I</span>
                      <span className="text-muted-foreground">Insurance</span>
                    </div>
                    <div className="border-t pt-2 text-xs text-muted-foreground">
                      PMI is added if down payment is less than 20%
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="grid gap-4 mt-6 sm:grid-cols-2">
            <Card className="shadow-md border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Info className="h-4 w-4 text-blue-600" />
                  What is Home Affordability?
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>
                  Home affordability calculations help determine how much house you can reasonably purchase based on
                  your income, debts, and available down payment. Lenders use debt-to-income ratios to assess your
                  ability to make monthly payments while maintaining financial stability.
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="h-4 w-4 text-purple-600" />
                  How to Use This Calculator
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <ol className="list-decimal list-inside space-y-1">
                  <li>Enter your gross income (before taxes)</li>
                  <li>Add your monthly debt payments</li>
                  <li>Specify your down payment amount or percentage</li>
                  <li>Enter the current mortgage interest rate</li>
                  <li>Select your preferred loan term</li>
                  <li>Optionally adjust property tax and insurance estimates</li>
                </ol>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  Tips for Home Buying
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <ul className="list-disc list-inside space-y-1">
                  <li>Save at least 20% for down payment to avoid PMI</li>
                  <li>Keep emergency fund separate from down payment</li>
                  <li>Factor in closing costs (2-5% of home price)</li>
                  <li>Consider maintenance costs (1% of home value/year)</li>
                  <li>Get pre-approved before house hunting</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0 bg-amber-50/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2 text-amber-800">
                  <AlertTriangle className="h-4 w-4" />
                  Important Disclaimer
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-amber-900/80">
                <p>
                  Home affordability calculations are estimates and may vary based on local taxes, insurance, and lender
                  requirements. Actual qualification depends on credit score, employment history, and other factors.
                  Consult a mortgage professional for personalized advice.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
