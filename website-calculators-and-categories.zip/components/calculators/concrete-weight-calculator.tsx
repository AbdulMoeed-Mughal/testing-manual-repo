"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Weight, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type InputMode = "volume" | "dimensions"

interface ConcreteWeightResult {
  volume: number
  weightKg: number
  weightTonnes: number
  weightPounds: number
}

export function ConcreteWeightCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [inputMode, setInputMode] = useState<InputMode>("dimensions")
  const [volume, setVolume] = useState("")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [density, setDensity] = useState("2400")
  const [result, setResult] = useState<ConcreteWeightResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateWeight = () => {
    setError("")
    setResult(null)

    const densityNum = Number.parseFloat(density)
    if (isNaN(densityNum) || densityNum <= 0) {
      setError("Please enter a valid density greater than 0")
      return
    }

    let volumeInM3: number

    if (inputMode === "volume") {
      const volumeNum = Number.parseFloat(volume)
      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }
      volumeInM3 = unitSystem === "imperial" ? volumeNum * 0.0283168 : volumeNum
    } else {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)
      const heightNum = Number.parseFloat(height)

      if (isNaN(lengthNum) || lengthNum <= 0 || isNaN(widthNum) || widthNum <= 0 || isNaN(heightNum) || heightNum <= 0) {
        setError("All dimensions must be positive numbers")
        return
      }

      if (unitSystem === "imperial") {
        volumeInM3 = (lengthNum * widthNum * heightNum) * 0.0283168
      } else {
        volumeInM3 = lengthNum * widthNum * heightNum
      }
    }

    const weightKg = volumeInM3 * densityNum
    const weightTonnes = weightKg / 1000
    const weightPounds = weightKg * 2.20462

    setResult({
      volume: volumeInM3,
      weightKg,
      weightTonnes,
      weightPounds,
    })
  }

  const handleReset = () => {
    setVolume("")
    setLength("")
    setWidth("")
    setHeight("")
    setDensity("2400")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Concrete Weight: ${result.weightKg.toFixed(2)} kg (${result.weightTonnes.toFixed(2)} tonnes) - Volume: ${result.volume.toFixed(3)} m³`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Concrete Weight Calculator Result",
          text: `Concrete Weight: ${result.weightKg.toFixed(2)} kg (${result.weightTonnes.toFixed(2)} tonnes)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setVolume("")
    setLength("")
    setWidth("")
    setHeight("")
    setResult(null)
    setError("")
  }

  const toggleInputMode = () => {
    setInputMode((prev) => (prev === "volume" ? "dimensions" : "volume"))
    setVolume("")
    setLength("")
    setWidth("")
    setHeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Weight className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Concrete Weight Calculator</CardTitle>
                    <CardDescription>Calculate concrete weight from volume or dimensions</CardDescription>
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Unit System</span>
                    <button
                      onClick={toggleUnitSystem}
                      className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                    >
                      <span
                        className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                          unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                        }`}
                      />
                      <span
                        className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                          unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        Metric
                      </span>
                      <span
                        className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                          unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        Imperial
                      </span>
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Input Mode</span>
                    <button
                      onClick={toggleInputMode}
                      className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                    >
                      <span
                        className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                          inputMode === "volume" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                        }`}
                      />
                      <span
                        className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                          inputMode === "dimensions" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        Dimensions
                      </span>
                      <span
                        className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                          inputMode === "volume" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        Volume
                      </span>
                    </button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {inputMode === "volume" ? (
                  <div className="space-y-2">
                    <Label htmlFor="volume">
                      Concrete Volume ({unitSystem === "metric" ? "m³" : "ft³"})
                    </Label>
                    <Input
                      id="volume"
                      type="number"
                      placeholder={`Enter volume in ${unitSystem === "metric" ? "cubic meters" : "cubic feet"}`}
                      value={volume}
                      onChange={(e) => setVolume(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                      <Input
                        id="length"
                        type="number"
                        placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                      <Input
                        id="width"
                        type="number"
                        placeholder={`Enter width in ${unitSystem === "metric" ? "meters" : "feet"}`}
                        value={width}
                        onChange={(e) => setWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="height">
                        Height/Thickness ({unitSystem === "metric" ? "m" : "ft"})
                      </Label>
                      <Input
                        id="height"
                        type="number"
                        placeholder={`Enter height/thickness in ${unitSystem === "metric" ? "meters" : "feet"}`}
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="density">Concrete Density (kg/m³)</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder="Enter concrete density"
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="10"
                  />
                  <p className="text-xs text-muted-foreground">Default: 2400 kg/m³ (Normal concrete)</p>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <Button onClick={calculateWeight} className="w-full" size="lg">
                  Calculate Weight
                </Button>

                {result && (
                  <div className="p-5 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Total Weight</p>
                        <p className="text-4xl font-bold text-amber-600">{result.weightKg.toFixed(2)} kg</p>
                        <p className="text-lg font-semibold text-amber-700 mt-1">
                          {result.weightTonnes.toFixed(3)} tonnes
                        </p>
                        <p className="text-sm text-muted-foreground mt-2">
                          {result.weightPounds.toFixed(2)} lbs
                        </p>
                      </div>

                      <div className="pt-3 border-t border-amber-200">
                        <p className="text-sm text-muted-foreground">Concrete Volume</p>
                        <p className="text-lg font-semibold text-amber-700">{result.volume.toFixed(3)} m³</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t border-amber-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Concrete Density Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Normal Concrete</span>
                      <span className="text-sm text-muted-foreground">2400 kg/m³</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Reinforced Concrete</span>
                      <span className="text-sm text-muted-foreground">2500 kg/m³</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Lightweight Concrete</span>
                      <span className="text-sm text-muted-foreground">1800 kg/m³</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Heavy Concrete</span>
                      <span className="text-sm text-muted-foreground">3000 kg/m³</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono">
                    <p className="font-semibold text-foreground">Weight = Volume × Density</p>
                  </div>
                  <p>
                    For dimensions-based calculation:
                    <br />
                    <strong>Volume = Length × Width × Height</strong>
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Concrete Weight?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Concrete weight is a critical factor in structural engineering and construction planning. The weight of
                  concrete depends on its volume and density, which varies based on the mix design and type of aggregates
                  used. Understanding concrete weight is essential for calculating structural loads, planning
                  transportation, and ensuring the safety and stability of construction projects.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Normal concrete typically has a density of 2400 kg/m³, but this can vary significantly. Reinforced
                  concrete with steel reinforcement is denser at approximately 2500 kg/m³, while lightweight concrete made
                  with lightweight aggregates can be as low as 1800 kg/m³. Heavy concrete used for radiation shielding
                  can reach densities of 3000 kg/m³ or more.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Why Calculate Concrete Weight?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating concrete weight is crucial for several aspects of construction. Structural engineers need to
                  know the dead load (permanent weight) of concrete elements to design safe and stable structures. The
                  weight affects foundation design, beam and column sizing, and overall structural integrity.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Transportation planning also depends on accurate weight calculations. Concrete trucks have weight limits,
                  and knowing the total weight helps determine the number of trips needed. For precast concrete elements,
                  weight calculations are essential for crane capacity planning and lifting equipment selection. This
                  ensures safe handling and installation on construction sites.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Concrete density may vary depending on mix design and aggregates used. Results are approximate and should
                  be verified with actual specifications. Different types of aggregates (crushed stone, gravel, lightweight
                  materials) will affect the final density and weight.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Always consult structural engineers for critical load calculations. The actual weight may differ from
                  calculated values due to variations in mix proportions, moisture content, and reinforcement density. For
                  structural design, use conservative estimates and apply appropriate safety factors as required by local
                  building codes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
