"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Building2, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type StructureType = "residential" | "commercial" | "industrial"

interface LoadResult {
  totalDeadLoad: number
  totalLiveLoad: number
  totalFoundationLoad: number
  safeLoad: number
  loadPerArea: number
}

// Typical load values (kN/m² for metric, lb/ft² for imperial)
const typicalLoads = {
  residential: { dead: 3.0, live: 2.0 }, // kN/m²
  commercial: { dead: 4.5, live: 3.5 },
  industrial: { dead: 6.0, live: 5.0 },
}

export function FoundationLoadCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [structureType, setStructureType] = useState<StructureType>("residential")
  const [floors, setFloors] = useState("1")
  const [liveLoad, setLiveLoad] = useState("")
  const [deadLoad, setDeadLoad] = useState("")
  const [area, setArea] = useState("")
  const [safetyFactor, setSafetyFactor] = useState("1.5")
  const [result, setResult] = useState<LoadResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const loadPresets = () => {
    const preset = typicalLoads[structureType]
    if (unitSystem === "metric") {
      setLiveLoad(preset.live.toString())
      setDeadLoad(preset.dead.toString())
    } else {
      setLiveLoad((preset.live * 20.885).toFixed(1)) // kN/m² to lb/ft²
      setDeadLoad((preset.dead * 20.885).toFixed(1))
    }
  }

  const calculateLoad = () => {
    setError("")
    setResult(null)

    const floorsNum = Number.parseInt(floors)
    const liveLoadNum = Number.parseFloat(liveLoad)
    const deadLoadNum = Number.parseFloat(deadLoad)
    const areaNum = Number.parseFloat(area)
    const sfNum = Number.parseFloat(safetyFactor)

    if (isNaN(floorsNum) || floorsNum < 1) {
      setError("Number of floors must be at least 1")
      return
    }
    if (isNaN(liveLoadNum) || liveLoadNum <= 0) {
      setError("Please enter a valid live load greater than 0")
      return
    }
    if (isNaN(deadLoadNum) || deadLoadNum <= 0) {
      setError("Please enter a valid dead load greater than 0")
      return
    }
    if (isNaN(areaNum) || areaNum <= 0) {
      setError("Please enter a valid area greater than 0")
      return
    }
    if (isNaN(sfNum) || sfNum < 1) {
      setError("Safety factor must be at least 1")
      return
    }

    // Convert to metric if needed
    let liveLoadMetric = liveLoadNum
    let deadLoadMetric = deadLoadNum
    let areaMetric = areaNum

    if (unitSystem === "imperial") {
      liveLoadMetric = liveLoadNum / 20.885 // lb/ft² to kN/m²
      deadLoadMetric = deadLoadNum / 20.885
      areaMetric = areaNum / 10.764 // ft² to m²
    }

    // Calculate total loads
    const totalDeadLoad = deadLoadMetric * areaMetric * floorsNum
    const totalLiveLoad = liveLoadMetric * areaMetric * floorsNum
    const totalFoundationLoad = totalDeadLoad + totalLiveLoad
    const safeLoad = totalFoundationLoad * sfNum
    const loadPerArea = totalFoundationLoad / areaMetric

    // Convert back if needed
    let resultDeadLoad = totalDeadLoad
    let resultLiveLoad = totalLiveLoad
    let resultTotalLoad = totalFoundationLoad
    let resultSafeLoad = safeLoad
    let resultLoadPerArea = loadPerArea

    if (unitSystem === "imperial") {
      resultDeadLoad = totalDeadLoad * 224.809 // kN to lb
      resultLiveLoad = totalLiveLoad * 224.809
      resultTotalLoad = totalFoundationLoad * 224.809
      resultSafeLoad = safeLoad * 224.809
      resultLoadPerArea = loadPerArea * 20.885 // kN/m² to lb/ft²
    }

    setResult({
      totalDeadLoad: Math.round(resultDeadLoad * 10) / 10,
      totalLiveLoad: Math.round(resultLiveLoad * 10) / 10,
      totalFoundationLoad: Math.round(resultTotalLoad * 10) / 10,
      safeLoad: Math.round(resultSafeLoad * 10) / 10,
      loadPerArea: Math.round(resultLoadPerArea * 10) / 10,
    })
  }

  const handleReset = () => {
    setFloors("1")
    setLiveLoad("")
    setDeadLoad("")
    setArea("")
    setSafetyFactor("1.5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const forceUnit = unitSystem === "metric" ? "kN" : "lb"
      const pressureUnit = unitSystem === "metric" ? "kN/m²" : "lb/ft²"
      await navigator.clipboard.writeText(
        `Foundation Load: Total = ${result.totalFoundationLoad.toLocaleString()} ${forceUnit}, Safe Load = ${result.safeLoad.toLocaleString()} ${forceUnit}, Load per Area = ${result.loadPerArea} ${pressureUnit}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const forceUnit = unitSystem === "metric" ? "kN" : "lb"
        await navigator.share({
          title: "Foundation Load Result",
          text: `Foundation Load: ${result.totalFoundationLoad.toLocaleString()} ${forceUnit} - Calculated using CalcHub`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLiveLoad("")
    setDeadLoad("")
    setArea("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Foundation Load Calculator</CardTitle>
                    <CardDescription>Calculate total load transmitted to foundation</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Structure Type */}
                <div className="space-y-2">
                  <Label htmlFor="structureType">Structure Type</Label>
                  <Select
                    value={structureType}
                    onValueChange={(value) => setStructureType(value as StructureType)}
                  >
                    <SelectTrigger id="structureType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="residential">Residential</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                      <SelectItem value="industrial">Industrial</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm" onClick={loadPresets} className="w-full">
                    Load Typical Values
                  </Button>
                </div>

                {/* Number of Floors */}
                <div className="space-y-2">
                  <Label htmlFor="floors">Number of Floors</Label>
                  <Input
                    id="floors"
                    type="number"
                    placeholder="Enter number of floors"
                    value={floors}
                    onChange={(e) => setFloors(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Live Load */}
                <div className="space-y-2">
                  <Label htmlFor="liveLoad">
                    Live Load per Floor ({unitSystem === "metric" ? "kN/m²" : "lb/ft²"})
                  </Label>
                  <Input
                    id="liveLoad"
                    type="number"
                    placeholder="Enter live load"
                    value={liveLoad}
                    onChange={(e) => setLiveLoad(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Dead Load */}
                <div className="space-y-2">
                  <Label htmlFor="deadLoad">
                    Dead Load per Floor ({unitSystem === "metric" ? "kN/m²" : "lb/ft²"})
                  </Label>
                  <Input
                    id="deadLoad"
                    type="number"
                    placeholder="Enter dead load"
                    value={deadLoad}
                    onChange={(e) => setDeadLoad(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Area */}
                <div className="space-y-2">
                  <Label htmlFor="area">Foundation Area ({unitSystem === "metric" ? "m²" : "ft²"})</Label>
                  <Input
                    id="area"
                    type="number"
                    placeholder={`Enter area in ${unitSystem === "metric" ? "square meters" : "square feet"}`}
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Safety Factor */}
                <div className="space-y-2">
                  <Label htmlFor="safetyFactor">Safety Factor (Optional)</Label>
                  <Input
                    id="safetyFactor"
                    type="number"
                    placeholder="Default: 1.5"
                    value={safetyFactor}
                    onChange={(e) => setSafetyFactor(e.target.value)}
                    min="1"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLoad} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Load
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Foundation Load</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {result.totalFoundationLoad.toLocaleString()}
                        </p>
                        <p className="text-sm font-medium text-amber-600 mt-1">
                          {unitSystem === "metric" ? "kN" : "lb"}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="text-center p-2 bg-white rounded-lg border border-amber-100">
                          <p className="text-xs text-muted-foreground mb-1">Dead Load</p>
                          <p className="font-semibold text-amber-700">
                            {result.totalDeadLoad.toLocaleString()} {unitSystem === "metric" ? "kN" : "lb"}
                          </p>
                        </div>
                        <div className="text-center p-2 bg-white rounded-lg border border-amber-100">
                          <p className="text-xs text-muted-foreground mb-1">Live Load</p>
                          <p className="font-semibold text-amber-700">
                            {result.totalLiveLoad.toLocaleString()} {unitSystem === "metric" ? "kN" : "lb"}
                          </p>
                        </div>
                        <div className="text-center p-2 bg-white rounded-lg border border-amber-100">
                          <p className="text-xs text-muted-foreground mb-1">Safe Load</p>
                          <p className="font-semibold text-amber-700">
                            {result.safeLoad.toLocaleString()} {unitSystem === "metric" ? "kN" : "lb"}
                          </p>
                        </div>
                        <div className="text-center p-2 bg-white rounded-lg border border-amber-100">
                          <p className="text-xs text-muted-foreground mb-1">Load per Area</p>
                          <p className="font-semibold text-amber-700">
                            {result.loadPerArea} {unitSystem === "metric" ? "kN/m²" : "lb/ft²"}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Load Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-amber-700">Residential</span>
                        <span className="text-xs text-amber-600">Light</span>
                      </div>
                      <p className="text-xs text-amber-600">Dead: 3 kN/m², Live: 2 kN/m²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-amber-700">Commercial</span>
                        <span className="text-xs text-amber-600">Medium</span>
                      </div>
                      <p className="text-xs text-amber-600">Dead: 4.5 kN/m², Live: 3.5 kN/m²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-amber-700">Industrial</span>
                        <span className="text-xs text-amber-600">Heavy</span>
                      </div>
                      <p className="text-xs text-amber-600">Dead: 6 kN/m², Live: 5 kN/m²</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Load Calculations</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground text-xs mb-1">Total Dead Load</p>
                      <p className="font-mono text-xs">Dead Load/Floor × Area × Floors</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground text-xs mb-1">Total Live Load</p>
                      <p className="font-mono text-xs">Live Load/Floor × Area × Floors</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground text-xs mb-1">Foundation Load</p>
                      <p className="font-mono text-xs">Dead Load + Live Load</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground text-xs mb-1">Safe Load</p>
                      <p className="font-mono text-xs">Foundation Load × Safety Factor</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Foundation Load */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Foundation Load?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Foundation load is the total force transmitted from a structure to the supporting soil through its
                  foundation system. It consists of two main components: dead loads (permanent, static loads from the
                  weight of the structure itself including walls, floors, roof, and fixed equipment) and live loads
                  (temporary, variable loads from occupants, furniture, movable equipment, and environmental factors like
                  snow or wind).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Accurate calculation of foundation loads is crucial for safe structural design. Engineers must consider
                  all possible load combinations and apply appropriate safety factors to account for uncertainties in
                  material properties, construction quality, and future usage patterns. The foundation must be designed to
                  distribute these loads safely to the soil without causing excessive settlement, tilting, or bearing
                  capacity failure.
                </p>
              </CardContent>
            </Card>

            {/* Dead Load vs Live Load */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Dead Load and Live Load</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Dead loads are the permanent, unchanging weights that a structure must support throughout its lifetime.
                  These include the weight of structural elements (beams, columns, slabs), architectural finishes
                  (flooring, ceilings, partitions), and fixed mechanical/electrical systems. Dead loads are relatively
                  predictable and can be accurately calculated based on material densities and dimensions. For typical
                  buildings, dead loads range from 3-6 kN/m² depending on construction materials and structural system.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Live loads, in contrast, are temporary and variable loads that change over time. They include people,
                  furniture, vehicles, stored materials, and environmental loads like snow or water accumulation. Building
                  codes specify minimum live load values based on occupancy type – residential floors typically require 2
                  kN/m², office spaces 3 kN/m², and storage or industrial areas can require 5 kN/m² or more. Engineers
                  must design for the maximum expected live load even though average conditions may be much lower.
                </p>
              </CardContent>
            </Card>

            {/* Safety Factors in Foundation Design */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  <CardTitle>Safety Factors in Foundation Design</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Safety factors are multipliers applied to calculated loads to account for uncertainties and provide a
                  margin of safety in structural design. A typical safety factor of 1.5 means the foundation is designed
                  to support 50% more load than the calculated service loads. This accounts for potential variations in
                  material strength, construction defects, unexpected overloading, and deterioration over the structure's
                  lifespan.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Modern building codes use load and resistance factor design (LRFD) methods, which apply different
                  factors to various load types based on their probability of occurrence. Dead loads, being more
                  predictable, typically receive a factor of 1.2, while live loads get 1.6. The combination ensures that
                  structures have adequate safety while avoiding overly conservative (and expensive) designs. Foundation
                  engineers must balance safety requirements with economic considerations while strictly adhering to code
                  requirements.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p className="font-semibold text-amber-900">Important Disclaimer</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Foundation load calculations are estimates based on typical values and simplified assumptions.
                      Actual structural design must comply with local building codes and engineering standards. All
                      foundation designs should be prepared and reviewed by licensed structural and geotechnical
                      engineers who can account for site-specific conditions, soil properties, seismic requirements, and
                      detailed load analysis.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
