"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Flame,
  Info,
  ChevronDown,
  ChevronUp,
  Activity,
  Zap,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityLevel = "sedentary" | "light" | "moderate" | "very" | "extra"
type Formula = "mifflin" | "harris"

interface TDEEResult {
  tdee: number
  bmr: number
  activityMultiplier: number
  activityName: string
  weightLoss: number
  maintenance: number
  weightGain: number
}

const activityLevels: Record<ActivityLevel, { name: string; multiplier: number; description: string }> = {
  sedentary: { name: "Sedentary", multiplier: 1.2, description: "Little or no exercise, desk job" },
  light: { name: "Lightly Active", multiplier: 1.375, description: "Light exercise 1-3 days/week" },
  moderate: { name: "Moderately Active", multiplier: 1.55, description: "Moderate exercise 3-5 days/week" },
  very: { name: "Very Active", multiplier: 1.725, description: "Hard exercise 6-7 days/week" },
  extra: { name: "Extra Active", multiplier: 1.9, description: "Very hard exercise, physical job" },
}

export function TDEECalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")
  const [formula, setFormula] = useState<Formula>("mifflin")
  const [result, setResult] = useState<TDEEResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateTDEE = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const weightNum = Number.parseFloat(weight)

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    let bmr: number

    if (formula === "mifflin") {
      // Mifflin-St Jeor Equation
      if (gender === "male") {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
      } else {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
      }
    } else {
      // Harris-Benedict Equation
      if (gender === "male") {
        bmr = 88.362 + 13.397 * weightInKg + 4.799 * heightInCm - 5.677 * ageNum
      } else {
        bmr = 447.593 + 9.247 * weightInKg + 3.098 * heightInCm - 4.33 * ageNum
      }
    }

    const activity = activityLevels[activityLevel]
    const tdee = Math.round(bmr * activity.multiplier)

    setResult({
      tdee,
      bmr: Math.round(bmr),
      activityMultiplier: activity.multiplier,
      activityName: activity.name,
      weightLoss: Math.round(tdee - 500),
      maintenance: tdee,
      weightGain: Math.round(tdee + 500),
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setActivityLevel("moderate")
    setFormula("mifflin")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My TDEE is ${result.tdee} calories/day (BMR: ${result.bmr} cal, Activity: ${result.activityName})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My TDEE Result",
          text: `I calculated my TDEE using CalcHub! My TDEE is ${result.tdee} calories/day.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Flame className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">TDEE Calculator</CardTitle>
                    <CardDescription>Calculate your Total Daily Energy Expenditure</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setGender("male")}
                      className={`p-3 rounded-lg border-2 text-center font-medium transition-all ${
                        gender === "male"
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-muted bg-background hover:border-muted-foreground/30"
                      }`}
                    >
                      Male
                    </button>
                    <button
                      onClick={() => setGender("female")}
                      className={`p-3 rounded-lg border-2 text-center font-medium transition-all ${
                        gender === "female"
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-muted bg-background hover:border-muted-foreground/30"
                      }`}
                    >
                      Female
                    </button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <Select value={activityLevel} onValueChange={(v) => setActivityLevel(v as ActivityLevel)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(activityLevels).map(([key, value]) => (
                        <SelectItem key={key} value={key}>
                          <div className="flex flex-col">
                            <span>{value.name}</span>
                            <span className="text-xs text-muted-foreground">{value.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* BMR Formula */}
                <div className="space-y-2">
                  <Label>BMR Formula</Label>
                  <Select value={formula} onValueChange={(v) => setFormula(v as Formula)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select formula" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mifflin">Mifflin-St Jeor (Recommended)</SelectItem>
                      <SelectItem value="harris">Harris-Benedict</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTDEE} className="w-full" size="lg">
                  Calculate TDEE
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your TDEE</p>
                      <p className="text-5xl font-bold text-orange-600 mb-2">{result.tdee.toLocaleString()}</p>
                      <p className="text-lg font-semibold text-orange-600">calories/day</p>
                    </div>

                    {/* Calorie Goals */}
                    <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                      <div className="p-2 rounded-lg bg-green-100 border border-green-200">
                        <p className="text-xs text-green-700">Weight Loss</p>
                        <p className="font-bold text-green-700">{result.weightLoss.toLocaleString()}</p>
                      </div>
                      <div className="p-2 rounded-lg bg-blue-100 border border-blue-200">
                        <p className="text-xs text-blue-700">Maintain</p>
                        <p className="font-bold text-blue-700">{result.maintenance.toLocaleString()}</p>
                      </div>
                      <div className="p-2 rounded-lg bg-purple-100 border border-purple-200">
                        <p className="text-xs text-purple-700">Weight Gain</p>
                        <p className="font-bold text-purple-700">{result.weightGain.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-3 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-orange-200 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">BMR (Basal Metabolic Rate)</span>
                          <span className="font-medium">{result.bmr.toLocaleString()} cal/day</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Activity Level</span>
                          <span className="font-medium">{result.activityName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Activity Multiplier</span>
                          <span className="font-medium">×{result.activityMultiplier}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Formula</span>
                          <span className="font-medium">
                            {formula === "mifflin" ? "Mifflin-St Jeor" : "Harris-Benedict"}
                          </span>
                        </div>
                        <div className="mt-2 p-2 bg-orange-100 rounded text-xs">
                          <strong>Calculation:</strong> {result.bmr} × {result.activityMultiplier} = {result.tdee}{" "}
                          cal/day
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Activity Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(activityLevels).map(([key, value]) => (
                      <div
                        key={key}
                        className={`flex items-center justify-between p-3 rounded-lg border ${
                          activityLevel === key ? "bg-orange-50 border-orange-200" : "bg-muted/50 border-muted"
                        }`}
                      >
                        <div>
                          <span className="font-medium">{value.name}</span>
                          <p className="text-xs text-muted-foreground">{value.description}</p>
                        </div>
                        <span className="text-sm font-mono">×{value.multiplier}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">TDEE Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">TDEE = BMR × Activity Multiplier</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-medium text-foreground">Mifflin-St Jeor BMR:</p>
                    <p className="text-xs">Male: (10 × weight) + (6.25 × height) − (5 × age) + 5</p>
                    <p className="text-xs">Female: (10 × weight) + (6.25 × height) − (5 × age) − 161</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is TDEE?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Total Daily Energy Expenditure (TDEE) represents the total number of calories your body burns in a
                  single day. It accounts for your Basal Metabolic Rate (BMR) — the energy needed to maintain basic
                  bodily functions at rest — plus the additional calories burned through physical activity, digestion,
                  and other daily activities. Understanding your TDEE is fundamental to managing your weight
                  effectively.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Your TDEE is composed of several components: BMR (60-70% of total expenditure), the thermic effect of
                  food (about 10%), non-exercise activity thermogenesis (NEAT), and exercise activity thermogenesis. By
                  knowing your TDEE, you can make informed decisions about calorie intake for weight loss, maintenance,
                  or muscle gain.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use Your TDEE</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Weight Loss</h4>
                    <p className="text-green-700 text-sm">
                      Eat 500 calories below your TDEE to lose approximately 1 pound (0.45 kg) per week. A moderate
                      deficit of 300-500 calories is sustainable for most people.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Maintenance</h4>
                    <p className="text-blue-700 text-sm">
                      Eat at your TDEE to maintain your current weight. This is ideal for body recomposition when
                      combined with strength training.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Weight Gain</h4>
                    <p className="text-purple-700 text-sm">
                      Eat 300-500 calories above your TDEE to gain weight. Combined with resistance training, this
                      supports lean muscle growth.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate TDEE Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2 list-disc pl-5">
                  <li>
                    <strong>Be honest about activity level:</strong> Most people overestimate their activity. Start with
                    a lower level and adjust based on results.
                  </li>
                  <li>
                    <strong>Track and adjust:</strong> Use your TDEE as a starting point, then adjust based on actual
                    weight changes over 2-4 weeks.
                  </li>
                  <li>
                    <strong>Account for NEAT:</strong> Non-exercise activity (walking, fidgeting) varies greatly and can
                    significantly impact TDEE.
                  </li>
                  <li>
                    <strong>Recalculate periodically:</strong> As your weight and activity level change, recalculate
                    your TDEE every 4-6 weeks.
                  </li>
                  <li>
                    <strong>Consider individual variation:</strong> Metabolic rates can vary by 10-15% between
                    individuals of similar size and activity level.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> TDEE calculations are estimates based on standard formulas and may vary
                  depending on individual metabolism, body composition, and lifestyle factors. Results should be used as
                  a starting point and adjusted based on actual progress. Consult a healthcare professional or
                  registered dietitian for personalized nutrition guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
