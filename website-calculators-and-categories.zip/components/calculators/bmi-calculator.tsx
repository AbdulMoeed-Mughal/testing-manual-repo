"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Scale, Info, AlertTriangle, Heart, Activity } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface BMIResult {
  value: number
  category: string
  color: string
  bgColor: string
}

export function BMICalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [result, setResult] = useState<BMIResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateBMI = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInMeters: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInMeters = heightCmNum / 100
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInMeters = totalInches * 0.0254
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    const bmi = weightInKg / (heightInMeters * heightInMeters)
    const roundedBMI = Math.round(bmi * 10) / 10

    let category: string
    let color: string
    let bgColor: string

    if (roundedBMI < 18.5) {
      category = "Underweight"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (roundedBMI < 25) {
      category = "Normal weight"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (roundedBMI < 30) {
      category = "Overweight"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Obese"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({ value: roundedBMI, category, color, bgColor })
  }

  const handleReset = () => {
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`My BMI is ${result.value} (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My BMI Result",
          text: `I calculated my BMI using CalcHub! My BMI is ${result.value} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">BMI Calculator</CardTitle>
                    <CardDescription>Calculate your Body Mass Index</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBMI} className="w-full" size="lg">
                  Calculate BMI
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your BMI</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.value}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BMI Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Underweight</span>
                      <span className="text-sm text-blue-600">{"< 18.5"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Normal weight</span>
                      <span className="text-sm text-green-600">18.5 – 24.9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Overweight</span>
                      <span className="text-sm text-yellow-600">25 – 29.9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Obese</span>
                      <span className="text-sm text-red-600">≥ 30</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BMI Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">BMI = Weight (kg) ÷ Height² (m²)</p>
                  </div>
                  <p>
                    For imperial units, the formula becomes:{" "}
                    <strong>BMI = (Weight in lbs × 703) ÷ Height² (inches²)</strong>
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is BMI */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Body Mass Index (BMI)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Body Mass Index, commonly known as BMI, is a numerical value derived from an individual's weight and
                  height. It was developed in the early 19th century by Belgian mathematician Adolphe Quetelet and has
                  since become one of the most widely used screening tools for categorizing individuals based on their
                  body weight relative to their height. The BMI provides a simple, inexpensive, and non-invasive method
                  to assess whether a person has a healthy body weight for their height.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Healthcare professionals, fitness experts, and public health organizations around the world use BMI as
                  an initial screening tool to identify potential weight-related health issues. While it doesn't
                  directly measure body fat percentage, research has shown that BMI correlates reasonably well with more
                  direct measures of body fat, such as underwater weighing and dual-energy X-ray absorptiometry (DEXA)
                  scans, making it a practical tool for population-level health assessments.
                </p>
              </CardContent>
            </Card>

            {/* How BMI is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How is BMI Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The BMI calculation is straightforward and uses a simple mathematical formula. In the metric system,
                  you divide your weight in kilograms by the square of your height in meters. For example, if you weigh
                  70 kilograms and are 1.75 meters tall, your BMI would be calculated as: 70 ÷ (1.75 × 1.75) = 22.9.
                  This places you in the "normal weight" category according to standard BMI classifications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For those using imperial measurements (pounds and inches), the formula is slightly modified. You
                  multiply your weight in pounds by 703, then divide by the square of your height in inches. So if you
                  weigh 154 pounds and are 69 inches tall, the calculation would be: (154 × 703) ÷ (69 × 69) = 22.7.
                  Both methods yield the same BMI value, allowing for universal comparison regardless of the measurement
                  system used.
                </p>
              </CardContent>
            </Card>

            {/* Understanding BMI Categories */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding BMI Categories</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The World Health Organization (WHO) has established standard BMI categories that are used globally to
                  classify weight status. These categories help healthcare providers quickly assess potential health
                  risks associated with being underweight, overweight, or obese. Understanding where you fall on this
                  scale can be the first step toward making informed decisions about your health.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Underweight (BMI below 18.5)</h4>
                    <p className="text-blue-700 text-sm">
                      A BMI under 18.5 indicates that you may be underweight. This can be associated with nutritional
                      deficiencies, weakened immune function, osteoporosis, and other health concerns. If you fall into
                      this category, consulting with a healthcare provider or nutritionist can help identify underlying
                      causes and develop a healthy weight gain strategy.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Normal Weight (BMI 18.5 to 24.9)</h4>
                    <p className="text-green-700 text-sm">
                      A BMI between 18.5 and 24.9 is considered healthy and indicates a good balance between weight and
                      height. People in this range generally have a lower risk of weight-related health problems.
                      However, maintaining this healthy weight requires ongoing attention to diet, physical activity,
                      and overall lifestyle choices.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Overweight (BMI 25 to 29.9)</h4>
                    <p className="text-yellow-700 text-sm">
                      A BMI of 25 to 29.9 places you in the overweight category. This may increase your risk for
                      conditions such as type 2 diabetes, high blood pressure, heart disease, and certain cancers.
                      Lifestyle modifications including improved diet and increased physical activity can help move
                      toward a healthier weight range.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Obese (BMI 30 and above)</h4>
                    <p className="text-red-700 text-sm">
                      A BMI of 30 or higher indicates obesity, which significantly increases the risk of serious health
                      conditions including heart disease, stroke, type 2 diabetes, sleep apnea, and certain types of
                      cancer. Medical professionals often recommend comprehensive weight management programs that may
                      include dietary changes, exercise, behavioral therapy, and in some cases, medication or surgery.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations of BMI</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While BMI is a useful screening tool, it has several important limitations that should be considered
                  when interpreting your results. BMI does not distinguish between weight from muscle and weight from
                  fat. This means that athletes or individuals with high muscle mass may be classified as overweight or
                  obese despite having low body fat percentages and excellent health.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Additionally, BMI doesn't account for factors such as age, sex, ethnicity, and body composition. For
                  example, women typically have more body fat than men at the same BMI, and older adults tend to have
                  more body fat than younger adults. Some ethnic groups, particularly those of Asian descent, may have
                  higher health risks at lower BMI levels. The distribution of body fat is also important—abdominal fat
                  (visceral fat) poses greater health risks than fat stored in other areas of the body, but BMI doesn't
                  measure fat distribution.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For pregnant women, children, and adolescents, standard BMI categories don't apply. Children's BMI is
                  assessed using age and sex-specific percentile charts, while pregnant women should consult with their
                  healthcare providers about appropriate weight gain during pregnancy. Despite these limitations, BMI
                  remains a valuable starting point for health assessments when used alongside other measurements and
                  clinical evaluations.
                </p>
              </CardContent>
            </Card>

            {/* Health Tips */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  <CardTitle>Tips for Maintaining a Healthy BMI</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Achieving and maintaining a healthy BMI involves a balanced approach to nutrition and physical
                  activity. Focus on consuming a variety of nutrient-dense foods including fruits, vegetables, whole
                  grains, lean proteins, and healthy fats. Portion control is essential—even healthy foods can
                  contribute to weight gain when consumed in excess. Stay hydrated by drinking plenty of water, and
                  limit sugary beverages and processed foods.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Regular physical activity is equally important. The World Health Organization recommends at least 150
                  minutes of moderate-intensity aerobic activity or 75 minutes of vigorous-intensity activity per week,
                  along with muscle-strengthening activities on two or more days per week. Find activities you
                  enjoy—whether it's walking, swimming, cycling, dancing, or playing sports—to make exercise a
                  sustainable part of your lifestyle.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Beyond diet and exercise, other lifestyle factors play a role in weight management. Getting adequate
                  sleep (7-9 hours for most adults), managing stress, and avoiding excessive alcohol consumption all
                  contribute to maintaining a healthy weight. Remember that sustainable changes take time—aim for
                  gradual improvements rather than drastic short-term measures. If you're concerned about your BMI or
                  overall health, consult with a healthcare professional who can provide personalized guidance based on
                  your individual circumstances.
                </p>
              </CardContent>
            </Card>
          </div>
          {/* End of content section */}
        </div>
      </main>

      <Footer />
    </div>
  )
}
