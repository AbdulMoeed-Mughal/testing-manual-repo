"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, AlertTriangle, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type InputMode = "center-axes" | "general-form"
type Orientation = "horizontal" | "vertical"

interface HyperbolaResult {
  standardForm: string
  generalForm: string
  center: { h: number; k: number }
  transverseAxis: number
  conjugateAxis: number
  c: number
  foci: { point1: string; point2: string }
  vertices: { point1: string; point2: string }
  coVertices: { point1: string; point2: string }
  asymptote1: string
  asymptote2: string
  eccentricity: number
  orientation: Orientation
  latusRectum: number
}

export function HyperbolaCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("center-axes")
  const [orientation, setOrientation] = useState<Orientation>("horizontal")
  const [centerH, setCenterH] = useState("")
  const [centerK, setCenterK] = useState("")
  const [axisA, setAxisA] = useState("")
  const [axisB, setAxisB] = useState("")
  // General form: Ax² + Bxy + Cy² + Dx + Ey + F = 0
  const [coeffA, setCoeffA] = useState("")
  const [coeffC, setCoeffC] = useState("")
  const [coeffD, setCoeffD] = useState("")
  const [coeffE, setCoeffE] = useState("")
  const [coeffF, setCoeffF] = useState("")
  const [result, setResult] = useState<HyperbolaResult | null>(null)
  const [showSteps, setShowSteps] = useState(false)
  const [steps, setSteps] = useState<string[]>([])
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatNumber = (num: number): string => {
    if (Number.isInteger(num)) return num.toString()
    return num.toFixed(4).replace(/\.?0+$/, "")
  }

  const formatCoord = (x: number, y: number): string => {
    return `(${formatNumber(x)}, ${formatNumber(y)})`
  }

  const calculateFromCenterAxes = () => {
    const h = Number.parseFloat(centerH) || 0
    const k = Number.parseFloat(centerK) || 0
    const a = Number.parseFloat(axisA)
    const b = Number.parseFloat(axisB)

    if (isNaN(a) || a <= 0) {
      setError("Transverse axis (a) must be a positive number")
      return
    }
    if (isNaN(b) || b <= 0) {
      setError("Conjugate axis (b) must be a positive number")
      return
    }

    const calcSteps: string[] = []
    calcSteps.push(`Given: Center (h, k) = (${h}, ${k}), a = ${a}, b = ${b}, Orientation: ${orientation}`)

    // Calculate c = √(a² + b²)
    const c = Math.sqrt(a * a + b * b)
    calcSteps.push(`Calculate c = √(a² + b²) = √(${a}² + ${b}²) = √${formatNumber(a * a + b * b)} = ${formatNumber(c)}`)

    // Standard form
    let standardForm: string
    let foci: { point1: string; point2: string }
    let vertices: { point1: string; point2: string }
    let coVertices: { point1: string; point2: string }
    let asymptote1: string
    let asymptote2: string

    const hStr = h === 0 ? "x" : h > 0 ? `(x - ${h})` : `(x + ${Math.abs(h)})`
    const kStr = k === 0 ? "y" : k > 0 ? `(y - ${k})` : `(y + ${Math.abs(k)})`

    if (orientation === "horizontal") {
      standardForm = `${hStr}²/${a * a} - ${kStr}²/${b * b} = 1`
      calcSteps.push(`Standard form (horizontal): ${hStr}²/${a * a} - ${kStr}²/${b * b} = 1`)

      foci = {
        point1: formatCoord(h - c, k),
        point2: formatCoord(h + c, k),
      }
      calcSteps.push(`Foci: (h ± c, k) = (${h} ± ${formatNumber(c)}, ${k}) = ${foci.point1} and ${foci.point2}`)

      vertices = {
        point1: formatCoord(h - a, k),
        point2: formatCoord(h + a, k),
      }
      calcSteps.push(`Vertices: (h ± a, k) = (${h} ± ${a}, ${k}) = ${vertices.point1} and ${vertices.point2}`)

      coVertices = {
        point1: formatCoord(h, k - b),
        point2: formatCoord(h, k + b),
      }
      calcSteps.push(`Co-vertices: (h, k ± b) = (${h}, ${k} ± ${b}) = ${coVertices.point1} and ${coVertices.point2}`)

      const slope = b / a
      asymptote1 = k === 0 ? `y = ${formatNumber(slope)}(x - ${h})` : `y - ${k} = ${formatNumber(slope)}(x - ${h})`
      asymptote2 = k === 0 ? `y = -${formatNumber(slope)}(x - ${h})` : `y - ${k} = -${formatNumber(slope)}(x - ${h})`
      if (h === 0 && k === 0) {
        asymptote1 = `y = ${formatNumber(slope)}x`
        asymptote2 = `y = -${formatNumber(slope)}x`
      }
      calcSteps.push(`Asymptotes: y - k = ±(b/a)(x - h) → ${asymptote1} and ${asymptote2}`)
    } else {
      standardForm = `${kStr}²/${a * a} - ${hStr}²/${b * b} = 1`
      calcSteps.push(`Standard form (vertical): ${kStr}²/${a * a} - ${hStr}²/${b * b} = 1`)

      foci = {
        point1: formatCoord(h, k - c),
        point2: formatCoord(h, k + c),
      }
      calcSteps.push(`Foci: (h, k ± c) = (${h}, ${k} ± ${formatNumber(c)}) = ${foci.point1} and ${foci.point2}`)

      vertices = {
        point1: formatCoord(h, k - a),
        point2: formatCoord(h, k + a),
      }
      calcSteps.push(`Vertices: (h, k ± a) = (${h}, ${k} ± ${a}) = ${vertices.point1} and ${vertices.point2}`)

      coVertices = {
        point1: formatCoord(h - b, k),
        point2: formatCoord(h + b, k),
      }
      calcSteps.push(`Co-vertices: (h ± b, k) = (${h} ± ${b}, ${k}) = ${coVertices.point1} and ${coVertices.point2}`)

      const slope = a / b
      asymptote1 = k === 0 ? `y = ${formatNumber(slope)}(x - ${h})` : `y - ${k} = ${formatNumber(slope)}(x - ${h})`
      asymptote2 = k === 0 ? `y = -${formatNumber(slope)}(x - ${h})` : `y - ${k} = -${formatNumber(slope)}(x - ${h})`
      if (h === 0 && k === 0) {
        asymptote1 = `y = ${formatNumber(slope)}x`
        asymptote2 = `y = -${formatNumber(slope)}x`
      }
      calcSteps.push(`Asymptotes: y - k = ±(a/b)(x - h) → ${asymptote1} and ${asymptote2}`)
    }

    // General form: Ax² + Cy² + Dx + Ey + F = 0
    let generalForm: string
    const a2 = a * a
    const b2 = b * b

    if (orientation === "horizontal") {
      // (x-h)²/a² - (y-k)²/b² = 1
      // b²(x-h)² - a²(y-k)² = a²b²
      // b²x² - 2b²hx + b²h² - a²y² + 2a²ky - a²k² = a²b²
      const A = b2
      const C = -a2
      const D = -2 * b2 * h
      const E = 2 * a2 * k
      const F = b2 * h * h - a2 * k * k - a2 * b2
      generalForm = `${formatNumber(A)}x² + ${formatNumber(C)}y² + ${formatNumber(D)}x + ${formatNumber(E)}y + ${formatNumber(F)} = 0`
    } else {
      // (y-k)²/a² - (x-h)²/b² = 1
      // b²(y-k)² - a²(x-h)² = a²b²
      const A = -a2
      const C = b2
      const D = 2 * a2 * h
      const E = -2 * b2 * k
      const F = -a2 * h * h + b2 * k * k - a2 * b2
      generalForm = `${formatNumber(A)}x² + ${formatNumber(C)}y² + ${formatNumber(D)}x + ${formatNumber(E)}y + ${formatNumber(F)} = 0`
    }
    calcSteps.push(`General form: ${generalForm}`)

    // Eccentricity
    const eccentricity = c / a
    calcSteps.push(`Eccentricity: e = c/a = ${formatNumber(c)}/${a} = ${formatNumber(eccentricity)}`)

    // Latus rectum
    const latusRectum = (2 * b * b) / a
    calcSteps.push(`Latus Rectum: 2b²/a = 2(${b})²/${a} = ${formatNumber(latusRectum)}`)

    setSteps(calcSteps)
    setResult({
      standardForm,
      generalForm,
      center: { h, k },
      transverseAxis: a,
      conjugateAxis: b,
      c,
      foci,
      vertices,
      coVertices,
      asymptote1,
      asymptote2,
      eccentricity,
      orientation,
      latusRectum,
    })
  }

  const calculateFromGeneralForm = () => {
    const A = Number.parseFloat(coeffA)
    const C = Number.parseFloat(coeffC)
    const D = Number.parseFloat(coeffD) || 0
    const E = Number.parseFloat(coeffE) || 0
    const F = Number.parseFloat(coeffF) || 0

    if (isNaN(A) || isNaN(C)) {
      setError("Coefficients A and C are required")
      return
    }

    // For a hyperbola, A and C must have opposite signs
    if (A * C >= 0) {
      setError("For a hyperbola, coefficients A and C must have opposite signs")
      return
    }

    const calcSteps: string[] = []
    calcSteps.push(`Given: ${A}x² + ${C}y² + ${D}x + ${E}y + ${F} = 0`)

    // Complete the square
    // Ax² + Dx + Cy² + Ey + F = 0
    // A(x² + D/A x) + C(y² + E/C y) + F = 0
    // A(x + D/2A)² - D²/4A + C(y + E/2C)² - E²/4C + F = 0

    const h = -D / (2 * A)
    const k = -E / (2 * C)
    calcSteps.push(`Complete the square:`)
    calcSteps.push(`h = -D/(2A) = -${D}/(2×${A}) = ${formatNumber(h)}`)
    calcSteps.push(`k = -E/(2C) = -${E}/(2×${C}) = ${formatNumber(k)}`)

    const constTerm = -F + (D * D) / (4 * A) + (E * E) / (4 * C)
    calcSteps.push(`Constant term: -F + D²/4A + E²/4C = ${formatNumber(constTerm)}`)

    if (Math.abs(constTerm) < 1e-10) {
      setError("Invalid hyperbola: degenerate case")
      return
    }

    // A(x-h)² + C(y-k)² = constTerm
    // Divide by constTerm: (x-h)²/(constTerm/A) + (y-k)²/(constTerm/C) = 1
    const term1 = constTerm / A
    const term2 = constTerm / C

    let detectedOrientation: Orientation
    let a: number, b: number

    if (term1 > 0 && term2 < 0) {
      // Horizontal hyperbola
      detectedOrientation = "horizontal"
      a = Math.sqrt(term1)
      b = Math.sqrt(-term2)
      calcSteps.push(`Horizontal hyperbola: a² = ${formatNumber(term1)}, b² = ${formatNumber(-term2)}`)
    } else if (term1 < 0 && term2 > 0) {
      // Vertical hyperbola
      detectedOrientation = "vertical"
      a = Math.sqrt(term2)
      b = Math.sqrt(-term1)
      calcSteps.push(`Vertical hyperbola: a² = ${formatNumber(term2)}, b² = ${formatNumber(-term1)}`)
    } else {
      setError("Invalid hyperbola parameters")
      return
    }

    calcSteps.push(`a = ${formatNumber(a)}, b = ${formatNumber(b)}`)

    // Now calculate using the same logic as center-axes mode
    const c = Math.sqrt(a * a + b * b)
    calcSteps.push(`c = √(a² + b²) = ${formatNumber(c)}`)

    const hStr = h === 0 ? "x" : h > 0 ? `(x - ${formatNumber(h)})` : `(x + ${formatNumber(Math.abs(h))})`
    const kStr = k === 0 ? "y" : k > 0 ? `(y - ${formatNumber(k)})` : `(y + ${formatNumber(Math.abs(k))})`

    let standardForm: string
    let foci: { point1: string; point2: string }
    let vertices: { point1: string; point2: string }
    let coVertices: { point1: string; point2: string }
    let asymptote1: string
    let asymptote2: string

    if (detectedOrientation === "horizontal") {
      standardForm = `${hStr}²/${formatNumber(a * a)} - ${kStr}²/${formatNumber(b * b)} = 1`
      foci = { point1: formatCoord(h - c, k), point2: formatCoord(h + c, k) }
      vertices = { point1: formatCoord(h - a, k), point2: formatCoord(h + a, k) }
      coVertices = { point1: formatCoord(h, k - b), point2: formatCoord(h, k + b) }
      const slope = b / a
      asymptote1 =
        h === 0 && k === 0
          ? `y = ${formatNumber(slope)}x`
          : `y - ${formatNumber(k)} = ${formatNumber(slope)}(x - ${formatNumber(h)})`
      asymptote2 =
        h === 0 && k === 0
          ? `y = -${formatNumber(slope)}x`
          : `y - ${formatNumber(k)} = -${formatNumber(slope)}(x - ${formatNumber(h)})`
    } else {
      standardForm = `${kStr}²/${formatNumber(a * a)} - ${hStr}²/${formatNumber(b * b)} = 1`
      foci = { point1: formatCoord(h, k - c), point2: formatCoord(h, k + c) }
      vertices = { point1: formatCoord(h, k - a), point2: formatCoord(h, k + a) }
      coVertices = { point1: formatCoord(h - b, k), point2: formatCoord(h + b, k) }
      const slope = a / b
      asymptote1 =
        h === 0 && k === 0
          ? `y = ${formatNumber(slope)}x`
          : `y - ${formatNumber(k)} = ${formatNumber(slope)}(x - ${formatNumber(h)})`
      asymptote2 =
        h === 0 && k === 0
          ? `y = -${formatNumber(slope)}x`
          : `y - ${formatNumber(k)} = -${formatNumber(slope)}(x - ${formatNumber(h)})`
    }

    calcSteps.push(`Standard form: ${standardForm}`)
    calcSteps.push(`Foci: ${foci.point1} and ${foci.point2}`)
    calcSteps.push(`Vertices: ${vertices.point1} and ${vertices.point2}`)
    calcSteps.push(`Asymptotes: ${asymptote1} and ${asymptote2}`)

    const eccentricity = c / a
    calcSteps.push(`Eccentricity: e = c/a = ${formatNumber(eccentricity)}`)

    const latusRectum = (2 * b * b) / a
    calcSteps.push(`Latus Rectum: 2b²/a = ${formatNumber(latusRectum)}`)

    const generalForm = `${formatNumber(A)}x² + ${formatNumber(C)}y² + ${formatNumber(D)}x + ${formatNumber(E)}y + ${formatNumber(F)} = 0`

    setSteps(calcSteps)
    setResult({
      standardForm,
      generalForm,
      center: { h, k },
      transverseAxis: a,
      conjugateAxis: b,
      c,
      foci,
      vertices,
      coVertices,
      asymptote1,
      asymptote2,
      eccentricity,
      orientation: detectedOrientation,
      latusRectum,
    })
  }

  const calculate = () => {
    setError("")
    setResult(null)
    setSteps([])

    if (inputMode === "center-axes") {
      calculateFromCenterAxes()
    } else {
      calculateFromGeneralForm()
    }
  }

  const handleReset = () => {
    setCenterH("")
    setCenterK("")
    setAxisA("")
    setAxisB("")
    setCoeffA("")
    setCoeffC("")
    setCoeffD("")
    setCoeffE("")
    setCoeffF("")
    setResult(null)
    setSteps([])
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Hyperbola Calculator Result:
Standard Form: ${result.standardForm}
General Form: ${result.generalForm}
Center: (${result.center.h}, ${result.center.k})
Transverse Axis (a): ${result.transverseAxis}
Conjugate Axis (b): ${result.conjugateAxis}
c: ${formatNumber(result.c)}
Foci: ${result.foci.point1} and ${result.foci.point2}
Vertices: ${result.vertices.point1} and ${result.vertices.point2}
Co-Vertices: ${result.coVertices.point1} and ${result.coVertices.point2}
Asymptotes: ${result.asymptote1} and ${result.asymptote2}
Eccentricity: ${formatNumber(result.eccentricity)}
Latus Rectum: ${formatNumber(result.latusRectum)}
Orientation: ${result.orientation}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Hyperbola Calculator Result",
          text: `Hyperbola: ${result.standardForm}\nCenter: (${result.center.h}, ${result.center.k})\nFoci: ${result.foci.point1} and ${result.foci.point2}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M3 12c0-4 4-8 9-8s9 4 9 8-4 8-9 8-9-4-9-8z" />
                      <path d="M12 4v16" strokeDasharray="2 2" />
                    </svg>
                  </div>
                  <div>
                    <CardTitle className="text-xl">Hyperbola Calculator</CardTitle>
                    <CardDescription>Calculate hyperbola properties and equations</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <Select value={inputMode} onValueChange={(v) => setInputMode(v as InputMode)}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="center-axes">Center + Axes</SelectItem>
                      <SelectItem value="general-form">General Form</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {inputMode === "center-axes" ? (
                  <>
                    {/* Center */}
                    <div className="space-y-2">
                      <Label>Center (h, k)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          type="number"
                          placeholder="h (x-coordinate)"
                          value={centerH}
                          onChange={(e) => setCenterH(e.target.value)}
                        />
                        <Input
                          type="number"
                          placeholder="k (y-coordinate)"
                          value={centerK}
                          onChange={(e) => setCenterK(e.target.value)}
                        />
                      </div>
                    </div>

                    {/* Axes */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="axisA">Transverse Axis (a)</Label>
                        <Input
                          id="axisA"
                          type="number"
                          placeholder="Enter a"
                          value={axisA}
                          onChange={(e) => setAxisA(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="axisB">Conjugate Axis (b)</Label>
                        <Input
                          id="axisB"
                          type="number"
                          placeholder="Enter b"
                          value={axisB}
                          onChange={(e) => setAxisB(e.target.value)}
                          min="0"
                          step="any"
                        />
                      </div>
                    </div>

                    {/* Orientation */}
                    <div className="space-y-2">
                      <Label>Orientation</Label>
                      <Select value={orientation} onValueChange={(v) => setOrientation(v as Orientation)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="horizontal">Horizontal (opens left/right)</SelectItem>
                          <SelectItem value="vertical">Vertical (opens up/down)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                ) : (
                  <>
                    {/* General Form: Ax² + Cy² + Dx + Ey + F = 0 */}
                    <div className="p-3 bg-muted rounded-lg text-center text-sm font-mono mb-2">
                      Ax² + Cy² + Dx + Ey + F = 0
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="coeffA">A (x² coefficient)</Label>
                        <Input
                          id="coeffA"
                          type="number"
                          placeholder="A"
                          value={coeffA}
                          onChange={(e) => setCoeffA(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="coeffC">C (y² coefficient)</Label>
                        <Input
                          id="coeffC"
                          type="number"
                          placeholder="C"
                          value={coeffC}
                          onChange={(e) => setCoeffC(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="coeffD">D (x coefficient)</Label>
                        <Input
                          id="coeffD"
                          type="number"
                          placeholder="D"
                          value={coeffD}
                          onChange={(e) => setCoeffD(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="coeffE">E (y coefficient)</Label>
                        <Input
                          id="coeffE"
                          type="number"
                          placeholder="E"
                          value={coeffE}
                          onChange={(e) => setCoeffE(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="coeffF">F (constant)</Label>
                        <Input
                          id="coeffF"
                          type="number"
                          placeholder="F"
                          value={coeffF}
                          onChange={(e) => setCoeffF(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Note: For a hyperbola, A and C must have opposite signs.
                    </p>
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Hyperbola
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300 space-y-4">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Standard Form</p>
                      <p className="text-lg font-bold text-blue-600 font-mono break-all">{result.standardForm}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Center</p>
                        <p className="font-semibold">
                          ({result.center.h}, {result.center.k})
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Orientation</p>
                        <p className="font-semibold capitalize">{result.orientation}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Transverse (a)</p>
                        <p className="font-semibold">{formatNumber(result.transverseAxis)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Conjugate (b)</p>
                        <p className="font-semibold">{formatNumber(result.conjugateAxis)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">c</p>
                        <p className="font-semibold">{formatNumber(result.c)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Eccentricity</p>
                        <p className="font-semibold">{formatNumber(result.eccentricity)}</p>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Foci</p>
                        <p className="font-semibold">
                          {result.foci.point1} and {result.foci.point2}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Vertices</p>
                        <p className="font-semibold">
                          {result.vertices.point1} and {result.vertices.point2}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Co-Vertices</p>
                        <p className="font-semibold">
                          {result.coVertices.point1} and {result.coVertices.point2}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Asymptotes</p>
                        <p className="font-semibold font-mono text-xs">{result.asymptote1}</p>
                        <p className="font-semibold font-mono text-xs">{result.asymptote2}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-muted-foreground">Latus Rectum</p>
                        <p className="font-semibold">{formatNumber(result.latusRectum)}</p>
                      </div>
                    </div>

                    {/* Step-by-step toggle */}
                    {steps.length > 0 && (
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="flex items-center justify-between w-full p-2 bg-white rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors"
                      >
                        <span>Step-by-Step Solution</span>
                        {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                    )}

                    {showSteps && steps.length > 0 && (
                      <div className="p-3 bg-white rounded-lg space-y-2 text-sm">
                        {steps.map((step, index) => (
                          <div key={index} className="flex gap-2">
                            <span className="text-blue-600 font-semibold">{index + 1}.</span>
                            <span className="font-mono text-xs">{step}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Hyperbola Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-1">Horizontal Hyperbola</p>
                    <p className="font-mono text-xs">(x−h)²/a² − (y−k)²/b² = 1</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-1">Vertical Hyperbola</p>
                    <p className="font-mono text-xs">(y−k)²/a² − (x−h)²/b² = 1</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-1">Distance to Foci</p>
                    <p className="font-mono text-xs">c = √(a² + b²)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm mb-1">Eccentricity</p>
                    <p className="font-mono text-xs">e = c/a (always {">"} 1)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Properties</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5" />
                    <p>
                      <strong>Center (h, k)</strong>: The midpoint between the two branches
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5" />
                    <p>
                      <strong>Transverse axis (a)</strong>: Distance from center to each vertex
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5" />
                    <p>
                      <strong>Conjugate axis (b)</strong>: Determines the shape of the hyperbola
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5" />
                    <p>
                      <strong>Foci</strong>: Two fixed points; the difference of distances from any point to the foci is
                      constant (2a)
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5" />
                    <p>
                      <strong>Asymptotes</strong>: Lines that the hyperbola approaches but never touches
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Hyperbola?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A hyperbola is a type of conic section formed when a plane intersects both nappes (cones) of a double
                  cone. It consists of two separate, mirror-image curves called branches. Unlike an ellipse, where the
                  sum of distances to two foci is constant, a hyperbola is defined as the set of all points where the
                  absolute difference of distances to two fixed points (foci) is constant and equals 2a.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Hyperbolas have many real-world applications including the paths of comets, the shape of cooling
                  towers, navigation systems (LORAN), and the behavior of certain optical and radio wave systems. The
                  distinctive asymptotic behavior makes hyperbolas useful in modeling phenomena that approach but never
                  reach certain limits.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Hyperbola calculations follow standard mathematical formulas. Results depend on correct input values
                  and axis configuration. This calculator is intended for educational purposes and should be verified
                  for critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
