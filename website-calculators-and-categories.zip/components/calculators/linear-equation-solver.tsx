"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Calculator, Info, Plus, Trash2, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type SolveMode = "single" | "system"
type SolutionMethod = "substitution" | "elimination" | "matrix"
type SolutionType = "unique" | "infinite" | "none"

interface SingleEquationResult {
  variable: string
  value: number
  steps: string[]
}

interface SystemResult {
  type: SolutionType
  solutions: { variable: string; value: number }[]
  steps: string[]
  matrixForm?: string[][]
  rrefForm?: string[][]
}

export function LinearEquationSolver() {
  const [mode, setMode] = useState<SolveMode>("single")
  const [singleEquation, setSingleEquation] = useState("")
  const [equations, setEquations] = useState<string[]>(["", ""])
  const [method, setMethod] = useState<SolutionMethod>("elimination")
  const [showSteps, setShowSteps] = useState(true)
  const [singleResult, setSingleResult] = useState<SingleEquationResult | null>(null)
  const [systemResult, setSystemResult] = useState<SystemResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(true)

  // Parse single equation like "2x + 5 = 15"
  const parseSingleEquation = (eq: string): { a: number; b: number; variable: string } | null => {
    try {
      const cleanEq = eq.replace(/\s+/g, "").toLowerCase()
      const parts = cleanEq.split("=")
      if (parts.length !== 2) return null

      let variable = "x"
      const match = cleanEq.match(/[a-z]/i)
      if (match) variable = match[0]

      // Parse left side: ax + b
      let leftA = 0,
        leftB = 0
      const leftPart = parts[0]

      // Extract coefficient of variable
      const varRegex = new RegExp(`([+-]?\\d*\\.?\\d*)${variable}`, "i")
      const varMatch = leftPart.match(varRegex)
      if (varMatch) {
        const coef = varMatch[1]
        leftA = coef === "" || coef === "+" ? 1 : coef === "-" ? -1 : Number.parseFloat(coef)
      }

      // Extract constants
      const withoutVar = leftPart.replace(varRegex, "")
      const constMatches = withoutVar.match(/[+-]?\d+\.?\d*/g)
      if (constMatches) {
        leftB = constMatches.reduce((sum, n) => sum + Number.parseFloat(n), 0)
      }

      // Parse right side
      const rightPart = parts[1]
      let rightA = 0,
        rightB = 0

      const rightVarMatch = rightPart.match(varRegex)
      if (rightVarMatch) {
        const coef = rightVarMatch[1]
        rightA = coef === "" || coef === "+" ? 1 : coef === "-" ? -1 : Number.parseFloat(coef)
      }

      const rightWithoutVar = rightPart.replace(varRegex, "")
      const rightConstMatches = rightWithoutVar.match(/[+-]?\d+\.?\d*/g)
      if (rightConstMatches) {
        rightB = rightConstMatches.reduce((sum, n) => sum + Number.parseFloat(n), 0)
      }
      if (rightPart && !rightVarMatch && !rightConstMatches) {
        rightB = Number.parseFloat(rightPart) || 0
      }

      // ax + b = cx + d => (a-c)x = d - b
      const a = leftA - rightA
      const b = rightB - leftB

      return { a, b, variable }
    } catch {
      return null
    }
  }

  // Solve single linear equation
  const solveSingleEquation = () => {
    setError("")
    setSingleResult(null)

    if (!singleEquation.trim()) {
      setError("Please enter an equation")
      return
    }

    const parsed = parseSingleEquation(singleEquation)
    if (!parsed) {
      setError("Invalid equation format. Use format like: 2x + 5 = 15")
      return
    }

    const { a, b, variable } = parsed

    if (a === 0) {
      if (b === 0) {
        setError("Infinite solutions: The equation is always true")
      } else {
        setError("No solution: The equation is never true")
      }
      return
    }

    const value = Math.round((b / a) * 10000) / 10000
    const steps = [
      `Original equation: ${singleEquation}`,
      `Rearranged to standard form: ${a}${variable} = ${b}`,
      `Divide both sides by ${a}:`,
      `${variable} = ${b} / ${a}`,
      `${variable} = ${value}`,
    ]

    setSingleResult({ variable, value, steps })
  }

  // Parse system equation like "2x + 3y = 10"
  const parseSystemEquation = (
    eq: string,
    variables: string[],
  ): { coefficients: number[]; constant: number } | null => {
    try {
      const cleanEq = eq.replace(/\s+/g, "").toLowerCase()
      const parts = cleanEq.split("=")
      if (parts.length !== 2) return null

      const coefficients: number[] = []
      const leftPart = parts[0]
      const rightPart = parts[1]

      for (const variable of variables) {
        const regex = new RegExp(`([+-]?\\d*\\.?\\d*)${variable}`, "i")
        const match = leftPart.match(regex)
        if (match) {
          const coef = match[1]
          coefficients.push(coef === "" || coef === "+" ? 1 : coef === "-" ? -1 : Number.parseFloat(coef))
        } else {
          coefficients.push(0)
        }
      }

      const constant = Number.parseFloat(rightPart) || 0

      return { coefficients, constant }
    } catch {
      return null
    }
  }

  // Solve system using elimination method
  const solveSystemElimination = (eqs: string[]): SystemResult => {
    const variables = ["x", "y"]
    if (eqs.length > 2) variables.push("z")
    if (eqs.length > 3) variables.push("w")

    const parsed = eqs.map((eq) => parseSystemEquation(eq, variables))
    if (parsed.some((p) => p === null)) {
      return { type: "none", solutions: [], steps: ["Error: Invalid equation format"] }
    }

    const steps: string[] = []
    steps.push("Using Elimination Method:")
    steps.push("")

    // Build augmented matrix
    const matrix: number[][] = parsed.map((p, i) => {
      steps.push(`Equation ${i + 1}: ${eqs[i]}`)
      return [...p!.coefficients, p!.constant]
    })
    steps.push("")

    // Gaussian elimination
    const n = variables.length
    const m = matrix.length

    for (let col = 0; col < n && col < m; col++) {
      // Find pivot
      let maxRow = col
      for (let row = col + 1; row < m; row++) {
        if (Math.abs(matrix[row][col]) > Math.abs(matrix[maxRow][col])) {
          maxRow = row
        }
      }

      // Swap rows
      if (maxRow !== col) {
        ;[matrix[col], matrix[maxRow]] = [matrix[maxRow], matrix[col]]
        steps.push(`Swap row ${col + 1} and row ${maxRow + 1}`)
      }

      // Check for zero pivot
      if (Math.abs(matrix[col][col]) < 1e-10) continue

      // Eliminate
      for (let row = col + 1; row < m; row++) {
        const factor = matrix[row][col] / matrix[col][col]
        if (factor !== 0) {
          steps.push(`R${row + 1} = R${row + 1} - ${factor.toFixed(2)} × R${col + 1}`)
          for (let j = col; j <= n; j++) {
            matrix[row][j] -= factor * matrix[col][j]
          }
        }
      }
    }

    // Back substitution
    const solutions: number[] = new Array(n).fill(0)
    steps.push("")
    steps.push("Back Substitution:")

    for (let i = n - 1; i >= 0; i--) {
      if (i < m && Math.abs(matrix[i][i]) > 1e-10) {
        let sum = matrix[i][n]
        for (let j = i + 1; j < n; j++) {
          sum -= matrix[i][j] * solutions[j]
        }
        solutions[i] = sum / matrix[i][i]
        steps.push(`${variables[i]} = ${solutions[i].toFixed(4)}`)
      }
    }

    // Check for no solution or infinite solutions
    let hasNoSolution = false
    let hasInfiniteSolutions = false

    for (let i = 0; i < m; i++) {
      const allZeroCoef = matrix[i].slice(0, n).every((v) => Math.abs(v) < 1e-10)
      const constant = matrix[i][n]

      if (allZeroCoef && Math.abs(constant) > 1e-10) {
        hasNoSolution = true
        break
      }
      if (allZeroCoef && Math.abs(constant) < 1e-10) {
        hasInfiniteSolutions = true
      }
    }

    if (hasNoSolution) {
      return { type: "none", solutions: [], steps: [...steps, "", "Result: No solution (inconsistent system)"] }
    }

    if (hasInfiniteSolutions) {
      return { type: "infinite", solutions: [], steps: [...steps, "", "Result: Infinite solutions (dependent system)"] }
    }

    return {
      type: "unique",
      solutions: variables.map((v, i) => ({ variable: v, value: Math.round(solutions[i] * 10000) / 10000 })),
      steps,
    }
  }

  // Solve system of equations
  const solveSystem = () => {
    setError("")
    setSystemResult(null)

    const validEquations = equations.filter((eq) => eq.trim())
    if (validEquations.length < 2) {
      setError("Please enter at least 2 equations")
      return
    }

    const result = solveSystemElimination(validEquations)
    setSystemResult(result)
  }

  const handleCalculate = () => {
    if (mode === "single") {
      solveSingleEquation()
    } else {
      solveSystem()
    }
  }

  const handleReset = () => {
    setSingleEquation("")
    setEquations(["", ""])
    setSingleResult(null)
    setSystemResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
  }

  const handleCopy = async () => {
    let text = ""
    if (mode === "single" && singleResult) {
      text = `${singleResult.variable} = ${singleResult.value}`
    } else if (systemResult && systemResult.type === "unique") {
      text = systemResult.solutions.map((s) => `${s.variable} = ${s.value}`).join(", ")
    }
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleCopyLatex = async () => {
    let latex = ""
    if (mode === "single" && singleResult) {
      latex = `${singleResult.variable} = ${singleResult.value}`
    } else if (systemResult && systemResult.type === "unique") {
      latex = systemResult.solutions.map((s) => `${s.variable} = ${s.value}`).join(", \\quad ")
    }
    await navigator.clipboard.writeText(latex)
    setCopiedLatex(true)
    setTimeout(() => setCopiedLatex(false), 2000)
  }

  const addEquation = () => {
    if (equations.length < 4) {
      setEquations([...equations, ""])
    }
  }

  const removeEquation = (index: number) => {
    if (equations.length > 2) {
      setEquations(equations.filter((_, i) => i !== index))
    }
  }

  const updateEquation = (index: number, value: string) => {
    const newEquations = [...equations]
    newEquations[index] = value
    setEquations(newEquations)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Linear Equation Solver</CardTitle>
                    <CardDescription>Solve linear equations step by step</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Equation Type</span>
                  <button
                    onClick={() => {
                      setMode(mode === "single" ? "system" : "single")
                      handleReset()
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "system" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "single" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Single
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "system" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      System
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {mode === "single" ? (
                  /* Single Equation Input */
                  <div className="space-y-2">
                    <Label htmlFor="equation">Enter Equation</Label>
                    <Input
                      id="equation"
                      type="text"
                      placeholder="e.g., 2x + 5 = 15"
                      value={singleEquation}
                      onChange={(e) => setSingleEquation(e.target.value)}
                      className="font-mono text-lg"
                    />
                    <p className="text-xs text-muted-foreground">Format: ax + b = c (supports any single variable)</p>
                  </div>
                ) : (
                  /* System of Equations Input */
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>System of Equations</Label>
                      <Select value={method} onValueChange={(v) => setMethod(v as SolutionMethod)}>
                        <SelectTrigger className="w-36">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="elimination">Elimination</SelectItem>
                          <SelectItem value="substitution">Substitution</SelectItem>
                          <SelectItem value="matrix">Matrix (RREF)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {equations.map((eq, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Input
                          type="text"
                          placeholder={`Equation ${index + 1}: e.g., 2x + 3y = 10`}
                          value={eq}
                          onChange={(e) => updateEquation(index, e.target.value)}
                          className="font-mono"
                        />
                        {equations.length > 2 && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeEquation(index)}
                            className="shrink-0"
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        )}
                      </div>
                    ))}

                    {equations.length < 4 && (
                      <Button variant="outline" size="sm" onClick={addEquation} className="w-full bg-transparent">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Equation
                      </Button>
                    )}

                    <p className="text-xs text-muted-foreground">
                      Format: ax + by = c for 2 variables, ax + by + cz = d for 3 variables
                    </p>
                  </div>
                )}

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between py-2">
                  <Label htmlFor="showSteps" className="cursor-pointer">
                    Show Step-by-Step Solution
                  </Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={handleCalculate} className="w-full" size="lg">
                  Solve Equation
                </Button>

                {/* Single Equation Result */}
                {singleResult && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Solution</p>
                      <p className="text-4xl font-bold text-green-600 mb-2 font-mono">
                        {singleResult.variable} = {singleResult.value}
                      </p>
                      <p className="text-sm text-green-700">Unique Solution</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" className="w-full justify-between">
                            Step-by-Step Solution
                            {stepsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-2 p-3 bg-white rounded-lg border space-y-1">
                            {singleResult.steps.map((step, i) => (
                              <p key={i} className="text-sm font-mono text-muted-foreground">
                                {step}
                              </p>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}
                  </div>
                )}

                {/* System Result */}
                {systemResult && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      systemResult.type === "unique"
                        ? "bg-green-50 border-green-200"
                        : systemResult.type === "infinite"
                          ? "bg-yellow-50 border-yellow-200"
                          : "bg-red-50 border-red-200"
                    }`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Solution</p>
                      {systemResult.type === "unique" ? (
                        <>
                          <div className="space-y-1 mb-2">
                            {systemResult.solutions.map((sol, i) => (
                              <p key={i} className="text-3xl font-bold text-green-600 font-mono">
                                {sol.variable} = {sol.value}
                              </p>
                            ))}
                          </div>
                          <p className="text-sm text-green-700">Unique Solution</p>
                        </>
                      ) : systemResult.type === "infinite" ? (
                        <>
                          <p className="text-2xl font-bold text-yellow-600 mb-2">Infinite Solutions</p>
                          <p className="text-sm text-yellow-700">
                            The system has infinitely many solutions (dependent equations)
                          </p>
                        </>
                      ) : (
                        <>
                          <p className="text-2xl font-bold text-red-600 mb-2">No Solution</p>
                          <p className="text-sm text-red-700">The system is inconsistent (contradictory equations)</p>
                        </>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      {systemResult.type === "unique" && (
                        <>
                          <Button variant="outline" size="sm" onClick={handleCopy}>
                            {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                            {copied ? "Copied" : "Copy"}
                          </Button>
                          <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                            {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                            {copiedLatex ? "Copied" : "LaTeX"}
                          </Button>
                        </>
                      )}
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" className="w-full justify-between">
                            Step-by-Step Solution
                            {stepsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-2 p-3 bg-white rounded-lg border space-y-1 max-h-60 overflow-y-auto">
                            {systemResult.steps.map((step, i) => (
                              <p key={i} className="text-sm font-mono text-muted-foreground">
                                {step || "\u00A0"}
                              </p>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Solution Methods</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700 block">Substitution</span>
                      <span className="text-xs text-blue-600">
                        Solve one equation for a variable, substitute into others
                      </span>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700 block">Elimination</span>
                      <span className="text-xs text-green-600">Add/subtract equations to eliminate variables</span>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700 block">Matrix (Gaussian)</span>
                      <span className="text-xs text-purple-600">Convert to augmented matrix, reduce to RREF</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Linear Equation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Single: ax + b = c</p>
                    <p className="text-xs">Solution: x = (c - b) / a</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">System (2×2):</p>
                    <p className="text-xs">a₁x + b₁y = c₁</p>
                    <p className="text-xs">a₂x + b₂y = c₂</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Solution Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Unique</span>
                      <span className="text-xs text-green-600">One solution</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Infinite</span>
                      <span className="text-xs text-yellow-600">Dependent system</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">None</span>
                      <span className="text-xs text-red-600">Inconsistent system</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Linear Equation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A linear equation is an algebraic equation in which each term is either a constant or the product of a
                  constant and a single variable raised to the first power. Linear equations form straight lines when
                  graphed on a coordinate plane. The general form of a linear equation in one variable is ax + b = c,
                  where a, b, and c are constants and x is the variable.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Systems of linear equations involve two or more equations with two or more variables. The solution to
                  a system is the set of values that satisfy all equations simultaneously. Systems can have exactly one
                  solution (intersecting lines), infinitely many solutions (same line), or no solution (parallel lines).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>For single equations:</strong> Enter your equation in the format "ax + b = c". For example,
                  "2x + 5 = 15" or "3y - 7 = 20". The calculator will isolate the variable and provide the solution with
                  step-by-step explanations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>For systems of equations:</strong> Enter 2-4 equations using variables x, y, z, and w. Each
                  equation should be in the form "ax + by = c". Select your preferred solution method (Elimination,
                  Substitution, or Matrix) and the calculator will find the values that satisfy all equations or
                  identify if the system has infinite or no solutions.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> This linear equation solver provides solutions based on standard
                  algebraic methods. Results depend on the validity and structure of the entered equations. Always
                  verify solutions by substituting back into the original equations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
