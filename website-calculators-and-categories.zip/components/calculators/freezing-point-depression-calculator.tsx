"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Snowflake, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface Solvent {
  name: string
  kf: number
  freezingPoint: number
}

const SOLVENTS: Solvent[] = [
  { name: "Water", kf: 1.86, freezingPoint: 0 },
  { name: "Benzene", kf: 5.12, freezingPoint: 5.5 },
  { name: "Cyclohexane", kf: 20.0, freezingPoint: 6.5 },
  { name: "Acetic Acid", kf: 3.90, freezingPoint: 16.6 },
  { name: "Camphor", kf: 37.7, freezingPoint: 178.8 },
  { name: "Naphthalene", kf: 6.94, freezingPoint: 80.2 },
  { name: "Phenol", kf: 7.40, freezingPoint: 40.9 },
  { name: "Nitrobenzene", kf: 6.87, freezingPoint: 5.7 },
  { name: "t-Butanol", kf: 9.10, freezingPoint: 25.5 },
]

interface Result {
  depression: number
  finalFreezingPoint: number
  molality: number
  vantHoffFactor: number
  kf: number
  pureFreezingPoint: number
}

export function FreezingPointDepressionCalculator() {
  const [solventMode, setSolventMode] = useState<"preset" | "custom">("preset")
  const [selectedSolvent, setSelectedSolvent] = useState("Water")
  const [molality, setMolality] = useState("")
  const [vantHoffFactor, setVantHoffFactor] = useState("1")
  const [customKf, setCustomKf] = useState("")
  const [customFreezingPoint, setCustomFreezingPoint] = useState("")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDepression = () => {
    setError("")
    setResult(null)

    const molalityNum = Number.parseFloat(molality)
    const iNum = Number.parseFloat(vantHoffFactor)

    if (isNaN(molalityNum) || molalityNum <= 0) {
      setError("Please enter a valid molality greater than 0")
      return
    }

    if (isNaN(iNum) || iNum <= 0) {
      setError("Please enter a valid van't Hoff factor greater than 0")
      return
    }

    let kfValue: number
    let pureFreezingPoint: number

    if (solventMode === "preset") {
      const solvent = SOLVENTS.find((s) => s.name === selectedSolvent)
      if (!solvent) {
        setError("Please select a valid solvent")
        return
      }
      kfValue = solvent.kf
      pureFreezingPoint = solvent.freezingPoint
    } else {
      const kfNum = Number.parseFloat(customKf)
      const fpNum = Number.parseFloat(customFreezingPoint)

      if (isNaN(kfNum) || kfNum <= 0) {
        setError("Please enter a valid cryoscopic constant (Kf) greater than 0")
        return
      }

      if (isNaN(fpNum)) {
        setError("Please enter a valid freezing point")
        return
      }

      kfValue = kfNum
      pureFreezingPoint = fpNum
    }

    // Calculate freezing point depression: ΔTf = i × Kf × m
    const depression = iNum * kfValue * molalityNum
    const finalFreezingPoint = pureFreezingPoint - depression

    setResult({
      depression,
      finalFreezingPoint,
      molality: molalityNum,
      vantHoffFactor: iNum,
      kf: kfValue,
      pureFreezingPoint,
    })
  }

  const handleReset = () => {
    setMolality("")
    setVantHoffFactor("1")
    setCustomKf("")
    setCustomFreezingPoint("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Freezing Point Depression: ${result.depression.toFixed(2)}°C\nFinal Freezing Point: ${result.finalFreezingPoint.toFixed(2)}°C`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Freezing Point Depression Result",
          text: `Freezing Point Depression: ${result.depression.toFixed(2)}°C, Final Freezing Point: ${result.finalFreezingPoint.toFixed(2)}°C`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getDepressionCategory = (depression: number): { label: string; color: string; bgColor: string } => {
    if (depression < 1) return { label: "Negligible", color: "text-blue-700", bgColor: "bg-blue-50 border-blue-200" }
    if (depression < 5) return { label: "Small", color: "text-green-700", bgColor: "bg-green-50 border-green-200" }
    if (depression < 20) return { label: "Moderate", color: "text-yellow-700", bgColor: "bg-yellow-50 border-yellow-200" }
    return { label: "Large", color: "text-purple-700", bgColor: "bg-purple-50 border-purple-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Snowflake className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Freezing Point Depression</CardTitle>
                    <CardDescription>Calculate colligative property effects</CardDescription>
                  </div>
                </div>

                {/* Solvent Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Solvent Mode</span>
                  <button
                    onClick={() => setSolventMode((prev) => (prev === "preset" ? "custom" : "preset"))}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-purple-600 shadow-sm transition-transform duration-200 ${
                        solventMode === "custom" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        solventMode === "preset" ? "text-white" : "text-muted-foreground"
                      }`}
                    >
                      Preset
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        solventMode === "custom" ? "text-white" : "text-muted-foreground"
                      }`}
                    >
                      Custom
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Solvent Selection */}
                {solventMode === "preset" ? (
                  <div className="space-y-2">
                    <Label htmlFor="solvent">Solvent</Label>
                    <Select value={selectedSolvent} onValueChange={setSelectedSolvent}>
                      <SelectTrigger id="solvent">
                        <SelectValue placeholder="Select solvent" />
                      </SelectTrigger>
                      <SelectContent>
                        {SOLVENTS.map((solvent) => (
                          <SelectItem key={solvent.name} value={solvent.name}>
                            {solvent.name} (K<sub>f</sub> = {solvent.kf} °C·kg/mol)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="customKf">
                        Cryoscopic Constant (K<sub>f</sub>)
                      </Label>
                      <Input
                        id="customKf"
                        type="number"
                        placeholder="Enter Kf in °C·kg/mol"
                        value={customKf}
                        onChange={(e) => setCustomKf(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customFreezingPoint">Pure Solvent Freezing Point (°C)</Label>
                      <Input
                        id="customFreezingPoint"
                        type="number"
                        placeholder="Enter freezing point in °C"
                        value={customFreezingPoint}
                        onChange={(e) => setCustomFreezingPoint(e.target.value)}
                        step="0.1"
                      />
                    </div>
                  </>
                )}

                {/* Molality Input */}
                <div className="space-y-2">
                  <Label htmlFor="molality">Molality (mol/kg)</Label>
                  <Input
                    id="molality"
                    type="number"
                    placeholder="Enter molality"
                    value={molality}
                    onChange={(e) => setMolality(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Van't Hoff Factor */}
                <div className="space-y-2">
                  <Label htmlFor="vantHoff">
                    Van't Hoff Factor (<em>i</em>)
                  </Label>
                  <Input
                    id="vantHoff"
                    type="number"
                    placeholder="Enter van't Hoff factor"
                    value={vantHoffFactor}
                    onChange={(e) => setVantHoffFactor(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Non-electrolyte = 1, NaCl ≈ 2, CaCl₂ ≈ 3</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDepression} className="w-full bg-purple-600 hover:bg-purple-700" size="lg">
                  Calculate Depression
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-3">
                    <div className={`p-4 rounded-xl border-2 ${getDepressionCategory(result.depression).bgColor}`}>
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Freezing Point Depression</p>
                        <p className={`text-4xl font-bold ${getDepressionCategory(result.depression).color} mb-1`}>
                          {result.depression.toFixed(2)}°C
                        </p>
                        <p className={`text-sm font-semibold ${getDepressionCategory(result.depression).color}`}>
                          {getDepressionCategory(result.depression).label}
                        </p>
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="text-sm text-muted-foreground mb-1">Final Freezing Point</p>
                      <p className="text-3xl font-bold text-purple-700">{result.finalFreezingPoint.toFixed(2)}°C</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              {result && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Step-by-Step Calculation</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold mb-2">Formula:</p>
                      <p className="font-mono">
                        ΔT<sub>f</sub> = <em>i</em> × K<sub>f</sub> × <em>m</em>
                      </p>
                    </div>
                    <div className="space-y-2">
                      <p>
                        <strong>1. Parameters:</strong>
                      </p>
                      <p className="pl-4">
                        • Van't Hoff factor (<em>i</em>): {result.vantHoffFactor}
                      </p>
                      <p className="pl-4">
                        • Cryoscopic constant (K<sub>f</sub>): {result.kf} °C·kg/mol
                      </p>
                      <p className="pl-4">
                        • Molality (<em>m</em>): {result.molality} mol/kg
                      </p>
                    </div>
                    <div className="space-y-2">
                      <p>
                        <strong>2. Calculate depression:</strong>
                      </p>
                      <p className="pl-4 font-mono text-xs">
                        ΔT<sub>f</sub> = {result.vantHoffFactor} × {result.kf} × {result.molality}
                      </p>
                      <p className="pl-4 font-mono text-xs">
                        ΔT<sub>f</sub> = {result.depression.toFixed(2)}°C
                      </p>
                    </div>
                    <div className="space-y-2">
                      <p>
                        <strong>3. Final freezing point:</strong>
                      </p>
                      <p className="pl-4 font-mono text-xs">
                        T<sub>f</sub>(solution) = {result.pureFreezingPoint}°C − {result.depression.toFixed(2)}°C
                      </p>
                      <p className="pl-4 font-mono text-xs">
                        T<sub>f</sub>(solution) = {result.finalFreezingPoint.toFixed(2)}°C
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Solvents</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {SOLVENTS.slice(0, 5).map((solvent) => (
                      <div key={solvent.name} className="flex items-center justify-between p-2 rounded bg-muted">
                        <span className="font-medium">{solvent.name}</span>
                        <span className="text-muted-foreground text-xs">
                          K<sub>f</sub> = {solvent.kf} °C·kg/mol
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Van't Hoff Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <p>
                    <strong>Non-electrolytes:</strong> <em>i</em> = 1
                  </p>
                  <p className="text-muted-foreground text-xs pl-4">Examples: glucose, sucrose, urea</p>
                  <p>
                    <strong>Binary salts:</strong> <em>i</em> ≈ 2
                  </p>
                  <p className="text-muted-foreground text-xs pl-4">Examples: NaCl, KBr, MgSO₄</p>
                  <p>
                    <strong>Ternary salts:</strong> <em>i</em> ≈ 3
                  </p>
                  <p className="text-muted-foreground text-xs pl-4">Examples: CaCl₂, Na₂SO₄</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-purple-600" />
                  <CardTitle>What is Freezing Point Depression?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Freezing point depression is a colligative property that describes the phenomenon where the freezing
                  point of a solvent is lowered when a solute is dissolved in it. This effect depends on the number of
                  solute particles present in the solution, not on the chemical nature of the solute itself. The more
                  solute particles dissolved, the greater the depression in freezing point.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This principle has many practical applications, including antifreeze in car radiators, road salt for
                  de-icing highways, and the production of ice cream. The van't Hoff factor accounts for the dissociation
                  of ionic compounds in solution, where salts like NaCl produce multiple particles per formula unit.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Snowflake className="h-5 w-5 text-purple-600" />
                  <CardTitle>Applications of Freezing Point Depression</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="space-y-3 text-muted-foreground">
                  <li>
                    <strong>Antifreeze Solutions:</strong> Ethylene glycol or propylene glycol is added to water in car
                    radiators to prevent freezing in cold weather and overheating in hot weather.
                  </li>
                  <li>
                    <strong>Road De-icing:</strong> Salt (NaCl) or calcium chloride is spread on roads to lower the
                    freezing point of water, preventing ice formation and melting existing ice.
                  </li>
                  <li>
                    <strong>Ice Cream Production:</strong> Salt is mixed with ice in hand-cranked ice cream makers to
                    lower the temperature below 0°C, allowing the cream mixture to freeze properly.
                  </li>
                  <li>
                    <strong>Molecular Weight Determination:</strong> Cryoscopy is used to determine the molar mass of
                    unknown compounds by measuring the freezing point depression they cause.
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-amber-200 bg-amber-50/50">
              <CardHeader>
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div>
                    <CardTitle className="text-amber-900">Important Disclaimer</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-amber-800 leading-relaxed">
                  Freezing point depression calculations assume ideal dilute solutions. Real systems may show deviations
                  due to solute interactions, non-ideal behavior at higher concentrations, and incomplete dissociation of
                  electrolytes. For accurate results in critical applications, experimental measurements should be
                  performed. This calculator is intended for educational purposes and approximate estimations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
