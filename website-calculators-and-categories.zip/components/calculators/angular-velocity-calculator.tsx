"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, RotateCw, Info, AlertTriangle, Gauge } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type AngleUnit = "radians" | "degrees"

interface AngularVelocityResult {
  omegaRadPerSec: number
  omegaDegPerSec: number
  rpm: number
  angularDisplacement: number
  angularDisplacementDeg: number
}

export function AngularVelocityCalculator() {
  const [angleUnit, setAngleUnit] = useState<AngleUnit>("radians")
  const [initialAngle, setInitialAngle] = useState("")
  const [finalAngle, setFinalAngle] = useState("")
  const [time, setTime] = useState("")
  const [result, setResult] = useState<AngularVelocityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateAngularVelocity = () => {
    setError("")
    setResult(null)

    const theta0 = Number.parseFloat(initialAngle)
    const theta = Number.parseFloat(finalAngle)
    const t = Number.parseFloat(time)

    if (isNaN(theta0)) {
      setError("Please enter a valid initial angle")
      return
    }

    if (isNaN(theta)) {
      setError("Please enter a valid final angle")
      return
    }

    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid time greater than 0")
      return
    }

    // Convert to radians if needed
    let theta0Rad = theta0
    let thetaRad = theta

    if (angleUnit === "degrees") {
      theta0Rad = theta0 * (Math.PI / 180)
      thetaRad = theta * (Math.PI / 180)
    }

    // Calculate angular displacement
    const angularDisplacement = thetaRad - theta0Rad
    const angularDisplacementDeg = angularDisplacement * (180 / Math.PI)

    // Calculate angular velocity (ω = Δθ / t)
    const omegaRadPerSec = angularDisplacement / t
    const omegaDegPerSec = omegaRadPerSec * (180 / Math.PI)
    const rpm = (omegaRadPerSec * 60) / (2 * Math.PI)

    setResult({
      omegaRadPerSec: Math.round(omegaRadPerSec * 10000) / 10000,
      omegaDegPerSec: Math.round(omegaDegPerSec * 10000) / 10000,
      rpm: Math.round(rpm * 10000) / 10000,
      angularDisplacement: Math.round(angularDisplacement * 10000) / 10000,
      angularDisplacementDeg: Math.round(angularDisplacementDeg * 10000) / 10000,
    })
  }

  const handleReset = () => {
    setInitialAngle("")
    setFinalAngle("")
    setTime("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Angular Velocity: ${result.omegaRadPerSec} rad/s (${result.omegaDegPerSec} °/s, ${result.rpm} RPM)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Angular Velocity Result",
          text: `I calculated angular velocity using CalcHub! ω = ${result.omegaRadPerSec} rad/s (${result.omegaDegPerSec} °/s, ${result.rpm} RPM)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleAngleUnit = () => {
    setAngleUnit((prev) => (prev === "radians" ? "degrees" : "radians"))
    setInitialAngle("")
    setFinalAngle("")
    setTime("")
    setResult(null)
    setError("")
  }

  const getResultColor = () => {
    if (!result) return { color: "text-gray-600", bgColor: "bg-gray-50 border-gray-200" }
    const absOmega = Math.abs(result.omegaRadPerSec)
    if (absOmega < 1) {
      return { color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    } else if (absOmega < 10) {
      return { color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    } else if (absOmega < 100) {
      return { color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    } else {
      return { color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    }
  }

  const resultColors = getResultColor()

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <RotateCw className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Angular Velocity Calculator</CardTitle>
                    <CardDescription>Calculate angular velocity from angle change</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Angle Unit</span>
                  <button
                    onClick={toggleAngleUnit}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        angleUnit === "degrees" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        angleUnit === "radians" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Radians
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        angleUnit === "degrees" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Degrees
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Angle Input */}
                <div className="space-y-2">
                  <Label htmlFor="initialAngle">Initial Angle θ₀ ({angleUnit === "radians" ? "rad" : "°"})</Label>
                  <Input
                    id="initialAngle"
                    type="number"
                    placeholder={`Enter initial angle in ${angleUnit}`}
                    value={initialAngle}
                    onChange={(e) => setInitialAngle(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Final Angle Input */}
                <div className="space-y-2">
                  <Label htmlFor="finalAngle">Final Angle θ ({angleUnit === "radians" ? "rad" : "°"})</Label>
                  <Input
                    id="finalAngle"
                    type="number"
                    placeholder={`Enter final angle in ${angleUnit}`}
                    value={finalAngle}
                    onChange={(e) => setFinalAngle(e.target.value)}
                    step="any"
                  />
                </div>

                {/* Time Input */}
                <div className="space-y-2">
                  <Label htmlFor="time">Time Interval (seconds)</Label>
                  <Input
                    id="time"
                    type="number"
                    placeholder="Enter time in seconds"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAngularVelocity} className="w-full" size="lg">
                  Calculate Angular Velocity
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${resultColors.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Angular Velocity (ω)</p>
                      <p className={`text-4xl font-bold ${resultColors.color} mb-1`}>{result.omegaRadPerSec}</p>
                      <p className={`text-lg font-semibold ${resultColors.color}`}>rad/s</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="text-center p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Degrees/sec</p>
                        <p className="font-semibold">{result.omegaDegPerSec} °/s</p>
                      </div>
                      <div className="text-center p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">RPM</p>
                        <p className="font-semibold">{result.rpm}</p>
                      </div>
                    </div>

                    <div className="mt-3 text-center p-2 bg-white/50 rounded-lg">
                      <p className="text-xs text-muted-foreground">Angular Displacement (Δθ)</p>
                      <p className="font-semibold">
                        {result.angularDisplacement} rad ({result.angularDisplacementDeg}°)
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Angular Velocity Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="font-semibold text-foreground">ω = (θ − θ₀) / t</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>ω</strong> = Angular velocity (rad/s)
                    </p>
                    <p>
                      <strong>θ</strong> = Final angle
                    </p>
                    <p>
                      <strong>θ₀</strong> = Initial angle
                    </p>
                    <p>
                      <strong>t</strong> = Time interval (seconds)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">rad/s to °/s</span>
                      <span className="text-sm text-blue-600">× (180/π)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">rad/s to RPM</span>
                      <span className="text-sm text-green-600">× (60/2π)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">1 revolution</span>
                      <span className="text-sm text-purple-600">= 2π rad = 360°</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Earth's Rotation</p>
                      <p className="text-muted-foreground">ω ≈ 7.27 × 10⁻⁵ rad/s</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Clock Second Hand</p>
                      <p className="text-muted-foreground">ω = π/30 rad/s ≈ 0.105 rad/s</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-medium">Car Wheel at 60 mph</p>
                      <p className="text-muted-foreground">ω ≈ 80-90 rad/s</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Angular Velocity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Angular velocity (ω) is a measure of how fast an object rotates or revolves around a fixed axis. It
                  describes the rate of change of the angular position of a rotating body. Unlike linear velocity, which
                  measures how fast an object moves in a straight line, angular velocity measures how quickly an object
                  spins or rotates.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Angular velocity is a vector quantity, meaning it has both magnitude and direction. The direction is
                  determined by the right-hand rule: if you curl your fingers in the direction of rotation, your thumb
                  points in the direction of the angular velocity vector. In most 2D applications, we work with the
                  magnitude only, distinguishing clockwise (negative) from counterclockwise (positive) rotation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Angular Velocity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Angular velocity has numerous applications in physics and engineering. In mechanical systems, it's
                  essential for analyzing rotating machinery like motors, turbines, and gears. The relationship between
                  angular velocity and linear velocity (v = ωr) is crucial for designing everything from car wheels to
                  planetary gear systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In aerospace engineering, understanding angular velocity is critical for spacecraft attitude control
                  and gyroscopic instruments. Athletes and coaches use angular velocity concepts in sports science to
                  optimize throwing motions, gymnastics routines, and diving techniques. Even in everyday life, angular
                  velocity appears in ceiling fans, Ferris wheels, and the Earth's rotation that gives us day and night.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Angular velocity calculations are estimates based on ideal motion. Actual rotation may vary due to
                  friction, external forces, or system constraints. This calculator assumes constant angular velocity
                  (no angular acceleration) during the time interval. For systems with varying angular velocity, more
                  advanced kinematic equations should be used.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
