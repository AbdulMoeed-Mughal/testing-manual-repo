"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, Droplets, Activity } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type AreaInputMode = "direct" | "diameter"
type VelocityUnit = "m/s" | "ft/s" | "cm/s"
type AreaUnit = "m²" | "cm²" | "in²" | "ft²"
type LengthUnit = "m" | "cm" | "mm" | "in" | "ft"
type FlowUnit = "m³/s" | "L/s" | "L/min" | "GPM" | "CFM"
type MassFlowUnit = "kg/s" | "kg/min" | "lb/s" | "lb/min"

interface FlowResult {
  volumetricFlow: number
  massFlow: number | null
  category: string
  color: string
  bgColor: string
}

export function FlowRateCalculator() {
  const [areaInputMode, setAreaInputMode] = useState<AreaInputMode>("diameter")
  const [velocity, setVelocity] = useState("")
  const [velocityUnit, setVelocityUnit] = useState<VelocityUnit>("m/s")
  const [area, setArea] = useState("")
  const [areaUnit, setAreaUnit] = useState<AreaUnit>("m²")
  const [diameter, setDiameter] = useState("")
  const [diameterUnit, setDiameterUnit] = useState<LengthUnit>("m")
  const [density, setDensity] = useState("")
  const [includeMassFlow, setIncludeMassFlow] = useState(false)
  const [flowUnit, setFlowUnit] = useState<FlowUnit>("m³/s")
  const [massFlowUnit, setMassFlowUnit] = useState<MassFlowUnit>("kg/s")
  const [result, setResult] = useState<FlowResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Conversion factors to SI units
  const velocityToMS: Record<VelocityUnit, number> = {
    "m/s": 1,
    "ft/s": 0.3048,
    "cm/s": 0.01,
  }

  const areaToM2: Record<AreaUnit, number> = {
    "m²": 1,
    "cm²": 0.0001,
    "in²": 0.00064516,
    "ft²": 0.092903,
  }

  const lengthToM: Record<LengthUnit, number> = {
    m: 1,
    cm: 0.01,
    mm: 0.001,
    in: 0.0254,
    ft: 0.3048,
  }

  const m3sToFlowUnit: Record<FlowUnit, number> = {
    "m³/s": 1,
    "L/s": 1000,
    "L/min": 60000,
    GPM: 15850.32,
    CFM: 2118.88,
  }

  const kgsToMassFlowUnit: Record<MassFlowUnit, number> = {
    "kg/s": 1,
    "kg/min": 60,
    "lb/s": 2.20462,
    "lb/min": 132.277,
  }

  const calculateFlowRate = () => {
    setError("")
    setResult(null)

    const v = Number.parseFloat(velocity)
    if (isNaN(v) || v <= 0) {
      setError("Please enter a valid velocity greater than 0")
      return
    }

    let areaInM2: number

    if (areaInputMode === "direct") {
      const a = Number.parseFloat(area)
      if (isNaN(a) || a <= 0) {
        setError("Please enter a valid area greater than 0")
        return
      }
      areaInM2 = a * areaToM2[areaUnit]
    } else {
      const d = Number.parseFloat(diameter)
      if (isNaN(d) || d <= 0) {
        setError("Please enter a valid diameter greater than 0")
        return
      }
      const diameterInM = d * lengthToM[diameterUnit]
      areaInM2 = Math.PI * Math.pow(diameterInM / 2, 2)
    }

    const velocityInMS = v * velocityToMS[velocityUnit]

    // Q = v × A (volumetric flow rate in m³/s)
    const Q_m3s = velocityInMS * areaInM2

    let massFlowKgS: number | null = null
    if (includeMassFlow) {
      const rho = Number.parseFloat(density)
      if (isNaN(rho) || rho <= 0) {
        setError("Please enter a valid density greater than 0 for mass flow calculation")
        return
      }
      massFlowKgS = rho * Q_m3s
    }

    // Convert to selected units
    const volumetricFlow = Q_m3s * m3sToFlowUnit[flowUnit]
    const massFlow = massFlowKgS !== null ? massFlowKgS * kgsToMassFlowUnit[massFlowUnit] : null

    // Categorize flow rate (based on typical pipe flow ranges)
    let category: string
    let color: string
    let bgColor: string

    if (Q_m3s < 0.001) {
      category = "Very Low Flow"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (Q_m3s < 0.01) {
      category = "Low Flow"
      color = "text-cyan-600"
      bgColor = "bg-cyan-50 border-cyan-200"
    } else if (Q_m3s < 0.1) {
      category = "Moderate Flow"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (Q_m3s < 1) {
      category = "High Flow"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very High Flow"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({ volumetricFlow, massFlow, category, color, bgColor })
  }

  const handleReset = () => {
    setVelocity("")
    setArea("")
    setDiameter("")
    setDensity("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        result.massFlow !== null
          ? `Volumetric Flow Rate: ${result.volumetricFlow.toExponential(4)} ${flowUnit}, Mass Flow Rate: ${result.massFlow.toExponential(4)} ${massFlowUnit}`
          : `Volumetric Flow Rate: ${result.volumetricFlow.toExponential(4)} ${flowUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleAreaInputMode = () => {
    setAreaInputMode((prev) => (prev === "direct" ? "diameter" : "direct"))
    setArea("")
    setDiameter("")
    setResult(null)
    setError("")
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1000 || Math.abs(num) < 0.001) {
      return num.toExponential(4)
    }
    return num.toFixed(6).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Flow Rate Calculator</CardTitle>
                    <CardDescription>Calculate volumetric and mass flow rates</CardDescription>
                  </div>
                </div>

                {/* Area Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Area Input</span>
                  <button
                    onClick={toggleAreaInputMode}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        areaInputMode === "direct" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        areaInputMode === "diameter" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Diameter
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        areaInputMode === "direct" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Area
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Velocity Input */}
                <div className="space-y-2">
                  <Label htmlFor="velocity">Fluid Velocity (v)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="velocity"
                      type="number"
                      placeholder="Enter velocity"
                      value={velocity}
                      onChange={(e) => setVelocity(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <select
                      value={velocityUnit}
                      onChange={(e) => setVelocityUnit(e.target.value as VelocityUnit)}
                      className="w-24 px-3 py-2 border rounded-md bg-background"
                    >
                      <option value="m/s">m/s</option>
                      <option value="ft/s">ft/s</option>
                      <option value="cm/s">cm/s</option>
                    </select>
                  </div>
                </div>

                {/* Area or Diameter Input */}
                {areaInputMode === "direct" ? (
                  <div className="space-y-2">
                    <Label htmlFor="area">Cross-sectional Area (A)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="area"
                        type="number"
                        placeholder="Enter area"
                        value={area}
                        onChange={(e) => setArea(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <select
                        value={areaUnit}
                        onChange={(e) => setAreaUnit(e.target.value as AreaUnit)}
                        className="w-24 px-3 py-2 border rounded-md bg-background"
                      >
                        <option value="m²">m²</option>
                        <option value="cm²">cm²</option>
                        <option value="in²">in²</option>
                        <option value="ft²">ft²</option>
                      </select>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="diameter">Pipe Diameter (D)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="diameter"
                        type="number"
                        placeholder="Enter diameter"
                        value={diameter}
                        onChange={(e) => setDiameter(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <select
                        value={diameterUnit}
                        onChange={(e) => setDiameterUnit(e.target.value as LengthUnit)}
                        className="w-24 px-3 py-2 border rounded-md bg-background"
                      >
                        <option value="m">m</option>
                        <option value="cm">cm</option>
                        <option value="mm">mm</option>
                        <option value="in">in</option>
                        <option value="ft">ft</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="flowUnit">Volumetric Flow Unit</Label>
                  <select
                    id="flowUnit"
                    value={flowUnit}
                    onChange={(e) => setFlowUnit(e.target.value as FlowUnit)}
                    className="w-full px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="m³/s">m³/s</option>
                    <option value="L/s">L/s</option>
                    <option value="L/min">L/min</option>
                    <option value="GPM">GPM (US)</option>
                    <option value="CFM">CFM</option>
                  </select>
                </div>

                {/* Mass Flow Toggle */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="includeMassFlow"
                    checked={includeMassFlow}
                    onChange={(e) => setIncludeMassFlow(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300"
                  />
                  <Label htmlFor="includeMassFlow" className="text-sm cursor-pointer">
                    Calculate mass flow rate (requires density)
                  </Label>
                </div>

                {/* Density Input (conditional) */}
                {includeMassFlow && (
                  <div className="space-y-2">
                    <Label htmlFor="density">Fluid Density (ρ) in kg/m³</Label>
                    <div className="flex gap-2">
                      <Input
                        id="density"
                        type="number"
                        placeholder="e.g., 1000 for water"
                        value={density}
                        onChange={(e) => setDensity(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <select
                        value={massFlowUnit}
                        onChange={(e) => setMassFlowUnit(e.target.value as MassFlowUnit)}
                        className="w-28 px-3 py-2 border rounded-md bg-background"
                      >
                        <option value="kg/s">kg/s</option>
                        <option value="kg/min">kg/min</option>
                        <option value="lb/s">lb/s</option>
                        <option value="lb/min">lb/min</option>
                      </select>
                    </div>
                    {/* Quick density buttons */}
                    <div className="flex flex-wrap gap-2 pt-1">
                      <span className="text-xs text-muted-foreground">Quick:</span>
                      {[
                        { label: "Water", value: "1000" },
                        { label: "Air", value: "1.225" },
                        { label: "Oil", value: "900" },
                        { label: "Seawater", value: "1025" },
                      ].map((fluid) => (
                        <button
                          key={fluid.label}
                          onClick={() => setDensity(fluid.value)}
                          className="text-xs px-2 py-1 rounded bg-muted hover:bg-muted/80 transition-colors"
                        >
                          {fluid.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFlowRate} className="w-full" size="lg">
                  Calculate Flow Rate
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Volumetric Flow Rate (Q)</p>
                      <p className={`text-3xl font-bold ${result.color} mb-1`}>
                        {formatNumber(result.volumetricFlow)} {flowUnit}
                      </p>
                      {result.massFlow !== null && (
                        <>
                          <p className="text-sm text-muted-foreground mt-3 mb-1">Mass Flow Rate (ṁ)</p>
                          <p className={`text-2xl font-bold ${result.color}`}>
                            {formatNumber(result.massFlow)} {massFlowUnit}
                          </p>
                        </>
                      )}
                      <p className={`text-sm font-medium ${result.color} mt-2`}>{result.category}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setShowSteps(!showSteps)}>
                        {showSteps ? "Hide Steps" : "Show Steps"}
                      </Button>
                    </div>

                    {/* Step-by-step breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p className="font-semibold">Calculation Steps:</p>
                        <p>
                          1. Velocity (v) = {velocity} {velocityUnit}
                        </p>
                        {areaInputMode === "diameter" ? (
                          <>
                            <p>
                              2. Diameter (D) = {diameter} {diameterUnit}
                            </p>
                            <p>
                              3. Area (A) = π × (D/2)² = π × ({diameter}/2)² {diameterUnit}²
                            </p>
                          </>
                        ) : (
                          <p>
                            2. Area (A) = {area} {areaUnit}
                          </p>
                        )}
                        <p>{areaInputMode === "diameter" ? "4" : "3"}. Q = v × A</p>
                        <p className="font-medium">
                          Result: Q = {formatNumber(result.volumetricFlow)} {flowUnit}
                        </p>
                        {result.massFlow !== null && (
                          <>
                            <p className="mt-2">
                              {areaInputMode === "diameter" ? "5" : "4"}. ṁ = ρ × Q = {density} × Q
                            </p>
                            <p className="font-medium">
                              Mass Flow: ṁ = {formatNumber(result.massFlow)} {massFlowUnit}
                            </p>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Flow Rate Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-center mb-2">Volumetric Flow Rate</p>
                    <p className="font-mono text-center text-lg">Q = v × A</p>
                    <p className="text-xs text-muted-foreground text-center mt-1">
                      Q = flow rate, v = velocity, A = cross-sectional area
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-center mb-2">Mass Flow Rate</p>
                    <p className="font-mono text-center text-lg">ṁ = ρ × Q = ρ × v × A</p>
                    <p className="text-xs text-muted-foreground text-center mt-1">
                      ṁ = mass flow rate, ρ = fluid density
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-center mb-2">Circular Pipe Area</p>
                    <p className="font-mono text-center text-lg">A = π × (D/2)²</p>
                    <p className="text-xs text-muted-foreground text-center mt-1">D = pipe diameter</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Flow Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Household faucet</span>
                      <span className="font-mono">~0.1 - 0.2 L/s</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Garden hose</span>
                      <span className="font-mono">~0.3 - 0.6 L/s</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Fire hydrant</span>
                      <span className="font-mono">~15 - 60 L/s</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Industrial pipe</span>
                      <span className="font-mono">~100+ L/s</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Flow Rate?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Flow rate is a fundamental concept in fluid mechanics that quantifies the amount of fluid passing
                  through a given cross-section per unit time. There are two main types: volumetric flow rate (Q), which
                  measures the volume of fluid passing through, and mass flow rate (ṁ), which measures the mass of fluid
                  passing through. Understanding flow rate is essential for designing piping systems, pumps, HVAC
                  systems, and many other engineering applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The continuity equation states that for incompressible flow in a closed system, the mass flow rate
                  must remain constant. This principle is crucial for analyzing fluid systems where the pipe diameter
                  changes, as velocity must adjust to maintain constant flow rate. Engineers use flow rate calculations
                  to size pipes, select pumps, and ensure systems operate efficiently.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Flow Rate Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Flow rate calculations are used across numerous industries and applications. In water supply systems,
                  engineers calculate flow rates to ensure adequate water pressure and volume for residential and
                  commercial buildings. In chemical processing, precise flow rate control is essential for maintaining
                  proper reaction conditions and product quality. HVAC systems rely on airflow calculations to ensure
                  proper heating, cooling, and ventilation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Other applications include hydraulic systems in machinery, fuel delivery systems in vehicles and
                  aircraft, blood flow analysis in medical diagnostics, and irrigation system design in agriculture. The
                  relationship between flow rate, velocity, and cross-sectional area (Q = vA) is one of the most
                  frequently applied equations in engineering practice.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Flow rate calculations are estimates based on ideal conditions. Actual
                  flow may vary due to pipe roughness, turbulence, temperature, and fluid properties. Consult fluid
                  mechanics references for precise analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
