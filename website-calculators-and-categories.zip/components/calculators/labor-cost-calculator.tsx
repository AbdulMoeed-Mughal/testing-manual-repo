"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Users, Info, Calculator, DollarSign } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Currency = "USD" | "INR"
type LaborType = "unskilled" | "skilled" | "supervisor"

interface LaborCostResult {
  basicCost: number
  overtimeCost: number
  totalCost: number
  costPerDay: number
  costPerLaborer: number
}

export function LaborCostCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [laborType, setLaborType] = useState<LaborType>("unskilled")
  const [numberOfLaborers, setNumberOfLaborers] = useState("")
  const [dailyRate, setDailyRate] = useState("")
  const [numberOfDays, setNumberOfDays] = useState("")
  const [overtimeHours, setOvertimeHours] = useState("")
  const [overtimeRate, setOvertimeRate] = useState("")
  const [result, setResult] = useState<LaborCostResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  // Preset average wages
  const presetWages: Record<Currency, Record<LaborType, number>> = {
    USD: {
      unskilled: 80,
      skilled: 150,
      supervisor: 250,
    },
    INR: {
      unskilled: 500,
      skilled: 1000,
      supervisor: 2000,
    },
  }

  const applyPreset = () => {
    setDailyRate(presetWages[currency][laborType].toString())
  }

  const calculateLaborCost = () => {
    setError("")
    setResult(null)

    const laborersNum = Number.parseFloat(numberOfLaborers)
    const rateNum = Number.parseFloat(dailyRate)
    const daysNum = Number.parseFloat(numberOfDays)

    if (isNaN(laborersNum) || laborersNum <= 0) {
      setError("Please enter a valid number of laborers greater than 0")
      return
    }
    if (isNaN(rateNum) || rateNum <= 0) {
      setError("Please enter a valid daily rate greater than 0")
      return
    }
    if (isNaN(daysNum) || daysNum <= 0) {
      setError("Please enter a valid number of days greater than 0")
      return
    }

    const overtimeHoursNum = Number.parseFloat(overtimeHours) || 0
    const overtimeRateNum = Number.parseFloat(overtimeRate) || 0

    if (overtimeHoursNum < 0 || overtimeRateNum < 0) {
      setError("Overtime hours and rate must be non-negative")
      return
    }

    const basicCost = laborersNum * rateNum * daysNum
    const overtimeCost = overtimeHoursNum * overtimeRateNum * laborersNum
    const totalCost = basicCost + overtimeCost
    const costPerDay = totalCost / daysNum
    const costPerLaborer = totalCost / laborersNum

    setResult({
      basicCost,
      overtimeCost,
      totalCost,
      costPerDay,
      costPerLaborer,
    })
  }

  const handleReset = () => {
    setNumberOfLaborers("")
    setDailyRate("")
    setNumberOfDays("")
    setOvertimeHours("")
    setOvertimeRate("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const currencySymbol = currency === "USD" ? "$" : "₹"
      await navigator.clipboard.writeText(
        `Total Labor Cost: ${currencySymbol}${result.totalCost.toLocaleString(undefined, {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const currencySymbol = currency === "USD" ? "$" : "₹"
      try {
        await navigator.share({
          title: "Labor Cost Estimate",
          text: `Labor Cost: ${currencySymbol}${result.totalCost.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const currencySymbol = currency === "USD" ? "$" : "₹"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Users className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Labor Cost Calculator</CardTitle>
                    <CardDescription>Calculate construction labor expenses</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Currency Selection */}
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select value={currency} onValueChange={(value) => setCurrency(value as Currency)}>
                    <SelectTrigger id="currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD ($)</SelectItem>
                      <SelectItem value="INR">INR (₹)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Labor Type */}
                <div className="space-y-2">
                  <Label htmlFor="laborType">Labor Type (Preset Rates)</Label>
                  <Select value={laborType} onValueChange={(value) => setLaborType(value as LaborType)}>
                    <SelectTrigger id="laborType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unskilled">Unskilled Worker</SelectItem>
                      <SelectItem value="skilled">Skilled Worker</SelectItem>
                      <SelectItem value="supervisor">Supervisor</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm" onClick={applyPreset} className="w-full">
                    Apply Preset Rate ({currencySymbol}
                    {presetWages[currency][laborType]}/day)
                  </Button>
                </div>

                {/* Number of Laborers */}
                <div className="space-y-2">
                  <Label htmlFor="laborers">Number of Laborers</Label>
                  <Input
                    id="laborers"
                    type="number"
                    placeholder="Enter number of laborers"
                    value={numberOfLaborers}
                    onChange={(e) => setNumberOfLaborers(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Daily Rate */}
                <div className="space-y-2">
                  <Label htmlFor="dailyRate">
                    Daily Wage Rate per Laborer ({currencySymbol})
                  </Label>
                  <Input
                    id="dailyRate"
                    type="number"
                    placeholder="Enter daily wage rate"
                    value={dailyRate}
                    onChange={(e) => setDailyRate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Number of Days */}
                <div className="space-y-2">
                  <Label htmlFor="days">Number of Workdays</Label>
                  <Input
                    id="days"
                    type="number"
                    placeholder="Enter number of days"
                    value={numberOfDays}
                    onChange={(e) => setNumberOfDays(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Overtime Hours */}
                <div className="space-y-2">
                  <Label htmlFor="overtimeHours">Overtime Hours (Optional)</Label>
                  <Input
                    id="overtimeHours"
                    type="number"
                    placeholder="Total overtime hours"
                    value={overtimeHours}
                    onChange={(e) => setOvertimeHours(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Overtime Rate */}
                <div className="space-y-2">
                  <Label htmlFor="overtimeRate">
                    Overtime Rate per Hour ({currencySymbol}) - Optional
                  </Label>
                  <Input
                    id="overtimeRate"
                    type="number"
                    placeholder="Hourly overtime rate"
                    value={overtimeRate}
                    onChange={(e) => setOvertimeRate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLaborCost} className="w-full" size="lg">
                  Calculate Labor Cost
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Labor Cost</p>
                      <p className="text-4xl font-bold text-amber-600">
                        {currencySymbol}
                        {result.totalCost.toLocaleString(undefined, {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </p>
                    </div>

                    {/* Cost Breakdown */}
                    <div className="space-y-2 mb-4 text-sm">
                      <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                        <span className="text-muted-foreground">Basic Labor Cost:</span>
                        <span className="font-semibold">
                          {currencySymbol}
                          {result.basicCost.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                      {result.overtimeCost > 0 && (
                        <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                          <span className="text-muted-foreground">Overtime Cost:</span>
                          <span className="font-semibold">
                            {currencySymbol}
                            {result.overtimeCost.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </span>
                        </div>
                      )}
                      <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                        <span className="text-muted-foreground">Cost per Day:</span>
                        <span className="font-semibold">
                          {currencySymbol}
                          {result.costPerDay.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-white/50 rounded">
                        <span className="text-muted-foreground">Cost per Laborer:</span>
                        <span className="font-semibold">
                          {currencySymbol}
                          {result.costPerLaborer.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Labor Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-900 mb-1">Unskilled Worker</h4>
                      <p className="text-amber-700">General helpers, manual labor, material handling</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-900 mb-1">Skilled Worker</h4>
                      <p className="text-amber-700">Masons, carpenters, plumbers, electricians, welders</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-900 mb-1">Supervisor</h4>
                      <p className="text-amber-700">Site supervisors, foremen, project coordinators</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cost Factors</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    Labor costs vary based on location, skill level, project complexity, and local market conditions.
                    Urban areas typically have higher rates than rural regions.
                  </p>
                  <p>
                    Overtime rates are usually 1.5x to 2x regular hourly rates. Consider seasonal demand and weather
                    impacts on labor availability and pricing.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Labor Cost */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Construction Labor Cost?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Construction labor cost represents the total wages paid to workers involved in a building project,
                  including unskilled helpers, skilled tradespeople, and supervisory staff. Labor typically accounts for
                  20-40% of total construction costs and varies significantly based on geographic location, skill level
                  requirements, project complexity, and local market conditions. Understanding and accurately estimating
                  labor costs is crucial for project budgeting and financial planning.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Labor costs include not only base wages but also overtime compensation, benefits, insurance, and
                  productivity factors. Different construction trades command different wage rates, with specialized skills
                  like electrical work, plumbing, and HVAC installation typically commanding higher rates than general
                  labor. Project managers must also account for labor productivity, which can be affected by weather,
                  site conditions, material availability, and crew experience levels.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Labor Cost */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Labor Cost</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The basic labor cost calculation multiplies the number of laborers by their daily wage rate and the
                  number of workdays required. For example, if you employ 10 workers at $150 per day for 20 days, the
                  basic labor cost would be 10 × $150 × 20 = $30,000. This provides a straightforward estimate for
                  standard working hours and conditions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For more complex projects, additional factors must be considered. Overtime work, which often occurs to
                  meet deadlines or during weather delays, typically costs 1.5 to 2 times the regular hourly rate.
                  Different labor types command different wages: unskilled workers might earn $80-120/day, skilled
                  tradespeople $150-250/day, and supervisors $250-400/day. Total labor cost includes all these components
                  plus potential benefits, insurance, and contractor markup if using subcontractors.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Common Labor Cost Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      What percentage of construction costs should be labor?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Labor typically represents 20-40% of total construction costs, though this varies by project type.
                      Residential construction often runs 25-35%, while commercial projects may be 30-45%. Labor-intensive
                      projects like custom homes or renovations can exceed 40%, while material-heavy projects like road
                      construction may be lower.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How do regional differences affect labor costs?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Labor costs vary dramatically by region due to local cost of living, union presence, labor supply,
                      and market demand. Urban areas and states with higher costs of living (California, New York,
                      Massachusetts) typically have rates 50-100% higher than rural areas or lower cost-of-living states.
                      International projects can have even wider variations.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      Should I hire contractors or direct labor?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Contractors provide expertise, insurance, warranties, and handle worker management but typically add
                      20-30% markup. Direct hiring offers cost savings but requires you to manage payroll, insurance,
                      workers' compensation, quality control, and assumes liability. For most homeowners and smaller
                      projects, licensed contractors are recommended despite higher costs.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Labor cost estimates are approximate. Actual costs vary by region, skill
                  level, and project conditions. Rates shown are general averages and may not reflect your local market.
                  Always obtain detailed quotes from licensed contractors for accurate pricing.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
