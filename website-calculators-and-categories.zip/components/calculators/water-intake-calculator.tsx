"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Droplets, Info, Activity, Thermometer, Baby } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityLevel = "sedentary" | "light" | "moderate" | "very-active"
type Climate = "cool" | "moderate" | "hot"

interface WaterResult {
  liters: number
  ounces: number
  glasses: number
  baseIntake: number
  activityAdjustment: number
  exerciseAdjustment: number
  climateAdjustment: number
  specialAdjustment: number
}

export function WaterIntakeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("sedentary")
  const [exerciseMinutes, setExerciseMinutes] = useState("")
  const [climate, setClimate] = useState<Climate>("moderate")
  const [isPregnant, setIsPregnant] = useState(false)
  const [isBreastfeeding, setIsBreastfeeding] = useState(false)
  const [result, setResult] = useState<WaterResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateWaterIntake = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const ageNum = Number.parseFloat(age)
    const exerciseNum = Number.parseFloat(exerciseMinutes) || 0

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(ageNum) || ageNum < 10) {
      setError("Please enter a valid age (10 years or older)")
      return
    }

    if (exerciseNum < 0) {
      setError("Exercise duration cannot be negative")
      return
    }

    // Convert to kg if imperial
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Base calculation: 35ml per kg of body weight
    const baseIntakeMl = 35 * weightInKg
    const baseIntakeLiters = baseIntakeMl / 1000

    // Activity adjustment
    let activityAdjustment = 0
    switch (activityLevel) {
      case "light":
        activityAdjustment = 0.5
        break
      case "moderate":
        activityAdjustment = 0.75
        break
      case "very-active":
        activityAdjustment = 1.0
        break
      default:
        activityAdjustment = 0
    }

    // Exercise adjustment: +0.25L per 30 minutes
    const exerciseAdjustment = (exerciseNum / 30) * 0.25

    // Climate adjustment
    let climateAdjustment = 0
    switch (climate) {
      case "moderate":
        climateAdjustment = 0.3
        break
      case "hot":
        climateAdjustment = 0.7
        break
      default:
        climateAdjustment = 0
    }

    // Special conditions adjustment (only for females)
    let specialAdjustment = 0
    if (gender === "female") {
      if (isPregnant) specialAdjustment += 0.3
      if (isBreastfeeding) specialAdjustment += 0.7
    }

    // Total water intake
    const totalLiters =
      baseIntakeLiters + activityAdjustment + exerciseAdjustment + climateAdjustment + specialAdjustment
    const roundedLiters = Math.round(totalLiters * 10) / 10

    // Convert to ounces (1 liter = 33.814 oz)
    const totalOunces = Math.round(roundedLiters * 33.814)

    // Glasses (1 glass = 250ml)
    const glasses = Math.round((roundedLiters * 1000) / 250)

    setResult({
      liters: roundedLiters,
      ounces: totalOunces,
      glasses,
      baseIntake: Math.round(baseIntakeLiters * 10) / 10,
      activityAdjustment,
      exerciseAdjustment: Math.round(exerciseAdjustment * 10) / 10,
      climateAdjustment,
      specialAdjustment,
    })
  }

  const handleReset = () => {
    setWeight("")
    setAge("")
    setExerciseMinutes("")
    setActivityLevel("sedentary")
    setClimate("moderate")
    setIsPregnant(false)
    setIsBreastfeeding(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My recommended daily water intake is ${result.liters}L (${result.ounces} oz) - approximately ${result.glasses} glasses per day.`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Water Intake Result",
          text: `I calculated my daily water intake using CalcHub! I should drink ${result.liters}L (${result.glasses} glasses) per day.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Water Intake Calculator</CardTitle>
                    <CardDescription>Calculate your daily hydration needs</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => {
                        setGender("male")
                        setIsPregnant(false)
                        setIsBreastfeeding(false)
                      }}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Age and Weight */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age (years)</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter age"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="10"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder={`Enter weight`}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "sedentary", label: "Sedentary" },
                      { value: "light", label: "Light" },
                      { value: "moderate", label: "Moderate" },
                      { value: "very-active", label: "Very Active" },
                    ].map((level) => (
                      <Button
                        key={level.value}
                        type="button"
                        variant={activityLevel === level.value ? "default" : "outline"}
                        onClick={() => setActivityLevel(level.value as ActivityLevel)}
                        className="w-full text-sm"
                        size="sm"
                      >
                        {level.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Exercise Duration */}
                <div className="space-y-2">
                  <Label htmlFor="exercise">Exercise Duration (minutes/day)</Label>
                  <Input
                    id="exercise"
                    type="number"
                    placeholder="e.g., 30"
                    value={exerciseMinutes}
                    onChange={(e) => setExerciseMinutes(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Climate */}
                <div className="space-y-2">
                  <Label>Climate</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "cool", label: "Cool" },
                      { value: "moderate", label: "Moderate" },
                      { value: "hot", label: "Hot" },
                    ].map((c) => (
                      <Button
                        key={c.value}
                        type="button"
                        variant={climate === c.value ? "default" : "outline"}
                        onClick={() => setClimate(c.value as Climate)}
                        className="w-full text-sm"
                        size="sm"
                      >
                        {c.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Special Conditions (Female only) */}
                {gender === "female" && (
                  <div className="space-y-2">
                    <Label>Special Conditions</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        type="button"
                        variant={isPregnant ? "default" : "outline"}
                        onClick={() => setIsPregnant(!isPregnant)}
                        className="w-full text-sm"
                        size="sm"
                      >
                        <Baby className="h-4 w-4 mr-1" />
                        Pregnant
                      </Button>
                      <Button
                        type="button"
                        variant={isBreastfeeding ? "default" : "outline"}
                        onClick={() => setIsBreastfeeding(!isBreastfeeding)}
                        className="w-full text-sm"
                        size="sm"
                      >
                        <Baby className="h-4 w-4 mr-1" />
                        Breastfeeding
                      </Button>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWaterIntake} className="w-full" size="lg">
                  Calculate Water Intake
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Daily Water Intake</p>
                      <p className="text-5xl font-bold text-blue-600 mb-1">{result.liters}L</p>
                      <p className="text-lg text-blue-600 mb-2">{result.ounces} oz</p>
                      <div className="flex items-center justify-center gap-1 text-blue-700">
                        <Droplets className="h-4 w-4" />
                        <span className="font-semibold">{result.glasses} glasses per day</span>
                      </div>
                    </div>

                    {/* Breakdown */}
                    <div className="mt-4 pt-4 border-t border-blue-200 space-y-2 text-sm">
                      <div className="flex justify-between text-muted-foreground">
                        <span>Base intake:</span>
                        <span>{result.baseIntake}L</span>
                      </div>
                      {result.activityAdjustment > 0 && (
                        <div className="flex justify-between text-muted-foreground">
                          <span>Activity adjustment:</span>
                          <span>+{result.activityAdjustment}L</span>
                        </div>
                      )}
                      {result.exerciseAdjustment > 0 && (
                        <div className="flex justify-between text-muted-foreground">
                          <span>Exercise adjustment:</span>
                          <span>+{result.exerciseAdjustment}L</span>
                        </div>
                      )}
                      {result.climateAdjustment > 0 && (
                        <div className="flex justify-between text-muted-foreground">
                          <span>Climate adjustment:</span>
                          <span>+{result.climateAdjustment}L</span>
                        </div>
                      )}
                      {result.specialAdjustment > 0 && (
                        <div className="flex justify-between text-muted-foreground">
                          <span>Special conditions:</span>
                          <span>+{result.specialAdjustment}L</span>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Hydration Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Sedentary</span>
                      <span className="text-sm text-blue-600">Base intake only</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Light Activity</span>
                      <span className="text-sm text-cyan-600">+0.5L</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-teal-50 border border-teal-200">
                      <span className="font-medium text-teal-700">Moderate Activity</span>
                      <span className="text-sm text-teal-600">+0.75L</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                      <span className="font-medium text-emerald-700">Very Active</span>
                      <span className="text-sm text-emerald-600">+1.0L</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Base = 35ml × Weight (kg)</p>
                  </div>
                  <p>
                    <strong>Additional adjustments:</strong> Activity level, exercise duration (+0.25L per 30 min),
                    climate conditions, and special conditions like pregnancy or breastfeeding.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Water Intake */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Why is Proper Hydration Important?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Water is essential for virtually every function in the human body. It makes up approximately 60% of
                  your body weight and plays a critical role in maintaining body temperature, transporting nutrients,
                  removing waste products, cushioning joints, and protecting sensitive tissues. Without adequate
                  hydration, your body cannot perform at its optimal level, leading to a range of symptoms from mild
                  fatigue to severe health complications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The amount of water each person needs varies significantly based on individual factors such as body
                  weight, physical activity level, climate, and overall health status. While the commonly cited "8
                  glasses a day" rule provides a simple guideline, it doesn't account for these individual differences.
                  A personalized approach to hydration, considering your unique circumstances, is far more effective for
                  maintaining optimal health and performance.
                </p>
              </CardContent>
            </Card>

            {/* Factors Affecting Water Needs */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Factors That Affect Your Water Needs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several key factors influence how much water you need each day. Understanding these factors helps you
                  make informed decisions about your hydration habits and adjust your intake as circumstances change.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Body Weight</h4>
                    <p className="text-blue-700 text-sm">
                      Larger bodies require more water to maintain proper function. The general recommendation is
                      approximately 35ml of water per kilogram of body weight. This means a person weighing 70kg needs
                      about 2.45 liters as a baseline, while someone weighing 90kg would need around 3.15 liters.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Physical Activity</h4>
                    <p className="text-cyan-700 text-sm">
                      Exercise and physical labor increase your water requirements significantly. When you exercise, you
                      lose water through sweat and increased respiration. For every 30 minutes of exercise, you should
                      add approximately 0.25 liters to your daily intake to compensate for fluid loss.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Climate and Environment</h4>
                    <p className="text-amber-700 text-sm">
                      Hot and humid weather increases perspiration, requiring additional fluid intake. Similarly,
                      high-altitude environments and heated indoor spaces during winter can increase water loss through
                      respiration. In hot climates, you may need to add 0.5-1 liter to your daily baseline.
                    </p>
                  </div>
                  <div className="p-4 bg-rose-50 border border-rose-200 rounded-lg">
                    <h4 className="font-semibold text-rose-800 mb-2">Special Conditions</h4>
                    <p className="text-rose-700 text-sm">
                      Pregnancy and breastfeeding significantly increase fluid requirements. Pregnant women should add
                      about 0.3 liters daily, while breastfeeding mothers need an additional 0.7 liters or more to
                      support milk production and maintain their own hydration levels.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Signs of Dehydration */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Signs of Dehydration to Watch For</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Recognizing the signs of dehydration early can help you take corrective action before it affects your
                  health and performance. Mild dehydration is common and easily reversible, but chronic or severe
                  dehydration can have serious consequences. Here are the key warning signs to watch for:
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Early signs</strong> include thirst (though by the time you feel thirsty, you may already be
                  mildly dehydrated), darker yellow urine, dry mouth and lips, fatigue, and headaches.{" "}
                  <strong>Moderate dehydration</strong> symptoms include decreased urine output, dizziness, rapid
                  heartbeat, and muscle cramps. <strong>Severe dehydration</strong> is a medical emergency characterized
                  by extreme thirst, very dark urine or no urine output, sunken eyes, rapid breathing, confusion, and
                  fainting.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The color of your urine is one of the best indicators of hydration status. Pale yellow indicates good
                  hydration, while dark yellow or amber suggests you need more fluids. Clear urine might indicate
                  overhydration, which can also be problematic as it may dilute essential electrolytes.
                </p>
              </CardContent>
            </Card>

            {/* Tips for Staying Hydrated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Staying Properly Hydrated</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Maintaining proper hydration throughout the day requires developing good habits and creating systems
                  that remind you to drink water regularly. Here are practical strategies to help you meet your daily
                  hydration goals:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Start your day with water:</strong> Drink a glass of water first thing in the morning to
                    rehydrate after sleep and kickstart your metabolism.
                  </li>
                  <li>
                    <strong>Keep water accessible:</strong> Carry a reusable water bottle with you throughout the day
                    and keep water at your desk, in your car, and by your bed.
                  </li>
                  <li>
                    <strong>Set reminders:</strong> Use phone apps or alarms to remind yourself to drink water at
                    regular intervals, especially if you often forget.
                  </li>
                  <li>
                    <strong>Eat water-rich foods:</strong> Fruits and vegetables like watermelon, cucumber, oranges, and
                    lettuce contribute to your daily fluid intake.
                  </li>
                  <li>
                    <strong>Drink before, during, and after exercise:</strong> Don't wait until you're thirsty during
                    workouts. Sip water regularly throughout your exercise routine.
                  </li>
                  <li>
                    <strong>Flavor your water:</strong> If you find plain water boring, add slices of lemon, lime,
                    cucumber, or mint to make it more appealing.
                  </li>
                </ul>
                <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-amber-800 text-sm">
                    <strong>Disclaimer:</strong> Water needs vary by individual based on health conditions, medications,
                    and other factors. This calculator provides general guidance only and should not replace medical
                    advice. Consult a healthcare provider if you have concerns about your hydration needs or underlying
                    health conditions.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
