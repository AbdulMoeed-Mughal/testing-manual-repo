"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Thermometer,
  Wind,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "pressure" | "volume" | "temperature" | "moles"

interface Result {
  value: number
  unit: string
  label: string
  color: string
  steps: string[]
}

export function IdealGasLawCalculator() {
  const [mode, setMode] = useState<CalculationMode>("pressure")
  const [pressure, setPressure] = useState("")
  const [pressureUnit, setPressureUnit] = useState("atm")
  const [volume, setVolume] = useState("")
  const [volumeUnit, setVolumeUnit] = useState("L")
  const [temperature, setTemperature] = useState("")
  const [temperatureUnit, setTemperatureUnit] = useState("K")
  const [moles, setMoles] = useState("")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  // Gas constant values
  const R_L_atm = 0.082057 // L·atm/(mol·K)
  const R_J = 8.314 // J/(mol·K) = Pa·m³/(mol·K)

  // Unit conversion factors
  const pressureToAtm: Record<string, number> = {
    atm: 1,
    Pa: 1 / 101325,
    kPa: 1 / 101.325,
    bar: 1 / 1.01325,
  }

  const volumeToL: Record<string, number> = {
    L: 1,
    "m³": 1000,
    mL: 0.001,
  }

  const convertTemperatureToK = (value: number, unit: string): number => {
    if (unit === "K") return value
    if (unit === "°C") return value + 273.15
    return value
  }

  const convertTemperatureFromK = (valueK: number, unit: string): number => {
    if (unit === "K") return valueK
    if (unit === "°C") return valueK - 273.15
    return valueK
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const steps: string[] = []

    try {
      let P_atm: number | null = null
      let V_L: number | null = null
      let T_K: number | null = null
      let n: number | null = null

      // Parse inputs based on mode
      if (mode !== "pressure") {
        const pVal = Number.parseFloat(pressure)
        if (isNaN(pVal) || pVal <= 0) {
          setError("Please enter a valid positive pressure")
          return
        }
        P_atm = pVal * pressureToAtm[pressureUnit]
        steps.push(`Pressure: ${pVal} ${pressureUnit} = ${P_atm.toFixed(6)} atm`)
      }

      if (mode !== "volume") {
        const vVal = Number.parseFloat(volume)
        if (isNaN(vVal) || vVal <= 0) {
          setError("Please enter a valid positive volume")
          return
        }
        V_L = vVal * volumeToL[volumeUnit]
        steps.push(`Volume: ${vVal} ${volumeUnit} = ${V_L.toFixed(6)} L`)
      }

      if (mode !== "temperature") {
        const tVal = Number.parseFloat(temperature)
        if (isNaN(tVal)) {
          setError("Please enter a valid temperature")
          return
        }
        T_K = convertTemperatureToK(tVal, temperatureUnit)
        if (T_K <= 0) {
          setError("Temperature must be above absolute zero (0 K)")
          return
        }
        steps.push(`Temperature: ${tVal} ${temperatureUnit} = ${T_K.toFixed(2)} K`)
      }

      if (mode !== "moles") {
        const nVal = Number.parseFloat(moles)
        if (isNaN(nVal) || nVal <= 0) {
          setError("Please enter a valid positive number of moles")
          return
        }
        n = nVal
        steps.push(`Moles: ${n} mol`)
      }

      steps.push(`Gas constant R = ${R_L_atm} L·atm/(mol·K)`)
      steps.push("")
      steps.push("Using Ideal Gas Law: PV = nRT")

      let calculatedValue: number
      let resultUnit: string
      let resultLabel: string
      let resultColor: string

      switch (mode) {
        case "pressure":
          // P = nRT/V
          steps.push("Solving for P: P = nRT/V")
          calculatedValue = (n! * R_L_atm * T_K!) / V_L!
          steps.push(`P = (${n} mol × ${R_L_atm} L·atm/(mol·K) × ${T_K!.toFixed(2)} K) / ${V_L!.toFixed(6)} L`)
          steps.push(`P = ${calculatedValue.toFixed(6)} atm`)

          // Convert to selected unit
          const pInSelectedUnit = calculatedValue / pressureToAtm[pressureUnit]
          steps.push(`P = ${pInSelectedUnit.toFixed(4)} ${pressureUnit}`)

          calculatedValue = pInSelectedUnit
          resultUnit = pressureUnit
          resultLabel = "Pressure"
          resultColor = "text-blue-600"
          break

        case "volume":
          // V = nRT/P
          steps.push("Solving for V: V = nRT/P")
          calculatedValue = (n! * R_L_atm * T_K!) / P_atm!
          steps.push(`V = (${n} mol × ${R_L_atm} L·atm/(mol·K) × ${T_K!.toFixed(2)} K) / ${P_atm!.toFixed(6)} atm`)
          steps.push(`V = ${calculatedValue.toFixed(6)} L`)

          // Convert to selected unit
          const vInSelectedUnit = calculatedValue / volumeToL[volumeUnit]
          steps.push(`V = ${vInSelectedUnit.toFixed(4)} ${volumeUnit}`)

          calculatedValue = vInSelectedUnit
          resultUnit = volumeUnit
          resultLabel = "Volume"
          resultColor = "text-green-600"
          break

        case "temperature":
          // T = PV/(nR)
          steps.push("Solving for T: T = PV/(nR)")
          calculatedValue = (P_atm! * V_L!) / (n! * R_L_atm)
          steps.push(`T = (${P_atm!.toFixed(6)} atm × ${V_L!.toFixed(6)} L) / (${n} mol × ${R_L_atm} L·atm/(mol·K))`)
          steps.push(`T = ${calculatedValue.toFixed(2)} K`)

          // Convert to selected unit
          const tInSelectedUnit = convertTemperatureFromK(calculatedValue, temperatureUnit)
          if (temperatureUnit !== "K") {
            steps.push(`T = ${tInSelectedUnit.toFixed(2)} ${temperatureUnit}`)
          }

          calculatedValue = tInSelectedUnit
          resultUnit = temperatureUnit
          resultLabel = "Temperature"
          resultColor = "text-orange-600"
          break

        case "moles":
          // n = PV/(RT)
          steps.push("Solving for n: n = PV/(RT)")
          calculatedValue = (P_atm! * V_L!) / (R_L_atm * T_K!)
          steps.push(
            `n = (${P_atm!.toFixed(6)} atm × ${V_L!.toFixed(6)} L) / (${R_L_atm} L·atm/(mol·K) × ${T_K!.toFixed(2)} K)`,
          )
          steps.push(`n = ${calculatedValue.toFixed(6)} mol`)

          resultUnit = "mol"
          resultLabel = "Amount of Gas"
          resultColor = "text-purple-600"
          break

        default:
          return
      }

      setResult({
        value: calculatedValue,
        unit: resultUnit,
        label: resultLabel,
        color: resultColor,
        steps,
      })
    } catch {
      setError("An error occurred during calculation")
    }
  }

  const handleReset = () => {
    setPressure("")
    setVolume("")
    setTemperature("")
    setMoles("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`${result.label}: ${result.value.toFixed(4)} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Ideal Gas Law Calculation",
          text: `I calculated ${result.label.toLowerCase()} using the Ideal Gas Law! Result: ${result.value.toFixed(4)} ${result.unit}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const formatResult = (value: number): string => {
    if (Math.abs(value) < 0.0001 || Math.abs(value) >= 1000000) {
      return value.toExponential(4)
    }
    return value.toFixed(4)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Wind className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Ideal Gas Law Calculator</CardTitle>
                    <CardDescription>Calculate P, V, T, or n using PV = nRT</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Mode Selection */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select value={mode} onValueChange={(v) => setMode(v as CalculationMode)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pressure">Pressure (P)</SelectItem>
                      <SelectItem value="volume">Volume (V)</SelectItem>
                      <SelectItem value="temperature">Temperature (T)</SelectItem>
                      <SelectItem value="moles">Amount of Gas (n)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Pressure Input */}
                {mode !== "pressure" && (
                  <div className="space-y-2">
                    <Label htmlFor="pressure">Pressure</Label>
                    <div className="flex gap-2">
                      <Input
                        id="pressure"
                        type="number"
                        placeholder="Enter pressure"
                        value={pressure}
                        onChange={(e) => setPressure(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={pressureUnit} onValueChange={setPressureUnit}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="atm">atm</SelectItem>
                          <SelectItem value="Pa">Pa</SelectItem>
                          <SelectItem value="kPa">kPa</SelectItem>
                          <SelectItem value="bar">bar</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Volume Input */}
                {mode !== "volume" && (
                  <div className="space-y-2">
                    <Label htmlFor="volume">Volume</Label>
                    <div className="flex gap-2">
                      <Input
                        id="volume"
                        type="number"
                        placeholder="Enter volume"
                        value={volume}
                        onChange={(e) => setVolume(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={volumeUnit} onValueChange={setVolumeUnit}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="L">L</SelectItem>
                          <SelectItem value="mL">mL</SelectItem>
                          <SelectItem value="m³">m³</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Temperature Input */}
                {mode !== "temperature" && (
                  <div className="space-y-2">
                    <Label htmlFor="temperature">Temperature</Label>
                    <div className="flex gap-2">
                      <Input
                        id="temperature"
                        type="number"
                        placeholder="Enter temperature"
                        value={temperature}
                        onChange={(e) => setTemperature(e.target.value)}
                        step="any"
                        className="flex-1"
                      />
                      <Select value={temperatureUnit} onValueChange={setTemperatureUnit}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="K">K</SelectItem>
                          <SelectItem value="°C">°C</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Moles Input */}
                {mode !== "moles" && (
                  <div className="space-y-2">
                    <Label htmlFor="moles">Amount of Gas (n)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="moles"
                        type="number"
                        placeholder="Enter moles"
                        value={moles}
                        onChange={(e) => setMoles(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <div className="w-24 flex items-center justify-center bg-muted rounded-md text-sm text-muted-foreground">
                        mol
                      </div>
                    </div>
                  </div>
                )}

                {/* Output Unit Selection */}
                {mode === "pressure" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={pressureUnit} onValueChange={setPressureUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="atm">atm</SelectItem>
                        <SelectItem value="Pa">Pa</SelectItem>
                        <SelectItem value="kPa">kPa</SelectItem>
                        <SelectItem value="bar">bar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {mode === "volume" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={volumeUnit} onValueChange={setVolumeUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="L">L</SelectItem>
                        <SelectItem value="mL">mL</SelectItem>
                        <SelectItem value="m³">m³</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {mode === "temperature" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={temperatureUnit} onValueChange={setTemperatureUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="K">K</SelectItem>
                        <SelectItem value="°C">°C</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Show Steps Toggle */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="showSteps"
                    checked={showSteps}
                    onChange={(e) => setShowSteps(e.target.checked)}
                    className="rounded border-gray-300"
                  />
                  <Label htmlFor="showSteps" className="text-sm cursor-pointer">
                    Show step-by-step solution
                  </Label>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{result.label}</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{formatResult(result.value)}</p>
                      <p className="text-lg text-muted-foreground">{result.unit}</p>
                    </div>

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 p-3 bg-white rounded-lg border">
                        <p className="text-sm font-medium mb-2">Solution Steps:</p>
                        <div className="text-xs text-muted-foreground space-y-1 font-mono">
                          {result.steps.map((step, index) => (
                            <p key={index}>{step || <br />}</p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Ideal Gas Law Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">PV = nRT</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-blue-50 rounded-lg">
                      <p className="font-medium text-blue-700">P = nRT/V</p>
                      <p className="text-xs text-blue-600">Calculate pressure</p>
                    </div>
                    <div className="p-2 bg-green-50 rounded-lg">
                      <p className="font-medium text-green-700">V = nRT/P</p>
                      <p className="text-xs text-green-600">Calculate volume</p>
                    </div>
                    <div className="p-2 bg-orange-50 rounded-lg">
                      <p className="font-medium text-orange-700">T = PV/nR</p>
                      <p className="text-xs text-orange-600">Calculate temperature</p>
                    </div>
                    <div className="p-2 bg-purple-50 rounded-lg">
                      <p className="font-medium text-purple-700">n = PV/RT</p>
                      <p className="text-xs text-purple-600">Calculate moles</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Gas Constant (R)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded-lg">
                      <span>R (L·atm)</span>
                      <span className="font-mono">0.082057 L·atm/(mol·K)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded-lg">
                      <span>R (SI units)</span>
                      <span className="font-mono">8.314 J/(mol·K)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded-lg">
                      <span>R (cal)</span>
                      <span className="font-mono">1.987 cal/(mol·K)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results assume ideal gas behavior and may deviate at high pressures or low temperatures where
                        real gas effects become significant.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Ideal Gas Law?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Ideal Gas Law is a fundamental equation in chemistry and physics that describes the behavior of
                  ideal gases. It combines several gas laws (Boyle's Law, Charles's Law, and Avogadro's Law) into a
                  single equation: <strong>PV = nRT</strong>. This equation relates the pressure (P), volume (V),
                  temperature (T), and amount of gas (n) through the universal gas constant (R).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  An "ideal gas" is a theoretical gas composed of randomly moving point particles that interact only
                  through elastic collisions. While no real gas behaves exactly as an ideal gas, many gases approximate
                  ideal behavior under normal conditions of temperature and pressure, making this equation incredibly
                  useful for practical calculations.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Variables</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Pressure (P)</h4>
                    <p className="text-blue-700 text-sm">
                      The force exerted by gas molecules colliding with the container walls. Measured in atmospheres
                      (atm), pascals (Pa), kilopascals (kPa), or bar.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Volume (V)</h4>
                    <p className="text-green-700 text-sm">
                      The space occupied by the gas. Typically measured in liters (L), milliliters (mL), or cubic meters
                      (m³).
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Temperature (T)</h4>
                    <p className="text-orange-700 text-sm">
                      Must be in absolute scale (Kelvin) for calculations. Convert from Celsius by adding 273.15. Note
                      that temperature must be above absolute zero.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Amount (n)</h4>
                    <p className="text-purple-700 text-sm">
                      The quantity of gas in moles. One mole contains Avogadro's number (6.022 × 10²³) of particles.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-primary" />
                  <CardTitle>Standard Temperature and Pressure (STP)</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Standard Temperature and Pressure (STP) is a reference condition used in chemistry calculations. At
                  STP (0°C or 273.15 K and 1 atm), one mole of an ideal gas occupies exactly 22.414 liters. This is
                  known as the molar volume of an ideal gas at STP.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="font-medium mb-2">At STP (0°C, 1 atm):</p>
                  <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                    <li>1 mole of ideal gas = 22.414 L</li>
                    <li>Temperature = 273.15 K = 0°C</li>
                    <li>Pressure = 1 atm = 101.325 kPa</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Wind className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Ideal Gas Law has numerous practical applications across various fields:
                </p>
                <ul className="mt-4 space-y-3 text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="font-semibold text-foreground">Chemistry Labs:</span>
                    Calculating the amount of gas produced or consumed in chemical reactions, determining molecular
                    weights of gases.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-foreground">Engineering:</span>
                    Designing gas storage tanks, pneumatic systems, and HVAC systems.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-foreground">Meteorology:</span>
                    Understanding atmospheric pressure changes and weather patterns.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-foreground">Scuba Diving:</span>
                    Calculating air consumption rates and decompression requirements.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-foreground">Medical:</span>
                    Respiratory therapy calculations and anesthesia delivery.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
