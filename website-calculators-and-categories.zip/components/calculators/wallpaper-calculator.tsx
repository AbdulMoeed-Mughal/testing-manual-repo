"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Layers,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface WallpaperResult {
  wallArea: number
  netWallArea: number
  rollCoverage: number
  rollsNeeded: number
  rollsWithWaste: number
  areaUnit: string
}

export function WallpaperCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [wallLength, setWallLength] = useState("")
  const [wallHeight, setWallHeight] = useState("")
  const [numWalls, setNumWalls] = useState("1")
  const [rollWidth, setRollWidth] = useState(unitSystem === "metric" ? "0.53" : "1.75")
  const [rollLength, setRollLength] = useState(unitSystem === "metric" ? "10" : "33")
  const [patternRepeat, setPatternRepeat] = useState("")
  const [openingsArea, setOpeningsArea] = useState("")
  const [wastePercentage, setWastePercentage] = useState("10")
  const [result, setResult] = useState<WallpaperResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateWallpaper = () => {
    setError("")
    setResult(null)

    const length = Number.parseFloat(wallLength)
    const height = Number.parseFloat(wallHeight)
    const walls = Number.parseFloat(numWalls) || 1
    const rWidth = Number.parseFloat(rollWidth)
    const rLength = Number.parseFloat(rollLength)
    const pattern = Number.parseFloat(patternRepeat) || 0
    const openings = Number.parseFloat(openingsArea) || 0
    const waste = Number.parseFloat(wastePercentage) || 0

    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid wall length greater than 0")
      return
    }
    if (isNaN(height) || height <= 0) {
      setError("Please enter a valid wall height greater than 0")
      return
    }
    if (isNaN(rWidth) || rWidth <= 0) {
      setError("Please enter a valid roll width greater than 0")
      return
    }
    if (isNaN(rLength) || rLength <= 0) {
      setError("Please enter a valid roll length greater than 0")
      return
    }

    // Calculate total wall area
    const totalWallArea = length * height * walls

    // Subtract openings
    if (openings >= totalWallArea) {
      setError("Openings area cannot exceed total wall area")
      return
    }
    const netWallArea = totalWallArea - openings

    // Adjust roll length for pattern repeat
    let effectiveRollLength = rLength
    if (pattern > 0) {
      // Account for pattern matching waste
      const stripsPerRoll = Math.floor(rLength / (height + pattern))
      effectiveRollLength = stripsPerRoll * height
      if (effectiveRollLength <= 0) {
        effectiveRollLength = rLength - pattern // Fallback
      }
    }

    // Calculate roll coverage
    const rollCoverage = rWidth * effectiveRollLength

    // Calculate rolls needed
    const rollsNeeded = netWallArea / rollCoverage

    // Add waste percentage
    const rollsWithWaste = rollsNeeded * (1 + waste / 100)

    const areaUnit = unitSystem === "metric" ? "m²" : "ft²"

    setResult({
      wallArea: Math.round(totalWallArea * 100) / 100,
      netWallArea: Math.round(netWallArea * 100) / 100,
      rollCoverage: Math.round(rollCoverage * 100) / 100,
      rollsNeeded: Math.round(rollsNeeded * 10) / 10,
      rollsWithWaste: Math.ceil(rollsWithWaste),
      areaUnit,
    })
  }

  const handleReset = () => {
    setWallLength("")
    setWallHeight("")
    setNumWalls("1")
    setRollWidth(unitSystem === "metric" ? "0.53" : "1.75")
    setRollLength(unitSystem === "metric" ? "10" : "33")
    setPatternRepeat("")
    setOpeningsArea("")
    setWastePercentage("10")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Wallpaper needed: ${result.rollsWithWaste} rolls (Wall area: ${result.netWallArea} ${result.areaUnit})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Wallpaper Calculation Result",
          text: `I calculated my wallpaper needs using CalcHub! ${result.rollsWithWaste} rolls required for ${result.netWallArea} ${result.areaUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    const newSystem = unitSystem === "metric" ? "imperial" : "metric"
    setUnitSystem(newSystem)
    setRollWidth(newSystem === "metric" ? "0.53" : "1.75")
    setRollLength(newSystem === "metric" ? "10" : "33")
    setWallLength("")
    setWallHeight("")
    setOpeningsArea("")
    setPatternRepeat("")
    setResult(null)
    setError("")
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"
  const areaUnit = unitSystem === "metric" ? "m²" : "ft²"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Wallpaper Calculator</CardTitle>
                    <CardDescription>Calculate rolls needed for your walls</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Wall Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="wallLength">Wall Length ({lengthUnit})</Label>
                    <Input
                      id="wallLength"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "5" : "16"}`}
                      value={wallLength}
                      onChange={(e) => setWallLength(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wallHeight">Wall Height ({lengthUnit})</Label>
                    <Input
                      id="wallHeight"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "2.5" : "8"}`}
                      value={wallHeight}
                      onChange={(e) => setWallHeight(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Number of Walls */}
                <div className="space-y-2">
                  <Label htmlFor="numWalls">Number of Walls</Label>
                  <Input
                    id="numWalls"
                    type="number"
                    placeholder="1"
                    value={numWalls}
                    onChange={(e) => setNumWalls(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Roll Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="rollWidth">Roll Width ({lengthUnit})</Label>
                    <Input
                      id="rollWidth"
                      type="number"
                      placeholder={unitSystem === "metric" ? "0.53" : "1.75"}
                      value={rollWidth}
                      onChange={(e) => setRollWidth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="rollLength">Roll Length ({lengthUnit})</Label>
                    <Input
                      id="rollLength"
                      type="number"
                      placeholder={unitSystem === "metric" ? "10" : "33"}
                      value={rollLength}
                      onChange={(e) => setRollLength(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Pattern Repeat */}
                <div className="space-y-2">
                  <Label htmlFor="patternRepeat">Pattern Repeat ({lengthUnit}) - Optional</Label>
                  <Input
                    id="patternRepeat"
                    type="number"
                    placeholder="0"
                    value={patternRepeat}
                    onChange={(e) => setPatternRepeat(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">Leave empty or 0 for plain wallpaper</p>
                </div>

                {/* Openings Area */}
                <div className="space-y-2">
                  <Label htmlFor="openingsArea">Doors/Windows Area ({areaUnit}) - Optional</Label>
                  <Input
                    id="openingsArea"
                    type="number"
                    placeholder="0"
                    value={openingsArea}
                    onChange={(e) => setOpeningsArea(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="wastePercentage">Waste Allowance (%)</Label>
                  <Input
                    id="wastePercentage"
                    type="number"
                    placeholder="10"
                    value={wastePercentage}
                    onChange={(e) => setWastePercentage(e.target.value)}
                    min="0"
                    max="50"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">Recommended: 5-10% for plain, 15-20% for patterns</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWallpaper} className="w-full" size="lg">
                  Calculate Wallpaper
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Rolls Required</p>
                      <p className="text-5xl font-bold text-amber-600 mb-2">{result.rollsWithWaste}</p>
                      <p className="text-lg font-semibold text-amber-700">wallpaper rolls</p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground">Net Wall Area</p>
                        <p className="font-semibold">
                          {result.netWallArea} {result.areaUnit}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground">Roll Coverage</p>
                        <p className="font-semibold">
                          {result.rollCoverage} {result.areaUnit}
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>

                    {/* Step-by-step breakdown */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="flex items-center justify-between w-full p-2 bg-white rounded-lg text-sm font-medium hover:bg-amber-100 transition-colors"
                      >
                        <span>Calculation Breakdown</span>
                        {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>

                      {showSteps && (
                        <div className="mt-2 p-3 bg-white rounded-lg text-sm space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Total Wall Area:</span>
                            <span className="font-medium">
                              {result.wallArea} {result.areaUnit}
                            </span>
                          </div>
                          {Number.parseFloat(openingsArea) > 0 && (
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Less Openings:</span>
                              <span className="font-medium">
                                -{openingsArea} {result.areaUnit}
                              </span>
                            </div>
                          )}
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Net Wall Area:</span>
                            <span className="font-medium">
                              {result.netWallArea} {result.areaUnit}
                            </span>
                          </div>
                          <div className="border-t pt-2 flex justify-between">
                            <span className="text-muted-foreground">Coverage per Roll:</span>
                            <span className="font-medium">
                              {result.rollCoverage} {result.areaUnit}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Rolls (exact):</span>
                            <span className="font-medium">{result.rollsNeeded}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">+ {wastePercentage}% Waste:</span>
                            <span className="font-medium">{result.rollsWithWaste} rolls</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Roll Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">European Standard</p>
                      <p className="text-muted-foreground">53 cm × 10 m (5.3 m²)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">American Standard</p>
                      <p className="text-muted-foreground">21" × 33' (57.75 ft²)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Wide Width</p>
                      <p className="text-muted-foreground">70 cm × 10 m (7 m²)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Waste Allowance Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center p-2 bg-green-50 rounded-lg">
                      <span className="text-green-700">Plain / No Pattern</span>
                      <span className="font-medium text-green-600">5-10%</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-yellow-50 rounded-lg">
                      <span className="text-yellow-700">Small Pattern Repeat</span>
                      <span className="font-medium text-yellow-600">10-15%</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-orange-50 rounded-lg">
                      <span className="text-orange-700">Large Pattern Repeat</span>
                      <span className="font-medium text-orange-600">15-20%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Rolls = Wall Area ÷ Roll Coverage</p>
                  </div>
                  <p>
                    <strong>Wall Area</strong> = Length × Height × Number of Walls - Openings
                  </p>
                  <p>
                    <strong>Roll Coverage</strong> = Roll Width × Effective Roll Length
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800">
                <p className="font-semibold mb-1">Disclaimer</p>
                <p>
                  Results are estimates. Actual wallpaper requirements may vary due to pattern matching, wall texture,
                  trimming, and installation technique. Always purchase extra rolls from the same batch to ensure color
                  consistency.
                </p>
              </div>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Wallpaper Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating wallpaper requirements accurately is essential to avoid running short during installation
                  or over-purchasing expensive materials. The calculation involves measuring your wall surfaces,
                  accounting for doors and windows, and factoring in the wallpaper roll dimensions and any pattern
                  repeat that may require additional material for proper alignment.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Unlike paint, wallpaper comes in fixed-size rolls, so you must always round up to the nearest whole
                  roll. Additionally, wallpaper from different production batches may have slight color variations, so
                  it's crucial to order all your rolls at once and keep extras for future repairs.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Pattern Repeat Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pattern repeat is the vertical distance between where the pattern is identical again on the wallpaper.
                  This measurement is crucial because when hanging patterned wallpaper, each strip must be aligned with
                  the previous one, which often means cutting off portions of wallpaper to match the pattern.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Types of Pattern Matches</h4>
                    <ul className="text-muted-foreground text-sm space-y-2">
                      <li>
                        <strong>Free Match:</strong> No pattern matching required - most economical
                      </li>
                      <li>
                        <strong>Straight Match:</strong> Pattern aligns horizontally across strips
                      </li>
                      <li>
                        <strong>Drop Match:</strong> Pattern alignment drops by half the repeat on alternate strips
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Do</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Measure each wall individually</li>
                      <li>• Account for pattern repeat waste</li>
                      <li>• Order extra rolls from same batch</li>
                      <li>• Check roll dimensions carefully</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Don't</h4>
                    <ul className="text-red-700 text-sm space-y-1">
                      <li>• Ignore window/door recesses</li>
                      <li>• Mix batches (color may vary)</li>
                      <li>• Forget sloped ceilings</li>
                      <li>• Underestimate waste</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
