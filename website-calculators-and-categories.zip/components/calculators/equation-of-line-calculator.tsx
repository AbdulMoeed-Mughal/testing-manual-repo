"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type InputMode = "two-points" | "point-slope"
type OutputForm = "slope-intercept" | "point-slope" | "standard"

interface LineResult {
  slope: number | null
  yIntercept: number | null
  xIntercept: number | null
  angle: number
  slopeInterceptForm: string
  pointSlopeForm: string
  standardForm: string
  isVertical: boolean
  isHorizontal: boolean
}

export function EquationOfLineCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("two-points")
  const [outputForm, setOutputForm] = useState<OutputForm>("slope-intercept")
  const [x1, setX1] = useState("")
  const [y1, setY1] = useState("")
  const [x2, setX2] = useState("")
  const [y2, setY2] = useState("")
  const [slope, setSlope] = useState("")
  const [result, setResult] = useState<LineResult | null>(null)
  const [showSteps, setShowSteps] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatNumber = (num: number): string => {
    if (Number.isInteger(num)) return num.toString()
    return num.toFixed(4).replace(/\.?0+$/, "")
  }

  const formatCoefficient = (num: number, isFirst = false): string => {
    if (num === 0) return ""
    if (num === 1) return isFirst ? "" : "+ "
    if (num === -1) return isFirst ? "-" : "- "
    if (num > 0) return isFirst ? formatNumber(num) : `+ ${formatNumber(num)}`
    return isFirst ? formatNumber(num) : `- ${formatNumber(Math.abs(num))}`
  }

  const gcd = (a: number, b: number): number => {
    a = Math.abs(Math.round(a * 1000000))
    b = Math.abs(Math.round(b * 1000000))
    while (b) {
      const t = b
      b = a % b
      a = t
    }
    return a / 1000000
  }

  const calculateLine = () => {
    setError("")
    setResult(null)

    const x1Num = Number.parseFloat(x1)
    const y1Num = Number.parseFloat(y1)

    if (isNaN(x1Num) || isNaN(y1Num)) {
      setError("Please enter valid coordinates for Point 1")
      return
    }

    let m: number | null = null
    let isVertical = false

    if (inputMode === "two-points") {
      const x2Num = Number.parseFloat(x2)
      const y2Num = Number.parseFloat(y2)

      if (isNaN(x2Num) || isNaN(y2Num)) {
        setError("Please enter valid coordinates for Point 2")
        return
      }

      if (x1Num === x2Num && y1Num === y2Num) {
        setError("The two points must be different")
        return
      }

      if (x2Num === x1Num) {
        isVertical = true
      } else {
        m = (y2Num - y1Num) / (x2Num - x1Num)
      }
    } else {
      const slopeNum = Number.parseFloat(slope)
      if (isNaN(slopeNum)) {
        setError("Please enter a valid slope")
        return
      }
      m = slopeNum
    }

    const isHorizontal = m === 0

    // Calculate y-intercept: b = y1 - m * x1
    let b: number | null = null
    if (!isVertical && m !== null) {
      b = y1Num - m * x1Num
    }

    // Calculate x-intercept: x = -b/m (when y = 0)
    let xInt: number | null = null
    if (isVertical) {
      xInt = x1Num
    } else if (m !== null && m !== 0 && b !== null) {
      xInt = -b / m
    } else if (m === 0) {
      xInt = null // Horizontal line has no x-intercept (unless y = 0)
    }

    // Calculate angle with x-axis
    let angle = 0
    if (isVertical) {
      angle = 90
    } else if (m !== null) {
      angle = Math.atan(m) * (180 / Math.PI)
    }

    // Generate equations
    let slopeInterceptForm = ""
    let pointSlopeForm = ""
    let standardForm = ""

    if (isVertical) {
      slopeInterceptForm = `x = ${formatNumber(x1Num)} (undefined slope)`
      pointSlopeForm = `x = ${formatNumber(x1Num)}`
      standardForm = `x ${x1Num >= 0 ? "- " + formatNumber(x1Num) : "+ " + formatNumber(Math.abs(x1Num))} = 0`
    } else if (m !== null && b !== null) {
      // Slope-intercept form: y = mx + b
      if (m === 0) {
        slopeInterceptForm = `y = ${formatNumber(b)}`
      } else if (b === 0) {
        slopeInterceptForm = `y = ${formatCoefficient(m, true)}x`
      } else {
        slopeInterceptForm = `y = ${formatCoefficient(m, true)}x ${b >= 0 ? "+ " + formatNumber(b) : "- " + formatNumber(Math.abs(b))}`
      }

      // Point-slope form: y - y1 = m(x - x1)
      const y1Sign = y1Num >= 0 ? "- " + formatNumber(y1Num) : "+ " + formatNumber(Math.abs(y1Num))
      const x1Sign = x1Num >= 0 ? "- " + formatNumber(x1Num) : "+ " + formatNumber(Math.abs(x1Num))
      pointSlopeForm = `y ${y1Sign} = ${formatNumber(m)}(x ${x1Sign})`

      // Standard form: Ax + By + C = 0 (where A >= 0)
      let A = -m
      let B = 1
      let C = -b

      // Try to get integer coefficients
      const scale = 1000000
      A = Math.round(A * scale) / scale
      B = Math.round(B * scale) / scale
      C = Math.round(C * scale) / scale

      // Make A positive
      if (A < 0) {
        A = -A
        B = -B
        C = -C
      }

      const formatStandardCoeff = (coeff: number, variable: string, isFirst: boolean): string => {
        if (coeff === 0) return ""
        const absCoeff = Math.abs(coeff)
        const sign = coeff >= 0 ? (isFirst ? "" : " + ") : isFirst ? "-" : " - "
        const coeffStr = absCoeff === 1 ? "" : formatNumber(absCoeff)
        return `${sign}${coeffStr}${variable}`
      }

      const stdParts = []
      if (A !== 0) stdParts.push(formatStandardCoeff(A, "x", true))
      if (B !== 0) stdParts.push(formatStandardCoeff(B, "y", stdParts.length === 0))
      if (C !== 0) {
        const sign = C >= 0 ? " + " : " - "
        stdParts.push(`${sign}${formatNumber(Math.abs(C))}`)
      }
      standardForm = stdParts.join("") + " = 0"
    }

    setResult({
      slope: m,
      yIntercept: b,
      xIntercept: xInt,
      angle,
      slopeInterceptForm,
      pointSlopeForm,
      standardForm,
      isVertical,
      isHorizontal,
    })
  }

  const handleReset = () => {
    setX1("")
    setY1("")
    setX2("")
    setY2("")
    setSlope("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const getSelectedEquation = (): string => {
    if (!result) return ""
    switch (outputForm) {
      case "slope-intercept":
        return result.slopeInterceptForm
      case "point-slope":
        return result.pointSlopeForm
      case "standard":
        return result.standardForm
      default:
        return result.slopeInterceptForm
    }
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Line Equation: ${getSelectedEquation()}\nSlope: ${result.isVertical ? "undefined" : formatNumber(result.slope!)}\nY-intercept: ${result.yIntercept !== null ? formatNumber(result.yIntercept) : "N/A"}\nX-intercept: ${result.xIntercept !== null ? formatNumber(result.xIntercept) : "N/A"}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Equation of Line Result",
          text: `Line Equation: ${getSelectedEquation()}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const renderSteps = () => {
    if (!result) return null

    const x1Num = Number.parseFloat(x1)
    const y1Num = Number.parseFloat(y1)

    if (inputMode === "two-points") {
      const x2Num = Number.parseFloat(x2)
      const y2Num = Number.parseFloat(y2)

      return (
        <div className="space-y-3 text-sm">
          <div className="p-3 bg-muted rounded-lg">
            <p className="font-medium mb-2">Step 1: Identify the two points</p>
            <p className="text-muted-foreground">
              Point 1: ({formatNumber(x1Num)}, {formatNumber(y1Num)})
            </p>
            <p className="text-muted-foreground">
              Point 2: ({formatNumber(x2Num)}, {formatNumber(y2Num)})
            </p>
          </div>

          {result.isVertical ? (
            <div className="p-3 bg-muted rounded-lg">
              <p className="font-medium mb-2">Step 2: Check for vertical line</p>
              <p className="text-muted-foreground">Since x₁ = x₂ = {formatNumber(x1Num)}, this is a vertical line.</p>
              <p className="text-muted-foreground mt-1">
                Vertical lines have undefined slope and are written as x = {formatNumber(x1Num)}
              </p>
            </div>
          ) : (
            <>
              <div className="p-3 bg-muted rounded-lg">
                <p className="font-medium mb-2">Step 2: Calculate the slope</p>
                <p className="text-muted-foreground">m = (y₂ - y₁) / (x₂ - x₁)</p>
                <p className="text-muted-foreground">
                  m = ({formatNumber(y2Num)} - {formatNumber(y1Num)}) / ({formatNumber(x2Num)} - {formatNumber(x1Num)})
                </p>
                <p className="text-muted-foreground">
                  m = {formatNumber(y2Num - y1Num)} / {formatNumber(x2Num - x1Num)}
                </p>
                <p className="text-muted-foreground font-medium">m = {formatNumber(result.slope!)}</p>
              </div>

              <div className="p-3 bg-muted rounded-lg">
                <p className="font-medium mb-2">Step 3: Calculate y-intercept</p>
                <p className="text-muted-foreground">
                  Using point ({formatNumber(x1Num)}, {formatNumber(y1Num)}) and slope m = {formatNumber(result.slope!)}
                </p>
                <p className="text-muted-foreground">b = y₁ - m × x₁</p>
                <p className="text-muted-foreground">
                  b = {formatNumber(y1Num)} - ({formatNumber(result.slope!)}) × ({formatNumber(x1Num)})
                </p>
                <p className="text-muted-foreground font-medium">b = {formatNumber(result.yIntercept!)}</p>
              </div>

              <div className="p-3 bg-muted rounded-lg">
                <p className="font-medium mb-2">Step 4: Write the equation</p>
                <p className="text-muted-foreground">Slope-intercept form: {result.slopeInterceptForm}</p>
                <p className="text-muted-foreground">Point-slope form: {result.pointSlopeForm}</p>
                <p className="text-muted-foreground">Standard form: {result.standardForm}</p>
              </div>
            </>
          )}
        </div>
      )
    } else {
      // Point-slope input mode
      const m = Number.parseFloat(slope)

      return (
        <div className="space-y-3 text-sm">
          <div className="p-3 bg-muted rounded-lg">
            <p className="font-medium mb-2">Step 1: Identify the given values</p>
            <p className="text-muted-foreground">
              Point: ({formatNumber(x1Num)}, {formatNumber(y1Num)})
            </p>
            <p className="text-muted-foreground">Slope: m = {formatNumber(m)}</p>
          </div>

          <div className="p-3 bg-muted rounded-lg">
            <p className="font-medium mb-2">Step 2: Use point-slope form</p>
            <p className="text-muted-foreground">y - y₁ = m(x - x₁)</p>
            <p className="text-muted-foreground">{result.pointSlopeForm}</p>
          </div>

          <div className="p-3 bg-muted rounded-lg">
            <p className="font-medium mb-2">Step 3: Calculate y-intercept</p>
            <p className="text-muted-foreground">b = y₁ - m × x₁</p>
            <p className="text-muted-foreground">
              b = {formatNumber(y1Num)} - ({formatNumber(m)}) × ({formatNumber(x1Num)})
            </p>
            <p className="text-muted-foreground font-medium">b = {formatNumber(result.yIntercept!)}</p>
          </div>

          <div className="p-3 bg-muted rounded-lg">
            <p className="font-medium mb-2">Step 4: Write the equation</p>
            <p className="text-muted-foreground">Slope-intercept form: {result.slopeInterceptForm}</p>
            <p className="text-muted-foreground">Standard form: {result.standardForm}</p>
          </div>
        </div>
      )
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Equation of Line Calculator</CardTitle>
                    <CardDescription>Find the equation of a line</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Method</span>
                  <button
                    onClick={() => {
                      setInputMode(inputMode === "two-points" ? "point-slope" : "two-points")
                      handleReset()
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "point-slope" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "two-points" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Two Points
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "point-slope" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Point + Slope
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Point 1 Input */}
                <div className="space-y-2">
                  <Label>Point 1 (x₁, y₁)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      type="number"
                      placeholder="x₁"
                      value={x1}
                      onChange={(e) => setX1(e.target.value)}
                      step="any"
                    />
                    <Input
                      type="number"
                      placeholder="y₁"
                      value={y1}
                      onChange={(e) => setY1(e.target.value)}
                      step="any"
                    />
                  </div>
                </div>

                {/* Point 2 or Slope Input */}
                {inputMode === "two-points" ? (
                  <div className="space-y-2">
                    <Label>Point 2 (x₂, y₂)</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="x₂"
                        value={x2}
                        onChange={(e) => setX2(e.target.value)}
                        step="any"
                      />
                      <Input
                        type="number"
                        placeholder="y₂"
                        value={y2}
                        onChange={(e) => setY2(e.target.value)}
                        step="any"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="slope">Slope (m)</Label>
                    <Input
                      id="slope"
                      type="number"
                      placeholder="Enter slope"
                      value={slope}
                      onChange={(e) => setSlope(e.target.value)}
                      step="any"
                    />
                  </div>
                )}

                {/* Output Form Selection */}
                <div className="space-y-2">
                  <Label>Output Form</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant={outputForm === "slope-intercept" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setOutputForm("slope-intercept")}
                      className="text-xs"
                    >
                      y = mx + b
                    </Button>
                    <Button
                      variant={outputForm === "point-slope" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setOutputForm("point-slope")}
                      className="text-xs"
                    >
                      Point-Slope
                    </Button>
                    <Button
                      variant={outputForm === "standard" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setOutputForm("standard")}
                      className="text-xs"
                    >
                      Standard
                    </Button>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLine} className="w-full" size="lg">
                  Calculate Equation
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Line Equation</p>
                      <p className="text-2xl font-bold text-blue-600 mb-3 font-mono">{getSelectedEquation()}</p>
                    </div>

                    {/* Additional Info */}
                    <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Slope (m)</p>
                        <p className="font-semibold">{result.isVertical ? "undefined" : formatNumber(result.slope!)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Angle with x-axis</p>
                        <p className="font-semibold">{formatNumber(result.angle)}°</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Y-intercept</p>
                        <p className="font-semibold">
                          {result.yIntercept !== null ? formatNumber(result.yIntercept) : "N/A"}
                        </p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">X-intercept</p>
                        <p className="font-semibold">
                          {result.xIntercept !== null ? formatNumber(result.xIntercept) : "N/A"}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-blue-600 hover:text-blue-700"
                    >
                      {showSteps ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Steps
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Steps
                        </>
                      )}
                    </button>

                    {showSteps && <div className="mt-4">{renderSteps()}</div>}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Line Equation Forms</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-700">Slope-Intercept Form</p>
                      <p className="text-sm text-blue-600 font-mono mt-1">y = mx + b</p>
                      <p className="text-xs text-blue-600 mt-1">m = slope, b = y-intercept</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="font-medium text-green-700">Point-Slope Form</p>
                      <p className="text-sm text-green-600 font-mono mt-1">y - y₁ = m(x - x₁)</p>
                      <p className="text-xs text-green-600 mt-1">Uses a point and slope</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-700">Standard Form</p>
                      <p className="text-sm text-purple-600 font-mono mt-1">Ax + By + C = 0</p>
                      <p className="text-xs text-purple-600 mt-1">A, B, C are coefficients</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Slope Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">m = (y₂ - y₁) / (x₂ - x₁)</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>Positive slope:</strong> Line rises from left to right
                    </p>
                    <p>
                      <strong>Negative slope:</strong> Line falls from left to right
                    </p>
                    <p>
                      <strong>Zero slope:</strong> Horizontal line (y = constant)
                    </p>
                    <p>
                      <strong>Undefined:</strong> Vertical line (x = constant)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Equation of a Line?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The equation of a line is a mathematical expression that describes all the points that lie on that
                  line in a coordinate plane. Every straight line can be represented by an equation, and this equation
                  uniquely determines the line's position and orientation. Understanding line equations is fundamental
                  to algebra, geometry, and many real-world applications including physics, engineering, and economics.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  There are several ways to express a line's equation, each with its own advantages. The slope-intercept
                  form (y = mx + b) directly shows the slope and y-intercept, making it easy to graph. The point-slope
                  form is useful when you know a point on the line and its slope. The standard form is often preferred
                  in formal mathematics and certain applications where symmetry between x and y is desired.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>How to Find the Equation of a Line</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>From Two Points:</strong> Given two points (x₁, y₁) and (x₂, y₂), first calculate the slope
                  using m = (y₂ - y₁)/(x₂ - x₁). Then use the point-slope form with either point to get y - y₁ = m(x -
                  x₁). Finally, simplify to get the slope-intercept form y = mx + b by solving for y.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>From Point and Slope:</strong> If you know a point (x₁, y₁) and the slope m, directly apply
                  the point-slope formula y - y₁ = m(x - x₁). Distribute and solve for y to convert to slope-intercept
                  form. This method is straightforward when the slope is already given or can be determined from the
                  context.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Line equations are calculated using standard mathematical formulas. Vertical lines have undefined
                  slope in slope-intercept form and are represented as x = constant. This calculator handles both
                  regular and special cases (vertical and horizontal lines) appropriately. Results are rounded for
                  display purposes; exact values may differ slightly for irrational numbers.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
