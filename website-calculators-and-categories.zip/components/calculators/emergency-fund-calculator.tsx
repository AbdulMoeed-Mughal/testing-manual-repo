"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  Shield,
  PiggyBank,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Target,
  TrendingUp,
  Clock,
  Wallet,
  Activity,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

interface EmergencyFundResult {
  recommendedFund: number
  baseAmount: number
  riskAdjustedAmount: number
  riskMultiplier: number
  currentSavings: number
  shortfall: number
  surplus: number
  status: "surplus" | "on-track" | "shortfall"
  monthsToGoal: number | null
  monthlyContributionNeeded: number | null
  coverageMonths: number
}

const COVERAGE_OPTIONS = [
  { value: "3", label: "3 months (Minimum)" },
  { value: "6", label: "6 months (Recommended)" },
  { value: "9", label: "9 months (Conservative)" },
  { value: "12", label: "12 months (Very Conservative)" },
]

const RISK_FACTORS = [
  { id: "unstable-job", label: "Unstable job or irregular income", multiplier: 0.1 },
  { id: "dependents", label: "Have dependents (children, elderly)", multiplier: 0.1 },
  { id: "medical", label: "Ongoing medical expenses", multiplier: 0.05 },
  { id: "single-income", label: "Single income household", multiplier: 0.1 },
  { id: "homeowner", label: "Homeowner (maintenance costs)", multiplier: 0.05 },
]

export function EmergencyFundCalculator() {
  const [monthlyExpenses, setMonthlyExpenses] = useState("")
  const [coverageMonths, setCoverageMonths] = useState("6")
  const [monthlyIncome, setMonthlyIncome] = useState("")
  const [currentSavings, setCurrentSavings] = useState("")
  const [monthlyContribution, setMonthlyContribution] = useState("")
  const [selectedRiskFactors, setSelectedRiskFactors] = useState<string[]>([])
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<EmergencyFundResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const toggleRiskFactor = (factorId: string) => {
    setSelectedRiskFactors((prev) =>
      prev.includes(factorId) ? prev.filter((id) => id !== factorId) : [...prev, factorId],
    )
  }

  const calculateEmergencyFund = () => {
    setError("")
    setResult(null)

    const expenses = Number.parseFloat(monthlyExpenses)
    const coverage = Number.parseInt(coverageMonths)
    const savings = currentSavings ? Number.parseFloat(currentSavings) : 0
    const contribution = monthlyContribution ? Number.parseFloat(monthlyContribution) : 0

    // Validation
    if (!monthlyExpenses || expenses <= 0) {
      setError("Please enter valid monthly expenses")
      return
    }

    if (expenses > 1000000) {
      setError("Monthly expenses seem unrealistic")
      return
    }

    // Calculate base emergency fund
    const baseAmount = expenses * coverage

    // Calculate risk multiplier
    let riskMultiplier = 1.0
    for (const factorId of selectedRiskFactors) {
      const factor = RISK_FACTORS.find((f) => f.id === factorId)
      if (factor) {
        riskMultiplier += factor.multiplier
      }
    }

    // Calculate risk-adjusted amount
    const riskAdjustedAmount = baseAmount * riskMultiplier
    const recommendedFund = Math.ceil(riskAdjustedAmount / 100) * 100 // Round to nearest 100

    // Calculate shortfall/surplus
    const shortfall = Math.max(0, recommendedFund - savings)
    const surplus = Math.max(0, savings - recommendedFund)

    // Determine status
    let status: "surplus" | "on-track" | "shortfall" = "on-track"
    if (surplus > 0) {
      status = "surplus"
    } else if (shortfall > recommendedFund * 0.1) {
      status = "shortfall"
    }

    // Calculate months to goal
    let monthsToGoal: number | null = null
    let monthlyContributionNeeded: number | null = null

    if (shortfall > 0 && contribution > 0) {
      monthsToGoal = Math.ceil(shortfall / contribution)
    }

    if (shortfall > 0) {
      // Calculate monthly contribution needed to reach goal in 12 months
      monthlyContributionNeeded = Math.ceil(shortfall / 12)
    }

    setResult({
      recommendedFund,
      baseAmount,
      riskAdjustedAmount,
      riskMultiplier,
      currentSavings: savings,
      shortfall,
      surplus,
      status,
      monthsToGoal,
      monthlyContributionNeeded,
      coverageMonths: coverage,
    })
  }

  const handleReset = () => {
    setMonthlyExpenses("")
    setCoverageMonths("6")
    setMonthlyIncome("")
    setCurrentSavings("")
    setMonthlyContribution("")
    setSelectedRiskFactors([])
    setShowAdvanced(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Emergency Fund Summary:\nRecommended Fund: $${result.recommendedFund.toLocaleString()}\nCurrent Savings: $${result.currentSavings.toLocaleString()}\n${result.shortfall > 0 ? `Shortfall: $${result.shortfall.toLocaleString()}` : `Surplus: $${result.surplus.toLocaleString()}`}\nCoverage: ${result.coverageMonths} months`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Emergency Fund Goal",
          text: `I'm building an emergency fund of $${result.recommendedFund.toLocaleString()} to cover ${result.coverageMonths} months of expenses!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "surplus":
        return "bg-green-50 border-green-200 text-green-700"
      case "shortfall":
        return "bg-red-50 border-red-200 text-red-700"
      default:
        return "bg-yellow-50 border-yellow-200 text-yellow-700"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "surplus":
        return <TrendingUp className="h-5 w-5" />
      case "shortfall":
        return <Target className="h-5 w-5" />
      default:
        return <Shield className="h-5 w-5" />
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "surplus":
        return "Fully Funded!"
      case "shortfall":
        return "Building Fund"
      default:
        return "On Track"
    }
  }

  const getProgressPercentage = () => {
    if (!result) return 0
    if (result.recommendedFund === 0) return 100
    return Math.min(100, (result.currentSavings / result.recommendedFund) * 100)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Shield className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Emergency Fund Calculator</CardTitle>
                    <CardDescription>Calculate your recommended emergency savings</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Monthly Expenses */}
                <div className="space-y-2">
                  <Label htmlFor="monthlyExpenses">Monthly Expenses ($)</Label>
                  <Input
                    id="monthlyExpenses"
                    type="number"
                    placeholder="Enter your total monthly expenses"
                    value={monthlyExpenses}
                    onChange={(e) => setMonthlyExpenses(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Coverage Duration */}
                <div className="space-y-2">
                  <Label>Coverage Duration</Label>
                  <Select value={coverageMonths} onValueChange={setCoverageMonths}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select coverage duration" />
                    </SelectTrigger>
                    <SelectContent>
                      {COVERAGE_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Current Savings (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="currentSavings">Current Emergency Savings (Optional)</Label>
                  <Input
                    id="currentSavings"
                    type="number"
                    placeholder="Enter your current savings"
                    value={currentSavings}
                    onChange={(e) => setCurrentSavings(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Risk Factors */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Risk Factors (Optional)</Label>
                  <p className="text-sm text-muted-foreground">
                    Select factors that apply to you for a risk-adjusted recommendation
                  </p>
                  <div className="space-y-2">
                    {RISK_FACTORS.map((factor) => (
                      <div key={factor.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={factor.id}
                          checked={selectedRiskFactors.includes(factor.id)}
                          onCheckedChange={() => toggleRiskFactor(factor.id)}
                        />
                        <label
                          htmlFor={factor.id}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                        >
                          {factor.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Advanced Options */}
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="w-full justify-between"
                  >
                    <span>Advanced Options</span>
                    {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>

                  {showAdvanced && (
                    <div className="space-y-3 p-3 border rounded-lg bg-muted/30">
                      <div className="space-y-2">
                        <Label htmlFor="monthlyIncome">Monthly Income (Optional)</Label>
                        <Input
                          id="monthlyIncome"
                          type="number"
                          placeholder="Enter your monthly income"
                          value={monthlyIncome}
                          onChange={(e) => setMonthlyIncome(e.target.value)}
                          min="0"
                          step="100"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="monthlyContribution">Monthly Savings Contribution (Optional)</Label>
                        <Input
                          id="monthlyContribution"
                          type="number"
                          placeholder="How much can you save monthly?"
                          value={monthlyContribution}
                          onChange={(e) => setMonthlyContribution(e.target.value)}
                          min="0"
                          step="50"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateEmergencyFund} className="w-full" size="lg">
                  Calculate Emergency Fund
                </Button>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleReset} className="flex-1 bg-transparent">
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                  <Button variant="outline" onClick={handleCopy} disabled={!result} className="flex-1 bg-transparent">
                    {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                    {copied ? "Copied!" : "Copy"}
                  </Button>
                  <Button variant="outline" onClick={handleShare} disabled={!result} className="flex-1 bg-transparent">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${getStatusColor(result.status)}`}
                  >
                    <div className="text-center mb-4">
                      <div className="flex items-center justify-center gap-2 mb-1">
                        {getStatusIcon(result.status)}
                        <p className="text-sm font-medium">{getStatusLabel(result.status)}</p>
                      </div>
                      <p className="text-3xl font-bold mb-1">{formatCurrency(result.recommendedFund)}</p>
                      <p className="text-sm opacity-80">Recommended Emergency Fund</p>
                    </div>

                    {/* Progress Bar */}
                    {result.currentSavings > 0 && (
                      <div className="mb-4">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Progress</span>
                          <span>{getProgressPercentage().toFixed(0)}%</span>
                        </div>
                        <div className="h-3 bg-white/50 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              result.status === "surplus"
                                ? "bg-green-500"
                                : result.status === "shortfall"
                                  ? "bg-red-500"
                                  : "bg-yellow-500"
                            }`}
                            style={{ width: `${getProgressPercentage()}%` }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white/80 rounded-lg text-center">
                        <p className="text-xs opacity-70 mb-1">Current Savings</p>
                        <p className="text-lg font-bold">{formatCurrency(result.currentSavings)}</p>
                      </div>
                      <div className="p-3 bg-white/80 rounded-lg text-center">
                        <p className="text-xs opacity-70 mb-1">{result.shortfall > 0 ? "Shortfall" : "Surplus"}</p>
                        <p className="text-lg font-bold">
                          {formatCurrency(result.shortfall > 0 ? result.shortfall : result.surplus)}
                        </p>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full justify-between bg-white/50 hover:bg-white/70"
                    >
                      <span>View Details</span>
                      {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>

                    {showDetails && (
                      <div className="mt-3 p-3 bg-white/80 rounded-lg space-y-3">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <p className="text-xs opacity-70">Base Amount</p>
                            <p className="font-semibold">{formatCurrency(result.baseAmount)}</p>
                          </div>
                          <div>
                            <p className="text-xs opacity-70">Risk Adjustment</p>
                            <p className="font-semibold">+{((result.riskMultiplier - 1) * 100).toFixed(0)}%</p>
                          </div>
                          <div>
                            <p className="text-xs opacity-70">Coverage Period</p>
                            <p className="font-semibold">{result.coverageMonths} months</p>
                          </div>
                          {result.monthsToGoal && (
                            <div>
                              <p className="text-xs opacity-70">Time to Goal</p>
                              <p className="font-semibold">{result.monthsToGoal} months</p>
                            </div>
                          )}
                        </div>

                        {result.monthlyContributionNeeded && result.shortfall > 0 && (
                          <div className="p-2 bg-blue-50 rounded-lg">
                            <p className="text-xs text-blue-700">
                              Save{" "}
                              <span className="font-bold">
                                {formatCurrency(result.monthlyContributionNeeded)}/month
                              </span>{" "}
                              to reach your goal in 12 months
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-4">
              {/* Coverage Guidelines Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Clock className="h-4 w-4 text-green-600" />
                    Coverage Guidelines
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between items-center p-2 rounded-lg bg-yellow-50">
                    <span className="text-sm font-medium">3 months</span>
                    <span className="text-xs text-muted-foreground">Minimum (Stable income)</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded-lg bg-green-50">
                    <span className="text-sm font-medium">6 months</span>
                    <span className="text-xs text-muted-foreground">Recommended</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded-lg bg-blue-50">
                    <span className="text-sm font-medium">9-12 months</span>
                    <span className="text-xs text-muted-foreground">Self-employed/Variable income</span>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Factors Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-orange-600" />
                    Risk Factor Impact
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {RISK_FACTORS.map((factor) => (
                      <div key={factor.id} className="flex justify-between items-center">
                        <span className="text-muted-foreground">{factor.label.split(" (")[0]}</span>
                        <span className="font-medium text-orange-600">+{factor.multiplier * 100}%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Formula Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Wallet className="h-4 w-4 text-blue-600" />
                    How It's Calculated
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-3 bg-muted/50 rounded-lg font-mono text-sm">
                    <p className="text-muted-foreground mb-2">Emergency Fund =</p>
                    <p className="font-semibold">Monthly Expenses × Months × Risk Factor</p>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Risk factor starts at 1.0 and increases based on your personal situation.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            <Card className="shadow-md border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Info className="h-4 w-4 text-blue-600" />
                  What is an Emergency Fund?
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground space-y-2">
                <p>
                  An emergency fund is savings set aside for unexpected expenses like job loss, medical emergencies, car
                  repairs, or home maintenance. It provides financial security and peace of mind.
                </p>
                <p>
                  Most financial experts recommend having 3-6 months of living expenses saved, though some situations
                  may warrant more.
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="h-4 w-4 text-green-600" />
                  Building Your Fund
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <ul className="space-y-1 list-disc list-inside">
                  <li>Start small - even $500 helps</li>
                  <li>Automate transfers to savings</li>
                  <li>Keep fund in high-yield savings account</li>
                  <li>Don't invest emergency funds</li>
                  <li>Replenish after using</li>
                  <li>Review and adjust annually</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <PiggyBank className="h-4 w-4 text-purple-600" />
                  Where to Keep Your Fund
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <ul className="space-y-1 list-disc list-inside">
                  <li>High-yield savings account (best)</li>
                  <li>Money market account</li>
                  <li>Short-term CDs (ladder)</li>
                  <li>Keep it accessible but separate</li>
                  <li>Avoid stocks or volatile investments</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0 bg-amber-50/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  Important Disclaimer
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>
                  Emergency fund recommendations are estimates based on user inputs and general guidelines. Individual
                  circumstances vary. Consult a financial advisor for personalized financial planning and advice
                  tailored to your specific situation.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
