"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Zap,
  Info,
  AlertTriangle,
  Calculator,
  Thermometer,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

type ConductivityUnit = "S/m" | "mS/cm" | "µS/cm" | "S/cm"

interface ConductivityResult {
  conductivity: number
  unit: ConductivityUnit
  resistivity: number
  temperatureAdjusted?: number
  category: string
  color: string
  bgColor: string
}

const unitConversions: Record<ConductivityUnit, number> = {
  "S/m": 1,
  "mS/cm": 0.1,
  "µS/cm": 0.0001,
  "S/cm": 100,
}

const materialConductivity: { name: string; conductivity: string; category: string }[] = [
  { name: "Silver", conductivity: "6.30 × 10⁷ S/m", category: "Excellent" },
  { name: "Copper", conductivity: "5.96 × 10⁷ S/m", category: "Excellent" },
  { name: "Gold", conductivity: "4.10 × 10⁷ S/m", category: "Excellent" },
  { name: "Aluminum", conductivity: "3.77 × 10⁷ S/m", category: "Excellent" },
  { name: "Iron", conductivity: "1.00 × 10⁷ S/m", category: "Good" },
  { name: "Stainless Steel", conductivity: "1.45 × 10⁶ S/m", category: "Moderate" },
  { name: "Seawater", conductivity: "4.8 S/m", category: "Low" },
  { name: "Tap Water", conductivity: "0.005-0.05 S/m", category: "Very Low" },
  { name: "Pure Water", conductivity: "5.5 × 10⁻⁶ S/m", category: "Insulator" },
  { name: "Glass", conductivity: "10⁻¹² S/m", category: "Insulator" },
]

export function ConductivityCalculator() {
  const [resistance, setResistance] = useState("")
  const [length, setLength] = useState("")
  const [area, setArea] = useState("")
  const [outputUnit, setOutputUnit] = useState<ConductivityUnit>("S/m")
  const [includeTemperature, setIncludeTemperature] = useState(false)
  const [tempCoefficient, setTempCoefficient] = useState("0.00393")
  const [temperature, setTemperature] = useState("")
  const [referenceTemp, setReferenceTemp] = useState("20")
  const [result, setResult] = useState<ConductivityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [steps, setSteps] = useState<string[]>([])

  const calculateConductivity = () => {
    setError("")
    setResult(null)
    setSteps([])

    const R = Number.parseFloat(resistance)
    const L = Number.parseFloat(length)
    const A = Number.parseFloat(area)

    if (isNaN(R) || R <= 0) {
      setError("Please enter a valid resistance greater than 0")
      return
    }
    if (isNaN(L) || L <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }
    if (isNaN(A) || A <= 0) {
      setError("Please enter a valid cross-sectional area greater than 0")
      return
    }

    const calculationSteps: string[] = []

    // Calculate conductivity: σ = L / (R × A)
    calculationSteps.push(`Step 1: Identify the values`)
    calculationSteps.push(`  Resistance (R) = ${R} Ω`)
    calculationSteps.push(`  Length (L) = ${L} m`)
    calculationSteps.push(`  Cross-sectional Area (A) = ${A} m²`)

    calculationSteps.push(`Step 2: Apply the conductivity formula`)
    calculationSteps.push(`  σ = L / (R × A)`)
    calculationSteps.push(`  σ = ${L} / (${R} × ${A})`)
    calculationSteps.push(`  σ = ${L} / ${(R * A).toExponential(4)}`)

    const conductivitySI = L / (R * A)
    calculationSteps.push(`  σ = ${conductivitySI.toExponential(4)} S/m`)

    // Convert to selected unit
    const conductivity = conductivitySI / unitConversions[outputUnit]
    calculationSteps.push(`Step 3: Convert to ${outputUnit}`)
    calculationSteps.push(`  σ = ${conductivity.toExponential(4)} ${outputUnit}`)

    // Calculate resistivity (inverse of conductivity)
    const resistivity = 1 / conductivitySI
    calculationSteps.push(`Step 4: Calculate resistivity (ρ = 1/σ)`)
    calculationSteps.push(`  ρ = ${resistivity.toExponential(4)} Ω·m`)

    let temperatureAdjusted: number | undefined
    if (includeTemperature) {
      const alpha = Number.parseFloat(tempCoefficient)
      const T = Number.parseFloat(temperature)
      const T0 = Number.parseFloat(referenceTemp)

      if (!isNaN(alpha) && !isNaN(T) && !isNaN(T0)) {
        calculationSteps.push(`Step 5: Apply temperature adjustment`)
        calculationSteps.push(`  Temperature coefficient (α) = ${alpha} /°C`)
        calculationSteps.push(`  Operating temperature (T) = ${T}°C`)
        calculationSteps.push(`  Reference temperature (T₀) = ${T0}°C`)
        calculationSteps.push(`  σ_T = σ₀ / [1 + α × (T − T₀)]`)
        calculationSteps.push(`  σ_T = ${conductivity.toExponential(4)} / [1 + ${alpha} × (${T} − ${T0})]`)

        const tempFactor = 1 + alpha * (T - T0)
        temperatureAdjusted = conductivity / tempFactor
        calculationSteps.push(`  σ_T = ${conductivity.toExponential(4)} / ${tempFactor.toFixed(4)}`)
        calculationSteps.push(`  σ_T = ${temperatureAdjusted.toExponential(4)} ${outputUnit}`)
      }
    }

    // Determine category based on conductivity in S/m
    let category: string
    let color: string
    let bgColor: string

    if (conductivitySI >= 1e7) {
      category = "Excellent Conductor"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (conductivitySI >= 1e5) {
      category = "Good Conductor"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (conductivitySI >= 1) {
      category = "Moderate Conductor"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (conductivitySI >= 1e-6) {
      category = "Poor Conductor"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Insulator"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setSteps(calculationSteps)
    setResult({
      conductivity,
      unit: outputUnit,
      resistivity,
      temperatureAdjusted,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setResistance("")
    setLength("")
    setArea("")
    setOutputUnit("S/m")
    setIncludeTemperature(false)
    setTempCoefficient("0.00393")
    setTemperature("")
    setReferenceTemp("20")
    setResult(null)
    setError("")
    setCopied(false)
    setSteps([])
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Electrical Conductivity: ${result.conductivity.toExponential(4)} ${result.unit} (${result.category})${result.temperatureAdjusted ? ` | Temperature Adjusted: ${result.temperatureAdjusted.toExponential(4)} ${result.unit}` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Electrical Conductivity Result",
          text: `Calculated conductivity: ${result.conductivity.toExponential(4)} ${result.unit} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1e6 || Math.abs(num) < 1e-4) {
      return num.toExponential(4)
    }
    return num.toPrecision(6)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Conductivity Calculator</CardTitle>
                    <CardDescription>Calculate electrical conductivity from material properties</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Resistance Input */}
                <div className="space-y-2">
                  <Label htmlFor="resistance">Resistance (Ω)</Label>
                  <Input
                    id="resistance"
                    type="number"
                    placeholder="Enter resistance in ohms"
                    value={resistance}
                    onChange={(e) => setResistance(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Length (m)</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder="Enter length in meters"
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Cross-sectional Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="area">Cross-sectional Area (m²)</Label>
                  <Input
                    id="area"
                    type="number"
                    placeholder="Enter area in square meters"
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="outputUnit">Output Unit</Label>
                  <Select value={outputUnit} onValueChange={(value) => setOutputUnit(value as ConductivityUnit)}>
                    <SelectTrigger id="outputUnit">
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="S/m">S/m (Siemens per meter)</SelectItem>
                      <SelectItem value="mS/cm">mS/cm (millisiemens per cm)</SelectItem>
                      <SelectItem value="µS/cm">µS/cm (microsiemens per cm)</SelectItem>
                      <SelectItem value="S/cm">S/cm (Siemens per cm)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Temperature Adjustment Toggle */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2">
                    <Thermometer className="h-4 w-4 text-muted-foreground" />
                    <Label htmlFor="temp-toggle" className="cursor-pointer">
                      Temperature Adjustment
                    </Label>
                  </div>
                  <Switch id="temp-toggle" checked={includeTemperature} onCheckedChange={setIncludeTemperature} />
                </div>

                {/* Temperature Inputs */}
                {includeTemperature && (
                  <div className="space-y-4 p-4 rounded-lg bg-muted/30 border">
                    <div className="space-y-2">
                      <Label htmlFor="tempCoefficient">Temperature Coefficient (α) /°C</Label>
                      <Input
                        id="tempCoefficient"
                        type="number"
                        placeholder="e.g., 0.00393 for copper"
                        value={tempCoefficient}
                        onChange={(e) => setTempCoefficient(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="temperature">Operating Temp (°C)</Label>
                        <Input
                          id="temperature"
                          type="number"
                          placeholder="e.g., 50"
                          value={temperature}
                          onChange={(e) => setTemperature(e.target.value)}
                          step="any"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="referenceTemp">Reference Temp (°C)</Label>
                        <Input
                          id="referenceTemp"
                          type="number"
                          placeholder="e.g., 20"
                          value={referenceTemp}
                          onChange={(e) => setReferenceTemp(e.target.value)}
                          step="any"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateConductivity} className="w-full" size="lg">
                  Calculate Conductivity
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Electrical Conductivity (σ)</p>
                      <p className={`text-3xl sm:text-4xl font-bold ${result.color} mb-1`}>
                        {formatNumber(result.conductivity)}
                      </p>
                      <p className="text-lg font-medium text-muted-foreground mb-2">{result.unit}</p>
                      <p className={`text-base font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 pt-4 border-t border-current/10 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Resistivity (ρ):</span>
                        <span className="font-medium">{formatNumber(result.resistivity)} Ω·m</span>
                      </div>
                      {result.temperatureAdjusted && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Temp-Adjusted σ:</span>
                          <span className="font-medium">
                            {formatNumber(result.temperatureAdjusted)} {result.unit}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step-by-step Solution */}
                {steps.length > 0 && (
                  <Collapsible open={showSteps} onOpenChange={setShowSteps}>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between">
                        <span>Step-by-Step Solution</span>
                        <ChevronDown className={`h-4 w-4 transition-transform ${showSteps ? "rotate-180" : ""}`} />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="mt-2 p-4 bg-muted/50 rounded-lg space-y-1 font-mono text-sm">
                        {steps.map((step, index) => (
                          <p
                            key={index}
                            className={step.startsWith("Step") ? "font-semibold mt-2" : "text-muted-foreground"}
                          >
                            {step}
                          </p>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conductivity Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">σ = L / (R × A)</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>σ</strong> = Electrical conductivity (S/m)
                    </p>
                    <p>
                      <strong>L</strong> = Length of the conductor (m)
                    </p>
                    <p>
                      <strong>R</strong> = Resistance (Ω)
                    </p>
                    <p>
                      <strong>A</strong> = Cross-sectional area (m²)
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mt-4">
                    <p className="font-semibold text-foreground text-sm">σ_T = σ₀ / [1 + α(T − T₀)]</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Temperature adjustment formula where α is the temperature coefficient.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Material Conductivity Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {materialConductivity.map((material, index) => (
                      <div key={index} className="flex items-center justify-between p-2 rounded-lg bg-muted/50 text-sm">
                        <span className="font-medium">{material.name}</span>
                        <span className="text-muted-foreground text-xs">{material.conductivity}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Temperature Coefficients</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between p-2 rounded-lg bg-muted/50 text-sm">
                      <span>Copper</span>
                      <span className="font-mono">0.00393 /°C</span>
                    </div>
                    <div className="flex justify-between p-2 rounded-lg bg-muted/50 text-sm">
                      <span>Aluminum</span>
                      <span className="font-mono">0.00429 /°C</span>
                    </div>
                    <div className="flex justify-between p-2 rounded-lg bg-muted/50 text-sm">
                      <span>Silver</span>
                      <span className="font-mono">0.00380 /°C</span>
                    </div>
                    <div className="flex justify-between p-2 rounded-lg bg-muted/50 text-sm">
                      <span>Gold</span>
                      <span className="font-mono">0.00340 /°C</span>
                    </div>
                    <div className="flex justify-between p-2 rounded-lg bg-muted/50 text-sm">
                      <span>Iron</span>
                      <span className="font-mono">0.00651 /°C</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Electrical Conductivity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrical conductivity (σ) is a measure of a material's ability to conduct electric current. It is
                  the inverse of electrical resistivity (ρ). Materials with high conductivity, such as metals, allow
                  electrons to flow easily, while insulators like glass or rubber have very low conductivity and resist
                  the flow of electric current.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Conductivity is measured in Siemens per meter (S/m) in SI units. It depends on the material's
                  properties, temperature, and in some cases, the presence of impurities. Understanding conductivity is
                  essential in electrical engineering, materials science, and various industrial applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Conductivity Measurements</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrical conductivity measurements are crucial in many fields. In water quality testing,
                  conductivity indicates the presence of dissolved ions and minerals. In electronics, it helps select
                  appropriate materials for wiring and components. In metallurgy, conductivity testing can reveal
                  material purity and detect defects.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature significantly affects conductivity. For most metals, conductivity decreases as temperature
                  increases because thermal vibrations interfere with electron flow. This is why the temperature
                  adjustment feature is important for accurate calculations in real-world conditions.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Electrical conductivity calculations are estimates based on entered values and ideal conditions.
                  Actual conductivity may vary due to temperature, impurities, or material defects. Consult material
                  specifications or an electrical engineer for precise measurements in critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
