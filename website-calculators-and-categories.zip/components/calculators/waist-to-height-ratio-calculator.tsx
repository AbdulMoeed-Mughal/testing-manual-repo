"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Ruler,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"

interface WHtRResult {
  ratio: number
  category: string
  color: string
  bgColor: string
  description: string
}

export function WaistToHeightRatioCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [waist, setWaist] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [result, setResult] = useState<WHtRResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateWHtR = () => {
    setError("")
    setResult(null)

    const waistNum = Number.parseFloat(waist)
    if (isNaN(waistNum) || waistNum <= 0) {
      setError("Please enter a valid waist circumference greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    // Convert waist to cm if imperial
    const waistInCm = unitSystem === "imperial" ? waistNum * 2.54 : waistNum

    // Validate realistic ratio
    if (waistInCm > heightInCm) {
      setError("Waist circumference cannot be greater than height")
      return
    }

    const ratio = waistInCm / heightInCm
    const roundedRatio = Math.round(ratio * 1000) / 1000

    let category: string
    let color: string
    let bgColor: string
    let description: string

    if (roundedRatio < 0.4) {
      category = "Underweight Risk"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
      description = "Your ratio suggests you may be underweight. Consider consulting a healthcare provider."
    } else if (roundedRatio < 0.5) {
      category = "Healthy"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      description = "Excellent! Your waist-to-height ratio indicates a healthy body fat distribution."
    } else if (roundedRatio < 0.6) {
      category = "Increased Risk"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
      description = "Your ratio suggests increased health risk. Consider lifestyle modifications."
    } else {
      category = "High Risk"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
      description = "Your ratio indicates high health risk. Consult a healthcare professional for guidance."
    }

    setResult({ ratio: roundedRatio, category, color, bgColor, description })
  }

  const handleReset = () => {
    setWaist("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`My Waist-to-Height Ratio is ${result.ratio} (${result.category})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Waist-to-Height Ratio Result",
          text: `I calculated my Waist-to-Height Ratio using CalcHub! My ratio is ${result.ratio} (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWaist("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Ruler className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Waist-to-Height Ratio</CardTitle>
                    <CardDescription>Assess your body fat distribution</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setGender("male")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        gender === "male"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted-foreground/20 hover:border-muted-foreground/40"
                      }`}
                    >
                      Male
                    </button>
                    <button
                      onClick={() => setGender("female")}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        gender === "female"
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-muted-foreground/20 hover:border-muted-foreground/40"
                      }`}
                    >
                      Female
                    </button>
                  </div>
                </div>

                {/* Waist Input */}
                <div className="space-y-2">
                  <Label htmlFor="waist">Waist Circumference ({unitSystem === "metric" ? "cm" : "inches"})</Label>
                  <Input
                    id="waist"
                    type="number"
                    placeholder={`Enter waist in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                    value={waist}
                    onChange={(e) => setWaist(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">
                    Measure around your belly button at the narrowest point
                  </p>
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWHtR} className="w-full" size="lg">
                  Calculate Ratio
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Waist-to-Height Ratio</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.ratio}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-sm text-muted-foreground mt-2">{result.description}</p>
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Waist:</span>
                          <span className="font-medium">
                            {unitSystem === "metric"
                              ? `${waist} cm`
                              : `${waist} in (${(Number(waist) * 2.54).toFixed(1)} cm)`}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Height:</span>
                          <span className="font-medium">
                            {unitSystem === "metric"
                              ? `${heightCm} cm`
                              : `${heightFeet}'${heightInches}" (${(Number(heightFeet) * 12 + Number(heightInches)) * 2.54} cm)`}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Formula:</span>
                          <span className="font-medium">Waist ÷ Height</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Target:</span>
                          <span className="font-medium">{"< 0.5"}</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">WHtR Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Underweight Risk</span>
                      <span className="text-sm text-blue-600">{"< 0.4"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Healthy</span>
                      <span className="text-sm text-green-600">0.4 – 0.49</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Increased Risk</span>
                      <span className="text-sm text-yellow-600">0.5 – 0.59</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">High Risk</span>
                      <span className="text-sm text-red-600">≥ 0.6</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">WHtR Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">WHtR = Waist (cm) ÷ Height (cm)</p>
                  </div>
                  <p>
                    The key guideline is simple:{" "}
                    <strong>Keep your waist circumference to less than half your height.</strong>
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How to Measure Waist</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <ol className="list-decimal list-inside space-y-1">
                    <li>Stand upright and breathe normally</li>
                    <li>Locate the top of your hip bone</li>
                    <li>Find the bottom of your ribs</li>
                    <li>Measure midway between these points</li>
                    <li>Keep the tape level and snug (not tight)</li>
                  </ol>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Waist-to-Height Ratio (WHtR)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Waist-to-Height Ratio (WHtR) is a simple but powerful health screening tool that compares your
                  waist circumference to your height. Unlike BMI, which only considers weight and height, WHtR
                  specifically measures central obesity—the accumulation of fat around your midsection, which is
                  strongly linked to cardiovascular disease, type 2 diabetes, and metabolic syndrome.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Research has shown that WHtR is often a better predictor of health risks than BMI because it accounts
                  for body fat distribution. Two people with the same BMI can have very different health risk profiles
                  depending on where they carry their fat. Abdominal fat, in particular, is metabolically active and
                  releases inflammatory substances that contribute to chronic disease.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Why WHtR is Important</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The WHtR has gained popularity among health researchers and practitioners because of its simplicity
                  and effectiveness. The key message is easy to remember: keep your waist circumference to less than
                  half your height. This simple guideline applies across different age groups, genders, and ethnicities,
                  making it a universal tool for health assessment.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Advantages of WHtR</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Simple to calculate and remember</li>
                      <li>• Better predictor of health risk than BMI</li>
                      <li>• Works across all age groups</li>
                      <li>• Gender and ethnicity independent</li>
                      <li>• Focuses on dangerous abdominal fat</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Health Risks of High WHtR</h4>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>• Cardiovascular disease</li>
                      <li>• Type 2 diabetes</li>
                      <li>• Metabolic syndrome</li>
                      <li>• High blood pressure</li>
                      <li>• Sleep apnea</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Improving Your WHtR</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  If your WHtR indicates increased or high risk, there are several evidence-based strategies you can
                  adopt to reduce your waist circumference and improve your overall health:
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground">Nutrition</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Focus on whole foods, reduce refined carbohydrates and added sugars, increase fiber intake, and
                      practice portion control. A Mediterranean-style diet has been shown to reduce abdominal fat.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground">Exercise</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Combine aerobic exercise (walking, cycling, swimming) with resistance training. High-intensity
                      interval training (HIIT) is particularly effective for reducing abdominal fat.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground">Lifestyle</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Get adequate sleep (7-9 hours), manage stress levels, limit alcohol consumption, and avoid
                      smoking. Chronic stress increases cortisol, which promotes abdominal fat storage.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p>
                      Waist-to-height ratio is an estimate of health risk and should not replace professional medical
                      evaluation. This calculator is for educational purposes only. If you have concerns about your
                      health or body composition, please consult with a qualified healthcare provider for personalized
                      advice and comprehensive assessment.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
