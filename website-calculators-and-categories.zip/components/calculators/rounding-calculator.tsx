"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Table,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type RoundingMethod = "half-up" | "half-down" | "half-even" | "ceiling" | "floor" | "truncate"
type PrecisionType = "decimal" | "significant"

interface RoundingResult {
  originalValue: number
  roundedValue: number
  method: string
  precision: number
  precisionType: string
  steps: string[]
}

interface MethodComparison {
  method: string
  result: number
}

export function RoundingCalculator() {
  const [inputValue, setInputValue] = useState("")
  const [roundingMethod, setRoundingMethod] = useState<RoundingMethod>("half-up")
  const [precisionType, setPrecisionType] = useState<PrecisionType>("decimal")
  const [precision, setPrecision] = useState("2")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<RoundingResult | null>(null)
  const [methodComparison, setMethodComparison] = useState<MethodComparison[]>([])
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showComparison, setShowComparison] = useState(false)

  const methodNames: Record<RoundingMethod, string> = {
    "half-up": "Round Half Up (Standard)",
    "half-down": "Round Half Down",
    "half-even": "Round Half to Even (Banker's)",
    ceiling: "Round Up (Ceiling)",
    floor: "Round Down (Floor)",
    truncate: "Truncate",
  }

  const roundHalfUp = (num: number, places: number): number => {
    const multiplier = Math.pow(10, places)
    return Math.round(num * multiplier) / multiplier
  }

  const roundHalfDown = (num: number, places: number): number => {
    const multiplier = Math.pow(10, places)
    const shifted = num * multiplier
    const decimal = shifted - Math.floor(shifted)
    if (decimal === 0.5) {
      return Math.floor(shifted) / multiplier
    }
    return Math.round(shifted) / multiplier
  }

  const roundHalfEven = (num: number, places: number): number => {
    const multiplier = Math.pow(10, places)
    const shifted = num * multiplier
    const floor = Math.floor(shifted)
    const decimal = shifted - floor

    if (Math.abs(decimal - 0.5) < 1e-10) {
      // Exactly half - round to nearest even
      if (floor % 2 === 0) {
        return floor / multiplier
      } else {
        return (floor + 1) / multiplier
      }
    }
    return Math.round(shifted) / multiplier
  }

  const roundCeiling = (num: number, places: number): number => {
    const multiplier = Math.pow(10, places)
    return Math.ceil(num * multiplier) / multiplier
  }

  const roundFloor = (num: number, places: number): number => {
    const multiplier = Math.pow(10, places)
    return Math.floor(num * multiplier) / multiplier
  }

  const truncateNum = (num: number, places: number): number => {
    const multiplier = Math.pow(10, places)
    return Math.trunc(num * multiplier) / multiplier
  }

  const roundToSignificantFigures = (num: number, sigFigs: number, method: RoundingMethod): number => {
    if (num === 0) return 0
    const magnitude = Math.floor(Math.log10(Math.abs(num)))
    const places = sigFigs - magnitude - 1

    switch (method) {
      case "half-up":
        return roundHalfUp(num, places)
      case "half-down":
        return roundHalfDown(num, places)
      case "half-even":
        return roundHalfEven(num, places)
      case "ceiling":
        return roundCeiling(num, places)
      case "floor":
        return roundFloor(num, places)
      case "truncate":
        return truncateNum(num, places)
      default:
        return roundHalfUp(num, places)
    }
  }

  const applyRounding = (num: number, prec: number, method: RoundingMethod, precType: PrecisionType): number => {
    if (precType === "significant") {
      return roundToSignificantFigures(num, prec, method)
    }

    switch (method) {
      case "half-up":
        return roundHalfUp(num, prec)
      case "half-down":
        return roundHalfDown(num, prec)
      case "half-even":
        return roundHalfEven(num, prec)
      case "ceiling":
        return roundCeiling(num, prec)
      case "floor":
        return roundFloor(num, prec)
      case "truncate":
        return truncateNum(num, prec)
      default:
        return roundHalfUp(num, prec)
    }
  }

  const generateSteps = (num: number, prec: number, method: RoundingMethod, precType: PrecisionType): string[] => {
    const steps: string[] = []
    const numStr = num.toString()

    steps.push(`Original number: ${num}`)

    if (precType === "significant") {
      const magnitude = Math.floor(Math.log10(Math.abs(num)))
      steps.push(`Number of significant figures requested: ${prec}`)
      steps.push(`Magnitude (power of 10): ${magnitude}`)
      steps.push(`Decimal places needed: ${prec - magnitude - 1}`)
    } else {
      steps.push(`Decimal places requested: ${prec}`)
    }

    const multiplier =
      precType === "significant" ? Math.pow(10, prec - Math.floor(Math.log10(Math.abs(num))) - 1) : Math.pow(10, prec)

    const shifted = num * multiplier
    steps.push(`Multiply by ${multiplier}: ${shifted}`)

    const decimal = shifted - Math.floor(shifted)
    steps.push(`Decimal part: ${decimal.toFixed(10).replace(/0+$/, "").replace(/\.$/, "")}`)

    switch (method) {
      case "half-up":
        steps.push(`Round half up rule: If decimal ≥ 0.5, round up; otherwise round down`)
        steps.push(
          decimal >= 0.5 ? `${decimal.toFixed(2)} ≥ 0.5, so round up` : `${decimal.toFixed(2)} < 0.5, so round down`,
        )
        break
      case "half-down":
        steps.push(`Round half down rule: If decimal > 0.5, round up; otherwise round down`)
        steps.push(
          decimal > 0.5 ? `${decimal.toFixed(2)} > 0.5, so round up` : `${decimal.toFixed(2)} ≤ 0.5, so round down`,
        )
        break
      case "half-even":
        steps.push(`Banker's rounding: If exactly 0.5, round to nearest even number`)
        if (Math.abs(decimal - 0.5) < 1e-10) {
          const floor = Math.floor(shifted)
          steps.push(`Exactly 0.5: nearest even is ${floor % 2 === 0 ? floor : floor + 1}`)
        } else {
          steps.push(`Not exactly 0.5, standard rounding applies`)
        }
        break
      case "ceiling":
        steps.push(`Ceiling rule: Always round up (toward positive infinity)`)
        break
      case "floor":
        steps.push(`Floor rule: Always round down (toward negative infinity)`)
        break
      case "truncate":
        steps.push(`Truncate rule: Remove decimal places (toward zero)`)
        break
    }

    const rounded = applyRounding(num, prec, method, precType)
    steps.push(`Divide by ${multiplier}: ${rounded}`)
    steps.push(`Final result: ${rounded}`)

    return steps
  }

  const calculateRounding = () => {
    setError("")
    setResult(null)
    setMethodComparison([])

    const num = Number.parseFloat(inputValue)
    if (isNaN(num)) {
      setError("Please enter a valid number")
      return
    }

    const prec = Number.parseInt(precision)
    if (isNaN(prec)) {
      setError("Please enter a valid precision")
      return
    }

    if (precisionType === "significant" && prec < 1) {
      setError("Significant figures must be at least 1")
      return
    }

    const rounded = applyRounding(num, prec, roundingMethod, precisionType)
    const steps = showSteps ? generateSteps(num, prec, roundingMethod, precisionType) : []

    setResult({
      originalValue: num,
      roundedValue: rounded,
      method: methodNames[roundingMethod],
      precision: prec,
      precisionType: precisionType === "decimal" ? "Decimal Places" : "Significant Figures",
      steps,
    })

    // Generate comparison of all methods
    const methods: RoundingMethod[] = ["half-up", "half-down", "half-even", "ceiling", "floor", "truncate"]
    const comparison = methods.map((method) => ({
      method: methodNames[method],
      result: applyRounding(num, prec, method, precisionType),
    }))
    setMethodComparison(comparison)
  }

  const handleReset = () => {
    setInputValue("")
    setPrecision("2")
    setRoundingMethod("half-up")
    setPrecisionType("decimal")
    setShowSteps(false)
    setResult(null)
    setMethodComparison([])
    setError("")
    setCopied(false)
    setShowComparison(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `${result.originalValue} rounded to ${result.precision} ${result.precisionType.toLowerCase()} using ${result.method}: ${result.roundedValue}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Rounding Calculator</CardTitle>
                    <CardDescription>Round numbers using various methods</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Number Input */}
                <div className="space-y-2">
                  <Label htmlFor="number">Number to Round</Label>
                  <Input
                    id="number"
                    type="text"
                    placeholder="Enter a number (e.g., 3.14159, -2.5, 1234.567)"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                  />
                </div>

                {/* Rounding Method */}
                <div className="space-y-2">
                  <Label htmlFor="method">Rounding Method</Label>
                  <Select value={roundingMethod} onValueChange={(v) => setRoundingMethod(v as RoundingMethod)}>
                    <SelectTrigger id="method">
                      <SelectValue placeholder="Select rounding method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="half-up">Round Half Up (Standard)</SelectItem>
                      <SelectItem value="half-down">Round Half Down</SelectItem>
                      <SelectItem value="half-even">Round Half to Even (Banker's)</SelectItem>
                      <SelectItem value="ceiling">Round Up (Ceiling)</SelectItem>
                      <SelectItem value="floor">Round Down (Floor)</SelectItem>
                      <SelectItem value="truncate">Truncate</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Precision Type */}
                <div className="space-y-2">
                  <Label htmlFor="precisionType">Precision Type</Label>
                  <Select value={precisionType} onValueChange={(v) => setPrecisionType(v as PrecisionType)}>
                    <SelectTrigger id="precisionType">
                      <SelectValue placeholder="Select precision type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="decimal">Decimal Places</SelectItem>
                      <SelectItem value="significant">Significant Figures</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Precision Value */}
                <div className="space-y-2">
                  <Label htmlFor="precision">
                    {precisionType === "decimal" ? "Decimal Places" : "Significant Figures"}
                  </Label>
                  <Input
                    id="precision"
                    type="number"
                    placeholder={precisionType === "decimal" ? "e.g., 2 for 0.00" : "e.g., 3 for 3 sig figs"}
                    value={precision}
                    onChange={(e) => setPrecision(e.target.value)}
                    min={precisionType === "significant" ? "1" : "-10"}
                    max="15"
                  />
                  <p className="text-xs text-muted-foreground">
                    {precisionType === "decimal"
                      ? "Use negative values to round to tens (-1), hundreds (-2), etc."
                      : "Minimum 1 significant figure"}
                  </p>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <Label htmlFor="show-steps" className="cursor-pointer">
                    Show step-by-step explanation
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRounding} className="w-full" size="lg">
                  Round Number
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Rounded Result</p>
                      <p className="text-4xl font-bold text-blue-600 mb-2 font-mono">{result.roundedValue}</p>
                      <p className="text-sm text-muted-foreground">
                        {result.method} • {result.precision} {result.precisionType}
                      </p>
                    </div>

                    {/* Steps */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-blue-100">
                        <p className="font-medium text-sm mb-2">Step-by-step:</p>
                        <ol className="text-sm text-muted-foreground space-y-1">
                          {result.steps.map((step, index) => (
                            <li key={index} className="flex gap-2">
                              <span className="font-medium text-blue-600">{index + 1}.</span>
                              <span>{step}</span>
                            </li>
                          ))}
                        </ol>
                      </div>
                    )}

                    {/* Method Comparison Toggle */}
                    <button
                      onClick={() => setShowComparison(!showComparison)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-blue-600 hover:text-blue-700"
                    >
                      <Table className="h-4 w-4" />
                      Compare all methods
                      {showComparison ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showComparison && methodComparison.length > 0 && (
                      <div className="mt-3 p-3 bg-white rounded-lg border border-blue-100">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left py-2 font-medium">Method</th>
                              <th className="text-right py-2 font-medium">Result</th>
                            </tr>
                          </thead>
                          <tbody>
                            {methodComparison.map((item, index) => (
                              <tr
                                key={index}
                                className={`border-b last:border-0 ${item.method === result.method ? "bg-blue-50" : ""}`}
                              >
                                <td className="py-2 text-muted-foreground">{item.method}</td>
                                <td className="py-2 text-right font-mono">{item.result}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rounding Methods</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Half Up (Standard)</span>
                      <p className="text-blue-600 text-xs mt-1">Round 0.5 up: 2.5 → 3, 3.5 → 4</p>
                    </div>
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Half Down</span>
                      <p className="text-green-600 text-xs mt-1">Round 0.5 down: 2.5 → 2, 3.5 → 3</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Half Even (Banker's)</span>
                      <p className="text-purple-600 text-xs mt-1">Round 0.5 to even: 2.5 → 2, 3.5 → 4</p>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Ceiling / Floor</span>
                      <p className="text-orange-600 text-xs mt-1">Always up (⌈⌉) or always down (⌊⌋)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <span className="font-medium text-gray-700">Truncate</span>
                      <p className="text-gray-600 text-xs mt-1">Remove decimals toward zero</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Precision Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-xs space-y-1">
                    <p>
                      <strong>Decimal Places:</strong>
                    </p>
                    <p>123.456 → 2 places = 123.46</p>
                    <p>123.456 → -1 places = 120</p>
                    <p>
                      <strong className="block mt-2">Significant Figures:</strong>
                    </p>
                    <p>123.456 → 3 sig figs = 123</p>
                    <p>0.00456 → 2 sig figs = 0.0046</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Rounding?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Rounding is a mathematical process of approximating a number to a nearby value with fewer significant
                  digits or decimal places. It's essential in everyday calculations, scientific measurements, financial
                  transactions, and computer science. Different rounding methods exist to handle the ambiguous case when
                  the digit to be dropped is exactly 5, each with specific use cases and applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The choice of rounding method can significantly impact results, especially in iterative calculations
                  or when dealing with large datasets. Banker's rounding (round half to even) is commonly used in
                  financial applications to minimize cumulative bias, while standard rounding (round half up) is more
                  intuitive for general purposes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter the number you want to round, select a rounding method, choose between decimal places or
                  significant figures for precision, and specify the precision level. The calculator will apply your
                  chosen rounding method and display the result. Enable step-by-step explanation to see exactly how the
                  rounding is performed, which is helpful for learning or verification.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Use negative precision values for decimal places to round to tens (-1), hundreds (-2), or thousands
                  (-3). The method comparison feature allows you to see how different rounding methods would affect the
                  same number, which is useful when choosing the most appropriate method for your application.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Rounding results depend on the selected method and precision. Different rounding rules may produce
                  different outcomes for the same number. This calculator is for educational and general purposes. For
                  critical financial or scientific applications, verify results and consult relevant standards for the
                  appropriate rounding method.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
