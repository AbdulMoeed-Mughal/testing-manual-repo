"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Layers,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface PlywoodResult {
  surfaceArea: number
  sheetArea: number
  sheetsNeeded: number
  sheetsWithWaste: number
  totalSurfaces: number
}

export function PlywoodSheetCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [surfaceLength, setSurfaceLength] = useState("")
  const [surfaceWidth, setSurfaceWidth] = useState("")
  const [sheetLength, setSheetLength] = useState(unitSystem === "metric" ? "2.44" : "8")
  const [sheetWidth, setSheetWidth] = useState(unitSystem === "metric" ? "1.22" : "4")
  const [wastePercentage, setWastePercentage] = useState("10")
  const [numberOfSurfaces, setNumberOfSurfaces] = useState("1")
  const [result, setResult] = useState<PlywoodResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculatePlywood = () => {
    setError("")
    setResult(null)

    const length = Number.parseFloat(surfaceLength)
    const width = Number.parseFloat(surfaceWidth)
    const sheetL = Number.parseFloat(sheetLength)
    const sheetW = Number.parseFloat(sheetWidth)
    const waste = Number.parseFloat(wastePercentage)
    const surfaces = Number.parseInt(numberOfSurfaces)

    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid surface length greater than 0")
      return
    }
    if (isNaN(width) || width <= 0) {
      setError("Please enter a valid surface width greater than 0")
      return
    }
    if (isNaN(sheetL) || sheetL <= 0) {
      setError("Please enter a valid sheet length greater than 0")
      return
    }
    if (isNaN(sheetW) || sheetW <= 0) {
      setError("Please enter a valid sheet width greater than 0")
      return
    }
    if (isNaN(waste) || waste < 0) {
      setError("Waste percentage must be 0 or greater")
      return
    }
    if (isNaN(surfaces) || surfaces < 1) {
      setError("Number of surfaces must be at least 1")
      return
    }

    // Calculate areas
    const surfaceArea = length * width * surfaces
    const sheetArea = sheetL * sheetW

    // Calculate sheets needed
    const sheetsNeeded = surfaceArea / sheetArea
    const sheetsWithWaste = sheetsNeeded * (1 + waste / 100)

    setResult({
      surfaceArea: Math.round(surfaceArea * 100) / 100,
      sheetArea: Math.round(sheetArea * 100) / 100,
      sheetsNeeded: Math.round(sheetsNeeded * 100) / 100,
      sheetsWithWaste: Math.ceil(sheetsWithWaste),
      totalSurfaces: surfaces,
    })
  }

  const handleReset = () => {
    setSurfaceLength("")
    setSurfaceWidth("")
    setSheetLength(unitSystem === "metric" ? "2.44" : "8")
    setSheetWidth(unitSystem === "metric" ? "1.22" : "4")
    setWastePercentage("10")
    setNumberOfSurfaces("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Plywood Sheet Calculation:
Surface Area: ${result.surfaceArea} ${unitSystem === "metric" ? "m²" : "ft²"}
Sheet Area: ${result.sheetArea} ${unitSystem === "metric" ? "m²" : "ft²"}
Sheets Required: ${result.sheetsWithWaste} sheets (including ${wastePercentage}% waste)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Plywood Sheet Calculation",
          text: `I need ${result.sheetsWithWaste} plywood sheets to cover ${result.surfaceArea} ${unitSystem === "metric" ? "m²" : "ft²"} (including ${wastePercentage}% waste). Calculated with CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    const newSystem = unitSystem === "metric" ? "imperial" : "metric"
    setUnitSystem(newSystem)
    setSurfaceLength("")
    setSurfaceWidth("")
    setSheetLength(newSystem === "metric" ? "2.44" : "8")
    setSheetWidth(newSystem === "metric" ? "1.22" : "4")
    setResult(null)
    setError("")
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"
  const areaUnit = unitSystem === "metric" ? "m²" : "ft²"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Plywood Sheet Calculator</CardTitle>
                    <CardDescription>Calculate sheets needed for your project</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Surface Dimensions */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Surface Dimensions</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder={`Length (${lengthUnit})`}
                        value={surfaceLength}
                        onChange={(e) => setSurfaceLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder={`Width (${lengthUnit})`}
                        value={surfaceWidth}
                        onChange={(e) => setSurfaceWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                </div>

                {/* Sheet Dimensions */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Plywood Sheet Size</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder={`Length (${lengthUnit})`}
                        value={sheetLength}
                        onChange={(e) => setSheetLength(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder={`Width (${lengthUnit})`}
                        value={sheetWidth}
                        onChange={(e) => setSheetWidth(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Standard: {unitSystem === "metric" ? "2.44m × 1.22m (8' × 4')" : "8' × 4' (2.44m × 1.22m)"}
                  </p>
                </div>

                {/* Number of Surfaces */}
                <div className="space-y-2">
                  <Label htmlFor="surfaces">Number of Surfaces / Layers</Label>
                  <Input
                    id="surfaces"
                    type="number"
                    placeholder="Enter number of surfaces"
                    value={numberOfSurfaces}
                    onChange={(e) => setNumberOfSurfaces(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="waste">Waste Allowance (%)</Label>
                  <Input
                    id="waste"
                    type="number"
                    placeholder="Enter waste percentage"
                    value={wastePercentage}
                    onChange={(e) => setWastePercentage(e.target.value)}
                    min="0"
                    max="50"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">Recommended: 5-10% for cuts and waste</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePlywood} className="w-full" size="lg">
                  Calculate Sheets
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Plywood Sheets Required</p>
                      <p className="text-5xl font-bold text-amber-600 mb-2">{result.sheetsWithWaste}</p>
                      <p className="text-lg font-semibold text-amber-700">sheets</p>
                    </div>

                    {/* Details */}
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div className="p-2 bg-white/60 rounded-lg text-center">
                        <p className="text-muted-foreground">Surface Area</p>
                        <p className="font-semibold">
                          {result.surfaceArea} {areaUnit}
                        </p>
                      </div>
                      <div className="p-2 bg-white/60 rounded-lg text-center">
                        <p className="text-muted-foreground">Sheet Area</p>
                        <p className="font-semibold">
                          {result.sheetArea} {areaUnit}
                        </p>
                      </div>
                      <div className="p-2 bg-white/60 rounded-lg text-center">
                        <p className="text-muted-foreground">Exact Sheets</p>
                        <p className="font-semibold">{result.sheetsNeeded}</p>
                      </div>
                      <div className="p-2 bg-white/60 rounded-lg text-center">
                        <p className="text-muted-foreground">With {wastePercentage}% Waste</p>
                        <p className="font-semibold">{result.sheetsWithWaste}</p>
                      </div>
                    </div>

                    {/* Step-by-step breakdown */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="flex items-center justify-between w-full p-2 bg-white/60 rounded-lg text-sm font-medium hover:bg-white/80 transition-colors"
                      >
                        <span>Step-by-Step Calculation</span>
                        {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                      {showSteps && (
                        <div className="mt-2 p-3 bg-white/60 rounded-lg text-sm space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">1. Surface Area:</span>
                            <span className="font-mono">
                              {surfaceLength} × {surfaceWidth}
                              {result.totalSurfaces > 1 ? ` × ${result.totalSurfaces}` : ""} = {result.surfaceArea}{" "}
                              {areaUnit}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">2. Sheet Area:</span>
                            <span className="font-mono">
                              {sheetLength} × {sheetWidth} = {result.sheetArea} {areaUnit}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">3. Sheets (exact):</span>
                            <span className="font-mono">
                              {result.surfaceArea} ÷ {result.sheetArea} = {result.sheetsNeeded}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">4. With waste:</span>
                            <span className="font-mono">
                              {result.sheetsNeeded} × (1 + {wastePercentage}%) = {result.sheetsWithWaste}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Plywood Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Full Sheet</span>
                      <span className="text-amber-600">8' × 4' (2.44m × 1.22m)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Half Sheet</span>
                      <span className="text-muted-foreground">4' × 4' (1.22m × 1.22m)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Quarter Sheet</span>
                      <span className="text-muted-foreground">4' × 2' (1.22m × 0.61m)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Oversized</span>
                      <span className="text-muted-foreground">10' × 4' (3.05m × 1.22m)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Thicknesses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <p className="font-medium">1/4" (6mm)</p>
                      <p className="text-xs text-muted-foreground">Backing, crafts</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <p className="font-medium">3/8" (9mm)</p>
                      <p className="text-xs text-muted-foreground">Light panels</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <p className="font-medium">1/2" (12mm)</p>
                      <p className="text-xs text-muted-foreground">Walls, shelving</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <p className="font-medium">5/8" (15mm)</p>
                      <p className="text-xs text-muted-foreground">Subfloors</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <p className="font-medium">3/4" (18mm)</p>
                      <p className="text-xs text-muted-foreground">Floors, furniture</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg text-center">
                      <p className="font-medium">1" (25mm)</p>
                      <p className="text-xs text-muted-foreground">Heavy-duty</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Waste Allowance Guide</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Simple rectangular areas</span>
                    <span className="font-medium text-foreground">5%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Standard rooms with cuts</span>
                    <span className="font-medium text-foreground">10%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Complex shapes / angles</span>
                    <span className="font-medium text-foreground">15%</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted rounded">
                    <span>Intricate patterns</span>
                    <span className="font-medium text-foreground">20%+</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800">
                <p className="font-medium mb-1">Estimation Disclaimer</p>
                <p>
                  Results are estimates. Actual plywood requirements may vary due to cutting patterns, overlaps, board
                  orientation, and site conditions. Always consult with a professional for precise measurements.
                </p>
              </div>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Plywood Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating the correct number of plywood sheets for a project is essential for budgeting and
                  minimizing waste. Plywood is sold in standard sheet sizes, with the most common being 4 feet by 8 feet
                  (1.22m × 2.44m). Understanding how to calculate coverage helps ensure you purchase the right amount of
                  material while accounting for cuts and waste.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The basic calculation involves dividing the total surface area to be covered by the area of a single
                  plywood sheet. However, real-world applications require additional material to account for cutting
                  waste, grain direction requirements, and the inability to use every scrap piece effectively.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Plywood Types and Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Construction Plywood</h4>
                    <p className="text-sm text-muted-foreground">
                      Used for structural applications like subfloors, roof sheathing, and wall sheathing. Typically CDX
                      grade with exterior glue.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Marine Plywood</h4>
                    <p className="text-sm text-muted-foreground">
                      High-quality plywood with waterproof glue, ideal for boat building, outdoor furniture, and areas
                      with high moisture exposure.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Cabinet Grade Plywood</h4>
                    <p className="text-sm text-muted-foreground">
                      Features smooth, defect-free face veneers suitable for visible surfaces in cabinets, furniture,
                      and decorative projects.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Pressure-Treated Plywood</h4>
                    <p className="text-sm text-muted-foreground">
                      Chemically treated to resist rot, decay, and insects. Used for ground contact applications and
                      outdoor structures.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Measure twice:</strong> Always double-check your measurements before purchasing materials
                      to avoid costly mistakes.
                    </span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Consider grain direction:</strong> Some applications require consistent grain direction,
                      which may increase waste.
                    </span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Plan your cuts:</strong> Sketch out a cutting diagram to maximize material usage and
                      minimize waste.
                    </span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Account for saw kerf:</strong> Each cut removes about 1/8" of material, which adds up over
                      multiple cuts.
                    </span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>
                      <strong>Buy extra:</strong> It's better to have a spare sheet than to make an extra trip to the
                      store mid-project.
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
