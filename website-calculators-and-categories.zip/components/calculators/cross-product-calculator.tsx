"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, Share2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface CrossProductResult {
  resultant: { x: number; y: number; z: number }
  magnitude: number
  unitVector: { x: number; y: number; z: number } | null
  angleBetween: number | null
  magnitudeA: number
  magnitudeB: number
  steps: string[]
}

export function CrossProductCalculator() {
  const [vectorA, setVectorA] = useState({ x: "", y: "", z: "" })
  const [vectorB, setVectorB] = useState({ x: "", y: "", z: "" })
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<CrossProductResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const ax = Number.parseFloat(vectorA.x)
    const ay = Number.parseFloat(vectorA.y)
    const az = Number.parseFloat(vectorA.z)
    const bx = Number.parseFloat(vectorB.x)
    const by = Number.parseFloat(vectorB.y)
    const bz = Number.parseFloat(vectorB.z)

    if ([ax, ay, az, bx, by, bz].some(isNaN)) {
      setError("Please enter valid numeric values for all vector components")
      return
    }

    const steps: string[] = []

    // Step 1: Display vectors
    steps.push(`Vector A = (${ax}, ${ay}, ${az})`)
    steps.push(`Vector B = (${bx}, ${by}, ${bz})`)

    // Step 2: Cross product formula using determinant method
    steps.push(`Using the determinant method:`)
    steps.push(`A × B = |i  j  k |`)
    steps.push(`        |${ax}  ${ay}  ${az}|`)
    steps.push(`        |${bx}  ${by}  ${bz}|`)

    // Step 3: Calculate components
    const rx = ay * bz - az * by
    const ry = az * bx - ax * bz
    const rz = ax * by - ay * bx

    steps.push(``)
    steps.push(`Rx = (${ay})(${bz}) - (${az})(${by}) = ${ay * bz} - ${az * by} = ${rx}`)
    steps.push(`Ry = (${az})(${bx}) - (${ax})(${bz}) = ${az * bx} - ${ax * bz} = ${ry}`)
    steps.push(`Rz = (${ax})(${by}) - (${ay})(${bx}) = ${ax * by} - ${ay * bx} = ${rz}`)

    steps.push(``)
    steps.push(`Resultant R = (${rx}, ${ry}, ${rz})`)

    // Step 4: Calculate magnitude
    const magnitude = Math.sqrt(rx * rx + ry * ry + rz * rz)
    steps.push(``)
    steps.push(`|R| = √(${rx}² + ${ry}² + ${rz}²)`)
    steps.push(`|R| = √(${rx * rx} + ${ry * ry} + ${rz * rz})`)
    steps.push(`|R| = √${rx * rx + ry * ry + rz * rz}`)
    steps.push(`|R| = ${magnitude.toFixed(6)}`)

    // Calculate magnitudes of A and B
    const magnitudeA = Math.sqrt(ax * ax + ay * ay + az * az)
    const magnitudeB = Math.sqrt(bx * bx + by * by + bz * bz)

    steps.push(``)
    steps.push(`|A| = √(${ax}² + ${ay}² + ${az}²) = ${magnitudeA.toFixed(6)}`)
    steps.push(`|B| = √(${bx}² + ${by}² + ${bz}²) = ${magnitudeB.toFixed(6)}`)

    // Unit vector (if magnitude is non-zero)
    let unitVector: { x: number; y: number; z: number } | null = null
    if (magnitude > 0) {
      unitVector = {
        x: rx / magnitude,
        y: ry / magnitude,
        z: rz / magnitude,
      }
      steps.push(``)
      steps.push(`Unit vector R̂ = R / |R|`)
      steps.push(`R̂ = (${unitVector.x.toFixed(6)}, ${unitVector.y.toFixed(6)}, ${unitVector.z.toFixed(6)})`)
    }

    // Angle between vectors using |A × B| = |A||B|sin(θ)
    let angleBetween: number | null = null
    if (magnitudeA > 0 && magnitudeB > 0) {
      const sinTheta = magnitude / (magnitudeA * magnitudeB)
      // Clamp to [-1, 1] to handle floating point errors
      const clampedSin = Math.max(-1, Math.min(1, sinTheta))
      angleBetween = Math.asin(clampedSin) * (180 / Math.PI)

      steps.push(``)
      steps.push(`Angle θ between vectors:`)
      steps.push(`|A × B| = |A||B|sin(θ)`)
      steps.push(`sin(θ) = |A × B| / (|A||B|)`)
      steps.push(`sin(θ) = ${magnitude.toFixed(6)} / (${magnitudeA.toFixed(6)} × ${magnitudeB.toFixed(6)})`)
      steps.push(`sin(θ) = ${sinTheta.toFixed(6)}`)
      steps.push(`θ = arcsin(${sinTheta.toFixed(6)}) = ${angleBetween.toFixed(4)}°`)
    }

    setResult({
      resultant: { x: rx, y: ry, z: rz },
      magnitude,
      unitVector,
      angleBetween,
      magnitudeA,
      magnitudeB,
      steps,
    })
  }

  const handleReset = () => {
    setVectorA({ x: "", y: "", z: "" })
    setVectorB({ x: "", y: "", z: "" })
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Cross Product: A × B = (${result.resultant.x}, ${result.resultant.y}, ${result.resultant.z}), Magnitude: ${result.magnitude.toFixed(6)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Cross Product Result",
          text: `Cross Product: A × B = (${result.resultant.x}, ${result.resultant.y}, ${result.resultant.z}), Magnitude: ${result.magnitude.toFixed(6)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const formatNumber = (n: number) => {
    if (Number.isInteger(n)) return n.toString()
    return n.toFixed(6).replace(/\.?0+$/, "")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <span className="text-lg font-bold">×</span>
                  </div>
                  <div>
                    <CardTitle className="text-xl">Cross Product Calculator</CardTitle>
                    <CardDescription>Calculate the cross product of two 3D vectors</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Vector A */}
                <div className="space-y-2">
                  <Label className="font-medium">Vector A</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label htmlFor="ax" className="text-xs text-muted-foreground">
                        x₁
                      </Label>
                      <Input
                        id="ax"
                        type="number"
                        placeholder="0"
                        value={vectorA.x}
                        onChange={(e) => setVectorA({ ...vectorA, x: e.target.value })}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="ay" className="text-xs text-muted-foreground">
                        y₁
                      </Label>
                      <Input
                        id="ay"
                        type="number"
                        placeholder="0"
                        value={vectorA.y}
                        onChange={(e) => setVectorA({ ...vectorA, y: e.target.value })}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="az" className="text-xs text-muted-foreground">
                        z₁
                      </Label>
                      <Input
                        id="az"
                        type="number"
                        placeholder="0"
                        value={vectorA.z}
                        onChange={(e) => setVectorA({ ...vectorA, z: e.target.value })}
                        step="any"
                      />
                    </div>
                  </div>
                </div>

                {/* Vector B */}
                <div className="space-y-2">
                  <Label className="font-medium">Vector B</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label htmlFor="bx" className="text-xs text-muted-foreground">
                        x₂
                      </Label>
                      <Input
                        id="bx"
                        type="number"
                        placeholder="0"
                        value={vectorB.x}
                        onChange={(e) => setVectorB({ ...vectorB, x: e.target.value })}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="by" className="text-xs text-muted-foreground">
                        y₂
                      </Label>
                      <Input
                        id="by"
                        type="number"
                        placeholder="0"
                        value={vectorB.y}
                        onChange={(e) => setVectorB({ ...vectorB, y: e.target.value })}
                        step="any"
                      />
                    </div>
                    <div>
                      <Label htmlFor="bz" className="text-xs text-muted-foreground">
                        z₂
                      </Label>
                      <Input
                        id="bz"
                        type="number"
                        placeholder="0"
                        value={vectorB.z}
                        onChange={(e) => setVectorB({ ...vectorB, z: e.target.value })}
                        step="any"
                      />
                    </div>
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between py-2">
                  <Label htmlFor="show-steps" className="text-sm">
                    Show step-by-step solution
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Cross Product
                </Button>

                {result && (
                  <div className="space-y-4">
                    {/* Resultant Vector */}
                    <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">Cross Product (A × B)</p>
                        <p className="text-2xl font-bold text-blue-600 font-mono">
                          ({formatNumber(result.resultant.x)}, {formatNumber(result.resultant.y)},{" "}
                          {formatNumber(result.resultant.z)})
                        </p>
                      </div>
                    </div>

                    {/* Additional Results */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground">Magnitude |R|</p>
                        <p className="font-semibold font-mono">{formatNumber(result.magnitude)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground">Angle (θ)</p>
                        <p className="font-semibold font-mono">
                          {result.angleBetween !== null ? `${result.angleBetween.toFixed(2)}°` : "N/A"}
                        </p>
                      </div>
                    </div>

                    {result.unitVector && (
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground">Unit Vector R̂</p>
                        <p className="font-semibold font-mono text-sm">
                          ({formatNumber(result.unitVector.x)}, {formatNumber(result.unitVector.y)},{" "}
                          {formatNumber(result.unitVector.z)})
                        </p>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground">|A|</p>
                        <p className="font-semibold font-mono">{formatNumber(result.magnitudeA)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50 text-center">
                        <p className="text-xs text-muted-foreground">|B|</p>
                        <p className="font-semibold font-mono">{formatNumber(result.magnitudeB)}</p>
                      </div>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="p-4 rounded-lg bg-muted/30 border">
                        <p className="font-medium mb-2 text-sm">Step-by-Step Solution:</p>
                        <div className="space-y-1 text-sm font-mono text-muted-foreground">
                          {result.steps.map((step, index) => (
                            <p key={index} className={step === "" ? "h-2" : ""}>
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cross Product Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">A × B = (y₁z₂ − z₁y₂, z₁x₂ − x₁z₂, x₁y₂ − y₁x₂)</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>Determinant Form:</strong>
                    </p>
                    <div className="p-2 bg-muted/50 rounded font-mono text-xs text-center">
                      <p>| i j k |</p>
                      <p>| x₁ y₁ z₁ |</p>
                      <p>| x₂ y₂ z₂ |</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Properties</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-2">
                      <span className="text-blue-600 font-bold">1.</span>
                      <p className="text-muted-foreground">
                        <strong>Anti-commutative:</strong> A × B = −(B × A)
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-blue-600 font-bold">2.</span>
                      <p className="text-muted-foreground">
                        <strong>Perpendicular:</strong> Result is perpendicular to both input vectors
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-blue-600 font-bold">3.</span>
                      <p className="text-muted-foreground">
                        <strong>Magnitude:</strong> |A × B| = |A||B|sin(θ)
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-blue-600 font-bold">4.</span>
                      <p className="text-muted-foreground">
                        <strong>Area:</strong> |A × B| equals parallelogram area spanned by A and B
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">(1,0,0) × (0,1,0)</span>
                      <span className="font-mono text-blue-600">(0,0,1)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">(0,1,0) × (0,0,1)</span>
                      <span className="font-mono text-blue-600">(1,0,0)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">(0,0,1) × (1,0,0)</span>
                      <span className="font-mono text-blue-600">(0,1,0)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono">(2,3,4) × (5,6,7)</span>
                      <span className="font-mono text-blue-600">(-3,6,-3)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Cross Product?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The cross product (also called the vector product) is a binary operation on two vectors in
                  three-dimensional space. Unlike the dot product which produces a scalar, the cross product produces
                  another vector that is perpendicular to both input vectors. This makes it extremely useful in physics
                  and engineering for finding normal vectors, calculating torque, and determining angular momentum.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The direction of the resulting vector follows the right-hand rule: if you curl your fingers from
                  vector A toward vector B, your thumb points in the direction of A × B. The magnitude of the cross
                  product equals the area of the parallelogram formed by the two vectors, which can be calculated as
                  |A||B|sin(θ) where θ is the angle between them.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Cross product calculations follow standard 3D vector formulas. Results depend on correct vector input.
                  This calculator is for educational purposes and should be verified for critical applications in
                  physics, engineering, or computer graphics.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
