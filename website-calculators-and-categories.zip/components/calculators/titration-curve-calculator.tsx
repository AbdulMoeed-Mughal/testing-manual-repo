"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Beaker, TrendingUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type TitrationType = "strong-strong" | "weak-strong" | "strong-weak" | "weak-weak"

interface TitrationResult {
  equivalenceVolume: number
  equivalencePH: number
  curveData: { volume: number; pH: number }[]
  bufferRegion: { start: number; end: number } | null
  halfEquivalencePH: number | null
}

export function TitrationCurveCalculator() {
  const [titrationType, setTitrationType] = useState<TitrationType>("strong-strong")
  const [analyteConc, setAnalyteConc] = useState("")
  const [analyteVolume, setAnalyteVolume] = useState("")
  const [analytePka, setAnalytePka] = useState("")
  const [titrantConc, setTitrantConc] = useState("")
  const [result, setResult] = useState<TitrationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateTitrationCurve = () => {
    setError("")
    setResult(null)

    const Ca = parseFloat(analyteConc)
    const Va = parseFloat(analyteVolume)
    const Ct = parseFloat(titrantConc)
    const pKa = parseFloat(analytePka)

    if (isNaN(Ca) || Ca <= 0) {
      setError("Please enter a valid analyte concentration greater than 0")
      return
    }
    if (isNaN(Va) || Va <= 0) {
      setError("Please enter a valid analyte volume greater than 0")
      return
    }
    if (isNaN(Ct) || Ct <= 0) {
      setError("Please enter a valid titrant concentration greater than 0")
      return
    }
    if ((titrationType === "weak-strong" || titrationType === "weak-weak") && (isNaN(pKa) || pKa <= 0 || pKa >= 14)) {
      setError("Please enter a valid pKa between 0 and 14")
      return
    }

    // Calculate equivalence point volume
    const molesAnalyte = Ca * Va / 1000 // Convert mL to L
    const equivalenceVolume = (molesAnalyte / Ct) * 1000 // Back to mL

    // Generate curve data points
    const curveData: { volume: number; pH: number }[] = []
    const maxVolume = equivalenceVolume * 1.5
    const numPoints = 100

    for (let i = 0; i <= numPoints; i++) {
      const Vt = (i / numPoints) * maxVolume
      const pH = calculatePH(Ca, Va, Ct, Vt, pKa, titrationType)
      curveData.push({ volume: Math.round(Vt * 100) / 100, pH: Math.round(pH * 100) / 100 })
    }

    // Calculate equivalence point pH
    const equivalencePH = calculatePH(Ca, Va, Ct, equivalenceVolume, pKa, titrationType)

    // Calculate half-equivalence point for weak acid/base
    let halfEquivalencePH: number | null = null
    let bufferRegion: { start: number; end: number } | null = null

    if (titrationType === "weak-strong" || titrationType === "weak-weak") {
      halfEquivalencePH = pKa
      bufferRegion = {
        start: equivalenceVolume * 0.1,
        end: equivalenceVolume * 0.9
      }
    }

    setResult({
      equivalenceVolume: Math.round(equivalenceVolume * 100) / 100,
      equivalencePH: Math.round(equivalencePH * 100) / 100,
      curveData,
      bufferRegion,
      halfEquivalencePH
    })
  }

  const calculatePH = (Ca: number, Va: number, Ct: number, Vt: number, pKa: number, type: TitrationType): number => {
    const molesAnalyte = Ca * Va / 1000
    const molesTitrant = Ct * Vt / 1000
    const totalVolume = (Va + Vt) / 1000 // in L

    if (type === "strong-strong") {
      // Strong acid titrated with strong base
      if (Vt === 0) {
        return -Math.log10(Ca)
      }
      const excessMoles = molesAnalyte - molesTitrant
      if (excessMoles > 0.0001) {
        // Before equivalence - excess acid
        const H = excessMoles / totalVolume
        return Math.max(0, Math.min(14, -Math.log10(H)))
      } else if (excessMoles < -0.0001) {
        // After equivalence - excess base
        const OH = Math.abs(excessMoles) / totalVolume
        const pOH = -Math.log10(OH)
        return Math.max(0, Math.min(14, 14 - pOH))
      } else {
        // At equivalence
        return 7
      }
    } else if (type === "weak-strong") {
      // Weak acid titrated with strong base
      const Ka = Math.pow(10, -pKa)
      
      if (Vt === 0) {
        // Initial pH of weak acid
        const H = Math.sqrt(Ka * Ca)
        return Math.max(0, Math.min(14, -Math.log10(H)))
      }
      
      const excessMoles = molesAnalyte - molesTitrant
      
      if (excessMoles > 0.0001) {
        // Buffer region - Henderson-Hasselbalch
        const conjugateBase = molesTitrant
        const acid = excessMoles
        if (acid > 0 && conjugateBase > 0) {
          return Math.max(0, Math.min(14, pKa + Math.log10(conjugateBase / acid)))
        }
        return pKa
      } else if (excessMoles < -0.0001) {
        // After equivalence - excess strong base
        const OH = Math.abs(excessMoles) / totalVolume
        const pOH = -Math.log10(OH)
        return Math.max(0, Math.min(14, 14 - pOH))
      } else {
        // At equivalence - conjugate base hydrolysis
        const Kb = 1e-14 / Ka
        const conjugateConc = molesAnalyte / totalVolume
        const OH = Math.sqrt(Kb * conjugateConc)
        const pOH = -Math.log10(OH)
        return Math.max(0, Math.min(14, 14 - pOH))
      }
    } else if (type === "strong-weak") {
      // Strong acid titrated with weak base
      const pKb = 14 - pKa
      const Kb = Math.pow(10, -pKb)
      
      if (Vt === 0) {
        return -Math.log10(Ca)
      }
      
      const excessMoles = molesAnalyte - molesTitrant
      
      if (excessMoles > 0.0001) {
        // Before equivalence - excess strong acid
        const H = excessMoles / totalVolume
        return Math.max(0, Math.min(14, -Math.log10(H)))
      } else if (excessMoles < -0.0001) {
        // Buffer region after equivalence
        const conjugateAcid = molesAnalyte
        const base = Math.abs(excessMoles)
        if (base > 0 && conjugateAcid > 0) {
          return Math.max(0, Math.min(14, pKa + Math.log10(base / conjugateAcid)))
        }
        return pKa
      } else {
        // At equivalence - conjugate acid
        const Ka = 1e-14 / Kb
        const conjugateConc = molesAnalyte / totalVolume
        const H = Math.sqrt(Ka * conjugateConc)
        return Math.max(0, Math.min(14, -Math.log10(H)))
      }
    } else {
      // Weak acid with weak base - simplified
      const Ka = Math.pow(10, -pKa)
      
      if (Vt === 0) {
        const H = Math.sqrt(Ka * Ca)
        return Math.max(0, Math.min(14, -Math.log10(H)))
      }
      
      const excessMoles = molesAnalyte - molesTitrant
      
      if (Math.abs(excessMoles) < 0.0001) {
        // At equivalence
        return 7 + (pKa - 7) * 0.5
      } else if (excessMoles > 0) {
        return Math.max(0, Math.min(14, pKa + Math.log10(molesTitrant / excessMoles)))
      } else {
        return Math.max(0, Math.min(14, 14 - pKa + Math.log10(Math.abs(excessMoles) / molesAnalyte)))
      }
    }
  }

  const handleReset = () => {
    setAnalyteConc("")
    setAnalyteVolume("")
    setAnalytePka("")
    setTitrantConc("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Titration Curve Results:\nEquivalence Point: ${result.equivalenceVolume} mL at pH ${result.equivalencePH}${result.halfEquivalencePH ? `\nHalf-Equivalence pH: ${result.halfEquivalencePH}` : ''}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Titration Curve Results",
          text: `Titration Curve: Equivalence Point at ${result.equivalenceVolume} mL (pH ${result.equivalencePH})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const needsPka = titrationType === "weak-strong" || titrationType === "weak-weak"

  // Find min and max pH for scaling
  const minPH = result ? Math.floor(Math.min(...result.curveData.map(d => d.pH))) : 0
  const maxPH = result ? Math.ceil(Math.max(...result.curveData.map(d => d.pH))) : 14
  const maxVolume = result ? Math.max(...result.curveData.map(d => d.volume)) : 100

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Titration Curve Calculator</CardTitle>
                    <CardDescription>Generate acid-base titration curves</CardDescription>
                  </div>
                </div>

                {/* Titration Type Toggle */}
                <div className="pt-2">
                  <span className="text-sm font-medium mb-2 block">Titration Type</span>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "strong-strong", label: "Strong-Strong" },
                      { value: "weak-strong", label: "Weak Acid-Strong Base" },
                      { value: "strong-weak", label: "Strong Acid-Weak Base" },
                      { value: "weak-weak", label: "Weak-Weak" },
                    ].map((type) => (
                      <button
                        key={type.value}
                        onClick={() => {
                          setTitrationType(type.value as TitrationType)
                          setResult(null)
                          setError("")
                        }}
                        className={`px-3 py-2 text-xs font-medium rounded-lg transition-colors ${
                          titrationType === type.value
                            ? "bg-purple-600 text-white"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {type.label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Analyte Inputs */}
                <div className="space-y-3">
                  <Label className="text-sm font-semibold text-purple-700">Analyte (in flask)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label htmlFor="analyteConc" className="text-xs">Concentration (M)</Label>
                      <Input
                        id="analyteConc"
                        type="number"
                        placeholder="0.1"
                        value={analyteConc}
                        onChange={(e) => setAnalyteConc(e.target.value)}
                        min="0"
                        step="0.001"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="analyteVolume" className="text-xs">Volume (mL)</Label>
                      <Input
                        id="analyteVolume"
                        type="number"
                        placeholder="25"
                        value={analyteVolume}
                        onChange={(e) => setAnalyteVolume(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>
                  </div>
                  {needsPka && (
                    <div className="space-y-1">
                      <Label htmlFor="analytePka" className="text-xs">pKa of Weak Acid</Label>
                      <Input
                        id="analytePka"
                        type="number"
                        placeholder="4.76 (acetic acid)"
                        value={analytePka}
                        onChange={(e) => setAnalytePka(e.target.value)}
                        min="0"
                        max="14"
                        step="0.01"
                      />
                    </div>
                  )}
                </div>

                {/* Titrant Input */}
                <div className="space-y-3">
                  <Label className="text-sm font-semibold text-purple-700">Titrant (in burette)</Label>
                  <div className="space-y-1">
                    <Label htmlFor="titrantConc" className="text-xs">Concentration (M)</Label>
                    <Input
                      id="titrantConc"
                      type="number"
                      placeholder="0.1"
                      value={titrantConc}
                      onChange={(e) => setTitrantConc(e.target.value)}
                      min="0"
                      step="0.001"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTitrationCurve} className="w-full bg-purple-600 hover:bg-purple-700" size="lg">
                  Generate Titration Curve
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    {/* Titration Curve Visualization */}
                    <div className="mb-4">
                      <p className="text-sm font-medium text-purple-700 mb-2">Titration Curve (pH vs Volume)</p>
                      <div className="relative h-48 bg-white rounded-lg border border-purple-200 p-2">
                        {/* Y-axis labels */}
                        <div className="absolute left-0 top-0 bottom-0 w-8 flex flex-col justify-between text-xs text-muted-foreground py-2">
                          <span>{maxPH}</span>
                          <span>{Math.round((maxPH + minPH) / 2)}</span>
                          <span>{minPH}</span>
                        </div>
                        {/* Chart area */}
                        <div className="ml-8 h-full relative">
                          <svg className="w-full h-full" viewBox={`0 0 ${maxVolume} ${maxPH - minPH}`} preserveAspectRatio="none">
                            {/* Buffer region highlight */}
                            {result.bufferRegion && (
                              <rect
                                x={result.bufferRegion.start}
                                y={0}
                                width={result.bufferRegion.end - result.bufferRegion.start}
                                height={maxPH - minPH}
                                fill="rgba(147, 51, 234, 0.1)"
                              />
                            )}
                            {/* Curve line */}
                            <polyline
                              fill="none"
                              stroke="#9333ea"
                              strokeWidth={maxVolume / 100}
                              points={result.curveData.map(d => `${d.volume},${maxPH - d.pH}`).join(' ')}
                            />
                            {/* Equivalence point marker */}
                            <circle
                              cx={result.equivalenceVolume}
                              cy={maxPH - result.equivalencePH}
                              r={maxVolume / 50}
                              fill="#dc2626"
                            />
                          </svg>
                          {/* X-axis labels */}
                          <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-muted-foreground -mb-5">
                            <span>0</span>
                            <span>{Math.round(maxVolume / 2)}</span>
                            <span>{Math.round(maxVolume)}</span>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-center text-muted-foreground mt-6">Volume of Titrant (mL)</p>
                    </div>

                    {/* Key Results */}
                    <div className="text-center mb-3">
                      <p className="text-sm text-muted-foreground mb-1">Equivalence Point</p>
                      <p className="text-3xl font-bold text-purple-600">{result.equivalenceVolume} mL</p>
                      <p className="text-lg font-semibold text-purple-600">pH = {result.equivalencePH}</p>
                    </div>

                    {/* Additional Info */}
                    {result.halfEquivalencePH && (
                      <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
                        <div className="p-2 bg-white rounded-lg text-center">
                          <p className="text-xs text-muted-foreground">Half-Equivalence pH</p>
                          <p className="font-semibold text-purple-700">{result.halfEquivalencePH}</p>
                        </div>
                        <div className="p-2 bg-white rounded-lg text-center">
                          <p className="text-xs text-muted-foreground">Buffer Region</p>
                          <p className="font-semibold text-purple-700">
                            {result.bufferRegion ? `${Math.round(result.bufferRegion.start)}-${Math.round(result.bufferRegion.end)} mL` : 'N/A'}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Legend */}
                    <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground mb-3">
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-red-600"></span> Equivalence Point
                      </span>
                      {result.bufferRegion && (
                        <span className="flex items-center gap-1">
                          <span className="w-3 h-3 rounded bg-purple-200"></span> Buffer Region
                        </span>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Key Points on Curve</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Initial Point</span>
                      <span className="text-sm text-purple-600">V = 0 mL</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Half-Equivalence</span>
                      <span className="text-sm text-blue-600">pH = pKa</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Equivalence Point</span>
                      <span className="text-sm text-red-600">Moles equal</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Post-Equivalence</span>
                      <span className="text-sm text-green-600">Excess titrant</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Equivalence Point pH</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg space-y-2">
                    <p><strong>Strong-Strong:</strong> pH = 7</p>
                    <p><strong>Weak Acid-Strong Base:</strong> pH {'>'} 7</p>
                    <p><strong>Strong Acid-Weak Base:</strong> pH {'<'} 7</p>
                    <p><strong>Weak-Weak:</strong> Depends on Ka/Kb</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is a Titration Curve */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Titration Curve?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A titration curve is a graphical representation of the change in pH of a solution as a titrant 
                  (typically an acid or base) is added to an analyte (the substance being analyzed). The curve 
                  plots pH on the y-axis against the volume of titrant added on the x-axis, revealing important 
                  information about the chemical reaction occurring during the titration process.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The shape of the titration curve depends on the strengths of the acid and base involved. 
                  Strong acid-strong base titrations produce steep, symmetrical curves with equivalence points 
                  at pH 7. Weak acid-strong base titrations show a more gradual rise with equivalence points 
                  above pH 7, while strong acid-weak base titrations have equivalence points below pH 7. 
                  Understanding these curves is essential for selecting appropriate indicators and analyzing 
                  unknown solutions.
                </p>
              </CardContent>
            </Card>

            {/* Understanding the Regions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Titration Curve Regions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A titration curve can be divided into several distinct regions, each with unique chemical 
                  characteristics. The initial region shows the pH of the pure analyte before any titrant is 
                  added. For a weak acid, this pH is determined by the acid dissociation equilibrium.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Buffer Region</h4>
                    <p className="text-purple-700 text-sm">
                      For weak acid titrations, the region between 10% and 90% of the equivalence point volume 
                      is called the buffer region. Here, both the weak acid and its conjugate base are present 
                      in significant amounts, and the pH changes gradually. At the half-equivalence point, 
                      pH equals pKa.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Equivalence Point Region</h4>
                    <p className="text-red-700 text-sm">
                      At the equivalence point, stoichiometrically equivalent amounts of acid and base have 
                      reacted. The pH changes rapidly in this region—even a single drop of titrant can cause 
                      a large pH shift. This steep portion of the curve is used to determine the endpoint 
                      of the titration.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Post-Equivalence Region</h4>
                    <p className="text-green-700 text-sm">
                      After the equivalence point, excess titrant determines the pH. For a strong base titrant, 
                      the pH rises toward 14 as more base is added. The curve levels off as the solution 
                      becomes increasingly basic (or acidic, depending on the titrant).
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Types of Titration Curves */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Acid-Base Titrations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Different combinations of strong and weak acids and bases produce distinctly shaped titration 
                  curves. Understanding these differences is crucial for proper experimental design and data 
                  interpretation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Strong Acid + Strong Base:</strong> These titrations produce the classic S-shaped curve 
                  with a sharp vertical section at the equivalence point (pH = 7). The curve is symmetrical, 
                  and almost any indicator can be used since the pH change is so dramatic.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Weak Acid + Strong Base:</strong> The initial pH is higher than for strong acids, 
                  and there is a distinct buffer region before the equivalence point. The equivalence point 
                  pH is greater than 7 because the conjugate base undergoes hydrolysis. Phenolphthalein 
                  (pH 8-10) is often a suitable indicator.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Strong Acid + Weak Base:</strong> The equivalence point pH is less than 7 due to 
                  conjugate acid hydrolysis. Methyl orange (pH 3-4) is typically used as the indicator for 
                  these titrations.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations and Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator provides theoretical titration curves based on ideal solution behavior and 
                  complete reactions. Real experimental titrations may deviate from these predictions due to 
                  several factors that should be considered when interpreting results.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature affects equilibrium constants—Ka and Kb values change with temperature, which 
                  alters the curve shape and equivalence point pH. Ionic strength effects can also shift 
                  equilibrium positions in concentrated solutions. Very dilute solutions may not show 
                  well-defined equivalence points due to the limitations of pH measurement.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For polyprotic acids or bases, multiple equivalence points occur, creating more complex 
                  curves. Carbon dioxide absorption from the air can affect the pH of basic solutions over 
                  time. Indicator color changes occur over a pH range, not at a single point, which introduces 
                  small uncertainties in visual endpoint detection.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-purple-500" />
                  <CardTitle>Applications of Titration Curves</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Titration curves have numerous practical applications in chemistry, biochemistry, and industry. 
                  In analytical chemistry, they are used to determine unknown concentrations of acids or bases 
                  in samples, identify unknown substances by comparing experimental curves to reference data, 
                  and select appropriate indicators for specific titrations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In biochemistry, titration curves help characterize amino acids and proteins by revealing 
                  their pKa values. This information is crucial for understanding enzyme activity, protein 
                  folding, and drug design. Buffer preparation relies on titration curve analysis to create 
                  solutions that maintain stable pH values.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Industrial applications include quality control in pharmaceutical manufacturing, wastewater 
                  treatment monitoring, food acidity testing, and environmental analysis. Understanding 
                  titration curves enables chemists to design efficient analytical methods and troubleshoot 
                  problems when experimental results differ from expectations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
