"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Baby,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface BreastfeedingResult {
  bmr: number
  tdee: number
  breastfeedingCalories: number
  totalCalories: number
  activityMultiplier: number
  weightLossCalories: number | null
  maintenanceCalories: number
}

const activityLevels = [
  { value: "sedentary", label: "Sedentary", multiplier: 1.2, description: "Little or no exercise" },
  { value: "light", label: "Lightly Active", multiplier: 1.375, description: "Light exercise 1-3 days/week" },
  { value: "moderate", label: "Moderately Active", multiplier: 1.55, description: "Moderate exercise 3-5 days/week" },
  { value: "very", label: "Very Active", multiplier: 1.725, description: "Hard exercise 6-7 days/week" },
  { value: "extra", label: "Extra Active", multiplier: 1.9, description: "Very hard exercise & physical job" },
]

const lactationStages = [
  { value: "0-6", label: "0-6 months postpartum", calories: 450 },
  { value: "6-12", label: "6-12 months postpartum", calories: 400 },
]

export function BreastfeedingCalorieCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [activityLevel, setActivityLevel] = useState("moderate")
  const [lactationStage, setLactationStage] = useState("0-6")
  const [prePregnancyWeight, setPrePregnancyWeight] = useState("")
  const [showWeightGoal, setShowWeightGoal] = useState(false)
  const [result, setResult] = useState<BreastfeedingResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const weightNum = Number.parseFloat(weight)

    if (isNaN(ageNum) || ageNum < 18 || ageNum > 60) {
      setError("Please enter a valid age between 18 and 60")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = (feet * 12 + inches) * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Calculate BMR using Mifflin-St Jeor formula (female)
    const bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161

    // Get activity multiplier
    const activity = activityLevels.find((a) => a.value === activityLevel)
    const multiplier = activity?.multiplier || 1.55

    // Calculate TDEE
    const tdee = bmr * multiplier

    // Get breastfeeding calorie addition
    const lactation = lactationStages.find((l) => l.value === lactationStage)
    const breastfeedingCalories = lactation?.calories || 450

    // Total calories needed
    const totalCalories = tdee + breastfeedingCalories

    // Calculate weight loss calories if pre-pregnancy weight is provided
    let weightLossCalories: number | null = null
    if (showWeightGoal && prePregnancyWeight) {
      const preWeightNum = Number.parseFloat(prePregnancyWeight)
      const preWeightKg = unitSystem === "imperial" ? preWeightNum * 0.453592 : preWeightNum
      if (!isNaN(preWeightKg) && preWeightKg < weightInKg) {
        // Safe weight loss during breastfeeding: 0.5 kg/week = 500 cal deficit
        // But not below TDEE - 500 to ensure adequate milk production
        weightLossCalories = Math.max(totalCalories - 500, tdee)
      }
    }

    setResult({
      bmr: Math.round(bmr),
      tdee: Math.round(tdee),
      breastfeedingCalories,
      totalCalories: Math.round(totalCalories),
      activityMultiplier: multiplier,
      weightLossCalories: weightLossCalories ? Math.round(weightLossCalories) : null,
      maintenanceCalories: Math.round(totalCalories),
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setActivityLevel("moderate")
    setLactationStage("0-6")
    setPrePregnancyWeight("")
    setShowWeightGoal(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Breastfeeding Calorie Needs: ${result.totalCalories} kcal/day (BMR: ${result.bmr}, TDEE: ${result.tdee}, Lactation bonus: +${result.breastfeedingCalories})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Breastfeeding Calorie Needs",
          text: `I calculated my breastfeeding calorie needs using CalcHub! I need approximately ${result.totalCalories} kcal/day.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setPrePregnancyWeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Baby className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Breastfeeding Calorie Calculator</CardTitle>
                    <CardDescription>Estimate daily calorie needs for lactating mothers</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="18"
                    max="60"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Current Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <Select value={activityLevel} onValueChange={setActivityLevel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {activityLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          <div className="flex flex-col">
                            <span>{level.label}</span>
                            <span className="text-xs text-muted-foreground">{level.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Lactation Stage */}
                <div className="space-y-2">
                  <Label>Lactation Stage</Label>
                  <Select value={lactationStage} onValueChange={setLactationStage}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {lactationStages.map((stage) => (
                        <SelectItem key={stage.value} value={stage.value}>
                          {stage.label} (+{stage.calories} kcal)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Optional: Weight Goal */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="showWeightGoal"
                      checked={showWeightGoal}
                      onChange={(e) => setShowWeightGoal(e.target.checked)}
                      className="h-4 w-4 rounded border-gray-300"
                    />
                    <Label htmlFor="showWeightGoal" className="text-sm font-normal cursor-pointer">
                      Include pre-pregnancy weight for gradual weight loss guidance
                    </Label>
                  </div>
                  {showWeightGoal && (
                    <Input
                      type="number"
                      placeholder={`Pre-pregnancy weight (${unitSystem === "metric" ? "kg" : "lb"})`}
                      value={prePregnancyWeight}
                      onChange={(e) => setPrePregnancyWeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Calorie Needs
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-pink-50 border-pink-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Daily Calorie Requirement</p>
                      <p className="text-5xl font-bold text-pink-600 mb-2">{result.totalCalories}</p>
                      <p className="text-lg font-semibold text-pink-600">kcal/day</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        Includes +{result.breastfeedingCalories} kcal for breastfeeding
                      </p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="flex items-center justify-center gap-1 w-full mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-pink-200 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Basal Metabolic Rate (BMR)</span>
                          <span className="font-medium">{result.bmr} kcal</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Activity Multiplier</span>
                          <span className="font-medium">× {result.activityMultiplier}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">TDEE (before lactation)</span>
                          <span className="font-medium">{result.tdee} kcal</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Lactation Bonus</span>
                          <span className="font-medium text-pink-600">+{result.breastfeedingCalories} kcal</span>
                        </div>
                        {result.weightLossCalories && (
                          <div className="flex justify-between pt-2 border-t border-pink-100">
                            <span className="text-muted-foreground">Safe Weight Loss Target</span>
                            <span className="font-medium text-amber-600">{result.weightLossCalories} kcal</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Lactation Calorie Requirements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-pink-50 border border-pink-200">
                      <span className="font-medium text-pink-700">0-6 months</span>
                      <span className="text-sm text-pink-600">+450 kcal/day</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">6-12 months</span>
                      <span className="text-sm text-purple-600">+400 kcal/day</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    Based on the Institute of Medicine recommendations for exclusively breastfeeding mothers.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Activity Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {activityLevels.map((level) => (
                      <div key={level.value} className="flex justify-between p-2 rounded bg-muted/50">
                        <span>{level.label}</span>
                        <span className="font-mono">× {level.multiplier}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BMR Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-xs">
                    <p className="font-semibold text-foreground">BMR = 10W + 6.25H - 5A - 161</p>
                    <p className="mt-2 text-muted-foreground">W = weight (kg), H = height (cm), A = age</p>
                  </div>
                  <p>Uses the Mifflin-St Jeor equation, considered one of the most accurate for estimating BMR.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Why Breastfeeding Increases Calorie Needs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Breastfeeding is a metabolically demanding process that requires significant energy to produce breast
                  milk. On average, a lactating mother produces about 750-800 mL of breast milk per day during the first
                  six months, with each liter of milk requiring approximately 500-700 calories to produce. This is why
                  the Institute of Medicine recommends an additional 450-500 kcal/day during the first six months of
                  exclusive breastfeeding.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  As babies begin to eat solid foods around 6 months of age, breast milk production typically decreases
                  slightly, which is why the calorie recommendation drops to about 400 kcal/day for the 6-12 month
                  period. However, individual needs can vary based on how much the baby continues to breastfeed, the
                  mother's metabolism, and activity level.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Baby className="h-5 w-5 text-primary" />
                  <CardTitle>Nutrition Tips for Breastfeeding Mothers</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Stay Hydrated</h4>
                    <p className="text-green-700 text-sm">
                      Drink at least 8-10 glasses of water daily. Your body needs extra fluids to produce breast milk.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Eat Nutrient-Dense Foods</h4>
                    <p className="text-blue-700 text-sm">
                      Focus on whole grains, lean proteins, fruits, vegetables, and healthy fats to support milk
                      quality.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Don't Skip Meals</h4>
                    <p className="text-purple-700 text-sm">
                      Eat regular, balanced meals and healthy snacks to maintain energy levels throughout the day.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Gradual Weight Loss Only</h4>
                    <p className="text-amber-700 text-sm">
                      If trying to lose weight, aim for no more than 0.5 kg (1 lb) per week to maintain milk supply.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Calorie estimates are general recommendations for lactating mothers and may vary based on individual
                  metabolism, baby's feeding patterns, and activity level. Restrictive dieting while breastfeeding is
                  not recommended as it may affect milk supply and quality. Always consult with a healthcare
                  professional, registered dietitian, or lactation consultant for personalized nutrition guidance during
                  breastfeeding.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
