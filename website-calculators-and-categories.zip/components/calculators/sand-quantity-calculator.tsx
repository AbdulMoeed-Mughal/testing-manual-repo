"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Package, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type InputMode = "area" | "volume"
type LengthUnit = "m" | "ft"
type ThicknessUnit = "mm" | "cm" | "m" | "in"
type VolumeUnit = "m3" | "ft3"
type WeightUnit = "kg" | "tons"

interface SandResult {
  volume: number
  volumeUnit: VolumeUnit
  weight: number
  weightUnit: WeightUnit
  bags50kg: number
  bags25kg: number
  totalWithWastage: number
}

export function SandQuantityCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("area")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [lengthUnit, setLengthUnit] = useState<LengthUnit>("m")
  const [directVolume, setDirectVolume] = useState("")
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("m3")
  const [thickness, setThickness] = useState("")
  const [thicknessUnit, setThicknessUnit] = useState<ThicknessUnit>("cm")
  const [density, setDensity] = useState("1600")
  const [wastage, setWastage] = useState("5")
  const [result, setResult] = useState<SandResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const convertToMeters = (value: number, unit: LengthUnit): number => {
    if (unit === "ft") return value * 0.3048
    return value
  }

  const convertThicknessToMeters = (value: number, unit: ThicknessUnit): number => {
    switch (unit) {
      case "mm":
        return value / 1000
      case "cm":
        return value / 100
      case "in":
        return value * 0.0254
      default:
        return value
    }
  }

  const convertVolumeToM3 = (value: number, unit: VolumeUnit): number => {
    if (unit === "ft3") return value * 0.0283168
    return value
  }

  const calculateSand = () => {
    setError("")
    setResult(null)

    let volumeInM3: number

    if (inputMode === "area") {
      const lengthNum = Number.parseFloat(length)
      const widthNum = Number.parseFloat(width)
      const thicknessNum = Number.parseFloat(thickness)

      if (isNaN(lengthNum) || lengthNum <= 0) {
        setError("Please enter a valid length greater than 0")
        return
      }
      if (isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter a valid width greater than 0")
        return
      }
      if (isNaN(thicknessNum) || thicknessNum <= 0) {
        setError("Please enter a valid thickness greater than 0")
        return
      }

      const lengthInM = convertToMeters(lengthNum, lengthUnit)
      const widthInM = convertToMeters(widthNum, lengthUnit)
      const thicknessInM = convertThicknessToMeters(thicknessNum, thicknessUnit)

      volumeInM3 = lengthInM * widthInM * thicknessInM
    } else {
      const volumeNum = Number.parseFloat(directVolume)

      if (isNaN(volumeNum) || volumeNum <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }

      volumeInM3 = convertVolumeToM3(volumeNum, volumeUnit)
    }

    const densityNum = Number.parseFloat(density)
    if (isNaN(densityNum) || densityNum <= 0) {
      setError("Please enter a valid density greater than 0")
      return
    }

    const wastageNum = Number.parseFloat(wastage) || 0
    if (wastageNum < 0 || wastageNum > 100) {
      setError("Wastage must be between 0 and 100")
      return
    }

    // Calculate weight in kg
    const weightInKg = volumeInM3 * densityNum
    const totalWithWastage = weightInKg * (1 + wastageNum / 100)

    // Calculate bags
    const bags50kg = Math.ceil(totalWithWastage / 50)
    const bags25kg = Math.ceil(totalWithWastage / 25)

    setResult({
      volume: parseFloat(volumeInM3.toFixed(3)),
      volumeUnit: "m3",
      weight: parseFloat(weightInKg.toFixed(2)),
      weightUnit: weightInKg >= 1000 ? "tons" : "kg",
      bags50kg,
      bags25kg,
      totalWithWastage: parseFloat(totalWithWastage.toFixed(2)),
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setDirectVolume("")
    setThickness("")
    setDensity("1600")
    setWastage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const weight = result.weightUnit === "tons" ? (result.weight / 1000).toFixed(2) : result.weight
      const unit = result.weightUnit
      await navigator.clipboard.writeText(
        `Sand Quantity: ${result.volume} m³ | Weight: ${weight} ${unit} | With wastage: ${result.totalWithWastage.toFixed(2)} kg`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const weight = result.weightUnit === "tons" ? (result.weight / 1000).toFixed(2) : result.weight
        const unit = result.weightUnit
        await navigator.share({
          title: "Sand Quantity Result",
          text: `I calculated sand quantity using CalcHub! Volume: ${result.volume} m³, Weight: ${weight} ${unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleInputMode = () => {
    setInputMode((prev) => (prev === "area" ? "volume" : "area"))
    setLength("")
    setWidth("")
    setDirectVolume("")
    setThickness("")
    setResult(null)
    setError("")
  }

  const displayWeight = result
    ? result.weightUnit === "tons"
      ? (result.weight / 1000).toFixed(2)
      : result.weight.toFixed(2)
    : "0"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Package className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Sand Quantity Calculator</CardTitle>
                    <CardDescription>Calculate sand needed for construction</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={toggleInputMode}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "volume" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "area" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Area
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "volume" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Volume
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {inputMode === "area" ? (
                  <>
                    {/* Length Input */}
                    <div className="space-y-2">
                      <Label htmlFor="length">Length</Label>
                      <div className="flex gap-2">
                        <Input
                          id="length"
                          type="number"
                          placeholder="Enter length"
                          value={length}
                          onChange={(e) => setLength(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <Select value={lengthUnit} onValueChange={(value: LengthUnit) => setLengthUnit(value)}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="m">m</SelectItem>
                            <SelectItem value="ft">ft</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Width Input */}
                    <div className="space-y-2">
                      <Label htmlFor="width">Width</Label>
                      <div className="flex gap-2">
                        <Input
                          id="width"
                          type="number"
                          placeholder="Enter width"
                          value={width}
                          onChange={(e) => setWidth(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <Select value={lengthUnit} onValueChange={(value: LengthUnit) => setLengthUnit(value)}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="m">m</SelectItem>
                            <SelectItem value="ft">ft</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Thickness Input */}
                    <div className="space-y-2">
                      <Label htmlFor="thickness">Thickness / Depth</Label>
                      <div className="flex gap-2">
                        <Input
                          id="thickness"
                          type="number"
                          placeholder="Enter thickness"
                          value={thickness}
                          onChange={(e) => setThickness(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <Select
                          value={thicknessUnit}
                          onValueChange={(value: ThicknessUnit) => setThicknessUnit(value)}
                        >
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="mm">mm</SelectItem>
                            <SelectItem value="cm">cm</SelectItem>
                            <SelectItem value="m">m</SelectItem>
                            <SelectItem value="in">in</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Direct Volume Input */}
                    <div className="space-y-2">
                      <Label htmlFor="volume">Volume</Label>
                      <div className="flex gap-2">
                        <Input
                          id="volume"
                          type="number"
                          placeholder="Enter volume"
                          value={directVolume}
                          onChange={(e) => setDirectVolume(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <Select value={volumeUnit} onValueChange={(value: VolumeUnit) => setVolumeUnit(value)}>
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="m3">m³</SelectItem>
                            <SelectItem value="ft3">ft³</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                )}

                {/* Density Input */}
                <div className="space-y-2">
                  <Label htmlFor="density">Sand Density (kg/m³)</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder="Default: 1600"
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="10"
                  />
                </div>

                {/* Wastage Input */}
                <div className="space-y-2">
                  <Label htmlFor="wastage">Wastage (%)</Label>
                  <Input
                    id="wastage"
                    type="number"
                    placeholder="Default: 5"
                    value={wastage}
                    onChange={(e) => setWastage(e.target.value)}
                    min="0"
                    max="100"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSand} className="w-full" size="lg">
                  Calculate Sand Quantity
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Sand Required</p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">
                          {displayWeight} {result.weightUnit}
                        </p>
                        <p className="text-sm text-amber-700">Volume: {result.volume} m³</p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="p-2 rounded-lg bg-white/50 border border-amber-100">
                          <p className="text-muted-foreground text-xs mb-1">With Wastage</p>
                          <p className="font-semibold text-amber-700">{result.totalWithWastage.toFixed(2)} kg</p>
                        </div>
                        <div className="p-2 rounded-lg bg-white/50 border border-amber-100">
                          <p className="text-muted-foreground text-xs mb-1">50kg Bags</p>
                          <p className="font-semibold text-amber-700">{result.bags50kg} bags</p>
                        </div>
                        <div className="p-2 rounded-lg bg-white/50 border border-amber-100 col-span-2">
                          <p className="text-muted-foreground text-xs mb-1">25kg Bags (Alternative)</p>
                          <p className="font-semibold text-amber-700">{result.bags25kg} bags</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Sand Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Dry Sand</span>
                      <span className="text-sm text-amber-600">1400-1600 kg/m³</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Wet Sand</span>
                      <span className="text-sm text-amber-600">1800-2000 kg/m³</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Packed Sand</span>
                      <span className="text-sm text-amber-600">2000-2200 kg/m³</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">Volume = Length × Width × Thickness</p>
                    <p className="font-semibold text-foreground">Weight = Volume × Density</p>
                    <p className="font-semibold text-foreground">With Wastage = Weight × (1 + Wastage%/100)</p>
                  </div>
                  <p>
                    The calculator automatically converts all measurements to cubic meters (m³) and calculates the total
                    weight based on sand density.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Sand Quantity Calculator */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Sand Quantity Calculator?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A Sand Quantity Calculator is an essential tool for construction professionals, contractors, and DIY
                  enthusiasts that helps determine the exact amount of sand required for various construction projects.
                  Whether you're mixing concrete, plastering walls, laying flooring, or backfilling foundations, this
                  calculator eliminates guesswork by providing accurate estimates based on your project dimensions and
                  requirements.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Sand is one of the most fundamental materials in construction, used in mortar, concrete, plastering,
                  and many other applications. Ordering too little sand can delay your project, while ordering too much
                  wastes money and storage space. This calculator helps you achieve the perfect balance by considering
                  factors like area dimensions, thickness, sand density, and even wastage allowance to provide precise
                  quantity estimates in both volume and weight measurements.
                </p>
              </CardContent>
            </Card>

            {/* How to Use */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Sand Quantity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Using this calculator is straightforward. First, choose your input mode – either area-based (length ×
                  width × thickness) or direct volume input. For area-based calculations, measure the length and width
                  of the area where you'll use sand, then specify the desired thickness or depth. The calculator
                  supports multiple units including meters, feet, centimeters, millimeters, and inches for your
                  convenience.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Next, enter the sand density, which typically ranges from 1400 to 2200 kg/m³ depending on moisture
                  content and compaction. Dry loose sand is around 1400-1600 kg/m³, while wet or packed sand can be
                  1800-2200 kg/m³. The default value of 1600 kg/m³ works well for most applications. Finally, add a
                  wastage percentage (typically 5-10%) to account for spillage, uneven surfaces, and compaction. The
                  calculator then provides total volume, weight, and the number of standard bags (50kg or 25kg) you'll
                  need to purchase.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  <CardTitle>Common Applications of Sand in Construction</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Sand serves multiple critical purposes in construction. In concrete mixing, sand acts as fine
                  aggregate that fills voids between coarse aggregates and provides workability to the mixture. The
                  typical ratio in concrete is about 1 part cement, 2 parts sand, and 3 parts coarse aggregate. For a
                  100mm thick concrete slab covering 10 square meters, you'd need approximately 1 cubic meter of sand.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Plastering and Rendering</h4>
                    <p className="text-amber-700 text-sm">
                      For wall plastering, sand is mixed with cement in ratios like 1:4 or 1:6. A typical 12mm thick
                      plaster on a 100 sq.m wall requires about 1.2 cubic meters of sand. The sand should be clean,
                      sharp, and free from organic matter for best adhesion and finish quality.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Bricklaying and Masonry</h4>
                    <p className="text-amber-700 text-sm">
                      Mortar for laying bricks typically uses a 1:4 or 1:5 cement to sand ratio. For every 1000
                      standard bricks (230×110×76mm), you'll need approximately 1.2 to 1.5 cubic meters of sand,
                      depending on joint thickness and mortar consistency.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Flooring and Bedding</h4>
                    <p className="text-amber-700 text-sm">
                      Sand bedding under paving stones or floor tiles provides a level, stable base. A typical bedding
                      layer is 50-75mm thick. For paving a 50 sq.m area with 50mm sand bedding, you'd need about 2.5
                      cubic meters of sand, plus extra for joint filling if using permeable paving.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Backfilling and Leveling</h4>
                    <p className="text-amber-700 text-sm">
                      Sand is excellent for backfilling around foundations, trenches, and pipes due to its drainage
                      properties. It compacts well and doesn't exert excessive pressure on structures. Calculate the
                      volume of the void to be filled and add 10-15% for compaction and settling.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Important Considerations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Sand density varies significantly based on moisture content, particle size, and compaction level.
                  Freshly delivered sand is typically loose and may compact by 10-15% after settling and use. Wet sand
                  weighs considerably more than dry sand – up to 30% heavier – which affects both transport costs and
                  handling. Always account for this by adding a wastage factor to your calculations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Sand quality is crucial for construction. Use clean, washed sand free from clay, silt, organic matter,
                  and salt. Clay content above 5% reduces bond strength in mortar and concrete. For plastering, use fine
                  sand passing through a 2.36mm sieve. For concrete, use medium to coarse sand (Zone II or Zone III as
                  per standards). Always source sand from reputable suppliers who can provide material test certificates
                  when required for structural applications.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm font-semibold mb-2">Disclaimer</p>
                  <p className="text-yellow-700 text-sm">
                    Sand density may vary based on moisture content, particle size distribution, and compaction. Results
                    are approximate and intended for estimation purposes only. Always consult with your supplier about
                    exact material specifications and add appropriate wastage factors for your specific project
                    conditions. For structural applications, verify calculations with a qualified engineer.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
