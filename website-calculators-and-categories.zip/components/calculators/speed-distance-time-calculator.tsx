"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Gauge, Info, AlertTriangle, Timer, MapPin, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "speed" | "distance" | "time"

interface Result {
  speed: number
  speedUnit: string
  distance: number
  distanceUnit: string
  time: number
  timeFormatted: string
  pace?: string
}

const distanceUnits = [
  { value: "km", label: "Kilometers (km)", toMeters: 1000 },
  { value: "m", label: "Meters (m)", toMeters: 1 },
  { value: "mi", label: "Miles (mi)", toMeters: 1609.344 },
  { value: "ft", label: "Feet (ft)", toMeters: 0.3048 },
]

const speedUnits = [
  { value: "km/h", label: "km/h", toMps: 1 / 3.6 },
  { value: "m/s", label: "m/s", toMps: 1 },
  { value: "mph", label: "mph", toMps: 0.44704 },
  { value: "ft/s", label: "ft/s", toMps: 0.3048 },
]

export function SpeedDistanceTimeCalculator() {
  const [mode, setMode] = useState<CalculationMode>("speed")
  const [distance, setDistance] = useState("")
  const [distanceUnit, setDistanceUnit] = useState("km")
  const [hours, setHours] = useState("")
  const [minutes, setMinutes] = useState("")
  const [seconds, setSeconds] = useState("")
  const [speed, setSpeed] = useState("")
  const [speedUnit, setSpeedUnit] = useState("km/h")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatTime = (totalSeconds: number): string => {
    const h = Math.floor(totalSeconds / 3600)
    const m = Math.floor((totalSeconds % 3600) / 60)
    const s = Math.round(totalSeconds % 60)
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`
  }

  const calculatePace = (distanceInKm: number, totalSeconds: number): string => {
    if (distanceInKm <= 0 || totalSeconds <= 0) return "N/A"
    const paceSecondsPerKm = totalSeconds / distanceInKm
    const paceMin = Math.floor(paceSecondsPerKm / 60)
    const paceSec = Math.round(paceSecondsPerKm % 60)
    return `${paceMin}:${paceSec.toString().padStart(2, "0")} /km`
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const distanceUnitData = distanceUnits.find((u) => u.value === distanceUnit)!
    const speedUnitData = speedUnits.find((u) => u.value === speedUnit)!

    if (mode === "speed") {
      const distanceValue = Number.parseFloat(distance)
      const h = Number.parseFloat(hours) || 0
      const m = Number.parseFloat(minutes) || 0
      const s = Number.parseFloat(seconds) || 0
      const totalSeconds = h * 3600 + m * 60 + s

      if (isNaN(distanceValue) || distanceValue <= 0) {
        setError("Please enter a valid distance greater than 0")
        return
      }
      if (totalSeconds <= 0) {
        setError("Please enter a valid time greater than 0")
        return
      }

      const distanceInMeters = distanceValue * distanceUnitData.toMeters
      const speedInMps = distanceInMeters / totalSeconds
      const speedInUnit = speedInMps / speedUnitData.toMps
      const distanceInKm = distanceInMeters / 1000

      setResult({
        speed: speedInUnit,
        speedUnit: speedUnit,
        distance: distanceValue,
        distanceUnit: distanceUnit,
        time: totalSeconds,
        timeFormatted: formatTime(totalSeconds),
        pace: calculatePace(distanceInKm, totalSeconds),
      })
    } else if (mode === "distance") {
      const speedValue = Number.parseFloat(speed)
      const h = Number.parseFloat(hours) || 0
      const m = Number.parseFloat(minutes) || 0
      const s = Number.parseFloat(seconds) || 0
      const totalSeconds = h * 3600 + m * 60 + s

      if (isNaN(speedValue) || speedValue <= 0) {
        setError("Please enter a valid speed greater than 0")
        return
      }
      if (totalSeconds <= 0) {
        setError("Please enter a valid time greater than 0")
        return
      }

      const speedInMps = speedValue * speedUnitData.toMps
      const distanceInMeters = speedInMps * totalSeconds
      const distanceInUnit = distanceInMeters / distanceUnitData.toMeters
      const distanceInKm = distanceInMeters / 1000

      setResult({
        speed: speedValue,
        speedUnit: speedUnit,
        distance: distanceInUnit,
        distanceUnit: distanceUnit,
        time: totalSeconds,
        timeFormatted: formatTime(totalSeconds),
        pace: calculatePace(distanceInKm, totalSeconds),
      })
    } else {
      const distanceValue = Number.parseFloat(distance)
      const speedValue = Number.parseFloat(speed)

      if (isNaN(distanceValue) || distanceValue <= 0) {
        setError("Please enter a valid distance greater than 0")
        return
      }
      if (isNaN(speedValue) || speedValue <= 0) {
        setError("Please enter a valid speed greater than 0")
        return
      }

      const distanceInMeters = distanceValue * distanceUnitData.toMeters
      const speedInMps = speedValue * speedUnitData.toMps
      const timeInSeconds = distanceInMeters / speedInMps
      const distanceInKm = distanceInMeters / 1000

      setResult({
        speed: speedValue,
        speedUnit: speedUnit,
        distance: distanceValue,
        distanceUnit: distanceUnit,
        time: timeInSeconds,
        timeFormatted: formatTime(timeInSeconds),
        pace: calculatePace(distanceInKm, timeInSeconds),
      })
    }
  }

  const handleReset = () => {
    setDistance("")
    setHours("")
    setMinutes("")
    setSeconds("")
    setSpeed("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = ""
      if (mode === "speed") {
        text = `Speed: ${result.speed.toFixed(2)} ${result.speedUnit}`
      } else if (mode === "distance") {
        text = `Distance: ${result.distance.toFixed(2)} ${result.distanceUnit}`
      } else {
        text = `Time: ${result.timeFormatted}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        let text = ""
        if (mode === "speed") {
          text = `Speed: ${result.speed.toFixed(2)} ${result.speedUnit} for ${result.distance} ${result.distanceUnit} in ${result.timeFormatted}`
        } else if (mode === "distance") {
          text = `Distance: ${result.distance.toFixed(2)} ${result.distanceUnit} at ${result.speed} ${result.speedUnit} in ${result.timeFormatted}`
        } else {
          text = `Time: ${result.timeFormatted} to cover ${result.distance} ${result.distanceUnit} at ${result.speed} ${result.speedUnit}`
        }
        await navigator.share({
          title: "Speed/Distance/Time Calculation",
          text: `I calculated using CalcHub! ${text}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Speed/Distance/Time</CardTitle>
                    <CardDescription>Calculate motion variables</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="pt-2">
                  <span className="text-sm font-medium block mb-2">Calculate</span>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "speed", label: "Speed", icon: Zap },
                      { value: "distance", label: "Distance", icon: MapPin },
                      { value: "time", label: "Time", icon: Timer },
                    ].map(({ value, label, icon: Icon }) => (
                      <button
                        key={value}
                        onClick={() => {
                          setMode(value as CalculationMode)
                          setResult(null)
                          setError("")
                        }}
                        className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                          mode === value
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        <Icon className="h-4 w-4" />
                        {label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Distance Input - show when calculating speed or time */}
                {(mode === "speed" || mode === "time") && (
                  <div className="space-y-2">
                    <Label>Distance</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter distance"
                        value={distance}
                        onChange={(e) => setDistance(e.target.value)}
                        min="0"
                        step="0.01"
                        className="flex-1"
                      />
                      <Select value={distanceUnit} onValueChange={setDistanceUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {distanceUnits.map((unit) => (
                            <SelectItem key={unit.value} value={unit.value}>
                              {unit.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Time Input - show when calculating speed or distance */}
                {(mode === "speed" || mode === "distance") && (
                  <div className="space-y-2">
                    <Label>Time (HH:MM:SS)</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Input
                          type="number"
                          placeholder="Hours"
                          value={hours}
                          onChange={(e) => setHours(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Minutes"
                          value={minutes}
                          onChange={(e) => setMinutes(e.target.value)}
                          min="0"
                          max="59"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Seconds"
                          value={seconds}
                          onChange={(e) => setSeconds(e.target.value)}
                          min="0"
                          max="59"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Speed Input - show when calculating distance or time */}
                {(mode === "distance" || mode === "time") && (
                  <div className="space-y-2">
                    <Label>Speed</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter speed"
                        value={speed}
                        onChange={(e) => setSpeed(e.target.value)}
                        min="0"
                        step="0.01"
                        className="flex-1"
                      />
                      <Select value={speedUnit} onValueChange={setSpeedUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {speedUnits.map((unit) => (
                            <SelectItem key={unit.value} value={unit.value}>
                              {unit.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Output Unit Selector */}
                {mode === "speed" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={speedUnit} onValueChange={setSpeedUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {speedUnits.map((unit) => (
                          <SelectItem key={unit.value} value={unit.value}>
                            {unit.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {mode === "distance" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={distanceUnit} onValueChange={setDistanceUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {distanceUnits.map((unit) => (
                          <SelectItem key={unit.value} value={unit.value}>
                            {unit.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {mode.charAt(0).toUpperCase() + mode.slice(1)}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "speed" ? "Speed" : mode === "distance" ? "Distance" : "Time"}
                      </p>
                      <p className="text-4xl font-bold text-orange-600 mb-2">
                        {mode === "speed"
                          ? `${result.speed.toFixed(2)} ${result.speedUnit}`
                          : mode === "distance"
                            ? `${result.distance.toFixed(2)} ${result.distanceUnit}`
                            : result.timeFormatted}
                      </p>

                      {/* Additional Info */}
                      <div className="grid grid-cols-2 gap-2 mt-3 text-sm">
                        {mode !== "distance" && (
                          <div className="p-2 bg-white/60 rounded-lg">
                            <p className="text-muted-foreground">Distance</p>
                            <p className="font-semibold">
                              {result.distance.toFixed(2)} {result.distanceUnit}
                            </p>
                          </div>
                        )}
                        {mode !== "time" && (
                          <div className="p-2 bg-white/60 rounded-lg">
                            <p className="text-muted-foreground">Time</p>
                            <p className="font-semibold">{result.timeFormatted}</p>
                          </div>
                        )}
                        {mode !== "speed" && (
                          <div className="p-2 bg-white/60 rounded-lg">
                            <p className="text-muted-foreground">Speed</p>
                            <p className="font-semibold">
                              {result.speed.toFixed(2)} {result.speedUnit}
                            </p>
                          </div>
                        )}
                        {result.pace && (
                          <div className="p-2 bg-white/60 rounded-lg">
                            <p className="text-muted-foreground">Pace</p>
                            <p className="font-semibold">{result.pace}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <p className="font-semibold text-orange-700 mb-1">Speed</p>
                    <p className="font-mono text-sm text-orange-600">Speed = Distance ÷ Time</p>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-semibold text-blue-700 mb-1">Distance</p>
                    <p className="font-mono text-sm text-blue-600">Distance = Speed × Time</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-semibold text-green-700 mb-1">Time</p>
                    <p className="font-mono text-sm text-green-600">Time = Distance ÷ Speed</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Real-World Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between items-center p-2 bg-muted rounded-lg">
                      <span>Walking</span>
                      <span className="font-mono text-muted-foreground">~5 km/h</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded-lg">
                      <span>Running (jog)</span>
                      <span className="font-mono text-muted-foreground">~10 km/h</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded-lg">
                      <span>Cycling</span>
                      <span className="font-mono text-muted-foreground">~20 km/h</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded-lg">
                      <span>Car (city)</span>
                      <span className="font-mono text-muted-foreground">~50 km/h</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded-lg">
                      <span>Car (highway)</span>
                      <span className="font-mono text-muted-foreground">~120 km/h</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted rounded-lg">
                      <span>Airplane</span>
                      <span className="font-mono text-muted-foreground">~900 km/h</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-yellow-200 bg-yellow-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Results are based on ideal constant speed and do not account for acceleration, deceleration, or
                        delays. Actual travel times may vary.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Speed, Distance, and Time</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Speed, distance, and time are three fundamental concepts in physics that describe motion. These
                  quantities are interconnected through simple mathematical relationships that have been understood
                  since ancient times. Whether you're planning a road trip, training for a marathon, or studying
                  kinematics, understanding these relationships is essential for accurate calculations and predictions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Speed measures how fast an object moves - the rate at which it covers distance over time. Distance is
                  the total length of the path traveled, while time measures the duration of the journey. Together,
                  these three variables form the foundation of motion analysis and are used extensively in physics,
                  engineering, transportation, and sports science.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>The Relationship Between Variables</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The relationship between speed, distance, and time can be expressed by three equivalent formulas:
                  Speed = Distance ÷ Time, Distance = Speed × Time, and Time = Distance ÷ Speed. These formulas assume
                  constant speed (uniform motion), meaning the object travels at the same rate throughout its journey.
                  In real-world scenarios, speed often varies, but average speed calculations still use these formulas.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When working with these calculations, units must be consistent. For example, if distance is in
                  kilometers and time is in hours, speed will be in kilometers per hour (km/h). This calculator
                  automatically handles unit conversions, allowing you to input values in your preferred units while
                  getting accurate results in any desired output unit.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Timer className="h-5 w-5 text-primary" />
                  <CardTitle>Speed vs. Velocity: Understanding the Difference</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While often used interchangeably in everyday language, speed and velocity have distinct meanings in
                  physics. Speed is a scalar quantity that only measures how fast something moves - it's always
                  positive. Velocity, on the other hand, is a vector quantity that includes both speed and direction. A
                  car traveling north at 60 km/h and another traveling south at 60 km/h have the same speed but
                  different velocities.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator focuses on speed calculations, which are sufficient for most practical applications
                  like travel planning, fitness tracking, and general motion calculations. For applications requiring
                  directional information, such as navigation systems or physics problems involving vectors, velocity
                  calculations would be more appropriate.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Speed, distance, and time calculations have countless real-world applications. Travelers use them to
                  estimate arrival times and plan routes. Athletes calculate running pace and predict race finish times.
                  Engineers design transportation systems based on these principles. Logistics companies optimize
                  delivery schedules, and aviation relies on precise speed-time calculations for flight planning.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Travel Planning</h4>
                    <p className="text-orange-700 text-sm">
                      Calculate how long a road trip will take at different speeds, or determine what speed you need to
                      maintain to arrive on time. Factor in rest stops by adjusting your time calculations.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Fitness & Training</h4>
                    <p className="text-blue-700 text-sm">
                      Runners use pace calculations to plan training sessions and predict race times. Knowing your
                      target pace helps you maintain consistent effort during long-distance events like marathons.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Transportation & Logistics</h4>
                    <p className="text-green-700 text-sm">
                      Shipping companies calculate delivery times based on distance and average vehicle speed. Airlines
                      use wind speed adjustments to calculate accurate flight times and fuel requirements.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
