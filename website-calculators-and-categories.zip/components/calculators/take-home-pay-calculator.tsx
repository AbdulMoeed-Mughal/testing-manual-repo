"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Wallet,
  Info,
  AlertTriangle,
  DollarSign,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface TakeHomeResult {
  grossPay: number
  federalTax: number
  stateTax: number
  socialSecurity: number
  medicare: number
  retirement: number
  healthInsurance: number
  otherDeductions: number
  totalDeductions: number
  netPay: number
  annualNet: number
  effectiveTaxRate: number
}

export function TakeHomePayCalculator() {
  const [grossSalary, setGrossSalary] = useState("")
  const [salaryType, setSalaryType] = useState<"annual" | "monthly" | "hourly">("annual")
  const [hoursPerWeek, setHoursPerWeek] = useState("40")
  const [payFrequency, setPayFrequency] = useState<"weekly" | "biweekly" | "monthly" | "annual">("monthly")
  const [federalRate, setFederalRate] = useState("")
  const [stateRate, setStateRate] = useState("")
  const [retirementPercent, setRetirementPercent] = useState("")
  const [healthInsurance, setHealthInsurance] = useState("")
  const [otherDeductions, setOtherDeductions] = useState("")
  const [result, setResult] = useState<TakeHomeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  const calculateTakeHome = () => {
    setError("")
    setResult(null)

    const salary = Number.parseFloat(grossSalary)
    if (isNaN(salary) || salary <= 0) {
      setError("Please enter a valid salary greater than 0")
      return
    }

    const fedRate = Number.parseFloat(federalRate) || 22
    const stRate = Number.parseFloat(stateRate) || 5
    const retirementPct = Number.parseFloat(retirementPercent) || 0
    const health = Number.parseFloat(healthInsurance) || 0
    const other = Number.parseFloat(otherDeductions) || 0
    const hours = Number.parseFloat(hoursPerWeek) || 40

    if (fedRate < 0 || fedRate > 100 || stRate < 0 || stRate > 100) {
      setError("Tax rates must be between 0 and 100")
      return
    }

    // Convert to annual salary
    let annualSalary = salary
    if (salaryType === "monthly") {
      annualSalary = salary * 12
    } else if (salaryType === "hourly") {
      annualSalary = salary * hours * 52
    }

    // Calculate per-period gross
    let periodsPerYear = 12
    if (payFrequency === "weekly") periodsPerYear = 52
    else if (payFrequency === "biweekly") periodsPerYear = 26
    else if (payFrequency === "annual") periodsPerYear = 1

    const grossPay = annualSalary / periodsPerYear

    // Calculate deductions
    const federalTax = grossPay * (fedRate / 100)
    const stateTax = grossPay * (stRate / 100)
    const socialSecurity = grossPay * 0.062 // 6.2%
    const medicare = grossPay * 0.0145 // 1.45%
    const retirement = grossPay * (retirementPct / 100)
    const healthPerPeriod = health / periodsPerYear
    const otherPerPeriod = other / periodsPerYear

    const totalDeductions =
      federalTax + stateTax + socialSecurity + medicare + retirement + healthPerPeriod + otherPerPeriod
    const netPay = grossPay - totalDeductions
    const annualNet = netPay * periodsPerYear
    const effectiveTaxRate = ((federalTax + stateTax + socialSecurity + medicare) / grossPay) * 100

    setResult({
      grossPay: Math.round(grossPay * 100) / 100,
      federalTax: Math.round(federalTax * 100) / 100,
      stateTax: Math.round(stateTax * 100) / 100,
      socialSecurity: Math.round(socialSecurity * 100) / 100,
      medicare: Math.round(medicare * 100) / 100,
      retirement: Math.round(retirement * 100) / 100,
      healthInsurance: Math.round(healthPerPeriod * 100) / 100,
      otherDeductions: Math.round(otherPerPeriod * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      netPay: Math.round(netPay * 100) / 100,
      annualNet: Math.round(annualNet * 100) / 100,
      effectiveTaxRate: Math.round(effectiveTaxRate * 10) / 10,
    })
  }

  const handleReset = () => {
    setGrossSalary("")
    setSalaryType("annual")
    setHoursPerWeek("40")
    setPayFrequency("monthly")
    setFederalRate("")
    setStateRate("")
    setRetirementPercent("")
    setHealthInsurance("")
    setOtherDeductions("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Take-Home Pay: $${result.netPay.toLocaleString()} per ${payFrequency === "annual" ? "year" : payFrequency === "monthly" ? "month" : payFrequency === "biweekly" ? "pay period" : "week"}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Take-Home Pay Result",
          text: `My estimated take-home pay is $${result.netPay.toLocaleString()}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(value)
  }

  const getPayFrequencyLabel = () => {
    switch (payFrequency) {
      case "weekly":
        return "Weekly"
      case "biweekly":
        return "Biweekly"
      case "monthly":
        return "Monthly"
      case "annual":
        return "Annual"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Wallet className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Take-Home Pay Calculator</CardTitle>
                    <CardDescription>Estimate your net income after deductions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gross Salary */}
                <div className="space-y-2">
                  <Label htmlFor="grossSalary">Gross Salary ($)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      id="grossSalary"
                      type="number"
                      placeholder="Enter salary"
                      value={grossSalary}
                      onChange={(e) => setGrossSalary(e.target.value)}
                      min="0"
                    />
                    <Select
                      value={salaryType}
                      onValueChange={(v) => setSalaryType(v as "annual" | "monthly" | "hourly")}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="annual">Annual</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="hourly">Hourly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Hours per week (if hourly) */}
                {salaryType === "hourly" && (
                  <div className="space-y-2">
                    <Label htmlFor="hoursPerWeek">Hours per Week</Label>
                    <Input
                      id="hoursPerWeek"
                      type="number"
                      placeholder="40"
                      value={hoursPerWeek}
                      onChange={(e) => setHoursPerWeek(e.target.value)}
                      min="0"
                      max="168"
                    />
                  </div>
                )}

                {/* Pay Frequency */}
                <div className="space-y-2">
                  <Label htmlFor="payFrequency">Pay Frequency</Label>
                  <Select
                    value={payFrequency}
                    onValueChange={(v) => setPayFrequency(v as "weekly" | "biweekly" | "monthly" | "annual")}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="biweekly">Biweekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="annual">Annual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Tax Rates */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="federalRate">Federal Tax Rate (%)</Label>
                    <Input
                      id="federalRate"
                      type="number"
                      placeholder="22"
                      value={federalRate}
                      onChange={(e) => setFederalRate(e.target.value)}
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="stateRate">State Tax Rate (%)</Label>
                    <Input
                      id="stateRate"
                      type="number"
                      placeholder="5"
                      value={stateRate}
                      onChange={(e) => setStateRate(e.target.value)}
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Additional Deductions</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="retirementPercent">Retirement Contribution (%)</Label>
                      <Input
                        id="retirementPercent"
                        type="number"
                        placeholder="6"
                        value={retirementPercent}
                        onChange={(e) => setRetirementPercent(e.target.value)}
                        min="0"
                        max="100"
                        step="0.5"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="healthInsurance">Health Insurance ($/year)</Label>
                      <Input
                        id="healthInsurance"
                        type="number"
                        placeholder="0"
                        value={healthInsurance}
                        onChange={(e) => setHealthInsurance(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="otherDeductions">Other Deductions ($/year)</Label>
                      <Input
                        id="otherDeductions"
                        type="number"
                        placeholder="0"
                        value={otherDeductions}
                        onChange={(e) => setOtherDeductions(e.target.value)}
                        min="0"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTakeHome} className="w-full" size="lg">
                  Calculate Take-Home Pay
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">{getPayFrequencyLabel()} Take-Home Pay</p>
                      <p className="text-4xl font-bold text-green-600">{formatCurrency(result.netPay)}</p>
                      <p className="text-sm text-muted-foreground mt-1">Annual: {formatCurrency(result.annualNet)}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Gross Pay</p>
                        <p className="font-semibold">{formatCurrency(result.grossPay)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-muted-foreground">Total Deductions</p>
                        <p className="font-semibold text-red-600">-{formatCurrency(result.totalDeductions)}</p>
                      </div>
                    </div>

                    {/* Deductions Breakdown */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails} className="mt-3">
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full bg-transparent">
                          {showDetails ? "Hide" : "Show"} Deductions Breakdown
                          {showDetails ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2">
                        <div className="p-3 bg-white rounded-lg space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Federal Tax</span>
                            <span className="text-red-600">-{formatCurrency(result.federalTax)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>State Tax</span>
                            <span className="text-red-600">-{formatCurrency(result.stateTax)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Social Security (6.2%)</span>
                            <span className="text-red-600">-{formatCurrency(result.socialSecurity)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Medicare (1.45%)</span>
                            <span className="text-red-600">-{formatCurrency(result.medicare)}</span>
                          </div>
                          {result.retirement > 0 && (
                            <div className="flex justify-between">
                              <span>Retirement</span>
                              <span className="text-red-600">-{formatCurrency(result.retirement)}</span>
                            </div>
                          )}
                          {result.healthInsurance > 0 && (
                            <div className="flex justify-between">
                              <span>Health Insurance</span>
                              <span className="text-red-600">-{formatCurrency(result.healthInsurance)}</span>
                            </div>
                          )}
                          {result.otherDeductions > 0 && (
                            <div className="flex justify-between">
                              <span>Other</span>
                              <span className="text-red-600">-{formatCurrency(result.otherDeductions)}</span>
                            </div>
                          )}
                          <div className="flex justify-between pt-2 border-t font-semibold">
                            <span>Effective Tax Rate</span>
                            <span>{result.effectiveTaxRate}%</span>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Deductions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Social Security</span>
                      <span className="text-sm text-blue-600">6.2%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Medicare</span>
                      <span className="text-sm text-purple-600">1.45%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Federal Tax</span>
                      <span className="text-sm text-green-600">10-37%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">State Tax</span>
                      <span className="text-sm text-yellow-600">0-13.3%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">2024 Federal Tax Brackets</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 bg-muted rounded">
                      <p className="font-semibold">10%</p>
                      <p>$0 - $11,600</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-semibold">12%</p>
                      <p>$11,601 - $47,150</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-semibold">22%</p>
                      <p>$47,151 - $100,525</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-semibold">24%</p>
                      <p>$100,526 - $191,950</p>
                    </div>
                  </div>
                  <p className="text-xs mt-2">*Single filer brackets shown</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Your Paycheck</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Your take-home pay, also known as net pay, is the amount you receive after all deductions are
                  subtracted from your gross pay. These deductions include federal and state income taxes, Social
                  Security and Medicare taxes (FICA), retirement contributions, and health insurance premiums.
                  Understanding these deductions helps you plan your budget more effectively.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Ways to Increase Take-Home Pay</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While you can&apos;t avoid mandatory taxes, there are legal ways to optimize your take-home pay.
                  Contributing to pre-tax retirement accounts like 401(k)s reduces your taxable income. Health Savings
                  Accounts (HSAs) and Flexible Spending Accounts (FSAs) also offer tax advantages. Additionally,
                  reviewing your W-4 withholdings can help ensure you&apos;re not overpaying taxes throughout the year.
                </p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Take-home pay calculations are estimates and may vary based on tax laws, deductions, and individual
                  circumstances. This calculator uses simplified tax calculations and may not account for all credits,
                  deductions, or special circumstances. Consult a tax professional or payroll service for accurate
                  results.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
