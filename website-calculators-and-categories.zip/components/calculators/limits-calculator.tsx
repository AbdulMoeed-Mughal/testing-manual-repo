"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Infinity,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type LimitDirection = "two-sided" | "left" | "right"
type ApproachType = "finite" | "positive-infinity" | "negative-infinity"

interface LimitResult {
  limitValue: string
  leftLimit: string | null
  rightLimit: string | null
  exists: boolean
  indeterminateForm: string | null
  method: string
  steps: string[]
}

export function LimitsCalculator() {
  const [functionInput, setFunctionInput] = useState("")
  const [variable, setVariable] = useState("x")
  const [approachType, setApproachType] = useState<ApproachType>("finite")
  const [approachValue, setApproachValue] = useState("")
  const [direction, setDirection] = useState<LimitDirection>("two-sided")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<LimitResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  // Tokenize expression
  const tokenize = (expr: string): string[] => {
    const tokens: string[] = []
    let i = 0
    while (i < expr.length) {
      if (/\s/.test(expr[i])) {
        i++
        continue
      }
      if (/[0-9.]/.test(expr[i])) {
        let num = ""
        while (i < expr.length && /[0-9.]/.test(expr[i])) {
          num += expr[i++]
        }
        tokens.push(num)
      } else if (/[a-zA-Z]/.test(expr[i])) {
        let name = ""
        while (i < expr.length && /[a-zA-Z0-9]/.test(expr[i])) {
          name += expr[i++]
        }
        tokens.push(name)
      } else if (expr[i] === "*" && expr[i + 1] === "*") {
        tokens.push("**")
        i += 2
      } else {
        tokens.push(expr[i++])
      }
    }
    return tokens
  }

  // Parse and evaluate expression
  const evaluateExpression = (expr: string, varName: string, value: number): number => {
    // Preprocess: handle implicit multiplication and standard notation
    let processed = expr
      .replace(/\s+/g, "")
      .replace(/(\d)([a-zA-Z(])/g, "$1*$2")
      .replace(/([)])(\d)/g, "$1*$2")
      .replace(/([)])([a-zA-Z(])/g, "$1*$2")
      .replace(/\^/g, "**")

    // Replace variable with value
    const varRegex = new RegExp(`\\b${varName}\\b`, "g")
    processed = processed.replace(varRegex, `(${value})`)

    // Replace math functions
    processed = processed
      .replace(/sin\(/g, "Math.sin(")
      .replace(/cos\(/g, "Math.cos(")
      .replace(/tan\(/g, "Math.tan(")
      .replace(/ln\(/g, "Math.log(")
      .replace(/log\(/g, "Math.log10(")
      .replace(/sqrt\(/g, "Math.sqrt(")
      .replace(/abs\(/g, "Math.abs(")
      .replace(/exp\(/g, "Math.exp(")
      .replace(/\bpi\b/gi, "Math.PI")
      .replace(/\be\b/g, "Math.E")

    try {
      const result = Function(`"use strict"; return (${processed})`)()
      return result
    } catch {
      return Number.NaN
    }
  }

  // Detect indeterminate form
  const detectIndeterminateForm = (numerator: number, denominator: number): string | null => {
    if (Math.abs(numerator) < 1e-10 && Math.abs(denominator) < 1e-10) {
      return "0/0"
    }
    if (!isFinite(numerator) && !isFinite(denominator)) {
      return "∞/∞"
    }
    if (Math.abs(numerator) < 1e-10 && !isFinite(denominator)) {
      return "0 × ∞"
    }
    return null
  }

  // Numerical limit approximation
  const approximateLimit = (
    expr: string,
    varName: string,
    target: number,
    dir: LimitDirection,
  ): { value: number; steps: string[] } => {
    const steps: string[] = []
    const deltas = [0.1, 0.01, 0.001, 0.0001, 0.00001]

    const leftValues: number[] = []
    const rightValues: number[] = []

    if (dir === "two-sided" || dir === "left") {
      steps.push(`Approaching from the left (${varName} → ${target}⁻):`)
      for (const delta of deltas) {
        const x = target - delta
        const y = evaluateExpression(expr, varName, x)
        leftValues.push(y)
        steps.push(`  f(${x.toFixed(5)}) = ${isFinite(y) ? y.toPrecision(8) : y}`)
      }
    }

    if (dir === "two-sided" || dir === "right") {
      steps.push(`Approaching from the right (${varName} → ${target}⁺):`)
      for (const delta of deltas) {
        const x = target + delta
        const y = evaluateExpression(expr, varName, x)
        rightValues.push(y)
        steps.push(`  f(${x.toFixed(5)}) = ${isFinite(y) ? y.toPrecision(8) : y}`)
      }
    }

    let finalValue: number
    if (dir === "left") {
      finalValue = leftValues[leftValues.length - 1]
    } else if (dir === "right") {
      finalValue = rightValues[rightValues.length - 1]
    } else {
      const leftFinal = leftValues[leftValues.length - 1]
      const rightFinal = rightValues[rightValues.length - 1]

      if (Math.abs(leftFinal - rightFinal) < 0.0001) {
        finalValue = (leftFinal + rightFinal) / 2
        steps.push(`Left and right limits agree: limit exists`)
      } else {
        finalValue = Number.NaN
        steps.push(`Left limit (${leftFinal.toPrecision(6)}) ≠ Right limit (${rightFinal.toPrecision(6)})`)
        steps.push(`The two-sided limit does not exist`)
      }
    }

    return { value: finalValue, steps }
  }

  // Limit at infinity approximation
  const approximateLimitAtInfinity = (
    expr: string,
    varName: string,
    positive: boolean,
  ): { value: number; steps: string[] } => {
    const steps: string[] = []
    const values = positive ? [10, 100, 1000, 10000, 100000] : [-10, -100, -1000, -10000, -100000]

    steps.push(`Evaluating as ${varName} → ${positive ? "+∞" : "-∞"}:`)

    const results: number[] = []
    for (const x of values) {
      const y = evaluateExpression(expr, varName, x)
      results.push(y)
      steps.push(`  f(${x}) = ${isFinite(y) ? y.toPrecision(8) : y}`)
    }

    // Analyze trend
    const lastTwo = results.slice(-2)
    let finalValue: number

    if (lastTwo.every((v) => !isFinite(v) && v > 0)) {
      finalValue = Infinity
      steps.push(`The function approaches +∞`)
    } else if (lastTwo.every((v) => !isFinite(v) && v < 0)) {
      finalValue = -Infinity
      steps.push(`The function approaches -∞`)
    } else if (Math.abs(lastTwo[1] - lastTwo[0]) < Math.abs(lastTwo[0]) * 0.001) {
      finalValue = lastTwo[1]
      steps.push(`The function converges to approximately ${finalValue.toPrecision(6)}`)
    } else {
      finalValue = lastTwo[1]
      steps.push(`Estimated limit: ${finalValue.toPrecision(6)}`)
    }

    return { value: finalValue, steps }
  }

  const calculateLimit = () => {
    setError("")
    setResult(null)

    if (!functionInput.trim()) {
      setError("Please enter a function")
      return
    }

    if (approachType === "finite" && !approachValue.trim()) {
      setError("Please enter a value to approach")
      return
    }

    const steps: string[] = []
    let limitValue: number
    let leftLimit: number | null = null
    let rightLimit: number | null = null
    let method = "Numerical Approximation"
    let indeterminateForm: string | null = null

    steps.push(`Function: f(${variable}) = ${functionInput}`)

    if (approachType === "finite") {
      const target = Number.parseFloat(approachValue)
      if (isNaN(target)) {
        setError("Invalid approach value")
        return
      }

      steps.push(
        `Finding: lim (${variable} → ${target}${direction === "left" ? "⁻" : direction === "right" ? "⁺" : ""}) f(${variable})`,
      )
      steps.push("")

      // Try direct substitution first
      const directValue = evaluateExpression(functionInput, variable, target)
      steps.push(`Step 1: Try direct substitution`)
      steps.push(`  f(${target}) = ${isFinite(directValue) ? directValue : "undefined"}`)
      steps.push("")

      if (isFinite(directValue) && !isNaN(directValue)) {
        limitValue = directValue
        method = "Direct Substitution"
        steps.push(`Since direct substitution gives a finite value, the limit is ${directValue}`)
      } else {
        steps.push(`Direct substitution fails. Using numerical approximation...`)
        steps.push("")

        // Check for indeterminate form (simplified check)
        const nearValue = evaluateExpression(functionInput, variable, target + 0.0001)
        if (!isFinite(nearValue)) {
          indeterminateForm = "Undefined"
        }

        const { value, steps: approxSteps } = approximateLimit(functionInput, variable, target, direction)
        steps.push(...approxSteps)
        limitValue = value

        if (direction === "two-sided") {
          const leftResult = approximateLimit(functionInput, variable, target, "left")
          const rightResult = approximateLimit(functionInput, variable, target, "right")
          leftLimit = leftResult.value
          rightLimit = rightResult.value
        }
      }
    } else {
      const positive = approachType === "positive-infinity"
      steps.push(`Finding: lim (${variable} → ${positive ? "+∞" : "-∞"}) f(${variable})`)
      steps.push("")

      const { value, steps: approxSteps } = approximateLimitAtInfinity(functionInput, variable, positive)
      steps.push(...approxSteps)
      limitValue = value
      method = "Numerical Approximation at Infinity"
    }

    const exists = isFinite(limitValue) || limitValue === Infinity || limitValue === -Infinity

    setResult({
      limitValue: formatNumber(limitValue),
      leftLimit: leftLimit !== null ? formatNumber(leftLimit) : null,
      rightLimit: rightLimit !== null ? formatNumber(rightLimit) : null,
      exists: exists && !isNaN(limitValue),
      indeterminateForm,
      method,
      steps,
    })
  }

  const formatNumber = (num: number): string => {
    if (isNaN(num)) return "Does Not Exist"
    if (num === Infinity) return "+∞"
    if (num === -Infinity) return "-∞"
    if (Math.abs(num) < 1e-10) return "0"
    if (Number.isInteger(num)) return num.toString()
    return num.toPrecision(8).replace(/\.?0+$/, "")
  }

  const handleReset = () => {
    setFunctionInput("")
    setVariable("x")
    setApproachType("finite")
    setApproachValue("")
    setDirection("two-sided")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `lim (${variable} → ${approachType === "finite" ? approachValue : approachType === "positive-infinity" ? "+∞" : "-∞"}) ${functionInput} = ${result.limitValue}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Limits Calculator Result",
          text: `lim (${variable} → ${approachType === "finite" ? approachValue : approachType === "positive-infinity" ? "+∞" : "-∞"}) ${functionInput} = ${result.limitValue}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Infinity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Limits Calculator</CardTitle>
                    <CardDescription>Calculate function limits</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="function">Function f({variable})</Label>
                  <Input
                    id="function"
                    type="text"
                    placeholder="e.g., (x^2 - 1)/(x - 1), sin(x)/x"
                    value={functionInput}
                    onChange={(e) => setFunctionInput(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Supports: +, -, *, /, ^, sin, cos, tan, ln, log, sqrt, abs, exp, pi, e
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="variable">Variable</Label>
                    <Select value={variable} onValueChange={setVariable}>
                      <SelectTrigger id="variable">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="x">x</SelectItem>
                        <SelectItem value="t">t</SelectItem>
                        <SelectItem value="n">n</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="approach-type">Approach</Label>
                    <Select value={approachType} onValueChange={(v) => setApproachType(v as ApproachType)}>
                      <SelectTrigger id="approach-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="finite">Finite Value</SelectItem>
                        <SelectItem value="positive-infinity">+∞</SelectItem>
                        <SelectItem value="negative-infinity">-∞</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {approachType === "finite" && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="approach-value">Approach Value (a)</Label>
                      <Input
                        id="approach-value"
                        type="text"
                        placeholder="e.g., 0, 1, pi"
                        value={approachValue}
                        onChange={(e) => setApproachValue(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="direction">Direction</Label>
                      <Select value={direction} onValueChange={(v) => setDirection(v as LimitDirection)}>
                        <SelectTrigger id="direction">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="two-sided">Two-sided</SelectItem>
                          <SelectItem value="left">Left-hand (a⁻)</SelectItem>
                          <SelectItem value="right">Right-hand (a⁺)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateLimit} className="w-full" size="lg">
                  Calculate Limit
                </Button>

                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${result.exists ? "bg-green-50 border-green-200" : "bg-yellow-50 border-yellow-200"} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        lim ({variable} →{" "}
                        {approachType === "finite" ? approachValue : approachType === "positive-infinity" ? "+∞" : "-∞"}
                        {direction === "left" ? "⁻" : direction === "right" ? "⁺" : ""})
                      </p>
                      <p className={`text-4xl font-bold mb-2 ${result.exists ? "text-green-600" : "text-yellow-600"}`}>
                        {result.limitValue}
                      </p>
                      <p className="text-sm text-muted-foreground">Method: {result.method}</p>
                    </div>

                    {result.leftLimit !== null && result.rightLimit !== null && (
                      <div className="mt-4 grid grid-cols-2 gap-2 text-center">
                        <div className="p-2 bg-white/50 rounded-lg">
                          <p className="text-xs text-muted-foreground">Left-hand limit</p>
                          <p className="font-semibold">{result.leftLimit}</p>
                        </div>
                        <div className="p-2 bg-white/50 rounded-lg">
                          <p className="text-xs text-muted-foreground">Right-hand limit</p>
                          <p className="font-semibold">{result.rightLimit}</p>
                        </div>
                      </div>
                    )}

                    {result.indeterminateForm && (
                      <div className="mt-3 p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Indeterminate Form</p>
                        <p className="font-mono font-semibold">{result.indeterminateForm}</p>
                      </div>
                    )}

                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="flex items-center justify-between w-full p-2 bg-white/50 rounded-lg hover:bg-white/70 transition-colors"
                        >
                          <span className="text-sm font-medium">Step-by-step solution</span>
                          {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>
                        {showDetails && (
                          <div className="mt-2 p-3 bg-white/50 rounded-lg text-sm font-mono whitespace-pre-wrap">
                            {result.steps.map((step, i) => (
                              <div key={i} className={step === "" ? "h-2" : ""}>
                                {step}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Limits</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded-lg">
                      <span className="font-mono">lim (x→0) sin(x)/x</span>
                      <span className="font-semibold">= 1</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded-lg">
                      <span className="font-mono">lim (x→0) (1-cos(x))/x</span>
                      <span className="font-semibold">= 0</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded-lg">
                      <span className="font-mono">lim (x→∞) (1+1/x)^x</span>
                      <span className="font-semibold">= e</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded-lg">
                      <span className="font-mono">lim (x→0) (e^x-1)/x</span>
                      <span className="font-semibold">= 1</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Indeterminate Forms</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>Forms that require special techniques:</p>
                  <div className="grid grid-cols-4 gap-2 text-center font-mono">
                    <div className="p-2 bg-muted rounded">0/0</div>
                    <div className="p-2 bg-muted rounded">∞/∞</div>
                    <div className="p-2 bg-muted rounded">0×∞</div>
                    <div className="p-2 bg-muted rounded">∞-∞</div>
                    <div className="p-2 bg-muted rounded">0⁰</div>
                    <div className="p-2 bg-muted rounded">∞⁰</div>
                    <div className="p-2 bg-muted rounded">1^∞</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <ul className="list-disc list-inside space-y-1">
                    <li>Use ^ for exponents: x^2, e^x</li>
                    <li>Use / for division: (x-1)/(x+1)</li>
                    <li>Functions: sin, cos, tan, ln, log, sqrt</li>
                    <li>Constants: pi, e</li>
                    <li>Implicit multiplication: 2x = 2*x</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Limit?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In calculus, a limit describes the value that a function approaches as the input (or variable)
                  approaches some value. Limits are fundamental to calculus and mathematical analysis, providing the
                  foundation for defining derivatives and integrals. The concept of a limit allows us to analyze
                  function behavior near points where the function may not be directly defined.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The notation lim (x → a) f(x) = L means that as x gets arbitrarily close to a, the function f(x) gets
                  arbitrarily close to L. This is true whether x approaches a from the left, from the right, or from
                  both sides. Understanding limits is essential for studying continuity, derivatives, and the behavior
                  of functions at boundaries and infinity.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Infinity className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Limits</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Two-sided Limit</h4>
                    <p className="text-blue-700 text-sm">
                      lim (x → a) f(x) exists only when both left and right limits exist and are equal.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">One-sided Limits</h4>
                    <p className="text-green-700 text-sm">
                      Left-hand limit (x → a⁻) and right-hand limit (x → a⁺) approach from one direction only.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Limits at Infinity</h4>
                    <p className="text-purple-700 text-sm">
                      lim (x → ±∞) f(x) describes the horizontal asymptotic behavior of the function.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Infinite Limits</h4>
                    <p className="text-orange-700 text-sm">
                      When f(x) → ±∞ as x → a, describing vertical asymptotic behavior.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Limit calculations follow standard calculus rules. This calculator uses numerical approximation
                  methods and may not handle all algebraic simplifications. Results depend on correct function input and
                  the selected approach value. For complex limits involving indeterminate forms, algebraic manipulation
                  or L'Hôpital's Rule may be required for exact solutions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
