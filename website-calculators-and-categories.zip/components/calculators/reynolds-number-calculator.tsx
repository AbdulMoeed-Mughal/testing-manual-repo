"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Waves, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface ReynoldsResult {
  reynoldsNumber: number
  regime: string
  color: string
  bgColor: string
}

export function ReynoldsNumberCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [density, setDensity] = useState("")
  const [velocity, setVelocity] = useState("")
  const [diameter, setDiameter] = useState("")
  const [viscosity, setViscosity] = useState("")
  const [result, setResult] = useState<ReynoldsResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateReynoldsNumber = () => {
    setError("")
    setResult(null)

    const rho = Number.parseFloat(density)
    const v = Number.parseFloat(velocity)
    const D = Number.parseFloat(diameter)
    const mu = Number.parseFloat(viscosity)

    if (isNaN(rho) || rho <= 0) {
      setError("Please enter a valid density greater than 0")
      return
    }
    if (isNaN(v) || v <= 0) {
      setError("Please enter a valid velocity greater than 0")
      return
    }
    if (isNaN(D) || D <= 0) {
      setError("Please enter a valid diameter/length greater than 0")
      return
    }
    if (isNaN(mu) || mu <= 0) {
      setError("Please enter a valid viscosity greater than 0")
      return
    }

    // Convert imperial to SI if needed
    let rhoSI = rho
    let vSI = v
    let DSI = D
    let muSI = mu

    if (unitSystem === "imperial") {
      // slug/ft³ to kg/m³
      rhoSI = rho * 515.379
      // ft/s to m/s
      vSI = v * 0.3048
      // ft to m
      DSI = D * 0.3048
      // lb/(ft·s) to Pa·s
      muSI = mu * 1.48816
    }

    // Re = (ρ × v × D) / μ
    const Re = (rhoSI * vSI * DSI) / muSI

    let regime: string
    let color: string
    let bgColor: string

    if (Re < 2300) {
      regime = "Laminar Flow"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (Re <= 4000) {
      regime = "Transitional Flow"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      regime = "Turbulent Flow"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({ reynoldsNumber: Re, regime, color, bgColor })
  }

  const handleReset = () => {
    setDensity("")
    setVelocity("")
    setDiameter("")
    setViscosity("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const formattedRe =
        result.reynoldsNumber < 10000 ? result.reynoldsNumber.toFixed(2) : result.reynoldsNumber.toExponential(3)
      await navigator.clipboard.writeText(`Reynolds Number: ${formattedRe} (${result.regime})`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const formattedRe =
        result.reynoldsNumber < 10000 ? result.reynoldsNumber.toFixed(2) : result.reynoldsNumber.toExponential(3)
      try {
        await navigator.share({
          title: "Reynolds Number Result",
          text: `I calculated the Reynolds Number using CalcHub! Re = ${formattedRe} (${result.regime})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setDensity("")
    setVelocity("")
    setDiameter("")
    setViscosity("")
    setResult(null)
    setError("")
  }

  const formatNumber = (num: number): string => {
    if (num < 0.001 || num >= 1e6) {
      return num.toExponential(3)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 2 })
  }

  // Common fluid presets
  const fluidPresets =
    unitSystem === "metric"
      ? [
          { name: "Water (20°C)", density: "998", viscosity: "0.001002" },
          { name: "Air (20°C)", density: "1.204", viscosity: "0.0000181" },
          { name: "Oil (SAE 30)", density: "880", viscosity: "0.29" },
          { name: "Glycerin", density: "1261", viscosity: "1.5" },
        ]
      : [
          { name: "Water (68°F)", density: "1.936", viscosity: "0.000672" },
          { name: "Air (68°F)", density: "0.00234", viscosity: "0.0000122" },
          { name: "Oil (SAE 30)", density: "1.707", viscosity: "0.195" },
          { name: "Glycerin", density: "2.447", viscosity: "1.009" },
        ]

  const applyPreset = (preset: (typeof fluidPresets)[0]) => {
    setDensity(preset.density)
    setViscosity(preset.viscosity)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Waves className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Reynolds Number Calculator</CardTitle>
                    <CardDescription>Analyze flow regimes in fluid mechanics</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Fluid Presets */}
                <div className="space-y-2">
                  <Label>Quick Fluid Selection</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {fluidPresets.map((preset) => (
                      <Button
                        key={preset.name}
                        variant="outline"
                        size="sm"
                        onClick={() => applyPreset(preset)}
                        className="text-xs"
                      >
                        {preset.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Density Input */}
                <div className="space-y-2">
                  <Label htmlFor="density">Fluid Density (ρ) [{unitSystem === "metric" ? "kg/m³" : "slug/ft³"}]</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "998" : "1.936"}`}
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Velocity Input */}
                <div className="space-y-2">
                  <Label htmlFor="velocity">Fluid Velocity (v) [{unitSystem === "metric" ? "m/s" : "ft/s"}]</Label>
                  <Input
                    id="velocity"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "2" : "6.56"}`}
                    value={velocity}
                    onChange={(e) => setVelocity(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Diameter Input */}
                <div className="space-y-2">
                  <Label htmlFor="diameter">
                    Characteristic Length/Diameter (D) [{unitSystem === "metric" ? "m" : "ft"}]
                  </Label>
                  <Input
                    id="diameter"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "0.05" : "0.164"}`}
                    value={diameter}
                    onChange={(e) => setDiameter(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Viscosity Input */}
                <div className="space-y-2">
                  <Label htmlFor="viscosity">
                    Dynamic Viscosity (μ) [{unitSystem === "metric" ? "Pa·s" : "lb/(ft·s)"}]
                  </Label>
                  <Input
                    id="viscosity"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "0.001002" : "0.000672"}`}
                    value={viscosity}
                    onChange={(e) => setViscosity(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateReynoldsNumber} className="w-full" size="lg">
                  Calculate Reynolds Number
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Reynolds Number (Re)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-2`}>{formatNumber(result.reynoldsNumber)}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.regime}</p>
                    </div>

                    {/* Step-by-step toggle */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-muted-foreground"
                    >
                      {showSteps ? "Hide" : "Show"} Calculation Steps
                    </Button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p className="font-mono">Re = (ρ × v × D) / μ</p>
                        <p className="font-mono">
                          Re = ({density} × {velocity} × {diameter}) / {viscosity}
                        </p>
                        <p className="font-mono">Re = {formatNumber(result.reynoldsNumber)}</p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Flow Regime Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Laminar Flow</span>
                      <span className="text-sm text-green-600">Re {"<"} 2,300</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Transitional Flow</span>
                      <span className="text-sm text-yellow-600">2,300 – 4,000</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Turbulent Flow</span>
                      <span className="text-sm text-red-600">Re {">"} 4,000</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Reynolds Number Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-lg">Re = (ρ × v × D) / μ</p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>ρ</strong> = Fluid density
                    </p>
                    <p>
                      <strong>v</strong> = Flow velocity
                    </p>
                    <p>
                      <strong>D</strong> = Characteristic length (pipe diameter)
                    </p>
                    <p>
                      <strong>μ</strong> = Dynamic viscosity
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Reynolds Number */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Reynolds Number?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Reynolds number (Re) is a dimensionless quantity in fluid mechanics that helps predict flow
                  patterns in different fluid flow situations. It is defined as the ratio of inertial forces to viscous
                  forces within a fluid. Named after Osborne Reynolds, who popularized its use in 1883, this number is
                  fundamental to understanding whether fluid flow will be laminar (smooth) or turbulent (chaotic).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Reynolds number is crucial in engineering applications ranging from pipe flow analysis and
                  aerodynamics to heat exchanger design and chemical reactor engineering. It allows engineers to scale
                  experiments from model to prototype and predict flow behavior without conducting full-scale tests.
                </p>
              </CardContent>
            </Card>

            {/* Flow Regimes Explained */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Waves className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Flow Regimes</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Laminar Flow (Re {"<"} 2,300)</h4>
                    <p className="text-green-700 text-sm">
                      In laminar flow, fluid particles move in smooth, parallel layers with no disruption between them.
                      The flow is orderly and predictable, making it ideal for applications requiring precise control.
                      Examples include blood flow in small vessels, honey pouring, and slow-moving water in small pipes.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Transitional Flow (2,300 ≤ Re ≤ 4,000)</h4>
                    <p className="text-yellow-700 text-sm">
                      Transitional flow occurs between laminar and turbulent regimes. The flow may switch between the
                      two states unpredictably. This region is often avoided in engineering design due to its
                      unpredictable nature and difficulty in analysis.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Turbulent Flow (Re {">"} 4,000)</h4>
                    <p className="text-red-700 text-sm">
                      Turbulent flow is characterized by chaotic, irregular fluid motion with eddies, swirls, and rapid
                      variations in pressure and velocity. While harder to analyze mathematically, it provides better
                      mixing and heat transfer. Examples include river rapids, smoke from chimneys, and most industrial
                      pipe flows.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-amber-700">
                  Reynolds number calculations are estimates based on ideal conditions. Actual flow behavior may vary
                  due to surface roughness, temperature gradients, pipe geometry, entrance effects, and other
                  environmental factors. The critical Reynolds numbers (2,300 and 4,000) are guidelines for circular
                  pipes and may differ for other geometries. Consult fluid mechanics references and conduct experiments
                  for precise analysis in critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
