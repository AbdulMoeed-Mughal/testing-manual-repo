"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Beaker,
  Scale,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Periodic table data with atomic weights
const elements: Record<string, number> = {
  H: 1.008,
  He: 4.003,
  Li: 6.941,
  Be: 9.012,
  B: 10.81,
  C: 12.01,
  N: 14.01,
  O: 16.0,
  F: 19.0,
  Ne: 20.18,
  Na: 22.99,
  Mg: 24.31,
  Al: 26.98,
  Si: 28.09,
  P: 30.97,
  S: 32.07,
  Cl: 35.45,
  Ar: 39.95,
  K: 39.1,
  Ca: 40.08,
  Sc: 44.96,
  Ti: 47.87,
  V: 50.94,
  Cr: 52.0,
  Mn: 54.94,
  Fe: 55.85,
  Co: 58.93,
  Ni: 58.69,
  Cu: 63.55,
  Zn: 65.38,
  Ga: 69.72,
  Ge: 72.63,
  As: 74.92,
  Se: 78.97,
  Br: 79.9,
  Kr: 83.8,
  Rb: 85.47,
  Sr: 87.62,
  Y: 88.91,
  Zr: 91.22,
  Nb: 92.91,
  Mo: 95.95,
  Tc: 98.0,
  Ru: 101.1,
  Rh: 102.9,
  Pd: 106.4,
  Ag: 107.9,
  Cd: 112.4,
  In: 114.8,
  Sn: 118.7,
  Sb: 121.8,
  Te: 127.6,
  I: 126.9,
  Xe: 131.3,
  Cs: 132.9,
  Ba: 137.3,
  La: 138.9,
  Ce: 140.1,
  Pr: 140.9,
  Nd: 144.2,
  Pm: 145.0,
  Sm: 150.4,
  Eu: 152.0,
  Gd: 157.3,
  Tb: 158.9,
  Dy: 162.5,
  Ho: 164.9,
  Er: 167.3,
  Tm: 168.9,
  Yb: 173.0,
  Lu: 175.0,
  Hf: 178.5,
  Ta: 180.9,
  W: 183.8,
  Re: 186.2,
  Os: 190.2,
  Ir: 192.2,
  Pt: 195.1,
  Au: 197.0,
  Hg: 200.6,
  Tl: 204.4,
  Pb: 207.2,
  Bi: 209.0,
  Po: 209.0,
  At: 210.0,
  Rn: 222.0,
  Fr: 223.0,
  Ra: 226.0,
  Ac: 227.0,
  Th: 232.0,
  Pa: 231.0,
  U: 238.0,
  Np: 237.0,
  Pu: 244.0,
  Am: 243.0,
  Cm: 247.0,
}

interface ParsedCompound {
  formula: string
  coefficient: number
  elements: Record<string, number>
  molecularWeight: number
}

interface ReactionResult {
  limitingReagent: string
  limitingIndex: number
  theoreticalYieldMoles: number
  theoreticalYieldGrams: number
  excessReagents: {
    formula: string
    excessMoles: number
    excessGrams: number
  }[]
  steps: string[]
}

export function LimitingReagentCalculator() {
  const [equation, setEquation] = useState("")
  const [reactantAmounts, setReactantAmounts] = useState<string[]>(["", ""])
  const [reactantUnits, setReactantUnits] = useState<string[]>(["g", "g"])
  const [selectedProduct, setSelectedProduct] = useState<number>(0)
  const [result, setResult] = useState<ReactionResult | null>(null)
  const [parsedReactants, setParsedReactants] = useState<ParsedCompound[]>([])
  const [parsedProducts, setParsedProducts] = useState<ParsedCompound[]>([])
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  // Parse chemical formula to get element counts
  const parseFormula = (formula: string): Record<string, number> => {
    const elementCounts: Record<string, number> = {}

    const parseGroup = (str: string, multiplier = 1): void => {
      let i = 0
      while (i < str.length) {
        if (str[i] === "(") {
          let depth = 1
          let j = i + 1
          while (depth > 0 && j < str.length) {
            if (str[j] === "(") depth++
            if (str[j] === ")") depth--
            j++
          }
          const innerGroup = str.slice(i + 1, j - 1)
          let numStr = ""
          while (j < str.length && /\d/.test(str[j])) {
            numStr += str[j]
            j++
          }
          const groupMultiplier = numStr ? Number.parseInt(numStr) : 1
          parseGroup(innerGroup, multiplier * groupMultiplier)
          i = j
        } else if (/[A-Z]/.test(str[i])) {
          let element = str[i]
          i++
          while (i < str.length && /[a-z]/.test(str[i])) {
            element += str[i]
            i++
          }
          let numStr = ""
          while (i < str.length && /\d/.test(str[i])) {
            numStr += str[i]
            i++
          }
          const count = numStr ? Number.parseInt(numStr) : 1
          elementCounts[element] = (elementCounts[element] || 0) + count * multiplier
        } else {
          i++
        }
      }
    }

    parseGroup(formula)
    return elementCounts
  }

  // Calculate molecular weight from element counts
  const calculateMolecularWeight = (elementCounts: Record<string, number>): number => {
    let weight = 0
    for (const [element, count] of Object.entries(elementCounts)) {
      if (elements[element]) {
        weight += elements[element] * count
      }
    }
    return weight
  }

  // Parse equation into reactants and products
  const parseEquation = (eq: string): { reactants: ParsedCompound[]; products: ParsedCompound[] } | null => {
    try {
      // Support different arrow formats
      const arrowMatch = eq.match(/(.+?)\s*(?:→|->|=|=>)\s*(.+)/)
      if (!arrowMatch) return null

      const parseCompounds = (side: string): ParsedCompound[] => {
        const compounds = side
          .split("+")
          .map((c) => c.trim())
          .filter((c) => c)
        return compounds
          .map((compound) => {
            // Extract coefficient
            const coeffMatch = compound.match(/^(\d*)\s*([A-Z].*)$/)
            if (!coeffMatch) return null

            const coefficient = coeffMatch[1] ? Number.parseInt(coeffMatch[1]) : 1
            const formula = coeffMatch[2].trim()
            const elementCounts = parseFormula(formula)
            const molecularWeight = calculateMolecularWeight(elementCounts)

            return {
              formula,
              coefficient,
              elements: elementCounts,
              molecularWeight,
            }
          })
          .filter((c): c is ParsedCompound => c !== null)
      }

      const reactants = parseCompounds(arrowMatch[1])
      const products = parseCompounds(arrowMatch[2])

      if (reactants.length < 2 || products.length < 1) return null

      return { reactants, products }
    } catch {
      return null
    }
  }

  // Handle equation change
  const handleEquationChange = (value: string) => {
    setEquation(value)
    setResult(null)
    setError("")

    const parsed = parseEquation(value)
    if (parsed) {
      setParsedReactants(parsed.reactants)
      setParsedProducts(parsed.products)
      // Adjust reactant amounts array
      setReactantAmounts((prev) => {
        const newAmounts = [...prev]
        while (newAmounts.length < parsed.reactants.length) newAmounts.push("")
        return newAmounts.slice(0, parsed.reactants.length)
      })
      setReactantUnits((prev) => {
        const newUnits = [...prev]
        while (newUnits.length < parsed.reactants.length) newUnits.push("g")
        return newUnits.slice(0, parsed.reactants.length)
      })
      setSelectedProduct(0)
    } else {
      setParsedReactants([])
      setParsedProducts([])
    }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (parsedReactants.length < 2) {
      setError("Please enter a valid balanced equation with at least 2 reactants")
      return
    }

    // Validate all reactant amounts
    const reactantMoles: number[] = []
    const steps: string[] = []

    steps.push("Step 1: Convert all reactants to moles")

    for (let i = 0; i < parsedReactants.length; i++) {
      const amount = Number.parseFloat(reactantAmounts[i])
      if (isNaN(amount) || amount <= 0) {
        setError(`Please enter a valid positive amount for ${parsedReactants[i].formula}`)
        return
      }

      const mw = parsedReactants[i].molecularWeight
      if (mw <= 0) {
        setError(`Could not calculate molecular weight for ${parsedReactants[i].formula}. Check the formula.`)
        return
      }

      let moles: number
      if (reactantUnits[i] === "mol") {
        moles = amount
        steps.push(`  ${parsedReactants[i].formula}: ${amount.toFixed(4)} mol (given)`)
      } else {
        moles = amount / mw
        steps.push(`  ${parsedReactants[i].formula}: ${amount} g ÷ ${mw.toFixed(2)} g/mol = ${moles.toFixed(4)} mol`)
      }
      reactantMoles.push(moles)
    }

    // Calculate which reactant produces the least product
    const product = parsedProducts[selectedProduct]
    const productCoeff = product.coefficient

    steps.push("")
    steps.push("Step 2: Calculate moles of product each reactant can produce")

    const productMolesFromEach: number[] = []
    for (let i = 0; i < parsedReactants.length; i++) {
      const reactant = parsedReactants[i]
      const molesProduct = (reactantMoles[i] / reactant.coefficient) * productCoeff
      productMolesFromEach.push(molesProduct)
      steps.push(
        `  From ${reactant.formula}: (${reactantMoles[i].toFixed(4)} mol × ${productCoeff}) ÷ ${reactant.coefficient} = ${molesProduct.toFixed(4)} mol ${product.formula}`,
      )
    }

    // Find limiting reagent (produces least product)
    const minProductMoles = Math.min(...productMolesFromEach)
    const limitingIndex = productMolesFromEach.indexOf(minProductMoles)
    const limitingReagent = parsedReactants[limitingIndex].formula

    steps.push("")
    steps.push(`Step 3: Identify limiting reagent`)
    steps.push(`  ${limitingReagent} produces the least amount of product (${minProductMoles.toFixed(4)} mol)`)
    steps.push(`  Therefore, ${limitingReagent} is the LIMITING REAGENT`)

    // Calculate theoretical yield
    const theoreticalYieldMoles = minProductMoles
    const theoreticalYieldGrams = theoreticalYieldMoles * product.molecularWeight

    steps.push("")
    steps.push("Step 4: Calculate theoretical yield")
    steps.push(
      `  Theoretical yield = ${theoreticalYieldMoles.toFixed(4)} mol × ${product.molecularWeight.toFixed(2)} g/mol`,
    )
    steps.push(`  Theoretical yield = ${theoreticalYieldGrams.toFixed(4)} g ${product.formula}`)

    // Calculate excess reagents
    steps.push("")
    steps.push("Step 5: Calculate excess reagents remaining")

    const excessReagents: { formula: string; excessMoles: number; excessGrams: number }[] = []
    for (let i = 0; i < parsedReactants.length; i++) {
      if (i !== limitingIndex) {
        const reactant = parsedReactants[i]
        // Moles of this reactant consumed
        const molesConsumed = (theoreticalYieldMoles / productCoeff) * reactant.coefficient
        const molesExcess = reactantMoles[i] - molesConsumed
        const gramsExcess = molesExcess * reactant.molecularWeight

        excessReagents.push({
          formula: reactant.formula,
          excessMoles: molesExcess,
          excessGrams: gramsExcess,
        })

        steps.push(
          `  ${reactant.formula}: ${reactantMoles[i].toFixed(4)} mol - ${molesConsumed.toFixed(4)} mol used = ${molesExcess.toFixed(4)} mol excess (${gramsExcess.toFixed(4)} g)`,
        )
      }
    }

    setResult({
      limitingReagent,
      limitingIndex,
      theoreticalYieldMoles,
      theoreticalYieldGrams,
      excessReagents,
      steps,
    })
  }

  const handleReset = () => {
    setEquation("")
    setReactantAmounts(["", ""])
    setReactantUnits(["g", "g"])
    setSelectedProduct(0)
    setResult(null)
    setParsedReactants([])
    setParsedProducts([])
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Limiting Reagent: ${result.limitingReagent}\nTheoretical Yield: ${result.theoreticalYieldGrams.toFixed(4)} g (${result.theoreticalYieldMoles.toFixed(4)} mol)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Limiting Reagent Calculation",
          text: `I calculated the limiting reagent using CalcHub! Limiting reagent: ${result.limitingReagent}, Theoretical yield: ${result.theoreticalYieldGrams.toFixed(4)} g`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const quickExamples = [
    { label: "2H₂ + O₂ → 2H₂O", equation: "2H2 + O2 -> 2H2O" },
    { label: "N₂ + 3H₂ → 2NH₃", equation: "N2 + 3H2 -> 2NH3" },
    { label: "2Al + 3Cl₂ → 2AlCl₃", equation: "2Al + 3Cl2 -> 2AlCl3" },
    { label: "CH₄ + 2O₂ → CO₂ + 2H₂O", equation: "CH4 + 2O2 -> CO2 + 2H2O" },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Limiting Reagent Calculator</CardTitle>
                    <CardDescription>Identify limiting reagent & theoretical yield</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Chemical Equation Input */}
                <div className="space-y-2">
                  <Label htmlFor="equation">Balanced Chemical Equation</Label>
                  <Input
                    id="equation"
                    type="text"
                    placeholder="e.g., 2H2 + O2 -> 2H2O"
                    value={equation}
                    onChange={(e) => handleEquationChange(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Use -{">"}, →, or = as arrow. Include coefficients.</p>
                </div>

                {/* Quick Examples */}
                <div className="space-y-2">
                  <Label className="text-sm">Quick Examples</Label>
                  <div className="flex flex-wrap gap-2">
                    {quickExamples.map((ex, i) => (
                      <Button
                        key={i}
                        variant="outline"
                        size="sm"
                        onClick={() => handleEquationChange(ex.equation)}
                        className="text-xs"
                      >
                        {ex.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Reactant Amounts */}
                {parsedReactants.length >= 2 && (
                  <div className="space-y-3 p-4 bg-muted/50 rounded-lg">
                    <Label className="text-sm font-medium">Reactant Quantities</Label>
                    {parsedReactants.map((reactant, i) => (
                      <div key={i} className="grid grid-cols-[1fr,auto,auto] gap-2 items-center">
                        <div className="text-sm font-medium text-purple-700 min-w-[60px]">
                          {reactant.coefficient > 1 ? reactant.coefficient : ""}
                          {reactant.formula}
                        </div>
                        <Input
                          type="number"
                          placeholder="Amount"
                          value={reactantAmounts[i] || ""}
                          onChange={(e) => {
                            const newAmounts = [...reactantAmounts]
                            newAmounts[i] = e.target.value
                            setReactantAmounts(newAmounts)
                          }}
                          className="w-24"
                          min="0"
                          step="0.01"
                        />
                        <Select
                          value={reactantUnits[i] || "g"}
                          onValueChange={(value) => {
                            const newUnits = [...reactantUnits]
                            newUnits[i] = value
                            setReactantUnits(newUnits)
                          }}
                        >
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="g">g</SelectItem>
                            <SelectItem value="mol">mol</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ))}
                    <p className="text-xs text-muted-foreground mt-2">
                      MW:{" "}
                      {parsedReactants.map((r) => `${r.formula} = ${r.molecularWeight.toFixed(2)} g/mol`).join(", ")}
                    </p>
                  </div>
                )}

                {/* Product Selection */}
                {parsedProducts.length > 1 && (
                  <div className="space-y-2">
                    <Label>Calculate Yield For</Label>
                    <Select
                      value={selectedProduct.toString()}
                      onValueChange={(value) => setSelectedProduct(Number.parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {parsedProducts.map((product, i) => (
                          <SelectItem key={i} value={i.toString()}>
                            {product.coefficient > 1 ? product.coefficient : ""}
                            {product.formula} ({product.molecularWeight.toFixed(2)} g/mol)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg" disabled={parsedReactants.length < 2}>
                  Calculate Limiting Reagent
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4">
                    {/* Main Result */}
                    <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                      <div className="text-center space-y-3">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Limiting Reagent</p>
                          <p className="text-3xl font-bold text-purple-600">{result.limitingReagent}</p>
                        </div>
                        <div className="border-t border-purple-200 pt-3">
                          <p className="text-sm text-muted-foreground mb-1">
                            Theoretical Yield of {parsedProducts[selectedProduct]?.formula}
                          </p>
                          <p className="text-2xl font-bold text-green-600">
                            {result.theoreticalYieldGrams.toFixed(4)} g
                          </p>
                          <p className="text-sm text-muted-foreground">
                            ({result.theoreticalYieldMoles.toFixed(4)} mol)
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Excess Reagents */}
                    {result.excessReagents.length > 0 && (
                      <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
                        <p className="text-sm font-medium text-amber-800 mb-2">Excess Reagents Remaining</p>
                        {result.excessReagents.map((ex, i) => (
                          <div key={i} className="flex justify-between text-sm text-amber-700">
                            <span>{ex.formula}</span>
                            <span>
                              {ex.excessGrams.toFixed(4)} g ({ex.excessMoles.toFixed(4)} mol)
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Step by Step */}
                    <div className="border rounded-lg">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="w-full flex items-center justify-between p-3 text-sm font-medium hover:bg-muted/50 transition-colors"
                      >
                        <span>Step-by-Step Solution</span>
                        {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                      {showSteps && (
                        <div className="p-3 pt-0 text-sm text-muted-foreground font-mono whitespace-pre-wrap border-t">
                          {result.steps.join("\n")}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Scale className="h-5 w-5 text-purple-600" />
                    How It Works
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">1. Convert to Moles</p>
                    <p>n = mass (g) ÷ molecular weight (g/mol)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">2. Use Mole Ratios</p>
                    <p>Compare moles of product each reactant can produce</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">3. Find Limiting Reagent</p>
                    <p>The reactant producing the least product is limiting</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Beaker className="h-5 w-5 text-purple-600" />
                    Key Formulas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-mono text-sm text-center text-purple-700">Moles = Mass ÷ Molar Mass</p>
                  </div>
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-mono text-sm text-center text-purple-700">
                      Product Moles = (Reactant Moles × Product Coeff) ÷ Reactant Coeff
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Important Note</p>
                      <p>
                        Results assume complete reaction and ideal conditions unless specified otherwise. Always verify
                        calculations for laboratory work.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Limiting Reagent?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In a chemical reaction, the limiting reagent (also called the limiting reactant) is the substance that
                  is completely consumed first and determines the maximum amount of product that can be formed. Once the
                  limiting reagent is used up, the reaction stops, regardless of how much of the other reactants (excess
                  reagents) remain. Understanding limiting reagents is fundamental to stoichiometry and essential for
                  efficient chemical synthesis in both laboratory and industrial settings.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept is analogous to baking: if a recipe calls for 2 eggs and 1 cup of flour per cake, but you
                  have 4 eggs and 1 cup of flour, you can only make 1 cake because flour is your "limiting ingredient."
                  The extra eggs become your "excess reagent" and remain unused.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Finding the Limiting Reagent</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To identify the limiting reagent, follow these systematic steps:
                </p>
                <div className="mt-4 space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Step 1: Balance the Equation</h4>
                    <p className="text-purple-700 text-sm">
                      Ensure your chemical equation is balanced. The coefficients represent the mole ratios of reactants
                      and products, which are essential for stoichiometric calculations.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Step 2: Convert to Moles</h4>
                    <p className="text-blue-700 text-sm">
                      Convert all given quantities to moles using the formula: moles = mass ÷ molar mass. This allows
                      direct comparison using mole ratios from the balanced equation.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Step 3: Calculate Product Potential</h4>
                    <p className="text-green-700 text-sm">
                      For each reactant, calculate how much product it could produce if it were completely consumed. Use
                      the mole ratios from the balanced equation.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Step 4: Compare Results</h4>
                    <p className="text-amber-700 text-sm">
                      The reactant that produces the smallest amount of product is the limiting reagent. This amount
                      represents the theoretical yield of the reaction.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding limiting reagents has numerous real-world applications:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Industrial Chemistry:</strong> Optimizing reactant quantities minimizes waste and reduces
                    costs. Excess reagents can be expensive and may require additional processing.
                  </li>
                  <li>
                    <strong>Pharmaceutical Manufacturing:</strong> Precise stoichiometry ensures correct drug dosages
                    and maximizes yield of expensive active ingredients.
                  </li>
                  <li>
                    <strong>Environmental Science:</strong> Calculating limiting nutrients in ecosystems helps
                    understand growth limitations and eutrophication potential.
                  </li>
                  <li>
                    <strong>Laboratory Research:</strong> Knowing the limiting reagent helps plan experiments
                    efficiently and predict product yields accurately.
                  </li>
                  <li>
                    <strong>Food Science:</strong> Recipe scaling and ingredient optimization for large-scale food
                    production relies on similar stoichiometric principles.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
