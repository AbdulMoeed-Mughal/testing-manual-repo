"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Check,
  Info,
  Calculator,
  X,
  ChevronDown,
  ChevronUp,
  Plus,
  Divide,
  Equal,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Switch } from "@/components/ui/switch"

type Operation = "simplify" | "add" | "subtract" | "multiply" | "divide" | "factor" | "expand" | "evaluate" | "roots"

interface Term {
  coefficient: number
  exponent: number
}

interface PolynomialResult {
  result: string
  steps: string[]
  factored?: string
  expanded?: string
  roots?: { value: string; multiplicity: number }[]
  evaluatedValue?: number
  remainder?: string
}

export function PolynomialCalculator() {
  const [polynomial1, setPolynomial1] = useState("")
  const [polynomial2, setPolynomial2] = useState("")
  const [variable, setVariable] = useState("x")
  const [operation, setOperation] = useState<Operation>("simplify")
  const [evaluateAt, setEvaluateAt] = useState("")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<PolynomialResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  // Parse polynomial string into terms
  const parsePolynomial = (expr: string, v: string): Term[] => {
    if (!expr.trim()) return []

    // Normalize the expression
    let normalized = expr
      .replace(/\s+/g, "")
      .replace(/−/g, "-")
      .replace(/\*\*/g, "^")
      .replace(new RegExp(`${v}\\^(\\d+)`, "g"), `${v}^$1`)

    // Add + before negative terms for splitting
    normalized = normalized.replace(/(?<!^)-/g, "+-")

    const terms: Term[] = []
    const termStrings = normalized.split("+").filter((t) => t !== "")

    for (const termStr of termStrings) {
      let coefficient = 1
      let exponent = 0

      if (termStr === v) {
        coefficient = 1
        exponent = 1
      } else if (termStr === `-${v}`) {
        coefficient = -1
        exponent = 1
      } else if (termStr.includes(v)) {
        const match = termStr.match(new RegExp(`^([+-]?\\d*\\.?\\d*)${v}(?:\\^(\\d+))?$`))
        if (match) {
          coefficient = match[1] === "" || match[1] === "+" ? 1 : match[1] === "-" ? -1 : Number.parseFloat(match[1])
          exponent = match[2] ? Number.parseInt(match[2]) : 1
        } else {
          throw new Error(`Invalid term: ${termStr}`)
        }
      } else {
        coefficient = Number.parseFloat(termStr)
        exponent = 0
        if (isNaN(coefficient)) {
          throw new Error(`Invalid term: ${termStr}`)
        }
      }

      terms.push({ coefficient, exponent })
    }

    return terms
  }

  // Combine like terms
  const combineTerms = (terms: Term[]): Term[] => {
    const combined: Map<number, number> = new Map()

    for (const term of terms) {
      const existing = combined.get(term.exponent) || 0
      combined.set(term.exponent, existing + term.coefficient)
    }

    return Array.from(combined.entries())
      .map(([exponent, coefficient]) => ({ coefficient, exponent }))
      .filter((t) => t.coefficient !== 0)
      .sort((a, b) => b.exponent - a.exponent)
  }

  // Format terms back to string
  const formatPolynomial = (terms: Term[], v: string): string => {
    if (terms.length === 0) return "0"

    return terms
      .map((term, index) => {
        let str = ""

        if (index === 0) {
          if (term.exponent === 0) {
            str = term.coefficient.toString()
          } else if (term.coefficient === 1) {
            str = term.exponent === 1 ? v : `${v}^${term.exponent}`
          } else if (term.coefficient === -1) {
            str = term.exponent === 1 ? `-${v}` : `-${v}^${term.exponent}`
          } else {
            str =
              term.exponent === 1
                ? `${term.coefficient}${v}`
                : term.exponent === 0
                  ? `${term.coefficient}`
                  : `${term.coefficient}${v}^${term.exponent}`
          }
        } else {
          const absCoef = Math.abs(term.coefficient)
          const sign = term.coefficient >= 0 ? " + " : " - "

          if (term.exponent === 0) {
            str = `${sign}${absCoef}`
          } else if (absCoef === 1) {
            str = term.exponent === 1 ? `${sign}${v}` : `${sign}${v}^${term.exponent}`
          } else {
            str = term.exponent === 1 ? `${sign}${absCoef}${v}` : `${sign}${absCoef}${v}^${term.exponent}`
          }
        }

        return str
      })
      .join("")
  }

  // Convert to LaTeX
  const toLatex = (expr: string, v: string): string => {
    return expr.replace(new RegExp(`${v}\\^(\\d+)`, "g"), `${v}^{$1}`).replace(/\*/g, " \\cdot ")
  }

  // Add polynomials
  const addPolynomials = (terms1: Term[], terms2: Term[]): { result: Term[]; steps: string[] } => {
    const steps: string[] = []
    steps.push(`Adding: (${formatPolynomial(terms1, variable)}) + (${formatPolynomial(terms2, variable)})`)

    const combined = combineTerms([...terms1, ...terms2])
    steps.push(`Combine like terms: ${formatPolynomial(combined, variable)}`)

    return { result: combined, steps }
  }

  // Subtract polynomials
  const subtractPolynomials = (terms1: Term[], terms2: Term[]): { result: Term[]; steps: string[] } => {
    const steps: string[] = []
    steps.push(`Subtracting: (${formatPolynomial(terms1, variable)}) - (${formatPolynomial(terms2, variable)})`)

    const negatedTerms2 = terms2.map((t) => ({ ...t, coefficient: -t.coefficient }))
    steps.push(`Negate second polynomial: ${formatPolynomial(negatedTerms2, variable)}`)

    const combined = combineTerms([...terms1, ...negatedTerms2])
    steps.push(`Combine like terms: ${formatPolynomial(combined, variable)}`)

    return { result: combined, steps }
  }

  // Multiply polynomials
  const multiplyPolynomials = (terms1: Term[], terms2: Term[]): { result: Term[]; steps: string[] } => {
    const steps: string[] = []
    steps.push(`Multiplying: (${formatPolynomial(terms1, variable)}) × (${formatPolynomial(terms2, variable)})`)

    const products: Term[] = []
    const productSteps: string[] = []

    for (const t1 of terms1) {
      for (const t2 of terms2) {
        const newTerm = {
          coefficient: t1.coefficient * t2.coefficient,
          exponent: t1.exponent + t2.exponent,
        }
        products.push(newTerm)

        const t1Str =
          t1.exponent === 0
            ? `${t1.coefficient}`
            : t1.coefficient === 1
              ? t1.exponent === 1
                ? variable
                : `${variable}^${t1.exponent}`
              : `${t1.coefficient}${variable}${t1.exponent > 1 ? `^${t1.exponent}` : ""}`
        const t2Str =
          t2.exponent === 0
            ? `${t2.coefficient}`
            : t2.coefficient === 1
              ? t2.exponent === 1
                ? variable
                : `${variable}^${t2.exponent}`
              : `${t2.coefficient}${variable}${t2.exponent > 1 ? `^${t2.exponent}` : ""}`
        const resultStr =
          newTerm.exponent === 0
            ? `${newTerm.coefficient}`
            : `${newTerm.coefficient}${variable}${newTerm.exponent > 1 ? `^${newTerm.exponent}` : ""}`

        productSteps.push(`(${t1Str}) × (${t2Str}) = ${resultStr}`)
      }
    }

    steps.push(`Multiply each term: ${productSteps.slice(0, 4).join(", ")}${productSteps.length > 4 ? "..." : ""}`)

    const combined = combineTerms(products)
    steps.push(`Combine like terms: ${formatPolynomial(combined, variable)}`)

    return { result: combined, steps }
  }

  // Polynomial division
  const dividePolynomials = (
    dividend: Term[],
    divisor: Term[],
  ): { quotient: Term[]; remainder: Term[]; steps: string[] } => {
    const steps: string[] = []
    steps.push(`Dividing: (${formatPolynomial(dividend, variable)}) ÷ (${formatPolynomial(divisor, variable)})`)

    if (divisor.length === 0 || (divisor.length === 1 && divisor[0].coefficient === 0)) {
      throw new Error("Cannot divide by zero")
    }

    let remainderTerms = [...dividend].sort((a, b) => b.exponent - a.exponent)
    const quotientTerms: Term[] = []
    const leadingDivisor = divisor.sort((a, b) => b.exponent - a.exponent)[0]

    let iterations = 0
    const maxIterations = 100

    while (
      remainderTerms.length > 0 &&
      remainderTerms[0].exponent >= leadingDivisor.exponent &&
      iterations < maxIterations
    ) {
      iterations++
      const leadingRemainder = remainderTerms[0]

      const quotientTerm: Term = {
        coefficient: leadingRemainder.coefficient / leadingDivisor.coefficient,
        exponent: leadingRemainder.exponent - leadingDivisor.exponent,
      }

      quotientTerms.push(quotientTerm)
      steps.push(
        `Divide ${formatPolynomial([leadingRemainder], variable)} by ${formatPolynomial([leadingDivisor], variable)} = ${formatPolynomial([quotientTerm], variable)}`,
      )

      const subtractTerms = divisor.map((t) => ({
        coefficient: t.coefficient * quotientTerm.coefficient,
        exponent: t.exponent + quotientTerm.exponent,
      }))

      remainderTerms = combineTerms([
        ...remainderTerms,
        ...subtractTerms.map((t) => ({ ...t, coefficient: -t.coefficient })),
      ])
    }

    steps.push(`Quotient: ${formatPolynomial(quotientTerms, variable)}`)
    if (remainderTerms.length > 0) {
      steps.push(`Remainder: ${formatPolynomial(remainderTerms, variable)}`)
    }

    return { quotient: quotientTerms, remainder: remainderTerms, steps }
  }

  // Factor polynomial (basic factoring)
  const factorPolynomial = (terms: Term[]): { factored: string; steps: string[] } => {
    const steps: string[] = []
    const sorted = terms.sort((a, b) => b.exponent - a.exponent)
    steps.push(`Original: ${formatPolynomial(sorted, variable)}`)

    // Find GCF of coefficients
    const gcd = (a: number, b: number): number => (b === 0 ? Math.abs(a) : gcd(b, a % b))
    let gcf = Math.abs(sorted[0].coefficient)
    for (const term of sorted) {
      gcf = gcd(gcf, Math.abs(term.coefficient))
    }

    // Find minimum exponent
    const minExp = Math.min(...sorted.map((t) => t.exponent))

    if (gcf > 1 || minExp > 0) {
      const factorStr =
        minExp > 0
          ? gcf > 1
            ? `${gcf}${variable}${minExp > 1 ? `^${minExp}` : ""}`
            : `${variable}${minExp > 1 ? `^${minExp}` : ""}`
          : `${gcf}`
      const factored = sorted.map((t) => ({
        coefficient: t.coefficient / gcf,
        exponent: t.exponent - minExp,
      }))
      steps.push(`Factor out ${factorStr}: ${factorStr}(${formatPolynomial(factored, variable)})`)

      // Check for quadratic factoring
      if (
        factored.length === 3 &&
        factored[0].exponent === 2 &&
        factored[1].exponent === 1 &&
        factored[2].exponent === 0
      ) {
        const a = factored[0].coefficient
        const b = factored[1].coefficient
        const c = factored[2].coefficient
        const discriminant = b * b - 4 * a * c

        if (discriminant >= 0) {
          const root1 = (-b + Math.sqrt(discriminant)) / (2 * a)
          const root2 = (-b - Math.sqrt(discriminant)) / (2 * a)

          if (Number.isInteger(root1) && Number.isInteger(root2)) {
            const factor1 = root1 >= 0 ? `(${variable} - ${root1})` : `(${variable} + ${Math.abs(root1)})`
            const factor2 = root2 >= 0 ? `(${variable} - ${root2})` : `(${variable} + ${Math.abs(root2)})`
            const fullFactored =
              gcf > 1 || minExp > 0
                ? `${factorStr}${a !== 1 ? a : ""}${factor1}${factor2}`
                : `${a !== 1 ? a : ""}${factor1}${factor2}`
            steps.push(`Factor quadratic: ${fullFactored}`)
            return { factored: fullFactored, steps }
          }
        }
      }

      return { factored: `${factorStr}(${formatPolynomial(factored, variable)})`, steps }
    }

    // Check for simple quadratic ax² + bx + c
    if (sorted.length === 3 && sorted[0].exponent === 2 && sorted[1].exponent === 1 && sorted[2].exponent === 0) {
      const a = sorted[0].coefficient
      const b = sorted[1].coefficient
      const c = sorted[2].coefficient
      const discriminant = b * b - 4 * a * c

      if (discriminant >= 0) {
        const root1 = (-b + Math.sqrt(discriminant)) / (2 * a)
        const root2 = (-b - Math.sqrt(discriminant)) / (2 * a)

        if (Number.isInteger(root1) && Number.isInteger(root2)) {
          const factor1 = root1 >= 0 ? `(${variable} - ${root1})` : `(${variable} + ${Math.abs(root1)})`
          const factor2 = root2 >= 0 ? `(${variable} - ${root2})` : `(${variable} + ${Math.abs(root2)})`
          const fullFactored = a !== 1 ? `${a}${factor1}${factor2}` : `${factor1}${factor2}`
          steps.push(`Factor quadratic using roots: ${fullFactored}`)
          return { factored: fullFactored, steps }
        }
      }

      steps.push("Cannot factor with integer coefficients")
      return { factored: formatPolynomial(sorted, variable), steps }
    }

    steps.push("Polynomial is already in simplest form")
    return { factored: formatPolynomial(sorted, variable), steps }
  }

  // Find roots
  const findRoots = (terms: Term[]): { roots: { value: string; multiplicity: number }[]; steps: string[] } => {
    const steps: string[] = []
    const sorted = terms.sort((a, b) => b.exponent - a.exponent)
    const degree = sorted[0]?.exponent || 0
    steps.push(`Polynomial degree: ${degree}`)

    if (degree === 0) {
      if (sorted[0].coefficient === 0) {
        return {
          roots: [{ value: "All real numbers", multiplicity: 1 }],
          steps: [...steps, "Constant zero - all values are roots"],
        }
      }
      return { roots: [], steps: [...steps, "Non-zero constant - no roots"] }
    }

    if (degree === 1) {
      const a = sorted.find((t) => t.exponent === 1)?.coefficient || 0
      const b = sorted.find((t) => t.exponent === 0)?.coefficient || 0
      const root = -b / a
      steps.push(`Linear equation: ${variable} = -${b}/${a} = ${root}`)
      return { roots: [{ value: root.toString(), multiplicity: 1 }], steps }
    }

    if (degree === 2) {
      const a = sorted.find((t) => t.exponent === 2)?.coefficient || 0
      const b = sorted.find((t) => t.exponent === 1)?.coefficient || 0
      const c = sorted.find((t) => t.exponent === 0)?.coefficient || 0

      const discriminant = b * b - 4 * a * c
      steps.push(`Using quadratic formula: ${variable} = (-b ± √(b² - 4ac)) / 2a`)
      steps.push(`Discriminant = ${b}² - 4(${a})(${c}) = ${discriminant}`)

      if (discriminant > 0) {
        const root1 = (-b + Math.sqrt(discriminant)) / (2 * a)
        const root2 = (-b - Math.sqrt(discriminant)) / (2 * a)
        steps.push(`Two real roots: ${variable} = ${root1.toFixed(4)}, ${variable} = ${root2.toFixed(4)}`)
        return {
          roots: [
            { value: root1.toFixed(4), multiplicity: 1 },
            { value: root2.toFixed(4), multiplicity: 1 },
          ],
          steps,
        }
      } else if (discriminant === 0) {
        const root = -b / (2 * a)
        steps.push(`One repeated root: ${variable} = ${root.toFixed(4)}`)
        return { roots: [{ value: root.toFixed(4), multiplicity: 2 }], steps }
      } else {
        const realPart = -b / (2 * a)
        const imagPart = Math.sqrt(-discriminant) / (2 * a)
        steps.push(`Two complex roots: ${variable} = ${realPart.toFixed(4)} ± ${imagPart.toFixed(4)}i`)
        return {
          roots: [
            { value: `${realPart.toFixed(4)} + ${imagPart.toFixed(4)}i`, multiplicity: 1 },
            { value: `${realPart.toFixed(4)} - ${imagPart.toFixed(4)}i`, multiplicity: 1 },
          ],
          steps,
        }
      }
    }

    // For higher degrees, use numerical methods or note limitation
    steps.push(`Higher degree polynomial (${degree}). Using numerical approximation...`)

    // Simple Newton-Raphson for finding one root
    const evaluate = (x: number): number => {
      return sorted.reduce((sum, t) => sum + t.coefficient * Math.pow(x, t.exponent), 0)
    }

    const derivative = (x: number): number => {
      return sorted.reduce((sum, t) => {
        if (t.exponent === 0) return sum
        return sum + t.coefficient * t.exponent * Math.pow(x, t.exponent - 1)
      }, 0)
    }

    const roots: { value: string; multiplicity: number }[] = []
    const tried = new Set<number>()

    for (let guess = -10; guess <= 10; guess += 0.5) {
      let x = guess
      for (let i = 0; i < 50; i++) {
        const fx = evaluate(x)
        const fpx = derivative(x)
        if (Math.abs(fpx) < 1e-10) break
        const newX = x - fx / fpx
        if (Math.abs(newX - x) < 1e-8) {
          const rounded = Math.round(newX * 10000) / 10000
          if (!tried.has(rounded) && Math.abs(evaluate(rounded)) < 0.001) {
            tried.add(rounded)
            roots.push({ value: rounded.toString(), multiplicity: 1 })
          }
          break
        }
        x = newX
      }
    }

    if (roots.length > 0) {
      steps.push(`Found roots: ${roots.map((r) => r.value).join(", ")}`)
    } else {
      steps.push("No real roots found in range [-10, 10]")
    }

    return { roots, steps }
  }

  // Evaluate polynomial at a value
  const evaluatePolynomial = (terms: Term[], value: number): { result: number; steps: string[] } => {
    const steps: string[] = []
    steps.push(`Evaluating at ${variable} = ${value}`)

    let sum = 0
    for (const term of terms) {
      const termValue = term.coefficient * Math.pow(value, term.exponent)
      steps.push(`${term.coefficient} × ${value}^${term.exponent} = ${termValue}`)
      sum += termValue
    }

    steps.push(`Sum = ${sum}`)
    return { result: sum, steps }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    try {
      const terms1 = parsePolynomial(polynomial1, variable)

      if (terms1.length === 0 && operation !== "evaluate") {
        setError("Please enter a valid polynomial expression")
        return
      }

      let calcResult: PolynomialResult

      switch (operation) {
        case "simplify": {
          const simplified = combineTerms(terms1)
          calcResult = {
            result: formatPolynomial(simplified, variable),
            steps: [`Original: ${polynomial1}`, `Simplified: ${formatPolynomial(simplified, variable)}`],
          }
          break
        }

        case "add":
        case "subtract":
        case "multiply":
        case "divide": {
          if (!polynomial2.trim()) {
            setError("Please enter a second polynomial for this operation")
            return
          }
          const terms2 = parsePolynomial(polynomial2, variable)

          if (operation === "add") {
            const { result: addResult, steps } = addPolynomials(terms1, terms2)
            calcResult = { result: formatPolynomial(addResult, variable), steps }
          } else if (operation === "subtract") {
            const { result: subResult, steps } = subtractPolynomials(terms1, terms2)
            calcResult = { result: formatPolynomial(subResult, variable), steps }
          } else if (operation === "multiply") {
            const { result: mulResult, steps } = multiplyPolynomials(terms1, terms2)
            calcResult = { result: formatPolynomial(mulResult, variable), steps }
          } else {
            const { quotient, remainder, steps } = dividePolynomials(terms1, terms2)
            calcResult = {
              result: formatPolynomial(quotient, variable),
              remainder: formatPolynomial(remainder, variable),
              steps,
            }
          }
          break
        }

        case "factor": {
          const { factored, steps } = factorPolynomial(terms1)
          calcResult = { result: factored, factored, steps }
          break
        }

        case "expand": {
          // For expand, we assume input might be in factored form, simplify it
          const expanded = combineTerms(terms1)
          calcResult = {
            result: formatPolynomial(expanded, variable),
            expanded: formatPolynomial(expanded, variable),
            steps: [`Original: ${polynomial1}`, `Expanded: ${formatPolynomial(expanded, variable)}`],
          }
          break
        }

        case "evaluate": {
          const evalValue = Number.parseFloat(evaluateAt)
          if (isNaN(evalValue)) {
            setError("Please enter a valid number to evaluate at")
            return
          }
          const { result: evalResult, steps } = evaluatePolynomial(terms1, evalValue)
          calcResult = {
            result: evalResult.toString(),
            evaluatedValue: evalResult,
            steps,
          }
          break
        }

        case "roots": {
          const { roots, steps } = findRoots(terms1)
          calcResult = {
            result: roots.length > 0 ? roots.map((r) => `${variable} = ${r.value}`).join(", ") : "No real roots",
            roots,
            steps,
          }
          break
        }

        default:
          setError("Invalid operation")
          return
      }

      setResult(calcResult)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid polynomial expression")
    }
  }

  const handleReset = () => {
    setPolynomial1("")
    setPolynomial2("")
    setEvaluateAt("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(result.result)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      await navigator.clipboard.writeText(toLatex(result.result, variable))
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const needsSecondPolynomial = ["add", "subtract", "multiply", "divide"].includes(operation)

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Polynomial Calculator</CardTitle>
                    <CardDescription>Perform operations on polynomials</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Operation Selection */}
                <div className="space-y-2">
                  <Label>Operation</Label>
                  <Select value={operation} onValueChange={(v) => setOperation(v as Operation)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="simplify">Simplify</SelectItem>
                      <SelectItem value="add">Add</SelectItem>
                      <SelectItem value="subtract">Subtract</SelectItem>
                      <SelectItem value="multiply">Multiply</SelectItem>
                      <SelectItem value="divide">Divide</SelectItem>
                      <SelectItem value="factor">Factor</SelectItem>
                      <SelectItem value="expand">Expand</SelectItem>
                      <SelectItem value="evaluate">Evaluate</SelectItem>
                      <SelectItem value="roots">Find Roots</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Variable Selection */}
                <div className="space-y-2">
                  <Label>Variable</Label>
                  <Select value={variable} onValueChange={setVariable}>
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="x">x</SelectItem>
                      <SelectItem value="y">y</SelectItem>
                      <SelectItem value="z">z</SelectItem>
                      <SelectItem value="t">t</SelectItem>
                      <SelectItem value="n">n</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Polynomial 1 Input */}
                <div className="space-y-2">
                  <Label htmlFor="poly1">{needsSecondPolynomial ? "First Polynomial" : "Polynomial Expression"}</Label>
                  <Input
                    id="poly1"
                    type="text"
                    placeholder={`e.g., 3${variable}^2 - 5${variable} + 2`}
                    value={polynomial1}
                    onChange={(e) => setPolynomial1(e.target.value)}
                    className="font-mono"
                  />
                </div>

                {/* Polynomial 2 Input (conditional) */}
                {needsSecondPolynomial && (
                  <div className="space-y-2">
                    <Label htmlFor="poly2">Second Polynomial</Label>
                    <Input
                      id="poly2"
                      type="text"
                      placeholder={`e.g., ${variable} + 1`}
                      value={polynomial2}
                      onChange={(e) => setPolynomial2(e.target.value)}
                      className="font-mono"
                    />
                  </div>
                )}

                {/* Evaluate At Input (conditional) */}
                {operation === "evaluate" && (
                  <div className="space-y-2">
                    <Label htmlFor="evalAt">Evaluate at {variable} =</Label>
                    <Input
                      id="evalAt"
                      type="number"
                      placeholder="Enter a value"
                      value={evaluateAt}
                      onChange={(e) => setEvaluateAt(e.target.value)}
                      step="any"
                    />
                  </div>
                )}

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show step-by-step solution</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <p className="text-2xl font-bold text-blue-600 font-mono break-all">{result.result}</p>

                      {result.remainder && result.remainder !== "0" && (
                        <p className="text-sm text-muted-foreground mt-2">
                          Remainder: <span className="font-mono text-blue-600">{result.remainder}</span>
                        </p>
                      )}

                      {result.roots && result.roots.length > 0 && (
                        <div className="mt-3 text-left">
                          <p className="text-sm font-medium mb-1">Roots:</p>
                          <div className="space-y-1">
                            {result.roots.map((root, idx) => (
                              <div key={idx} className="text-sm font-mono text-blue-700">
                                {variable} = {root.value}
                                {root.multiplicity > 1 && ` (multiplicity: ${root.multiplicity})`}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={showDetails} onOpenChange={setShowDetails} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full">
                            {showDetails ? (
                              <ChevronUp className="h-4 w-4 mr-1" />
                            ) : (
                              <ChevronDown className="h-4 w-4 mr-1" />
                            )}
                            {showDetails ? "Hide Steps" : "Show Steps"}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="bg-white rounded-lg p-3 space-y-2 text-sm">
                            {result.steps.map((step, idx) => (
                              <div key={idx} className="flex gap-2">
                                <span className="text-muted-foreground">{idx + 1}.</span>
                                <span className="font-mono break-all">{step}</span>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Operations Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-2 p-2 rounded bg-muted/50">
                      <Equal className="h-4 w-4 mt-0.5 text-blue-600" />
                      <div>
                        <span className="font-medium">Simplify</span>
                        <p className="text-muted-foreground">Combine like terms</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 p-2 rounded bg-muted/50">
                      <Plus className="h-4 w-4 mt-0.5 text-green-600" />
                      <div>
                        <span className="font-medium">Add / Subtract</span>
                        <p className="text-muted-foreground">Combine two polynomials</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 p-2 rounded bg-muted/50">
                      <X className="h-4 w-4 mt-0.5 text-purple-600" />
                      <div>
                        <span className="font-medium">Multiply</span>
                        <p className="text-muted-foreground">FOIL or distribution</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 p-2 rounded bg-muted/50">
                      <Divide className="h-4 w-4 mt-0.5 text-orange-600" />
                      <div>
                        <span className="font-medium">Divide</span>
                        <p className="text-muted-foreground">Long division with remainder</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">3x^2 - 5x + 2</p>
                  </div>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>Use ^ for exponents: x^2, x^3</li>
                    <li>Use * for multiplication (optional)</li>
                    <li>Spaces are ignored</li>
                    <li>Supports +, -, decimal coefficients</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Polynomial Degree</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Linear</span>
                      <span className="text-blue-600">Degree 1</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Quadratic</span>
                      <span className="text-green-600">Degree 2</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Cubic</span>
                      <span className="text-yellow-600">Degree 3</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Quartic</span>
                      <span className="text-purple-600">Degree 4</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Polynomial?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A polynomial is a mathematical expression consisting of variables (also called indeterminates) and
                  coefficients, combined using addition, subtraction, multiplication, and non-negative integer
                  exponents. For example, 3x² - 5x + 2 is a polynomial with three terms. The highest exponent determines
                  the polynomial's degree, which affects its behavior and the number of possible roots.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Polynomial Operations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Addition & Subtraction:</strong> Combine like terms (terms with the same variable and
                  exponent).
                  <br />
                  <br />
                  <strong>Multiplication:</strong> Use the distributive property (FOIL for binomials) and combine like
                  terms.
                  <br />
                  <br />
                  <strong>Division:</strong> Use polynomial long division to find the quotient and remainder.
                  <br />
                  <br />
                  <strong>Factoring:</strong> Express the polynomial as a product of simpler polynomials.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-medium mb-1">Disclaimer</p>
                    <p>
                      This polynomial calculator performs symbolic and numeric operations based on standard algebraic
                      rules. Results may vary for higher-degree or complex polynomials. For advanced mathematical work,
                      please verify results with a computer algebra system.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
