"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Apple, Info, AlertTriangle, Activity, Scale } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityLevel = "sedentary" | "light" | "moderate" | "active" | "athlete"
type FitnessGoal = "maintenance" | "fat-loss" | "muscle-gain"

interface MacroResult {
  calories: number
  protein: number
  carbs: number
  fat: number
  proteinPercent: number
  carbsPercent: number
  fatPercent: number
  perMeal: {
    protein: number
    carbs: number
    fat: number
    calories: number
  }
}

const activityMultipliers: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
  athlete: 1.9,
}

const goalRatios: Record<FitnessGoal, { protein: number; carbs: number; fat: number }> = {
  maintenance: { protein: 25, carbs: 50, fat: 25 },
  "fat-loss": { protein: 30, carbs: 40, fat: 30 },
  "muscle-gain": { protein: 30, carbs: 50, fat: 20 },
}

export function MacroCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")
  const [fitnessGoal, setFitnessGoal] = useState<FitnessGoal>("maintenance")
  const [mealsPerDay, setMealsPerDay] = useState("3")
  const [result, setResult] = useState<MacroResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateMacros = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseInt(age)
    const weightNum = Number.parseFloat(weight)
    const meals = Number.parseInt(mealsPerDay) || 3

    if (isNaN(ageNum) || ageNum < 10) {
      setError("Please enter a valid age (10 years or older)")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number
    if (unitSystem === "metric") {
      heightInCm = Number.parseFloat(heightCm)
      if (isNaN(heightInCm) || heightInCm <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = (feet * 12 + inches) * 2.54
    }

    // Convert weight to kg if imperial
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Calculate BMR using Mifflin-St Jeor Equation
    let bmr: number
    if (gender === "male") {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
    } else {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
    }

    // Calculate TDEE
    const tdee = bmr * activityMultipliers[activityLevel]

    // Adjust calories based on goal
    let targetCalories: number
    if (fitnessGoal === "fat-loss") {
      targetCalories = tdee - 500 // 500 calorie deficit
    } else if (fitnessGoal === "muscle-gain") {
      targetCalories = tdee + 300 // 300 calorie surplus
    } else {
      targetCalories = tdee
    }

    // Get macro ratios based on goal
    const ratios = goalRatios[fitnessGoal]

    // Calculate macros in grams
    const proteinGrams = Math.round((targetCalories * (ratios.protein / 100)) / 4)
    const carbsGrams = Math.round((targetCalories * (ratios.carbs / 100)) / 4)
    const fatGrams = Math.round((targetCalories * (ratios.fat / 100)) / 9)

    // Calculate per meal
    const perMeal = {
      protein: Math.round(proteinGrams / meals),
      carbs: Math.round(carbsGrams / meals),
      fat: Math.round(fatGrams / meals),
      calories: Math.round(targetCalories / meals),
    }

    setResult({
      calories: Math.round(targetCalories),
      protein: proteinGrams,
      carbs: carbsGrams,
      fat: fatGrams,
      proteinPercent: ratios.protein,
      carbsPercent: ratios.carbs,
      fatPercent: ratios.fat,
      perMeal,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setActivityLevel("moderate")
    setFitnessGoal("maintenance")
    setMealsPerDay("3")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `My Daily Macros:
Calories: ${result.calories} kcal
Protein: ${result.protein}g (${result.proteinPercent}%)
Carbs: ${result.carbs}g (${result.carbsPercent}%)
Fat: ${result.fat}g (${result.fatPercent}%)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Macro Results",
          text: `My daily macros: ${result.calories} kcal | Protein: ${result.protein}g | Carbs: ${result.carbs}g | Fat: ${result.fat}g`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Apple className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Macro Calculator</CardTitle>
                    <CardDescription>Calculate your daily macronutrient needs</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="Feet"
                        value={heightFeet}
                        onChange={(e) => setHeightFeet(e.target.value)}
                        min="0"
                      />
                      <Input
                        type="number"
                        placeholder="Inches"
                        value={heightInches}
                        onChange={(e) => setHeightInches(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                )}

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label>Activity Level</Label>
                  <div className="grid grid-cols-1 gap-2">
                    {[
                      { value: "sedentary", label: "Sedentary", desc: "Little to no exercise" },
                      { value: "light", label: "Lightly Active", desc: "Light exercise 1-3 days/week" },
                      { value: "moderate", label: "Moderately Active", desc: "Moderate exercise 3-5 days/week" },
                      { value: "active", label: "Very Active", desc: "Hard exercise 6-7 days/week" },
                      { value: "athlete", label: "Athlete", desc: "Very hard exercise, physical job" },
                    ].map((level) => (
                      <button
                        key={level.value}
                        type="button"
                        onClick={() => setActivityLevel(level.value as ActivityLevel)}
                        className={`flex items-center justify-between p-3 rounded-lg border-2 transition-all text-left ${
                          activityLevel === level.value
                            ? "border-primary bg-primary/5"
                            : "border-muted hover:border-primary/50"
                        }`}
                      >
                        <div>
                          <span className="font-medium">{level.label}</span>
                          <p className="text-xs text-muted-foreground">{level.desc}</p>
                        </div>
                        {activityLevel === level.value && <Check className="h-4 w-4 text-primary" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Fitness Goal */}
                <div className="space-y-2">
                  <Label>Fitness Goal</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      type="button"
                      variant={fitnessGoal === "fat-loss" ? "default" : "outline"}
                      onClick={() => setFitnessGoal("fat-loss")}
                      className={`w-full ${fitnessGoal === "fat-loss" ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                    >
                      Fat Loss
                    </Button>
                    <Button
                      type="button"
                      variant={fitnessGoal === "maintenance" ? "default" : "outline"}
                      onClick={() => setFitnessGoal("maintenance")}
                      className={`w-full ${fitnessGoal === "maintenance" ? "bg-green-600 hover:bg-green-700" : ""}`}
                    >
                      Maintain
                    </Button>
                    <Button
                      type="button"
                      variant={fitnessGoal === "muscle-gain" ? "default" : "outline"}
                      onClick={() => setFitnessGoal("muscle-gain")}
                      className={`w-full ${fitnessGoal === "muscle-gain" ? "bg-orange-600 hover:bg-orange-700" : ""}`}
                    >
                      Muscle Gain
                    </Button>
                  </div>
                </div>

                {/* Meals Per Day */}
                <div className="space-y-2">
                  <Label htmlFor="meals">Meals Per Day</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {["2", "3", "4", "5"].map((num) => (
                      <Button
                        key={num}
                        type="button"
                        variant={mealsPerDay === num ? "default" : "outline"}
                        onClick={() => setMealsPerDay(num)}
                        className="w-full"
                      >
                        {num}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMacros} className="w-full" size="lg">
                  Calculate Macros
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Daily Calories</p>
                      <p className="text-4xl font-bold text-green-600">{result.calories}</p>
                      <p className="text-sm text-green-600">kcal/day</p>
                    </div>

                    {/* Macro Bars */}
                    <div className="space-y-3 mb-4">
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-blue-700">Protein</span>
                          <span className="text-blue-600">
                            {result.protein}g ({result.proteinPercent}%)
                          </span>
                        </div>
                        <div className="h-3 bg-blue-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500 rounded-full transition-all duration-500"
                            style={{ width: `${result.proteinPercent}%` }}
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-orange-700">Carbohydrates</span>
                          <span className="text-orange-600">
                            {result.carbs}g ({result.carbsPercent}%)
                          </span>
                        </div>
                        <div className="h-3 bg-orange-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-orange-500 rounded-full transition-all duration-500"
                            style={{ width: `${result.carbsPercent}%` }}
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-green-700">Fat</span>
                          <span className="text-green-600">
                            {result.fat}g ({result.fatPercent}%)
                          </span>
                        </div>
                        <div className="h-3 bg-green-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-green-500 rounded-full transition-all duration-500"
                            style={{ width: `${result.fatPercent}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Per Meal Breakdown */}
                    <div className="p-3 bg-white/60 rounded-lg mb-4">
                      <p className="text-sm font-medium text-center mb-2">Per Meal ({mealsPerDay} meals)</p>
                      <div className="grid grid-cols-4 gap-2 text-center text-xs">
                        <div className="p-2 bg-gray-100 rounded">
                          <p className="font-bold text-gray-700">{result.perMeal.calories}</p>
                          <p className="text-muted-foreground">kcal</p>
                        </div>
                        <div className="p-2 bg-blue-100 rounded">
                          <p className="font-bold text-blue-700">{result.perMeal.protein}g</p>
                          <p className="text-blue-600">Protein</p>
                        </div>
                        <div className="p-2 bg-orange-100 rounded">
                          <p className="font-bold text-orange-700">{result.perMeal.carbs}g</p>
                          <p className="text-orange-600">Carbs</p>
                        </div>
                        <div className="p-2 bg-green-100 rounded">
                          <p className="font-bold text-green-700">{result.perMeal.fat}g</p>
                          <p className="text-green-600">Fat</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Default Macro Ratios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-green-700">Maintenance</span>
                      </div>
                      <p className="text-sm text-green-600">Protein 25% | Carbs 50% | Fat 25%</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-blue-700">Fat Loss</span>
                      </div>
                      <p className="text-sm text-blue-600">Protein 30% | Carbs 40% | Fat 30%</p>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-orange-700">Muscle Gain</span>
                      </div>
                      <p className="text-sm text-orange-600">Protein 30% | Carbs 50% | Fat 20%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Macro Calculations</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-xs space-y-1">
                    <p>
                      <strong className="text-foreground">Protein (g)</strong> = (Calories × %) ÷ 4
                    </p>
                    <p>
                      <strong className="text-foreground">Carbs (g)</strong> = (Calories × %) ÷ 4
                    </p>
                    <p>
                      <strong className="text-foreground">Fat (g)</strong> = (Calories × %) ÷ 9
                    </p>
                  </div>
                  <p>Protein and carbohydrates provide 4 calories per gram, while fat provides 9 calories per gram.</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    These calculations are estimates based on standard formulas. Individual needs may vary based on
                    metabolism, health conditions, and specific fitness goals. Consult a nutritionist or healthcare
                    professional for personalized guidance.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What Are Macronutrients?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Macronutrients, commonly referred to as "macros," are the three primary nutrients that provide your
                  body with energy: protein, carbohydrates, and fats. Unlike micronutrients (vitamins and minerals),
                  which are needed in small amounts, macronutrients are required in large quantities to fuel your daily
                  activities, support bodily functions, and maintain overall health. Understanding and balancing your
                  macronutrient intake is fundamental to achieving your fitness and health goals, whether you're looking
                  to lose weight, build muscle, or simply maintain a healthy lifestyle.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Each macronutrient serves specific functions in your body. Protein is essential for building and
                  repairing tissues, making enzymes and hormones, and supporting immune function. Carbohydrates are your
                  body's primary energy source, fueling everything from brain function to physical activity. Fats are
                  crucial for hormone production, nutrient absorption, cell membrane integrity, and providing a
                  concentrated source of energy. The balance of these three macros in your diet significantly impacts
                  your body composition, energy levels, and overall health outcomes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Macro Ratios</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Macro ratios represent the percentage of your total daily calories that come from each macronutrient.
                  The optimal ratio varies depending on your fitness goals, activity level, and individual metabolism.
                  For general health maintenance, a balanced approach of 25% protein, 50% carbohydrates, and 25% fat
                  works well for most people. This ratio provides adequate protein for tissue maintenance, sufficient
                  carbs for energy, and enough fat for hormonal health.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For fat loss, increasing protein to 30% while reducing carbs to 40% helps preserve muscle mass during
                  a calorie deficit while keeping you satiated. The slightly higher fat percentage of 30% supports
                  hormone production, which can be affected during weight loss. For muscle gain, maintaining high
                  protein at 30% supports muscle protein synthesis, while increasing carbs to 50% provides the energy
                  needed for intense workouts and recovery. The lower fat percentage of 20% ensures you're getting
                  adequate calories from the more anabolic macros while still meeting essential fatty acid needs.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Calorie and Macro Calculation Methods</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator uses the Mifflin-St Jeor equation to estimate your Basal Metabolic Rate (BMR), which
                  represents the calories your body burns at rest to maintain vital functions like breathing,
                  circulation, and cell production. The Mifflin-St Jeor equation is considered one of the most accurate
                  formulas for estimating BMR and is widely used by nutritionists and fitness professionals. For men,
                  the formula is: BMR = 10 × weight(kg) + 6.25 × height(cm) - 5 × age(years) + 5. For women: BMR = 10 ×
                  weight(kg) + 6.25 × height(cm) - 5 × age(years) - 161.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Your Total Daily Energy Expenditure (TDEE) is calculated by multiplying your BMR by an activity factor
                  that accounts for your physical activity level. Sedentary individuals multiply by 1.2, while athletes
                  may use a multiplier of 1.9 or higher. Once your TDEE is determined, the calculator adjusts for your
                  fitness goal—subtracting 500 calories for fat loss (approximately 1 pound per week loss) or adding 300
                  calories for muscle gain. Your macros are then calculated by applying the appropriate ratios to this
                  calorie target and converting to grams using standard conversion factors.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Apple className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Meeting Your Macro Goals</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Successfully hitting your macro targets requires planning and consistency. Start by focusing on
                  protein first, as it's often the most challenging macro to meet, especially for those new to tracking.
                  Good protein sources include lean meats, fish, eggs, dairy, legumes, and protein supplements.
                  Distribute your protein intake evenly across meals to maximize muscle protein synthesis throughout the
                  day. Most research suggests consuming 20-40 grams of protein per meal for optimal results.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For carbohydrates, prioritize complex carbs like whole grains, vegetables, fruits, and legumes over
                  simple sugars. These provide sustained energy and essential fiber for digestive health. Time your
                  higher-carb meals around your workouts for optimal performance and recovery. When it comes to fats,
                  focus on healthy sources like avocados, nuts, seeds, olive oil, and fatty fish. Avoid trans fats and
                  limit saturated fats while ensuring you get adequate omega-3 fatty acids for their anti-inflammatory
                  benefits and overall health support.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Consider using a food tracking app to monitor your intake, at least initially, until you develop an
                  intuitive sense of portion sizes and macro content. Meal prepping can also make it significantly
                  easier to hit your targets consistently. Remember that these calculations provide a starting point—you
                  may need to adjust based on your individual response, progress, and how you feel. Weight and body
                  composition changes, energy levels, and workout performance are all valuable feedback for fine-tuning
                  your macro intake over time.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
