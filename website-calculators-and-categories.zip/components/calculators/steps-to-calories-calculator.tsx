"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Footprints,
  Info,
  AlertTriangle,
  Activity,
  Gauge,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityType = "walking" | "running"
type Pace = "slow" | "moderate" | "fast"

interface Result {
  calories: number
  distance: number
  caloriesPerStep: number
  pace: Pace
  activityType: ActivityType
}

export function StepsToCaloriesCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [weight, setWeight] = useState("")
  const [steps, setSteps] = useState("")
  const [stepLength, setStepLength] = useState("")
  const [activityType, setActivityType] = useState<ActivityType>("walking")
  const [pace, setPace] = useState<Pace>("moderate")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const defaultStepLength = unitSystem === "metric" ? 0.762 : 2.5 // meters or feet

  const calculateCalories = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const stepsNum = Number.parseInt(steps)
    const stepLengthNum = stepLength ? Number.parseFloat(stepLength) : defaultStepLength

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(stepsNum) || stepsNum < 0) {
      setError("Please enter a valid number of steps (0 or more)")
      return
    }

    if (stepLengthNum <= 0) {
      setError("Step length must be greater than 0")
      return
    }

    // Convert weight to kg if imperial
    const weightKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Calculate distance
    let distanceKm: number
    if (unitSystem === "metric") {
      distanceKm = (stepsNum * stepLengthNum) / 1000 // meters to km
    } else {
      const distanceFeet = stepsNum * stepLengthNum
      const distanceMiles = distanceFeet / 5280
      distanceKm = distanceMiles * 1.60934 // miles to km
    }

    // MET values based on activity type and pace
    const metValues = {
      walking: { slow: 2.0, moderate: 3.5, fast: 5.0 },
      running: { slow: 6.0, moderate: 8.3, fast: 11.0 },
    }

    const met = metValues[activityType][pace]

    // Calculate time (approximate based on average speeds)
    const speeds = {
      walking: { slow: 3.2, moderate: 5.0, fast: 6.4 }, // km/h
      running: { slow: 8.0, moderate: 9.7, fast: 12.0 }, // km/h
    }

    const speed = speeds[activityType][pace]
    const timeHours = distanceKm / speed

    // Calories = MET × weight (kg) × time (hours)
    const calories = met * weightKg * timeHours
    const roundedCalories = Math.round(calories)

    // Distance in user's preferred unit
    const displayDistance = unitSystem === "metric" ? distanceKm : distanceKm / 1.60934

    // Calories per step
    const caloriesPerStep = stepsNum > 0 ? calories / stepsNum : 0

    // Warn for extreme values
    if (stepsNum > 100000) {
      setError("Warning: Very high step count. Results may be less accurate for extreme values.")
    }

    setResult({
      calories: roundedCalories,
      distance: Math.round(displayDistance * 100) / 100,
      caloriesPerStep: Math.round(caloriesPerStep * 1000) / 1000,
      pace,
      activityType,
    })
  }

  const handleReset = () => {
    setWeight("")
    setSteps("")
    setStepLength("")
    setActivityType("walking")
    setPace("moderate")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Steps: ${steps} | Distance: ${result.distance} ${unitSystem === "metric" ? "km" : "mi"} | Calories Burned: ${result.calories} kcal (${activityType}, ${pace} pace)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Steps to Calories Result",
          text: `I walked/ran ${steps} steps (${result.distance} ${unitSystem === "metric" ? "km" : "mi"}) and burned ${result.calories} calories! Calculated with CalcHub.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setStepLength("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Footprints className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Steps to Calories Calculator</CardTitle>
                    <CardDescription>Estimate calories burned from walking or running</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender (optional)</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={gender === "male" ? "default" : "outline"}
                      onClick={() => setGender("male")}
                      className="w-full"
                    >
                      Male
                    </Button>
                    <Button
                      type="button"
                      variant={gender === "female" ? "default" : "outline"}
                      onClick={() => setGender("female")}
                      className="w-full"
                    >
                      Female
                    </Button>
                  </div>
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Steps Input */}
                <div className="space-y-2">
                  <Label htmlFor="steps">Number of Steps</Label>
                  <Input
                    id="steps"
                    type="number"
                    placeholder="Enter number of steps"
                    value={steps}
                    onChange={(e) => setSteps(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Step Length Input (optional) */}
                <div className="space-y-2">
                  <Label htmlFor="stepLength">
                    Step Length ({unitSystem === "metric" ? "m" : "ft"})
                    <span className="text-muted-foreground text-xs ml-1">(optional)</span>
                  </Label>
                  <Input
                    id="stepLength"
                    type="number"
                    placeholder={`Default: ${defaultStepLength} ${unitSystem === "metric" ? "m" : "ft"}`}
                    value={stepLength}
                    onChange={(e) => setStepLength(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Activity Type */}
                <div className="space-y-2">
                  <Label>Activity Type</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={activityType === "walking" ? "default" : "outline"}
                      onClick={() => setActivityType("walking")}
                      className="w-full"
                    >
                      Walking
                    </Button>
                    <Button
                      type="button"
                      variant={activityType === "running" ? "default" : "outline"}
                      onClick={() => setActivityType("running")}
                      className="w-full"
                    >
                      Running
                    </Button>
                  </div>
                </div>

                {/* Pace Selection */}
                <div className="space-y-2">
                  <Label>Pace</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      type="button"
                      variant={pace === "slow" ? "default" : "outline"}
                      onClick={() => setPace("slow")}
                      className={`w-full ${pace === "slow" ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                    >
                      Slow
                    </Button>
                    <Button
                      type="button"
                      variant={pace === "moderate" ? "default" : "outline"}
                      onClick={() => setPace("moderate")}
                      className={`w-full ${pace === "moderate" ? "bg-green-600 hover:bg-green-700" : ""}`}
                    >
                      Moderate
                    </Button>
                    <Button
                      type="button"
                      variant={pace === "fast" ? "default" : "outline"}
                      onClick={() => setPace("fast")}
                      className={`w-full ${pace === "fast" ? "bg-orange-600 hover:bg-orange-700" : ""}`}
                    >
                      Fast
                    </Button>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCalories} className="w-full" size="lg">
                  Calculate Calories Burned
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Calories Burned</p>
                      <p className="text-5xl font-bold text-green-600 mb-2">{result.calories}</p>
                      <p className="text-lg font-semibold text-green-600">kcal</p>
                    </div>

                    {/* Additional Stats */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Distance</p>
                        <p className="text-lg font-bold text-foreground">
                          {result.distance} {unitSystem === "metric" ? "km" : "mi"}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Cal/Step</p>
                        <p className="text-lg font-bold text-foreground">{result.caloriesPerStep}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Step Count Goals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Sedentary</span>
                      <span className="text-sm text-red-600">{"< 5,000 steps"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Low Active</span>
                      <span className="text-sm text-yellow-600">5,000 - 7,499</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Somewhat Active</span>
                      <span className="text-sm text-blue-600">7,500 - 9,999</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Active</span>
                      <span className="text-sm text-green-600">10,000 - 12,499</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                      <span className="font-medium text-emerald-700">Highly Active</span>
                      <span className="text-sm text-emerald-600">12,500+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Average Calories per 1,000 Steps</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground">Walking</p>
                      <p>~30-40 kcal</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground">Running</p>
                      <p>~80-100 kcal</p>
                    </div>
                  </div>
                  <p className="text-xs">
                    Values vary based on body weight, pace, and terrain. A 70kg person burns approximately 35 calories
                    per 1,000 walking steps.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2 text-amber-800">
                    <AlertTriangle className="h-5 w-5" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-amber-700">
                    This calculator provides estimates only. Actual calories burned vary by individual factors such as
                    metabolism, walking/running efficiency, terrain, and environmental conditions.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Steps and Calorie Burn</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Walking and running are among the most accessible forms of physical activity, requiring no special
                  equipment or gym membership. Tracking your daily steps has become increasingly popular with the rise
                  of fitness trackers and smartphone apps. Understanding how your step count translates to calories
                  burned can help you set realistic fitness goals and manage your weight more effectively.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The relationship between steps and calories is not a simple one-to-one conversion. Multiple factors
                  influence how many calories you burn per step, including your body weight, walking or running speed,
                  stride length, terrain, and even your individual metabolic efficiency. Heavier individuals burn more
                  calories per step because more energy is required to move a larger mass, while faster paces increase
                  the intensity and therefore the calorie expenditure.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How Calories Are Calculated from Steps</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Our calculator uses the MET (Metabolic Equivalent of Task) method to estimate calorie expenditure. MET
                  values represent the energy cost of physical activities as multiples of your resting metabolic rate.
                  Walking at a moderate pace has a MET value of approximately 3.5, meaning you burn 3.5 times more
                  calories than you would at complete rest. Running increases this significantly, with MET values
                  ranging from 6 to 11 or higher depending on speed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The basic formula is: <strong>Calories = MET × Weight (kg) × Time (hours)</strong>. We calculate the
                  time by first determining the distance traveled (steps × step length) and then dividing by the average
                  speed for your selected activity type and pace. This approach provides a more accurate estimate than
                  simple step-to-calorie ratios because it accounts for the intensity of your activity.
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="font-semibold text-foreground mb-2">Average Step Lengths:</p>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>Walking: 0.65 - 0.85 meters (2.1 - 2.8 feet)</li>
                    <li>Running: 1.0 - 1.5 meters (3.3 - 4.9 feet)</li>
                    <li>Average default: 0.762 meters (2.5 feet)</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Calorie Burn</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence how many calories you burn while walking or running. Understanding these can
                  help you interpret your results and potentially increase your calorie expenditure:
                </p>
                <div className="mt-4 space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Body Weight</h4>
                    <p className="text-blue-700 text-sm">
                      Heavier individuals burn more calories because more energy is needed to move a larger body mass. A
                      90kg person burns approximately 30% more calories than a 70kg person covering the same distance at
                      the same pace.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Speed and Intensity</h4>
                    <p className="text-green-700 text-sm">
                      Walking faster or running significantly increases calorie burn. A brisk walk can burn nearly twice
                      as many calories as a leisurely stroll, while running can burn 2-3 times more than walking the
                      same distance.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Terrain and Incline</h4>
                    <p className="text-purple-700 text-sm">
                      Walking or running uphill, on sand, or on uneven surfaces requires more energy than flat, paved
                      surfaces. Hill walking can increase calorie burn by 50% or more compared to flat terrain.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Individual Metabolism</h4>
                    <p className="text-orange-700 text-sm">
                      Age, fitness level, muscle mass, and genetic factors all influence your metabolic rate. More fit
                      individuals may actually burn fewer calories for the same activity because their bodies become
                      more efficient.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Footprints className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Increasing Your Daily Steps</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Reaching a daily step goal can seem challenging at first, but small changes to your routine can add up
                  significantly. Here are practical strategies to increase your daily step count and burn more calories:
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Take Walking Meetings</p>
                    <p className="text-xs text-muted-foreground">
                      Turn phone calls or one-on-one meetings into walking sessions
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Park Further Away</p>
                    <p className="text-xs text-muted-foreground">Choose parking spots at the far end of lots</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Use Stairs</p>
                    <p className="text-xs text-muted-foreground">Skip elevators and escalators when possible</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Walk During Breaks</p>
                    <p className="text-xs text-muted-foreground">Use coffee or lunch breaks for short walks</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Evening Walks</p>
                    <p className="text-xs text-muted-foreground">End your day with a 15-30 minute neighborhood walk</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground text-sm">Walk While Waiting</p>
                    <p className="text-xs text-muted-foreground">
                      Pace instead of sitting while waiting for appointments
                    </p>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Remember that consistency matters more than intensity when building a walking habit. Starting with a
                  goal of just 2,000-3,000 additional steps per day is more sustainable than immediately aiming for
                  10,000. Gradually increase your target as walking becomes a natural part of your daily routine.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
