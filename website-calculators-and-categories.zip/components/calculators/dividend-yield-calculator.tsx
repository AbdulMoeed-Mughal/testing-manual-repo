"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  DollarSign,
  PieChart,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, currencySymbols, formatCurrency, currencyOptions } from "@/lib/currency"

type DividendFrequency = "quarterly" | "semi-annual" | "annual" | "monthly"

interface DividendResult {
  dividendYield: number
  yieldCategory: string
  yieldColor: string
  yieldBgColor: string
  totalAnnualDividend: number
  dividendPerPayment: number
  paymentsPerYear: number
}

export function DividendYieldCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [annualDividend, setAnnualDividend] = useState("")
  const [stockPrice, setStockPrice] = useState("")
  const [sharesOwned, setSharesOwned] = useState("")
  const [frequency, setFrequency] = useState<DividendFrequency>("quarterly")
  const [result, setResult] = useState<DividendResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const getPaymentsPerYear = (freq: DividendFrequency): number => {
    switch (freq) {
      case "monthly":
        return 12
      case "quarterly":
        return 4
      case "semi-annual":
        return 2
      case "annual":
        return 1
      default:
        return 4
    }
  }

  const calculateDividendYield = () => {
    setError("")
    setResult(null)

    const dividendNum = Number.parseFloat(annualDividend)
    const priceNum = Number.parseFloat(stockPrice)

    if (isNaN(dividendNum) || dividendNum < 0) {
      setError("Please enter a valid annual dividend (0 or greater)")
      return
    }

    if (isNaN(priceNum) || priceNum <= 0) {
      setError("Please enter a valid stock price greater than 0")
      return
    }

    const dividendYield = (dividendNum / priceNum) * 100
    const paymentsPerYear = getPaymentsPerYear(frequency)
    const dividendPerPayment = dividendNum / paymentsPerYear

    let yieldCategory: string
    let yieldColor: string
    let yieldBgColor: string

    if (dividendYield === 0) {
      yieldCategory = "No Dividend"
      yieldColor = "text-gray-600"
      yieldBgColor = "bg-gray-50 border-gray-200"
    } else if (dividendYield < 2) {
      yieldCategory = "Low Yield"
      yieldColor = "text-blue-600"
      yieldBgColor = "bg-blue-50 border-blue-200"
    } else if (dividendYield < 4) {
      yieldCategory = "Moderate Yield"
      yieldColor = "text-green-600"
      yieldBgColor = "bg-green-50 border-green-200"
    } else if (dividendYield < 6) {
      yieldCategory = "High Yield"
      yieldColor = "text-yellow-600"
      yieldBgColor = "bg-yellow-50 border-yellow-200"
    } else {
      yieldCategory = "Very High Yield"
      yieldColor = "text-red-600"
      yieldBgColor = "bg-red-50 border-red-200"
    }

    setResult({
      dividendYield: Math.round(dividendYield * 100) / 100,
      yieldCategory,
      yieldColor,
      yieldBgColor,
      totalAnnualDividend: dividendNum,
      dividendPerPayment,
      paymentsPerYear,
    })
  }

  const handleReset = () => {
    setAnnualDividend("")
    setStockPrice("")
    setSharesOwned("")
    setFrequency("quarterly")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const shares = Number.parseFloat(sharesOwned) || 0
      const totalIncome = shares > 0 ? result.totalAnnualDividend * shares : result.totalAnnualDividend
      await navigator.clipboard.writeText(
        `Dividend Yield: ${result.dividendYield}% (${result.yieldCategory})${shares > 0 ? ` | Annual Income: ${formatCurrency(totalIncome, currency)}` : ""}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const shares = Number.parseFloat(sharesOwned) || 0
        const totalIncome = shares > 0 ? result.totalAnnualDividend * shares : 0
        await navigator.share({
          title: "Dividend Yield Result",
          text: `I calculated a dividend yield of ${result.dividendYield}% (${result.yieldCategory}) using CalcHub!${shares > 0 ? ` Annual dividend income: ${formatCurrency(totalIncome, currency)}` : ""}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const shares = Number.parseFloat(sharesOwned) || 0
  const totalAnnualIncome = result ? result.totalAnnualDividend * shares : 0
  const incomePerPayment = result ? result.dividendPerPayment * shares : 0

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Dividend Yield Calculator</CardTitle>
                    <CardDescription>Calculate dividend yield and income potential</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <Select value={currency} onValueChange={(value: Currency) => setCurrency(value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencyOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.symbol} {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Annual Dividend Input */}
                <div className="space-y-2">
                  <Label htmlFor="annualDividend">Annual Dividend per Share ({currencySymbols[currency]})</Label>
                  <Input
                    id="annualDividend"
                    type="number"
                    placeholder="e.g., 2.50"
                    value={annualDividend}
                    onChange={(e) => setAnnualDividend(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Stock Price Input */}
                <div className="space-y-2">
                  <Label htmlFor="stockPrice">Current Stock Price ({currencySymbols[currency]})</Label>
                  <Input
                    id="stockPrice"
                    type="number"
                    placeholder="e.g., 50.00"
                    value={stockPrice}
                    onChange={(e) => setStockPrice(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Shares Owned Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="sharesOwned">Number of Shares Owned (Optional)</Label>
                  <Input
                    id="sharesOwned"
                    type="number"
                    placeholder="e.g., 100"
                    value={sharesOwned}
                    onChange={(e) => setSharesOwned(e.target.value)}
                    min="0"
                  />
                </div>

                {/* Dividend Frequency */}
                <div className="space-y-2">
                  <Label>Dividend Payment Frequency</Label>
                  <Select value={frequency} onValueChange={(value: DividendFrequency) => setFrequency(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="semi-annual">Semi-Annual</SelectItem>
                      <SelectItem value="annual">Annual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDividendYield} className="w-full" size="lg">
                  Calculate Dividend Yield
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.yieldBgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Dividend Yield</p>
                      <p className={`text-5xl font-bold ${result.yieldColor} mb-2`}>{result.dividendYield}%</p>
                      <p className={`text-lg font-semibold ${result.yieldColor}`}>{result.yieldCategory}</p>
                    </div>

                    {/* Income Summary */}
                    {shares > 0 && (
                      <div className="mt-4 pt-4 border-t border-current/10">
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div>
                            <p className="text-xs text-muted-foreground">Annual Income</p>
                            <p className="text-lg font-bold text-foreground">
                              {formatCurrency(totalAnnualIncome, currency)}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Per Payment</p>
                            <p className="text-lg font-bold text-foreground">
                              {formatCurrency(incomePerPayment, currency)}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Expandable Details */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          {showDetails ? (
                            <ChevronUp className="h-4 w-4 mr-1" />
                          ) : (
                            <ChevronDown className="h-4 w-4 mr-1" />
                          )}
                          {showDetails ? "Hide Details" : "Show Details"}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="bg-background/50 rounded-lg p-3 space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Annual Dividend/Share:</span>
                            <span className="font-medium">{formatCurrency(result.totalAnnualDividend, currency)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Dividend/Payment:</span>
                            <span className="font-medium">{formatCurrency(result.dividendPerPayment, currency)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Payments/Year:</span>
                            <span className="font-medium">{result.paymentsPerYear}</span>
                          </div>
                          {shares > 0 && (
                            <>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Shares Owned:</span>
                                <span className="font-medium">{shares.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Monthly Income (Avg):</span>
                                <span className="font-medium">{formatCurrency(totalAnnualIncome / 12, currency)}</span>
                              </div>
                            </>
                          )}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dividend Yield Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <span className="font-medium text-gray-700">No Dividend</span>
                      <span className="text-sm text-gray-600">0%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Low Yield</span>
                      <span className="text-sm text-blue-600">{"< 2%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Moderate Yield</span>
                      <span className="text-sm text-green-600">2% - 4%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">High Yield</span>
                      <span className="text-sm text-yellow-600">4% - 6%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very High Yield</span>
                      <span className="text-sm text-red-600">{"> 6%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dividend Yield Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Yield = (Annual Dividend ÷ Stock Price) × 100</p>
                  </div>
                  <p>
                    For example, if a stock pays {currencySymbols[currency]}2.00 annually and costs{" "}
                    {currencySymbols[currency]}50.00 per share:
                    <br />
                    <strong>Yield = (2 ÷ 50) × 100 = 4%</strong>
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Dividend Yield?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Dividend yield is a financial ratio that shows how much a company pays out in dividends each year
                  relative to its stock price. It is expressed as a percentage and represents the return on investment
                  from dividends alone, not including any capital gains. Dividend yield is a key metric for
                  income-focused investors who want to generate regular cash flow from their investments.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A higher dividend yield can be attractive to income investors, but it's important to analyze whether
                  the dividend is sustainable. Very high yields (above 6%) may indicate that the stock price has dropped
                  significantly, potentially signaling financial trouble for the company. Conversely, a low yield might
                  indicate a growth-focused company that reinvests profits rather than distributing them to
                  shareholders.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter the annual dividend per share and the current stock price to calculate the dividend yield. You
                  can find the annual dividend information in the company's financial reports, investor relations page,
                  or financial news websites. The stock price should be the current market price.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Optionally, enter the number of shares you own to see your total annual dividend income and income per
                  payment period. Select the dividend payment frequency (monthly, quarterly, semi-annual, or annual) to
                  see how much you'll receive at each payment.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Factors to Consider</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Dividend Sustainability</h4>
                    <p className="text-sm text-muted-foreground">
                      Look at the company's payout ratio (dividends ÷ earnings). A ratio above 80% may indicate the
                      dividend is at risk of being cut.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Dividend Growth</h4>
                    <p className="text-sm text-muted-foreground">
                      Companies that consistently increase dividends (Dividend Aristocrats) may offer better long-term
                      returns than high-yield stocks.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Tax Implications</h4>
                    <p className="text-sm text-muted-foreground">
                      Dividends may be taxed differently than capital gains. Qualified dividends typically receive
                      favorable tax treatment.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Total Return</h4>
                    <p className="text-sm text-muted-foreground">
                      Consider both dividend yield and potential stock price appreciation for a complete picture of
                      investment returns.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Dividend yield calculations are estimates based on entered values and current stock price. Actual
                  dividends may vary due to company policies, market conditions, and regulatory changes. Past dividend
                  payments do not guarantee future dividends. This calculator is for informational purposes only and
                  should not be considered financial advice. Consult a qualified financial advisor before making
                  investment decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
