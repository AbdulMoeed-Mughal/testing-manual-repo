"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  PiggyBank,
  Calendar,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Currency = "USD" | "EUR" | "GBP" | "INR" | "JPY" | "CAD" | "AUD"
type Frequency = "monthly" | "quarterly"

interface SIPResult {
  investedAmount: number
  maturityValue: number
  totalReturns: number
  wealthMultiplier: number
}

const currencySymbols: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  INR: "₹",
  JPY: "¥",
  CAD: "C$",
  AUD: "A$",
}

export function SIPCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [frequency, setFrequency] = useState<Frequency>("monthly")
  const [monthlyAmount, setMonthlyAmount] = useState("")
  const [duration, setDuration] = useState("")
  const [returnRate, setReturnRate] = useState("")
  const [result, setResult] = useState<SIPResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const formatCurrency = (value: number): string => {
    const symbol = currencySymbols[currency]
    if (currency === "INR") {
      if (value >= 10000000) {
        return `${symbol}${(value / 10000000).toFixed(2)} Cr`
      } else if (value >= 100000) {
        return `${symbol}${(value / 100000).toFixed(2)} L`
      }
    }
    if (value >= 1000000000) {
      return `${symbol}${(value / 1000000000).toFixed(2)}B`
    } else if (value >= 1000000) {
      return `${symbol}${(value / 1000000).toFixed(2)}M`
    } else if (value >= 1000) {
      return `${symbol}${(value / 1000).toFixed(2)}K`
    }
    return `${symbol}${value.toFixed(2)}`
  }

  const formatNumber = (value: number): string => {
    return value.toLocaleString(currency === "INR" ? "en-IN" : "en-US", {
      maximumFractionDigits: 2,
    })
  }

  const calculateSIP = () => {
    setError("")
    setResult(null)

    const amount = Number.parseFloat(monthlyAmount)
    const years = Number.parseFloat(duration)
    const rate = Number.parseFloat(returnRate)

    if (isNaN(amount) || amount <= 0) {
      setError("Please enter a valid investment amount greater than 0")
      return
    }

    if (isNaN(years) || years <= 0) {
      setError("Please enter a valid duration greater than 0")
      return
    }

    if (isNaN(rate) || rate < 0) {
      setError("Please enter a valid return rate (0 or higher)")
      return
    }

    // Calculate based on frequency
    const periodsPerYear = frequency === "monthly" ? 12 : 4
    const totalPeriods = years * periodsPerYear
    const periodRate = rate / 100 / periodsPerYear

    let maturityValue: number

    if (rate === 0) {
      maturityValue = amount * totalPeriods
    } else {
      // FV = P × [ ( (1 + r)^n − 1 ) / r ] × (1 + r)
      maturityValue = amount * ((Math.pow(1 + periodRate, totalPeriods) - 1) / periodRate) * (1 + periodRate)
    }

    const investedAmount = amount * totalPeriods
    const totalReturns = maturityValue - investedAmount
    const wealthMultiplier = maturityValue / investedAmount

    setResult({
      investedAmount,
      maturityValue,
      totalReturns,
      wealthMultiplier,
    })
  }

  const handleReset = () => {
    setMonthlyAmount("")
    setDuration("")
    setReturnRate("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const symbol = currencySymbols[currency]
      const text = `SIP Investment Summary:\nInvestment: ${symbol}${formatNumber(result.investedAmount)}\nMaturity Value: ${symbol}${formatNumber(result.maturityValue)}\nTotal Returns: ${symbol}${formatNumber(result.totalReturns)}\nWealth Multiplier: ${result.wealthMultiplier.toFixed(2)}x`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const symbol = currencySymbols[currency]
      try {
        await navigator.share({
          title: "My SIP Investment Projection",
          text: `Investing ${symbol}${formatNumber(Number.parseFloat(monthlyAmount))} ${frequency} for ${duration} years at ${returnRate}% returns could grow to ${symbol}${formatNumber(result.maturityValue)}! Wealth multiplier: ${result.wealthMultiplier.toFixed(2)}x`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">SIP Calculator</CardTitle>
                    <CardDescription>Estimate your investment growth</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="INR">INR (₹)</option>
                    <option value="JPY">JPY (¥)</option>
                    <option value="CAD">CAD (C$)</option>
                    <option value="AUD">AUD (A$)</option>
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Investment Frequency */}
                <div className="space-y-2">
                  <Label>Investment Frequency</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={frequency === "monthly" ? "default" : "outline"}
                      onClick={() => setFrequency("monthly")}
                      className="w-full"
                    >
                      Monthly
                    </Button>
                    <Button
                      type="button"
                      variant={frequency === "quarterly" ? "default" : "outline"}
                      onClick={() => setFrequency("quarterly")}
                      className="w-full"
                    >
                      Quarterly
                    </Button>
                  </div>
                </div>

                {/* Investment Amount */}
                <div className="space-y-2">
                  <Label htmlFor="amount">
                    {frequency === "monthly" ? "Monthly" : "Quarterly"} Investment ({currencySymbols[currency]})
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder={`Enter ${frequency} investment amount`}
                    value={monthlyAmount}
                    onChange={(e) => setMonthlyAmount(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Investment Duration (Years)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Enter duration in years"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Expected Return Rate */}
                <div className="space-y-2">
                  <Label htmlFor="return">Expected Annual Return Rate (%)</Label>
                  <Input
                    id="return"
                    type="number"
                    placeholder="Enter expected return rate"
                    value={returnRate}
                    onChange={(e) => setReturnRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSIP} className="w-full" size="lg">
                  Calculate Returns
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Maturity Value</p>
                      <p className="text-4xl sm:text-5xl font-bold text-green-600">
                        {formatCurrency(result.maturityValue)}
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center mb-4">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Invested</p>
                        <p className="font-semibold text-sm">{formatCurrency(result.investedAmount)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Returns</p>
                        <p className="font-semibold text-sm text-green-600">+{formatCurrency(result.totalReturns)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Multiplier</p>
                        <p className="font-semibold text-sm text-blue-600">{result.wealthMultiplier.toFixed(2)}x</p>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-xs mb-1">
                        <span>Principal</span>
                        <span>Returns</span>
                      </div>
                      <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-blue-500 to-green-500"
                          style={{ width: `${(result.investedAmount / result.maturityValue) * 100}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs mt-1 text-muted-foreground">
                        <span>{((result.investedAmount / result.maturityValue) * 100).toFixed(1)}%</span>
                        <span>{((result.totalReturns / result.maturityValue) * 100).toFixed(1)}%</span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">SIP Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs sm:text-sm">
                      FV = P × [((1 + r)^n − 1) / r] × (1 + r)
                    </p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>FV</strong> = Future Value (Maturity Amount)
                    </p>
                    <p>
                      <strong>P</strong> = Investment per period
                    </p>
                    <p>
                      <strong>r</strong> = Periodic rate (annual rate / periods per year)
                    </p>
                    <p>
                      <strong>n</strong> = Total number of periods
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sample Returns (12% p.a.)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">5 Years</span>
                      <span className="text-sm text-blue-600">1.4x</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">10 Years</span>
                      <span className="text-sm text-green-600">2.3x</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">20 Years</span>
                      <span className="text-sm text-purple-600">5.0x</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">30 Years</span>
                      <span className="text-sm text-orange-600">11.6x</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Returns are estimated and market-linked; actual results may vary. Past performance is not
                        indicative of future results. Please consult a financial advisor before investing.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Systematic Investment Plan (SIP)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A Systematic Investment Plan (SIP) is a disciplined investment approach that allows individuals to
                  invest a fixed amount of money at regular intervals—typically monthly or quarterly—into mutual funds
                  or other investment vehicles. Rather than investing a large lump sum at once, SIP enables investors to
                  spread their investments over time, making it an accessible and manageable way to build wealth
                  gradually. This method has become increasingly popular among both novice and experienced investors due
                  to its simplicity and effectiveness in wealth creation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The beauty of SIP lies in its ability to harness the power of compounding while minimizing the impact
                  of market volatility. When markets are down, your fixed investment amount purchases more units, and
                  when markets are up, it purchases fewer units. This strategy, known as rupee-cost averaging or
                  dollar-cost averaging, effectively reduces the average cost per unit over time and eliminates the need
                  to time the market—a task that even professional investors find challenging.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PiggyBank className="h-5 w-5 text-primary" />
                  <CardTitle>Benefits of SIP Investing</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  SIP investing offers numerous advantages that make it an ideal wealth-building strategy for investors
                  of all backgrounds. First and foremost is the power of compounding—often called the eighth wonder of
                  the world. When your investment returns generate their own returns, the growth becomes exponential
                  over time. Starting early with even small amounts can lead to substantial wealth accumulation over
                  decades. For example, investing just $500 monthly for 30 years at 12% annual returns can grow to over
                  $1.7 million.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Another significant benefit is financial discipline. SIP automates your investment process, ensuring
                  that you invest consistently regardless of market conditions or personal spending temptations. This
                  "set it and forget it" approach removes emotional decision-making from investing. Additionally, SIP
                  offers flexibility—you can start with small amounts, increase or decrease your investment, pause
                  temporarily, or stop altogether based on your financial situation. Most platforms allow you to modify
                  your SIP without penalties, making it adaptable to life's changing circumstances.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>How the SIP Calculator Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Our SIP calculator uses the standard future value formula for regular investments to project your
                  potential returns. The calculation takes into account your periodic investment amount, the expected
                  annual return rate, and the investment duration. The formula assumes that returns are compounded at
                  the same frequency as your investments—monthly for monthly SIPs and quarterly for quarterly SIPs.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The wealth multiplier shown in the results indicates how many times your total investment has grown.
                  For instance, a wealth multiplier of 2.5x means your maturity value is 2.5 times your total invested
                  amount, with the difference being your returns. The progress bar visually represents the proportion of
                  your final corpus that comes from your principal investment versus the returns generated through
                  compounding. Over longer time periods, you'll notice that returns constitute an increasingly larger
                  portion of the total corpus—this is the magic of compound interest at work.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Maximizing SIP Returns</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To maximize the benefits of SIP investing, consider starting as early as possible. Time is your
                  greatest ally when it comes to compounding. Even small differences in starting age can result in
                  significant differences in final wealth. Someone who starts investing at 25 will accumulate
                  substantially more than someone who starts at 35, even if they invest the same amount monthly.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Consider implementing a step-up SIP strategy where you increase your investment amount annually—
                  typically by 5-10%—to align with salary increments. This approach significantly boosts your final
                  corpus without dramatically impacting your monthly budget. Additionally, maintain your SIP through
                  market downturns rather than stopping or redeeming. Downturns actually work in your favor by allowing
                  you to accumulate more units at lower prices, which can lead to higher returns when markets recover.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Finally, diversify your SIP investments across different fund categories based on your risk tolerance
                  and investment horizon. Large-cap funds offer stability, mid-cap and small-cap funds offer higher
                  growth potential with increased volatility, while debt funds provide steady returns with lower risk. A
                  balanced portfolio tailored to your goals and risk appetite will help you achieve optimal
                  risk-adjusted returns over the long term.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
