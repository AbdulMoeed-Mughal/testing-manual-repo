"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Fence, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "m" | "ft"
type WallType = "gravity" | "rcc"
type MixRatio = "1:2:4" | "1:1.5:3" | "1:3:6"

interface RetainingWallResult {
  wallVolume: number
  dryVolume: number
  cementBags: number
  cementKg: number
  sandM3: number
  sandKg: number
  aggregateM3: number
  aggregateKg: number
}

const mixRatios: Record<MixRatio, { cement: number; sand: number; aggregate: number; grade: string }> = {
  "1:2:4": { cement: 1, sand: 2, aggregate: 4, grade: "M15" },
  "1:1.5:3": { cement: 1, sand: 1.5, aggregate: 3, grade: "M20" },
  "1:3:6": { cement: 1, sand: 3, aggregate: 6, grade: "M10" },
}

export function RetainingWallCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("m")
  const [wallType, setWallType] = useState<WallType>("rcc")
  const [length, setLength] = useState("")
  const [height, setHeight] = useState("")
  const [topThickness, setTopThickness] = useState("")
  const [baseThickness, setBaseThickness] = useState("")
  const [mixRatio, setMixRatio] = useState<MixRatio>("1:2:4")
  const [dryVolumeFactor, setDryVolumeFactor] = useState("1.54")
  const [wastagePercentage, setWastagePercentage] = useState("5")
  const [result, setResult] = useState<RetainingWallResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateRetainingWall = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const heightNum = Number.parseFloat(height)
    const topThicknessNum = Number.parseFloat(topThickness)
    const baseThicknessNum = Number.parseFloat(baseThickness)
    const dryVolumeFactorNum = Number.parseFloat(dryVolumeFactor)
    const wastageNum = Number.parseFloat(wastagePercentage)

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid wall length greater than 0")
      return
    }

    if (isNaN(heightNum) || heightNum <= 0) {
      setError("Please enter a valid wall height greater than 0")
      return
    }

    if (isNaN(topThicknessNum) || topThicknessNum <= 0) {
      setError("Please enter a valid top thickness greater than 0")
      return
    }

    if (isNaN(baseThicknessNum) || baseThicknessNum <= 0) {
      setError("Please enter a valid base thickness greater than 0")
      return
    }

    if (baseThicknessNum < topThicknessNum) {
      setError("Base thickness must be greater than or equal to top thickness")
      return
    }

    if (isNaN(dryVolumeFactorNum) || dryVolumeFactorNum <= 0) {
      setError("Please enter a valid dry volume factor greater than 0")
      return
    }

    if (isNaN(wastageNum) || wastageNum < 0) {
      setError("Please enter a valid wastage percentage")
      return
    }

    // Convert to meters if needed
    let lengthM = lengthNum
    let heightM = heightNum
    let topThicknessM = topThicknessNum
    let baseThicknessM = baseThicknessNum

    if (unitSystem === "ft") {
      lengthM = lengthNum * 0.3048
      heightM = heightNum * 0.3048
      topThicknessM = topThicknessNum * 0.3048
      baseThicknessM = baseThicknessNum * 0.3048
    }

    // Calculate average thickness
    const avgThickness = (topThicknessM + baseThicknessM) / 2

    // Calculate wall volume (trapezoidal cross-section)
    let wallVolume = lengthM * avgThickness * heightM

    // Apply wastage
    wallVolume = wallVolume * (1 + wastageNum / 100)

    // Calculate dry volume
    const dryVolume = wallVolume * dryVolumeFactorNum

    // Get mix ratio values
    const ratio = mixRatios[mixRatio]
    const totalParts = ratio.cement + ratio.sand + ratio.aggregate

    // Calculate cement (density 1440 kg/m³)
    const cementVolume = (ratio.cement / totalParts) * dryVolume
    const cementKg = cementVolume * 1440
    const cementBags = cementKg / 50 // 50kg bags

    // Calculate sand (density 1600 kg/m³)
    const sandM3 = (ratio.sand / totalParts) * dryVolume
    const sandKg = sandM3 * 1600

    // Calculate aggregate (density 1450 kg/m³)
    const aggregateM3 = (ratio.aggregate / totalParts) * dryVolume
    const aggregateKg = aggregateM3 * 1450

    // Convert volumes back to selected unit if needed
    let displayWallVolume = wallVolume
    if (unitSystem === "ft") {
      displayWallVolume = wallVolume * 35.3147 // m³ to ft³
    }

    setResult({
      wallVolume: displayWallVolume,
      dryVolume,
      cementBags,
      cementKg,
      sandM3,
      sandKg,
      aggregateM3,
      aggregateKg,
    })
  }

  const handleReset = () => {
    setLength("")
    setHeight("")
    setTopThickness("")
    setBaseThickness("")
    setMixRatio("1:2:4")
    setDryVolumeFactor("1.54")
    setWastagePercentage("5")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Retaining Wall: Wall Volume: ${result.wallVolume.toFixed(2)} ${unitSystem}³, Cement: ${result.cementBags.toFixed(0)} bags, Sand: ${result.sandM3.toFixed(2)} m³, Aggregate: ${result.aggregateM3.toFixed(2)} m³`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Retaining Wall Calculator Result",
          text: `I calculated retaining wall materials using CalcHub! Wall Volume: ${result.wallVolume.toFixed(2)} ${unitSystem}³`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "m" ? "ft" : "m"))
    setLength("")
    setHeight("")
    setTopThickness("")
    setBaseThickness("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Fence className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Retaining Wall Calculator</CardTitle>
                    <CardDescription>Calculate concrete and materials for retaining walls</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "ft" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "m" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Meters
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "ft" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Feet
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Wall Type */}
                <div className="space-y-2">
                  <Label htmlFor="wallType">Wall Type</Label>
                  <Select value={wallType} onValueChange={(value) => setWallType(value as WallType)}>
                    <SelectTrigger id="wallType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gravity">Gravity Wall</SelectItem>
                      <SelectItem value="rcc">RCC Wall</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dimensions Grid */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">Length ({unitSystem})</Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder="0"
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="height">Height ({unitSystem})</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="0"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="topThickness">Top Thickness ({unitSystem})</Label>
                    <Input
                      id="topThickness"
                      type="number"
                      placeholder="0"
                      value={topThickness}
                      onChange={(e) => setTopThickness(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="baseThickness">Base Thickness ({unitSystem})</Label>
                    <Input
                      id="baseThickness"
                      type="number"
                      placeholder="0"
                      value={baseThickness}
                      onChange={(e) => setBaseThickness(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Mix Ratio */}
                <div className="space-y-2">
                  <Label htmlFor="mixRatio">Concrete Mix Ratio</Label>
                  <Select value={mixRatio} onValueChange={(value) => setMixRatio(value as MixRatio)}>
                    <SelectTrigger id="mixRatio">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1:2:4">1:2:4 (M15)</SelectItem>
                      <SelectItem value="1:1.5:3">1:1.5:3 (M20)</SelectItem>
                      <SelectItem value="1:3:6">1:3:6 (M10)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="dryVolumeFactor">Dry Volume Factor</Label>
                    <Input
                      id="dryVolumeFactor"
                      type="number"
                      placeholder="1.54"
                      value={dryVolumeFactor}
                      onChange={(e) => setDryVolumeFactor(e.target.value)}
                      min="1"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wastagePercentage">Wastage (%)</Label>
                    <Input
                      id="wastagePercentage"
                      type="number"
                      placeholder="5"
                      value={wastagePercentage}
                      onChange={(e) => setWastagePercentage(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRetainingWall} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Materials
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                      <div className="text-center mb-4">
                        <p className="text-sm text-muted-foreground mb-1">Wall Volume</p>
                        <p className="text-4xl font-bold text-amber-600 mb-1">
                          {result.wallVolume.toFixed(2)}
                        </p>
                        <p className="text-sm font-medium text-amber-600">{unitSystem}³</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between p-2 rounded bg-white/50">
                          <span className="text-muted-foreground">Cement Required</span>
                          <span className="font-semibold text-foreground">
                            {result.cementBags.toFixed(0)} bags ({result.cementKg.toFixed(0)} kg)
                          </span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded bg-white/50">
                          <span className="text-muted-foreground">Sand Required</span>
                          <span className="font-semibold text-foreground">
                            {result.sandM3.toFixed(2)} m³ ({result.sandKg.toFixed(0)} kg)
                          </span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded bg-white/50">
                          <span className="text-muted-foreground">Aggregate Required</span>
                          <span className="font-semibold text-foreground">
                            {result.aggregateM3.toFixed(2)} m³ ({result.aggregateKg.toFixed(0)} kg)
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Wall Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">Gravity Wall</h4>
                      <p className="text-sm text-amber-700">
                        Uses mass and weight to resist soil pressure. Typically wider at base.
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <h4 className="font-semibold text-amber-800 mb-1">RCC Wall</h4>
                      <p className="text-sm text-amber-700">
                        Reinforced concrete cantilever wall with steel reinforcement for strength.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mix Ratio Guide</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex items-center justify-between p-2 rounded bg-muted">
                    <span>1:2:4 (M15)</span>
                    <span className="font-medium">Standard walls</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-muted">
                    <span>1:1.5:3 (M20)</span>
                    <span className="font-medium">Higher strength</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-muted">
                    <span>1:3:6 (M10)</span>
                    <span className="font-medium">Light walls</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is a Retaining Wall */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Retaining Wall?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A retaining wall is a structure designed to hold back soil and prevent erosion on sloped terrain.
                  These walls are essential in landscaping, construction, and civil engineering projects where there is
                  a significant change in ground elevation. Retaining walls resist lateral pressure from soil, water,
                  and other materials, making them critical for stability and safety in many construction scenarios.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  There are various types of retaining walls, including gravity walls that rely on their mass to resist
                  soil pressure, and reinforced concrete cantilever walls that use steel reinforcement for added
                  strength. The choice between wall types depends on factors such as wall height, soil conditions,
                  drainage requirements, and budget constraints. Proper design and construction are essential to ensure
                  the wall can withstand the forces it will encounter over its lifetime.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Retaining Wall Materials */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Retaining Wall Materials</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating materials for a retaining wall begins with determining the wall volume. For walls with
                  varying thickness (typical for gravity walls), calculate the average thickness by adding the top and
                  base thickness and dividing by 2. Then multiply this average thickness by the wall length and height
                  to get the volume. For example, a wall that is 10m long, 3m high, with 0.3m top thickness and 0.5m
                  base thickness has an average thickness of 0.4m, giving a volume of 10 × 0.4 × 3 = 12 m³.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Once you have the wet volume, apply the dry volume factor (typically 1.54) to account for voids and
                  compaction in the concrete mix. Then, based on your selected mix ratio, calculate the quantities of
                  cement, sand, and aggregate. For a 1:2:4 mix, the total parts are 7 (1+2+4). If the dry volume is
                  18.48 m³, cement would be (1/7) × 18.48 = 2.64 m³, which converts to about 3,802 kg or 76 bags of
                  50kg cement. Always add a wastage percentage (typically 5-10%) to account for spillage and
                  construction inefficiencies.
                </p>
              </CardContent>
            </Card>

            {/* Design Considerations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Fence className="h-5 w-5 text-primary" />
                  <CardTitle>Design Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Proper retaining wall design requires consideration of multiple factors beyond just the wall
                  dimensions. Soil type and properties significantly affect the lateral pressure the wall must resist.
                  Clay soils exert more pressure than sandy soils, and saturated soils can dramatically increase loads.
                  Drainage is critical—water buildup behind a retaining wall can cause failure even in well-designed
                  structures. Always include weep holes or drainage systems to prevent water accumulation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The base thickness of a retaining wall should typically be at least 10-15% of the wall height for
                  gravity walls, though this can vary based on specific conditions. For walls over 4 feet (1.2m) high,
                  professional engineering design is strongly recommended. Other important factors include foundation
                  depth (usually at least 1/10 of wall height below grade), reinforcement requirements for RCC walls,
                  and compliance with local building codes. Remember that this calculator provides material estimates
                  only—actual design should be verified by a qualified structural engineer.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      What is the difference between gravity and RCC retaining walls?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Gravity walls rely solely on their mass and weight to resist soil pressure. They are typically
                      thicker and made of plain concrete, stone, or masonry. RCC (Reinforced Cement Concrete) walls use
                      steel reinforcement to provide strength, allowing for thinner sections and greater height
                      capabilities. RCC walls are more economical for taller walls but require professional design and
                      skilled construction.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Why is the dry volume factor 1.54?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The dry volume factor of 1.54 accounts for the fact that when cement, sand, and aggregate are
                      mixed, they occupy less space due to filling of voids between particles. The dry volume (before
                      mixing) is approximately 54% more than the wet volume (after mixing). This factor ensures you
                      order enough materials to achieve the required concrete volume.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">
                      How do I choose the right concrete mix ratio?
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      The mix ratio depends on the required strength and wall type. M10 (1:3:6) is suitable for light
                      walls up to 1.5m high. M15 (1:2:4) is the standard choice for most residential retaining walls up
                      to 3m. M20 (1:1.5:3) is used for higher walls or walls subject to significant loads. Always
                      consult local building codes and consider getting a professional structural assessment for
                      critical applications.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Do I need a permit for a retaining wall?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Most jurisdictions require permits for retaining walls over a certain height, typically 3-4 feet
                      (0.9-1.2m). Even for shorter walls, you may need to verify property lines, utility locations, and
                      drainage considerations. Walls that support structures, roads, or public walkways almost always
                      require permits and professional engineering. Check with your local building department before
                      starting construction.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p className="font-semibold text-amber-900">Important Disclaimer</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Calculations assume uniform wall geometry. Actual requirements depend on soil type, reinforcement
                      design, drainage provisions, and local building codes. This calculator provides material estimates
                      only and should not replace professional engineering design. For walls over 4 feet (1.2m) high or
                      in critical applications, always consult a qualified structural engineer. Material quantities may
                      vary based on construction methods and site conditions.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
