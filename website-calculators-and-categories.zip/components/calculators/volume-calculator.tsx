"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Box,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Shape =
  | "cube"
  | "cuboid"
  | "sphere"
  | "cylinder"
  | "cone"
  | "pyramid"
  | "triangular-prism"
  | "hemisphere"
  | "ellipsoid"
  | "torus"

type VolumeUnit = "mm³" | "cm³" | "m³" | "in³" | "ft³" | "yd³" | "L"

interface VolumeResult {
  volume: number
  unit: VolumeUnit
  formula: string
  steps: string[]
}

const shapes: { value: Shape; label: string; icon: string }[] = [
  { value: "cube", label: "Cube", icon: "⬜" },
  { value: "cuboid", label: "Cuboid (Rectangular Prism)", icon: "📦" },
  { value: "sphere", label: "Sphere", icon: "🔵" },
  { value: "cylinder", label: "Cylinder", icon: "🥫" },
  { value: "cone", label: "Cone", icon: "🔺" },
  { value: "pyramid", label: "Rectangular Pyramid", icon: "🔻" },
  { value: "triangular-prism", label: "Triangular Prism", icon: "🔷" },
  { value: "hemisphere", label: "Hemisphere", icon: "🌓" },
  { value: "ellipsoid", label: "Ellipsoid", icon: "🥚" },
  { value: "torus", label: "Torus (Donut)", icon: "🍩" },
]

const volumeUnits: { value: VolumeUnit; label: string }[] = [
  { value: "mm³", label: "Cubic Millimeters (mm³)" },
  { value: "cm³", label: "Cubic Centimeters (cm³)" },
  { value: "m³", label: "Cubic Meters (m³)" },
  { value: "in³", label: "Cubic Inches (in³)" },
  { value: "ft³", label: "Cubic Feet (ft³)" },
  { value: "yd³", label: "Cubic Yards (yd³)" },
  { value: "L", label: "Liters (L)" },
]

// Conversion factors to cm³
const toCm3: Record<VolumeUnit, number> = {
  "mm³": 0.001,
  "cm³": 1,
  "m³": 1000000,
  "in³": 16.387064,
  "ft³": 28316.846592,
  "yd³": 764554.857984,
  L: 1000,
}

export function VolumeCalculator() {
  const [shape, setShape] = useState<Shape>("cube")
  const [unit, setUnit] = useState<VolumeUnit>("cm³")
  const [inputs, setInputs] = useState<Record<string, string>>({})
  const [result, setResult] = useState<VolumeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const getInputFields = (shape: Shape): { key: string; label: string; placeholder: string }[] => {
    switch (shape) {
      case "cube":
        return [{ key: "side", label: "Side Length", placeholder: "Enter side length" }]
      case "cuboid":
        return [
          { key: "length", label: "Length", placeholder: "Enter length" },
          { key: "width", label: "Width", placeholder: "Enter width" },
          { key: "height", label: "Height", placeholder: "Enter height" },
        ]
      case "sphere":
        return [{ key: "radius", label: "Radius", placeholder: "Enter radius" }]
      case "cylinder":
        return [
          { key: "radius", label: "Radius", placeholder: "Enter radius" },
          { key: "height", label: "Height", placeholder: "Enter height" },
        ]
      case "cone":
        return [
          { key: "radius", label: "Base Radius", placeholder: "Enter base radius" },
          { key: "height", label: "Height", placeholder: "Enter height" },
        ]
      case "pyramid":
        return [
          { key: "length", label: "Base Length", placeholder: "Enter base length" },
          { key: "width", label: "Base Width", placeholder: "Enter base width" },
          { key: "height", label: "Height", placeholder: "Enter height" },
        ]
      case "triangular-prism":
        return [
          { key: "base", label: "Triangle Base", placeholder: "Enter triangle base" },
          { key: "triangleHeight", label: "Triangle Height", placeholder: "Enter triangle height" },
          { key: "length", label: "Prism Length", placeholder: "Enter prism length" },
        ]
      case "hemisphere":
        return [{ key: "radius", label: "Radius", placeholder: "Enter radius" }]
      case "ellipsoid":
        return [
          { key: "a", label: "Semi-axis a", placeholder: "Enter semi-axis a" },
          { key: "b", label: "Semi-axis b", placeholder: "Enter semi-axis b" },
          { key: "c", label: "Semi-axis c", placeholder: "Enter semi-axis c" },
        ]
      case "torus":
        return [
          { key: "majorRadius", label: "Major Radius (R)", placeholder: "Enter major radius" },
          { key: "minorRadius", label: "Minor Radius (r)", placeholder: "Enter minor radius" },
        ]
      default:
        return []
    }
  }

  const calculateVolume = () => {
    setError("")
    setResult(null)

    const fields = getInputFields(shape)
    const values: Record<string, number> = {}

    for (const field of fields) {
      const val = Number.parseFloat(inputs[field.key] || "")
      if (isNaN(val) || val <= 0) {
        setError(`Please enter a valid ${field.label.toLowerCase()} greater than 0`)
        return
      }
      values[field.key] = val
    }

    let volume: number
    let formula: string
    let steps: string[]

    switch (shape) {
      case "cube": {
        const s = values.side
        volume = Math.pow(s, 3)
        formula = "V = s³"
        steps = [`V = ${s}³`, `V = ${s} × ${s} × ${s}`, `V = ${volume.toFixed(4)}`]
        break
      }
      case "cuboid": {
        const { length, width, height } = values
        volume = length * width * height
        formula = "V = l × w × h"
        steps = [`V = ${length} × ${width} × ${height}`, `V = ${volume.toFixed(4)}`]
        break
      }
      case "sphere": {
        const r = values.radius
        volume = (4 / 3) * Math.PI * Math.pow(r, 3)
        formula = "V = (4/3)πr³"
        steps = [
          `V = (4/3) × π × ${r}³`,
          `V = (4/3) × π × ${Math.pow(r, 3).toFixed(4)}`,
          `V = ${((4 / 3) * Math.pow(r, 3)).toFixed(4)} × π`,
          `V = ${volume.toFixed(4)}`,
        ]
        break
      }
      case "cylinder": {
        const { radius, height } = values
        volume = Math.PI * Math.pow(radius, 2) * height
        formula = "V = πr²h"
        steps = [
          `V = π × ${radius}² × ${height}`,
          `V = π × ${Math.pow(radius, 2).toFixed(4)} × ${height}`,
          `V = ${(Math.pow(radius, 2) * height).toFixed(4)} × π`,
          `V = ${volume.toFixed(4)}`,
        ]
        break
      }
      case "cone": {
        const { radius, height } = values
        volume = (1 / 3) * Math.PI * Math.pow(radius, 2) * height
        formula = "V = (1/3)πr²h"
        steps = [
          `V = (1/3) × π × ${radius}² × ${height}`,
          `V = (1/3) × π × ${Math.pow(radius, 2).toFixed(4)} × ${height}`,
          `V = ${((1 / 3) * Math.pow(radius, 2) * height).toFixed(4)} × π`,
          `V = ${volume.toFixed(4)}`,
        ]
        break
      }
      case "pyramid": {
        const { length, width, height } = values
        volume = (1 / 3) * length * width * height
        formula = "V = (1/3) × l × w × h"
        steps = [
          `V = (1/3) × ${length} × ${width} × ${height}`,
          `V = (1/3) × ${(length * width * height).toFixed(4)}`,
          `V = ${volume.toFixed(4)}`,
        ]
        break
      }
      case "triangular-prism": {
        const { base, triangleHeight, length } = values
        const triangleArea = (1 / 2) * base * triangleHeight
        volume = triangleArea * length
        formula = "V = (1/2 × b × h) × l"
        steps = [
          `Triangle Area = (1/2) × ${base} × ${triangleHeight}`,
          `Triangle Area = ${triangleArea.toFixed(4)}`,
          `V = ${triangleArea.toFixed(4)} × ${length}`,
          `V = ${volume.toFixed(4)}`,
        ]
        break
      }
      case "hemisphere": {
        const r = values.radius
        volume = (2 / 3) * Math.PI * Math.pow(r, 3)
        formula = "V = (2/3)πr³"
        steps = [
          `V = (2/3) × π × ${r}³`,
          `V = (2/3) × π × ${Math.pow(r, 3).toFixed(4)}`,
          `V = ${((2 / 3) * Math.pow(r, 3)).toFixed(4)} × π`,
          `V = ${volume.toFixed(4)}`,
        ]
        break
      }
      case "ellipsoid": {
        const { a, b, c } = values
        volume = (4 / 3) * Math.PI * a * b * c
        formula = "V = (4/3)πabc"
        steps = [
          `V = (4/3) × π × ${a} × ${b} × ${c}`,
          `V = (4/3) × π × ${(a * b * c).toFixed(4)}`,
          `V = ${((4 / 3) * a * b * c).toFixed(4)} × π`,
          `V = ${volume.toFixed(4)}`,
        ]
        break
      }
      case "torus": {
        const { majorRadius, minorRadius } = values
        volume = 2 * Math.PI * Math.PI * majorRadius * Math.pow(minorRadius, 2)
        formula = "V = 2π²Rr²"
        steps = [
          `V = 2 × π² × ${majorRadius} × ${minorRadius}²`,
          `V = 2 × π² × ${majorRadius} × ${Math.pow(minorRadius, 2).toFixed(4)}`,
          `V = ${(2 * majorRadius * Math.pow(minorRadius, 2)).toFixed(4)} × π²`,
          `V = ${volume.toFixed(4)}`,
        ]
        break
      }
      default:
        setError("Invalid shape selected")
        return
    }

    setResult({
      volume,
      unit,
      formula,
      steps,
    })
  }

  const handleReset = () => {
    setInputs({})
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Volume of ${shapes.find((s) => s.value === shape)?.label}: ${formatNumber(result.volume)} ${result.unit}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Volume Calculation Result",
          text: `I calculated the volume of a ${shapes.find((s) => s.value === shape)?.label} using CalcHub! Volume: ${formatNumber(result.volume)} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const handleShapeChange = (newShape: Shape) => {
    setShape(newShape)
    setInputs({})
    setResult(null)
    setError("")
  }

  const formatNumber = (num: number): string => {
    if (num >= 1e9) {
      return num.toExponential(4)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 4 })
  }

  const inputFields = getInputFields(shape)

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Box className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Volume Calculator</CardTitle>
                    <CardDescription>Calculate volume of 3D shapes</CardDescription>
                  </div>
                </div>

                {/* Shape Selection */}
                <div className="space-y-2 pt-2">
                  <Label>Select Shape</Label>
                  <Select value={shape} onValueChange={(v) => handleShapeChange(v as Shape)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {shapes.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          <span className="flex items-center gap-2">
                            <span>{s.icon}</span>
                            <span>{s.label}</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Unit Selection */}
                <div className="space-y-2">
                  <Label>Unit</Label>
                  <Select value={unit} onValueChange={(v) => setUnit(v as VolumeUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {volumeUnits.map((u) => (
                        <SelectItem key={u.value} value={u.value}>
                          {u.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Dynamic Input Fields */}
                {inputFields.map((field) => (
                  <div key={field.key} className="space-y-2">
                    <Label htmlFor={field.key}>
                      {field.label} ({unit.replace("³", "")})
                    </Label>
                    <Input
                      id={field.key}
                      type="number"
                      placeholder={field.placeholder}
                      value={inputs[field.key] || ""}
                      onChange={(e) => setInputs({ ...inputs, [field.key]: e.target.value })}
                      min="0"
                      step="any"
                    />
                  </div>
                ))}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateVolume} className="w-full" size="lg">
                  Calculate Volume
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Volume</p>
                      <p className="text-4xl font-bold text-blue-600 mb-2">
                        {formatNumber(result.volume)}
                        <span className="text-2xl ml-1">{result.unit}</span>
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Formula: <span className="font-mono font-semibold">{result.formula}</span>
                      </p>
                    </div>

                    {/* Step-by-step toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 flex items-center justify-center gap-1 text-sm text-blue-600 hover:text-blue-700"
                    >
                      {showSteps ? (
                        <>
                          Hide Steps <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Steps <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg border border-blue-100">
                        <p className="text-xs font-medium text-muted-foreground mb-2">Calculation Steps:</p>
                        <div className="space-y-1">
                          {result.steps.map((step, index) => (
                            <p key={index} className="text-sm font-mono text-foreground">
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Volume Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Cube</p>
                      <p className="text-xs text-muted-foreground font-mono">V = s³</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Cuboid</p>
                      <p className="text-xs text-muted-foreground font-mono">V = l × w × h</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Sphere</p>
                      <p className="text-xs text-muted-foreground font-mono">V = (4/3)πr³</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Cylinder</p>
                      <p className="text-xs text-muted-foreground font-mono">V = πr²h</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Cone</p>
                      <p className="text-xs text-muted-foreground font-mono">V = (1/3)πr²h</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Pyramid</p>
                      <p className="text-xs text-muted-foreground font-mono">V = (1/3) × l × w × h</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Hemisphere</p>
                      <p className="text-xs text-muted-foreground font-mono">V = (2/3)πr³</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Ellipsoid</p>
                      <p className="text-xs text-muted-foreground font-mono">V = (4/3)πabc</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium text-sm">Torus</p>
                      <p className="text-xs text-muted-foreground font-mono">V = 2π²Rr²</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p>
                    This calculator provides estimates only. Verify manually for critical measurements. Results are
                    rounded to 4 decimal places for display purposes.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Volume?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Volume is the amount of three-dimensional space occupied by a substance or enclosed within a
                  container. It is a fundamental measurement in mathematics, physics, engineering, and everyday life.
                  Unlike area, which measures two-dimensional space, volume quantifies the capacity of three-dimensional
                  objects, making it essential for understanding how much space an object takes up or how much a
                  container can hold.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of volume dates back to ancient civilizations, where it was used for practical purposes
                  such as measuring grain stores, calculating the capacity of vessels, and designing buildings. Today,
                  volume calculations are crucial in fields ranging from architecture and manufacturing to medicine and
                  chemistry. Understanding volume helps us determine everything from the amount of concrete needed for a
                  foundation to the dosage of medication based on body volume.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Box className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding 3D Shapes</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Three-dimensional shapes, or solids, are geometric figures that have length, width, and height. Each
                  shape has unique properties that determine how its volume is calculated. <strong>Prisms</strong> (like
                  cubes and cuboids) have flat faces and straight edges, with volume calculated by multiplying the base
                  area by height. <strong>Curved solids</strong> (like spheres and cylinders) involve the mathematical
                  constant π (pi) in their calculations due to their circular cross-sections.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Pyramids and cones</strong> are pointed shapes that taper from a base to an apex. Their
                  volumes are exactly one-third of the corresponding prism or cylinder with the same base and height.
                  This relationship was discovered by ancient Greek mathematicians and remains a fundamental principle
                  in geometry. <strong>Composite shapes</strong> can often be broken down into simpler components,
                  allowing complex volumes to be calculated by adding or subtracting the volumes of basic shapes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Volume Units and Conversions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Volume can be expressed in various units depending on the application and region. The metric system
                  uses cubic meters (m³), cubic centimeters (cm³), and liters (L), while the imperial system uses cubic
                  feet (ft³), cubic inches (in³), and gallons. One liter equals exactly 1,000 cubic centimeters, making
                  conversions straightforward in the metric system.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When converting between units, remember that volume scales with the cube of the linear dimension. For
                  example, 1 meter equals 100 centimeters, but 1 cubic meter equals 1,000,000 cubic centimeters (100³).
                  This cubic relationship is crucial for accurate conversions and explains why small changes in linear
                  dimensions can result in large changes in volume. Always double-check your unit conversions,
                  especially in professional applications where accuracy is critical.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Box className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications of Volume</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Volume calculations have countless real-world applications. In <strong>construction</strong>,
                  engineers calculate the volume of concrete needed for foundations, the capacity of water tanks, and
                  the air volume in rooms for HVAC design. <strong>Shipping and logistics</strong> rely on volume
                  measurements to optimize container space and calculate shipping costs based on dimensional weight.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In <strong>medicine</strong>, volume calculations help determine organ sizes, blood volume, and
                  medication dosages. <strong>Manufacturing</strong> uses volume to calculate material requirements,
                  design molds, and ensure products meet specifications. Even in <strong>cooking</strong>, understanding
                  volume helps with scaling recipes and choosing appropriate containers. From filling a swimming pool to
                  designing spacecraft fuel tanks, volume calculations are essential for solving practical problems
                  across all industries.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
