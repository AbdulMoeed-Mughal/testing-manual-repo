"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, MoveVertical, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface StairResult {
  numberOfRisers: number
  adjustedRiserHeight: number
  treadWidth: number
  totalRun: number
  comfortable: boolean
  color: string
  bgColor: string
}

export function StairRiserTreadCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [totalHeight, setTotalHeight] = useState("")
  const [preferredRiser, setPreferredRiser] = useState("")
  const [stairWidth, setStairWidth] = useState("")
  const [result, setResult] = useState<StairResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateStairs = () => {
    setError("")
    setResult(null)

    const heightNum = Number.parseFloat(totalHeight)
    if (isNaN(heightNum) || heightNum <= 0) {
      setError("Please enter a valid total height greater than 0")
      return
    }

    // Convert to mm for calculation
    const heightMm = unitSystem === "metric" ? heightNum * 1000 : heightNum * 25.4

    // Determine riser height
    let riserHeightMm: number
    if (preferredRiser && Number.parseFloat(preferredRiser) > 0) {
      riserHeightMm = unitSystem === "metric" ? Number.parseFloat(preferredRiser) : Number.parseFloat(preferredRiser) * 25.4
    } else {
      // Default comfortable riser height
      riserHeightMm = 170 // 170mm is comfortable for most people
    }

    // Validate riser height range
    if (riserHeightMm < 120 || riserHeightMm > 200) {
      setError(`Riser height must be between ${unitSystem === "metric" ? "120-200 mm" : "4.7-7.9 in"}`)
      return
    }

    // Calculate number of risers
    const numberOfRisers = Math.ceil(heightMm / riserHeightMm)

    // Calculate adjusted riser height
    const adjustedRiserMm = heightMm / numberOfRisers

    // Calculate tread width using the formula: 2R + T = 600-650mm (comfort range)
    // Using 625mm as the standard
    const treadWidthMm = 625 - 2 * adjustedRiserMm

    // Validate tread width
    if (treadWidthMm < 250 || treadWidthMm > 320) {
      setError("Calculated tread width is outside safe range. Adjust riser height.")
      return
    }

    // Calculate total run
    const numberOfSteps = numberOfRisers - 1
    const totalRunMm = treadWidthMm * numberOfSteps

    // Check if comfortable (ideal range)
    const comfortable = adjustedRiserMm >= 150 && adjustedRiserMm <= 180 && treadWidthMm >= 250 && treadWidthMm <= 300
    const color = comfortable ? "text-green-600" : "text-amber-600"
    const bgColor = comfortable ? "bg-green-50 border-green-200" : "bg-amber-50 border-amber-200"

    // Convert back to display units
    const adjustedRiser = unitSystem === "metric" ? adjustedRiserMm : adjustedRiserMm / 25.4
    const treadWidth = unitSystem === "metric" ? treadWidthMm : treadWidthMm / 25.4
    const totalRun = unitSystem === "metric" ? totalRunMm / 1000 : totalRunMm / 304.8

    setResult({
      numberOfRisers,
      adjustedRiserHeight: Math.round(adjustedRiser * 10) / 10,
      treadWidth: Math.round(treadWidth * 10) / 10,
      totalRun: Math.round(totalRun * 100) / 100,
      comfortable,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setTotalHeight("")
    setPreferredRiser("")
    setStairWidth("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "mm" : "in"
      const runUnit = unitSystem === "metric" ? "m" : "ft"
      await navigator.clipboard.writeText(
        `Risers: ${result.numberOfRisers}, Riser Height: ${result.adjustedRiserHeight} ${unit}, Tread: ${result.treadWidth} ${unit}, Total Run: ${result.totalRun} ${runUnit}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const unit = unitSystem === "metric" ? "mm" : "in"
        await navigator.share({
          title: "Stair Riser & Tread Calculation",
          text: `Risers: ${result.numberOfRisers}, Riser Height: ${result.adjustedRiserHeight} ${unit}, Tread: ${result.treadWidth} ${unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setTotalHeight("")
    setPreferredRiser("")
    setResult(null)
    setError("")
  }

  const setPresetRiser = (value: string) => {
    setPreferredRiser(value)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <MoveVertical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Stair Riser & Tread Calculator</CardTitle>
                    <CardDescription>Calculate stair dimensions</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Total Height Input */}
                <div className="space-y-2">
                  <Label htmlFor="totalHeight">Total Height ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="totalHeight"
                    type="number"
                    placeholder="Floor-to-floor height"
                    value={totalHeight}
                    onChange={(e) => setTotalHeight(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Preferred Riser Height */}
                <div className="space-y-2">
                  <Label htmlFor="preferredRiser">
                    Preferred Riser Height (Optional, {unitSystem === "metric" ? "mm" : "in"})
                  </Label>
                  <Input
                    id="preferredRiser"
                    type="number"
                    placeholder={unitSystem === "metric" ? "Default: 170 mm" : "Default: 6.7 in"}
                    value={preferredRiser}
                    onChange={(e) => setPreferredRiser(e.target.value)}
                    min="0"
                    step="1"
                  />
                  <div className="flex gap-2 flex-wrap">
                    {unitSystem === "metric" ? (
                      <>
                        <Button type="button" variant="outline" size="sm" onClick={() => setPresetRiser("150")}>
                          150 mm
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setPresetRiser("170")}>
                          170 mm
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setPresetRiser("180")}>
                          180 mm
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button type="button" variant="outline" size="sm" onClick={() => setPresetRiser("6")}>
                          6 in
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setPresetRiser("6.7")}>
                          6.7 in
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setPresetRiser("7")}>
                          7 in
                        </Button>
                      </>
                    )}
                  </div>
                </div>

                {/* Stair Width (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="stairWidth">Stair Width (Optional, {unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="stairWidth"
                    type="number"
                    placeholder="Enter stair width"
                    value={stairWidth}
                    onChange={(e) => setStairWidth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateStairs} className="w-full" size="lg">
                  Calculate Stairs
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-current/10">
                        <p className="text-sm text-muted-foreground mb-1">Number of Risers</p>
                        <p className={`text-4xl font-bold ${result.color}`}>{result.numberOfRisers}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground">Riser Height</p>
                          <p className={`font-semibold ${result.color}`}>
                            {result.adjustedRiserHeight} {unitSystem === "metric" ? "mm" : "in"}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Tread Width</p>
                          <p className={`font-semibold ${result.color}`}>
                            {result.treadWidth} {unitSystem === "metric" ? "mm" : "in"}
                          </p>
                        </div>
                      </div>

                      <div className="text-sm">
                        <p className="text-muted-foreground">Total Run</p>
                        <p className={`font-semibold ${result.color}`}>
                          {result.totalRun} {unitSystem === "metric" ? "m" : "ft"}
                        </p>
                      </div>

                      <div className={`p-2 rounded-lg text-center text-sm font-medium ${result.color}`}>
                        {result.comfortable ? "✓ Comfortable Dimensions" : "⚠ Within Acceptable Range"}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Dimensions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-green-700">Ideal Riser</span>
                        <span className="text-sm text-green-600">150-180 mm</span>
                      </div>
                      <p className="text-xs text-green-600">Most comfortable range</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-blue-700">Ideal Tread</span>
                        <span className="text-sm text-blue-600">250-300 mm</span>
                      </div>
                      <p className="text-xs text-blue-600">Safe foot placement</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-amber-700">Max Riser</span>
                        <span className="text-sm text-amber-600">200 mm</span>
                      </div>
                      <p className="text-xs text-amber-600">Building code limit</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-purple-700">Min Tread</span>
                        <span className="text-sm text-purple-600">250 mm</span>
                      </div>
                      <p className="text-xs text-purple-600">Minimum safe width</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">Number of Risers:</p>
                    <p className="font-mono">Risers = ⌈Total Height ÷ Riser Height⌉</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">Tread Width (Comfort):</p>
                    <p className="font-mono">2R + T = 600-650 mm</p>
                    <p className="text-xs">Where R = Riser, T = Tread</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Stair Riser & Tread */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Stair Risers and Treads?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A stair riser is the vertical portion of a step - the height between one step and the next. The tread is
                  the horizontal part where you place your foot when climbing or descending stairs. Together, these two
                  dimensions define the geometry of a staircase and directly impact its safety, comfort, and usability. The
                  relationship between riser height and tread depth is crucial for creating stairs that feel natural to use
                  and meet building code requirements.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Proper stair design considers human biomechanics and typical stride patterns. When riser and tread
                  dimensions are well-proportioned, users can climb stairs with a comfortable, rhythmic gait without
                  excessive strain or risk of tripping. Conversely, poorly designed stairs with inconsistent riser heights
                  or inadequate tread depths are major contributors to falls and injuries. Understanding these dimensions
                  helps create safer, more accessible stairs for buildings of all types.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Stair Dimensions?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating stair dimensions starts with measuring the total vertical rise - the floor-to-floor height
                  the stairs must span. Divide this total height by your preferred riser height (typically 150-180mm for
                  comfortable stairs) and round up to get the number of risers needed. Then divide the total height by this
                  number of risers to get the actual riser height that will be used. This ensures all risers are exactly
                  the same height, which is critical for safety.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The tread depth is calculated using the standard formula for comfortable stairs: 2R + T = 600-650mm,
                  where R is the riser height and T is the tread depth. This formula, known as Blondel's rule, reflects the
                  natural relationship between step height and depth that matches human stride patterns. For example, with
                  a 170mm riser, the ideal tread would be 625 - (2 × 170) = 285mm. The total run of the stairs equals the
                  tread depth multiplied by the number of steps (which is one less than the number of risers).
                </p>
              </CardContent>
            </Card>

            {/* Building Code Requirements */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Building Code Requirements</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Building codes worldwide establish minimum and maximum dimensions for stair risers and treads to ensure
                  safety. In most jurisdictions, maximum riser height is 200mm (7.87 inches) and minimum tread depth is
                  250mm (9.84 inches) for residential stairs, with slightly more stringent requirements for commercial and
                  public buildings. These limits are based on extensive research into stair safety and the physical
                  capabilities of diverse user populations, including children, elderly individuals, and people with
                  mobility challenges.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Beyond basic dimensional requirements, building codes also mandate that all risers in a flight of stairs
                  must be uniform within very tight tolerances (typically ±5mm). Even small variations in riser height can
                  cause users to trip, as they develop a rhythm while climbing that assumes consistent dimensions. Codes
                  also specify requirements for stair width, headroom clearance, handrails, and landings. Always consult
                  local building codes when designing stairs, as requirements can vary by location and building type, and
                  professional review by architects or engineers is typically required for building permits.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2 text-sm text-amber-900">
                    <p className="font-semibold">Important Notice:</p>
                    <p className="leading-relaxed">
                      Calculations provided by this calculator are indicative and intended for preliminary planning only.
                      Actual staircase dimensions must comply with local building codes, ergonomic standards, and safety
                      regulations. Professional review by qualified architects, engineers, or building inspectors is
                      required before construction. Factors including headroom clearance, stair width, handrails, landings,
                      and uniformity of dimensions must be verified to ensure safe and code-compliant stair design.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
