"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Droplet, Info } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type TempUnit = "C" | "K"
type PressureUnit = "atm" | "Pa" | "kPa" | "bar" | "mmHg"
type SoluteType = "nonelectrolyte" | "electrolyte"

interface OsmoticPressureResult {
  pressure: number
  pressureAtm: number
  molarity: number
  temperature: number
  vantHoff: number
  category: string
  color: string
  bgColor: string
}

export function OsmoticPressureCalculator() {
  const [molarity, setMolarity] = useState("")
  const [temperature, setTemperature] = useState("")
  const [tempUnit, setTempUnit] = useState<TempUnit>("C")
  const [pressureUnit, setPressureUnit] = useState<PressureUnit>("atm")
  const [vantHoff, setVantHoff] = useState("1")
  const [soluteType, setSoluteType] = useState<SoluteType>("nonelectrolyte")
  const [result, setResult] = useState<OsmoticPressureResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  // Gas constant R = 0.08206 L·atm/(mol·K)
  const R = 0.08206

  const calculateOsmoticPressure = () => {
    setError("")
    setResult(null)

    const M = Number.parseFloat(molarity)
    const T_input = Number.parseFloat(temperature)
    const i = Number.parseFloat(vantHoff)

    // Validation
    if (isNaN(M) || M <= 0) {
      setError("Molarity must be positive")
      return
    }

    if (isNaN(T_input) || T_input <= 0) {
      setError("Temperature must be positive")
      return
    }

    if (isNaN(i) || i < 1) {
      setError("Van't Hoff factor must be ≥ 1")
      return
    }

    // Convert temperature to Kelvin
    let T_kelvin = T_input
    if (tempUnit === "C") {
      T_kelvin = T_input + 273.15
      if (T_kelvin <= 0) {
        setError("Temperature must be above absolute zero")
        return
      }
    }

    // Calculate osmotic pressure: π = i × M × R × T (in atm)
    const pi_atm = i * M * R * T_kelvin

    // Convert to selected unit
    let pi_converted = pi_atm
    switch (pressureUnit) {
      case "atm":
        pi_converted = pi_atm
        break
      case "Pa":
        pi_converted = pi_atm * 101325
        break
      case "kPa":
        pi_converted = pi_atm * 101.325
        break
      case "bar":
        pi_converted = pi_atm * 1.01325
        break
      case "mmHg":
        pi_converted = pi_atm * 760
        break
    }

    // Categorize based on osmotic pressure (using atm as reference)
    let category: string
    let color: string
    let bgColor: string

    if (pi_atm < 1) {
      category = "Hypotonic (Low)"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (pi_atm < 10) {
      category = "Isotonic (Moderate)"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (pi_atm < 50) {
      category = "Hypertonic (High)"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      category = "Very Hypertonic"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      pressure: pi_converted,
      pressureAtm: pi_atm,
      molarity: M,
      temperature: T_kelvin,
      vantHoff: i,
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setMolarity("")
    setTemperature("")
    setVantHoff("1")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Osmotic Pressure: ${result.pressure.toFixed(4)} ${pressureUnit} (${result.category})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Osmotic Pressure Result",
          text: `Osmotic Pressure: ${result.pressure.toFixed(4)} ${pressureUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const handleSoluteTypeChange = (type: SoluteType) => {
    setSoluteType(type)
    // Set default van't Hoff factor based on solute type
    if (type === "nonelectrolyte") {
      setVantHoff("1")
    } else {
      setVantHoff("2") // Common for NaCl
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Droplet className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Osmotic Pressure Calculator</CardTitle>
                    <CardDescription>Calculate colligative properties of solutions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Solute Type */}
                <div className="space-y-2">
                  <Label>Solute Type</Label>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant={soluteType === "nonelectrolyte" ? "default" : "outline"}
                      className="flex-1"
                      onClick={() => handleSoluteTypeChange("nonelectrolyte")}
                    >
                      Nonelectrolyte
                    </Button>
                    <Button
                      type="button"
                      variant={soluteType === "electrolyte" ? "default" : "outline"}
                      className="flex-1"
                      onClick={() => handleSoluteTypeChange("electrolyte")}
                    >
                      Electrolyte
                    </Button>
                  </div>
                </div>

                {/* Molarity Input */}
                <div className="space-y-2">
                  <Label htmlFor="molarity">Molarity (M)</Label>
                  <Input
                    id="molarity"
                    type="number"
                    placeholder="Enter molarity in mol/L"
                    value={molarity}
                    onChange={(e) => setMolarity(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Temperature Input */}
                <div className="space-y-2">
                  <Label htmlFor="temperature">Temperature</Label>
                  <div className="flex gap-2">
                    <Input
                      id="temperature"
                      type="number"
                      placeholder="Enter temperature"
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                      step="0.1"
                      className="flex-1"
                    />
                    <Select value={tempUnit} onValueChange={(value: TempUnit) => setTempUnit(value)}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="C">°C</SelectItem>
                        <SelectItem value="K">K</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Van't Hoff Factor */}
                <div className="space-y-2">
                  <Label htmlFor="vanthoff">
                    Van't Hoff Factor (i)
                    <span className="text-xs text-muted-foreground ml-2">
                      {soluteType === "nonelectrolyte" ? "(usually 1)" : "(2 for NaCl, 3 for CaCl₂)"}
                    </span>
                  </Label>
                  <Input
                    id="vanthoff"
                    type="number"
                    placeholder="Enter van't Hoff factor"
                    value={vantHoff}
                    onChange={(e) => setVantHoff(e.target.value)}
                    min="1"
                    step="0.1"
                  />
                </div>

                {/* Pressure Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Pressure Unit</Label>
                  <Select
                    value={pressureUnit}
                    onValueChange={(value: PressureUnit) => setPressureUnit(value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="atm">atm</SelectItem>
                      <SelectItem value="Pa">Pa</SelectItem>
                      <SelectItem value="kPa">kPa</SelectItem>
                      <SelectItem value="bar">bar</SelectItem>
                      <SelectItem value="mmHg">mmHg</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateOsmoticPressure} className="w-full" size="lg">
                  Calculate Osmotic Pressure
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Osmotic Pressure</p>
                      <p className={`text-4xl font-bold ${result.color} mb-2`}>
                        {result.pressure.toFixed(4)} {pressureUnit}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Calculation Details */}
                    <div className="mt-4 pt-4 border-t border-current/20 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Parameters:</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Molarity (M):</span>
                        <span className="font-medium">{result.molarity.toFixed(4)} mol/L</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Temperature (T):</span>
                        <span className="font-medium">{result.temperature.toFixed(2)} K</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Van't Hoff factor (i):</span>
                        <span className="font-medium">{result.vantHoff}</span>
                      </div>
                      {pressureUnit !== "atm" && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">In atm:</span>
                          <span className="font-medium">{result.pressureAtm.toFixed(4)} atm</span>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Osmotic Pressure Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">π = i × M × R × T</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex justify-between">
                      <span>π = Osmotic pressure</span>
                    </div>
                    <div className="flex justify-between">
                      <span>i = Van't Hoff factor</span>
                    </div>
                    <div className="flex justify-between">
                      <span>M = Molarity (mol/L)</span>
                    </div>
                    <div className="flex justify-between">
                      <span>R = 0.08206 L·atm/(mol·K)</span>
                    </div>
                    <div className="flex justify-between">
                      <span>T = Temperature (K)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Osmotic Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Hypotonic</span>
                      <span className="text-sm text-blue-600">{"< 1 atm"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Isotonic</span>
                      <span className="text-sm text-green-600">1 – 10 atm</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Hypertonic</span>
                      <span className="text-sm text-yellow-600">10 – 50 atm</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very Hypertonic</span>
                      <span className="text-sm text-red-600">≥ 50 atm</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Van't Hoff Factor Examples</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="text-muted-foreground">Glucose (C₆H₁₂O₆)</span>
                      <span className="font-medium">i = 1</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="text-muted-foreground">NaCl</span>
                      <span className="font-medium">i ≈ 2</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="text-muted-foreground">CaCl₂</span>
                      <span className="font-medium">i ≈ 3</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="text-muted-foreground">Na₂SO₄</span>
                      <span className="font-medium">i ≈ 3</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Osmotic Pressure */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Osmotic Pressure?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Osmotic pressure is the minimum pressure required to prevent the flow of solvent molecules through
                  a semipermeable membrane from a region of lower solute concentration to a region of higher solute
                  concentration. It is one of the four colligative properties of solutions, which depend on the
                  number of solute particles rather than their chemical identity.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This phenomenon is fundamental in biological systems, particularly in maintaining cell turgor,
                  nutrient transport, and waste removal. In medical applications, osmotic pressure is critical for
                  designing intravenous solutions, dialysis treatments, and understanding drug delivery mechanisms
                  across biological membranes.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplet className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Osmotic Pressure</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Osmotic pressure plays crucial roles in various fields. In biology, it maintains cell shape and
                  function through osmotic balance. Red blood cells, for example, must be suspended in isotonic
                  solutions to prevent hemolysis or crenation. In chemistry and chemical engineering, reverse
                  osmosis processes exploit osmotic pressure principles for water purification and desalination.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In medicine, understanding osmotic pressure helps in formulating IV fluids, developing controlled
                  drug release systems, and treating conditions like edema. Environmental science uses osmotic
                  pressure concepts in soil-water relationships and plant physiology, while the food industry
                  applies these principles in preservation through osmotic dehydration and in beverage carbonation.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2 text-sm text-yellow-800">
                    <p className="font-semibold">Important Note</p>
                    <p className="leading-relaxed">
                      Osmotic pressure calculations assume ideal dilute solutions. Deviations may occur for
                      concentrated or non-ideal systems. For critical applications in medicine, research, or
                      industrial processes, consult appropriate resources and conduct experimental verification.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
