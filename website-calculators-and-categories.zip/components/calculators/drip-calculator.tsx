"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  DollarSign,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { formatCurrency, currencySymbols, type Currency } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

type DividendType = "yield" | "perShare"
type Frequency = "quarterly" | "semiannual" | "annual"

interface YearlyBreakdown {
  year: number
  shares: number
  stockPrice: number
  dividendsReceived: number
  sharesAdded: number
  portfolioValue: number
  totalContributions: number
  totalDividendsReinvested: number
}

interface DRIPResult {
  totalShares: number
  futurePortfolioValue: number
  totalDividendsReinvested: number
  totalContributions: number
  totalGain: number
  gainPercentage: number
  yearlyBreakdown: YearlyBreakdown[]
}

export function DRIPCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [initialInvestment, setInitialInvestment] = useState("")
  const [stockPrice, setStockPrice] = useState("")
  const [dividendType, setDividendType] = useState<DividendType>("yield")
  const [dividendYield, setDividendYield] = useState("")
  const [dividendPerShare, setDividendPerShare] = useState("")
  const [growthRate, setGrowthRate] = useState("")
  const [duration, setDuration] = useState("")
  const [frequency, setFrequency] = useState<Frequency>("quarterly")
  const [monthlyContribution, setMonthlyContribution] = useState("")
  const [taxRate, setTaxRate] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<DRIPResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const symbol = currencySymbols[currency]

  const getPeriodsPerYear = (freq: Frequency): number => {
    switch (freq) {
      case "quarterly":
        return 4
      case "semiannual":
        return 2
      case "annual":
        return 1
    }
  }

  const calculateDRIP = () => {
    setError("")
    setResult(null)

    const initial = Number.parseFloat(initialInvestment)
    const price = Number.parseFloat(stockPrice)
    const growth = Number.parseFloat(growthRate) / 100
    const years = Number.parseInt(duration)
    const monthly = Number.parseFloat(monthlyContribution) || 0
    const tax = Number.parseFloat(taxRate) / 100 || 0

    if (isNaN(initial) || initial <= 0) {
      setError("Please enter a valid initial investment amount")
      return
    }
    if (isNaN(price) || price <= 0) {
      setError("Please enter a valid stock price")
      return
    }
    if (isNaN(years) || years <= 0 || years > 50) {
      setError("Please enter a valid duration (1-50 years)")
      return
    }

    let annualDividendYield: number
    if (dividendType === "yield") {
      const yieldValue = Number.parseFloat(dividendYield)
      if (isNaN(yieldValue) || yieldValue < 0 || yieldValue > 100) {
        setError("Please enter a valid dividend yield (0-100%)")
        return
      }
      annualDividendYield = yieldValue / 100
    } else {
      const perShare = Number.parseFloat(dividendPerShare)
      if (isNaN(perShare) || perShare < 0) {
        setError("Please enter a valid dividend per share")
        return
      }
      annualDividendYield = perShare / price
    }

    const periodsPerYear = getPeriodsPerYear(frequency)
    const totalPeriods = years * periodsPerYear
    const dividendPerPeriod = annualDividendYield / periodsPerYear
    const growthPerPeriod = Math.pow(1 + growth, 1 / periodsPerYear) - 1

    let shares = initial / price
    let currentPrice = price
    let totalDividendsReinvested = 0
    let totalContributions = initial
    const yearlyBreakdown: YearlyBreakdown[] = []

    for (let year = 1; year <= years; year++) {
      let yearDividends = 0
      let yearSharesAdded = 0
      const startShares = shares

      for (let period = 1; period <= periodsPerYear; period++) {
        // Add monthly contributions for this period
        const monthsInPeriod = 12 / periodsPerYear
        const periodContribution = monthly * monthsInPeriod
        if (periodContribution > 0) {
          shares += periodContribution / currentPrice
          totalContributions += periodContribution
        }

        // Calculate and reinvest dividends
        const dividendAmount = shares * currentPrice * dividendPerPeriod
        const afterTaxDividend = dividendAmount * (1 - tax)
        const newShares = afterTaxDividend / currentPrice

        shares += newShares
        yearDividends += afterTaxDividend
        yearSharesAdded += newShares
        totalDividendsReinvested += afterTaxDividend

        // Apply stock price growth
        currentPrice *= 1 + growthPerPeriod
      }

      yearlyBreakdown.push({
        year,
        shares: Math.round(shares * 1000) / 1000,
        stockPrice: Math.round(currentPrice * 100) / 100,
        dividendsReceived: Math.round(yearDividends * 100) / 100,
        sharesAdded: Math.round(yearSharesAdded * 1000) / 1000,
        portfolioValue: Math.round(shares * currentPrice * 100) / 100,
        totalContributions: Math.round(totalContributions * 100) / 100,
        totalDividendsReinvested: Math.round(totalDividendsReinvested * 100) / 100,
      })
    }

    const futureValue = shares * currentPrice
    const totalGain = futureValue - totalContributions
    const gainPercentage = (totalGain / totalContributions) * 100

    setResult({
      totalShares: Math.round(shares * 1000) / 1000,
      futurePortfolioValue: Math.round(futureValue * 100) / 100,
      totalDividendsReinvested: Math.round(totalDividendsReinvested * 100) / 100,
      totalContributions: Math.round(totalContributions * 100) / 100,
      totalGain: Math.round(totalGain * 100) / 100,
      gainPercentage: Math.round(gainPercentage * 10) / 10,
      yearlyBreakdown,
    })
  }

  const handleReset = () => {
    setInitialInvestment("")
    setStockPrice("")
    setDividendYield("")
    setDividendPerShare("")
    setGrowthRate("")
    setDuration("")
    setMonthlyContribution("")
    setTaxRate("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `DRIP Calculator Results:
Portfolio Value: ${formatCurrency(result.futurePortfolioValue, currency)}
Total Shares: ${result.totalShares.toLocaleString()}
Total Dividends Reinvested: ${formatCurrency(result.totalDividendsReinvested, currency)}
Total Gain: ${formatCurrency(result.totalGain, currency)} (${result.gainPercentage}%)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "DRIP Calculator Results",
          text: `My projected portfolio value with dividend reinvestment: ${formatCurrency(result.futurePortfolioValue, currency)} (${result.gainPercentage}% gain)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">DRIP Calculator</CardTitle>
                    <CardDescription>Estimate dividend reinvestment growth</CardDescription>
                  </div>
                </div>
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Investment */}
                <div className="space-y-2">
                  <Label htmlFor="initialInvestment">Initial Investment ({symbol})</Label>
                  <Input
                    id="initialInvestment"
                    type="number"
                    placeholder="e.g., 10000"
                    value={initialInvestment}
                    onChange={(e) => setInitialInvestment(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Stock Price */}
                <div className="space-y-2">
                  <Label htmlFor="stockPrice">Current Stock Price ({symbol})</Label>
                  <Input
                    id="stockPrice"
                    type="number"
                    placeholder="e.g., 50"
                    value={stockPrice}
                    onChange={(e) => setStockPrice(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Dividend Type Toggle */}
                <div className="space-y-2">
                  <Label>Dividend Input Type</Label>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant={dividendType === "yield" ? "default" : "outline"}
                      size="sm"
                      className="flex-1"
                      onClick={() => setDividendType("yield")}
                    >
                      Yield (%)
                    </Button>
                    <Button
                      type="button"
                      variant={dividendType === "perShare" ? "default" : "outline"}
                      size="sm"
                      className="flex-1"
                      onClick={() => setDividendType("perShare")}
                    >
                      Per Share ({symbol})
                    </Button>
                  </div>
                </div>

                {/* Dividend Input */}
                {dividendType === "yield" ? (
                  <div className="space-y-2">
                    <Label htmlFor="dividendYield">Annual Dividend Yield (%)</Label>
                    <Input
                      id="dividendYield"
                      type="number"
                      placeholder="e.g., 3.5"
                      value={dividendYield}
                      onChange={(e) => setDividendYield(e.target.value)}
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="dividendPerShare">Annual Dividend Per Share ({symbol})</Label>
                    <Input
                      id="dividendPerShare"
                      type="number"
                      placeholder="e.g., 2.00"
                      value={dividendPerShare}
                      onChange={(e) => setDividendPerShare(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}

                {/* Growth Rate */}
                <div className="space-y-2">
                  <Label htmlFor="growthRate">Expected Annual Stock Price Growth (%)</Label>
                  <Input
                    id="growthRate"
                    type="number"
                    placeholder="e.g., 7"
                    value={growthRate}
                    onChange={(e) => setGrowthRate(e.target.value)}
                    min="-50"
                    max="100"
                    step="0.5"
                  />
                </div>

                {/* Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Investment Duration (Years)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="e.g., 20"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="1"
                    max="50"
                  />
                </div>

                {/* Dividend Frequency */}
                <div className="space-y-2">
                  <Label htmlFor="frequency">Dividend Payment Frequency</Label>
                  <Select value={frequency} onValueChange={(v) => setFrequency(v as Frequency)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="semiannual">Semi-Annual</SelectItem>
                      <SelectItem value="annual">Annual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="monthlyContribution">Monthly Contribution ({symbol})</Label>
                      <Input
                        id="monthlyContribution"
                        type="number"
                        placeholder="e.g., 500"
                        value={monthlyContribution}
                        onChange={(e) => setMonthlyContribution(e.target.value)}
                        min="0"
                        step="50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="taxRate">Dividend Tax Rate (%)</Label>
                      <Input
                        id="taxRate"
                        type="number"
                        placeholder="e.g., 15"
                        value={taxRate}
                        onChange={(e) => setTaxRate(e.target.value)}
                        min="0"
                        max="100"
                        step="0.5"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDRIP} className="w-full" size="lg">
                  Calculate DRIP Growth
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Future Portfolio Value</p>
                      <p className="text-4xl font-bold text-green-600">
                        {formatCurrency(result.futurePortfolioValue, currency)}
                      </p>
                      <p className="text-lg font-semibold text-green-700 mt-1">
                        +{result.gainPercentage}% Total Return
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Shares</p>
                        <p className="text-lg font-bold text-foreground">{result.totalShares.toLocaleString()}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Dividends Reinvested</p>
                        <p className="text-lg font-bold text-foreground">
                          {formatCurrency(result.totalDividendsReinvested, currency)}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Contributions</p>
                        <p className="text-lg font-bold text-foreground">
                          {formatCurrency(result.totalContributions, currency)}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Total Gain</p>
                        <p className="text-lg font-bold text-green-600">{formatCurrency(result.totalGain, currency)}</p>
                      </div>
                    </div>

                    {/* Visual Breakdown */}
                    <div className="mb-4">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Contributions vs Growth</span>
                      </div>
                      <div className="h-4 rounded-full overflow-hidden bg-muted flex">
                        <div
                          className="bg-blue-500 h-full"
                          style={{
                            width: `${(result.totalContributions / result.futurePortfolioValue) * 100}%`,
                          }}
                        />
                        <div
                          className="bg-green-500 h-full"
                          style={{
                            width: `${(result.totalGain / result.futurePortfolioValue) * 100}%`,
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span className="text-blue-600">Contributions</span>
                        <span className="text-green-600">Growth + Dividends</span>
                      </div>
                    </div>

                    {/* Year-by-Year Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full mb-2 bg-transparent">
                          {showBreakdown ? "Hide" : "Show"} Year-by-Year Breakdown
                          {showBreakdown ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="max-h-64 overflow-y-auto rounded-lg border bg-white">
                          <table className="w-full text-xs">
                            <thead className="sticky top-0 bg-muted">
                              <tr>
                                <th className="p-2 text-left">Year</th>
                                <th className="p-2 text-right">Shares</th>
                                <th className="p-2 text-right">Price</th>
                                <th className="p-2 text-right">Value</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.yearlyBreakdown.map((row) => (
                                <tr key={row.year} className="border-t">
                                  <td className="p-2">{row.year}</td>
                                  <td className="p-2 text-right">{row.shares.toLocaleString()}</td>
                                  <td className="p-2 text-right">{formatCurrency(row.stockPrice, currency)}</td>
                                  <td className="p-2 text-right font-medium">
                                    {formatCurrency(row.portfolioValue, currency)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How DRIP Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 text-xs font-bold shrink-0">
                        1
                      </div>
                      <p className="text-muted-foreground">
                        <strong className="text-foreground">Receive Dividends</strong> - Company pays dividends based on
                        shares owned
                      </p>
                    </div>
                    <div className="flex gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 text-xs font-bold shrink-0">
                        2
                      </div>
                      <p className="text-muted-foreground">
                        <strong className="text-foreground">Automatic Reinvestment</strong> - Dividends buy more shares
                        at current price
                      </p>
                    </div>
                    <div className="flex gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 text-xs font-bold shrink-0">
                        3
                      </div>
                      <p className="text-muted-foreground">
                        <strong className="text-foreground">Compound Growth</strong> - More shares generate more
                        dividends over time
                      </p>
                    </div>
                    <div className="flex gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 text-xs font-bold shrink-0">
                        4
                      </div>
                      <p className="text-muted-foreground">
                        <strong className="text-foreground">Wealth Accumulation</strong> - Portfolio grows exponentially
                        over years
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">DRIP Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">New Shares = Dividend ÷ Stock Price</p>
                    <p className="text-xs mt-2">Total Value = Shares × Current Price</p>
                  </div>
                  <p>
                    Each dividend payment is used to purchase additional shares, which then generate their own dividends
                    in subsequent periods.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Benefits of DRIP</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Compound Returns</span>
                      <p className="text-green-600 text-xs mt-1">Dividends earn dividends over time</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Dollar-Cost Averaging</span>
                      <p className="text-blue-600 text-xs mt-1">Buy shares at various price points</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Automatic Investing</span>
                      <p className="text-purple-600 text-xs mt-1">No manual reinvestment needed</p>
                    </div>
                    <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Often Commission-Free</span>
                      <p className="text-orange-600 text-xs mt-1">Many brokers offer free DRIP enrollment</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Dividend Reinvestment (DRIP)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A Dividend Reinvestment Plan (DRIP) is an investment strategy where dividends paid by a stock or
                  mutual fund are automatically used to purchase additional shares of that same investment. Instead of
                  receiving cash dividends, investors accumulate more shares over time, which in turn generate more
                  dividends in a compounding cycle.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Many companies and brokerage firms offer DRIPs, often with no commission fees. Some company-sponsored
                  DRIPs even offer shares at a small discount to market price. This makes DRIP an attractive option for
                  long-term investors focused on wealth accumulation rather than immediate income.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>The Power of Dividend Compounding</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The true power of DRIP lies in compounding. When you reinvest dividends to buy more shares, those new
                  shares also earn dividends. Over time, this creates a snowball effect where your investment grows
                  exponentially rather than linearly.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, an investment with a 3% dividend yield might seem modest, but over 20-30 years of
                  consistent reinvestment combined with stock price appreciation, the total return can be substantially
                  higher than an investment without dividend reinvestment. Historical data shows that a significant
                  portion of total stock market returns come from reinvested dividends.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While DRIPs offer many benefits, there are important factors to consider. Dividends are generally
                  taxable in the year they are paid, even when reinvested. This can create a tax liability without
                  corresponding cash income. Keep accurate records of reinvested dividends to properly calculate your
                  cost basis when selling.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Additionally, automatic reinvestment means you continue buying shares regardless of the stock's
                  valuation. This could result in purchasing overvalued shares. Consider your overall portfolio
                  allocation and whether continued investment in a single stock aligns with your diversification goals.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Dividend reinvestment calculations are estimates based on entered values and assumed growth rates.
                      Actual investment outcomes may vary due to market fluctuations, dividend changes, and taxes.
                      Consult a financial advisor for personalized guidance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
