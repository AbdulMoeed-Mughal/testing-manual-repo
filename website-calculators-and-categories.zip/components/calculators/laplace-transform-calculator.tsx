"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Calculator, Info, ChevronDown, ChevronUp, Share2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

interface LaplaceResult {
  originalFunction: string
  transformedFunction: string
  roc: string
  steps: string[]
  method: string
}

// Common Laplace transform pairs
const transformPairs: { [key: string]: { transform: string; roc: string } } = {
  "1": { transform: "1/s", roc: "Re(s) > 0" },
  t: { transform: "1/s²", roc: "Re(s) > 0" },
  "t^2": { transform: "2/s³", roc: "Re(s) > 0" },
  "t^3": { transform: "6/s⁴", roc: "Re(s) > 0" },
  "t^n": { transform: "n!/s^(n+1)", roc: "Re(s) > 0" },
  "e^(at)": { transform: "1/(s-a)", roc: "Re(s) > a" },
  "e^(-at)": { transform: "1/(s+a)", roc: "Re(s) > -a" },
  "sin(at)": { transform: "a/(s² + a²)", roc: "Re(s) > 0" },
  "cos(at)": { transform: "s/(s² + a²)", roc: "Re(s) > 0" },
  "sinh(at)": { transform: "a/(s² - a²)", roc: "Re(s) > |a|" },
  "cosh(at)": { transform: "s/(s² - a²)", roc: "Re(s) > |a|" },
  "t*e^(at)": { transform: "1/(s-a)²", roc: "Re(s) > a" },
  "t*sin(at)": { transform: "2as/(s² + a²)²", roc: "Re(s) > 0" },
  "t*cos(at)": { transform: "(s² - a²)/(s² + a²)²", roc: "Re(s) > 0" },
  "e^(at)*sin(bt)": { transform: "b/((s-a)² + b²)", roc: "Re(s) > a" },
  "e^(at)*cos(bt)": { transform: "(s-a)/((s-a)² + b²)", roc: "Re(s) > a" },
  "u(t)": { transform: "1/s", roc: "Re(s) > 0" },
  "delta(t)": { transform: "1", roc: "All s" },
}

export function LaplaceTransformCalculator() {
  const [functionInput, setFunctionInput] = useState("")
  const [transformVar, setTransformVar] = useState("s")
  const [method, setMethod] = useState<"table" | "definition">("table")
  const [showSteps, setShowSteps] = useState(true)
  const [result, setResult] = useState<LaplaceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [showStepsPanel, setShowStepsPanel] = useState(false)

  const parseAndTransform = (input: string): LaplaceResult | null => {
    const cleanInput = input.trim().toLowerCase().replace(/\s+/g, "")
    const steps: string[] = []

    // Check for exact matches in transform pairs
    for (const [func, data] of Object.entries(transformPairs)) {
      const normalizedFunc = func.toLowerCase().replace(/\s+/g, "")
      if (cleanInput === normalizedFunc) {
        steps.push(`Identify the function: f(t) = ${func}`)
        steps.push(`Look up in standard Laplace transform table`)
        steps.push(`L{${func}} = ${data.transform}`)
        steps.push(`Region of convergence: ${data.roc}`)
        return {
          originalFunction: func,
          transformedFunction: data.transform,
          roc: data.roc,
          steps,
          method: "Table lookup",
        }
      }
    }

    // Parse polynomial terms (e.g., "3t^2", "5t", "7")
    const polyMatch = cleanInput.match(/^(-?\d*\.?\d*)\*?t\^?(\d*)$/)
    if (polyMatch) {
      const coeff =
        polyMatch[1] === "" || polyMatch[1] === "-" ? (polyMatch[1] === "-" ? -1 : 1) : Number.parseFloat(polyMatch[1])
      const power = polyMatch[2] === "" ? 1 : Number.parseInt(polyMatch[2])

      const factorial = (n: number): number => (n <= 1 ? 1 : n * factorial(n - 1))
      const fact = factorial(power)

      steps.push(`Identify the function: f(t) = ${coeff === 1 ? "" : coeff}t${power === 1 ? "" : "^" + power}`)
      steps.push(`Apply the formula: L{t^n} = n!/s^(n+1)`)
      steps.push(`For n = ${power}: L{t^${power}} = ${fact}/s^${power + 1}`)
      if (coeff !== 1) {
        steps.push(
          `Apply linearity: L{${coeff}·t^${power}} = ${coeff} × ${fact}/s^${power + 1} = ${coeff * fact}/s^${power + 1}`,
        )
      }

      return {
        originalFunction: `${coeff === 1 ? "" : coeff}t${power === 1 ? "" : "^" + power}`,
        transformedFunction: `${coeff * fact}/${transformVar}^${power + 1}`,
        roc: "Re(s) > 0",
        steps,
        method: "Power rule",
      }
    }

    // Parse constant
    const constMatch = cleanInput.match(/^(-?\d+\.?\d*)$/)
    if (constMatch) {
      const c = Number.parseFloat(constMatch[1])
      steps.push(`Identify the function: f(t) = ${c}`)
      steps.push(`Apply the formula: L{c} = c/s`)
      steps.push(`L{${c}} = ${c}/${transformVar}`)
      return {
        originalFunction: `${c}`,
        transformedFunction: `${c}/${transformVar}`,
        roc: "Re(s) > 0",
        steps,
        method: "Constant rule",
      }
    }

    // Parse e^(at) or exp(at)
    const expMatch = cleanInput.match(/^e\^?$$(-?\d*\.?\d*)t$$$/) || cleanInput.match(/^exp$$(-?\d*\.?\d*)t$$$/)
    if (expMatch) {
      const a =
        expMatch[1] === "" || expMatch[1] === "-" ? (expMatch[1] === "-" ? -1 : 1) : Number.parseFloat(expMatch[1])
      steps.push(`Identify the function: f(t) = e^(${a}t)`)
      steps.push(`Apply the formula: L{e^(at)} = 1/(s-a)`)
      if (a >= 0) {
        steps.push(`For a = ${a}: L{e^(${a}t)} = 1/(${transformVar}-${a})`)
      } else {
        steps.push(`For a = ${a}: L{e^(${a}t)} = 1/(${transformVar}+${Math.abs(a)})`)
      }
      return {
        originalFunction: `e^(${a}t)`,
        transformedFunction: a >= 0 ? `1/(${transformVar}-${a})` : `1/(${transformVar}+${Math.abs(a)})`,
        roc: `Re(s) > ${a}`,
        steps,
        method: "Exponential rule",
      }
    }

    // Parse sin(at) or cos(at)
    const trigMatch = cleanInput.match(/^(sin|cos)$$(\d*\.?\d*)t$$$/)
    if (trigMatch) {
      const func = trigMatch[1]
      const a = trigMatch[2] === "" ? 1 : Number.parseFloat(trigMatch[2])

      if (func === "sin") {
        steps.push(`Identify the function: f(t) = sin(${a}t)`)
        steps.push(`Apply the formula: L{sin(at)} = a/(s² + a²)`)
        steps.push(`For a = ${a}: L{sin(${a}t)} = ${a}/(${transformVar}² + ${a * a})`)
        return {
          originalFunction: `sin(${a}t)`,
          transformedFunction: `${a}/(${transformVar}² + ${a * a})`,
          roc: "Re(s) > 0",
          steps,
          method: "Trigonometric rule",
        }
      } else {
        steps.push(`Identify the function: f(t) = cos(${a}t)`)
        steps.push(`Apply the formula: L{cos(at)} = s/(s² + a²)`)
        steps.push(`For a = ${a}: L{cos(${a}t)} = ${transformVar}/(${transformVar}² + ${a * a})`)
        return {
          originalFunction: `cos(${a}t)`,
          transformedFunction: `${transformVar}/(${transformVar}² + ${a * a})`,
          roc: "Re(s) > 0",
          steps,
          method: "Trigonometric rule",
        }
      }
    }

    // Parse sinh(at) or cosh(at)
    const hypMatch = cleanInput.match(/^(sinh|cosh)$$(\d*\.?\d*)t$$$/)
    if (hypMatch) {
      const func = hypMatch[1]
      const a = hypMatch[2] === "" ? 1 : Number.parseFloat(hypMatch[2])

      if (func === "sinh") {
        steps.push(`Identify the function: f(t) = sinh(${a}t)`)
        steps.push(`Apply the formula: L{sinh(at)} = a/(s² - a²)`)
        steps.push(`For a = ${a}: L{sinh(${a}t)} = ${a}/(${transformVar}² - ${a * a})`)
        return {
          originalFunction: `sinh(${a}t)`,
          transformedFunction: `${a}/(${transformVar}² - ${a * a})`,
          roc: `Re(s) > ${a}`,
          steps,
          method: "Hyperbolic rule",
        }
      } else {
        steps.push(`Identify the function: f(t) = cosh(${a}t)`)
        steps.push(`Apply the formula: L{cosh(at)} = s/(s² - a²)`)
        steps.push(`For a = ${a}: L{cosh(${a}t)} = ${transformVar}/(${transformVar}² - ${a * a})`)
        return {
          originalFunction: `cosh(${a}t)`,
          transformedFunction: `${transformVar}/(${transformVar}² - ${a * a})`,
          roc: `Re(s) > ${a}`,
          steps,
          method: "Hyperbolic rule",
        }
      }
    }

    // Parse unit step u(t-a)
    const unitStepMatch = cleanInput.match(/^u$$t(-(\d+\.?\d*))?$$$/)
    if (unitStepMatch) {
      const a = unitStepMatch[2] ? Number.parseFloat(unitStepMatch[2]) : 0
      if (a === 0) {
        steps.push(`Identify the function: f(t) = u(t) (unit step function)`)
        steps.push(`Apply the formula: L{u(t)} = 1/s`)
        return {
          originalFunction: "u(t)",
          transformedFunction: `1/${transformVar}`,
          roc: "Re(s) > 0",
          steps,
          method: "Unit step rule",
        }
      } else {
        steps.push(`Identify the function: f(t) = u(t-${a}) (shifted unit step)`)
        steps.push(`Apply the time-shifting property: L{u(t-a)} = e^(-as)/s`)
        steps.push(`For a = ${a}: L{u(t-${a})} = e^(-${a}${transformVar})/${transformVar}`)
        return {
          originalFunction: `u(t-${a})`,
          transformedFunction: `e^(-${a}${transformVar})/${transformVar}`,
          roc: "Re(s) > 0",
          steps,
          method: "Time-shifting property",
        }
      }
    }

    // Parse delta(t-a)
    const deltaMatch = cleanInput.match(/^delta$$t(-(\d+\.?\d*))?$$$/)
    if (deltaMatch) {
      const a = deltaMatch[2] ? Number.parseFloat(deltaMatch[2]) : 0
      if (a === 0) {
        steps.push(`Identify the function: f(t) = δ(t) (Dirac delta function)`)
        steps.push(`Apply the formula: L{δ(t)} = 1`)
        return {
          originalFunction: "δ(t)",
          transformedFunction: "1",
          roc: "All s",
          steps,
          method: "Delta function rule",
        }
      } else {
        steps.push(`Identify the function: f(t) = δ(t-${a}) (shifted delta)`)
        steps.push(`Apply the time-shifting property: L{δ(t-a)} = e^(-as)`)
        steps.push(`For a = ${a}: L{δ(t-${a})} = e^(-${a}${transformVar})`)
        return {
          originalFunction: `δ(t-${a})`,
          transformedFunction: `e^(-${a}${transformVar})`,
          roc: "All s",
          steps,
          method: "Time-shifting property",
        }
      }
    }

    return null
  }

  const calculateTransform = () => {
    setError("")
    setResult(null)

    if (!functionInput.trim()) {
      setError("Please enter a time-domain function")
      return
    }

    const transformResult = parseAndTransform(functionInput)

    if (transformResult) {
      setResult(transformResult)
    } else {
      setError("Unable to compute Laplace transform. Please check your input format.")
    }
  }

  const handleReset = () => {
    setFunctionInput("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
    setShowStepsPanel(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `L{${result.originalFunction}} = ${result.transformedFunction}, ROC: ${result.roc}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      const latex = `\\mathcal{L}\\{${result.originalFunction}\\} = ${result.transformedFunction}`
      await navigator.clipboard.writeText(latex)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Laplace Transform Result",
          text: `L{${result.originalFunction}} = ${result.transformedFunction}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Laplace Transform Calculator</CardTitle>
                    <CardDescription>Compute Laplace transforms of functions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Function Input */}
                <div className="space-y-2">
                  <Label htmlFor="function">Time-Domain Function f(t)</Label>
                  <Input
                    id="function"
                    type="text"
                    placeholder="e.g., t^2, sin(3t), e^(-2t), u(t)"
                    value={functionInput}
                    onChange={(e) => setFunctionInput(e.target.value)}
                  />
                </div>

                {/* Transform Variable */}
                <div className="space-y-2">
                  <Label>Transform Variable</Label>
                  <Select value={transformVar} onValueChange={setTransformVar}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="s">s (standard)</SelectItem>
                      <SelectItem value="p">p</SelectItem>
                      <SelectItem value="z">z</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Method Selection */}
                <div className="space-y-2">
                  <Label>Method</Label>
                  <Select value={method} onValueChange={(v) => setMethod(v as "table" | "definition")}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="table">Table-based lookup</SelectItem>
                      <SelectItem value="definition">Definition-based</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show step-by-step solution</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateTransform} className="w-full" size="lg">
                  Calculate Transform
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <p className="text-sm text-muted-foreground">Laplace Transform</p>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-lg font-mono">
                          <span className="text-muted-foreground">L{`{`}</span>
                          <span className="font-semibold text-blue-600">{result.originalFunction}</span>
                          <span className="text-muted-foreground">{`}`}</span>
                          <span className="mx-2">=</span>
                          <span className="font-bold text-blue-700 text-xl">{result.transformedFunction}</span>
                        </p>
                      </div>
                      <div className="flex items-center justify-center gap-2 text-sm">
                        <span className="text-muted-foreground">ROC:</span>
                        <span className="font-medium text-blue-600">{result.roc}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">Method: {result.method}</div>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowStepsPanel(!showStepsPanel)}
                          className="flex items-center justify-between w-full p-2 bg-white rounded-lg border hover:bg-gray-50 transition-colors"
                        >
                          <span className="text-sm font-medium">Step-by-step Solution</span>
                          {showStepsPanel ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>
                        {showStepsPanel && (
                          <div className="mt-2 p-3 bg-white rounded-lg border space-y-2">
                            {result.steps.map((step, index) => (
                              <div key={index} className="flex gap-2 text-sm">
                                <span className="font-semibold text-blue-600">{index + 1}.</span>
                                <span>{step}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4 flex-wrap">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Laplace Transforms</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm font-mono">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>L{`{1}`}</span>
                      <span className="text-blue-600">1/s</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>L{`{t}`}</span>
                      <span className="text-blue-600">1/s²</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>L{`{t^n}`}</span>
                      <span className="text-blue-600">n!/s^(n+1)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>L{`{e^(at)}`}</span>
                      <span className="text-blue-600">1/(s-a)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>L{`{sin(at)}`}</span>
                      <span className="text-blue-600">a/(s²+a²)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>L{`{cos(at)}`}</span>
                      <span className="text-blue-600">s/(s²+a²)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>L{`{δ(t)}`}</span>
                      <span className="text-blue-600">1</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>L{`{u(t)}`}</span>
                      <span className="text-blue-600">1/s</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Polynomials:</strong> t, t^2, 3t^4
                  </p>
                  <p>
                    <strong>Exponentials:</strong> e^(2t), e^(-3t)
                  </p>
                  <p>
                    <strong>Trigonometric:</strong> sin(2t), cos(5t)
                  </p>
                  <p>
                    <strong>Hyperbolic:</strong> sinh(t), cosh(2t)
                  </p>
                  <p>
                    <strong>Unit Step:</strong> u(t), u(t-3)
                  </p>
                  <p>
                    <strong>Delta:</strong> delta(t), delta(t-2)
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Definition</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center mb-3">
                    <p>L{`{f(t)}`} = ∫₀^∞ e^(-st) f(t) dt</p>
                  </div>
                  <p>
                    The Laplace transform converts a function of time f(t) into a function of complex frequency F(s),
                    making it easier to analyze and solve differential equations.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Laplace Transform?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Laplace transform is an integral transform that converts a function of time f(t) into a function
                  of complex frequency F(s). Named after Pierre-Simon Laplace, this mathematical tool is fundamental in
                  engineering and physics, particularly for solving linear ordinary differential equations with constant
                  coefficients. It transforms differentiation and integration into multiplication and division
                  operations, significantly simplifying the analysis of linear time-invariant systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The transform is particularly useful in control theory, signal processing, and circuit analysis. It
                  allows engineers to analyze the behavior of systems in the frequency domain, where complex
                  differential equations become simple algebraic equations. The region of convergence (ROC) specifies
                  the values of s for which the integral converges, ensuring the transform exists.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Key Properties</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Linearity</h4>
                    <p className="text-blue-700 text-sm font-mono">L{`{af + bg}`} = aF(s) + bG(s)</p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Time Shifting</h4>
                    <p className="text-green-700 text-sm font-mono">L{`{f(t-a)u(t-a)}`} = e^(-as)F(s)</p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Frequency Shifting</h4>
                    <p className="text-purple-700 text-sm font-mono">L{`{e^(at)f(t)}`} = F(s-a)</p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Differentiation</h4>
                    <p className="text-orange-700 text-sm font-mono">L{`{f'(t)}`} = sF(s) - f(0)</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <Card className="mt-8 bg-yellow-50 border-yellow-200">
            <CardContent className="pt-6">
              <p className="text-sm text-yellow-800">
                <strong>Note:</strong> Laplace transform calculations follow standard mathematical definitions. Results
                depend on correct function input and convergence conditions. This calculator handles common function
                types; complex expressions may require manual computation or advanced software.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
