"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Dumbbell, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Formula = "epley" | "brzycki" | "lander" | "lombardi" | "average"

interface OneRMResult {
  oneRM: number
  formula: string
  allResults: { formula: string; value: number }[]
  trainingWeights: { percent: number; weight: number; reps: string }[]
}

const FORMULAS: { value: Formula; label: string; description: string }[] = [
  { value: "epley", label: "Epley", description: "Most commonly used formula" },
  { value: "brzycki", label: "Brzycki", description: "Accurate for lower rep ranges" },
  { value: "lander", label: "Lander", description: "Good for moderate rep ranges" },
  { value: "lombardi", label: "Lombardi", description: "Uses exponential calculation" },
  { value: "average", label: "Average All", description: "Average of all formulas" },
]

const EXERCISES = [
  "Bench Press",
  "Squat",
  "Deadlift",
  "Overhead Press",
  "Barbell Row",
  "Romanian Deadlift",
  "Front Squat",
  "Incline Bench Press",
  "Other",
]

export function OneRepMaxCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [weight, setWeight] = useState("")
  const [reps, setReps] = useState("")
  const [formula, setFormula] = useState<Formula>("epley")
  const [exercise, setExercise] = useState("")
  const [result, setResult] = useState<OneRMResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculate1RM = (weightValue: number, repsValue: number, formulaType: Formula): number => {
    switch (formulaType) {
      case "epley":
        return weightValue * (1 + 0.0333 * repsValue)
      case "brzycki":
        return weightValue * (36 / (37 - repsValue))
      case "lander":
        return (100 * weightValue) / (101.3 - 2.67123 * repsValue)
      case "lombardi":
        return weightValue * Math.pow(repsValue, 0.1)
      default:
        return weightValue * (1 + 0.0333 * repsValue)
    }
  }

  const calculateOneRM = () => {
    setError("")
    setResult(null)

    const weightNum = Number.parseFloat(weight)
    const repsNum = Number.parseInt(reps)

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    if (isNaN(repsNum) || repsNum < 1 || repsNum > 12) {
      setError("Please enter repetitions between 1 and 12")
      return
    }

    if (repsNum === 1) {
      // If 1 rep, the weight is already the 1RM
      const trainingWeights = [
        { percent: 100, weight: weightNum, reps: "1" },
        { percent: 95, weight: Math.round(weightNum * 0.95 * 10) / 10, reps: "2" },
        { percent: 90, weight: Math.round(weightNum * 0.9 * 10) / 10, reps: "3-4" },
        { percent: 85, weight: Math.round(weightNum * 0.85 * 10) / 10, reps: "5-6" },
        { percent: 80, weight: Math.round(weightNum * 0.8 * 10) / 10, reps: "7-8" },
        { percent: 75, weight: Math.round(weightNum * 0.75 * 10) / 10, reps: "9-10" },
        { percent: 70, weight: Math.round(weightNum * 0.7 * 10) / 10, reps: "11-12" },
        { percent: 65, weight: Math.round(weightNum * 0.65 * 10) / 10, reps: "13-15" },
      ]

      setResult({
        oneRM: weightNum,
        formula: "Direct (1 rep performed)",
        allResults: [{ formula: "Direct", value: weightNum }],
        trainingWeights,
      })
      return
    }

    // Calculate with all formulas
    const allResults = [
      { formula: "Epley", value: Math.round(calculate1RM(weightNum, repsNum, "epley") * 10) / 10 },
      { formula: "Brzycki", value: Math.round(calculate1RM(weightNum, repsNum, "brzycki") * 10) / 10 },
      { formula: "Lander", value: Math.round(calculate1RM(weightNum, repsNum, "lander") * 10) / 10 },
      { formula: "Lombardi", value: Math.round(calculate1RM(weightNum, repsNum, "lombardi") * 10) / 10 },
    ]

    let oneRM: number
    let formulaUsed: string

    if (formula === "average") {
      oneRM = Math.round((allResults.reduce((sum, r) => sum + r.value, 0) / allResults.length) * 10) / 10
      formulaUsed = "Average of All Formulas"
    } else {
      const selectedResult = allResults.find((r) => r.formula.toLowerCase() === formula)
      oneRM = selectedResult?.value || allResults[0].value
      formulaUsed = FORMULAS.find((f) => f.value === formula)?.label || "Epley"
    }

    // Calculate training weights based on 1RM
    const trainingWeights = [
      { percent: 100, weight: oneRM, reps: "1" },
      { percent: 95, weight: Math.round(oneRM * 0.95 * 10) / 10, reps: "2" },
      { percent: 90, weight: Math.round(oneRM * 0.9 * 10) / 10, reps: "3-4" },
      { percent: 85, weight: Math.round(oneRM * 0.85 * 10) / 10, reps: "5-6" },
      { percent: 80, weight: Math.round(oneRM * 0.8 * 10) / 10, reps: "7-8" },
      { percent: 75, weight: Math.round(oneRM * 0.75 * 10) / 10, reps: "9-10" },
      { percent: 70, weight: Math.round(oneRM * 0.7 * 10) / 10, reps: "11-12" },
      { percent: 65, weight: Math.round(oneRM * 0.65 * 10) / 10, reps: "13-15" },
    ]

    setResult({
      oneRM,
      formula: formulaUsed,
      allResults,
      trainingWeights,
    })
  }

  const handleReset = () => {
    setWeight("")
    setReps("")
    setFormula("epley")
    setExercise("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const exerciseText = exercise ? ` for ${exercise}` : ""
      await navigator.clipboard.writeText(
        `My estimated 1RM${exerciseText} is ${result.oneRM} ${unitSystem === "metric" ? "kg" : "lb"} (${result.formula})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const exerciseText = exercise ? ` for ${exercise}` : ""
      try {
        await navigator.share({
          title: "My One-Rep Max Result",
          text: `I calculated my 1RM${exerciseText} using CalcHub! My estimated max is ${result.oneRM} ${unitSystem === "metric" ? "kg" : "lb"}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Dumbbell className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">One-Rep Max Calculator</CardTitle>
                    <CardDescription>Estimate your maximum single-rep lift</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight Lifted ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.5"
                  />
                </div>

                {/* Reps Input */}
                <div className="space-y-2">
                  <Label htmlFor="reps">Repetitions Performed (1-12)</Label>
                  <Input
                    id="reps"
                    type="number"
                    placeholder="Enter number of reps"
                    value={reps}
                    onChange={(e) => setReps(e.target.value)}
                    min="1"
                    max="12"
                  />
                  <p className="text-xs text-muted-foreground">Formulas are most accurate for 1-12 reps</p>
                </div>

                {/* Formula Selection */}
                <div className="space-y-2">
                  <Label>Formula</Label>
                  <Select value={formula} onValueChange={(value: Formula) => setFormula(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select formula" />
                    </SelectTrigger>
                    <SelectContent>
                      {FORMULAS.map((f) => (
                        <SelectItem key={f.value} value={f.value}>
                          <div className="flex flex-col">
                            <span>{f.label}</span>
                            <span className="text-xs text-muted-foreground">{f.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Exercise Selection (Optional) */}
                <div className="space-y-2">
                  <Label>Exercise (Optional)</Label>
                  <Select value={exercise} onValueChange={setExercise}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select exercise" />
                    </SelectTrigger>
                    <SelectContent>
                      {EXERCISES.map((ex) => (
                        <SelectItem key={ex} value={ex}>
                          {ex}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateOneRM} className="w-full" size="lg">
                  Calculate 1RM
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        Estimated One-Rep Max{exercise ? ` (${exercise})` : ""}
                      </p>
                      <p className="text-5xl font-bold text-green-600 mb-2">
                        {result.oneRM} <span className="text-2xl">{unitSystem === "metric" ? "kg" : "lb"}</span>
                      </p>
                      <p className="text-sm text-green-600">Using {result.formula}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show All Formulas
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-green-200 space-y-3">
                        <p className="text-sm font-medium text-center mb-2">Results by Formula</p>
                        <div className="grid grid-cols-2 gap-2">
                          {result.allResults.map((r) => (
                            <div
                              key={r.formula}
                              className="p-2 bg-white rounded-lg border border-green-100 text-center"
                            >
                              <p className="text-xs text-muted-foreground">{r.formula}</p>
                              <p className="font-semibold text-green-700">
                                {r.value} {unitSystem === "metric" ? "kg" : "lb"}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              {/* Training Weights */}
              {result && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Training Weights</CardTitle>
                    <CardDescription>Suggested weights for different rep ranges</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {result.trainingWeights.map((tw) => (
                        <div
                          key={tw.percent}
                          className={`flex items-center justify-between p-3 rounded-lg ${
                            tw.percent === 100
                              ? "bg-red-50 border border-red-200"
                              : tw.percent >= 85
                                ? "bg-orange-50 border border-orange-200"
                                : tw.percent >= 75
                                  ? "bg-yellow-50 border border-yellow-200"
                                  : "bg-green-50 border border-green-200"
                          }`}
                        >
                          <div>
                            <span className="font-medium">{tw.percent}%</span>
                            <span className="text-sm text-muted-foreground ml-2">({tw.reps} reps)</span>
                          </div>
                          <span className="font-semibold">
                            {tw.weight} {unitSystem === "metric" ? "kg" : "lb"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Formulas Reference */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">1RM Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium mb-1">Epley Formula</p>
                    <p className="font-mono text-xs">1RM = Weight × (1 + 0.0333 × Reps)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium mb-1">Brzycki Formula</p>
                    <p className="font-mono text-xs">1RM = Weight × (36 / (37 − Reps))</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium mb-1">Lander Formula</p>
                    <p className="font-mono text-xs">1RM = (100 × Weight) / (101.3 − 2.67 × Reps)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium mb-1">Lombardi Formula</p>
                    <p className="font-mono text-xs">1RM = Weight × Reps^0.10</p>
                  </div>
                </CardContent>
              </Card>

              {/* Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Tips for Accuracy</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Use strict form - no bouncing or assistance</p>
                  <p>• Lower rep ranges (1-5) give more accurate estimates</p>
                  <p>• Results vary between exercises and individuals</p>
                  <p>• Always warm up properly before heavy lifts</p>
                  <p>• Use a spotter when testing true 1RM</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is One-Rep Max (1RM)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  One-Rep Max (1RM) is the maximum amount of weight you can lift for a single repetition of a given
                  exercise with proper form. It&apos;s a key metric in strength training used to measure progress,
                  design training programs, and set appropriate working weights. Rather than testing your actual 1RM
                  (which can be risky), you can estimate it using submaximal lifts and mathematical formulas.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Knowing your 1RM allows you to calculate percentages for different training goals: strength work
                  typically uses 85-95% of 1RM, hypertrophy (muscle building) uses 70-85%, and muscular endurance
                  training uses 50-70%. This calculator uses proven formulas developed by sports scientists to give you
                  reliable estimates without the risk of maximal testing.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Dumbbell className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Formulas</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Epley Formula:</strong> The most widely used formula, particularly effective for rep ranges of
                  1-10. It assumes a linear relationship between weight and repetitions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-3">
                  <strong>Brzycki Formula:</strong> Often considered most accurate for lower rep ranges (1-6). It tends
                  to give slightly lower estimates than Epley for higher rep ranges.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-3">
                  <strong>Lander Formula:</strong> Provides a good middle ground and works well across moderate rep
                  ranges (3-10 reps).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-3">
                  <strong>Lombardi Formula:</strong> Uses an exponential calculation and may be more accurate for
                  experienced lifters with consistent form.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> 1RM calculations are estimates and may vary based on individual strength,
                  form, fatigue, and exercise technique. These formulas are most accurate for rep ranges of 1-12. Always
                  prioritize safety, use proper form, and have a spotter when attempting heavy lifts. Consult a fitness
                  professional before starting any new training program.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
