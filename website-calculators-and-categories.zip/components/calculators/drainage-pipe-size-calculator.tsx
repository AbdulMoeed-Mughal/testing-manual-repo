"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, CircleDot, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface PipeResult {
  diameterMm: number
  diameterInch: number
  velocityMS: number
  velocityFtS: number
  velocityStatus: "Low" | "Optimal" | "High"
  velocityColor: string
  velocityBgColor: string
}

export function DrainagePipeSizeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [flowRate, setFlowRate] = useState("")
  const [slope, setSlope] = useState("")
  const [material, setMaterial] = useState("pvc")
  const [manningN, setManningN] = useState("0.010")
  const [result, setResult] = useState<PipeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const materialRoughness: Record<string, number> = {
    pvc: 0.010,
    hdpe: 0.012,
    concrete: 0.013,
    "corrugated-metal": 0.024,
    clay: 0.013,
  }

  const calculatePipeSize = () => {
    setError("")
    setResult(null)

    const flowRateNum = Number.parseFloat(flowRate)
    const slopeNum = Number.parseFloat(slope)
    const nValue = Number.parseFloat(manningN)

    // Validation
    if (isNaN(flowRateNum) || flowRateNum <= 0) {
      setError("Please enter a valid flow rate greater than 0")
      return
    }
    if (isNaN(slopeNum) || slopeNum <= 0) {
      setError("Please enter a valid slope greater than 0")
      return
    }
    if (isNaN(nValue) || nValue <= 0) {
      setError("Please enter a valid Manning's coefficient")
      return
    }

    // Convert to metric if imperial
    let flowRateM3S = flowRateNum
    if (unitSystem === "imperial") {
      flowRateM3S = flowRateNum * 0.0283168 // cfs to m³/s
    } else {
      flowRateM3S = flowRateNum / 1000 // L/s to m³/s
    }

    // Manning's formula for circular pipe flowing full
    // Q = (1/n) × A × R^(2/3) × S^(1/2)
    // For circular pipe: A = πD²/4, R = D/4
    // Solving for D: D = ((Q × n) / (0.312 × S^0.5))^(3/8)

    const diameter = Math.pow((flowRateM3S * nValue) / (0.312 * Math.pow(slopeNum, 0.5)), 3 / 8)
    const diameterMm = diameter * 1000
    const diameterInch = diameter * 39.3701

    // Calculate velocity
    const area = Math.PI * Math.pow(diameter, 2) / 4
    const velocityMS = flowRateM3S / area
    const velocityFtS = velocityMS * 3.28084

    // Determine velocity status
    let velocityStatus: "Low" | "Optimal" | "High"
    let velocityColor: string
    let velocityBgColor: string

    if (velocityMS < 0.6) {
      velocityStatus = "Low"
      velocityColor = "text-yellow-600"
      velocityBgColor = "bg-yellow-50 border-yellow-200"
    } else if (velocityMS <= 3.0) {
      velocityStatus = "Optimal"
      velocityColor = "text-green-600"
      velocityBgColor = "bg-green-50 border-green-200"
    } else {
      velocityStatus = "High"
      velocityColor = "text-red-600"
      velocityBgColor = "bg-red-50 border-red-200"
    }

    setResult({
      diameterMm,
      diameterInch,
      velocityMS,
      velocityFtS,
      velocityStatus,
      velocityColor,
      velocityBgColor,
    })
  }

  const handleReset = () => {
    setFlowRate("")
    setSlope("")
    setMaterial("pvc")
    setManningN("0.010")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Recommended Pipe Diameter: ${result.diameterMm.toFixed(0)} mm (${result.diameterInch.toFixed(1)} inches), Velocity: ${result.velocityMS.toFixed(2)} m/s`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Drainage Pipe Size Calculation",
          text: `Recommended Pipe: ${result.diameterMm.toFixed(0)} mm diameter`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setFlowRate("")
    setSlope("")
    setResult(null)
    setError("")
  }

  const handleMaterialChange = (value: string) => {
    setMaterial(value)
    setManningN(materialRoughness[value].toString())
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <CircleDot className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Drainage Pipe Size Calculator</CardTitle>
                    <CardDescription>Calculate optimal pipe diameter for drainage</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Flow Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="flow-rate">Design Flow Rate ({unitSystem === "metric" ? "L/s" : "cfs"})</Label>
                  <Input
                    id="flow-rate"
                    type="number"
                    placeholder={`Enter flow rate in ${unitSystem === "metric" ? "liters/second" : "cubic feet/second"}`}
                    value={flowRate}
                    onChange={(e) => setFlowRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Slope Input */}
                <div className="space-y-2">
                  <Label htmlFor="slope">Pipe Slope ({unitSystem === "metric" ? "m/m" : "ft/ft"})</Label>
                  <Input
                    id="slope"
                    type="number"
                    placeholder="e.g., 0.005"
                    value={slope}
                    onChange={(e) => setSlope(e.target.value)}
                    min="0"
                    step="0.0001"
                  />
                  <p className="text-xs text-muted-foreground">Typical range: 0.001 to 0.01</p>
                </div>

                {/* Material Selection */}
                <div className="space-y-2">
                  <Label htmlFor="material">Pipe Material</Label>
                  <Select value={material} onValueChange={handleMaterialChange}>
                    <SelectTrigger id="material">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pvc">PVC (n = 0.010)</SelectItem>
                      <SelectItem value="hdpe">HDPE (n = 0.012)</SelectItem>
                      <SelectItem value="concrete">Concrete (n = 0.013)</SelectItem>
                      <SelectItem value="corrugated-metal">Corrugated Metal (n = 0.024)</SelectItem>
                      <SelectItem value="clay">Clay (n = 0.013)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Manning's N */}
                <div className="space-y-2">
                  <Label htmlFor="manning-n">{"Manning's Roughness (n)"}</Label>
                  <Input
                    id="manning-n"
                    type="number"
                    placeholder="0.010"
                    value={manningN}
                    onChange={(e) => setManningN(e.target.value)}
                    min="0.001"
                    max="0.050"
                    step="0.001"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePipeSize} className="w-full" size="lg">
                  Calculate Pipe Size
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Recommended Pipe Diameter</p>
                        <p className="text-4xl font-bold text-amber-700">{result.diameterMm.toFixed(0)}</p>
                        <p className="text-sm font-medium text-amber-600">
                          mm ({result.diameterInch.toFixed(1)} inches)
                        </p>
                      </div>
                    </div>

                    <div className={`p-4 rounded-xl border-2 ${result.velocityBgColor} transition-all duration-300`}>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center pb-2 border-b border-current/20">
                          <span className="text-sm font-medium">Flow Velocity</span>
                          <span className={`text-sm font-semibold ${result.velocityColor}`}>
                            {result.velocityStatus}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Velocity:</span>
                          <span className="font-medium">
                            {unitSystem === "metric"
                              ? `${result.velocityMS.toFixed(2)} m/s`
                              : `${result.velocityFtS.toFixed(2)} ft/s`}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground pt-2">
                          {result.velocityStatus === "Low" && "Velocity too low - risk of sediment deposition"}
                          {result.velocityStatus === "Optimal" && "Velocity within optimal range for self-cleaning"}
                          {result.velocityStatus === "High" && "Velocity too high - risk of erosion"}
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 pt-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Velocity Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-800">Minimum (Self-cleaning)</span>
                      <span className="text-yellow-600">0.6 m/s</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-800">Optimal Range</span>
                      <span className="text-green-600">0.6 - 3.0 m/s</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-800">Maximum (Erosion risk)</span>
                      <span className="text-red-600">{"> 3.0 m/s"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">{"Manning's Formula"}</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">Q = (1/n) × A × R²⁄³ × S¹⁄²</p>
                    <p className="text-xs">
                      Q = Flow rate, n = Roughness, A = Area,
                      <br />R = Hydraulic radius, S = Slope
                    </p>
                  </div>
                  <p>
                    This calculator uses Manning's equation to determine the optimal pipe diameter for a given flow rate
                    and slope.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Drainage Pipe Sizing */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Drainage Pipe Sizing?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Drainage pipe sizing is a critical aspect of hydraulic engineering that involves determining the
                  appropriate diameter of pipes to efficiently convey wastewater, stormwater, or other fluids while
                  maintaining adequate flow velocities. Proper pipe sizing ensures that drainage systems function
                  effectively without issues such as sediment buildup, blockages, or pipe erosion, all of which can
                  lead to costly maintenance and system failures.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The sizing process takes into account multiple factors including the design flow rate, pipe slope,
                  material roughness characteristics, and local drainage standards. Engineers use Manning's equation,
                  a well-established empirical formula in open channel flow hydraulics, to calculate the relationship
                  between these variables and determine the optimal pipe diameter that will maintain self-cleaning
                  velocities while preventing excessive wear.
                </p>
              </CardContent>
            </Card>

            {/* How to Use Calculator */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To use this drainage pipe size calculator effectively, start by selecting your preferred unit system
                  - metric (L/s, m/m) or imperial (cfs, ft/ft). Input the design flow rate, which represents the
                  maximum expected flow through the pipe. This value typically comes from hydrological calculations
                  based on rainfall intensity, catchment area, and runoff coefficients for stormwater systems, or from
                  fixture unit calculations for sanitary drainage.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Next, enter the pipe slope - this is the gradient at which the pipe will be installed, expressed as
                  a decimal (e.g., 0.005 for a 0.5% or 1:200 slope). Select the pipe material from the dropdown menu,
                  which automatically populates the Manning's roughness coefficient (n-value). You can manually adjust
                  this value if needed. The calculator will then compute the recommended pipe diameter and flow
                  velocity, providing feedback on whether the velocity falls within the optimal self-cleaning range.
                </p>
              </CardContent>
            </Card>

            {/* Pipe Material Properties */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CircleDot className="h-5 w-5 text-primary" />
                  <CardTitle>Pipe Material Properties</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">PVC (Polyvinyl Chloride)</h4>
                    <p className="text-amber-700 text-sm">
                      PVC pipes have the smoothest interior surface (n = 0.010) and are highly resistant to chemical
                      corrosion. They're lightweight, easy to install, and cost-effective, making them ideal for most
                      residential and light commercial drainage applications. PVC maintains consistent flow
                      characteristics over its lifespan and doesn't rust or corrode.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">HDPE (High-Density Polyethylene)</h4>
                    <p className="text-amber-700 text-sm">
                      HDPE pipes (n = 0.012) offer excellent flexibility and impact resistance, making them suitable
                      for areas with ground movement or freeze-thaw cycles. They're commonly used for stormwater
                      drainage, culverts, and applications requiring resistance to abrasion and chemical attack.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Concrete Pipe</h4>
                    <p className="text-amber-700 text-sm">
                      Concrete drainage pipes (n = 0.013) are extremely durable and can handle high loads, making them
                      ideal for municipal storm sewers and large-scale drainage systems. They're available in larger
                      diameters than plastic pipes and can last 50-100 years with proper installation and maintenance.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Corrugated Metal</h4>
                    <p className="text-amber-700 text-sm">
                      Corrugated metal pipes (n = 0.024) are strong and can span long distances without support. While
                      they have higher roughness values that reduce flow efficiency, they're often used for culverts
                      and highway drainage where structural strength and load-bearing capacity are priorities over
                      hydraulic efficiency.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2 text-sm text-amber-800">
                    <p className="font-semibold">Important Note</p>
                    <p>
                      Pipe size recommendations are indicative. Actual design must comply with hydraulic standards and
                      site conditions. Always consult with a qualified hydraulic engineer or drainage specialist for
                      final design specifications, especially for municipal or large-scale drainage systems.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
