"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Activity,
  Info,
  ChevronDown,
  ChevronUp,
  Heart,
  Dumbbell,
  Flame,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type ActivityLevel = "sedentary" | "light" | "moderate" | "high"

interface FitnessAgeResult {
  fitnessAge: number
  chronologicalAge: number
  difference: number
  category: string
  color: string
  bgColor: string
  cardioScore: number
  strengthScore: number
  flexibilityScore: number
  overallScore: number
}

export function FitnessAgeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState<Gender>("male")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [restingHeartRate, setRestingHeartRate] = useState("")
  const [vo2Max, setVo2Max] = useState("")
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate")

  // Optional inputs
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [pushUps, setPushUps] = useState("")
  const [sitUps, setSitUps] = useState("")
  const [flexibilityScore, setFlexibilityScore] = useState("")

  const [result, setResult] = useState<FitnessAgeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateFitnessAge = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseInt(age)
    if (isNaN(ageNum) || ageNum < 18 || ageNum > 100) {
      setError("Please enter a valid age between 18 and 100")
      return
    }

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number
    if (unitSystem === "metric") {
      heightInCm = Number.parseFloat(heightCm)
      if (isNaN(heightInCm) || heightInCm <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = (feet * 12 + inches) * 2.54
    }

    const rhrNum = Number.parseInt(restingHeartRate)
    if (isNaN(rhrNum) || rhrNum < 30 || rhrNum > 150) {
      setError("Please enter a valid resting heart rate between 30 and 150 bpm")
      return
    }

    const vo2Num = Number.parseFloat(vo2Max)
    if (isNaN(vo2Num) || vo2Num < 10 || vo2Num > 90) {
      setError("Please enter a valid VO2 Max between 10 and 90 ml/kg/min")
      return
    }

    // Convert weight to kg if imperial
    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Calculate BMI
    const heightInM = heightInCm / 100
    const bmi = weightInKg / (heightInM * heightInM)

    // Calculate cardiovascular score (based on RHR and VO2 Max)
    // Lower RHR is better, higher VO2 Max is better
    let cardioScore = 0

    // RHR scoring (0-40 points)
    if (rhrNum < 50) cardioScore += 40
    else if (rhrNum < 60) cardioScore += 35
    else if (rhrNum < 70) cardioScore += 30
    else if (rhrNum < 80) cardioScore += 20
    else if (rhrNum < 90) cardioScore += 10
    else cardioScore += 0

    // VO2 Max scoring (0-60 points) - age and gender adjusted
    const vo2Percentile = getVO2Percentile(vo2Num, ageNum, gender)
    cardioScore += Math.round(vo2Percentile * 0.6)

    // Calculate strength score (0-100) if provided
    let strengthScore = 50 // Default average
    const pushUpsNum = Number.parseInt(pushUps)
    const sitUpsNum = Number.parseInt(sitUps)

    if (!isNaN(pushUpsNum) && pushUpsNum >= 0) {
      const pushUpPercentile = getPushUpPercentile(pushUpsNum, ageNum, gender)
      if (!isNaN(sitUpsNum) && sitUpsNum >= 0) {
        const sitUpPercentile = getSitUpPercentile(sitUpsNum, ageNum, gender)
        strengthScore = Math.round((pushUpPercentile + sitUpPercentile) / 2)
      } else {
        strengthScore = pushUpPercentile
      }
    }

    // Calculate flexibility score (0-100) if provided
    let flexScore = 50 // Default average
    const flexNum = Number.parseInt(flexibilityScore)
    if (!isNaN(flexNum) && flexNum >= 0 && flexNum <= 100) {
      flexScore = flexNum
    }

    // Activity level adjustment
    let activityMultiplier = 1
    switch (activityLevel) {
      case "sedentary":
        activityMultiplier = 1.15
        break
      case "light":
        activityMultiplier = 1.05
        break
      case "moderate":
        activityMultiplier = 1.0
        break
      case "high":
        activityMultiplier = 0.9
        break
    }

    // BMI adjustment
    let bmiAdjustment = 0
    if (bmi < 18.5) bmiAdjustment = 2
    else if (bmi < 25) bmiAdjustment = 0
    else if (bmi < 30) bmiAdjustment = 3
    else bmiAdjustment = 6

    // Calculate overall fitness score (weighted)
    const overallScore = Math.round(cardioScore * 0.5 + strengthScore * 0.3 + flexScore * 0.2)

    // Calculate fitness age
    // Higher score = younger fitness age
    // Base calculation: chronological age adjusted by fitness score deviation from average (50)
    const scoreDeviation = (overallScore - 50) / 50 // -1 to 1
    let fitnessAge = Math.round((ageNum - scoreDeviation * 15) * activityMultiplier + bmiAdjustment)

    // Clamp fitness age to reasonable bounds
    fitnessAge = Math.max(18, Math.min(90, fitnessAge))

    const difference = fitnessAge - ageNum

    let category: string
    let color: string
    let bgColor: string

    if (difference <= -10) {
      category = "Excellent - Much Younger"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (difference <= -5) {
      category = "Very Good - Younger"
      color = "text-emerald-600"
      bgColor = "bg-emerald-50 border-emerald-200"
    } else if (difference <= 0) {
      category = "Good - At or Below Age"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (difference <= 5) {
      category = "Average - Slightly Older"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (difference <= 10) {
      category = "Below Average - Older"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Needs Improvement - Much Older"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      fitnessAge,
      chronologicalAge: ageNum,
      difference,
      category,
      color,
      bgColor,
      cardioScore,
      strengthScore,
      flexibilityScore: flexScore,
      overallScore,
    })
  }

  // Helper functions for percentile calculations
  function getVO2Percentile(vo2: number, age: number, gender: Gender): number {
    // Simplified VO2 Max percentile based on age and gender
    const avgVO2 = gender === "male" ? 45 - (age - 20) * 0.4 : 38 - (age - 20) * 0.35

    const stdDev = 8
    const zScore = (vo2 - avgVO2) / stdDev

    // Convert z-score to percentile (simplified)
    const percentile = 50 + zScore * 34
    return Math.max(0, Math.min(100, percentile))
  }

  function getPushUpPercentile(pushUps: number, age: number, gender: Gender): number {
    // Average push-ups by age and gender
    let avgPushUps: number
    if (gender === "male") {
      if (age < 30) avgPushUps = 25
      else if (age < 40) avgPushUps = 20
      else if (age < 50) avgPushUps = 15
      else if (age < 60) avgPushUps = 12
      else avgPushUps = 10
    } else {
      if (age < 30) avgPushUps = 15
      else if (age < 40) avgPushUps = 12
      else if (age < 50) avgPushUps = 10
      else if (age < 60) avgPushUps = 8
      else avgPushUps = 5
    }

    const deviation = pushUps - avgPushUps
    const percentile = 50 + deviation * 3
    return Math.max(0, Math.min(100, percentile))
  }

  function getSitUpPercentile(sitUps: number, age: number, gender: Gender): number {
    // Average sit-ups by age and gender
    let avgSitUps: number
    if (gender === "male") {
      if (age < 30) avgSitUps = 30
      else if (age < 40) avgSitUps = 25
      else if (age < 50) avgSitUps = 20
      else if (age < 60) avgSitUps = 15
      else avgSitUps = 10
    } else {
      if (age < 30) avgSitUps = 25
      else if (age < 40) avgSitUps = 20
      else if (age < 50) avgSitUps = 15
      else if (age < 60) avgSitUps = 10
      else avgSitUps = 8
    }

    const deviation = sitUps - avgSitUps
    const percentile = 50 + deviation * 2.5
    return Math.max(0, Math.min(100, percentile))
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setRestingHeartRate("")
    setVo2Max("")
    setActivityLevel("moderate")
    setPushUps("")
    setSitUps("")
    setFlexibilityScore("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My Fitness Age is ${result.fitnessAge} years (${result.difference > 0 ? "+" : ""}${result.difference} years vs chronological age of ${result.chronologicalAge})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Fitness Age Result",
          text: `I calculated my Fitness Age using CalcHub! My Fitness Age is ${result.fitnessAge} years (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Fitness Age Calculator</CardTitle>
                    <CardDescription>Estimate your fitness age vs chronological age</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Age and Gender */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age (years)</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="e.g., 35"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      min="18"
                      max="100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender</Label>
                    <Select value={gender} onValueChange={(v) => setGender(v as Gender)}>
                      <SelectTrigger id="gender">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="Feet"
                        value={heightFeet}
                        onChange={(e) => setHeightFeet(e.target.value)}
                        min="0"
                      />
                      <Input
                        type="number"
                        placeholder="Inches"
                        value={heightInches}
                        onChange={(e) => setHeightInches(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                )}

                {/* Resting Heart Rate */}
                <div className="space-y-2">
                  <Label htmlFor="rhr">Resting Heart Rate (bpm)</Label>
                  <Input
                    id="rhr"
                    type="number"
                    placeholder="e.g., 65"
                    value={restingHeartRate}
                    onChange={(e) => setRestingHeartRate(e.target.value)}
                    min="30"
                    max="150"
                  />
                </div>

                {/* VO2 Max */}
                <div className="space-y-2">
                  <Label htmlFor="vo2max">VO2 Max (ml/kg/min)</Label>
                  <Input
                    id="vo2max"
                    type="number"
                    placeholder="e.g., 40"
                    value={vo2Max}
                    onChange={(e) => setVo2Max(e.target.value)}
                    min="10"
                    max="90"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">
                    {"Don't"} know your VO2 Max? Use our VO2 Max Calculator to estimate it.
                  </p>
                </div>

                {/* Activity Level */}
                <div className="space-y-2">
                  <Label htmlFor="activity">Activity Level</Label>
                  <Select value={activityLevel} onValueChange={(v) => setActivityLevel(v as ActivityLevel)}>
                    <SelectTrigger id="activity">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                      <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                      <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                      <SelectItem value="high">High (6-7 days/week)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="advanced" className="text-sm font-medium">
                    Include Strength & Flexibility Tests
                  </Label>
                  <Switch id="advanced" checked={showAdvanced} onCheckedChange={setShowAdvanced} />
                </div>

                {/* Advanced Inputs */}
                {showAdvanced && (
                  <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="pushups">Push-ups (max reps)</Label>
                        <Input
                          id="pushups"
                          type="number"
                          placeholder="e.g., 25"
                          value={pushUps}
                          onChange={(e) => setPushUps(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="situps">Sit-ups (max in 1 min)</Label>
                        <Input
                          id="situps"
                          type="number"
                          placeholder="e.g., 30"
                          value={sitUps}
                          onChange={(e) => setSitUps(e.target.value)}
                          min="0"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="flexibility">Flexibility Score (0-100)</Label>
                      <Input
                        id="flexibility"
                        type="number"
                        placeholder="Self-assessed 0-100"
                        value={flexibilityScore}
                        onChange={(e) => setFlexibilityScore(e.target.value)}
                        min="0"
                        max="100"
                      />
                      <p className="text-xs text-muted-foreground">
                        Rate your flexibility: 0-30 Poor, 31-50 Below Average, 51-70 Average, 71-85 Good, 86-100
                        Excellent
                      </p>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFitnessAge} className="w-full" size="lg">
                  Calculate Fitness Age
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Fitness Age</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.fitnessAge}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        {result.difference > 0 ? "+" : ""}
                        {result.difference} years vs chronological age ({result.chronologicalAge})
                      </p>
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full flex items-center justify-center gap-2 mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Component Scores
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Heart className="h-4 w-4 text-red-500" />
                            <span className="text-sm">Cardiovascular Score</span>
                          </div>
                          <span className="font-semibold">{result.cardioScore}/100</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-red-500 h-2 rounded-full transition-all"
                            style={{ width: `${result.cardioScore}%` }}
                          />
                        </div>

                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center gap-2">
                            <Dumbbell className="h-4 w-4 text-blue-500" />
                            <span className="text-sm">Strength Score</span>
                          </div>
                          <span className="font-semibold">{result.strengthScore}/100</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-blue-500 h-2 rounded-full transition-all"
                            style={{ width: `${result.strengthScore}%` }}
                          />
                        </div>

                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center gap-2">
                            <Flame className="h-4 w-4 text-orange-500" />
                            <span className="text-sm">Flexibility Score</span>
                          </div>
                          <span className="font-semibold">{result.flexibilityScore}/100</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-orange-500 h-2 rounded-full transition-all"
                            style={{ width: `${result.flexibilityScore}%` }}
                          />
                        </div>

                        <div className="mt-4 pt-3 border-t border-current/10">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Overall Fitness Score</span>
                            <span className="font-bold text-lg">{result.overallScore}/100</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fitness Age Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">10+ Years Younger</span>
                      <span className="text-sm text-green-600">Excellent</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                      <span className="font-medium text-emerald-700">5-10 Years Younger</span>
                      <span className="text-sm text-emerald-600">Very Good</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">0-5 Years Younger</span>
                      <span className="text-sm text-blue-600">Good</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">0-5 Years Older</span>
                      <span className="text-sm text-yellow-600">Average</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">5-10 Years Older</span>
                      <span className="text-sm text-orange-600">Below Average</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">10+ Years Older</span>
                      <span className="text-sm text-red-600">Needs Improvement</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Score Weighting</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <div className="flex justify-between">
                      <span>Cardiovascular (RHR + VO2)</span>
                      <span className="font-semibold">50%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Strength (Push-ups + Sit-ups)</span>
                      <span className="font-semibold">30%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Flexibility</span>
                      <span className="font-semibold">20%</span>
                    </div>
                  </div>
                  <p>
                    Cardiovascular fitness is weighted most heavily as it has the strongest correlation with overall
                    health and longevity.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Fitness Age?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Fitness age is a concept that estimates how old your body functions compared to the average person of
                  your chronological age. Unlike your birth age, which increases with time, fitness age can actually
                  decrease with improved physical conditioning. A 50-year-old with excellent cardiovascular fitness,
                  strength, and flexibility might have a fitness age of 35, meaning their body performs like the average
                  35-year-old.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept was popularized by researchers at the Norwegian University of Science and Technology, who
                  developed algorithms based on large population studies. Their research showed that fitness age is a
                  better predictor of longevity than chronological age, making it a powerful motivational tool for
                  improving health.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Key Factors in Fitness Age</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Cardiovascular Fitness</h4>
                    <p className="text-red-700 text-sm">
                      VO2 Max and resting heart rate are the strongest predictors of fitness age. Higher VO2 Max and
                      lower resting heart rate indicate a younger cardiovascular system.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Muscular Strength</h4>
                    <p className="text-blue-700 text-sm">
                      Muscle mass and strength naturally decline with age. Maintaining strength through resistance
                      training can significantly lower your fitness age.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Flexibility & Mobility</h4>
                    <p className="text-orange-700 text-sm">
                      Joint flexibility and range of motion decrease with age. Regular stretching and mobility work
                      helps maintain a younger fitness age.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Body Composition</h4>
                    <p className="text-green-700 text-sm">
                      Maintaining a healthy BMI and body fat percentage is associated with younger fitness age and
                      better overall health outcomes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How to Improve Your Fitness Age</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Increase cardiovascular exercise:</strong> Aim for 150+ minutes of moderate or 75+ minutes
                    of vigorous aerobic activity weekly.
                  </li>
                  <li>
                    <strong>Add strength training:</strong> Include resistance exercises 2-3 times per week targeting
                    all major muscle groups.
                  </li>
                  <li>
                    <strong>Incorporate flexibility work:</strong> Stretch daily and consider yoga or Pilates for
                    improved mobility.
                  </li>
                  <li>
                    <strong>Maintain a healthy weight:</strong> A BMI in the normal range (18.5-24.9) supports a lower
                    fitness age.
                  </li>
                  <li>
                    <strong>Prioritize recovery:</strong> Quality sleep and rest days allow your body to adapt and
                    improve.
                  </li>
                  <li>
                    <strong>Stay consistent:</strong> Regular, sustained exercise over time produces the best results.
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Fitness age estimates are based on standard formulas and population
                  averages. Individual variation exists due to genetics, health conditions, and other factors. This
                  calculator provides a general estimate for educational purposes only. Consult a fitness professional
                  or healthcare provider for personalized evaluation, exercise recommendations, and before starting any
                  new fitness program.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
