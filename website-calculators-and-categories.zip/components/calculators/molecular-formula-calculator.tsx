"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Atom,
  Beaker,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

// Periodic table data with atomic weights
const ELEMENTS: Record<string, number> = {
  H: 1.008,
  He: 4.0026,
  Li: 6.94,
  Be: 9.0122,
  B: 10.81,
  C: 12.011,
  N: 14.007,
  O: 15.999,
  F: 18.998,
  Ne: 20.18,
  Na: 22.99,
  Mg: 24.305,
  Al: 26.982,
  Si: 28.086,
  P: 30.974,
  S: 32.06,
  Cl: 35.45,
  Ar: 39.948,
  K: 39.098,
  Ca: 40.078,
  Sc: 44.956,
  Ti: 47.867,
  V: 50.942,
  Cr: 51.996,
  Mn: 54.938,
  Fe: 55.845,
  Co: 58.933,
  Ni: 58.693,
  Cu: 63.546,
  Zn: 65.38,
  Ga: 69.723,
  Ge: 72.63,
  As: 74.922,
  Se: 78.971,
  Br: 79.904,
  Kr: 83.798,
  Rb: 85.468,
  Sr: 87.62,
  Y: 88.906,
  Zr: 91.224,
  Nb: 92.906,
  Mo: 95.95,
  Tc: 98,
  Ru: 101.07,
  Rh: 102.91,
  Pd: 106.42,
  Ag: 107.87,
  Cd: 112.41,
  In: 114.82,
  Sn: 118.71,
  Sb: 121.76,
  Te: 127.6,
  I: 126.9,
  Xe: 131.29,
  Cs: 132.91,
  Ba: 137.33,
  La: 138.91,
  Ce: 140.12,
  Pr: 140.91,
  Nd: 144.24,
  Pm: 145,
  Sm: 150.36,
  Eu: 151.96,
  Gd: 157.25,
  Tb: 158.93,
  Dy: 162.5,
  Ho: 164.93,
  Er: 167.26,
  Tm: 168.93,
  Yb: 173.05,
  Lu: 174.97,
  Hf: 178.49,
  Ta: 180.95,
  W: 183.84,
  Re: 186.21,
  Os: 190.23,
  Ir: 192.22,
  Pt: 195.08,
  Au: 196.97,
  Hg: 200.59,
  Tl: 204.38,
  Pb: 207.2,
  Bi: 208.98,
  Po: 209,
  At: 210,
  Rn: 222,
  Fr: 223,
  Ra: 226,
  Ac: 227,
  Th: 232.04,
  Pa: 231.04,
  U: 238.03,
  Np: 237,
  Pu: 244,
  Am: 243,
  Cm: 247,
  Bk: 247,
  Cf: 251,
  Es: 252,
  Fm: 257,
  Md: 258,
  No: 259,
  Lr: 262,
  Rf: 267,
  Db: 270,
  Sg: 271,
  Bh: 270,
  Hs: 277,
  Mt: 276,
  Ds: 281,
  Rg: 282,
  Cn: 285,
  Nh: 286,
  Fl: 289,
  Mc: 290,
  Lv: 293,
  Ts: 294,
  Og: 294,
}

interface ParsedElement {
  element: string
  count: number
}

interface Result {
  empiricalFormula: string
  molecularFormula: string
  empiricalMass: number
  molarMass: number
  multiplier: number
  elements: ParsedElement[]
  molecularElements: ParsedElement[]
  isWholeNumber: boolean
}

export function MolecularFormulaCalculator() {
  const [empiricalFormula, setEmpiricalFormula] = useState("")
  const [molarMass, setMolarMass] = useState("")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  // Parse chemical formula into elements and counts
  const parseFormula = (formula: string): { elements: ParsedElement[]; mass: number } | null => {
    const elements: ParsedElement[] = []
    let totalMass = 0

    // Handle parentheses first by expanding them
    let expanded = formula
    const parenRegex = /$$([^()]+)$$(\d*)/g
    let match

    while ((match = parenRegex.exec(formula)) !== null) {
      const inner = match[1]
      const multiplier = match[2] ? Number.parseInt(match[2]) : 1
      let expandedInner = ""

      // Parse inner formula and multiply subscripts
      const innerRegex = /([A-Z][a-z]?)(\d*)/g
      let innerMatch
      while ((innerMatch = innerRegex.exec(inner)) !== null) {
        const elem = innerMatch[1]
        const count = (innerMatch[2] ? Number.parseInt(innerMatch[2]) : 1) * multiplier
        expandedInner += elem + (count > 1 ? count : "")
      }

      expanded = expanded.replace(match[0], expandedInner)
    }

    // Now parse the expanded formula
    const elementRegex = /([A-Z][a-z]?)(\d*)/g
    let elemMatch

    while ((elemMatch = elementRegex.exec(expanded)) !== null) {
      const element = elemMatch[1]
      const count = elemMatch[2] ? Number.parseInt(elemMatch[2]) : 1

      if (!ELEMENTS[element]) {
        return null
      }

      // Check if element already exists
      const existing = elements.find((e) => e.element === element)
      if (existing) {
        existing.count += count
      } else {
        elements.push({ element, count })
      }

      totalMass += ELEMENTS[element] * count
    }

    if (elements.length === 0) {
      return null
    }

    return { elements, mass: totalMass }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (!empiricalFormula.trim()) {
      setError("Please enter an empirical formula")
      return
    }

    const molarMassNum = Number.parseFloat(molarMass)
    if (isNaN(molarMassNum) || molarMassNum <= 0) {
      setError("Please enter a valid molar mass greater than 0")
      return
    }

    const parsed = parseFormula(empiricalFormula.trim())
    if (!parsed) {
      setError("Invalid formula. Please check your input and ensure all element symbols are correct.")
      return
    }

    const { elements, mass: empiricalMass } = parsed

    // Calculate multiplier
    const multiplierRaw = molarMassNum / empiricalMass
    const multiplier = Math.round(multiplierRaw)

    // Check if it's close to a whole number
    const isWholeNumber = Math.abs(multiplierRaw - multiplier) < 0.1

    if (multiplier <= 0) {
      setError("The molar mass appears to be less than the empirical formula mass. Please check your values.")
      return
    }

    // Calculate molecular formula elements
    const molecularElements = elements.map((e) => ({
      element: e.element,
      count: e.count * multiplier,
    }))

    // Build molecular formula string
    const molecularFormula = molecularElements.map((e) => e.element + (e.count > 1 ? e.count : "")).join("")

    setResult({
      empiricalFormula: empiricalFormula.trim(),
      molecularFormula,
      empiricalMass,
      molarMass: molarMassNum,
      multiplier,
      elements,
      molecularElements,
      isWholeNumber,
    })
  }

  const handleReset = () => {
    setEmpiricalFormula("")
    setMolarMass("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Empirical Formula: ${result.empiricalFormula}\nMolecular Formula: ${result.molecularFormula}\nMultiplier (n): ${result.multiplier}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Molecular Formula Calculator Result",
          text: `Empirical: ${result.empiricalFormula} → Molecular: ${result.molecularFormula} (n=${result.multiplier})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const quickExamples = [
    { empirical: "CH2O", molar: "180.16", name: "Glucose" },
    { empirical: "CH2", molar: "56.11", name: "Butene" },
    { empirical: "CH", molar: "78.11", name: "Benzene" },
    { empirical: "NO2", molar: "92.02", name: "N₂O₄" },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Molecular Formula Calculator</CardTitle>
                    <CardDescription>Find molecular formula from empirical formula</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Empirical Formula Input */}
                <div className="space-y-2">
                  <Label htmlFor="empirical">Empirical Formula</Label>
                  <Input
                    id="empirical"
                    type="text"
                    placeholder="e.g., CH2O, NO2, CH"
                    value={empiricalFormula}
                    onChange={(e) => setEmpiricalFormula(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter using element symbols (e.g., CH2O for formaldehyde)
                  </p>
                </div>

                {/* Molar Mass Input */}
                <div className="space-y-2">
                  <Label htmlFor="molar">Molar Mass of Compound (g/mol)</Label>
                  <Input
                    id="molar"
                    type="number"
                    placeholder="e.g., 180.16"
                    value={molarMass}
                    onChange={(e) => setMolarMass(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Quick Examples */}
                <div className="space-y-2">
                  <Label className="text-sm text-muted-foreground">Quick Examples</Label>
                  <div className="flex flex-wrap gap-2">
                    {quickExamples.map((ex) => (
                      <Button
                        key={ex.name}
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEmpiricalFormula(ex.empirical)
                          setMolarMass(ex.molar)
                        }}
                        className="text-xs"
                      >
                        {ex.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps" className="text-sm">
                    Show calculation steps
                  </Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Molecular Formula
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Molecular Formula</p>
                      <p className="text-4xl font-bold text-purple-600 font-mono tracking-wide">
                        {result.molecularFormula}
                      </p>
                      {!result.isWholeNumber && (
                        <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded-lg">
                          <p className="text-xs text-yellow-700 flex items-center justify-center gap-1">
                            <AlertTriangle className="h-3 w-3" />
                            Multiplier is not a whole number. Check your values.
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Summary */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Empirical Mass</p>
                        <p className="text-lg font-semibold text-foreground">{result.empiricalMass.toFixed(3)} g/mol</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Multiplier (n)</p>
                        <p className="text-lg font-semibold text-purple-600">{result.multiplier}</p>
                      </div>
                    </div>

                    {/* Step-by-step */}
                    {showSteps && (
                      <div className="p-3 bg-white rounded-lg border space-y-2 text-sm">
                        <p className="font-medium text-foreground">Calculation Steps:</p>
                        <div className="space-y-1 text-muted-foreground">
                          <p>
                            1. Empirical formula:{" "}
                            <span className="font-mono text-foreground">{result.empiricalFormula}</span>
                          </p>
                          <p>
                            2. Empirical formula mass (M<sub>emp</sub>):
                          </p>
                          <div className="pl-4 font-mono text-xs">
                            {result.elements.map((e, i) => (
                              <span key={e.element}>
                                {i > 0 && " + "}
                                {e.count} × {ELEMENTS[e.element].toFixed(3)} ({e.element})
                              </span>
                            ))}
                            <span>
                              {" "}
                              = <strong>{result.empiricalMass.toFixed(3)} g/mol</strong>
                            </span>
                          </div>
                          <p>3. Calculate multiplier (n):</p>
                          <div className="pl-4 font-mono text-xs">
                            n = Molar mass ÷ M<sub>emp</sub> = {result.molarMass} ÷ {result.empiricalMass.toFixed(3)} ={" "}
                            <strong>
                              {(result.molarMass / result.empiricalMass).toFixed(2)} ≈ {result.multiplier}
                            </strong>
                          </div>
                          <p>4. Multiply subscripts by n = {result.multiplier}:</p>
                          <div className="pl-4 font-mono text-xs">
                            {result.elements.map((e, i) => (
                              <span key={e.element}>
                                {i > 0 && ", "}
                                {e.element}: {e.count} × {result.multiplier} = {e.count * result.multiplier}
                              </span>
                            ))}
                          </div>
                          <p>
                            5. Molecular formula:{" "}
                            <span className="font-mono font-bold text-purple-600">{result.molecularFormula}</span>
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula Reference</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">
                      n = M<sub>compound</sub> ÷ M<sub>empirical</sub>
                    </p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>n</strong> = multiplier (whole number)
                    </p>
                    <p>
                      <strong>
                        M<sub>compound</sub>
                      </strong>{" "}
                      = molar mass of compound
                    </p>
                    <p>
                      <strong>
                        M<sub>empirical</sub>
                      </strong>{" "}
                      = molar mass of empirical formula
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Empirical vs Molecular</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <p className="font-medium text-blue-800 text-sm">Empirical Formula</p>
                      <p className="text-blue-700 text-xs mt-1">Simplest whole-number ratio of atoms (e.g., CH₂O)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <p className="font-medium text-purple-800 text-sm">Molecular Formula</p>
                      <p className="text-purple-700 text-xs mt-1">
                        Actual number of atoms in a molecule (e.g., C₆H₁₂O₆)
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium">Disclaimer</p>
                      <p className="mt-1 text-amber-700">
                        Results assume accurate empirical formula and molar mass measurements. Always verify with
                        experimental data.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Molecular Formula?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A molecular formula shows the exact number of each type of atom present in a single molecule of a
                  compound. Unlike the empirical formula, which represents the simplest whole-number ratio of atoms, the
                  molecular formula reflects the true composition of the molecule. For example, glucose has the
                  empirical formula CH₂O, but its molecular formula is C₆H₁₂O₆, indicating that each glucose molecule
                  contains exactly 6 carbon atoms, 12 hydrogen atoms, and 6 oxygen atoms.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The molecular formula is always a whole-number multiple of the empirical formula. This relationship is
                  expressed as: Molecular Formula = (Empirical Formula) × n, where n is a positive integer called the
                  multiplier. Understanding this relationship is crucial for determining the true structure and
                  properties of chemical compounds.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>How to Determine Molecular Formula</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To find the molecular formula from an empirical formula, you need two pieces of information: the
                  empirical formula itself and the molar mass of the actual compound (usually determined experimentally
                  through techniques like mass spectrometry).
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Step 1: Calculate Empirical Formula Mass</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Add up the atomic masses of all atoms in the empirical formula. For CH₂O: 12.01 + (2 × 1.008) +
                      16.00 = 30.03 g/mol
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Step 2: Calculate the Multiplier (n)</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Divide the compound's molar mass by the empirical formula mass: n = 180.16 ÷ 30.03 = 6
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">Step 3: Multiply Subscripts</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Multiply each subscript in the empirical formula by n: (CH₂O) × 6 = C₆H₁₂O₆
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Common Examples</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 pr-4 font-medium">Compound</th>
                        <th className="text-left py-2 px-4 font-medium">Empirical</th>
                        <th className="text-left py-2 px-4 font-medium">Molecular</th>
                        <th className="text-left py-2 pl-4 font-medium">n</th>
                      </tr>
                    </thead>
                    <tbody className="text-muted-foreground">
                      <tr className="border-b">
                        <td className="py-2 pr-4">Glucose</td>
                        <td className="py-2 px-4 font-mono">CH₂O</td>
                        <td className="py-2 px-4 font-mono">C₆H₁₂O₆</td>
                        <td className="py-2 pl-4">6</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4">Benzene</td>
                        <td className="py-2 px-4 font-mono">CH</td>
                        <td className="py-2 px-4 font-mono">C₆H₆</td>
                        <td className="py-2 pl-4">6</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4">Acetic Acid</td>
                        <td className="py-2 px-4 font-mono">CH₂O</td>
                        <td className="py-2 px-4 font-mono">C₂H₄O₂</td>
                        <td className="py-2 pl-4">2</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4">Hydrogen Peroxide</td>
                        <td className="py-2 px-4 font-mono">HO</td>
                        <td className="py-2 px-4 font-mono">H₂O₂</td>
                        <td className="py-2 pl-4">2</td>
                      </tr>
                      <tr>
                        <td className="py-2 pr-4">Ethylene</td>
                        <td className="py-2 px-4 font-mono">CH₂</td>
                        <td className="py-2 px-4 font-mono">C₂H₄</td>
                        <td className="py-2 pl-4">2</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Determining molecular formulas is essential in many areas of chemistry and related sciences:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Drug Development:</strong> Pharmaceutical chemists must know exact molecular formulas to
                    synthesize medications with precise dosages and predict drug interactions.
                  </li>
                  <li>
                    <strong>Material Science:</strong> Understanding molecular composition helps design polymers,
                    ceramics, and other materials with specific properties.
                  </li>
                  <li>
                    <strong>Forensic Chemistry:</strong> Identifying unknown substances often requires determining their
                    molecular formulas from mass spectrometry data.
                  </li>
                  <li>
                    <strong>Biochemistry:</strong> Studying metabolic pathways and enzyme reactions requires knowledge
                    of the molecular formulas of substrates and products.
                  </li>
                  <li>
                    <strong>Environmental Science:</strong> Analyzing pollutants and their breakdown products depends on
                    accurate molecular formula determination.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
