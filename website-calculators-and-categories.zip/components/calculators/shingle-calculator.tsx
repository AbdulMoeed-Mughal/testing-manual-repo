"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Home,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface ShingleResult {
  roofArea: number
  effectiveCoverage: number
  shinglesNeeded: number
  shinglesWithWaste: number
  totalShingles: number
}

export function ShingleCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("imperial")
  const [roofLength, setRoofLength] = useState("")
  const [roofWidth, setRoofWidth] = useState("")
  const [numberOfSides, setNumberOfSides] = useState("2")
  const [shingleLength, setShingleLength] = useState(unitSystem === "metric" ? "1.0" : "3")
  const [shingleWidth, setShingleWidth] = useState(unitSystem === "metric" ? "0.33" : "1")
  const [exposure, setExposure] = useState(unitSystem === "metric" ? "0.14" : "5.625")
  const [wastePercentage, setWastePercentage] = useState("10")
  const [result, setResult] = useState<ShingleResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateShingles = () => {
    setError("")
    setResult(null)

    const length = Number.parseFloat(roofLength)
    const width = Number.parseFloat(roofWidth)
    const sides = Number.parseInt(numberOfSides)
    const sLength = Number.parseFloat(shingleLength)
    const sWidth = Number.parseFloat(shingleWidth)
    const exp = Number.parseFloat(exposure)
    const waste = Number.parseFloat(wastePercentage)

    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid roof length greater than 0")
      return
    }
    if (isNaN(width) || width <= 0) {
      setError("Please enter a valid roof width greater than 0")
      return
    }
    if (isNaN(sides) || sides <= 0) {
      setError("Please enter a valid number of roof sides greater than 0")
      return
    }
    if (isNaN(sLength) || sLength <= 0) {
      setError("Please enter a valid shingle length greater than 0")
      return
    }
    if (isNaN(sWidth) || sWidth <= 0) {
      setError("Please enter a valid shingle width greater than 0")
      return
    }
    if (isNaN(exp) || exp <= 0) {
      setError("Please enter a valid shingle exposure greater than 0")
      return
    }
    if (exp > sLength) {
      setError("Shingle exposure cannot be greater than shingle length")
      return
    }
    if (isNaN(waste) || waste < 0) {
      setError("Please enter a valid waste percentage (0 or greater)")
      return
    }

    // Calculate roof area
    const roofArea = length * width * sides

    // Effective shingle coverage area (exposure × width)
    const effectiveCoverage = exp * sWidth

    // Number of shingles needed (without waste)
    const shinglesNeeded = roofArea / effectiveCoverage

    // Total shingles with waste
    const shinglesWithWaste = shinglesNeeded * (waste / 100)
    const totalShingles = Math.ceil(shinglesNeeded + shinglesWithWaste)

    setResult({
      roofArea,
      effectiveCoverage,
      shinglesNeeded,
      shinglesWithWaste,
      totalShingles,
    })
  }

  const handleReset = () => {
    setRoofLength("")
    setRoofWidth("")
    setNumberOfSides("2")
    setShingleLength(unitSystem === "metric" ? "1.0" : "3")
    setShingleWidth(unitSystem === "metric" ? "0.33" : "1")
    setExposure(unitSystem === "metric" ? "0.14" : "5.625")
    setWastePercentage("10")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const areaUnit = unitSystem === "metric" ? "m²" : "ft²"
      await navigator.clipboard.writeText(
        `Shingle Calculator Results:\nRoof Area: ${result.roofArea.toFixed(2)} ${areaUnit}\nShingles Needed: ${result.totalShingles} shingles (including ${wastePercentage}% waste)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const areaUnit = unitSystem === "metric" ? "m²" : "ft²"
      try {
        await navigator.share({
          title: "Shingle Calculator Results",
          text: `I calculated my roofing shingles using CalcHub! Roof Area: ${result.roofArea.toFixed(2)} ${areaUnit}, Shingles Needed: ${result.totalShingles}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    const newSystem = unitSystem === "metric" ? "imperial" : "metric"
    setUnitSystem(newSystem)
    setRoofLength("")
    setRoofWidth("")
    // Set default shingle dimensions based on unit system
    if (newSystem === "metric") {
      setShingleLength("1.0")
      setShingleWidth("0.33")
      setExposure("0.14")
    } else {
      setShingleLength("3")
      setShingleWidth("1")
      setExposure("5.625")
    }
    setResult(null)
    setError("")
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"
  const areaUnit = unitSystem === "metric" ? "m²" : "ft²"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Shingle Calculator</CardTitle>
                    <CardDescription>Calculate roofing shingles needed</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Roof Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="roofLength">Roof Length ({lengthUnit})</Label>
                    <Input
                      id="roofLength"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "10" : "30"}`}
                      value={roofLength}
                      onChange={(e) => setRoofLength(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="roofWidth">Roof Width ({lengthUnit})</Label>
                    <Input
                      id="roofWidth"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "5" : "15"}`}
                      value={roofWidth}
                      onChange={(e) => setRoofWidth(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Number of Sides */}
                <div className="space-y-2">
                  <Label htmlFor="numberOfSides">Number of Roof Sides/Slopes</Label>
                  <Input
                    id="numberOfSides"
                    type="number"
                    placeholder="e.g., 2"
                    value={numberOfSides}
                    onChange={(e) => setNumberOfSides(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Shingle Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="shingleLength">Shingle Length ({lengthUnit})</Label>
                    <Input
                      id="shingleLength"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "1.0" : "3"}`}
                      value={shingleLength}
                      onChange={(e) => setShingleLength(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="shingleWidth">Shingle Width ({lengthUnit})</Label>
                    <Input
                      id="shingleWidth"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "0.33" : "1"}`}
                      value={shingleWidth}
                      onChange={(e) => setShingleWidth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Exposure / Overlap */}
                <div className="space-y-2">
                  <Label htmlFor="exposure">Shingle Exposure ({unitSystem === "metric" ? "m" : "inches"})</Label>
                  <Input
                    id="exposure"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "metric" ? "0.14" : "5.625"}`}
                    value={exposure}
                    onChange={(e) => setExposure(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                  <p className="text-xs text-muted-foreground">The visible portion of the shingle after overlap</p>
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="wastePercentage">Waste Allowance (%)</Label>
                  <Input
                    id="wastePercentage"
                    type="number"
                    placeholder="e.g., 10"
                    value={wastePercentage}
                    onChange={(e) => setWastePercentage(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateShingles} className="w-full" size="lg">
                  Calculate Shingles
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Shingles Needed</p>
                      <p className="text-5xl font-bold text-amber-600 mb-2">{result.totalShingles.toLocaleString()}</p>
                      <p className="text-sm text-muted-foreground">
                        Roof Area: {result.roofArea.toFixed(2)} {areaUnit}
                      </p>
                    </div>

                    {/* Expandable Steps */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="flex items-center justify-between w-full text-sm font-medium text-amber-700 hover:text-amber-800"
                      >
                        <span>Calculation Breakdown</span>
                        {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                      {showSteps && (
                        <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Roof Area:</span>
                            <span className="font-mono">
                              {roofLength} × {roofWidth} × {numberOfSides} = {result.roofArea.toFixed(2)} {areaUnit}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Effective Coverage:</span>
                            <span className="font-mono">
                              {exposure} × {shingleWidth} = {result.effectiveCoverage.toFixed(4)} {areaUnit}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Shingles (no waste):</span>
                            <span className="font-mono">{result.shinglesNeeded.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Waste ({wastePercentage}%):</span>
                            <span className="font-mono">+{result.shinglesWithWaste.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between font-semibold border-t pt-2">
                            <span>Total Shingles:</span>
                            <span className="font-mono">{result.totalShingles}</span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Shingle Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Roof Area</p>
                    <p className="font-mono text-sm font-semibold">Area = Length × Width × Sides</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Effective Coverage</p>
                    <p className="font-mono text-sm font-semibold">Coverage = Exposure × Shingle Width</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Shingles Required</p>
                    <p className="font-mono text-sm font-semibold">Shingles = Area ÷ Coverage</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">With Waste</p>
                    <p className="font-mono text-sm font-semibold">Total = Shingles × (1 + Waste%)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Shingle Sizes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>3-Tab Shingle</span>
                      <span className="text-muted-foreground">36" × 12" (5" exposure)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Architectural</span>
                      <span className="text-muted-foreground">36" × 13" (5.625" exposure)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Premium Designer</span>
                      <span className="text-muted-foreground">36" × 14" (5-6" exposure)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recommended Waste %</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-green-50 border border-green-200 rounded">
                      <span className="text-green-700">Simple Gable Roof</span>
                      <span className="text-green-600 font-medium">5-7%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-yellow-50 border border-yellow-200 rounded">
                      <span className="text-yellow-700">Hip Roof</span>
                      <span className="text-yellow-600 font-medium">10-12%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-orange-50 border border-orange-200 rounded">
                      <span className="text-orange-700">Complex/Cut-up Roof</span>
                      <span className="text-orange-600 font-medium">15-20%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-yellow-800">
                <p className="font-semibold mb-1">Disclaimer</p>
                <p>
                  Results are estimates. Actual shingle requirements may vary due to cutting, roof design, dormers,
                  valleys, and installation practices. Always consult a professional roofer for accurate measurements.
                </p>
              </div>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Roofing Shingles</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Roofing shingles are one of the most popular roofing materials used in residential construction. They
                  provide excellent protection against weather elements while offering an attractive appearance.
                  Understanding how to calculate the number of shingles needed for a roofing project is essential for
                  accurate material estimation and budgeting.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key to accurate shingle calculation lies in understanding the concept of "exposure" - the visible
                  portion of each shingle after installation. Since shingles overlap one another, the effective coverage
                  area of each shingle is less than its actual dimensions. This overlap is crucial for waterproofing the
                  roof.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Home className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Roofing Shingles</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">3-Tab Shingles</h4>
                    <p className="text-sm text-muted-foreground">
                      The most economical option with a flat appearance and three tabs per strip. Typical dimensions are
                      36" × 12" with a 5" exposure. They have a lifespan of 15-20 years.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Architectural Shingles</h4>
                    <p className="text-sm text-muted-foreground">
                      Also called dimensional or laminate shingles, they have multiple layers creating a textured look.
                      Standard size is 36" × 13" with 5.625" exposure. Lifespan of 25-30 years.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Premium Designer Shingles</h4>
                    <p className="text-sm text-muted-foreground">
                      High-end shingles that mimic the look of slate, wood shakes, or tile. They offer superior
                      aesthetics and durability with lifespans of 30-50 years.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Impact-Resistant Shingles</h4>
                    <p className="text-sm text-muted-foreground">
                      Specially designed to withstand hail and high winds. They meet Class 4 impact rating standards and
                      may qualify for insurance discounts in storm-prone areas.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Shingle Quantity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence the number of shingles required for a roofing project beyond basic roof
                  area:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Roof Pitch:</strong> Steeper roofs have greater surface area and may require more shingles
                    than the footprint suggests.
                  </li>
                  <li>
                    <strong>Roof Complexity:</strong> Dormers, valleys, hips, and ridges increase waste due to cutting
                    and fitting.
                  </li>
                  <li>
                    <strong>Starter Strips:</strong> The first row of shingles requires additional material for proper
                    installation.
                  </li>
                  <li>
                    <strong>Ridge Caps:</strong> Special shingles or cut shingles are needed to cover roof peaks.
                  </li>
                  <li>
                    <strong>Flashing Areas:</strong> Around chimneys, vents, and skylights require careful cutting.
                  </li>
                  <li>
                    <strong>Installer Experience:</strong> Less experienced installers may generate more waste.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
