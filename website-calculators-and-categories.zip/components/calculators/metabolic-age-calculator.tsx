"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Activity,
  Info,
  AlertTriangle,
  Heart,
  Zap,
  TrendingUp,
  TrendingDown,
  Minus,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type Formula = "mifflin" | "harris"

interface MetabolicAgeResult {
  bmr: number
  metabolicAge: number
  actualAge: number
  difference: number
  status: "younger" | "equal" | "older"
  color: string
  bgColor: string
}

// Average BMR values by age and gender (approximations based on population data)
const averageBMRByAge = {
  male: [
    { age: 18, bmr: 1800 },
    { age: 25, bmr: 1750 },
    { age: 30, bmr: 1700 },
    { age: 35, bmr: 1650 },
    { age: 40, bmr: 1600 },
    { age: 45, bmr: 1550 },
    { age: 50, bmr: 1500 },
    { age: 55, bmr: 1450 },
    { age: 60, bmr: 1400 },
    { age: 65, bmr: 1350 },
    { age: 70, bmr: 1300 },
    { age: 75, bmr: 1250 },
    { age: 80, bmr: 1200 },
  ],
  female: [
    { age: 18, bmr: 1500 },
    { age: 25, bmr: 1450 },
    { age: 30, bmr: 1400 },
    { age: 35, bmr: 1375 },
    { age: 40, bmr: 1350 },
    { age: 45, bmr: 1325 },
    { age: 50, bmr: 1300 },
    { age: 55, bmr: 1275 },
    { age: 60, bmr: 1250 },
    { age: 65, bmr: 1225 },
    { age: 70, bmr: 1200 },
    { age: 75, bmr: 1175 },
    { age: 80, bmr: 1150 },
  ],
}

export function MetabolicAgeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender | "">("")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [formula, setFormula] = useState<Formula>("mifflin")
  const [result, setResult] = useState<MetabolicAgeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateMetabolicAge = () => {
    setError("")
    setResult(null)

    // Validate inputs
    const ageNum = Number.parseInt(age)
    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (!gender) {
      setError("Please select your gender")
      return
    }

    const weightNum = Number.parseFloat(weight)
    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number

    if (unitSystem === "metric") {
      const heightCmNum = Number.parseFloat(heightCm)
      if (isNaN(heightCmNum) || heightCmNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = heightCmNum
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      const totalInches = feet * 12 + inches
      heightInCm = totalInches * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    // Calculate BMR
    let bmr: number

    if (formula === "mifflin") {
      // Mifflin-St Jeor Equation
      if (gender === "male") {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
      } else {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
      }
    } else {
      // Harris-Benedict Equation
      if (gender === "male") {
        bmr = 88.362 + 13.397 * weightInKg + 4.799 * heightInCm - 5.677 * ageNum
      } else {
        bmr = 447.593 + 9.247 * weightInKg + 3.098 * heightInCm - 4.33 * ageNum
      }
    }

    bmr = Math.round(bmr)

    // Find metabolic age by comparing BMR with average values
    const averages = averageBMRByAge[gender]
    let metabolicAge = ageNum

    // Find the age group with the closest BMR
    let closestDiff = Number.POSITIVE_INFINITY
    for (const avg of averages) {
      const diff = Math.abs(avg.bmr - bmr)
      if (diff < closestDiff) {
        closestDiff = diff
        metabolicAge = avg.age
      }
    }

    // Interpolate for more precise metabolic age
    for (let i = 0; i < averages.length - 1; i++) {
      if (
        (bmr >= averages[i + 1].bmr && bmr <= averages[i].bmr) ||
        (bmr <= averages[i + 1].bmr && bmr >= averages[i].bmr)
      ) {
        const ratio = (bmr - averages[i].bmr) / (averages[i + 1].bmr - averages[i].bmr)
        metabolicAge = Math.round(averages[i].age + ratio * (averages[i + 1].age - averages[i].age))
        break
      }
    }

    // Handle edge cases
    if (bmr > averages[0].bmr) {
      metabolicAge = Math.max(15, averages[0].age - Math.round((bmr - averages[0].bmr) / 50))
    } else if (bmr < averages[averages.length - 1].bmr) {
      metabolicAge = Math.min(
        90,
        averages[averages.length - 1].age + Math.round((averages[averages.length - 1].bmr - bmr) / 50),
      )
    }

    const difference = metabolicAge - ageNum
    let status: "younger" | "equal" | "older"
    let color: string
    let bgColor: string

    if (difference < -2) {
      status = "younger"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (difference > 2) {
      status = "older"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else {
      status = "equal"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    }

    setResult({
      bmr,
      metabolicAge,
      actualAge: ageNum,
      difference,
      status,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setAge("")
    setGender("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setFormula("mifflin")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My Metabolic Age is ${result.metabolicAge} years (Actual age: ${result.actualAge}, BMR: ${result.bmr} kcal/day)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Metabolic Age Result",
          text: `I calculated my Metabolic Age using CalcHub! My metabolic age is ${result.metabolicAge} years (Actual age: ${result.actualAge})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Metabolic Age Calculator</CardTitle>
                    <CardDescription>Estimate your metabolic age based on BMR</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={gender} onValueChange={(value) => setGender(value as Gender)}>
                    <SelectTrigger id="gender">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Input
                          type="number"
                          placeholder="Feet"
                          value={heightFeet}
                          onChange={(e) => setHeightFeet(e.target.value)}
                          min="0"
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          placeholder="Inches"
                          value={heightInches}
                          onChange={(e) => setHeightInches(e.target.value)}
                          min="0"
                          max="11"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Formula Selection */}
                <div className="space-y-2">
                  <Label htmlFor="formula">BMR Formula</Label>
                  <Select value={formula} onValueChange={(value) => setFormula(value as Formula)}>
                    <SelectTrigger id="formula">
                      <SelectValue placeholder="Select formula" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mifflin">Mifflin-St Jeor (Recommended)</SelectItem>
                      <SelectItem value="harris">Harris-Benedict</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMetabolicAge} className="w-full" size="lg">
                  Calculate Metabolic Age
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Metabolic Age</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.metabolicAge}</p>
                      <div className="flex items-center justify-center gap-2 mb-2">
                        {result.status === "younger" && <TrendingDown className="h-5 w-5 text-green-600" />}
                        {result.status === "older" && <TrendingUp className="h-5 w-5 text-red-600" />}
                        {result.status === "equal" && <Minus className="h-5 w-5 text-blue-600" />}
                        <p className={`text-lg font-semibold ${result.color}`}>
                          {result.status === "younger" &&
                            `${Math.abs(result.difference)} years younger than actual age`}
                          {result.status === "older" && `${Math.abs(result.difference)} years older than actual age`}
                          {result.status === "equal" && "Same as actual age"}
                        </p>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mt-4 p-3 bg-white/50 rounded-lg">
                        <div>
                          <p className="text-xs text-muted-foreground">Actual Age</p>
                          <p className="font-semibold">{result.actualAge} years</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Your BMR</p>
                          <p className="font-semibold">{result.bmr} kcal/day</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">What Does It Mean?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex items-center gap-2">
                        <TrendingDown className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-700">Younger</span>
                      </div>
                      <span className="text-sm text-green-600">Higher BMR, efficient metabolism</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex items-center gap-2">
                        <Minus className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-blue-700">Equal</span>
                      </div>
                      <span className="text-sm text-blue-600">Average for your age</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-red-600" />
                        <span className="font-medium text-red-700">Older</span>
                      </div>
                      <span className="text-sm text-red-600">Lower BMR, slower metabolism</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">BMR Formulas</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Mifflin-St Jeor (Recommended)</p>
                    <p className="font-mono text-xs">Male: (10 × kg) + (6.25 × cm) − (5 × age) + 5</p>
                    <p className="font-mono text-xs">Female: (10 × kg) + (6.25 × cm) − (5 × age) − 161</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Harris-Benedict</p>
                    <p className="font-mono text-xs">Male: 88.36 + (13.4 × kg) + (4.8 × cm) − (5.7 × age)</p>
                    <p className="font-mono text-xs">Female: 447.6 + (9.2 × kg) + (3.1 × cm) − (4.3 × age)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Zap className="h-4 w-4 text-yellow-500" />
                    Tips to Improve Metabolic Age
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Build muscle through strength training</p>
                  <p>• Stay physically active daily</p>
                  <p>• Get adequate quality sleep (7-9 hours)</p>
                  <p>• Eat protein-rich foods</p>
                  <p>• Stay hydrated</p>
                  <p>• Manage stress levels</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Metabolic Age?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Metabolic age is a concept that compares your Basal Metabolic Rate (BMR) to the average BMR of people
                  at different chronological ages. Your BMR represents the number of calories your body burns at rest to
                  maintain vital functions like breathing, circulation, and cell production. By comparing your BMR to
                  population averages, we can estimate whether your metabolism functions like someone younger, older, or
                  the same age as you.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A metabolic age lower than your actual age suggests a more efficient metabolism, often associated with
                  higher muscle mass and better overall fitness. Conversely, a higher metabolic age may indicate a
                  slower metabolism, which can be influenced by factors such as body composition, activity level, and
                  lifestyle habits.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Basal Metabolic Rate (BMR)</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Basal Metabolic Rate is the amount of energy your body expends while at complete rest. This includes
                  energy used for breathing, blood circulation, controlling body temperature, cell growth, brain and
                  nerve function, and contraction of muscles. BMR typically accounts for about 60-75% of your total
                  daily energy expenditure.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Several factors influence BMR, including age, gender, body composition (muscle vs. fat), genetics,
                  hormones, and overall health. Generally, BMR decreases with age as muscle mass tends to decline. Men
                  typically have higher BMRs than women due to greater muscle mass. Understanding your BMR can help you
                  make informed decisions about nutrition and exercise.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Factors That Affect Metabolic Age</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Factors That Lower Metabolic Age</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Higher muscle mass</li>
                      <li>• Regular physical activity</li>
                      <li>• Strength training</li>
                      <li>• Adequate protein intake</li>
                      <li>• Quality sleep</li>
                      <li>• Proper hydration</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Factors That Raise Metabolic Age</h4>
                    <ul className="text-red-700 text-sm space-y-1">
                      <li>• Sedentary lifestyle</li>
                      <li>• Loss of muscle mass</li>
                      <li>• Poor sleep quality</li>
                      <li>• Chronic stress</li>
                      <li>• Restrictive dieting</li>
                      <li>• Hormonal imbalances</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  Metabolic age is an estimate based on population averages and should not be considered a medical
                  diagnosis. Individual metabolism varies significantly based on genetics, health conditions,
                  medications, and other factors not captured in these calculations. For personalized health advice,
                  please consult with a healthcare professional or registered dietitian. This calculator is intended for
                  educational purposes only.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
