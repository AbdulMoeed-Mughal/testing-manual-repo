"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Scale,
  Info,
  AlertTriangle,
  Users,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { CurrencySelector } from "@/components/ui/currency-selector"
import { formatCurrency, type Currency, currencySymbols } from "@/lib/currency"

type LegalFramework = "islamic" | "equal"

interface Heir {
  id: string
  relationship: string
  count: number
  gender: "male" | "female"
}

interface HeirShare {
  relationship: string
  count: number
  sharePerPerson: number
  totalShare: number
  percentage: number
}

interface InheritanceResult {
  netEstate: number
  totalDistributed: number
  shares: HeirShare[]
  remainingEstate: number
}

const heirTypes = [
  { value: "spouse-wife", label: "Wife", gender: "female" as const },
  { value: "spouse-husband", label: "Husband", gender: "male" as const },
  { value: "son", label: "Son", gender: "male" as const },
  { value: "daughter", label: "Daughter", gender: "female" as const },
  { value: "father", label: "Father", gender: "male" as const },
  { value: "mother", label: "Mother", gender: "female" as const },
  { value: "brother-full", label: "Full Brother", gender: "male" as const },
  { value: "sister-full", label: "Full Sister", gender: "female" as const },
  { value: "grandfather", label: "Grandfather", gender: "male" as const },
  { value: "grandmother", label: "Grandmother", gender: "female" as const },
]

export function InheritanceShareCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [totalEstate, setTotalEstate] = useState("")
  const [debts, setDebts] = useState("")
  const [funeralExpenses, setFuneralExpenses] = useState("")
  const [bequests, setBequests] = useState("")
  const [legalFramework, setLegalFramework] = useState<LegalFramework>("islamic")
  const [heirs, setHeirs] = useState<Heir[]>([
    { id: "1", relationship: "spouse-wife", count: 1, gender: "female" },
    { id: "2", relationship: "son", count: 2, gender: "male" },
  ])
  const [result, setResult] = useState<InheritanceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showBreakdown, setShowBreakdown] = useState(false)

  const addHeir = () => {
    const newId = (Math.max(...heirs.map((h) => Number.parseInt(h.id)), 0) + 1).toString()
    setHeirs([...heirs, { id: newId, relationship: "son", count: 1, gender: "male" }])
  }

  const removeHeir = (id: string) => {
    if (heirs.length > 1) {
      setHeirs(heirs.filter((h) => h.id !== id))
    }
  }

  const updateHeir = (id: string, field: keyof Heir, value: string | number) => {
    setHeirs(
      heirs.map((h) => {
        if (h.id === id) {
          if (field === "relationship") {
            const heirType = heirTypes.find((t) => t.value === value)
            return { ...h, relationship: value as string, gender: heirType?.gender || "male" }
          }
          return { ...h, [field]: value }
        }
        return h
      }),
    )
  }

  const calculateInheritance = () => {
    setError("")
    setResult(null)

    const estate = Number.parseFloat(totalEstate)
    if (isNaN(estate) || estate <= 0) {
      setError("Please enter a valid total estate value greater than 0")
      return
    }

    const debtAmount = Number.parseFloat(debts) || 0
    const funeralAmount = Number.parseFloat(funeralExpenses) || 0
    const bequestAmount = Number.parseFloat(bequests) || 0

    if (debtAmount < 0 || funeralAmount < 0 || bequestAmount < 0) {
      setError("Deductions cannot be negative")
      return
    }

    // Calculate net estate
    const netEstate = estate - debtAmount - funeralAmount - bequestAmount

    if (netEstate <= 0) {
      setError("Net estate must be greater than 0 after deductions")
      return
    }

    // Check if bequests exceed 1/3 (Islamic law restriction)
    if (legalFramework === "islamic" && bequestAmount > estate / 3) {
      setError("In Islamic law, bequests cannot exceed 1/3 of the total estate")
      return
    }

    let shares: HeirShare[] = []

    if (legalFramework === "equal") {
      // Equal distribution among all heirs
      const totalHeirs = heirs.reduce((sum, h) => sum + h.count, 0)
      const sharePerPerson = netEstate / totalHeirs

      shares = heirs.map((heir) => ({
        relationship: heirTypes.find((t) => t.value === heir.relationship)?.label || heir.relationship,
        count: heir.count,
        sharePerPerson: sharePerPerson,
        totalShare: sharePerPerson * heir.count,
        percentage: (heir.count / totalHeirs) * 100,
      }))
    } else {
      // Islamic inheritance calculation
      shares = calculateIslamicShares(netEstate, heirs)
    }

    const totalDistributed = shares.reduce((sum, s) => sum + s.totalShare, 0)

    setResult({
      netEstate,
      totalDistributed,
      shares,
      remainingEstate: netEstate - totalDistributed,
    })
  }

  const calculateIslamicShares = (netEstate: number, heirs: Heir[]): HeirShare[] => {
    const shares: HeirShare[] = []
    let remainingEstate = netEstate

    // Group heirs by relationship
    const heirGroups = heirs.reduce(
      (acc, heir) => {
        if (!acc[heir.relationship]) {
          acc[heir.relationship] = { count: 0, gender: heir.gender }
        }
        acc[heir.relationship].count += heir.count
        return acc
      },
      {} as Record<string, { count: number; gender: string }>,
    )

    const hasSons = heirGroups["son"]?.count > 0
    const hasDaughters = heirGroups["daughter"]?.count > 0
    const hasChildren = hasSons || hasDaughters

    // Fixed shares (Fard) - Spouse
    if (heirGroups["spouse-wife"]) {
      // Wife gets 1/8 if children exist, 1/4 otherwise
      const wifeFraction = hasChildren ? 1 / 8 : 1 / 4
      const wifeShare = netEstate * wifeFraction
      const wifeCount = heirGroups["spouse-wife"].count
      shares.push({
        relationship: "Wife",
        count: wifeCount,
        sharePerPerson: wifeShare / wifeCount,
        totalShare: wifeShare,
        percentage: wifeFraction * 100,
      })
      remainingEstate -= wifeShare
    }

    if (heirGroups["spouse-husband"]) {
      // Husband gets 1/4 if children exist, 1/2 otherwise
      const husbandFraction = hasChildren ? 1 / 4 : 1 / 2
      const husbandShare = netEstate * husbandFraction
      shares.push({
        relationship: "Husband",
        count: 1,
        sharePerPerson: husbandShare,
        totalShare: husbandShare,
        percentage: husbandFraction * 100,
      })
      remainingEstate -= husbandShare
    }

    // Father gets 1/6 fixed + residue if no male children
    if (heirGroups["father"]) {
      const fatherFraction = 1 / 6
      const fatherShare = netEstate * fatherFraction
      if (!hasSons && hasChildren) {
        // Father gets 1/6 fixed when daughters exist
        shares.push({
          relationship: "Father",
          count: 1,
          sharePerPerson: fatherShare,
          totalShare: fatherShare,
          percentage: fatherFraction * 100,
        })
        remainingEstate -= fatherShare
      } else if (hasChildren) {
        // Father gets 1/6 when sons exist
        shares.push({
          relationship: "Father",
          count: 1,
          sharePerPerson: fatherShare,
          totalShare: fatherShare,
          percentage: fatherFraction * 100,
        })
        remainingEstate -= fatherShare
      } else {
        // Father as residuary (no children)
        // Will be calculated later
      }
    }

    // Mother gets 1/6 if children exist, 1/3 otherwise
    if (heirGroups["mother"]) {
      const motherFraction = hasChildren ? 1 / 6 : 1 / 3
      const motherShare = netEstate * motherFraction
      shares.push({
        relationship: "Mother",
        count: 1,
        sharePerPerson: motherShare,
        totalShare: motherShare,
        percentage: motherFraction * 100,
      })
      remainingEstate -= motherShare
    }

    // Children as residuary heirs
    if (hasChildren) {
      const sonCount = heirGroups["son"]?.count || 0
      const daughterCount = heirGroups["daughter"]?.count || 0

      if (hasSons && hasDaughters) {
        // Sons get 2x daughters (2:1 ratio)
        const totalParts = sonCount * 2 + daughterCount
        const partValue = remainingEstate / totalParts

        if (sonCount > 0) {
          shares.push({
            relationship: "Son",
            count: sonCount,
            sharePerPerson: partValue * 2,
            totalShare: partValue * 2 * sonCount,
            percentage: ((partValue * 2 * sonCount) / netEstate) * 100,
          })
        }
        if (daughterCount > 0) {
          shares.push({
            relationship: "Daughter",
            count: daughterCount,
            sharePerPerson: partValue,
            totalShare: partValue * daughterCount,
            percentage: ((partValue * daughterCount) / netEstate) * 100,
          })
        }
      } else if (hasSons) {
        // Only sons - share equally
        shares.push({
          relationship: "Son",
          count: sonCount,
          sharePerPerson: remainingEstate / sonCount,
          totalShare: remainingEstate,
          percentage: (remainingEstate / netEstate) * 100,
        })
      } else if (hasDaughters) {
        // Only daughters
        if (daughterCount === 1) {
          // Single daughter gets 1/2
          const daughterShare = netEstate * 0.5
          shares.push({
            relationship: "Daughter",
            count: 1,
            sharePerPerson: daughterShare,
            totalShare: daughterShare,
            percentage: 50,
          })
        } else {
          // Multiple daughters share 2/3
          const daughterShare = netEstate * (2 / 3)
          shares.push({
            relationship: "Daughter",
            count: daughterCount,
            sharePerPerson: daughterShare / daughterCount,
            totalShare: daughterShare,
            percentage: (2 / 3) * 100,
          })
        }
      }
    } else {
      // No children - Father as residuary
      if (heirGroups["father"]) {
        shares.push({
          relationship: "Father",
          count: 1,
          sharePerPerson: remainingEstate,
          totalShare: remainingEstate,
          percentage: (remainingEstate / netEstate) * 100,
        })
      }
    }

    return shares
  }

  const handleReset = () => {
    setTotalEstate("")
    setDebts("")
    setFuneralExpenses("")
    setBequests("")
    setHeirs([
      { id: "1", relationship: "spouse-wife", count: 1, gender: "female" },
      { id: "2", relationship: "son", count: 2, gender: "male" },
    ])
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.shares
        .map(
          (s) =>
            `${s.relationship} (${s.count}): ${formatCurrency(s.totalShare, currency)} (${s.percentage.toFixed(1)}%)`,
        )
        .join("\n")
      await navigator.clipboard.writeText(
        `Inheritance Distribution:\n${text}\n\nTotal: ${formatCurrency(result.totalDistributed, currency)}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Inheritance Share Calculation",
          text: `I calculated inheritance shares using CalcHub! Net Estate: ${formatCurrency(result.netEstate, currency)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Inheritance Share Calculator</CardTitle>
                    <CardDescription>Calculate estate distribution among heirs</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Total Estate */}
                <div className="space-y-2">
                  <Label htmlFor="estate">Total Estate Value ({symbol})</Label>
                  <Input
                    id="estate"
                    type="number"
                    placeholder="Enter total estate value"
                    value={totalEstate}
                    onChange={(e) => setTotalEstate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Legal Framework */}
                <div className="space-y-2">
                  <Label>Legal Framework</Label>
                  <Select value={legalFramework} onValueChange={(v) => setLegalFramework(v as LegalFramework)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="islamic">Islamic Law (Faraid)</SelectItem>
                      <SelectItem value="equal">Equal Distribution</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Heirs */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Heirs</Label>
                    <Button variant="outline" size="sm" onClick={addHeir}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Heir
                    </Button>
                  </div>

                  {heirs.map((heir) => (
                    <div key={heir.id} className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                      <Select value={heir.relationship} onValueChange={(v) => updateHeir(heir.id, "relationship", v)}>
                        <SelectTrigger className="flex-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {heirTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        placeholder="Count"
                        value={heir.count}
                        onChange={(e) => updateHeir(heir.id, "count", Number.parseInt(e.target.value) || 1)}
                        min="1"
                        className="w-20"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeHeir(heir.id)}
                        disabled={heirs.length <= 1}
                      >
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  ))}
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between">
                      <span>Deductions (Optional)</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-3 pt-2">
                    <div className="space-y-2">
                      <Label htmlFor="debts">Debts ({symbol})</Label>
                      <Input
                        id="debts"
                        type="number"
                        placeholder="Outstanding debts"
                        value={debts}
                        onChange={(e) => setDebts(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="funeral">Funeral Expenses ({symbol})</Label>
                      <Input
                        id="funeral"
                        type="number"
                        placeholder="Funeral costs"
                        value={funeralExpenses}
                        onChange={(e) => setFuneralExpenses(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bequests">Bequests/Wasiyyah ({symbol})</Label>
                      <Input
                        id="bequests"
                        type="number"
                        placeholder="Max 1/3 of estate"
                        value={bequests}
                        onChange={(e) => setBequests(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                      {legalFramework === "islamic" && (
                        <p className="text-xs text-muted-foreground">
                          In Islamic law, bequests cannot exceed 1/3 of the estate
                        </p>
                      )}
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateInheritance} className="w-full" size="lg">
                  Calculate Distribution
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Net Estate</p>
                      <p className="text-3xl font-bold text-green-600">{formatCurrency(result.netEstate, currency)}</p>
                    </div>

                    {/* Distribution Summary */}
                    <div className="space-y-2 mb-4">
                      {result.shares.map((share, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-white rounded-lg">
                          <div>
                            <span className="font-medium">{share.relationship}</span>
                            {share.count > 1 && <span className="text-muted-foreground text-sm"> × {share.count}</span>}
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">{formatCurrency(share.totalShare, currency)}</p>
                            <p className="text-xs text-muted-foreground">{share.percentage.toFixed(1)}%</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Expandable Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          {showBreakdown ? "Hide" : "Show"} Per-Person Breakdown
                          {showBreakdown ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="pt-2">
                        <div className="space-y-2">
                          {result.shares
                            .filter((s) => s.count > 1)
                            .map((share, index) => (
                              <div key={index} className="p-2 bg-white rounded-lg text-sm">
                                <p className="font-medium">
                                  {share.relationship} (each of {share.count}):
                                </p>
                                <p className="text-green-600">
                                  {formatCurrency(share.sharePerPerson, currency)} per person
                                </p>
                              </div>
                            ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Islamic Inheritance Shares</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Wife (with children)</span>
                      <span className="text-sm text-blue-600">1/8</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Wife (no children)</span>
                      <span className="text-sm text-blue-600">1/4</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Husband (with children)</span>
                      <span className="text-sm text-green-600">1/4</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Husband (no children)</span>
                      <span className="text-sm text-green-600">1/2</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Mother</span>
                      <span className="text-sm text-purple-600">1/6 or 1/3</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Father</span>
                      <span className="text-sm text-orange-600">1/6 + Residue</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Distribution Order</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Before Distribution:</p>
                    <ol className="list-decimal list-inside space-y-1">
                      <li>Pay funeral expenses</li>
                      <li>Settle all debts</li>
                      <li>Execute bequests (max 1/3)</li>
                    </ol>
                  </div>
                  <p>
                    The remaining estate is then distributed according to the fixed shares (Fard) for each heir
                    category.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Islamic Inheritance (Faraid)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Islamic inheritance law, known as Faraid or Mirath, is a comprehensive system derived from the Quran
                  and Hadith that governs the distribution of a deceased person's estate among their heirs. The system
                  ensures that wealth is distributed fairly among family members according to their relationship and
                  responsibilities, with specific fractions allocated to different categories of heirs.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The law distinguishes between fixed-share heirs (Ashabul Furudh) who receive predetermined fractions,
                  and residuary heirs (Asabah) who inherit what remains after the fixed shares are distributed. This
                  calculator implements the basic rules for common inheritance scenarios involving immediate family
                  members.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter the total value of the estate including all assets such as property, cash, investments, and
                  valuables. Add the relevant heirs by selecting their relationship to the deceased and specifying the
                  count if there are multiple heirs of the same type. Optionally, you can deduct debts, funeral
                  expenses, and any bequests (limited to 1/3 of the estate in Islamic law).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The calculator will then compute each heir's share according to the selected legal framework. You can
                  choose between Islamic law (Faraid) for Shariah-compliant distribution or equal distribution for a
                  simple per-capita division among all heirs.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  This calculator provides estimates based on general Islamic inheritance rules and entered values.
                  Inheritance laws can be complex and may vary based on specific circumstances, local regulations, and
                  scholarly interpretations. For accurate inheritance distribution, please consult a qualified Islamic
                  scholar (Mufti), legal professional, or certified inheritance specialist who can consider all relevant
                  factors and provide proper guidance according to your specific situation.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
