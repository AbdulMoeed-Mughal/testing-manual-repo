"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type Mode = "charging" | "discharging"

interface RCResult {
  tau: number
  tauUnit: string
  voltages: {
    t1: number
    t2: number
    t3: number
    t4: number
    t5: number
  }
  timeToTarget?: number
  timeToTargetUnit?: string
}

export function RCTimeConstantCalculator() {
  const [resistance, setResistance] = useState("")
  const [resistanceUnit, setResistanceUnit] = useState("ohm")
  const [capacitance, setCapacitance] = useState("")
  const [capacitanceUnit, setCapacitanceUnit] = useState("uF")
  const [initialVoltage, setInitialVoltage] = useState("")
  const [targetVoltage, setTargetVoltage] = useState("")
  const [mode, setMode] = useState<Mode>("charging")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<RCResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const resistanceMultipliers: Record<string, number> = {
    ohm: 1,
    kohm: 1e3,
    mohm: 1e6,
  }

  const capacitanceMultipliers: Record<string, number> = {
    F: 1,
    mF: 1e-3,
    uF: 1e-6,
    nF: 1e-9,
    pF: 1e-12,
  }

  const formatTime = (seconds: number): { value: number; unit: string } => {
    if (seconds >= 1) return { value: seconds, unit: "s" }
    if (seconds >= 1e-3) return { value: seconds * 1e3, unit: "ms" }
    if (seconds >= 1e-6) return { value: seconds * 1e6, unit: "µs" }
    return { value: seconds * 1e9, unit: "ns" }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const R = Number.parseFloat(resistance)
    const C = Number.parseFloat(capacitance)

    if (isNaN(R) || R <= 0) {
      setError("Please enter a valid resistance greater than 0")
      return
    }
    if (isNaN(C) || C <= 0) {
      setError("Please enter a valid capacitance greater than 0")
      return
    }

    const R_ohms = R * resistanceMultipliers[resistanceUnit]
    const C_farads = C * capacitanceMultipliers[capacitanceUnit]

    // Calculate time constant
    const tau = R_ohms * C_farads
    const tauFormatted = formatTime(tau)

    // Calculate voltages at different time constants
    const V0 = Number.parseFloat(initialVoltage) || 10 // Default to 10V if not specified
    let voltages: RCResult["voltages"]

    if (mode === "charging") {
      // V(t) = V0 * (1 - e^(-t/τ))
      voltages = {
        t1: V0 * (1 - Math.exp(-1)),
        t2: V0 * (1 - Math.exp(-2)),
        t3: V0 * (1 - Math.exp(-3)),
        t4: V0 * (1 - Math.exp(-4)),
        t5: V0 * (1 - Math.exp(-5)),
      }
    } else {
      // V(t) = V0 * e^(-t/τ)
      voltages = {
        t1: V0 * Math.exp(-1),
        t2: V0 * Math.exp(-2),
        t3: V0 * Math.exp(-3),
        t4: V0 * Math.exp(-4),
        t5: V0 * Math.exp(-5),
      }
    }

    // Calculate time to reach target voltage if specified
    let timeToTarget: number | undefined
    let timeToTargetUnit: string | undefined

    const Vt = Number.parseFloat(targetVoltage)
    if (!isNaN(Vt) && Vt > 0) {
      if (mode === "charging" && Vt < V0) {
        // t = -τ * ln(1 - Vt/V0)
        const ratio = 1 - Vt / V0
        if (ratio > 0) {
          timeToTarget = -tau * Math.log(ratio)
          const formatted = formatTime(timeToTarget)
          timeToTarget = formatted.value
          timeToTargetUnit = formatted.unit
        }
      } else if (mode === "discharging" && Vt < V0) {
        // t = -τ * ln(Vt/V0)
        const ratio = Vt / V0
        if (ratio > 0) {
          timeToTarget = -tau * Math.log(ratio)
          const formatted = formatTime(timeToTarget)
          timeToTarget = formatted.value
          timeToTargetUnit = formatted.unit
        }
      }
    }

    setResult({
      tau: tauFormatted.value,
      tauUnit: tauFormatted.unit,
      voltages,
      timeToTarget,
      timeToTargetUnit,
    })
  }

  const handleReset = () => {
    setResistance("")
    setCapacitance("")
    setInitialVoltage("")
    setTargetVoltage("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `RC Time Constant: τ = ${result.tau.toFixed(4)} ${result.tauUnit}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "RC Time Constant Calculation",
          text: `RC Time Constant: τ = ${result.tau.toFixed(4)} ${result.tauUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">RC Time Constant Calculator</CardTitle>
                    <CardDescription>Calculate τ for RC circuits</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Circuit Mode</span>
                  <button
                    onClick={() => setMode(mode === "charging" ? "discharging" : "charging")}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "discharging" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "charging" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Charging
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "discharging" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Discharging
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Resistance Input */}
                <div className="space-y-2">
                  <Label htmlFor="resistance">Resistance (R)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="resistance"
                      type="number"
                      placeholder="Enter resistance"
                      value={resistance}
                      onChange={(e) => setResistance(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={resistanceUnit} onValueChange={setResistanceUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ohm">Ω</SelectItem>
                        <SelectItem value="kohm">kΩ</SelectItem>
                        <SelectItem value="mohm">MΩ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Capacitance Input */}
                <div className="space-y-2">
                  <Label htmlFor="capacitance">Capacitance (C)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="capacitance"
                      type="number"
                      placeholder="Enter capacitance"
                      value={capacitance}
                      onChange={(e) => setCapacitance(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={capacitanceUnit} onValueChange={setCapacitanceUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="F">F</SelectItem>
                        <SelectItem value="mF">mF</SelectItem>
                        <SelectItem value="uF">µF</SelectItem>
                        <SelectItem value="nF">nF</SelectItem>
                        <SelectItem value="pF">pF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Initial Voltage Input */}
                <div className="space-y-2">
                  <Label htmlFor="initialVoltage">
                    {mode === "charging" ? "Supply Voltage (V₀)" : "Initial Voltage (V₀)"} (optional)
                  </Label>
                  <Input
                    id="initialVoltage"
                    type="number"
                    placeholder="Default: 10V"
                    value={initialVoltage}
                    onChange={(e) => setInitialVoltage(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Target Voltage Input */}
                <div className="space-y-2">
                  <Label htmlFor="targetVoltage">Target Voltage (optional)</Label>
                  <Input
                    id="targetVoltage"
                    type="number"
                    placeholder="Calculate time to reach voltage"
                    value={targetVoltage}
                    onChange={(e) => setTargetVoltage(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Time Constant
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">RC Time Constant (τ)</p>
                      <p className="text-4xl font-bold text-orange-600 mb-1">
                        {result.tau.toFixed(4)} {result.tauUnit}
                      </p>
                    </div>

                    {result.timeToTarget !== undefined && (
                      <div className="mt-3 p-3 bg-white/60 rounded-lg text-center">
                        <p className="text-sm text-muted-foreground">Time to Target Voltage</p>
                        <p className="text-xl font-semibold text-orange-700">
                          {result.timeToTarget.toFixed(4)} {result.timeToTargetUnit}
                        </p>
                      </div>
                    )}

                    {/* Voltage at Time Constants */}
                    <div className="mt-3 p-3 bg-white/60 rounded-lg">
                      <p className="text-sm font-medium text-center mb-2">
                        Voltage at Time Constants ({mode === "charging" ? "Charging" : "Discharging"})
                      </p>
                      <div className="grid grid-cols-5 gap-1 text-center text-xs">
                        <div>
                          <p className="font-medium">1τ</p>
                          <p>{result.voltages.t1.toFixed(2)}V</p>
                        </div>
                        <div>
                          <p className="font-medium">2τ</p>
                          <p>{result.voltages.t2.toFixed(2)}V</p>
                        </div>
                        <div>
                          <p className="font-medium">3τ</p>
                          <p>{result.voltages.t3.toFixed(2)}V</p>
                        </div>
                        <div>
                          <p className="font-medium">4τ</p>
                          <p>{result.voltages.t4.toFixed(2)}V</p>
                        </div>
                        <div>
                          <p className="font-medium">5τ</p>
                          <p>{result.voltages.t5.toFixed(2)}V</p>
                        </div>
                      </div>
                    </div>

                    {/* Step-by-step */}
                    <Collapsible open={showSteps} onOpenChange={setShowSteps} className="mt-3">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          {showSteps ? "Hide" : "Show"} Calculation Steps
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2 p-3 bg-white/60 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Apply the RC time constant formula
                        </p>
                        <p className="font-mono bg-muted p-2 rounded">τ = R × C</p>
                        <p>
                          <strong>Step 2:</strong> Convert units to base SI units
                        </p>
                        <p className="font-mono bg-muted p-2 rounded">
                          R = {resistance} {resistanceUnit === "ohm" ? "Ω" : resistanceUnit === "kohm" ? "kΩ" : "MΩ"} ={" "}
                          {(Number.parseFloat(resistance) * resistanceMultipliers[resistanceUnit]).toExponential(3)} Ω
                        </p>
                        <p className="font-mono bg-muted p-2 rounded">
                          C = {capacitance}{" "}
                          {capacitanceUnit === "F"
                            ? "F"
                            : capacitanceUnit === "mF"
                              ? "mF"
                              : capacitanceUnit === "uF"
                                ? "µF"
                                : capacitanceUnit === "nF"
                                  ? "nF"
                                  : "pF"}{" "}
                          ={" "}
                          {(Number.parseFloat(capacitance) * capacitanceMultipliers[capacitanceUnit]).toExponential(3)}{" "}
                          F
                        </p>
                        <p>
                          <strong>Step 3:</strong> Calculate time constant
                        </p>
                        <p className="font-mono bg-muted p-2 rounded">
                          τ = {(Number.parseFloat(resistance) * resistanceMultipliers[resistanceUnit]).toExponential(3)}{" "}
                          ×{" "}
                          {(Number.parseFloat(capacitance) * capacitanceMultipliers[capacitanceUnit]).toExponential(3)}{" "}
                          = {result.tau.toFixed(4)} {result.tauUnit}
                        </p>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">RC Time Constant Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">τ = R × C</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>τ</strong> = Time constant (seconds)
                    </p>
                    <p>
                      <strong>R</strong> = Resistance (ohms)
                    </p>
                    <p>
                      <strong>C</strong> = Capacitance (farads)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Voltage Equations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-medium text-green-700 mb-1">Charging</p>
                    <p className="font-mono text-sm text-green-600">V(t) = V₀ × (1 − e^(−t/τ))</p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-700 mb-1">Discharging</p>
                    <p className="font-mono text-sm text-blue-600">V(t) = V₀ × e^(−t/τ)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Time Constant Milestones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1τ</span>
                      <span>63.2% charged / 36.8% remaining</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>2τ</span>
                      <span>86.5% charged / 13.5% remaining</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>3τ</span>
                      <span>95.0% charged / 5.0% remaining</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>4τ</span>
                      <span>98.2% charged / 1.8% remaining</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>5τ</span>
                      <span>99.3% charged / 0.7% remaining</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an RC Time Constant?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The RC time constant (τ, tau) is a measure of how quickly a capacitor charges or discharges through a
                  resistor in an RC circuit. It represents the time required for the voltage across the capacitor to
                  reach approximately 63.2% of its final value during charging, or to drop to approximately 36.8% of its
                  initial value during discharging. The time constant is a fundamental parameter in electronics,
                  determining the response time of filters, timing circuits, and signal processing applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  After 5 time constants (5τ), the capacitor is considered to be fully charged or discharged for
                  practical purposes, having reached over 99% of its final value. This principle is widely used in
                  designing timing circuits, filters, integrators, and differentiators in analog electronics.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of RC Circuits</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  RC circuits are fundamental building blocks in electronics with numerous practical applications. They
                  are used as low-pass and high-pass filters for signal processing, coupling and decoupling capacitors
                  in audio circuits, timing elements in oscillators and delay circuits, and for noise suppression in
                  power supplies. The time constant determines the cutoff frequency in filter applications (f_c =
                  1/(2πRC)), making it essential for designing audio equalizers, radio receivers, and communication
                  systems.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm">
                  RC time constant calculations are based on ideal circuit conditions. Actual circuit behavior may vary
                  due to parasitic elements, component tolerance, temperature effects, and other real-world factors.
                  Consult circuit datasheets or an electrical engineer for precise measurements in critical
                  applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
