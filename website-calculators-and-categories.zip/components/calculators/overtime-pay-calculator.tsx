"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, DollarSign, Info, Clock, TrendingUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

interface OvertimeResult {
  regularHours: number
  overtimeHours: number
  regularPay: number
  overtimePay: number
  bonuses: number
  totalPay: number
  effectiveHourlyRate: number
  overtimePercentage: number
}

export function OvertimePayCalculator() {
  const [hourlyWage, setHourlyWage] = useState("")
  const [standardHours, setStandardHours] = useState("40")
  const [totalHours, setTotalHours] = useState("")
  const [overtimeMultiplier, setOvertimeMultiplier] = useState("1.5")
  const [payFrequency, setPayFrequency] = useState("weekly")
  const [bonuses, setBonuses] = useState("")
  const [result, setResult] = useState<OvertimeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)

  const calculateOvertimePay = () => {
    setError("")
    setResult(null)

    const wage = Number.parseFloat(hourlyWage)
    const standard = Number.parseFloat(standardHours)
    const total = Number.parseFloat(totalHours)
    const multiplier = Number.parseFloat(overtimeMultiplier)
    const bonusAmount = Number.parseFloat(bonuses) || 0

    if (isNaN(wage) || wage <= 0) {
      setError("Please enter a valid hourly wage greater than 0")
      return
    }

    if (isNaN(standard) || standard <= 0) {
      setError("Please enter valid standard hours greater than 0")
      return
    }

    if (isNaN(total) || total < 0) {
      setError("Please enter valid total hours worked")
      return
    }

    if (isNaN(multiplier) || multiplier < 1) {
      setError("Overtime multiplier must be at least 1")
      return
    }

    // Calculate overtime hours
    const overtimeHours = Math.max(0, total - standard)
    const regularHours = Math.min(total, standard)

    // Calculate pay
    const regularPay = regularHours * wage
    const overtimePay = overtimeHours * wage * multiplier
    const totalPay = regularPay + overtimePay + bonusAmount

    // Calculate effective hourly rate
    const effectiveHourlyRate = total > 0 ? totalPay / total : wage

    // Calculate overtime percentage of total pay
    const overtimePercentage = totalPay > 0 ? (overtimePay / totalPay) * 100 : 0

    setResult({
      regularHours,
      overtimeHours,
      regularPay,
      overtimePay,
      bonuses: bonusAmount,
      totalPay,
      effectiveHourlyRate,
      overtimePercentage,
    })
  }

  const handleReset = () => {
    setHourlyWage("")
    setStandardHours("40")
    setTotalHours("")
    setOvertimeMultiplier("1.5")
    setPayFrequency("weekly")
    setBonuses("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Overtime Pay Summary:
Regular Pay: $${result.regularPay.toFixed(2)} (${result.regularHours} hrs)
Overtime Pay: $${result.overtimePay.toFixed(2)} (${result.overtimeHours} hrs)
${result.bonuses > 0 ? `Bonuses: $${result.bonuses.toFixed(2)}\n` : ""}Total Pay: $${result.totalPay.toFixed(2)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Overtime Pay Calculation",
          text: `I calculated my overtime pay using CalcHub! Total: $${result.totalPay.toFixed(2)} (Regular: $${result.regularPay.toFixed(2)}, Overtime: $${result.overtimePay.toFixed(2)})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value)
  }

  const getPayPeriodMultiplier = () => {
    switch (payFrequency) {
      case "weekly":
        return 1
      case "biweekly":
        return 2
      case "monthly":
        return 4.33
      default:
        return 1
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Overtime Pay Calculator</CardTitle>
                    <CardDescription>Calculate earnings including overtime</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Hourly Wage */}
                <div className="space-y-2">
                  <Label htmlFor="hourlyWage">Regular Hourly Wage ($)</Label>
                  <Input
                    id="hourlyWage"
                    type="number"
                    placeholder="Enter hourly wage"
                    value={hourlyWage}
                    onChange={(e) => setHourlyWage(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Standard Hours */}
                <div className="space-y-2">
                  <Label htmlFor="standardHours">Standard Hours per Week</Label>
                  <Input
                    id="standardHours"
                    type="number"
                    placeholder="Enter standard hours"
                    value={standardHours}
                    onChange={(e) => setStandardHours(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Total Hours Worked */}
                <div className="space-y-2">
                  <Label htmlFor="totalHours">Total Hours Worked</Label>
                  <Input
                    id="totalHours"
                    type="number"
                    placeholder="Enter total hours worked"
                    value={totalHours}
                    onChange={(e) => setTotalHours(e.target.value)}
                    min="0"
                    step="0.5"
                  />
                </div>

                {/* Overtime Multiplier */}
                <div className="space-y-2">
                  <Label htmlFor="overtimeMultiplier">Overtime Rate Multiplier</Label>
                  <Select value={overtimeMultiplier} onValueChange={setOvertimeMultiplier}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select multiplier" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1.25">1.25x (Time and a Quarter)</SelectItem>
                      <SelectItem value="1.5">1.5x (Time and a Half)</SelectItem>
                      <SelectItem value="2">2x (Double Time)</SelectItem>
                      <SelectItem value="2.5">2.5x (Double Time and a Half)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      <ChevronDown
                        className={`h-4 w-4 transition-transform ${showAdvanced ? "transform rotate-180" : ""}`}
                      />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    {/* Pay Frequency */}
                    <div className="space-y-2">
                      <Label htmlFor="payFrequency">Pay Frequency</Label>
                      <Select value={payFrequency} onValueChange={setPayFrequency}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="biweekly">Biweekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Bonuses */}
                    <div className="space-y-2">
                      <Label htmlFor="bonuses">Bonuses / Additional Pay ($)</Label>
                      <Input
                        id="bonuses"
                        type="number"
                        placeholder="Enter bonus amount (optional)"
                        value={bonuses}
                        onChange={(e) => setBonuses(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateOvertimePay} className="w-full" size="lg">
                  Calculate Overtime Pay
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Pay</p>
                      <p className="text-4xl font-bold text-green-600">{formatCurrency(result.totalPay)}</p>
                    </div>

                    {/* Pay Breakdown */}
                    <div className="space-y-3 mb-4">
                      <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                        <span className="text-sm text-muted-foreground">Regular Pay ({result.regularHours} hrs)</span>
                        <span className="font-semibold text-foreground">{formatCurrency(result.regularPay)}</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                        <span className="text-sm text-muted-foreground">Overtime Pay ({result.overtimeHours} hrs)</span>
                        <span className="font-semibold text-orange-600">{formatCurrency(result.overtimePay)}</span>
                      </div>
                      {result.bonuses > 0 && (
                        <div className="flex justify-between items-center p-2 bg-white rounded-lg">
                          <span className="text-sm text-muted-foreground">Bonuses</span>
                          <span className="font-semibold text-blue-600">{formatCurrency(result.bonuses)}</span>
                        </div>
                      )}
                    </div>

                    {/* Visual Breakdown Bar */}
                    <div className="mb-4">
                      <div className="h-4 rounded-full overflow-hidden flex">
                        <div
                          className="bg-green-500 transition-all"
                          style={{
                            width: `${(result.regularPay / result.totalPay) * 100}%`,
                          }}
                        />
                        <div
                          className="bg-orange-500 transition-all"
                          style={{
                            width: `${(result.overtimePay / result.totalPay) * 100}%`,
                          }}
                        />
                        {result.bonuses > 0 && (
                          <div
                            className="bg-blue-500 transition-all"
                            style={{
                              width: `${(result.bonuses / result.totalPay) * 100}%`,
                            }}
                          />
                        )}
                      </div>
                      <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <span className="w-2 h-2 bg-green-500 rounded-full" />
                          Regular
                        </span>
                        <span className="flex items-center gap-1">
                          <span className="w-2 h-2 bg-orange-500 rounded-full" />
                          Overtime
                        </span>
                        {result.bonuses > 0 && (
                          <span className="flex items-center gap-1">
                            <span className="w-2 h-2 bg-blue-500 rounded-full" />
                            Bonus
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Additional Stats */}
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">Effective Rate</p>
                        <p className="font-semibold">{formatCurrency(result.effectiveHourlyRate)}/hr</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg text-center">
                        <p className="text-muted-foreground text-xs">OT % of Pay</p>
                        <p className="font-semibold">{result.overtimePercentage.toFixed(1)}%</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Overtime Rate Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">1.25x</span>
                      <span className="text-sm text-blue-600">Time and a Quarter</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">1.5x</span>
                      <span className="text-sm text-green-600">Time and a Half (Standard)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">2x</span>
                      <span className="text-sm text-yellow-600">Double Time</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">2.5x</span>
                      <span className="text-sm text-orange-600">Double Time and a Half</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Overtime Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">OT Hours = Total Hours − Standard Hours</p>
                    <p className="font-semibold text-foreground">OT Pay = OT Hours × Wage × Multiplier</p>
                    <p className="font-semibold text-foreground">Total = Regular Pay + OT Pay + Bonuses</p>
                  </div>
                  <p>
                    In the U.S., the standard overtime rate is <strong>1.5x</strong> (time and a half) for hours worked
                    beyond 40 per week under the Fair Labor Standards Act (FLSA).
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Overtime Pay */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Overtime Pay?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Overtime pay is the additional compensation employees receive for working beyond their standard work
                  hours. In most countries, labor laws mandate that employers pay workers at a higher rate for overtime
                  hours to compensate for the extra time and effort. This practice helps protect workers from
                  exploitation and ensures fair compensation for extended work periods.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In the United States, the Fair Labor Standards Act (FLSA) requires that non-exempt employees receive
                  overtime pay at a rate of at least 1.5 times their regular hourly rate for all hours worked over 40 in
                  a workweek. Some states have additional overtime requirements, such as daily overtime for hours worked
                  beyond 8 in a single day.
                </p>
              </CardContent>
            </Card>

            {/* How Overtime is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>How is Overtime Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Overtime calculation involves determining the number of hours worked beyond the standard threshold and
                  applying the appropriate multiplier. For example, if you earn $20/hour and work 50 hours in a week
                  with a 40-hour standard, your overtime would be: 10 overtime hours × $20 × 1.5 = $300 in overtime pay,
                  plus $800 in regular pay (40 × $20), for a total of $1,100.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The overtime multiplier varies by jurisdiction and employment contract. While 1.5x is the most common
                  rate, some situations call for double time (2x), particularly for holidays, weekends, or excessive
                  overtime hours. Always check your employment agreement and local labor laws to understand your
                  specific overtime rate.
                </p>
              </CardContent>
            </Card>

            {/* Tips for Managing Overtime */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Managing Overtime</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Track Your Hours</h4>
                    <p className="text-green-700 text-sm">
                      Keep detailed records of all hours worked, including start and end times. This documentation
                      protects you and ensures accurate pay.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Know Your Rights</h4>
                    <p className="text-blue-700 text-sm">
                      Understand whether you are classified as exempt or non-exempt. Non-exempt employees are entitled
                      to overtime pay under federal law.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Check State Laws</h4>
                    <p className="text-yellow-700 text-sm">
                      Some states have additional overtime protections, such as daily overtime requirements. California,
                      for example, requires overtime for hours over 8 per day.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Review Your Paystubs</h4>
                    <p className="text-purple-700 text-sm">
                      Regularly verify that your overtime is calculated correctly on your paystubs. Report any
                      discrepancies to your HR department promptly.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800">
                  <strong>Disclaimer:</strong> Overtime pay calculations are estimates based on user inputs and may vary
                  according to employment contracts and labor laws. Consult your payroll department or labor regulations
                  for exact calculations. This calculator does not account for all possible deductions, taxes, or
                  special pay arrangements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
