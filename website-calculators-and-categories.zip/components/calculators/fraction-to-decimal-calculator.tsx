"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Divide, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type InputMode = "simple" | "mixed"

interface FractionToDecimalResult {
  decimal: string
  exactDecimal: string
  isRepeating: boolean
  repeatingPart: string
  nonRepeatingPart: string
  repeatingNotation: string
  steps: string[]
}

export function FractionToDecimalCalculator() {
  const [inputMode, setInputMode] = useState<InputMode>("simple")
  const [numerator, setNumerator] = useState("")
  const [denominator, setDenominator] = useState("")
  const [wholeNumber, setWholeNumber] = useState("")
  const [precision, setPrecision] = useState("10")
  const [detectRepeating, setDetectRepeating] = useState(true)
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<FractionToDecimalResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")

  const gcd = (a: number, b: number): number => {
    a = Math.abs(a)
    b = Math.abs(b)
    while (b) {
      const t = b
      b = a % b
      a = t
    }
    return a
  }

  const findRepeatingDecimal = (
    num: number,
    den: number,
    maxIterations = 1000,
  ): {
    nonRepeating: string
    repeating: string
    isRepeating: boolean
  } => {
    const isNegative = num < 0 !== den < 0
    num = Math.abs(num)
    den = Math.abs(den)

    const integerPart = Math.floor(num / den)
    let remainder = num % den

    if (remainder === 0) {
      return { nonRepeating: (isNegative ? "-" : "") + integerPart.toString(), repeating: "", isRepeating: false }
    }

    const remainders: Map<number, number> = new Map()
    let decimalPart = ""
    let position = 0

    while (remainder !== 0 && position < maxIterations) {
      if (remainders.has(remainder)) {
        const repeatStart = remainders.get(remainder)!
        const nonRepeating = decimalPart.substring(0, repeatStart)
        const repeating = decimalPart.substring(repeatStart)
        return {
          nonRepeating: (isNegative ? "-" : "") + integerPart + (nonRepeating ? "." + nonRepeating : "."),
          repeating,
          isRepeating: true,
        }
      }

      remainders.set(remainder, position)
      remainder *= 10
      const digit = Math.floor(remainder / den)
      decimalPart += digit.toString()
      remainder %= den
      position++
    }

    return {
      nonRepeating: (isNegative ? "-" : "") + integerPart + "." + decimalPart,
      repeating: "",
      isRepeating: false,
    }
  }

  const calculateDecimal = () => {
    setError("")
    setResult(null)

    const num = Number.parseInt(numerator)
    const den = Number.parseInt(denominator)
    const whole = inputMode === "mixed" ? Number.parseInt(wholeNumber) || 0 : 0
    const precisionNum = Number.parseInt(precision) || 10

    if (isNaN(num)) {
      setError("Please enter a valid numerator")
      return
    }

    if (isNaN(den) || den === 0) {
      setError("Please enter a valid denominator (not zero)")
      return
    }

    const steps: string[] = []

    // Convert mixed number to improper fraction if needed
    let effectiveNum = num
    let effectiveDen = den
    const isNegative = (whole < 0 || num < 0) !== den < 0

    if (inputMode === "mixed" && whole !== 0) {
      const absWhole = Math.abs(whole)
      const absNum = Math.abs(num)
      const absDen = Math.abs(den)
      effectiveNum = absWhole * absDen + absNum
      if (isNegative) effectiveNum = -effectiveNum
      effectiveDen = absDen
      steps.push(`Convert mixed number to improper fraction:`)
      steps.push(
        `${whole} ${absNum}/${absDen} = (${absWhole} × ${absDen} + ${absNum})/${absDen} = ${effectiveNum}/${effectiveDen}`,
      )
    } else {
      steps.push(`Starting fraction: ${num}/${den}`)
    }

    // Simplify fraction
    const divisor = gcd(effectiveNum, effectiveDen)
    const simplifiedNum = effectiveNum / divisor
    const simplifiedDen = effectiveDen / divisor

    if (divisor > 1) {
      steps.push(`Simplify by dividing by GCD(${Math.abs(effectiveNum)}, ${Math.abs(effectiveDen)}) = ${divisor}:`)
      steps.push(`${effectiveNum}/${effectiveDen} = ${simplifiedNum}/${simplifiedDen}`)
    }

    // Perform division
    steps.push(`Divide numerator by denominator:`)
    steps.push(`${simplifiedNum} ÷ ${simplifiedDen}`)

    // Calculate decimal
    const exactDecimalValue = simplifiedNum / simplifiedDen
    const roundedDecimal = exactDecimalValue.toFixed(precisionNum)

    // Detect repeating decimals
    let repeatingInfo = { nonRepeating: "", repeating: "", isRepeating: false }
    if (detectRepeating) {
      repeatingInfo = findRepeatingDecimal(simplifiedNum, simplifiedDen)
    }

    if (repeatingInfo.isRepeating) {
      steps.push(`Result: ${repeatingInfo.nonRepeating}${repeatingInfo.repeating}... (repeating)`)
      steps.push(`Repeating notation: ${repeatingInfo.nonRepeating}(${repeatingInfo.repeating})`)
    } else {
      steps.push(`Result: ${roundedDecimal}`)
    }

    // Create repeating notation string
    let repeatingNotation = ""
    if (repeatingInfo.isRepeating) {
      repeatingNotation = `${repeatingInfo.nonRepeating}${repeatingInfo.repeating
        .split("")
        .map((d) => d + "̅")
        .join("")}`
    }

    setResult({
      decimal: roundedDecimal,
      exactDecimal: exactDecimalValue.toString(),
      isRepeating: repeatingInfo.isRepeating,
      repeatingPart: repeatingInfo.repeating,
      nonRepeatingPart: repeatingInfo.nonRepeating,
      repeatingNotation,
      steps,
    })
  }

  const handleReset = () => {
    setNumerator("")
    setDenominator("")
    setWholeNumber("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.isRepeating ? `${result.nonRepeatingPart}(${result.repeatingPart}) repeating` : result.decimal
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      const whole = inputMode === "mixed" && wholeNumber ? wholeNumber + "\\," : ""
      const latex = `\\frac{${numerator}}{${denominator}} = ${result.isRepeating ? `${result.nonRepeatingPart}\\overline{${result.repeatingPart}}` : result.decimal}`
      await navigator.clipboard.writeText(latex)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const shareText = result.isRepeating
          ? `${numerator}/${denominator} = ${result.nonRepeatingPart}(${result.repeatingPart}) repeating`
          : `${numerator}/${denominator} = ${result.decimal}`
        await navigator.share({
          title: "Fraction to Decimal Conversion",
          text: `I converted a fraction to decimal using CalcHub! ${shareText}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Divide className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Fraction to Decimal</CardTitle>
                    <CardDescription>Convert fractions to decimal numbers</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={() => {
                      setInputMode(inputMode === "simple" ? "mixed" : "simple")
                      setWholeNumber("")
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "mixed" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "simple" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Simple
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "mixed" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Mixed
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Fraction Input */}
                <div className="space-y-2">
                  <Label>Fraction</Label>
                  <div className="flex items-center gap-2">
                    {inputMode === "mixed" && (
                      <Input
                        type="number"
                        placeholder="Whole"
                        value={wholeNumber}
                        onChange={(e) => setWholeNumber(e.target.value)}
                        className="w-20"
                      />
                    )}
                    <div className="flex-1 flex flex-col items-center gap-1">
                      <Input
                        type="number"
                        placeholder="Numerator"
                        value={numerator}
                        onChange={(e) => setNumerator(e.target.value)}
                        className="text-center"
                      />
                      <div className="w-full h-0.5 bg-foreground" />
                      <Input
                        type="number"
                        placeholder="Denominator"
                        value={denominator}
                        onChange={(e) => setDenominator(e.target.value)}
                        className="text-center"
                      />
                    </div>
                  </div>
                </div>

                {/* Options */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="precision">Decimal Places</Label>
                    <Select value={precision} onValueChange={setPrecision}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="6">6</SelectItem>
                        <SelectItem value="8">8</SelectItem>
                        <SelectItem value="10">10</SelectItem>
                        <SelectItem value="15">15</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="repeating">Detect Repeating Decimals</Label>
                    <Switch id="repeating" checked={detectRepeating} onCheckedChange={setDetectRepeating} />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="steps">Show Steps</Label>
                    <Switch id="steps" checked={showSteps} onCheckedChange={setShowSteps} />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDecimal} className="w-full" size="lg">
                  Convert to Decimal
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Decimal Equivalent</p>
                      <p className="text-4xl font-bold text-blue-600 mb-2 font-mono">
                        {result.isRepeating ? (
                          <>
                            {result.nonRepeatingPart}
                            <span className="border-t-2 border-blue-600">{result.repeatingPart}</span>
                          </>
                        ) : (
                          result.decimal
                        )}
                      </p>
                      {result.isRepeating && (
                        <p className="text-sm text-blue-700">
                          Repeating: {result.nonRepeatingPart}({result.repeatingPart})...
                        </p>
                      )}
                    </div>

                    {/* Step-by-step */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 p-3 bg-white/70 rounded-lg">
                        <p className="font-semibold text-sm mb-2">Step-by-Step:</p>
                        <div className="space-y-1">
                          {result.steps.map((step, index) => (
                            <p key={index} className="text-sm text-muted-foreground font-mono">
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {[
                      { fraction: "1/2", decimal: "0.5" },
                      { fraction: "1/3", decimal: "0.333..." },
                      { fraction: "1/4", decimal: "0.25" },
                      { fraction: "1/5", decimal: "0.2" },
                      { fraction: "1/6", decimal: "0.1666..." },
                      { fraction: "1/8", decimal: "0.125" },
                      { fraction: "2/3", decimal: "0.666..." },
                      { fraction: "3/4", decimal: "0.75" },
                      { fraction: "7/8", decimal: "0.875" },
                    ].map((item) => (
                      <div key={item.fraction} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <span className="font-medium font-mono">{item.fraction}</span>
                        <span className="text-muted-foreground font-mono">{item.decimal}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conversion Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Decimal = Numerator ÷ Denominator</p>
                  </div>
                  <p>
                    <strong>For mixed numbers:</strong> First convert to improper fraction by multiplying the whole
                    number by the denominator and adding the numerator.
                  </p>
                  <p>
                    <strong>Repeating decimals:</strong> Some fractions produce decimals that repeat indefinitely. We
                    detect these patterns and show them with an overline or parentheses.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Simple:</strong> Enter numerator and denominator (e.g., 3/4)
                  </p>
                  <p>
                    <strong>Mixed:</strong> Enter whole number, numerator, and denominator (e.g., 2 1/4)
                  </p>
                  <p>
                    <strong>Negative:</strong> Use negative sign on numerator or whole number
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Fraction to Decimal Conversion?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Fraction to decimal conversion is the process of transforming a fraction (a ratio of two integers)
                  into its equivalent decimal representation. This is achieved by dividing the numerator by the
                  denominator. For example, the fraction 3/4 becomes 0.75 when converted to decimal form.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding how to convert between fractions and decimals is essential in mathematics, science,
                  engineering, and everyday life. Decimals are often more practical for calculations, comparisons, and
                  measurements, while fractions can represent exact values that decimals cannot (like 1/3).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Decimal Results</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Terminating Decimals</h4>
                    <p className="text-green-700 text-sm">
                      These decimals end after a finite number of digits. They occur when the denominator (in lowest
                      terms) has only 2 and 5 as prime factors. Examples: 1/4 = 0.25, 3/8 = 0.375
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Repeating Decimals</h4>
                    <p className="text-blue-700 text-sm">
                      These decimals have a pattern that repeats infinitely. They occur when the denominator has prime
                      factors other than 2 and 5. Examples: 1/3 = 0.333..., 2/7 = 0.285714285714...
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-muted-foreground" />
                  <CardTitle className="text-base">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Fraction to decimal conversions are based on exact division. Repeating decimals may be rounded
                  according to specified precision. For critical applications requiring exact values, consider using
                  fractions or symbolic computation.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
