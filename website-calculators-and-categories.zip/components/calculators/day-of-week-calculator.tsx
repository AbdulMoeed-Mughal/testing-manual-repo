"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, CalendarDays } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface DayResult {
  dayName: string
  isWeekend: boolean
  dayNumber: number
}

export function DayOfWeekCalculator() {
  const [selectedDate, setSelectedDate] = useState("")
  const [result, setResult] = useState<DayResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDayOfWeek = () => {
    setError("")
    setResult(null)

    if (!selectedDate) {
      setError("Please select a date")
      return
    }

    const date = new Date(selectedDate)
    if (isNaN(date.getTime())) {
      setError("Invalid date selected")
      return
    }

    const dayNumber = date.getDay()
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    const dayName = dayNames[dayNumber]
    const isWeekend = dayNumber === 0 || dayNumber === 6

    setResult({ dayName, isWeekend, dayNumber })
  }

  const handleReset = () => {
    setSelectedDate("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result && selectedDate) {
      const date = new Date(selectedDate)
      const formattedDate = date.toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      })
      await navigator.clipboard.writeText(`${formattedDate} - ${result.dayName}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && selectedDate && navigator.share) {
      try {
        const date = new Date(selectedDate)
        const formattedDate = date.toLocaleDateString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric",
        })
        await navigator.share({
          title: "Day of Week",
          text: `${formattedDate} falls on ${result.dayName}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Day of Week Calculator</CardTitle>
                    <CardDescription>Find the day of the week for any date</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="date">Select Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min="1900-01-01"
                    max="2100-12-31"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDayOfWeek} className="w-full" size="lg">
                  Find Day of Week
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                      result.isWeekend
                        ? "bg-purple-50 border-purple-200"
                        : "bg-cyan-50 border-cyan-200"
                    }`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Day of the Week</p>
                      <p
                        className={`text-4xl font-bold mb-2 ${
                          result.isWeekend ? "text-purple-600" : "text-cyan-600"
                        }`}
                      >
                        {result.dayName}
                      </p>
                      <p
                        className={`text-sm font-semibold ${
                          result.isWeekend ? "text-purple-600" : "text-cyan-600"
                        }`}
                      >
                        {result.isWeekend ? "Weekend" : "Weekday"}
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Days of the Week</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Monday - Friday</span>
                      <span className="text-sm text-cyan-600">Weekdays</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Saturday - Sunday</span>
                      <span className="text-sm text-purple-600">Weekend</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Facts</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    The day of the week is calculated using the <strong>Gregorian calendar</strong>, which is the
                    internationally accepted civil calendar.
                  </p>
                  <p>
                    Each week has <strong>7 days</strong>, and the pattern repeats infinitely. The calculator uses
                    Zeller's congruence algorithm for accurate results.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Day of Week */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Day of Week Calculation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Day of week calculation is the process of determining which day of the week (Sunday, Monday,
                  Tuesday, etc.) corresponds to a specific date. This calculation is essential for scheduling,
                  planning, historical research, and understanding calendar patterns. The algorithm takes into
                  account leap years, varying month lengths, and century adjustments to provide accurate results for
                  any date in the Gregorian calendar system.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The most common algorithm used is Zeller's congruence, developed by Christian Zeller in the 19th
                  century. It uses a mathematical formula that considers the day, month, year, and century to
                  calculate the day of the week. This method works for both historical dates and future dates,
                  making it a versatile tool for various applications from genealogy research to event planning.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Knowing the day of the week for specific dates has numerous practical applications. Event planners
                  use it to schedule weddings, conferences, and celebrations on preferred days. Historical
                  researchers verify dates and timelines in documents and records. Business professionals plan
                  meetings and deadlines around weekdays and weekends.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Personal planning also benefits from day of week calculations. You can determine what day your
                  birthday falls on in future years, plan vacations around weekends, calculate school schedules, and
                  understand patterns in historical events. The ability to quickly determine the day of the week for
                  any date makes scheduling and time management more efficient and accurate.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-cyan-200 bg-cyan-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-cyan-900">
                  <strong>Note:</strong> Day of the week calculations are based on entered dates and the Gregorian
                  calendar system. Results may vary depending on calendar type and historical calendar adjustments.
                  For dates before 1582, consider using the Julian calendar system for historical accuracy.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
