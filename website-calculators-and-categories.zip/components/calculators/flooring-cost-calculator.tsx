"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Home,
  Info,
  DollarSign,
  Ruler,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface FlooringResult {
  floorArea: number
  totalAreaWithWaste: number
  materialCost: number
  installationCost: number
  subtotal: number
  taxAmount: number
  totalCost: number
  areaUnit: string
  wasteArea: number
}

export function FlooringCostCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [materialPrice, setMaterialPrice] = useState("")
  const [installationPrice, setInstallationPrice] = useState("")
  const [wastePercent, setWastePercent] = useState("10")
  const [taxRate, setTaxRate] = useState("")
  const [result, setResult] = useState<FlooringResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculate = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const materialPriceNum = Number.parseFloat(materialPrice)

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }

    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }

    if (isNaN(materialPriceNum) || materialPriceNum < 0) {
      setError("Please enter a valid material price")
      return
    }

    const installationPriceNum = Number.parseFloat(installationPrice) || 0
    const wastePercentNum = Number.parseFloat(wastePercent) || 0
    const taxRateNum = Number.parseFloat(taxRate) || 0

    if (wastePercentNum < 0) {
      setError("Waste percentage cannot be negative")
      return
    }

    if (taxRateNum < 0) {
      setError("Tax rate cannot be negative")
      return
    }

    // Calculate floor area
    const floorArea = lengthNum * widthNum

    // Calculate waste area and total area with waste
    const wasteArea = floorArea * (wastePercentNum / 100)
    const totalAreaWithWaste = floorArea + wasteArea

    // Calculate costs
    const materialCost = totalAreaWithWaste * materialPriceNum
    const installationCost = floorArea * installationPriceNum
    const subtotal = materialCost + installationCost
    const taxAmount = subtotal * (taxRateNum / 100)
    const totalCost = subtotal + taxAmount

    const areaUnit = unitSystem === "metric" ? "m²" : "ft²"

    setResult({
      floorArea: Math.round(floorArea * 100) / 100,
      totalAreaWithWaste: Math.round(totalAreaWithWaste * 100) / 100,
      materialCost: Math.round(materialCost * 100) / 100,
      installationCost: Math.round(installationCost * 100) / 100,
      subtotal: Math.round(subtotal * 100) / 100,
      taxAmount: Math.round(taxAmount * 100) / 100,
      totalCost: Math.round(totalCost * 100) / 100,
      areaUnit,
      wasteArea: Math.round(wasteArea * 100) / 100,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setMaterialPrice("")
    setInstallationPrice("")
    setWastePercent("10")
    setTaxRate("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Flooring Cost Estimate:
Floor Area: ${result.floorArea} ${result.areaUnit}
Material Area (with ${wastePercent}% waste): ${result.totalAreaWithWaste} ${result.areaUnit}
Material Cost: $${result.materialCost.toLocaleString()}
Installation Cost: $${result.installationCost.toLocaleString()}
Subtotal: $${result.subtotal.toLocaleString()}
Tax: $${result.taxAmount.toLocaleString()}
Total Cost: $${result.totalCost.toLocaleString()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Flooring Cost Estimate",
          text: `My flooring project: ${result.floorArea} ${result.areaUnit} floor area, Total Cost: $${result.totalCost.toLocaleString()}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setResult(null)
    setError("")
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"
  const areaUnit = unitSystem === "metric" ? "m²" : "ft²"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Flooring Cost Calculator</CardTitle>
                    <CardDescription>Estimate total flooring project cost</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Dimensions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="length">Length ({lengthUnit})</Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "5" : "16"}`}
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="width">Width ({lengthUnit})</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder={`e.g., ${unitSystem === "metric" ? "4" : "12"}`}
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Cost Inputs */}
                <div className="space-y-2">
                  <Label htmlFor="materialPrice">Material Cost (per {areaUnit})</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="materialPrice"
                      type="number"
                      placeholder="e.g., 25"
                      value={materialPrice}
                      onChange={(e) => setMaterialPrice(e.target.value)}
                      min="0"
                      step="0.01"
                      className="pl-9"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="installationPrice">Installation Cost (per {areaUnit}) - Optional</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="installationPrice"
                      type="number"
                      placeholder="e.g., 10"
                      value={installationPrice}
                      onChange={(e) => setInstallationPrice(e.target.value)}
                      min="0"
                      step="0.01"
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* Waste and Tax */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="wastePercent">Waste (%)</Label>
                    <Input
                      id="wastePercent"
                      type="number"
                      placeholder="e.g., 10"
                      value={wastePercent}
                      onChange={(e) => setWastePercent(e.target.value)}
                      min="0"
                      step="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="taxRate">Tax Rate (%) - Optional</Label>
                    <Input
                      id="taxRate"
                      type="number"
                      placeholder="e.g., 8"
                      value={taxRate}
                      onChange={(e) => setTaxRate(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Cost
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Estimated Cost</p>
                      <p className="text-4xl font-bold text-amber-600">${result.totalCost.toLocaleString()}</p>
                    </div>

                    {/* Cost Breakdown */}
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between p-2 bg-white/60 rounded">
                        <span>Floor Area</span>
                        <span className="font-medium">
                          {result.floorArea} {result.areaUnit}
                        </span>
                      </div>
                      <div className="flex justify-between p-2 bg-white/60 rounded">
                        <span>Material Area (incl. waste)</span>
                        <span className="font-medium">
                          {result.totalAreaWithWaste} {result.areaUnit}
                        </span>
                      </div>
                      <div className="flex justify-between p-2 bg-white/60 rounded">
                        <span>Material Cost</span>
                        <span className="font-medium">${result.materialCost.toLocaleString()}</span>
                      </div>
                      {result.installationCost > 0 && (
                        <div className="flex justify-between p-2 bg-white/60 rounded">
                          <span>Installation Cost</span>
                          <span className="font-medium">${result.installationCost.toLocaleString()}</span>
                        </div>
                      )}
                      <div className="flex justify-between p-2 bg-white/60 rounded">
                        <span>Subtotal</span>
                        <span className="font-medium">${result.subtotal.toLocaleString()}</span>
                      </div>
                      {result.taxAmount > 0 && (
                        <div className="flex justify-between p-2 bg-white/60 rounded">
                          <span>Tax ({taxRate}%)</span>
                          <span className="font-medium">${result.taxAmount.toLocaleString()}</span>
                        </div>
                      )}
                    </div>

                    {/* Expandable Steps */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 flex items-center justify-center gap-1 text-sm text-amber-700 hover:text-amber-800"
                    >
                      {showSteps ? (
                        <>
                          Hide calculation steps <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show calculation steps <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/80 rounded-lg text-sm space-y-2">
                        <p className="font-medium text-amber-800">Step-by-Step Calculation:</p>
                        <div className="space-y-1 text-muted-foreground">
                          <p>
                            1. Floor Area = {length} × {width} = {result.floorArea} {result.areaUnit}
                          </p>
                          <p>
                            2. Waste Area = {result.floorArea} × {wastePercent}% = {result.wasteArea} {result.areaUnit}
                          </p>
                          <p>
                            3. Total Material Area = {result.floorArea} + {result.wasteArea} ={" "}
                            {result.totalAreaWithWaste} {result.areaUnit}
                          </p>
                          <p>
                            4. Material Cost = {result.totalAreaWithWaste} × ${materialPrice} = $
                            {result.materialCost.toLocaleString()}
                          </p>
                          {result.installationCost > 0 && (
                            <p>
                              5. Installation Cost = {result.floorArea} × ${installationPrice} = $
                              {result.installationCost.toLocaleString()}
                            </p>
                          )}
                          <p>
                            {result.installationCost > 0 ? "6" : "5"}. Subtotal = $
                            {result.materialCost.toLocaleString()} + ${result.installationCost.toLocaleString()} = $
                            {result.subtotal.toLocaleString()}
                          </p>
                          {result.taxAmount > 0 && (
                            <p>
                              {result.installationCost > 0 ? "7" : "6"}. Tax = ${result.subtotal.toLocaleString()} ×{" "}
                              {taxRate}% = ${result.taxAmount.toLocaleString()}
                            </p>
                          )}
                          <p className="font-medium text-amber-800">
                            Total = ${result.subtotal.toLocaleString()} + ${result.taxAmount.toLocaleString()} = $
                            {result.totalCost.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Material Costs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span>Laminate</span>
                      <span className="font-medium">$2–8 per ft² / $20–85 per m²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span>Vinyl / LVP</span>
                      <span className="font-medium">$2–7 per ft² / $20–75 per m²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span>Hardwood</span>
                      <span className="font-medium">$6–15 per ft² / $65–160 per m²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span>Tile (Ceramic)</span>
                      <span className="font-medium">$1–10 per ft² / $10–110 per m²</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span>Carpet</span>
                      <span className="font-medium">$2–8 per ft² / $20–85 per m²</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recommended Waste %</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="text-green-700">Straight Lay (Simple Room)</span>
                      <span className="font-medium text-green-600">5–7%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="text-yellow-700">Standard Room</span>
                      <span className="font-medium text-yellow-600">10%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="text-orange-700">Diagonal / Pattern</span>
                      <span className="font-medium text-orange-600">15%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="text-red-700">Complex Layout</span>
                      <span className="font-medium text-red-600">20%+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual costs may vary depending on material type, labor rates, subfloor
                        condition, and local market prices. Get quotes from contractors for accurate pricing.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Flooring Costs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Flooring costs can vary significantly based on the type of material, installation complexity, and
                  regional labor rates. Understanding the different cost components helps you budget accurately for your
                  flooring project. The total cost typically includes material costs, installation labor, waste
                  allowance, and applicable taxes.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Material costs are usually calculated per square foot or square meter and can range from
                  budget-friendly options like laminate to premium choices like hardwood or natural stone. Installation
                  costs depend on the flooring type and complexity, with some materials like vinyl being DIY-friendly
                  while others like hardwood require professional installation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Flooring Costs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold mb-2">Material Type</h4>
                    <p className="text-sm text-muted-foreground">
                      Hardwood and natural stone cost more than laminate or vinyl. Quality grades within each category
                      also affect pricing significantly.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold mb-2">Room Complexity</h4>
                    <p className="text-sm text-muted-foreground">
                      Irregular shapes, closets, doorways, and transitions increase labor time and waste percentage.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold mb-2">Subfloor Condition</h4>
                    <p className="text-sm text-muted-foreground">
                      Damaged or uneven subfloors may require repair, leveling, or moisture barriers before
                      installation.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold mb-2">Removal & Disposal</h4>
                    <p className="text-sm text-muted-foreground">
                      Removing existing flooring adds to labor costs. Some materials like tile are more expensive to
                      remove.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimates</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="font-medium text-foreground">Measure accurately:</span>
                    <span>Measure each room separately and add them together for irregular spaces.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-medium text-foreground">Account for waste:</span>
                    <span>Always include waste allowance (5–15%) for cuts, mistakes, and future repairs.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-medium text-foreground">Get multiple quotes:</span>
                    <span>Compare at least 3 contractor quotes to ensure competitive pricing.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-medium text-foreground">Consider hidden costs:</span>
                    <span>Budget for underlayment, transitions, baseboards, and subfloor repairs.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-medium text-foreground">Buy extra material:</span>
                    <span>Order 10–15% extra to have matching material for future repairs.</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
