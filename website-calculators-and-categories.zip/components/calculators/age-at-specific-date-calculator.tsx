"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, Clock } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface AgeResult {
  years: number
  months: number
  days: number
  totalDays: number
  totalMonths: number
  targetDate: string
}

export function AgeAtSpecificDateCalculator() {
  const [birthDate, setBirthDate] = useState("")
  const [targetDate, setTargetDate] = useState("")
  const [result, setResult] = useState<AgeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateAge = () => {
    setError("")
    setResult(null)

    if (!birthDate) {
      setError("Please enter a date of birth")
      return
    }

    if (!targetDate) {
      setError("Please enter a target date")
      return
    }

    const birth = new Date(birthDate)
    const target = new Date(targetDate)

    if (isNaN(birth.getTime()) || isNaN(target.getTime())) {
      setError("Invalid date entered")
      return
    }

    if (birth > target) {
      setError("Date of birth cannot be after target date")
      return
    }

    // Calculate age
    let years = target.getFullYear() - birth.getFullYear()
    let months = target.getMonth() - birth.getMonth()
    let days = target.getDate() - birth.getDate()

    if (days < 0) {
      months--
      const prevMonth = new Date(target.getFullYear(), target.getMonth(), 0)
      days += prevMonth.getDate()
    }

    if (months < 0) {
      years--
      months += 12
    }

    // Calculate total days
    const timeDiff = target.getTime() - birth.getTime()
    const totalDays = Math.floor(timeDiff / (1000 * 60 * 60 * 24))

    // Calculate total months
    const totalMonths = years * 12 + months

    const formattedDate = target.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    setResult({
      years,
      months,
      days,
      totalDays,
      totalMonths,
      targetDate: formattedDate,
    })
  }

  const handleReset = () => {
    setBirthDate("")
    setTargetDate("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Age on ${result.targetDate}: ${result.years} years, ${result.months} months, ${result.days} days`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Age at Specific Date",
          text: `Calculated age on ${result.targetDate}: ${result.years} years, ${result.months} months, ${result.days} days`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Age at Specific Date Calculator</CardTitle>
                    <CardDescription>Calculate age on any target date</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="birthDate">Date of Birth</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    max="2100-12-31"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="targetDate">Target Date</Label>
                  <Input
                    id="targetDate"
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    max="2100-12-31"
                  />
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                <Button onClick={calculateAge} className="w-full" size="lg">
                  Calculate Age
                </Button>

                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Age on</p>
                      <p className="text-base font-semibold text-cyan-700 mb-3">{result.targetDate}</p>
                      <div className="flex items-center justify-center gap-2 flex-wrap">
                        <div className="text-center">
                          <p className="text-4xl font-bold text-cyan-600">{result.years}</p>
                          <p className="text-sm text-cyan-600">years</p>
                        </div>
                        <span className="text-2xl text-cyan-600">·</span>
                        <div className="text-center">
                          <p className="text-4xl font-bold text-cyan-600">{result.months}</p>
                          <p className="text-sm text-cyan-600">months</p>
                        </div>
                        <span className="text-2xl text-cyan-600">·</span>
                        <div className="text-center">
                          <p className="text-4xl font-bold text-cyan-600">{result.days}</p>
                          <p className="text-sm text-cyan-600">days</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 pt-3 border-t border-cyan-200">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Total Months:</span>
                        <span className="font-medium text-cyan-700">{result.totalMonths} months</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Total Days:</span>
                        <span className="font-medium text-cyan-700">{result.totalDays.toLocaleString()} days</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Use Cases</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-700 mb-1">Eligibility Verification</p>
                    <p className="text-sm text-cyan-600">Check age for legal requirements</p>
                  </div>
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-700 mb-1">Event Planning</p>
                    <p className="text-sm text-cyan-600">Determine age at future events</p>
                  </div>
                  <div className="p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                    <p className="font-medium text-cyan-700 mb-1">Historical Reference</p>
                    <p className="text-sm text-cyan-600">Calculate age in the past</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Tips</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>• Target date can be past or future</p>
                  <p>• Useful for planning milestones</p>
                  <p>• Accounts for leap years</p>
                  <p>• Accurate to the day</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Age at a Specific Date?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Age at a specific date refers to calculating how old someone was, is, or will be on a particular date
                  in time. Unlike calculating current age, this method allows you to determine age on any past or future
                  date, making it invaluable for planning, verification, and historical reference. This calculation is
                  essential when you need to know someone's exact age on a specific occasion or event.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This type of calculation is particularly useful in legal, educational, and administrative contexts where
                  age requirements are tied to specific dates. For example, determining if someone met the minimum age
                  requirement for an election, calculating age for insurance policies, or verifying eligibility for
                  age-restricted activities on particular dates.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Age at a Specific Date</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate age at a specific date, you subtract the date of birth from the target date, just as you
                  would when calculating current age, but using the specified date instead of today. The calculation
                  accounts for years, months, and days, ensuring precision. For example, if someone was born on June 10,
                  2000, and you want to know their age on December 25, 2025, you would calculate the full years (25),
                  remaining months (6), and remaining days (15).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The process requires careful attention to calendar irregularities such as leap years and varying month
                  lengths. When the target date is in the past, you're calculating historical age; when it's in the
                  future, you're projecting age. This flexibility makes the calculation useful for a wide range of
                  planning and verification scenarios, from retirement planning to academic enrollment.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Common Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Age at a specific date calculations are widely used in legal and administrative settings. Courts use
                  these calculations to determine if defendants were minors at the time of an offense. Insurance
                  companies calculate age on policy effective dates to determine premiums. Educational institutions
                  verify age requirements for enrollment, ensuring students meet minimum or maximum age criteria on
                  specific cutoff dates.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In personal planning, these calculations help with milestone celebrations, retirement planning, and
                  travel arrangements that have age restrictions. Historical researchers use them to understand the ages
                  of historical figures during significant events. Sports organizations calculate age for competition
                  categories based on specific tournament dates. The versatility of this calculation makes it an
                  essential tool for both professional and personal use.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <div className="mt-8 p-4 bg-muted rounded-lg border">
            <p className="text-sm text-muted-foreground text-center">
              <strong>Note:</strong> Age calculations are based on entered dates and may vary slightly due to leap years
              and calendar differences. For legal or official purposes, always verify age calculations with relevant
              authorities.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
