"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  Activity,
  Target,
  AlertTriangle,
  Scale,
  Heart,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"
type Gender = "male" | "female"
type Method = "navy" | "bmi"

interface BodyFatResult {
  bodyFatPercentage: number
  fatMass: number
  leanMass: number
  category: string
  color: string
  bgColor: string
}

const maleCategories = [
  { min: 0, max: 5.99, label: "Essential Fat", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" },
  { min: 6, max: 13.99, label: "Athletes", color: "text-green-600", bgColor: "bg-green-50 border-green-200" },
  { min: 14, max: 17.99, label: "Fitness", color: "text-emerald-600", bgColor: "bg-emerald-50 border-emerald-200" },
  { min: 18, max: 24.99, label: "Average", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" },
  { min: 25, max: 100, label: "Obese", color: "text-red-600", bgColor: "bg-red-50 border-red-200" },
]

const femaleCategories = [
  { min: 0, max: 13.99, label: "Essential Fat", color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" },
  { min: 14, max: 20.99, label: "Athletes", color: "text-green-600", bgColor: "bg-green-50 border-green-200" },
  { min: 21, max: 24.99, label: "Fitness", color: "text-emerald-600", bgColor: "bg-emerald-50 border-emerald-200" },
  { min: 25, max: 31.99, label: "Average", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" },
  { min: 32, max: 100, label: "Obese", color: "text-red-600", bgColor: "bg-red-50 border-red-200" },
]

export function BodyFatCalculator() {
  const [method, setMethod] = useState<Method>("navy")
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [gender, setGender] = useState<Gender>("male")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [heightFeet, setHeightFeet] = useState("")
  const [heightInches, setHeightInches] = useState("")
  const [neck, setNeck] = useState("")
  const [waist, setWaist] = useState("")
  const [hip, setHip] = useState("")
  const [result, setResult] = useState<BodyFatResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const getCategory = (bodyFat: number, gender: Gender) => {
    const categories = gender === "male" ? maleCategories : femaleCategories
    for (const cat of categories) {
      if (bodyFat >= cat.min && bodyFat <= cat.max) {
        return { label: cat.label, color: cat.color, bgColor: cat.bgColor }
      }
    }
    return { label: "Unknown", color: "text-gray-600", bgColor: "bg-gray-50 border-gray-200" }
  }

  const calculateBodyFat = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    const weightNum = Number.parseFloat(weight)

    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 120) {
      setError("Please enter a valid age between 1 and 120")
      return
    }

    if (isNaN(weightNum) || weightNum <= 0) {
      setError("Please enter a valid weight greater than 0")
      return
    }

    let heightInCm: number
    if (unitSystem === "metric") {
      heightInCm = Number.parseFloat(heightCm)
      if (isNaN(heightInCm) || heightInCm <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
    } else {
      const feet = Number.parseFloat(heightFeet) || 0
      const inches = Number.parseFloat(heightInches) || 0
      if (feet <= 0 && inches <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
      heightInCm = (feet * 12 + inches) * 2.54
    }

    const weightInKg = unitSystem === "imperial" ? weightNum * 0.453592 : weightNum

    let bodyFatPercentage: number

    if (method === "navy") {
      let neckCm = Number.parseFloat(neck)
      let waistCm = Number.parseFloat(waist)
      let hipCm = Number.parseFloat(hip)

      if (isNaN(neckCm) || neckCm <= 0) {
        setError("Please enter a valid neck circumference")
        return
      }
      if (isNaN(waistCm) || waistCm <= 0) {
        setError("Please enter a valid waist circumference")
        return
      }
      if (gender === "female" && (isNaN(hipCm) || hipCm <= 0)) {
        setError("Please enter a valid hip circumference")
        return
      }

      // Convert to cm if imperial
      if (unitSystem === "imperial") {
        neckCm = neckCm * 2.54
        waistCm = waistCm * 2.54
        hipCm = hipCm * 2.54
      }

      if (waistCm <= neckCm) {
        setError("Waist circumference must be greater than neck circumference")
        return
      }

      // US Navy Formula
      if (gender === "male") {
        bodyFatPercentage = 86.01 * Math.log10(waistCm - neckCm) - 70.041 * Math.log10(heightInCm) + 36.76
      } else {
        bodyFatPercentage = 163.205 * Math.log10(waistCm + hipCm - neckCm) - 97.684 * Math.log10(heightInCm) - 78.387
      }
    } else {
      // BMI-based method
      const heightInM = heightInCm / 100
      const bmi = weightInKg / (heightInM * heightInM)

      if (gender === "male") {
        bodyFatPercentage = 1.2 * bmi + 0.23 * ageNum - 16.2
      } else {
        bodyFatPercentage = 1.2 * bmi + 0.23 * ageNum - 5.4
      }
    }

    bodyFatPercentage = Math.round(bodyFatPercentage * 10) / 10

    // Ensure body fat is within reasonable bounds
    if (bodyFatPercentage < 0) bodyFatPercentage = 0
    if (bodyFatPercentage > 60) bodyFatPercentage = 60

    const fatMass = Math.round(((weightInKg * bodyFatPercentage) / 100) * 10) / 10
    const leanMass = Math.round((weightInKg - fatMass) * 10) / 10

    const category = getCategory(bodyFatPercentage, gender)

    setResult({
      bodyFatPercentage,
      fatMass: unitSystem === "imperial" ? Math.round(fatMass * 2.20462 * 10) / 10 : fatMass,
      leanMass: unitSystem === "imperial" ? Math.round(leanMass * 2.20462 * 10) / 10 : leanMass,
      category: category.label,
      color: category.color,
      bgColor: category.bgColor,
    })
  }

  const handleReset = () => {
    setAge("")
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setNeck("")
    setWaist("")
    setHip("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My Body Fat: ${result.bodyFatPercentage}% (${result.category}) | Fat Mass: ${result.fatMass}${unitSystem === "metric" ? "kg" : "lb"} | Lean Mass: ${result.leanMass}${unitSystem === "metric" ? "kg" : "lb"}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Body Fat Result",
          text: `I calculated my body fat using CalcHub! My body fat is ${result.bodyFatPercentage}% (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setWeight("")
    setHeightCm("")
    setHeightFeet("")
    setHeightInches("")
    setNeck("")
    setWaist("")
    setHip("")
    setResult(null)
    setError("")
  }

  const currentCategories = gender === "male" ? maleCategories : femaleCategories

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Target className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Body Fat Calculator</CardTitle>
                    <CardDescription>Calculate your body fat percentage</CardDescription>
                  </div>
                </div>

                {/* Method Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Method</span>
                  <button
                    onClick={() => {
                      setMethod((prev) => (prev === "navy" ? "bmi" : "navy"))
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        method === "bmi" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "navy" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      US Navy
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "bmi" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      BMI-Based
                    </span>
                  </button>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Gender Selection */}
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => {
                        setGender("male")
                        setResult(null)
                      }}
                      className={`py-3 px-4 rounded-lg border-2 font-medium transition-all ${
                        gender === "male"
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-muted-foreground/20 hover:border-muted-foreground/40"
                      }`}
                    >
                      Male
                    </button>
                    <button
                      onClick={() => {
                        setGender("female")
                        setResult(null)
                      }}
                      className={`py-3 px-4 rounded-lg border-2 font-medium transition-all ${
                        gender === "female"
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-muted-foreground/20 hover:border-muted-foreground/40"
                      }`}
                    >
                      Female
                    </button>
                  </div>
                </div>

                {/* Age Input */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>

                {/* Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder={`Enter weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Height Input */}
                {unitSystem === "metric" ? (
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter height in centimeters"
                      value={heightCm}
                      onChange={(e) => setHeightCm(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Height</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="number"
                        placeholder="Feet"
                        value={heightFeet}
                        onChange={(e) => setHeightFeet(e.target.value)}
                        min="0"
                      />
                      <Input
                        type="number"
                        placeholder="Inches"
                        value={heightInches}
                        onChange={(e) => setHeightInches(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                )}

                {/* Navy Method specific inputs */}
                {method === "navy" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="neck">Neck Circumference ({unitSystem === "metric" ? "cm" : "in"})</Label>
                      <Input
                        id="neck"
                        type="number"
                        placeholder={`Measure at narrowest point`}
                        value={neck}
                        onChange={(e) => setNeck(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="waist">Waist Circumference ({unitSystem === "metric" ? "cm" : "in"})</Label>
                      <Input
                        id="waist"
                        type="number"
                        placeholder={gender === "male" ? "Measure at navel level" : "Measure at narrowest point"}
                        value={waist}
                        onChange={(e) => setWaist(e.target.value)}
                        min="0"
                        step="0.1"
                      />
                    </div>

                    {gender === "female" && (
                      <div className="space-y-2">
                        <Label htmlFor="hip">Hip Circumference ({unitSystem === "metric" ? "cm" : "in"})</Label>
                        <Input
                          id="hip"
                          type="number"
                          placeholder="Measure at widest point"
                          value={hip}
                          onChange={(e) => setHip(e.target.value)}
                          min="0"
                          step="0.1"
                        />
                      </div>
                    )}
                  </>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBodyFat} className="w-full" size="lg">
                  Calculate Body Fat
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Body Fat</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.bodyFatPercentage}%</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Body Composition */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="bg-white/60 rounded-lg p-3 text-center">
                        <p className="text-xs text-muted-foreground">Fat Mass</p>
                        <p className="text-lg font-bold text-foreground">
                          {result.fatMass} {unitSystem === "metric" ? "kg" : "lb"}
                        </p>
                      </div>
                      <div className="bg-white/60 rounded-lg p-3 text-center">
                        <p className="text-xs text-muted-foreground">Lean Mass</p>
                        <p className="text-lg font-bold text-foreground">
                          {result.leanMass} {unitSystem === "metric" ? "kg" : "lb"}
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Body Fat Categories ({gender === "male" ? "Men" : "Women"})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {currentCategories.map((cat) => (
                      <div
                        key={cat.label}
                        className={`flex items-center justify-between p-3 rounded-lg ${cat.bgColor}`}
                      >
                        <span className={`font-medium ${cat.color}`}>{cat.label}</span>
                        <span className={`text-sm ${cat.color}`}>
                          {cat.min === 0
                            ? `< ${cat.max + 1}%`
                            : cat.max === 100
                              ? `≥ ${cat.min}%`
                              : `${cat.min} – ${cat.max}%`}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">
                    {method === "navy" ? "US Navy Formula" : "BMI-Based Formula"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  {method === "navy" ? (
                    <>
                      <div className="p-4 bg-muted rounded-lg font-mono text-xs">
                        <p className="font-semibold text-foreground mb-2">Male:</p>
                        <p>BF% = 86.010 × log₁₀(waist − neck) − 70.041 × log₁₀(height) + 36.76</p>
                        <p className="font-semibold text-foreground mt-3 mb-2">Female:</p>
                        <p>BF% = 163.205 × log₁₀(waist + hip − neck) − 97.684 × log₁₀(height) − 78.387</p>
                      </div>
                      <p>Measurements in centimeters. The US Navy method is accurate to within 3-4% of DEXA scans.</p>
                    </>
                  ) : (
                    <>
                      <div className="p-4 bg-muted rounded-lg font-mono text-xs">
                        <p className="font-semibold text-foreground mb-2">Male:</p>
                        <p>BF% = (1.20 × BMI) + (0.23 × age) − 16.2</p>
                        <p className="font-semibold text-foreground mt-3 mb-2">Female:</p>
                        <p>BF% = (1.20 × BMI) + (0.23 × age) − 5.4</p>
                      </div>
                      <p>The BMI-based method is less accurate but requires fewer measurements.</p>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Body Fat Percentage */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Body Fat Percentage?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Body fat percentage is the total mass of fat divided by total body mass, expressed as a percentage.
                  Unlike weight alone, body fat percentage provides a more accurate picture of your body composition and
                  overall health. Two people can weigh the same but have vastly different body fat percentages depending
                  on their muscle mass, bone density, and fat distribution. Understanding your body fat percentage helps
                  you set realistic fitness goals and track meaningful progress beyond the scale.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Fat serves essential functions in the body including energy storage, hormone production, organ
                  protection, and temperature regulation. However, excessive body fat, particularly visceral fat stored
                  around internal organs, is associated with increased risk of cardiovascular disease, type 2 diabetes,
                  certain cancers, and metabolic syndrome. Conversely, having too little body fat can lead to hormonal
                  imbalances, weakened immune function, and nutrient deficiencies. Maintaining an optimal body fat
                  percentage is crucial for both health and athletic performance.
                </p>
              </CardContent>
            </Card>

            {/* Understanding the US Navy Method */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the US Navy Method</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The US Navy body fat formula was developed by the United States Navy as a simple, reliable method for
                  assessing body composition without expensive equipment. This method uses circumference measurements at
                  specific body sites along with height to estimate body fat percentage. For men, measurements are taken
                  at the neck and waist; for women, an additional hip measurement is required. The formula has been
                  validated against hydrostatic weighing and DEXA scans, showing accuracy within 3-4% for most
                  individuals.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To get accurate measurements, use a flexible tape measure and take readings on bare skin. For the
                  neck, measure just below the larynx (Adam's apple) at the narrowest point. For the waist, men should
                  measure at the navel level, while women should measure at the narrowest point. For hips (women only),
                  measure at the widest point of the buttocks. Take each measurement twice and use the average.
                  Consistency in measurement technique is more important than absolute precision for tracking changes
                  over time.
                </p>
              </CardContent>
            </Card>

            {/* Body Fat Categories Explained */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  <CardTitle>Body Fat Categories Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Body fat categories differ between men and women due to physiological differences. Women naturally
                  carry more essential fat for reproductive functions and hormone production. Essential fat is the
                  minimum amount required for normal physiological function—approximately 2-5% for men and 10-13% for
                  women. Going below these levels can cause serious health problems including hormonal disruption, organ
                  damage, and compromised immune function.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Athletes (Men: 6-13% | Women: 14-20%)</h4>
                    <p className="text-green-700 text-sm">
                      This range is typical for competitive athletes and those engaged in intensive training. At this
                      level, muscle definition is visible and physical performance is optimized. Maintaining this range
                      long-term requires dedicated training and nutrition, and may not be sustainable or healthy for
                      everyone.
                    </p>
                  </div>
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <h4 className="font-semibold text-emerald-800 mb-2">Fitness (Men: 14-17% | Women: 21-24%)</h4>
                    <p className="text-emerald-700 text-sm">
                      The fitness category represents a healthy, athletic body composition achievable through regular
                      exercise and balanced nutrition. Most people who work out consistently fall into this range.
                      Muscle definition is apparent, and this level is associated with excellent health markers.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Average (Men: 18-24% | Women: 25-31%)</h4>
                    <p className="text-yellow-700 text-sm">
                      This range is considered acceptable and represents the average body fat percentage for moderately
                      active individuals. While not optimal for athletic performance, this range is generally healthy
                      and sustainable for most people with moderate exercise habits.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Obese (Men: 25%+ | Women: 32%+)</h4>
                    <p className="text-red-700 text-sm">
                      Body fat percentages in this range are associated with increased health risks including
                      cardiovascular disease, insulin resistance, joint problems, and certain cancers. If you fall into
                      this category, working with healthcare professionals to develop a sustainable fat loss plan is
                      recommended.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* How to Reduce Body Fat */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>How to Reduce Body Fat Effectively</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Reducing body fat requires a sustainable approach combining nutrition, exercise, and lifestyle
                  modifications. Creating a moderate caloric deficit of 300-500 calories per day promotes fat loss while
                  preserving muscle mass. Focus on whole foods including lean proteins, vegetables, fruits, whole
                  grains, and healthy fats. Protein intake of 0.7-1 gram per pound of body weight supports muscle
                  retention during weight loss. Avoid extreme diets that promise rapid results, as they often lead to
                  muscle loss and metabolic adaptation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Resistance training is crucial for maintaining and building muscle during fat loss. Aim for 2-4
                  strength training sessions per week, focusing on compound movements like squats, deadlifts, presses,
                  and rows. Add 2-3 sessions of cardiovascular exercise, mixing steady-state cardio with high-intensity
                  interval training (HIIT) for optimal fat burning. Sleep 7-9 hours per night to support hormone balance
                  and recovery. Manage stress through meditation, deep breathing, or other relaxation techniques, as
                  chronic stress elevates cortisol which promotes fat storage, particularly around the midsection.
                </p>
              </CardContent>
            </Card>

            {/* Limitations and Considerations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations and Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While body fat calculators provide useful estimates, they have limitations. The US Navy method assumes
                  typical fat distribution patterns and may be less accurate for individuals with unusual body
                  proportions, very lean athletes, or those with significant muscle mass. The BMI-based method is even
                  less precise as it doesn't account for body composition differences. For the most accurate body fat
                  measurement, consider professional methods like DEXA scans, hydrostatic weighing, or air displacement
                  plethysmography (Bod Pod).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Use this calculator as a tracking tool rather than an absolute measure. What matters most is the trend
                  over time rather than any single measurement. Take measurements consistently—same time of day, same
                  conditions—and track changes over weeks and months. Remember that body fat percentage is just one
                  metric of health. Focus on how you feel, your energy levels, physical performance, and other health
                  markers alongside body composition goals. If you have concerns about your body fat percentage or
                  health, consult with a healthcare professional or registered dietitian.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
