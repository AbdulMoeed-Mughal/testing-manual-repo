"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, Target, CheckCircle2, XCircle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

export function AttendanceCalculator() {
  const [totalClasses, setTotalClasses] = useState<string>("")
  const [classesAttended, setClassesAttended] = useState<string>("")
  const [requiredPercentage, setRequiredPercentage] = useState<string>("75")
  const [useRequirement, setUseRequirement] = useState(true)
  const [copied, setCopied] = useState(false)
  const [showBreakdown, setShowBreakdown] = useState(false)

  const total = Number.parseFloat(totalClasses) || 0
  const attended = Number.parseFloat(classesAttended) || 0
  const required = Number.parseFloat(requiredPercentage) || 75

  const isValid = total > 0 && attended >= 0 && attended <= total
  const attendancePercentage = isValid ? (attended / total) * 100 : 0
  const classesMissed = isValid ? total - attended : 0
  const isEligible = attendancePercentage >= required
  const shortfall = required - attendancePercentage
  const surplus = attendancePercentage - required

  const calculateClassesNeeded = () => {
    if (!isValid || required >= 100) return 0
    const numerator = (required * total) / 100 - attended
    const denominator = 1 - required / 100
    if (denominator <= 0) return Number.POSITIVE_INFINITY
    return Math.max(0, Math.ceil(numerator / denominator))
  }

  const calculateClassesCanMiss = () => {
    if (!isValid || required <= 0) return Number.POSITIVE_INFINITY
    const numerator = (100 * attended) / required - total
    return Math.max(0, Math.floor(numerator))
  }

  const classesNeeded = calculateClassesNeeded()
  const classesCanMiss = calculateClassesCanMiss()

  const getStatusColor = () => {
    if (!isValid) return "text-muted-foreground"
    if (attendancePercentage >= 90) return "text-green-600"
    if (attendancePercentage >= 75) return "text-emerald-600"
    if (attendancePercentage >= 60) return "text-yellow-600"
    if (attendancePercentage >= 50) return "text-orange-600"
    return "text-red-600"
  }

  const getStatusBg = () => {
    if (!isValid) return "bg-muted"
    if (attendancePercentage >= 90) return "bg-green-50 border-green-200"
    if (attendancePercentage >= 75) return "bg-emerald-50 border-emerald-200"
    if (attendancePercentage >= 60) return "bg-yellow-50 border-yellow-200"
    if (attendancePercentage >= 50) return "bg-orange-50 border-orange-200"
    return "bg-red-50 border-red-200"
  }

  const getStatusLabel = () => {
    if (!isValid) return "Enter data"
    if (attendancePercentage >= 90) return "Excellent"
    if (attendancePercentage >= 75) return "Good"
    if (attendancePercentage >= 60) return "Average"
    if (attendancePercentage >= 50) return "Below Average"
    return "Critical"
  }

  const handleReset = () => {
    setTotalClasses("")
    setClassesAttended("")
    setRequiredPercentage("75")
    setUseRequirement(true)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (!isValid) return
    const text = `Attendance: ${attendancePercentage.toFixed(2)}% (${attended}/${total} classes)`
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShare = async () => {
    if (!isValid || !navigator.share) return
    try {
      await navigator.share({
        title: "Attendance Calculator Result",
        text: `My attendance is ${attendancePercentage.toFixed(2)}% (${attended}/${total} classes)`,
        url: window.location.href,
      })
    } catch {
      // User cancelled
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/education-learning">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Education & Learning
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Attendance Calculator</CardTitle>
                    <CardDescription>Calculate your attendance percentage</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Input Fields */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="total">Total Classes</Label>
                    <Input
                      id="total"
                      type="number"
                      placeholder="e.g., 100"
                      value={totalClasses}
                      onChange={(e) => setTotalClasses(e.target.value)}
                      min="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="attended">Classes Attended</Label>
                    <Input
                      id="attended"
                      type="number"
                      placeholder="e.g., 85"
                      value={classesAttended}
                      onChange={(e) => setClassesAttended(e.target.value)}
                      min="0"
                      max={totalClasses || undefined}
                    />
                  </div>
                </div>

                {/* Requirement Toggle */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Target className="h-4 w-4 text-muted-foreground" />
                    <Label htmlFor="use-req" className="cursor-pointer">
                      Check eligibility
                    </Label>
                  </div>
                  <Switch id="use-req" checked={useRequirement} onCheckedChange={setUseRequirement} />
                </div>

                {useRequirement && (
                  <div className="space-y-2">
                    <Label htmlFor="required">Minimum Required (%)</Label>
                    <Input
                      id="required"
                      type="number"
                      placeholder="e.g., 75"
                      value={requiredPercentage}
                      onChange={(e) => setRequiredPercentage(e.target.value)}
                      min="0"
                      max="100"
                    />
                  </div>
                )}

                {/* Error */}
                {total > 0 && attended > total && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">
                    Classes attended cannot exceed total classes
                  </div>
                )}

                {/* Result */}
                {isValid && (
                  <div className={`p-4 rounded-xl border-2 ${getStatusBg()} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Attendance</p>
                      <p className={`text-5xl font-bold ${getStatusColor()} mb-2`}>
                        {attendancePercentage.toFixed(2)}%
                      </p>
                      <p className={`text-lg font-semibold ${getStatusColor()}`}>{getStatusLabel()}</p>
                    </div>

                    <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-current/10">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Total</p>
                        <p className="text-lg font-semibold">{total}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-green-600">Attended</p>
                        <p className="text-lg font-semibold text-green-700">{attended}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-red-600">Missed</p>
                        <p className="text-lg font-semibold text-red-700">{classesMissed}</p>
                      </div>
                    </div>

                    {/* Eligibility */}
                    {useRequirement && (
                      <div className={`mt-4 p-3 rounded-lg ${isEligible ? "bg-green-100" : "bg-red-100"}`}>
                        <div className="flex items-center gap-2">
                          {isEligible ? (
                            <CheckCircle2 className="h-5 w-5 text-green-600" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-600" />
                          )}
                          <div>
                            <p className={`font-semibold ${isEligible ? "text-green-700" : "text-red-700"}`}>
                              {isEligible ? "Eligible" : "Not Eligible"}
                            </p>
                            <p className={`text-sm ${isEligible ? "text-green-600" : "text-red-600"}`}>
                              {isEligible
                                ? `${surplus.toFixed(1)}% above ${required}%`
                                : `${shortfall.toFixed(1)}% below ${required}%`}
                            </p>
                          </div>
                        </div>
                        {!isEligible && classesNeeded > 0 && classesNeeded !== Number.POSITIVE_INFINITY && (
                          <p className="text-sm text-red-700 mt-2">
                            Need to attend next <strong>{classesNeeded}</strong> classes consecutively.
                          </p>
                        )}
                        {isEligible && classesCanMiss > 0 && (
                          <p className="text-sm text-green-700 mt-2">
                            Can miss up to <strong>{classesCanMiss}</strong> more classes.
                          </p>
                        )}
                      </div>
                    )}

                    {/* Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3 text-muted-foreground">
                          {showBreakdown ? "Hide" : "Show"} Calculation
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="p-3 bg-background/50 rounded text-sm font-mono text-center">
                          ({attended} ÷ {total}) × 100 = {attendancePercentage.toFixed(2)}%
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Attendance Standards</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">90% - 100%</span>
                      <span className="text-sm text-green-600">Excellent</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                      <span className="font-medium text-emerald-700">75% - 89%</span>
                      <span className="text-sm text-emerald-600">Good</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">60% - 74%</span>
                      <span className="text-sm text-yellow-600">Average</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">50% - 59%</span>
                      <span className="text-sm text-orange-600">Below Average</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Below 50%</span>
                      <span className="text-sm text-red-600">Critical</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Requirements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                      <span className="text-sm">Most Universities</span>
                      <span className="font-medium">75%</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                      <span className="text-sm">Professional Courses</span>
                      <span className="font-medium">80%</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                      <span className="text-sm">Medical/Engineering</span>
                      <span className="font-medium">75-85%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Attendance Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Attendance % = (Attended ÷ Total) × 100</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Why Attendance Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Regular attendance is crucial for academic success. Most educational institutions have minimum
                  attendance requirements (typically 75%) that students must meet to be eligible for exams. Low
                  attendance can result in being barred from examinations, loss of grades, or even academic probation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Beyond eligibility, consistent attendance helps with better understanding of course material,
                  participation in discussions, building relationships with professors, and staying on track with
                  assignments and deadlines.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
