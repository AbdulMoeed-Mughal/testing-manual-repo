"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  CreditCard,
  Info,
  AlertTriangle,
  Calendar,
  TrendingDown,
  DollarSign,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type PaymentType = "fixed" | "minimum"

interface PayoffResult {
  monthlyPayment: number
  monthsToPayoff: number
  totalInterest: number
  totalPayment: number
  payoffDate: Date
  schedule: PaymentScheduleItem[]
}

interface PaymentScheduleItem {
  month: number
  payment: number
  principal: number
  interest: number
  balance: number
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
]

export function CreditCardPayoffCalculator() {
  const [currency, setCurrency] = useState("USD")
  const [paymentType, setPaymentType] = useState<PaymentType>("fixed")
  const [balance, setBalance] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [monthlyPayment, setMonthlyPayment] = useState("")
  const [minimumPercent, setMinimumPercent] = useState("2")
  const [extraPayment, setExtraPayment] = useState("")
  const [result, setResult] = useState<PayoffResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSchedule, setShowSchedule] = useState(false)

  const currencySymbol = currencies.find((c) => c.code === currency)?.symbol || "$"

  const formatCurrency = (value: number) => {
    if (currency === "INR") {
      return `${currencySymbol}${value.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`
    }
    return `${currencySymbol}${value.toLocaleString("en-US", { maximumFractionDigits: 2 })}`
  }

  const calculatePayoff = () => {
    setError("")
    setResult(null)

    const balanceNum = Number.parseFloat(balance)
    const rateNum = Number.parseFloat(interestRate)
    const extraNum = Number.parseFloat(extraPayment) || 0

    if (isNaN(balanceNum) || balanceNum <= 0) {
      setError("Please enter a valid balance greater than 0")
      return
    }

    if (isNaN(rateNum) || rateNum < 0) {
      setError("Please enter a valid interest rate (0 or higher)")
      return
    }

    let payment: number

    if (paymentType === "fixed") {
      payment = Number.parseFloat(monthlyPayment)
      if (isNaN(payment) || payment <= 0) {
        setError("Please enter a valid monthly payment greater than 0")
        return
      }
    } else {
      const minPercent = Number.parseFloat(minimumPercent) || 2
      payment = Math.max(balanceNum * (minPercent / 100), 25) // Minimum $25 or percentage
    }

    payment += extraNum

    const monthlyRate = rateNum / 100 / 12
    const monthlyInterest = balanceNum * monthlyRate

    // Check if payment is enough to cover interest
    if (payment <= monthlyInterest && rateNum > 0) {
      setError(
        `Monthly payment (${formatCurrency(payment)}) must be greater than monthly interest (${formatCurrency(monthlyInterest)}) to pay off the debt`,
      )
      return
    }

    // Calculate payoff iteratively
    let currentBalance = balanceNum
    let totalInterest = 0
    let months = 0
    const schedule: PaymentScheduleItem[] = []
    const maxMonths = 600 // 50 years max

    while (currentBalance > 0.01 && months < maxMonths) {
      months++
      const interestCharge = currentBalance * monthlyRate
      let actualPayment = payment

      // For minimum payment, recalculate each month
      if (paymentType === "minimum") {
        const minPercent = Number.parseFloat(minimumPercent) || 2
        actualPayment = Math.max(currentBalance * (minPercent / 100), 25) + extraNum
      }

      // Last payment adjustment
      if (actualPayment > currentBalance + interestCharge) {
        actualPayment = currentBalance + interestCharge
      }

      const principalPaid = actualPayment - interestCharge
      currentBalance -= principalPaid
      totalInterest += interestCharge

      schedule.push({
        month: months,
        payment: actualPayment,
        principal: principalPaid,
        interest: interestCharge,
        balance: Math.max(0, currentBalance),
      })
    }

    const payoffDate = new Date()
    payoffDate.setMonth(payoffDate.getMonth() + months)

    setResult({
      monthlyPayment: payment,
      monthsToPayoff: months,
      totalInterest,
      totalPayment: balanceNum + totalInterest,
      payoffDate,
      schedule,
    })
  }

  const handleReset = () => {
    setBalance("")
    setInterestRate("")
    setMonthlyPayment("")
    setMinimumPercent("2")
    setExtraPayment("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSchedule(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Credit Card Payoff Plan: Balance ${formatCurrency(Number.parseFloat(balance))}, ${result.monthsToPayoff} months to payoff, Total Interest: ${formatCurrency(result.totalInterest)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Credit Card Payoff Plan",
          text: `I calculated my credit card payoff using CalcHub! ${result.monthsToPayoff} months to pay off ${formatCurrency(Number.parseFloat(balance))} with ${formatCurrency(result.totalInterest)} in interest.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatMonths = (months: number) => {
    const years = Math.floor(months / 12)
    const remainingMonths = months % 12
    if (years === 0) return `${months} months`
    if (remainingMonths === 0) return `${years} year${years > 1 ? "s" : ""}`
    return `${years} year${years > 1 ? "s" : ""} ${remainingMonths} month${remainingMonths > 1 ? "s" : ""}`
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <CreditCard className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Credit Card Payoff Calculator</CardTitle>
                    <CardDescription>Plan your debt payoff strategy</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {currencies.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.symbol})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Payment Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Payment Type</span>
                  <button
                    onClick={() => setPaymentType((prev) => (prev === "fixed" ? "minimum" : "fixed"))}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        paymentType === "minimum" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        paymentType === "fixed" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Fixed
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        paymentType === "minimum" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Minimum
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Balance Input */}
                <div className="space-y-2">
                  <Label htmlFor="balance">Current Balance ({currencySymbol})</Label>
                  <Input
                    id="balance"
                    type="number"
                    placeholder="e.g., 5000"
                    value={balance}
                    onChange={(e) => setBalance(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Interest Rate Input */}
                <div className="space-y-2">
                  <Label htmlFor="rate">Annual Interest Rate (%)</Label>
                  <Input
                    id="rate"
                    type="number"
                    placeholder="e.g., 18.99"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Payment Input */}
                {paymentType === "fixed" ? (
                  <div className="space-y-2">
                    <Label htmlFor="payment">Monthly Payment ({currencySymbol})</Label>
                    <Input
                      id="payment"
                      type="number"
                      placeholder="e.g., 200"
                      value={monthlyPayment}
                      onChange={(e) => setMonthlyPayment(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="minPercent">Minimum Payment (%)</Label>
                    <Input
                      id="minPercent"
                      type="number"
                      placeholder="e.g., 2"
                      value={minimumPercent}
                      onChange={(e) => setMinimumPercent(e.target.value)}
                      min="1"
                      max="10"
                      step="0.1"
                    />
                    <p className="text-xs text-muted-foreground">
                      Typically 2-3% of balance, minimum {currencySymbol}25
                    </p>
                  </div>
                )}

                {/* Extra Payment Input */}
                <div className="space-y-2">
                  <Label htmlFor="extra">Extra Monthly Payment ({currencySymbol}) - Optional</Label>
                  <Input
                    id="extra"
                    type="number"
                    placeholder="e.g., 50"
                    value={extraPayment}
                    onChange={(e) => setExtraPayment(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePayoff} className="w-full" size="lg">
                  Calculate Payoff
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Time to Payoff</p>
                      <p className="text-4xl font-bold text-green-600 mb-1">{formatMonths(result.monthsToPayoff)}</p>
                      <p className="text-sm text-green-600">
                        Payoff Date: {result.payoffDate.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Monthly Payment</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.monthlyPayment)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Interest</p>
                        <p className="font-semibold text-red-600">{formatCurrency(result.totalInterest)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Principal</p>
                        <p className="font-semibold text-foreground">{formatCurrency(Number.parseFloat(balance))}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Payment</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.totalPayment)}</p>
                      </div>
                    </div>

                    {/* Payoff Schedule Toggle */}
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mb-3 bg-transparent"
                      onClick={() => setShowSchedule(!showSchedule)}
                    >
                      {showSchedule ? "Hide" : "Show"} Payment Schedule
                    </Button>

                    {showSchedule && (
                      <div className="max-h-60 overflow-y-auto bg-white rounded-lg border">
                        <table className="w-full text-xs">
                          <thead className="bg-muted sticky top-0">
                            <tr>
                              <th className="p-2 text-left">Month</th>
                              <th className="p-2 text-right">Payment</th>
                              <th className="p-2 text-right">Principal</th>
                              <th className="p-2 text-right">Interest</th>
                              <th className="p-2 text-right">Balance</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.schedule.slice(0, 24).map((item) => (
                              <tr key={item.month} className="border-t">
                                <td className="p-2">{item.month}</td>
                                <td className="p-2 text-right">{formatCurrency(item.payment)}</td>
                                <td className="p-2 text-right text-green-600">{formatCurrency(item.principal)}</td>
                                <td className="p-2 text-right text-red-600">{formatCurrency(item.interest)}</td>
                                <td className="p-2 text-right">{formatCurrency(item.balance)}</td>
                              </tr>
                            ))}
                            {result.schedule.length > 24 && (
                              <tr className="border-t bg-muted/50">
                                <td colSpan={5} className="p-2 text-center text-muted-foreground">
                                  ... and {result.schedule.length - 24} more months
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Payoff Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                      <TrendingDown className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-green-800">Pay More Than Minimum</p>
                        <p className="text-sm text-green-700">
                          Paying only the minimum can take decades to pay off debt
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <DollarSign className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-blue-800">Extra Payments</p>
                        <p className="text-sm text-blue-700">Even small extra payments significantly reduce interest</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <Calendar className="h-5 w-5 text-purple-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-purple-800">Balance Transfer</p>
                        <p className="text-sm text-purple-700">Consider 0% APR transfers to reduce interest charges</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How Interest Works</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Monthly Interest = Balance × (APR ÷ 12)</p>
                  </div>
                  <p>
                    Credit card interest compounds monthly. At 18.99% APR on a {currencySymbol}5,000 balance, you pay{" "}
                    {currencySymbol}
                    {((5000 * 0.1899) / 12).toFixed(2)} in interest the first month alone.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Actual payoff may vary based on lender terms, fees, and
                        changes in interest rates.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Credit Card Debt</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Credit card debt is one of the most expensive forms of consumer debt, with average interest rates
                  ranging from 15% to 25% APR or higher. Unlike mortgages or auto loans where interest rates are
                  typically single digits, credit cards charge premium rates for the convenience and flexibility they
                  offer. Understanding how credit card interest accumulates is crucial for developing an effective
                  payoff strategy and avoiding the trap of minimum payments that can extend debt for decades.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When you carry a balance on your credit card, interest is calculated daily based on your average daily
                  balance and added to your account monthly. This means interest compounds on interest, causing your
                  debt to grow exponentially if not managed properly. Even a seemingly manageable balance can become
                  overwhelming when left to accumulate interest over time, which is why having a clear payoff plan is
                  essential for financial health.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>The Minimum Payment Trap</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Credit card companies typically require a minimum payment of 2-3% of your balance or a fixed amount
                  (usually {currencySymbol}25-35), whichever is greater. While this seems affordable, making only
                  minimum payments is one of the costliest financial decisions you can make. On a {currencySymbol}5,000
                  balance at 18.99% APR, paying only the minimum could take over 20 years to pay off and cost more than{" "}
                  {currencySymbol}6,000 in interest - more than the original balance itself.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The reason minimum payments are so dangerous is that most of your early payments go toward interest
                  rather than principal. In the example above, if your minimum payment is {currencySymbol}100, about{" "}
                  {currencySymbol}79 goes to interest in the first month, leaving only {currencySymbol}21 to reduce your
                  balance. This is why credit card debt can feel impossible to escape - you're barely making progress on
                  the actual debt while enriching the credit card company.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Effective Payoff Strategies</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The most effective way to pay off credit card debt is to pay as much as you can above the minimum
                  payment. Even an extra {currencySymbol}50 per month can dramatically reduce your payoff time and total
                  interest paid. Use windfalls like tax refunds, bonuses, or side income to make additional payments.
                  Every extra dollar goes directly to principal reduction, which then reduces future interest charges.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Debt Avalanche Method</h4>
                    <p className="text-blue-700 text-sm">
                      Pay minimums on all cards except the one with the highest interest rate. Put all extra money
                      toward the highest-rate card until it's paid off, then move to the next highest. This method
                      minimizes total interest paid.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Debt Snowball Method</h4>
                    <p className="text-green-700 text-sm">
                      Pay off the smallest balance first while maintaining minimums on others. The psychological wins
                      from eliminating accounts can provide motivation to continue the payoff journey.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Balance Transfer</h4>
                    <p className="text-purple-700 text-sm">
                      Transfer balances to a 0% APR promotional card. This pauses interest accumulation, allowing 100%
                      of payments to reduce principal. Be aware of transfer fees (typically 3-5%) and the promotional
                      period length.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Building Better Credit Habits</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While paying off existing debt, it's equally important to prevent new debt from accumulating. Create a
                  budget that accounts for all expenses so you don't rely on credit cards for regular purchases. Build
                  an emergency fund to cover unexpected expenses without reaching for plastic. Even a small fund of{" "}
                  {currencySymbol}500-1,000 can prevent many situations that lead to credit card debt.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Consider using your credit card only for purchases you can pay in full when the bill arrives. This
                  allows you to earn rewards and build credit history without paying interest. Set up automatic payments
                  for at least the minimum amount to avoid late fees, but aim to pay the full statement balance monthly.
                  Remember, the best credit card strategy is using them as a payment tool, not a lending tool.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
