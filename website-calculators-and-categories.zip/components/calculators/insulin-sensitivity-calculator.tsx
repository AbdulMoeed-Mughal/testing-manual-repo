"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Activity,
  Info,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type GlucoseUnit = "mg/dL" | "mmol/L"

interface InsulinSensitivityResult {
  homaIR: number
  insulinSensitivity: number
  category: string
  color: string
  bgColor: string
  description: string
}

export function InsulinSensitivityCalculator() {
  const [glucoseUnit, setGlucoseUnit] = useState<GlucoseUnit>("mg/dL")
  const [fastingGlucose, setFastingGlucose] = useState("")
  const [fastingInsulin, setFastingInsulin] = useState("")
  const [age, setAge] = useState("")
  const [weight, setWeight] = useState("")
  const [height, setHeight] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [result, setResult] = useState<InsulinSensitivityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateInsulinSensitivity = () => {
    setError("")
    setResult(null)

    const glucoseNum = Number.parseFloat(fastingGlucose)
    const insulinNum = Number.parseFloat(fastingInsulin)

    if (isNaN(glucoseNum) || glucoseNum <= 0) {
      setError("Please enter a valid fasting glucose value greater than 0")
      return
    }

    if (isNaN(insulinNum) || insulinNum <= 0) {
      setError("Please enter a valid fasting insulin value greater than 0")
      return
    }

    // Validate realistic ranges
    if (glucoseUnit === "mg/dL" && (glucoseNum < 40 || glucoseNum > 500)) {
      setError("Fasting glucose should be between 40-500 mg/dL")
      return
    }

    if (glucoseUnit === "mmol/L" && (glucoseNum < 2.2 || glucoseNum > 27.8)) {
      setError("Fasting glucose should be between 2.2-27.8 mmol/L")
      return
    }

    if (insulinNum < 1 || insulinNum > 300) {
      setError("Fasting insulin should be between 1-300 µU/mL")
      return
    }

    // Calculate HOMA-IR
    // For mg/dL: HOMA-IR = (Fasting Insulin × Fasting Glucose) / 405
    // For mmol/L: HOMA-IR = (Fasting Insulin × Fasting Glucose) / 22.5
    let homaIR: number
    if (glucoseUnit === "mg/dL") {
      homaIR = (insulinNum * glucoseNum) / 405
    } else {
      homaIR = (insulinNum * glucoseNum) / 22.5
    }

    const roundedHomaIR = Math.round(homaIR * 100) / 100
    const insulinSensitivity = Math.round((1 / homaIR) * 100) / 100

    // Categorize insulin sensitivity based on HOMA-IR
    let category: string
    let color: string
    let bgColor: string
    let description: string

    if (homaIR < 1.0) {
      category = "Highly Sensitive"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      description = "Excellent insulin sensitivity. Your body responds very efficiently to insulin."
    } else if (homaIR < 2.0) {
      category = "Normal Sensitivity"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
      description = "Good insulin sensitivity within normal healthy range."
    } else if (homaIR < 3.0) {
      category = "Moderate Resistance"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
      description = "Early signs of insulin resistance. Consider lifestyle modifications."
    } else if (homaIR < 5.0) {
      category = "Significant Resistance"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
      description = "Notable insulin resistance. Medical consultation recommended."
    } else {
      category = "Severe Resistance"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
      description = "High insulin resistance indicating metabolic dysfunction. Seek medical advice."
    }

    setResult({
      homaIR: roundedHomaIR,
      insulinSensitivity,
      category,
      color,
      bgColor,
      description,
    })
  }

  const handleReset = () => {
    setFastingGlucose("")
    setFastingInsulin("")
    setAge("")
    setWeight("")
    setHeight("")
    setGender("male")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `My HOMA-IR is ${result.homaIR} (${result.category}). Insulin Sensitivity: ${result.insulinSensitivity}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Insulin Sensitivity Result",
          text: `I calculated my insulin sensitivity using CalcHub! My HOMA-IR is ${result.homaIR} (${result.category})`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const toggleGlucoseUnit = () => {
    if (glucoseUnit === "mg/dL") {
      // Convert mg/dL to mmol/L
      if (fastingGlucose) {
        const converted = Number.parseFloat(fastingGlucose) / 18.0182
        setFastingGlucose(converted.toFixed(1))
      }
      setGlucoseUnit("mmol/L")
    } else {
      // Convert mmol/L to mg/dL
      if (fastingGlucose) {
        const converted = Number.parseFloat(fastingGlucose) * 18.0182
        setFastingGlucose(converted.toFixed(0))
      }
      setGlucoseUnit("mg/dL")
    }
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Insulin Sensitivity Calculator</CardTitle>
                    <CardDescription>Calculate HOMA-IR and insulin sensitivity</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Glucose Unit</span>
                  <button
                    onClick={toggleGlucoseUnit}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        glucoseUnit === "mmol/L" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        glucoseUnit === "mg/dL" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      mg/dL
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        glucoseUnit === "mmol/L" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      mmol/L
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Fasting Glucose Input */}
                <div className="space-y-2">
                  <Label htmlFor="glucose">Fasting Blood Glucose ({glucoseUnit})</Label>
                  <Input
                    id="glucose"
                    type="number"
                    placeholder={`Enter fasting glucose in ${glucoseUnit}`}
                    value={fastingGlucose}
                    onChange={(e) => setFastingGlucose(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Fasting Insulin Input */}
                <div className="space-y-2">
                  <Label htmlFor="insulin">Fasting Insulin (µU/mL)</Label>
                  <Input
                    id="insulin"
                    type="number"
                    placeholder="Enter fasting insulin level"
                    value={fastingInsulin}
                    onChange={(e) => setFastingInsulin(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Optional Fields */}
                <div className="pt-2 border-t">
                  <p className="text-sm text-muted-foreground mb-3">Optional fields for context</p>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="age">Age (years)</Label>
                      <Input
                        id="age"
                        type="number"
                        placeholder="Age"
                        value={age}
                        onChange={(e) => setAge(e.target.value)}
                        min="1"
                        max="120"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Gender</Label>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant={gender === "male" ? "default" : "outline"}
                          size="sm"
                          className="flex-1"
                          onClick={() => setGender("male")}
                        >
                          Male
                        </Button>
                        <Button
                          type="button"
                          variant={gender === "female" ? "default" : "outline"}
                          size="sm"
                          className="flex-1"
                          onClick={() => setGender("female")}
                        >
                          Female
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mt-3">
                    <div className="space-y-2">
                      <Label htmlFor="weight">Weight (kg)</Label>
                      <Input
                        id="weight"
                        type="number"
                        placeholder="Weight"
                        value={weight}
                        onChange={(e) => setWeight(e.target.value)}
                        min="1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="height">Height (cm)</Label>
                      <Input
                        id="height"
                        type="number"
                        placeholder="Height"
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        min="1"
                      />
                    </div>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateInsulinSensitivity} className="w-full" size="lg">
                  Calculate Insulin Sensitivity
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">HOMA-IR Score</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.homaIR}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                      <p className="text-sm text-muted-foreground mt-2">{result.description}</p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          Hide Details <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Details <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">HOMA-IR:</span>
                          <span className="font-medium">{result.homaIR}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Insulin Sensitivity (1/HOMA-IR):</span>
                          <span className="font-medium">{result.insulinSensitivity}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fasting Glucose:</span>
                          <span className="font-medium">
                            {fastingGlucose} {glucoseUnit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fasting Insulin:</span>
                          <span className="font-medium">{fastingInsulin} µU/mL</span>
                        </div>
                        {age && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Age:</span>
                            <span className="font-medium">{age} years</span>
                          </div>
                        )}
                        {weight && height && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">BMI:</span>
                            <span className="font-medium">
                              {(Number(weight) / Math.pow(Number(height) / 100, 2)).toFixed(1)} kg/m²
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">HOMA-IR Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Highly Sensitive</span>
                      <span className="text-sm text-green-600">{"< 1.0"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Normal</span>
                      <span className="text-sm text-blue-600">1.0 – 1.9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Resistance</span>
                      <span className="text-sm text-yellow-600">2.0 – 2.9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Significant Resistance</span>
                      <span className="text-sm text-orange-600">3.0 – 4.9</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Severe Resistance</span>
                      <span className="text-sm text-red-600">≥ 5.0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">HOMA-IR Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground text-xs">For mg/dL:</p>
                    <p className="font-semibold text-foreground">HOMA-IR = (Insulin × Glucose) ÷ 405</p>
                    <p className="font-semibold text-foreground text-xs mt-2">For mmol/L:</p>
                    <p className="font-semibold text-foreground">HOMA-IR = (Insulin × Glucose) ÷ 22.5</p>
                  </div>
                  <p>
                    Insulin Sensitivity is calculated as the inverse of HOMA-IR: <strong>1 ÷ HOMA-IR</strong>
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Normal Reference Ranges</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="text-muted-foreground">Fasting Glucose (mg/dL):</span>
                      <span className="font-medium">70 – 100</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="text-muted-foreground">Fasting Glucose (mmol/L):</span>
                      <span className="font-medium">3.9 – 5.6</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span className="text-muted-foreground">Fasting Insulin (µU/mL):</span>
                      <span className="font-medium">2 – 25</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Insulin Sensitivity?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Insulin sensitivity refers to how responsive your cells are to insulin, the hormone that regulates
                  blood sugar levels. When you have high insulin sensitivity, your cells respond efficiently to insulin,
                  allowing glucose to enter cells for energy with relatively small amounts of insulin. This is a sign of
                  good metabolic health and is associated with lower risk of type 2 diabetes and cardiovascular disease.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In contrast, insulin resistance occurs when cells don't respond well to insulin, requiring the
                  pancreas to produce more insulin to maintain normal blood sugar levels. Over time, this can lead to
                  elevated blood sugar, prediabetes, and eventually type 2 diabetes. The HOMA-IR (Homeostatic Model
                  Assessment for Insulin Resistance) is a widely used clinical tool to estimate insulin resistance from
                  fasting glucose and insulin levels.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Improving Insulin Sensitivity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  There are several evidence-based strategies to improve insulin sensitivity and reduce insulin
                  resistance:
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Exercise Regularly</h4>
                    <p className="text-green-700 text-sm">
                      Both aerobic exercise and resistance training improve insulin sensitivity. Aim for at least 150
                      minutes of moderate activity per week.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Healthy Diet</h4>
                    <p className="text-blue-700 text-sm">
                      Focus on whole foods, fiber-rich vegetables, lean proteins, and healthy fats. Reduce refined
                      carbohydrates and added sugars.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Maintain Healthy Weight</h4>
                    <p className="text-purple-700 text-sm">
                      Even modest weight loss (5-10% of body weight) can significantly improve insulin sensitivity,
                      especially visceral fat reduction.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Quality Sleep</h4>
                    <p className="text-orange-700 text-sm">
                      Poor sleep and sleep deprivation can worsen insulin resistance. Aim for 7-9 hours of quality sleep
                      per night.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Medical Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Insulin sensitivity calculations are estimates based on standard formulas and should not replace
                  professional medical evaluation. HOMA-IR is a screening tool and has limitations—it may not be
                  accurate during acute illness, pregnancy, or with certain medications. Always consult a healthcare
                  provider for personalized assessment, diagnosis, and treatment recommendations. This calculator is for
                  educational purposes only and should not be used as the sole basis for medical decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
