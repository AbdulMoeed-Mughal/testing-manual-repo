"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Beaker } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "normality" | "equivalents" | "volume"
type VolumeUnit = "L" | "mL"

interface Result {
  normality: number
  equivalents: number
  volume: number
  volumeUnit: VolumeUnit
  steps: string[]
}

export function SolutionNormalityCalculator() {
  const [mode, setMode] = useState<CalculationMode>("normality")
  const [equivalents, setEquivalents] = useState("")
  const [volume, setVolume] = useState("")
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>("L")
  const [normality, setNormality] = useState("")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  const calculate = () => {
    setError("")
    setResult(null)

    const steps: string[] = []

    if (mode === "normality") {
      const eq = Number.parseFloat(equivalents)
      const vol = Number.parseFloat(volume)

      if (isNaN(eq) || eq < 0) {
        setError("Please enter a valid number of equivalents (≥ 0)")
        return
      }
      if (isNaN(vol) || vol <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }

      // Convert to liters if needed
      const volInLiters = volumeUnit === "mL" ? vol / 1000 : vol

      steps.push(`Given: Equivalents = ${eq} eq, Volume = ${vol} ${volumeUnit}`)
      if (volumeUnit === "mL") {
        steps.push(`Convert volume to liters: ${vol} mL ÷ 1000 = ${volInLiters} L`)
      }
      steps.push(`Formula: N = Equivalents ÷ Volume`)
      steps.push(`N = ${eq} eq ÷ ${volInLiters} L`)

      const n = eq / volInLiters
      steps.push(`N = ${n.toFixed(6)} eq/L`)

      setResult({
        normality: n,
        equivalents: eq,
        volume: vol,
        volumeUnit,
        steps,
      })
    } else if (mode === "equivalents") {
      const n = Number.parseFloat(normality)
      const vol = Number.parseFloat(volume)

      if (isNaN(n) || n < 0) {
        setError("Please enter a valid normality (≥ 0)")
        return
      }
      if (isNaN(vol) || vol <= 0) {
        setError("Please enter a valid volume greater than 0")
        return
      }

      // Convert to liters if needed
      const volInLiters = volumeUnit === "mL" ? vol / 1000 : vol

      steps.push(`Given: Normality = ${n} N, Volume = ${vol} ${volumeUnit}`)
      if (volumeUnit === "mL") {
        steps.push(`Convert volume to liters: ${vol} mL ÷ 1000 = ${volInLiters} L`)
      }
      steps.push(`Formula: Equivalents = N × Volume`)
      steps.push(`eq = ${n} N × ${volInLiters} L`)

      const eq = n * volInLiters
      steps.push(`eq = ${eq.toFixed(6)} eq`)

      setResult({
        normality: n,
        equivalents: eq,
        volume: vol,
        volumeUnit,
        steps,
      })
    } else if (mode === "volume") {
      const n = Number.parseFloat(normality)
      const eq = Number.parseFloat(equivalents)

      if (isNaN(n) || n <= 0) {
        setError("Please enter a valid normality greater than 0")
        return
      }
      if (isNaN(eq) || eq < 0) {
        setError("Please enter a valid number of equivalents (≥ 0)")
        return
      }

      steps.push(`Given: Equivalents = ${eq} eq, Normality = ${n} N`)
      steps.push(`Formula: Volume = Equivalents ÷ N`)
      steps.push(`V = ${eq} eq ÷ ${n} N`)

      const volInLiters = eq / n
      steps.push(`V = ${volInLiters.toFixed(6)} L`)

      const finalVol = volumeUnit === "mL" ? volInLiters * 1000 : volInLiters
      if (volumeUnit === "mL") {
        steps.push(`Convert to mL: ${volInLiters.toFixed(6)} L × 1000 = ${finalVol.toFixed(4)} mL`)
      }

      setResult({
        normality: n,
        equivalents: eq,
        volume: finalVol,
        volumeUnit,
        steps,
      })
    }
  }

  const handleReset = () => {
    setEquivalents("")
    setVolume("")
    setNormality("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = ""
      if (mode === "normality") {
        text = `Normality: ${result.normality.toFixed(4)} N (eq/L)`
      } else if (mode === "equivalents") {
        text = `Equivalents: ${result.equivalents.toFixed(4)} eq`
      } else {
        text = `Volume: ${result.volume.toFixed(4)} ${result.volumeUnit}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        let text = ""
        if (mode === "normality") {
          text = `I calculated the normality using CalcHub! N = ${result.normality.toFixed(4)} eq/L`
        } else if (mode === "equivalents") {
          text = `I calculated the equivalents using CalcHub! eq = ${result.equivalents.toFixed(4)}`
        } else {
          text = `I calculated the volume using CalcHub! V = ${result.volume.toFixed(4)} ${result.volumeUnit}`
        }
        await navigator.share({
          title: "Solution Normality Calculator Result",
          text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number, decimals = 4): string => {
    if (Math.abs(num) < 0.0001 || Math.abs(num) >= 1000000) {
      return num.toExponential(decimals)
    }
    return num.toFixed(decimals)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Solution Normality Calculator</CardTitle>
                    <CardDescription>Calculate normality, equivalents, or volume</CardDescription>
                  </div>
                </div>

                {/* Mode Selector */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Calculate</Label>
                  <Select
                    value={mode}
                    onValueChange={(v) => {
                      setMode(v as CalculationMode)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="normality">Normality from Equivalents & Volume</SelectItem>
                      <SelectItem value="equivalents">Equivalents from Normality & Volume</SelectItem>
                      <SelectItem value="volume">Volume from Normality & Equivalents</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Equivalents Input */}
                {(mode === "normality" || mode === "volume") && (
                  <div className="space-y-2">
                    <Label htmlFor="equivalents">Number of Equivalents (eq)</Label>
                    <Input
                      id="equivalents"
                      type="number"
                      placeholder="Enter equivalents"
                      value={equivalents}
                      onChange={(e) => setEquivalents(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Normality Input */}
                {(mode === "equivalents" || mode === "volume") && (
                  <div className="space-y-2">
                    <Label htmlFor="normality">Normality (N, eq/L)</Label>
                    <Input
                      id="normality"
                      type="number"
                      placeholder="Enter normality"
                      value={normality}
                      onChange={(e) => setNormality(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Volume Input */}
                {(mode === "normality" || mode === "equivalents") && (
                  <div className="space-y-2">
                    <Label htmlFor="volume">Solution Volume</Label>
                    <div className="flex gap-2">
                      <Input
                        id="volume"
                        type="number"
                        placeholder="Enter volume"
                        value={volume}
                        onChange={(e) => setVolume(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={volumeUnit} onValueChange={(v) => setVolumeUnit(v as VolumeUnit)}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="L">L</SelectItem>
                          <SelectItem value="mL">mL</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Output Unit for Volume mode */}
                {mode === "volume" && (
                  <div className="space-y-2">
                    <Label>Output Volume Unit</Label>
                    <Select value={volumeUnit} onValueChange={(v) => setVolumeUnit(v as VolumeUnit)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="L">Liters (L)</SelectItem>
                        <SelectItem value="mL">Milliliters (mL)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "normality" ? "Normality" : mode === "equivalents" ? "Equivalents" : "Volume"}
                      </p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">
                        {mode === "normality"
                          ? formatNumber(result.normality)
                          : mode === "equivalents"
                            ? formatNumber(result.equivalents)
                            : formatNumber(result.volume)}
                      </p>
                      <p className="text-lg font-medium text-purple-700">
                        {mode === "normality" ? "N (eq/L)" : mode === "equivalents" ? "eq" : result.volumeUnit}
                      </p>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 p-3 bg-white/60 rounded-lg">
                        <p className="text-sm font-medium text-purple-800 mb-2">Step-by-Step Solution:</p>
                        <div className="space-y-1">
                          {result.steps.map((step, index) => (
                            <p key={index} className="text-sm text-purple-700 font-mono">
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Normality Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="font-mono text-sm font-semibold text-purple-800 text-center">N = eq ÷ V</p>
                    <p className="text-xs text-purple-600 text-center mt-1">Normality = Equivalents ÷ Volume</p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-mono text-sm font-semibold text-blue-800 text-center">eq = N × V</p>
                    <p className="text-xs text-blue-600 text-center mt-1">Equivalents = Normality × Volume</p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-mono text-sm font-semibold text-green-800 text-center">V = eq ÷ N</p>
                    <p className="text-xs text-green-600 text-center mt-1">Volume = Equivalents ÷ Normality</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Reference</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span className="font-medium">Normality (N)</span>
                    <span className="text-muted-foreground">eq/L</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span className="font-medium">Equivalents</span>
                    <span className="text-muted-foreground">eq</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span className="font-medium">1 L</span>
                    <span className="text-muted-foreground">1000 mL</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Disclaimer</p>
                      <p className="text-sm text-amber-700 mt-1">
                        Results assume ideal solutions and accurate measurements. Always verify calculations for
                        critical laboratory work.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Normality?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Normality (N) is a measure of concentration that expresses the number of gram equivalents of a solute
                  per liter of solution. Unlike molarity, which measures moles per liter, normality takes into account
                  the reactive capacity of a substance—specifically, the number of protons (H⁺) that can be donated or
                  accepted, electrons transferred, or ions involved in a reaction.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of normality is particularly useful in acid-base chemistry, redox reactions, and
                  precipitation reactions. It provides a more practical measure of concentration when stoichiometry
                  involves reactive equivalents rather than whole molecules. For example, 1 N H₂SO₄ can donate 2 moles
                  of H⁺ ions, while 1 M H₂SO₄ represents 1 mole of the acid per liter.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Equivalents</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An equivalent (eq) is the amount of a substance that can react with or supply one mole of hydrogen
                  ions (H⁺) in an acid-base reaction, or one mole of electrons in a redox reaction. The number of
                  equivalents depends on the type of reaction and the specific substance involved.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm">For Acids:</p>
                    <p className="text-sm text-muted-foreground">
                      Equivalents = Moles × number of H⁺ ions that can be donated
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Example: H₂SO₄ can donate 2 H⁺, so 1 mol H₂SO₄ = 2 eq
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm">For Bases:</p>
                    <p className="text-sm text-muted-foreground">
                      Equivalents = Moles × number of OH⁻ ions that can be accepted
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Example: Ca(OH)₂ can accept 2 H⁺, so 1 mol Ca(OH)₂ = 2 eq
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-sm">For Redox Reactions:</p>
                    <p className="text-sm text-muted-foreground">
                      Equivalents = Moles × number of electrons transferred
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Normality vs. Molarity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While both normality and molarity are measures of concentration, they serve different purposes.
                  Molarity (M) measures the number of moles of solute per liter of solution, while normality (N)
                  measures the number of equivalents per liter. The relationship between them is:
                </p>
                <div className="my-4 p-4 bg-muted rounded-lg text-center">
                  <p className="font-mono font-semibold">N = M × n</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    where n is the number of equivalents per mole (n-factor)
                  </p>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="flex justify-between p-2 bg-purple-50 rounded border border-purple-200">
                    <span className="font-medium text-purple-800">HCl (1 N = 1 M)</span>
                    <span className="text-sm text-purple-600">n = 1</span>
                  </div>
                  <div className="flex justify-between p-2 bg-purple-50 rounded border border-purple-200">
                    <span className="font-medium text-purple-800">H₂SO₄ (1 N = 0.5 M)</span>
                    <span className="text-sm text-purple-600">n = 2</span>
                  </div>
                  <div className="flex justify-between p-2 bg-purple-50 rounded border border-purple-200">
                    <span className="font-medium text-purple-800">H₃PO₄ (1 N = 0.33 M)</span>
                    <span className="text-sm text-purple-600">n = 3</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Normality is widely used in various laboratory and industrial applications:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>Titrations:</strong> Normality simplifies calculations when performing acid-base or redox
                    titrations, as equal volumes of solutions with equal normalities will exactly react with each other.
                  </li>
                  <li>
                    <strong>Water Quality Testing:</strong> Hardness of water is often expressed in terms of normality
                    of calcium and magnesium ions.
                  </li>
                  <li>
                    <strong>Electrochemistry:</strong> In electroplating and battery chemistry, normality helps
                    calculate the amount of material deposited or consumed.
                  </li>
                  <li>
                    <strong>Pharmaceutical Industry:</strong> Many drug concentrations and reagents are specified in
                    normality for precise formulation.
                  </li>
                  <li>
                    <strong>Clinical Chemistry:</strong> Blood and body fluid analysis often uses normality for
                    electrolyte measurements.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
