"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Home,
  Info,
  AlertTriangle,
  DollarSign,
  Calendar,
  ChevronDown,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type DownPaymentMode = "amount" | "percentage"

interface MortgageResult {
  monthlyPI: number
  monthlyPITI: number
  loanAmount: number
  totalInterest: number
  totalCost: number
  payoffDate: string
}

export function MortgageCalculator() {
  const [homePrice, setHomePrice] = useState("")
  const [downPaymentMode, setDownPaymentMode] = useState<DownPaymentMode>("percentage")
  const [downPaymentAmount, setDownPaymentAmount] = useState("")
  const [downPaymentPercent, setDownPaymentPercent] = useState("20")
  const [loanTerm, setLoanTerm] = useState("30")
  const [interestRate, setInterestRate] = useState("")
  const [propertyTax, setPropertyTax] = useState("")
  const [homeInsurance, setHomeInsurance] = useState("")
  const [hoaFees, setHoaFees] = useState("")
  const [extraPayment, setExtraPayment] = useState("")
  const [startDate, setStartDate] = useState(new Date().toISOString().split("T")[0])
  const [result, setResult] = useState<MortgageResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showAmortization, setShowAmortization] = useState(false)

  const calculateMortgage = () => {
    setError("")
    setResult(null)

    const homePriceNum = Number.parseFloat(homePrice)
    if (isNaN(homePriceNum) || homePriceNum <= 0) {
      setError("Please enter a valid home price greater than 0")
      return
    }

    let downPaymentNum = 0
    if (downPaymentMode === "percentage") {
      const percentNum = Number.parseFloat(downPaymentPercent)
      if (isNaN(percentNum) || percentNum < 0 || percentNum > 100) {
        setError("Down payment percentage must be between 0 and 100")
        return
      }
      downPaymentNum = (homePriceNum * percentNum) / 100
    } else {
      downPaymentNum = Number.parseFloat(downPaymentAmount) || 0
      if (downPaymentNum < 0 || downPaymentNum > homePriceNum) {
        setError("Down payment cannot exceed home price")
        return
      }
    }

    const loanAmount = homePriceNum - downPaymentNum

    const interestRateNum = Number.parseFloat(interestRate)
    if (isNaN(interestRateNum) || interestRateNum < 0) {
      setError("Please enter a valid interest rate")
      return
    }

    const loanTermNum = Number.parseFloat(loanTerm)
    if (isNaN(loanTermNum) || loanTermNum <= 0) {
      setError("Please enter a valid loan term")
      return
    }

    if (interestRateNum > 20) {
      setError("Warning: Interest rate seems unusually high (>20%)")
    }

    // Calculate monthly mortgage payment (P&I)
    const monthlyRate = interestRateNum / 12 / 100
    const numPayments = loanTermNum * 12
    let monthlyPI = 0

    if (monthlyRate === 0) {
      monthlyPI = loanAmount / numPayments
    } else {
      monthlyPI =
        (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, numPayments))) /
        (Math.pow(1 + monthlyRate, numPayments) - 1)
    }

    // Additional monthly costs
    const monthlyPropertyTax = (Number.parseFloat(propertyTax) || 0) / 12
    const monthlyInsurance = (Number.parseFloat(homeInsurance) || 0) / 12
    const monthlyHOA = Number.parseFloat(hoaFees) || 0
    const extraPaymentNum = Number.parseFloat(extraPayment) || 0

    const monthlyPITI = monthlyPI + monthlyPropertyTax + monthlyInsurance + monthlyHOA

    // Calculate total interest without extra payments first
    const totalPaid = monthlyPI * numPayments
    let totalInterest = totalPaid - loanAmount
    let actualPayoffMonths = numPayments

    // Recalculate with extra payments if applicable
    if (extraPaymentNum > 0) {
      let balance = loanAmount
      let months = 0
      let totalInterestPaid = 0

      while (balance > 0 && months < numPayments * 2) {
        const interestPayment = balance * monthlyRate
        const principalPayment = monthlyPI - interestPayment + extraPaymentNum
        totalInterestPaid += interestPayment
        balance -= principalPayment
        months++

        if (balance <= 0) break
      }

      actualPayoffMonths = months
      totalInterest = totalInterestPaid
    }

    const totalCost = loanAmount + totalInterest

    // Calculate payoff date
    const payoffDate = new Date(startDate)
    payoffDate.setMonth(payoffDate.getMonth() + actualPayoffMonths)

    setResult({
      monthlyPI: Math.round(monthlyPI * 100) / 100,
      monthlyPITI: Math.round(monthlyPITI * 100) / 100,
      loanAmount: Math.round(loanAmount * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
      totalCost: Math.round(totalCost * 100) / 100,
      payoffDate: payoffDate.toLocaleDateString("en-US", { year: "numeric", month: "long" }),
    })
  }

  const handleReset = () => {
    setHomePrice("")
    setDownPaymentAmount("")
    setDownPaymentPercent("20")
    setInterestRate("")
    setLoanTerm("30")
    setPropertyTax("")
    setHomeInsurance("")
    setHoaFees("")
    setExtraPayment("")
    setStartDate(new Date().toISOString().split("T")[0])
    setResult(null)
    setError("")
    setCopied(false)
    setShowAmortization(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Mortgage: $${result.monthlyPI.toLocaleString()}/mo (P&I), Total: $${result.totalCost.toLocaleString()}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Mortgage Calculation",
          text: `I calculated my mortgage using CalcHub! Monthly Payment: $${result.monthlyPI.toLocaleString()}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleDownPaymentMode = () => {
    setDownPaymentMode((prev) => (prev === "amount" ? "percentage" : "amount"))
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Mortgage Calculator</CardTitle>
                    <CardDescription>Calculate your home loan payments</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Home Price */}
                <div className="space-y-2">
                  <Label htmlFor="homePrice">Home Purchase Price ($)</Label>
                  <Input
                    id="homePrice"
                    type="number"
                    placeholder="Enter home price"
                    value={homePrice}
                    onChange={(e) => setHomePrice(e.target.value)}
                    min="0"
                    step="1000"
                  />
                </div>

                {/* Down Payment */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Down Payment</Label>
                    <button
                      onClick={toggleDownPaymentMode}
                      className="relative inline-flex h-8 w-32 items-center rounded-full bg-muted p-0.5 transition-colors text-xs"
                    >
                      <span
                        className={`absolute h-7 w-[calc(50%-2px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                          downPaymentMode === "percentage" ? "translate-x-0" : "translate-x-[calc(100%+2px)]"
                        }`}
                      />
                      <span
                        className={`relative z-10 flex-1 text-center font-medium transition-colors ${
                          downPaymentMode === "percentage" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        %
                      </span>
                      <span
                        className={`relative z-10 flex-1 text-center font-medium transition-colors ${
                          downPaymentMode === "amount" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        $
                      </span>
                    </button>
                  </div>
                  {downPaymentMode === "percentage" ? (
                    <Input
                      type="number"
                      placeholder="Enter percentage"
                      value={downPaymentPercent}
                      onChange={(e) => setDownPaymentPercent(e.target.value)}
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  ) : (
                    <Input
                      type="number"
                      placeholder="Enter amount"
                      value={downPaymentAmount}
                      onChange={(e) => setDownPaymentAmount(e.target.value)}
                      min="0"
                      step="1000"
                    />
                  )}
                </div>

                {/* Loan Term */}
                <div className="space-y-2">
                  <Label htmlFor="loanTerm">Loan Term</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {["15", "20", "30"].map((term) => (
                      <button
                        key={term}
                        onClick={() => setLoanTerm(term)}
                        className={`py-2 px-3 rounded-lg border-2 text-sm font-medium transition-all ${
                          loanTerm === term
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background border-border hover:border-primary/50"
                        }`}
                      >
                        {term}y
                      </button>
                    ))}
                    <Input
                      id="loanTerm"
                      type="number"
                      placeholder="Custom"
                      value={loanTerm !== "15" && loanTerm !== "20" && loanTerm !== "30" ? loanTerm : ""}
                      onChange={(e) => setLoanTerm(e.target.value)}
                      min="1"
                      className="text-sm"
                    />
                  </div>
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Enter interest rate"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Optional Fields - Collapsible */}
                <details className="group">
                  <summary className="flex items-center justify-between cursor-pointer text-sm font-medium text-muted-foreground hover:text-foreground">
                    <span>Optional: Taxes, Insurance & HOA</span>
                    <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" />
                  </summary>
                  <div className="mt-4 space-y-4 pt-2 border-t">
                    <div className="space-y-2">
                      <Label htmlFor="propertyTax">Annual Property Tax ($)</Label>
                      <Input
                        id="propertyTax"
                        type="number"
                        placeholder="Optional"
                        value={propertyTax}
                        onChange={(e) => setPropertyTax(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="homeInsurance">Annual Home Insurance ($)</Label>
                      <Input
                        id="homeInsurance"
                        type="number"
                        placeholder="Optional"
                        value={homeInsurance}
                        onChange={(e) => setHomeInsurance(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="hoaFees">Monthly HOA Fees ($)</Label>
                      <Input
                        id="hoaFees"
                        type="number"
                        placeholder="Optional"
                        value={hoaFees}
                        onChange={(e) => setHoaFees(e.target.value)}
                        min="0"
                      />
                    </div>
                  </div>
                </details>

                {/* Extra Payment */}
                <details className="group">
                  <summary className="flex items-center justify-between cursor-pointer text-sm font-medium text-muted-foreground hover:text-foreground">
                    <span>Optional: Extra Monthly Payment</span>
                    <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" />
                  </summary>
                  <div className="mt-4 space-y-2 pt-2 border-t">
                    <Label htmlFor="extraPayment">Extra Monthly Payment ($)</Label>
                    <Input
                      id="extraPayment"
                      type="number"
                      placeholder="Enter extra payment amount"
                      value={extraPayment}
                      onChange={(e) => setExtraPayment(e.target.value)}
                      min="0"
                    />
                  </div>
                </details>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMortgage} className="w-full" size="lg">
                  Calculate Mortgage
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-green-200">
                        <p className="text-sm text-muted-foreground mb-1">Monthly Payment (P&I)</p>
                        <p className="text-4xl font-bold text-green-600">${result.monthlyPI.toLocaleString()}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground">Total w/ PITI</p>
                          <p className="font-semibold text-foreground">${result.monthlyPITI.toLocaleString()}/mo</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Loan Amount</p>
                          <p className="font-semibold text-foreground">${result.loanAmount.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Total Interest</p>
                          <p className="font-semibold text-foreground">${result.totalInterest.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Payoff Date</p>
                          <p className="font-semibold text-foreground">{result.payoffDate}</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4 pt-3 border-t border-green-200">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mortgage Components</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold mb-1">Principal & Interest (P&I)</p>
                      <p className="text-muted-foreground">
                        The base mortgage payment covering loan principal and interest charges
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold mb-1">Property Tax</p>
                      <p className="text-muted-foreground">
                        Annual taxes paid to local government, divided into monthly payments
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold mb-1">Home Insurance</p>
                      <p className="text-muted-foreground">Required insurance covering property damage and liability</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold mb-1">HOA Fees</p>
                      <p className="text-muted-foreground">
                        Monthly homeowners association fees for community amenities and maintenance
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-xs">
                    <p className="font-semibold text-foreground mb-2">Monthly Payment (P&I):</p>
                    <p className="break-all">M = P × [r(1+r)ⁿ] / [(1+r)ⁿ - 1]</p>
                  </div>
                  <div className="space-y-1">
                    <p>
                      <strong>P</strong> = Loan amount (Price - Down payment)
                    </p>
                    <p>
                      <strong>r</strong> = Monthly interest rate (Annual rate / 12)
                    </p>
                    <p>
                      <strong>n</strong> = Total number of payments (Years × 12)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-600" />
                    <CardTitle className="text-lg text-amber-900">Disclaimer</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="text-sm text-amber-800">
                  <p>
                    This calculator provides estimates only. Actual mortgage terms and costs may vary by lender and
                    location. Consult with a mortgage professional for accurate quotes.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Mortgages</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A mortgage is a loan specifically designed for purchasing real estate, where the property itself
                  serves as collateral for the loan. For most Americans, a mortgage represents the largest financial
                  commitment they'll ever make, typically spanning 15 to 30 years. Understanding how mortgages work is
                  crucial for making informed decisions about homeownership and building long-term wealth through real
                  estate.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When you take out a mortgage, you're essentially borrowing money from a lender (usually a bank or
                  mortgage company) to purchase a home. In return, you agree to pay back the loan amount plus interest
                  over a specified period. The interest rate, loan term, and down payment all significantly impact your
                  monthly payment and the total amount you'll pay over the life of the loan. Even small differences in
                  interest rates can result in thousands of dollars in savings or additional costs over time.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Mortgage Payment Components (PITI)</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Your total monthly mortgage payment typically consists of four main components, commonly referred to
                  as PITI: Principal, Interest, Taxes, and Insurance. The principal is the portion of your payment that
                  goes toward paying down the actual loan amount. The interest is what the lender charges you for
                  borrowing the money. As you progress through your mortgage, a larger portion of your payment goes
                  toward principal and less toward interest.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Property taxes are collected by your lender and held in an escrow account, then paid to your local
                  government on your behalf, typically once or twice a year. Homeowners insurance protects your property
                  against damage and is also usually collected monthly and paid from your escrow account. Many lenders
                  require private mortgage insurance (PMI) if your down payment is less than 20%, adding an additional
                  monthly cost until you reach 20% equity in your home.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Home className="h-5 w-5 text-primary" />
                  <CardTitle>Down Payments and Loan-to-Value Ratio</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The down payment is the upfront cash payment you make toward the purchase of your home, expressed
                  either as a dollar amount or a percentage of the home's purchase price. While the traditional down
                  payment has been 20% of the home's value, many loan programs today allow for much lower down payments,
                  sometimes as low as 3% for first-time buyers. However, a larger down payment offers several
                  advantages: it reduces your monthly payment, helps you build equity faster, may qualify you for better
                  interest rates, and can eliminate the need for PMI.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Your loan-to-value (LTV) ratio is calculated by dividing your loan amount by the home's appraised
                  value. For example, if you're buying a $300,000 home with a $60,000 down payment, your loan amount is
                  $240,000, giving you an LTV of 80%. Lenders use LTV to assess risk—higher LTV ratios mean more risk
                  for the lender, which often results in higher interest rates or additional requirements like PMI.
                  Keeping your LTV at 80% or lower (20% down payment) typically provides the most favorable terms.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Mortgage Terms and Amortization</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The mortgage term refers to the length of time you have to repay your loan. The most common terms are
                  15 and 30 years, though other options like 10, 20, or 40 years exist. A 30-year mortgage offers lower
                  monthly payments but results in paying significantly more interest over the life of the loan.
                  Conversely, a 15-year mortgage has higher monthly payments but builds equity much faster and saves
                  tens of thousands of dollars in interest charges.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Amortization is the process by which your loan balance decreases over time through regular payments.
                  In the early years of your mortgage, the majority of each payment goes toward interest, with only a
                  small portion reducing the principal. As time passes, this ratio gradually shifts, and by the final
                  years of your loan, most of your payment is going toward principal. This front-loaded interest
                  structure is why making extra principal payments early in your mortgage term can have such a dramatic
                  impact on total interest paid and loan payoff time.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Making Extra Payments</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Making extra principal payments is one of the most effective strategies for paying off your mortgage
                  early and saving substantial money on interest. Even small additional payments can shave years off
                  your mortgage and save tens of thousands in interest. For example, on a $300,000 mortgage at 6%
                  interest, paying just an extra $200 per month could save you over $80,000 in interest and help you pay
                  off your loan nearly 8 years early.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Before making extra payments, verify that your lender doesn't charge prepayment penalties and ensure
                  the extra amount is applied to principal, not future payments. Consider whether accelerating mortgage
                  payoff is your best financial move—if you have high-interest debt like credit cards, it often makes
                  more sense to pay those off first. Similarly, if your employer offers a 401(k) match, contributing
                  enough to get the full match typically provides better returns than extra mortgage payments. The key
                  is to balance mortgage acceleration with other financial goals and opportunities.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
