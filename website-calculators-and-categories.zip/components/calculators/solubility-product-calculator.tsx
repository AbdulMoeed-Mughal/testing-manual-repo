"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Beaker, Info, AlertTriangle, FlaskConical, Atom } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type SaltType = "MX" | "MX2" | "M2X" | "MX3" | "M2X3"
type InputMode = "solubility" | "ksp"

interface KspResult {
  ksp: number
  solubility: number
  cationConc: number
  anionConc: number
  saltType: SaltType
}

const saltTypeInfo: Record<SaltType, { formula: string; kspFormula: string; cationCoeff: number; anionCoeff: number }> = {
  MX: { formula: "MX ⇌ M⁺ + X⁻", kspFormula: "Ksp = [M⁺][X⁻] = S²", cationCoeff: 1, anionCoeff: 1 },
  MX2: { formula: "MX₂ ⇌ M²⁺ + 2X⁻", kspFormula: "Ksp = [M²⁺][X⁻]² = 4S³", cationCoeff: 1, anionCoeff: 2 },
  M2X: { formula: "M₂X ⇌ 2M⁺ + X²⁻", kspFormula: "Ksp = [M⁺]²[X²⁻] = 4S³", cationCoeff: 2, anionCoeff: 1 },
  MX3: { formula: "MX₃ ⇌ M³⁺ + 3X⁻", kspFormula: "Ksp = [M³⁺][X⁻]³ = 27S⁴", cationCoeff: 1, anionCoeff: 3 },
  M2X3: { formula: "M₂X₃ ⇌ 2M³⁺ + 3X²⁻", kspFormula: "Ksp = [M³⁺]²[X²⁻]³ = 108S⁵", cationCoeff: 2, anionCoeff: 3 },
}

export function SolubilityProductCalculator() {
  const [saltType, setSaltType] = useState<SaltType>("MX")
  const [inputMode, setInputMode] = useState<InputMode>("solubility")
  const [solubility, setSolubility] = useState("")
  const [kspInput, setKspInput] = useState("")
  const [result, setResult] = useState<KspResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateKsp = () => {
    setError("")
    setResult(null)

    if (inputMode === "solubility") {
      const S = Number.parseFloat(solubility)
      if (isNaN(S) || S <= 0) {
        setError("Please enter a valid solubility value greater than 0")
        return
      }

      let ksp: number
      let cationConc: number
      let anionConc: number

      const info = saltTypeInfo[saltType]
      cationConc = info.cationCoeff * S
      anionConc = info.anionCoeff * S

      switch (saltType) {
        case "MX":
          ksp = S * S
          break
        case "MX2":
        case "M2X":
          ksp = 4 * Math.pow(S, 3)
          break
        case "MX3":
          ksp = 27 * Math.pow(S, 4)
          break
        case "M2X3":
          ksp = 108 * Math.pow(S, 5)
          break
        default:
          ksp = S * S
      }

      setResult({
        ksp,
        solubility: S,
        cationConc,
        anionConc,
        saltType,
      })
    } else {
      const ksp = Number.parseFloat(kspInput)
      if (isNaN(ksp) || ksp <= 0) {
        setError("Please enter a valid Ksp value greater than 0")
        return
      }

      let S: number

      switch (saltType) {
        case "MX":
          S = Math.sqrt(ksp)
          break
        case "MX2":
        case "M2X":
          S = Math.pow(ksp / 4, 1 / 3)
          break
        case "MX3":
          S = Math.pow(ksp / 27, 1 / 4)
          break
        case "M2X3":
          S = Math.pow(ksp / 108, 1 / 5)
          break
        default:
          S = Math.sqrt(ksp)
      }

      const info = saltTypeInfo[saltType]
      const cationConc = info.cationCoeff * S
      const anionConc = info.anionCoeff * S

      setResult({
        ksp,
        solubility: S,
        cationConc,
        anionConc,
        saltType,
      })
    }
  }

  const handleReset = () => {
    setSolubility("")
    setKspInput("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = inputMode === "solubility"
        ? `Ksp = ${result.ksp.toExponential(3)}, [M] = ${result.cationConc.toExponential(3)} M, [X] = ${result.anionConc.toExponential(3)} M`
        : `Solubility = ${result.solubility.toExponential(3)} M, [M] = ${result.cationConc.toExponential(3)} M, [X] = ${result.anionConc.toExponential(3)} M`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Ksp Calculation Result",
          text: `Ksp = ${result.ksp.toExponential(3)}, Solubility = ${result.solubility.toExponential(3)} M`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleInputMode = () => {
    setInputMode((prev) => (prev === "solubility" ? "ksp" : "solubility"))
    setSolubility("")
    setKspInput("")
    setResult(null)
    setError("")
  }

  const formatScientific = (num: number): string => {
    if (num === 0) return "0"
    if (num >= 0.001 && num < 10000) {
      return num.toPrecision(4)
    }
    return num.toExponential(3)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Beaker className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Solubility Product Calculator</CardTitle>
                    <CardDescription>Calculate Ksp or solubility for sparingly soluble salts</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculate</span>
                  <button
                    onClick={toggleInputMode}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "ksp" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "solubility" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Ksp from S
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "ksp" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      S from Ksp
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Salt Type Selection */}
                <div className="space-y-2">
                  <Label>Salt Stoichiometry</Label>
                  <div className="grid grid-cols-5 gap-2">
                    {(Object.keys(saltTypeInfo) as SaltType[]).map((type) => (
                      <button
                        key={type}
                        onClick={() => {
                          setSaltType(type)
                          setResult(null)
                        }}
                        className={`p-2 rounded-lg text-sm font-medium transition-colors ${
                          saltType === type
                            ? "bg-purple-600 text-white"
                            : "bg-muted hover:bg-muted/80 text-foreground"
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {saltTypeInfo[saltType].formula}
                  </p>
                </div>

                {/* Input Field */}
                {inputMode === "solubility" ? (
                  <div className="space-y-2">
                    <Label htmlFor="solubility">Molar Solubility, S (mol/L)</Label>
                    <Input
                      id="solubility"
                      type="text"
                      placeholder="e.g., 1.3e-4 or 0.00013"
                      value={solubility}
                      onChange={(e) => setSolubility(e.target.value)}
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="ksp">Solubility Product, Ksp</Label>
                    <Input
                      id="ksp"
                      type="text"
                      placeholder="e.g., 1.8e-10 or 0.00000000018"
                      value={kspInput}
                      onChange={(e) => setKspInput(e.target.value)}
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateKsp} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {inputMode === "solubility" ? "Solubility Product (Ksp)" : "Molar Solubility (S)"}
                      </p>
                      <p className="text-4xl font-bold text-purple-600 mb-2">
                        {inputMode === "solubility"
                          ? formatScientific(result.ksp)
                          : `${formatScientific(result.solubility)} M`}
                      </p>
                    </div>

                    {/* Ion Concentrations Table */}
                    <div className="mt-4 p-3 bg-white rounded-lg">
                      <p className="text-sm font-medium text-center mb-2">Equilibrium Ion Concentrations</p>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="p-2 bg-purple-50 rounded text-center">
                          <span className="text-muted-foreground">[Cation]</span>
                          <p className="font-semibold text-purple-700">{formatScientific(result.cationConc)} M</p>
                        </div>
                        <div className="p-2 bg-purple-50 rounded text-center">
                          <span className="text-muted-foreground">[Anion]</span>
                          <p className="font-semibold text-purple-700">{formatScientific(result.anionConc)} M</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Ksp Formulas by Salt Type</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {(Object.entries(saltTypeInfo) as [SaltType, typeof saltTypeInfo[SaltType]][]).map(([type, info]) => (
                      <div
                        key={type}
                        className={`flex items-center justify-between p-3 rounded-lg ${
                          saltType === type ? "bg-purple-50 border border-purple-200" : "bg-muted"
                        }`}
                      >
                        <span className={`font-medium ${saltType === type ? "text-purple-700" : ""}`}>{type}</span>
                        <span className={`text-sm font-mono ${saltType === type ? "text-purple-600" : "text-muted-foreground"}`}>
                          {info.kspFormula}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Ksp Values</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 bg-muted rounded">
                      <p className="font-medium text-foreground">AgCl</p>
                      <p>1.8 × 10⁻¹⁰</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-medium text-foreground">CaCO₃</p>
                      <p>3.4 × 10⁻⁹</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-medium text-foreground">BaSO₄</p>
                      <p>1.1 × 10⁻¹⁰</p>
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <p className="font-medium text-foreground">PbI₂</p>
                      <p>9.8 × 10⁻⁹</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Ksp */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Solubility Product Constant (Ksp)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The solubility product constant (Ksp) is an equilibrium constant that describes the dissolution of a
                  sparingly soluble ionic compound in water. When a slightly soluble salt dissolves, it dissociates into
                  its constituent ions until equilibrium is reached between the solid and dissolved ions. The Ksp
                  represents this equilibrium and is calculated as the product of the ion concentrations raised to their
                  stoichiometric coefficients.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, when silver chloride (AgCl) dissolves in water, it establishes the equilibrium:
                  AgCl(s) ⇌ Ag⁺(aq) + Cl⁻(aq). The Ksp expression is Ksp = [Ag⁺][Cl⁻]. A smaller Ksp value indicates
                  lower solubility, while a larger Ksp indicates higher solubility. Understanding Ksp is essential for
                  predicting precipitation reactions, analyzing solution chemistry, and many industrial applications.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Ksp */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Ksp from Solubility</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate Ksp from molar solubility (S), you need to determine the equilibrium concentrations of
                  each ion and then apply the Ksp expression. The relationship depends on the stoichiometry of the salt.
                  For a simple 1:1 salt like AgCl with solubility S, both [Ag⁺] and [Cl⁻] equal S, giving Ksp = S².
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For salts with different stoichiometries, the calculation is more complex. Consider PbI₂ which
                  dissociates as: PbI₂(s) ⇌ Pb²⁺(aq) + 2I⁻(aq). If the solubility is S, then [Pb²⁺] = S and [I⁻] = 2S.
                  Therefore, Ksp = [Pb²⁺][I⁻]² = (S)(2S)² = 4S³. This relationship between Ksp and S varies with salt
                  type, which is why selecting the correct stoichiometry is crucial for accurate calculations.
                </p>
              </CardContent>
            </Card>

            {/* Applications of Ksp */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Solubility Product</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The solubility product constant has numerous practical applications in chemistry and industry. In
                  qualitative analysis, Ksp values help predict whether a precipitate will form when solutions are mixed.
                  By comparing the ion product (Q) to Ksp, chemists can determine if a solution is unsaturated (Q {"<"} Ksp),
                  saturated (Q = Ksp), or supersaturated (Q {">"} Ksp).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In water treatment, Ksp values guide the removal of heavy metals and other contaminants through
                  precipitation. The common ion effect, where adding a common ion decreases solubility, is used to
                  selectively precipitate compounds. In medicine, understanding Ksp helps in studying kidney stone
                  formation (calcium oxalate) and developing treatments. Environmental scientists use Ksp to model
                  mineral weathering and groundwater chemistry.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations of Ksp Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ksp calculations assume ideal dilute solution behavior, which may not hold in all conditions. The
                  presence of other ions in solution (ionic strength effects) can significantly alter actual solubility
                  compared to predicted values. Activity coefficients should be used instead of concentrations for more
                  accurate calculations in solutions with high ionic strength.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature affects Ksp values, as most Ksp data is reported at 25°C. Complex ion formation can
                  increase apparent solubility beyond what Ksp predicts. For example, AgCl is more soluble in ammonia
                  solution due to formation of [Ag(NH₃)₂]⁺ complex ions. Additionally, the common ion effect, pH
                  effects (for salts of weak acids or bases), and kinetic factors can all cause deviations from simple
                  Ksp predictions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
