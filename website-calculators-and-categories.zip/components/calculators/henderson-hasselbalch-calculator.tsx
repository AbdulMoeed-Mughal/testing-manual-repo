"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Beaker, Activity } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type BufferType = "acidic" | "basic"

interface HHResult {
  pH: number
  pOH: number
  pKa: number
  pKb: number
  ratio: number
  bufferCapacity: string
  effectiveRange: { min: number; max: number }
}

export function HendersonHasselbalchCalculator() {
  const [bufferType, setBufferType] = useState<BufferType>("acidic")
  const [ka, setKa] = useState("")
  const [kb, setKb] = useState("")
  const [acidConc, setAcidConc] = useState("")
  const [baseConc, setBaseConc] = useState("")
  const [result, setResult] = useState<HHResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const acidConcNum = Number.parseFloat(acidConc)
    const baseConcNum = Number.parseFloat(baseConc)

    if (isNaN(acidConcNum) || acidConcNum <= 0) {
      setError(bufferType === "acidic" ? "Please enter a valid weak acid concentration greater than 0" : "Please enter a valid weak base concentration greater than 0")
      return
    }

    if (isNaN(baseConcNum) || baseConcNum <= 0) {
      setError(bufferType === "acidic" ? "Please enter a valid conjugate base concentration greater than 0" : "Please enter a valid conjugate acid concentration greater than 0")
      return
    }

    let pKa: number
    let pKb: number

    if (bufferType === "acidic") {
      const kaNum = Number.parseFloat(ka)
      if (isNaN(kaNum) || kaNum <= 0) {
        setError("Please enter a valid Ka value greater than 0")
        return
      }
      pKa = -Math.log10(kaNum)
      pKb = 14 - pKa
    } else {
      const kbNum = Number.parseFloat(kb)
      if (isNaN(kbNum) || kbNum <= 0) {
        setError("Please enter a valid Kb value greater than 0")
        return
      }
      pKb = -Math.log10(kbNum)
      pKa = 14 - pKb
    }

    let pH: number
    let pOH: number
    let ratio: number

    if (bufferType === "acidic") {
      // pH = pKa + log([A-]/[HA])
      ratio = baseConcNum / acidConcNum
      pH = pKa + Math.log10(ratio)
      pOH = 14 - pH
    } else {
      // pOH = pKb + log([BH+]/[B])
      ratio = acidConcNum / baseConcNum
      pOH = pKb + Math.log10(ratio)
      pH = 14 - pOH
    }

    // Buffer capacity assessment
    let bufferCapacity: string
    if (ratio >= 0.1 && ratio <= 10) {
      bufferCapacity = "Good"
    } else if (ratio >= 0.01 && ratio <= 100) {
      bufferCapacity = "Moderate"
    } else {
      bufferCapacity = "Poor"
    }

    // Effective buffer range (pKa ± 1)
    const effectiveRange = {
      min: Math.round((pKa - 1) * 100) / 100,
      max: Math.round((pKa + 1) * 100) / 100
    }

    setResult({
      pH: Math.round(pH * 1000) / 1000,
      pOH: Math.round(pOH * 1000) / 1000,
      pKa: Math.round(pKa * 1000) / 1000,
      pKb: Math.round(pKb * 1000) / 1000,
      ratio: Math.round(ratio * 1000) / 1000,
      bufferCapacity,
      effectiveRange
    })
  }

  const handleReset = () => {
    setKa("")
    setKb("")
    setAcidConc("")
    setBaseConc("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = bufferType === "acidic"
        ? `pH = ${result.pH}, pOH = ${result.pOH}, Ratio [A⁻]/[HA] = ${result.ratio}`
        : `pOH = ${result.pOH}, pH = ${result.pH}, Ratio [BH⁺]/[B] = ${result.ratio}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Henderson-Hasselbalch Calculator Result",
          text: `I calculated buffer pH using the Henderson-Hasselbalch equation! pH = ${result.pH}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleBufferType = () => {
    setBufferType((prev) => (prev === "acidic" ? "basic" : "acidic"))
    setKa("")
    setKb("")
    setAcidConc("")
    setBaseConc("")
    setResult(null)
    setError("")
  }

  const getpHColor = (pH: number) => {
    if (pH < 3) return { color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
    if (pH < 6) return { color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    if (pH < 8) return { color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    if (pH < 11) return { color: "text-blue-600", bgColor: "bg-blue-50 border-blue-200" }
    return { color: "text-purple-600", bgColor: "bg-purple-50 border-purple-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Henderson-Hasselbalch Calculator</CardTitle>
                    <CardDescription>Calculate buffer pH using the H-H equation</CardDescription>
                  </div>
                </div>

                {/* Buffer Type Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Buffer Type</span>
                  <button
                    onClick={toggleBufferType}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        bufferType === "basic" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        bufferType === "acidic" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Acidic
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        bufferType === "basic" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Basic
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Ka or Kb Input */}
                {bufferType === "acidic" ? (
                  <div className="space-y-2">
                    <Label htmlFor="ka">Acid Dissociation Constant (Ka)</Label>
                    <Input
                      id="ka"
                      type="text"
                      placeholder="e.g., 1.8e-5 or 0.000018"
                      value={ka}
                      onChange={(e) => setKa(e.target.value)}
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="kb">Base Dissociation Constant (Kb)</Label>
                    <Input
                      id="kb"
                      type="text"
                      placeholder="e.g., 1.8e-5 or 0.000018"
                      value={kb}
                      onChange={(e) => setKb(e.target.value)}
                    />
                  </div>
                )}

                {/* Concentration Inputs */}
                <div className="space-y-2">
                  <Label htmlFor="acidConc">
                    {bufferType === "acidic" ? "Weak Acid Concentration [HA] (M)" : "Conjugate Acid Concentration [BH⁺] (M)"}
                  </Label>
                  <Input
                    id="acidConc"
                    type="number"
                    placeholder="Enter concentration in mol/L"
                    value={acidConc}
                    onChange={(e) => setAcidConc(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="baseConc">
                    {bufferType === "acidic" ? "Conjugate Base Concentration [A⁻] (M)" : "Weak Base Concentration [B] (M)"}
                  </Label>
                  <Input
                    id="baseConc"
                    type="number"
                    placeholder="Enter concentration in mol/L"
                    value={baseConc}
                    onChange={(e) => setBaseConc(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate pH
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getpHColor(result.pH).bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Calculated pH</p>
                      <p className={`text-5xl font-bold ${getpHColor(result.pH).color} mb-2`}>{result.pH}</p>
                      <p className="text-sm text-muted-foreground">pOH = {result.pOH}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">pKa</p>
                        <p className="font-semibold">{result.pKa}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Ratio</p>
                        <p className="font-semibold">{result.ratio}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Buffer Capacity</p>
                        <p className={`font-semibold ${result.bufferCapacity === "Good" ? "text-green-600" : result.bufferCapacity === "Moderate" ? "text-yellow-600" : "text-red-600"}`}>
                          {result.bufferCapacity}
                        </p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Effective Range</p>
                        <p className="font-semibold">{result.effectiveRange.min} - {result.effectiveRange.max}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">pH Scale Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Strongly Acidic</span>
                      <span className="text-sm text-red-600">pH 0-3</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Weakly Acidic</span>
                      <span className="text-sm text-orange-600">pH 3-6</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Neutral</span>
                      <span className="text-sm text-green-600">pH 6-8</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Weakly Basic</span>
                      <span className="text-sm text-blue-600">pH 8-11</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Strongly Basic</span>
                      <span className="text-sm text-purple-600">pH 11-14</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Henderson-Hasselbalch Equations</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">For Acidic Buffers:</p>
                    <p className="text-foreground mt-1">pH = pKa + log([A⁻]/[HA])</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">For Basic Buffers:</p>
                    <p className="text-foreground mt-1">pOH = pKb + log([BH⁺]/[B])</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Henderson-Hasselbalch */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Henderson-Hasselbalch Equation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Henderson-Hasselbalch equation is a fundamental relationship in acid-base chemistry that describes
                  the pH of a buffer solution. Named after Lawrence Joseph Henderson and Karl Albert Hasselbalch, this
                  equation provides a convenient way to calculate the pH of a solution containing a weak acid and its
                  conjugate base, or a weak base and its conjugate acid.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equation is derived from the equilibrium expression for weak acid dissociation and is particularly
                  useful for understanding buffer systems. It relates the pH directly to the pKa (or pKb) of the acid
                  (or base) and the ratio of the concentrations of the conjugate pair. This relationship is essential
                  in biochemistry, pharmacy, and environmental science where pH control is critical.
                </p>
              </CardContent>
            </Card>

            {/* How Calculations Work */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>How the Calculation Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  For an acidic buffer system containing a weak acid (HA) and its conjugate base (A⁻), the pH is
                  calculated using: pH = pKa + log([A⁻]/[HA]). The pKa is first calculated from the Ka value using
                  pKa = -log(Ka). When the concentrations of acid and conjugate base are equal, the pH equals the pKa.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For basic buffer systems containing a weak base (B) and its conjugate acid (BH⁺), the equation
                  becomes: pOH = pKb + log([BH⁺]/[B]). The pH is then found using pH = 14 - pOH. The ratio of
                  concentrations determines how far the pH shifts from the pKa value. A ratio greater than 1 shifts
                  pH higher (more basic), while a ratio less than 1 shifts pH lower (more acidic).
                </p>
              </CardContent>
            </Card>

            {/* Buffer Capacity */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Buffer Capacity</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Buffer capacity refers to the ability of a buffer solution to resist changes in pH when acid or base
                  is added. A buffer works best when the ratio of [A⁻]/[HA] (or [BH⁺]/[B]) is close to 1:1. The
                  effective buffering range is generally considered to be within ±1 pH unit of the pKa value.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Good Buffer Capacity (Ratio 0.1 to 10)</h4>
                    <p className="text-green-700 text-sm">
                      The buffer effectively resists pH changes. This range corresponds to pH = pKa ± 1, where the
                      buffer has maximum capacity to neutralize added acids or bases.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Moderate Buffer Capacity (Ratio 0.01 to 100)</h4>
                    <p className="text-yellow-700 text-sm">
                      The buffer still provides some resistance to pH changes but is less effective. Small additions
                      of strong acid or base may cause noticeable pH shifts.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Poor Buffer Capacity (Ratio outside 0.01 to 100)</h4>
                    <p className="text-red-700 text-sm">
                      The solution has minimal buffering ability. The pH is dominated by one component, and small
                      additions of acid or base will cause significant pH changes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations of the Henderson-Hasselbalch Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the Henderson-Hasselbalch equation is widely used, it has several important limitations. The
                  equation assumes ideal solution behavior and uses concentrations rather than activities. At high
                  ionic strengths or with charged species, activity coefficients can significantly affect the actual pH.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The equation also assumes that the equilibrium concentrations of the acid and conjugate base are
                  approximately equal to their initial concentrations. This assumption breaks down for very dilute
                  solutions or when the Ka value is relatively large. For polyprotic acids, each dissociation step
                  requires its own Henderson-Hasselbalch calculation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Temperature effects are another consideration—Ka values change with temperature, which affects the
                  calculated pH. For accurate measurements in real-world applications, direct pH measurement with a
                  calibrated pH meter is recommended, using the Henderson-Hasselbalch equation as a guide for buffer
                  preparation and understanding.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-purple-600" />
                  <CardTitle>Applications of the Henderson-Hasselbalch Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The Henderson-Hasselbalch equation has numerous practical applications across various scientific
                  disciplines. In biochemistry, it is essential for understanding blood pH regulation through the
                  bicarbonate buffer system and for preparing laboratory buffers at specific pH values for enzyme
                  assays and protein studies.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In pharmacy, the equation helps predict drug ionization states at different pH values, which is
                  crucial for understanding drug absorption, distribution, and bioavailability. Pharmaceutical
                  scientists use it to formulate medications with optimal stability and efficacy.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Environmental scientists apply the equation to understand natural buffer systems in lakes, oceans,
                  and soil. The carbonate buffer system in seawater, for example, is critical for marine life and
                  climate regulation. Understanding these buffer systems helps scientists predict and mitigate the
                  effects of acid rain and ocean acidification.
                </p>
              </CardContent>
            </Card>
          </div>
          {/* End of content section */}
        </div>
      </main>

      <Footer />
    </div>
  )
}
