"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Beaker, ArrowRightLeft } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "concentration" | "pressure"

interface Species {
  name: string
  coefficient: string
  value: string
}

interface QResult {
  q: number
  k: number
  direction: string
  color: string
  bgColor: string
}

export function ReactionQuotientCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("concentration")
  const [reactants, setReactants] = useState<Species[]>([
    { name: "A", coefficient: "1", value: "" },
    { name: "B", coefficient: "1", value: "" },
  ])
  const [products, setProducts] = useState<Species[]>([
    { name: "C", coefficient: "1", value: "" },
    { name: "D", coefficient: "1", value: "" },
  ])
  const [equilibriumConstant, setEquilibriumConstant] = useState("")
  const [result, setResult] = useState<QResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const updateReactant = (index: number, field: keyof Species, value: string) => {
    const updated = [...reactants]
    updated[index][field] = value
    setReactants(updated)
  }

  const updateProduct = (index: number, field: keyof Species, value: string) => {
    const updated = [...products]
    updated[index][field] = value
    setProducts(updated)
  }

  const addReactant = () => {
    if (reactants.length < 4) {
      const names = ["A", "B", "E", "F"]
      const nextName = names[reactants.length] || `R${reactants.length + 1}`
      setReactants([...reactants, { name: nextName, coefficient: "1", value: "" }])
    }
  }

  const addProduct = () => {
    if (products.length < 4) {
      const names = ["C", "D", "G", "H"]
      const nextName = names[products.length] || `P${products.length + 1}`
      setProducts([...products, { name: nextName, coefficient: "1", value: "" }])
    }
  }

  const removeReactant = (index: number) => {
    if (reactants.length > 1) {
      setReactants(reactants.filter((_, i) => i !== index))
    }
  }

  const removeProduct = (index: number) => {
    if (products.length > 1) {
      setProducts(products.filter((_, i) => i !== index))
    }
  }

  const calculateQ = () => {
    setError("")
    setResult(null)

    // Validate K
    const k = Number.parseFloat(equilibriumConstant)
    if (isNaN(k) || k <= 0) {
      setError("Please enter a valid equilibrium constant (K) greater than 0")
      return
    }

    // Validate and calculate products numerator
    let numerator = 1
    for (const product of products) {
      const coef = Number.parseFloat(product.coefficient)
      const val = Number.parseFloat(product.value)
      if (isNaN(coef) || coef <= 0) {
        setError(`Please enter a valid coefficient for product ${product.name}`)
        return
      }
      if (isNaN(val) || val < 0) {
        setError(`Please enter a valid ${unitSystem === "concentration" ? "concentration" : "pressure"} for product ${product.name}`)
        return
      }
      if (val === 0) {
        numerator = 0
        break
      }
      numerator *= Math.pow(val, coef)
    }

    // Validate and calculate reactants denominator
    let denominator = 1
    for (const reactant of reactants) {
      const coef = Number.parseFloat(reactant.coefficient)
      const val = Number.parseFloat(reactant.value)
      if (isNaN(coef) || coef <= 0) {
        setError(`Please enter a valid coefficient for reactant ${reactant.name}`)
        return
      }
      if (isNaN(val) || val <= 0) {
        setError(`Please enter a valid ${unitSystem === "concentration" ? "concentration" : "pressure"} for reactant ${reactant.name} (must be > 0)`)
        return
      }
      denominator *= Math.pow(val, coef)
    }

    const q = numerator / denominator

    let direction: string
    let color: string
    let bgColor: string

    const ratio = q / k
    if (ratio < 0.99) {
      direction = "Forward (Q < K)"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (ratio > 1.01) {
      direction = "Reverse (Q > K)"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else {
      direction = "At Equilibrium (Q ≈ K)"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    }

    setResult({ q, k, direction, color, bgColor })
  }

  const handleReset = () => {
    setReactants([
      { name: "A", coefficient: "1", value: "" },
      { name: "B", coefficient: "1", value: "" },
    ])
    setProducts([
      { name: "C", coefficient: "1", value: "" },
      { name: "D", coefficient: "1", value: "" },
    ])
    setEquilibriumConstant("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Reaction Quotient Q = ${result.q.toExponential(4)}, K = ${result.k}, Direction: ${result.direction}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Reaction Quotient Result",
          text: `I calculated the reaction quotient using CalcHub! Q = ${result.q.toExponential(4)}, Reaction proceeds: ${result.direction}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "concentration" ? "pressure" : "concentration"))
    setResult(null)
    setError("")
  }

  const formatQ = (q: number): string => {
    if (q === 0) return "0"
    if (q >= 0.001 && q < 10000) {
      return q.toPrecision(4)
    }
    return q.toExponential(3)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Reaction Quotient Calculator</CardTitle>
                    <CardDescription>Calculate Q and predict reaction direction</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Type</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "pressure" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "concentration" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Conc (M)
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "pressure" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Press (atm)
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Reactants */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-semibold">Reactants</Label>
                    {reactants.length < 4 && (
                      <Button variant="ghost" size="sm" onClick={addReactant} className="h-7 text-xs">
                        + Add
                      </Button>
                    )}
                  </div>
                  {reactants.map((reactant, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Input
                        type="text"
                        placeholder="Name"
                        value={reactant.name}
                        onChange={(e) => updateReactant(index, "name", e.target.value)}
                        className="w-16"
                      />
                      <Input
                        type="number"
                        placeholder="Coef"
                        value={reactant.coefficient}
                        onChange={(e) => updateReactant(index, "coefficient", e.target.value)}
                        className="w-16"
                        min="0"
                        step="1"
                      />
                      <Input
                        type="number"
                        placeholder={unitSystem === "concentration" ? "[M]" : "P (atm)"}
                        value={reactant.value}
                        onChange={(e) => updateReactant(index, "value", e.target.value)}
                        className="flex-1"
                        min="0"
                        step="any"
                      />
                      {reactants.length > 1 && (
                        <Button variant="ghost" size="sm" onClick={() => removeReactant(index)} className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive">
                          ×
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                {/* Products */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-semibold">Products</Label>
                    {products.length < 4 && (
                      <Button variant="ghost" size="sm" onClick={addProduct} className="h-7 text-xs">
                        + Add
                      </Button>
                    )}
                  </div>
                  {products.map((product, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Input
                        type="text"
                        placeholder="Name"
                        value={product.name}
                        onChange={(e) => updateProduct(index, "name", e.target.value)}
                        className="w-16"
                      />
                      <Input
                        type="number"
                        placeholder="Coef"
                        value={product.coefficient}
                        onChange={(e) => updateProduct(index, "coefficient", e.target.value)}
                        className="w-16"
                        min="0"
                        step="1"
                      />
                      <Input
                        type="number"
                        placeholder={unitSystem === "concentration" ? "[M]" : "P (atm)"}
                        value={product.value}
                        onChange={(e) => updateProduct(index, "value", e.target.value)}
                        className="flex-1"
                        min="0"
                        step="any"
                      />
                      {products.length > 1 && (
                        <Button variant="ghost" size="sm" onClick={() => removeProduct(index)} className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive">
                          ×
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                {/* Equilibrium Constant */}
                <div className="space-y-2">
                  <Label htmlFor="k">Equilibrium Constant (K)</Label>
                  <Input
                    id="k"
                    type="number"
                    placeholder="Enter K value"
                    value={equilibriumConstant}
                    onChange={(e) => setEquilibriumConstant(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateQ} className="w-full" size="lg">
                  Calculate Q
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Reaction Quotient (Q)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-2`}>{formatQ(result.q)}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.direction}</p>
                      <p className="text-xs text-muted-foreground mt-2">K = {result.k}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Q vs K Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Q &lt; K</span>
                      <span className="text-sm text-green-600">Forward reaction</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Q = K</span>
                      <span className="text-sm text-blue-600">At equilibrium</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Q &gt; K</span>
                      <span className="text-sm text-red-600">Reverse reaction</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Q Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Q = [Products]^n / [Reactants]^m</p>
                  </div>
                  <p>
                    For the reaction aA + bB ⇌ cC + dD:{" "}
                    <strong>Q = ([C]^c × [D]^d) / ([A]^a × [B]^b)</strong>
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Q */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Reaction Quotient (Q)?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The reaction quotient, denoted as Q, is a measure of the relative amounts of products and reactants 
                  present in a reaction mixture at any point in time. It has the same mathematical form as the 
                  equilibrium constant (K), but while K only applies when a system is at equilibrium, Q can be 
                  calculated at any moment during a reaction. This makes Q an invaluable tool for predicting which 
                  direction a reaction will proceed to reach equilibrium.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of Q was developed as part of the broader understanding of chemical equilibrium that 
                  emerged in the late 19th century. Norwegian chemists Cato Guldberg and Peter Waage formulated the 
                  law of mass action in 1864, which provided the theoretical foundation for both K and Q. By comparing 
                  the reaction quotient to the equilibrium constant, chemists can determine whether a reaction mixture 
                  has too many products (Q &gt; K), too many reactants (Q &lt; K), or is already at equilibrium (Q = K).
                </p>
              </CardContent>
            </Card>

            {/* How Q is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>How is Q Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The reaction quotient is calculated using the same expression as the equilibrium constant. For a 
                  general reaction aA + bB ⇌ cC + dD, the reaction quotient Qc (using concentrations) is given by: 
                  Qc = ([C]^c × [D]^d) / ([A]^a × [B]^b), where the brackets denote molar concentrations and the 
                  exponents are the stoichiometric coefficients from the balanced equation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For gas-phase reactions, it is often more convenient to use partial pressures instead of 
                  concentrations. The reaction quotient Qp uses partial pressures: Qp = (P_C^c × P_D^d) / (P_A^a × P_B^b). 
                  Note that pure solids and pure liquids are not included in the expression for Q because their 
                  concentrations remain essentially constant during the reaction. Only species in the aqueous phase 
                  (for Qc) or gas phase (for Qp) are included.
                </p>
              </CardContent>
            </Card>

            {/* Predicting Reaction Direction */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5 text-primary" />
                  <CardTitle>Predicting Reaction Direction</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The power of the reaction quotient lies in its ability to predict which direction a reaction will 
                  proceed. By comparing Q to the equilibrium constant K, we can determine the reaction's trajectory:
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">When Q &lt; K: Forward Reaction</h4>
                    <p className="text-green-700 text-sm">
                      The ratio of products to reactants is less than at equilibrium. The system responds by 
                      converting reactants into products, shifting the reaction to the right. This continues until 
                      Q increases to equal K.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">When Q = K: At Equilibrium</h4>
                    <p className="text-blue-700 text-sm">
                      The system is at chemical equilibrium. The rates of the forward and reverse reactions are 
                      equal, and there is no net change in concentrations over time. The reaction appears to have 
                      stopped, though both forward and reverse reactions continue at equal rates.
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">When Q &gt; K: Reverse Reaction</h4>
                    <p className="text-red-700 text-sm">
                      The ratio of products to reactants is greater than at equilibrium. The system responds by 
                      converting products back into reactants, shifting the reaction to the left. This continues 
                      until Q decreases to equal K.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations and Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the reaction quotient is a powerful tool, there are important limitations to consider. The 
                  standard Q expression assumes ideal behavior, where activities can be approximated by concentrations 
                  or partial pressures. In real systems, especially those with high concentrations or ionic solutions, 
                  significant deviations may occur due to intermolecular interactions and non-ideal behavior.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Additionally, Q only tells us the direction of the reaction, not how fast equilibrium will be 
                  reached. A reaction may be thermodynamically favorable (Q ≠ K) but kinetically slow due to a high 
                  activation energy barrier. Temperature also affects both K and the relationship between Qp and Qc 
                  (through the ideal gas law), so ensure all measurements are taken at the same temperature as the 
                  K value being used for comparison.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For ionic solutions, activities rather than concentrations should technically be used, especially 
                  at higher ionic strengths. Activity coefficients account for the non-ideal interactions between 
                  ions in solution. For most educational purposes and dilute solutions, concentrations provide 
                  reasonable approximations.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-purple-500" />
                  <CardTitle>Applications of Reaction Quotient</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The reaction quotient has numerous practical applications in chemistry and industry. In industrial 
                  processes like the Haber process for ammonia synthesis, engineers use Q to optimize conditions and 
                  maximize yield. By manipulating temperature, pressure, and reactant concentrations, they can ensure 
                  Q remains less than K, driving the reaction continuously toward product formation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In biochemistry, Q is essential for understanding metabolic pathways. Cells maintain certain 
                  reactions far from equilibrium (Q ≠ K) to provide driving force for essential processes. For 
                  example, the ATP hydrolysis reaction is maintained with Q much less than K, ensuring that ATP 
                  hydrolysis remains thermodynamically favorable for powering cellular work.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Environmental chemists use Q to predict the behavior of pollutants and the effectiveness of 
                  remediation strategies. Understanding whether a dissolution or precipitation reaction will proceed 
                  forward or backward helps in predicting contaminant mobility in groundwater and designing effective 
                  treatment systems.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
