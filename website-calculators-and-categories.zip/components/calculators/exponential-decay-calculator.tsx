"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, TrendingDown, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type CompoundingFrequency = "continuous" | "yearly" | "semi-annually" | "quarterly" | "monthly" | "daily"

interface DecayResult {
  finalValue: number
  decayFactor: number
  absoluteDecrease: number
  percentageDecrease: number
  schedule: { period: number; value: number; decrease: number }[]
}

export function ExponentialDecayCalculator() {
  const [initialValue, setInitialValue] = useState("")
  const [decayRate, setDecayRate] = useState("")
  const [timePeriod, setTimePeriod] = useState("")
  const [compounding, setCompounding] = useState<CompoundingFrequency>("continuous")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<DecayResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSchedule, setShowSchedule] = useState(false)

  const getPeriodsPerYear = (freq: CompoundingFrequency): number => {
    switch (freq) {
      case "yearly":
        return 1
      case "semi-annually":
        return 2
      case "quarterly":
        return 4
      case "monthly":
        return 12
      case "daily":
        return 365
      default:
        return 1
    }
  }

  const calculateDecay = () => {
    setError("")
    setResult(null)

    const P0 = Number.parseFloat(initialValue)
    const r = Number.parseFloat(decayRate) / 100
    const t = Number.parseFloat(timePeriod)

    if (isNaN(P0) || P0 <= 0) {
      setError("Please enter a valid initial value greater than 0")
      return
    }

    if (isNaN(r) || r < 0) {
      setError("Please enter a valid decay rate (0 or greater)")
      return
    }

    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid time period greater than 0")
      return
    }

    let finalValue: number
    const schedule: { period: number; value: number; decrease: number }[] = []

    if (compounding === "continuous") {
      // Continuous decay: P = P₀ × e^(−r × t)
      finalValue = P0 * Math.exp(-r * t)

      // Generate schedule
      for (let i = 0; i <= Math.min(t, 50); i++) {
        const value = P0 * Math.exp(-r * i)
        const prevValue = i === 0 ? P0 : P0 * Math.exp(-r * (i - 1))
        schedule.push({
          period: i,
          value: value,
          decrease: prevValue - value,
        })
      }
    } else {
      // Discrete decay: P = P₀ × (1 − r/n)^(n × t)
      const n = getPeriodsPerYear(compounding)
      finalValue = P0 * Math.pow(1 - r / n, n * t)

      // Generate schedule
      for (let i = 0; i <= Math.min(t, 50); i++) {
        const value = P0 * Math.pow(1 - r / n, n * i)
        const prevValue = i === 0 ? P0 : P0 * Math.pow(1 - r / n, n * (i - 1))
        schedule.push({
          period: i,
          value: value,
          decrease: prevValue - value,
        })
      }
    }

    const decayFactor = finalValue / P0
    const absoluteDecrease = P0 - finalValue
    const percentageDecrease = (absoluteDecrease / P0) * 100

    setResult({
      finalValue,
      decayFactor,
      absoluteDecrease,
      percentageDecrease,
      schedule,
    })
  }

  const handleReset = () => {
    setInitialValue("")
    setDecayRate("")
    setTimePeriod("")
    setCompounding("continuous")
    setShowSteps(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowSchedule(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Exponential Decay Result:
Initial Value: ${Number.parseFloat(initialValue).toLocaleString()}
Decay Rate: ${decayRate}%
Time Period: ${timePeriod} years
Final Value: ${result.finalValue.toLocaleString(undefined, { maximumFractionDigits: 4 })}
Total Decrease: ${result.absoluteDecrease.toLocaleString(undefined, { maximumFractionDigits: 4 })} (${result.percentageDecrease.toFixed(2)}%)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Exponential Decay Calculation",
          text: `Initial: ${Number.parseFloat(initialValue).toLocaleString()}, Rate: ${decayRate}%, Time: ${timePeriod} years → Final: ${result.finalValue.toLocaleString(undefined, { maximumFractionDigits: 4 })}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const formatNumber = (num: number, decimals = 4) => {
    if (Math.abs(num) < 0.0001 && num !== 0) {
      return num.toExponential(decimals)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: decimals })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <TrendingDown className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Exponential Decay Calculator</CardTitle>
                    <CardDescription>Calculate decay over time</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Value */}
                <div className="space-y-2">
                  <Label htmlFor="initialValue">Initial Value (P₀)</Label>
                  <Input
                    id="initialValue"
                    type="number"
                    placeholder="Enter initial value"
                    value={initialValue}
                    onChange={(e) => setInitialValue(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Decay Rate */}
                <div className="space-y-2">
                  <Label htmlFor="decayRate">Decay Rate (%)</Label>
                  <Input
                    id="decayRate"
                    type="number"
                    placeholder="Enter decay rate percentage"
                    value={decayRate}
                    onChange={(e) => setDecayRate(e.target.value)}
                    min="0"
                    max="100"
                    step="0.01"
                  />
                </div>

                {/* Time Period */}
                <div className="space-y-2">
                  <Label htmlFor="timePeriod">Time Period (years)</Label>
                  <Input
                    id="timePeriod"
                    type="number"
                    placeholder="Enter time in years"
                    value={timePeriod}
                    onChange={(e) => setTimePeriod(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Compounding Frequency */}
                <div className="space-y-2">
                  <Label>Compounding Frequency</Label>
                  <Select value={compounding} onValueChange={(v) => setCompounding(v as CompoundingFrequency)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="continuous">Continuous</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                      <SelectItem value="semi-annually">Semi-Annually</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show Step-by-Step</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDecay} className="w-full" size="lg">
                  Calculate Decay
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Final Value</p>
                      <p className="text-4xl font-bold text-blue-600 mb-1">{formatNumber(result.finalValue)}</p>
                      <p className="text-sm text-muted-foreground">Decay Factor: {formatNumber(result.decayFactor)}</p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Absolute Decrease</p>
                        <p className="font-semibold text-red-600">{formatNumber(result.absoluteDecrease)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Percentage Decrease</p>
                        <p className="font-semibold text-red-600">{result.percentageDecrease.toFixed(2)}%</p>
                      </div>
                    </div>

                    {/* Visual Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Remaining</span>
                        <span>Lost</span>
                      </div>
                      <div className="h-3 bg-red-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-500 rounded-full transition-all duration-500"
                          style={{ width: `${(result.decayFactor * 100).toFixed(1)}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span className="text-blue-600 font-medium">{(result.decayFactor * 100).toFixed(1)}%</span>
                        <span className="text-red-600 font-medium">{result.percentageDecrease.toFixed(1)}%</span>
                      </div>
                    </div>

                    {/* Step-by-Step Breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg">
                        <p className="font-medium text-sm mb-2">Calculation Steps:</p>
                        <div className="text-xs space-y-1 text-muted-foreground font-mono">
                          <p>P₀ = {Number.parseFloat(initialValue).toLocaleString()}</p>
                          <p>
                            r = {decayRate}% = {(Number.parseFloat(decayRate) / 100).toFixed(4)}
                          </p>
                          <p>t = {timePeriod} years</p>
                          {compounding === "continuous" ? (
                            <>
                              <p className="pt-2 text-foreground font-semibold">Continuous Decay:</p>
                              <p>P = P₀ × e^(-r × t)</p>
                              <p>
                                P = {Number.parseFloat(initialValue).toLocaleString()} × e^(-
                                {(Number.parseFloat(decayRate) / 100).toFixed(4)} × {timePeriod})
                              </p>
                              <p>
                                P = {Number.parseFloat(initialValue).toLocaleString()} × e^(
                                {((-Number.parseFloat(decayRate) / 100) * Number.parseFloat(timePeriod)).toFixed(4)})
                              </p>
                              <p>
                                P = {Number.parseFloat(initialValue).toLocaleString()} ×{" "}
                                {Math.exp(
                                  (-Number.parseFloat(decayRate) / 100) * Number.parseFloat(timePeriod),
                                ).toFixed(6)}
                              </p>
                              <p className="text-blue-600 font-semibold">P = {formatNumber(result.finalValue)}</p>
                            </>
                          ) : (
                            <>
                              <p className="pt-2 text-foreground font-semibold">Discrete Decay ({compounding}):</p>
                              <p>n = {getPeriodsPerYear(compounding)} periods/year</p>
                              <p>P = P₀ × (1 - r/n)^(n × t)</p>
                              <p>
                                P = {Number.parseFloat(initialValue).toLocaleString()} × (1 -{" "}
                                {(Number.parseFloat(decayRate) / 100).toFixed(4)}/{getPeriodsPerYear(compounding)})^(
                                {getPeriodsPerYear(compounding)} × {timePeriod})
                              </p>
                              <p className="text-blue-600 font-semibold">P = {formatNumber(result.finalValue)}</p>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Decay Schedule */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSchedule(!showSchedule)}
                        className="flex items-center justify-between w-full p-2 bg-white rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <span className="font-medium text-sm">Decay Schedule</span>
                        {showSchedule ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                      {showSchedule && (
                        <div className="mt-2 max-h-60 overflow-y-auto">
                          <table className="w-full text-xs">
                            <thead className="bg-gray-100 sticky top-0">
                              <tr>
                                <th className="p-2 text-left">Year</th>
                                <th className="p-2 text-right">Value</th>
                                <th className="p-2 text-right">Decrease</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.schedule.map((row, idx) => (
                                <tr key={idx} className="border-b border-gray-100">
                                  <td className="p-2">{row.period}</td>
                                  <td className="p-2 text-right font-mono">{formatNumber(row.value, 2)}</td>
                                  <td className="p-2 text-right font-mono text-red-600">
                                    {row.period === 0 ? "-" : `-${formatNumber(row.decrease, 2)}`}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Decay Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-semibold text-blue-800 mb-1">Continuous Decay</p>
                    <p className="font-mono text-sm text-blue-700">P = P₀ × e^(-r × t)</p>
                    <p className="text-xs text-blue-600 mt-1">Used for radioactive decay, natural processes</p>
                  </div>
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="font-semibold text-green-800 mb-1">Discrete Decay</p>
                    <p className="font-mono text-sm text-green-700">P = P₀ × (1 - r/n)^(n × t)</p>
                    <p className="text-xs text-green-600 mt-1">Used for depreciation, periodic decay</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>
                      <strong>P</strong> = Final value after decay
                    </p>
                    <p>
                      <strong>P₀</strong> = Initial value
                    </p>
                    <p>
                      <strong>r</strong> = Decay rate (as decimal)
                    </p>
                    <p>
                      <strong>t</strong> = Time period
                    </p>
                    <p>
                      <strong>n</strong> = Compounding periods per year
                    </p>
                    <p>
                      <strong>e</strong> = Euler's number (~2.71828)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-blue-500 mt-1.5" />
                      <div>
                        <p className="font-medium">Radioactive Decay</p>
                        <p className="text-muted-foreground text-xs">Half-life of isotopes, nuclear physics</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-green-500 mt-1.5" />
                      <div>
                        <p className="font-medium">Asset Depreciation</p>
                        <p className="text-muted-foreground text-xs">Vehicle, equipment, property value loss</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-yellow-500 mt-1.5" />
                      <div>
                        <p className="font-medium">Population Decline</p>
                        <p className="text-muted-foreground text-xs">Species extinction, disease decay</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-purple-500 mt-1.5" />
                      <div>
                        <p className="font-medium">Drug Metabolism</p>
                        <p className="text-muted-foreground text-xs">Medicine half-life in the body</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Exponential Decay?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Exponential decay is a mathematical concept that describes how quantities decrease at a rate
                  proportional to their current value. Unlike linear decay where values decrease by a fixed amount,
                  exponential decay means the rate of decrease slows down over time as the quantity gets smaller. This
                  pattern is observed in many natural and economic phenomena.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key characteristic of exponential decay is the concept of "half-life" - the time it takes for a
                  quantity to reduce to half its original value. This half-life remains constant regardless of the
                  starting amount, making exponential decay predictable and widely applicable in fields ranging from
                  nuclear physics to finance and pharmacology.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Enter your initial value (the starting amount), decay rate (as a percentage), and time period in
                  years. Choose between continuous decay (for natural processes like radioactive decay) or discrete
                  compounding frequencies (for financial depreciation). The calculator will show the final value, total
                  decrease, and a year-by-year breakdown of the decay process.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Disclaimer:</strong> Exponential decay calculations are based on standard mathematical
                  formulas. Results may vary due to rounding and compounding assumptions. For scientific applications,
                  consult with domain experts and use specialized software for precise calculations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
