"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Heart, Info, AlertTriangle, Activity } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "mgdl" | "mmoll"

interface CholesterolResult {
  totalHdlRatio: number
  ldlHdlRatio: number | null
  nonHdlCholesterol: number
  riskCategory: string
  riskColor: string
  riskBgColor: string
}

export function CholesterolRatioCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("mgdl")
  const [totalCholesterol, setTotalCholesterol] = useState("")
  const [hdlCholesterol, setHdlCholesterol] = useState("")
  const [ldlCholesterol, setLdlCholesterol] = useState("")
  const [triglycerides, setTriglycerides] = useState("")
  const [result, setResult] = useState<CholesterolResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateRatios = () => {
    setError("")
    setResult(null)

    const totalNum = Number.parseFloat(totalCholesterol)
    const hdlNum = Number.parseFloat(hdlCholesterol)
    const ldlNum = ldlCholesterol ? Number.parseFloat(ldlCholesterol) : null
    const trigNum = triglycerides ? Number.parseFloat(triglycerides) : null

    if (isNaN(totalNum) || totalNum <= 0) {
      setError("Please enter a valid Total Cholesterol value greater than 0")
      return
    }

    if (isNaN(hdlNum) || hdlNum <= 0) {
      setError("Please enter a valid HDL Cholesterol value greater than 0")
      return
    }

    if (hdlNum >= totalNum) {
      setError("HDL Cholesterol cannot be greater than or equal to Total Cholesterol")
      return
    }

    if (ldlNum !== null && (isNaN(ldlNum) || ldlNum <= 0)) {
      setError("Please enter a valid LDL Cholesterol value greater than 0")
      return
    }

    if (trigNum !== null && (isNaN(trigNum) || trigNum <= 0)) {
      setError("Please enter a valid Triglycerides value greater than 0")
      return
    }

    // Convert to mg/dL if in mmol/L for calculations
    let totalMgdl = totalNum
    let hdlMgdl = hdlNum
    let ldlMgdl = ldlNum

    if (unitSystem === "mmoll") {
      totalMgdl = totalNum * 38.67
      hdlMgdl = hdlNum * 38.67
      if (ldlMgdl !== null) {
        ldlMgdl = ldlMgdl * 38.67
      }
    }

    // Calculate ratios
    const totalHdlRatio = Math.round((totalMgdl / hdlMgdl) * 10) / 10
    const ldlHdlRatio = ldlMgdl !== null ? Math.round((ldlMgdl / hdlMgdl) * 10) / 10 : null
    const nonHdlCholesterol = Math.round(totalMgdl - hdlMgdl)

    // Determine risk category based on Total/HDL ratio
    let riskCategory: string
    let riskColor: string
    let riskBgColor: string

    if (totalHdlRatio < 3.5) {
      riskCategory = "Low Risk"
      riskColor = "text-green-600"
      riskBgColor = "bg-green-50 border-green-200"
    } else if (totalHdlRatio <= 4.5) {
      riskCategory = "Moderate Risk"
      riskColor = "text-yellow-600"
      riskBgColor = "bg-yellow-50 border-yellow-200"
    } else {
      riskCategory = "High Risk"
      riskColor = "text-red-600"
      riskBgColor = "bg-red-50 border-red-200"
    }

    setResult({
      totalHdlRatio,
      ldlHdlRatio,
      nonHdlCholesterol,
      riskCategory,
      riskColor,
      riskBgColor,
    })
  }

  const handleReset = () => {
    setTotalCholesterol("")
    setHdlCholesterol("")
    setLdlCholesterol("")
    setTriglycerides("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Cholesterol Ratios:
Total/HDL Ratio: ${result.totalHdlRatio}
${result.ldlHdlRatio ? `LDL/HDL Ratio: ${result.ldlHdlRatio}` : ""}
Non-HDL Cholesterol: ${result.nonHdlCholesterol} mg/dL
Risk Category: ${result.riskCategory}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Cholesterol Ratio Results",
          text: `I calculated my cholesterol ratios using CalcHub! Total/HDL Ratio: ${result.totalHdlRatio} (${result.riskCategory})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "mgdl" ? "mmoll" : "mgdl"))
    setTotalCholesterol("")
    setHdlCholesterol("")
    setLdlCholesterol("")
    setTriglycerides("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Heart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Cholesterol Ratio Calculator</CardTitle>
                    <CardDescription>Assess your cardiovascular risk</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "mmoll" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "mgdl" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      mg/dL
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "mmoll" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      mmol/L
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Total Cholesterol Input */}
                <div className="space-y-2">
                  <Label htmlFor="total">Total Cholesterol ({unitSystem === "mgdl" ? "mg/dL" : "mmol/L"}) *</Label>
                  <Input
                    id="total"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "mgdl" ? "200" : "5.2"}`}
                    value={totalCholesterol}
                    onChange={(e) => setTotalCholesterol(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* HDL Cholesterol Input */}
                <div className="space-y-2">
                  <Label htmlFor="hdl">HDL Cholesterol ({unitSystem === "mgdl" ? "mg/dL" : "mmol/L"}) *</Label>
                  <Input
                    id="hdl"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "mgdl" ? "50" : "1.3"}`}
                    value={hdlCholesterol}
                    onChange={(e) => setHdlCholesterol(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* LDL Cholesterol Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="ldl">
                    LDL Cholesterol ({unitSystem === "mgdl" ? "mg/dL" : "mmol/L"}){" "}
                    <span className="text-muted-foreground">(optional)</span>
                  </Label>
                  <Input
                    id="ldl"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "mgdl" ? "130" : "3.4"}`}
                    value={ldlCholesterol}
                    onChange={(e) => setLdlCholesterol(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Triglycerides Input (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="trig">
                    Triglycerides ({unitSystem === "mgdl" ? "mg/dL" : "mmol/L"}){" "}
                    <span className="text-muted-foreground">(optional)</span>
                  </Label>
                  <Input
                    id="trig"
                    type="number"
                    placeholder={`e.g., ${unitSystem === "mgdl" ? "150" : "1.7"}`}
                    value={triglycerides}
                    onChange={(e) => setTriglycerides(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRatios} className="w-full" size="lg">
                  Calculate Ratios
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.riskBgColor} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total/HDL Ratio</p>
                      <p className={`text-5xl font-bold ${result.riskColor} mb-2`}>{result.totalHdlRatio}</p>
                      <p className={`text-lg font-semibold ${result.riskColor}`}>{result.riskCategory}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      {result.ldlHdlRatio && (
                        <div className="bg-white/60 rounded-lg p-3 text-center">
                          <p className="text-xs text-muted-foreground">LDL/HDL Ratio</p>
                          <p className="text-xl font-bold text-foreground">{result.ldlHdlRatio}</p>
                        </div>
                      )}
                      <div
                        className={`bg-white/60 rounded-lg p-3 text-center ${!result.ldlHdlRatio ? "col-span-2" : ""}`}
                      >
                        <p className="text-xs text-muted-foreground">Non-HDL Cholesterol</p>
                        <p className="text-xl font-bold text-foreground">{result.nonHdlCholesterol} mg/dL</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Risk Categories (Total/HDL Ratio)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low Risk</span>
                      <span className="text-sm text-green-600">{"< 3.5"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Risk</span>
                      <span className="text-sm text-yellow-600">3.5 – 4.5</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">High Risk</span>
                      <span className="text-sm text-red-600">{"> 4.5"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Optimal Cholesterol Levels</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Total Cholesterol</span>
                      <span className="font-medium text-foreground">{"< 200 mg/dL"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>HDL (Good)</span>
                      <span className="font-medium text-foreground">{"≥ 60 mg/dL"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>LDL (Bad)</span>
                      <span className="font-medium text-foreground">{"< 100 mg/dL"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Triglycerides</span>
                      <span className="font-medium text-foreground">{"< 150 mg/dL"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Medical Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Consult a healthcare professional for accurate
                        cardiovascular risk assessment and personalized medical advice.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            {/* What is Cholesterol Ratio */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Cholesterol Ratio?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A cholesterol ratio is a calculation that compares different types of cholesterol in your blood to
                  assess your risk of cardiovascular disease. The most commonly used ratio is the Total Cholesterol to
                  HDL ratio, which divides your total cholesterol by your HDL (high-density lipoprotein) cholesterol
                  level. This ratio provides valuable insight into your heart health because it considers both the "bad"
                  cholesterol that can build up in your arteries and the "good" cholesterol that helps remove it.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  While individual cholesterol numbers are important, the ratio between them can be an even better
                  predictor of heart disease risk. A person with moderately elevated total cholesterol but very high HDL
                  levels may actually have a lower cardiovascular risk than someone with lower total cholesterol but
                  poor HDL levels. This is why healthcare providers often look at cholesterol ratios alongside
                  individual values when assessing overall cardiovascular health.
                </p>
              </CardContent>
            </Card>

            {/* Understanding Different Ratios */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Different Cholesterol Ratios</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  There are several cholesterol ratios that healthcare providers may use to evaluate cardiovascular
                  risk. The Total Cholesterol/HDL ratio, also known as Castelli Risk Index I, is the most widely used. A
                  ratio below 3.5 is considered optimal, indicating that you have a healthy balance of cholesterol
                  types. Ratios between 3.5 and 4.5 suggest moderate risk, while ratios above 4.5 indicate higher
                  cardiovascular risk and may warrant lifestyle changes or medical intervention.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The LDL/HDL ratio, sometimes called Castelli Risk Index II, specifically compares your "bad" LDL
                  cholesterol to your "good" HDL cholesterol. An ideal LDL/HDL ratio is below 2.0 for men and below 1.5
                  for women. Additionally, Non-HDL cholesterol (calculated by subtracting HDL from total cholesterol)
                  has emerged as another important metric, as it includes all the potentially harmful cholesterol-
                  carrying particles in your blood, including LDL and VLDL.
                </p>
              </CardContent>
            </Card>

            {/* Why Ratios Matter */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Why Cholesterol Ratios Matter for Heart Health</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Cholesterol ratios matter because they provide a more complete picture of your cardiovascular risk
                  than looking at any single cholesterol value alone. HDL cholesterol acts like a garbage truck in your
                  bloodstream, picking up excess cholesterol from your arteries and transporting it back to your liver
                  for disposal. The ratio reflects the balance between cholesterol that may accumulate in your arteries
                  versus cholesterol that is being actively removed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Research has consistently shown that cholesterol ratios are strong predictors of heart attack and
                  stroke risk. The Framingham Heart Study, one of the longest-running cardiovascular studies, found that
                  the Total/HDL ratio was a better predictor of heart disease than total cholesterol alone. For every
                  one-point increase in the Total/HDL ratio, the risk of heart attack increases by approximately 53% in
                  men and 47% in women, highlighting the importance of maintaining optimal ratios.
                </p>
              </CardContent>
            </Card>

            {/* Improving Your Ratios */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Improving Your Cholesterol Ratios</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Improving your cholesterol ratios involves both lowering harmful LDL cholesterol and raising
                  protective HDL cholesterol. Regular aerobic exercise is one of the most effective ways to boost HDL
                  levels—aim for at least 150 minutes of moderate-intensity activity per week. Exercise can raise HDL by
                  5-10% within two months of starting a regular program. Activities like brisk walking, cycling,
                  swimming, or jogging all contribute to better cholesterol profiles.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Dietary changes also play a crucial role in optimizing cholesterol ratios. Replace saturated and trans
                  fats with heart-healthy unsaturated fats found in olive oil, nuts, avocados, and fatty fish. Increase
                  your fiber intake through whole grains, fruits, vegetables, and legumes—soluble fiber specifically
                  helps reduce LDL cholesterol. Limiting processed foods, added sugars, and refined carbohydrates can
                  also improve your overall lipid profile and reduce triglycerides.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Lifestyle factors beyond diet and exercise also impact cholesterol ratios. Maintaining a healthy
                  weight, quitting smoking, and limiting alcohol consumption all contribute to better cardiovascular
                  health. Smoking specifically lowers HDL cholesterol and damages blood vessel walls, making it easier
                  for cholesterol to accumulate. If lifestyle changes alone are insufficient, your healthcare provider
                  may recommend medications such as statins to help achieve optimal cholesterol levels and ratios.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
