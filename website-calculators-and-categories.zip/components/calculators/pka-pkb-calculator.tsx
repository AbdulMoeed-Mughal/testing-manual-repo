"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  ArrowRightLeft,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "ka-to-pka" | "pka-to-ka" | "kb-to-pkb" | "pkb-to-kb" | "pka-pkb-convert"

interface Result {
  primaryValue: number
  primaryLabel: string
  primaryUnit: string
  secondaryValue?: number
  secondaryLabel?: string
  secondaryUnit?: string
  conjugateValue?: number
  conjugateLabel?: string
  conjugateUnit?: string
  classification: string
  classificationColor: string
  steps: string[]
}

export function PKaPKbCalculator() {
  const [mode, setMode] = useState<CalculationMode>("ka-to-pka")
  const [inputValue, setInputValue] = useState("")
  const [exponent, setExponent] = useState("-5")
  const [result, setResult] = useState<Result | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const KW = 1e-14 // Water dissociation constant at 25°C

  const formatScientific = (num: number): string => {
    if (num === 0) return "0"
    if (num >= 0.01 && num < 10000) {
      return num.toPrecision(4)
    }
    const exp = Math.floor(Math.log10(Math.abs(num)))
    const mantissa = num / Math.pow(10, exp)
    return `${mantissa.toFixed(2)} × 10^${exp}`
  }

  const getClassification = (pKa: number): { text: string; color: string } => {
    if (pKa < 0) {
      return { text: "Very Strong Acid", color: "text-red-600" }
    } else if (pKa < 4) {
      return { text: "Strong Acid", color: "text-orange-600" }
    } else if (pKa < 7) {
      return { text: "Weak Acid", color: "text-yellow-600" }
    } else if (pKa < 10) {
      return { text: "Very Weak Acid", color: "text-green-600" }
    } else if (pKa < 14) {
      return { text: "Extremely Weak Acid", color: "text-blue-600" }
    } else {
      return { text: "Negligible Acidity", color: "text-purple-600" }
    }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const inputNum = Number.parseFloat(inputValue)

    if (mode === "ka-to-pka" || mode === "kb-to-pkb") {
      const exp = Number.parseFloat(exponent)
      if (isNaN(inputNum) || inputNum <= 0) {
        setError("Please enter a valid positive value for the equilibrium constant")
        return
      }
      const K = inputNum * Math.pow(10, exp)
      const pK = -Math.log10(K)

      const steps: string[] = []
      const isAcid = mode === "ka-to-pka"
      const label = isAcid ? "pKa" : "pKb"
      const kLabel = isAcid ? "Ka" : "Kb"

      steps.push(`Given: ${kLabel} = ${inputNum} × 10^${exp} = ${formatScientific(K)}`)
      steps.push(`Formula: ${label} = −log₁₀(${kLabel})`)
      steps.push(`${label} = −log₁₀(${formatScientific(K)})`)
      steps.push(`${label} = ${pK.toFixed(4)}`)

      // Calculate conjugate
      const conjugatePK = 14 - pK
      const conjugateK = Math.pow(10, -conjugatePK)
      steps.push(`Conjugate: ${isAcid ? "pKb" : "pKa"} = 14 − ${label} = ${conjugatePK.toFixed(4)}`)

      const classification = isAcid ? getClassification(pK) : getClassification(14 - pK)

      setResult({
        primaryValue: pK,
        primaryLabel: label,
        primaryUnit: "",
        secondaryValue: K,
        secondaryLabel: kLabel,
        secondaryUnit: "",
        conjugateValue: conjugatePK,
        conjugateLabel: isAcid ? "pKb" : "pKa",
        conjugateUnit: "",
        classification: classification.text,
        classificationColor: classification.color,
        steps,
      })
    } else if (mode === "pka-to-ka" || mode === "pkb-to-kb") {
      if (isNaN(inputNum)) {
        setError("Please enter a valid pK value")
        return
      }

      const K = Math.pow(10, -inputNum)
      const steps: string[] = []
      const isAcid = mode === "pka-to-ka"
      const label = isAcid ? "Ka" : "Kb"
      const pLabel = isAcid ? "pKa" : "pKb"

      steps.push(`Given: ${pLabel} = ${inputNum}`)
      steps.push(`Formula: ${label} = 10^(−${pLabel})`)
      steps.push(`${label} = 10^(−${inputNum})`)
      steps.push(`${label} = ${formatScientific(K)}`)

      // Calculate conjugate
      const conjugatePK = 14 - inputNum
      const conjugateK = Math.pow(10, -conjugatePK)
      steps.push(`Conjugate: ${isAcid ? "pKb" : "pKa"} = 14 − ${pLabel} = ${conjugatePK.toFixed(4)}`)
      steps.push(`Conjugate: ${isAcid ? "Kb" : "Ka"} = ${formatScientific(conjugateK)}`)

      const classification = isAcid ? getClassification(inputNum) : getClassification(14 - inputNum)

      setResult({
        primaryValue: K,
        primaryLabel: label,
        primaryUnit: "",
        secondaryValue: inputNum,
        secondaryLabel: pLabel,
        secondaryUnit: "",
        conjugateValue: conjugatePK,
        conjugateLabel: isAcid ? "pKb" : "pKa",
        conjugateUnit: "",
        classification: classification.text,
        classificationColor: classification.color,
        steps,
      })
    } else if (mode === "pka-pkb-convert") {
      if (isNaN(inputNum)) {
        setError("Please enter a valid pKa or pKb value")
        return
      }

      const conjugateValue = 14 - inputNum
      const steps: string[] = []

      steps.push(`Given: pKa = ${inputNum}`)
      steps.push(`Relationship: pKa + pKb = 14 (at 25°C)`)
      steps.push(`pKb = 14 − pKa`)
      steps.push(`pKb = 14 − ${inputNum} = ${conjugateValue.toFixed(4)}`)
      steps.push(`Ka = 10^(−${inputNum}) = ${formatScientific(Math.pow(10, -inputNum))}`)
      steps.push(`Kb = 10^(−${conjugateValue.toFixed(4)}) = ${formatScientific(Math.pow(10, -conjugateValue))}`)

      const classification = getClassification(inputNum)

      setResult({
        primaryValue: conjugateValue,
        primaryLabel: "pKb",
        primaryUnit: "",
        secondaryValue: inputNum,
        secondaryLabel: "pKa",
        secondaryUnit: "",
        conjugateValue: Math.pow(10, -conjugateValue),
        conjugateLabel: "Kb",
        conjugateUnit: "",
        classification: classification.text,
        classificationColor: classification.color,
        steps,
      })
    }
  }

  const handleReset = () => {
    setInputValue("")
    setExponent("-5")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `${result.primaryLabel}: ${result.primaryLabel === "Ka" || result.primaryLabel === "Kb" ? formatScientific(result.primaryValue) : result.primaryValue.toFixed(4)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "pKa/pKb Calculator Result",
          text: `${result.primaryLabel}: ${result.primaryLabel === "Ka" || result.primaryLabel === "Kb" ? formatScientific(result.primaryValue) : result.primaryValue.toFixed(4)} - Calculated using CalcHub`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getModeLabel = (m: CalculationMode): string => {
    switch (m) {
      case "ka-to-pka":
        return "Ka → pKa"
      case "pka-to-ka":
        return "pKa → Ka"
      case "kb-to-pkb":
        return "Kb → pKb"
      case "pkb-to-kb":
        return "pKb → Kb"
      case "pka-pkb-convert":
        return "pKa ↔ pKb"
    }
  }

  const getInputLabel = (): string => {
    switch (mode) {
      case "ka-to-pka":
        return "Ka (Acid Dissociation Constant)"
      case "pka-to-ka":
        return "pKa"
      case "kb-to-pkb":
        return "Kb (Base Dissociation Constant)"
      case "pkb-to-kb":
        return "pKb"
      case "pka-pkb-convert":
        return "pKa (enter to find pKb)"
    }
  }

  const needsExponent = mode === "ka-to-pka" || mode === "kb-to-pkb"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">pKa/pKb Calculator</CardTitle>
                    <CardDescription>Calculate acid-base dissociation constants</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Mode */}
                <div className="space-y-2">
                  <Label>Calculation Mode</Label>
                  <Select
                    value={mode}
                    onValueChange={(v) => {
                      setMode(v as CalculationMode)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ka-to-pka">Ka → pKa (Acid constant to pKa)</SelectItem>
                      <SelectItem value="pka-to-ka">pKa → Ka (pKa to acid constant)</SelectItem>
                      <SelectItem value="kb-to-pkb">Kb → pKb (Base constant to pKb)</SelectItem>
                      <SelectItem value="pkb-to-kb">pKb → Kb (pKb to base constant)</SelectItem>
                      <SelectItem value="pka-pkb-convert">pKa ↔ pKb (Conjugate conversion)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Input Value */}
                <div className="space-y-2">
                  <Label htmlFor="inputValue">{getInputLabel()}</Label>
                  {needsExponent ? (
                    <div className="flex gap-2 items-center">
                      <Input
                        id="inputValue"
                        type="number"
                        placeholder="e.g., 1.8"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        step="0.1"
                        className="flex-1"
                      />
                      <span className="text-sm text-muted-foreground">×10^</span>
                      <Input
                        type="number"
                        placeholder="-5"
                        value={exponent}
                        onChange={(e) => setExponent(e.target.value)}
                        className="w-20"
                      />
                    </div>
                  ) : (
                    <Input
                      id="inputValue"
                      type="number"
                      placeholder={mode === "pka-pkb-convert" ? "e.g., 4.76" : "e.g., 4.76"}
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      step="0.01"
                    />
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{result.primaryLabel}</p>
                      <p className="text-4xl font-bold text-purple-600 mb-2">
                        {result.primaryLabel === "Ka" || result.primaryLabel === "Kb"
                          ? formatScientific(result.primaryValue)
                          : result.primaryValue.toFixed(4)}
                      </p>
                      <p className={`text-sm font-medium ${result.classificationColor}`}>{result.classification}</p>
                    </div>

                    {/* Additional Results */}
                    <div className="mt-4 grid grid-cols-2 gap-3">
                      {result.secondaryValue !== undefined && (
                        <div className="p-3 bg-white rounded-lg border">
                          <p className="text-xs text-muted-foreground">{result.secondaryLabel}</p>
                          <p className="font-semibold text-foreground">
                            {result.secondaryLabel === "Ka" || result.secondaryLabel === "Kb"
                              ? formatScientific(result.secondaryValue)
                              : result.secondaryValue.toFixed(4)}
                          </p>
                        </div>
                      )}
                      {result.conjugateValue !== undefined && (
                        <div className="p-3 bg-white rounded-lg border">
                          <p className="text-xs text-muted-foreground">Conjugate {result.conjugateLabel}</p>
                          <p className="font-semibold text-foreground">
                            {result.conjugateLabel === "Ka" || result.conjugateLabel === "Kb"
                              ? formatScientific(result.conjugateValue)
                              : result.conjugateValue.toFixed(4)}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Step-by-step solution toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-center gap-1 w-full mt-4 text-sm text-purple-600 hover:text-purple-700"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg border text-sm space-y-1">
                        {result.steps.map((step, idx) => (
                          <p key={idx} className="text-muted-foreground font-mono text-xs">
                            {step}
                          </p>
                        ))}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">pKa from Ka</p>
                    <p className="font-mono text-sm font-semibold">pKa = −log₁₀(Ka)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Ka from pKa</p>
                    <p className="font-mono text-sm font-semibold">Ka = 10^(−pKa)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Conjugate Relationship</p>
                    <p className="font-mono text-sm font-semibold">pKa + pKb = 14</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Water Constant (25°C)</p>
                    <p className="font-mono text-sm font-semibold">Kw = Ka × Kb = 10⁻¹⁴</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common pKa Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-red-50 rounded border border-red-100">
                      <span>HCl (Hydrochloric acid)</span>
                      <span className="font-mono font-semibold">−7</span>
                    </div>
                    <div className="flex justify-between p-2 bg-orange-50 rounded border border-orange-100">
                      <span>CH₃COOH (Acetic acid)</span>
                      <span className="font-mono font-semibold">4.76</span>
                    </div>
                    <div className="flex justify-between p-2 bg-yellow-50 rounded border border-yellow-100">
                      <span>H₂CO₃ (Carbonic acid)</span>
                      <span className="font-mono font-semibold">6.35</span>
                    </div>
                    <div className="flex justify-between p-2 bg-green-50 rounded border border-green-100">
                      <span>NH₄⁺ (Ammonium ion)</span>
                      <span className="font-mono font-semibold">9.25</span>
                    </div>
                    <div className="flex justify-between p-2 bg-blue-50 rounded border border-blue-100">
                      <span>H₂O (Water)</span>
                      <span className="font-mono font-semibold">14</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-yellow-200 bg-yellow-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-medium mb-1">Standard Conditions</p>
                      <p>
                        Results assume standard conditions (25°C, 1 atm) and ideal behavior. Actual values may vary with
                        temperature and ionic strength.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are pKa and pKb?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  pKa and pKb are logarithmic measures of acid and base strength, respectively. They provide a more
                  convenient scale for comparing the relative strengths of acids and bases than using the raw
                  dissociation constants (Ka and Kb), which can span many orders of magnitude. A lower pKa indicates a
                  stronger acid, while a lower pKb indicates a stronger base.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The "p" in pKa stands for "negative logarithm" (from the German "potenz," meaning power). This
                  notation was introduced by Søren Sørensen in 1909 when he developed the pH scale. Just as pH provides
                  a convenient scale for hydrogen ion concentration, pKa provides a practical scale for acid
                  dissociation constants.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Conjugate Relationship</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Every acid has a conjugate base, and every base has a conjugate acid. When an acid donates a proton
                  (H⁺), it becomes its conjugate base. When a base accepts a proton, it becomes its conjugate acid. The
                  relationship between a conjugate acid-base pair is expressed mathematically as:{" "}
                  <strong>pKa + pKb = 14</strong> (at 25°C).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This relationship arises from the water dissociation equilibrium. At 25°C, Kw = Ka × Kb = 10⁻¹⁴.
                  Taking the negative logarithm of both sides gives us pKa + pKb = pKw = 14. This means a strong acid
                  (low pKa) will have a weak conjugate base (high pKb), and vice versa.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Understanding pKa values is essential in many scientific fields. In pharmaceutical chemistry, pKa
                  determines drug absorption, distribution, and bioavailability. Most drugs are weak acids or bases, and
                  their ionization state affects how they cross biological membranes. Drugs are typically designed with
                  specific pKa values to optimize their pharmacokinetic properties.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In biochemistry, pKa values of amino acid side chains are crucial for understanding enzyme catalysis
                  and protein structure. The pKa of a functional group determines its charge state at physiological pH,
                  which affects protein folding, enzyme activity, and molecular interactions. Buffer systems used in
                  laboratories are also designed based on pKa values to maintain stable pH conditions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
