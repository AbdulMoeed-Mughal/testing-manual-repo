"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, AlertTriangle, Gauge } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type StressUnit = "pa" | "kpa" | "mpa" | "gpa" | "psi" | "ksi"
type StrainInputMode = "decimal" | "percentage"

interface YoungsModulusResult {
  modulusPa: number
  modulusDisplay: number
  displayUnit: string
  category: string
  color: string
  bgColor: string
}

const stressUnitLabels: Record<StressUnit, string> = {
  pa: "Pa",
  kpa: "kPa",
  mpa: "MPa",
  gpa: "GPa",
  psi: "psi",
  ksi: "ksi",
}

const stressToPA: Record<StressUnit, number> = {
  pa: 1,
  kpa: 1e3,
  mpa: 1e6,
  gpa: 1e9,
  psi: 6894.76,
  ksi: 6894760,
}

const commonMaterials = [
  { name: "Rubber", modulus: "0.01 - 0.1 GPa" },
  { name: "Polyethylene", modulus: "0.2 - 1.0 GPa" },
  { name: "Wood (along grain)", modulus: "9 - 16 GPa" },
  { name: "Concrete", modulus: "20 - 40 GPa" },
  { name: "Aluminum", modulus: "69 GPa" },
  { name: "Glass", modulus: "50 - 90 GPa" },
  { name: "Copper", modulus: "110 - 130 GPa" },
  { name: "Steel", modulus: "190 - 215 GPa" },
  { name: "Tungsten", modulus: "400 - 410 GPa" },
  { name: "Diamond", modulus: "1050 - 1210 GPa" },
]

export function YoungsModulusCalculator() {
  const [stress, setStress] = useState("")
  const [stressUnit, setStressUnit] = useState<StressUnit>("mpa")
  const [strain, setStrain] = useState("")
  const [strainMode, setStrainMode] = useState<StrainInputMode>("decimal")
  const [outputUnit, setOutputUnit] = useState<StressUnit>("gpa")
  const [result, setResult] = useState<YoungsModulusResult | null>(null)
  const [showSteps, setShowSteps] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateYoungsModulus = () => {
    setError("")
    setResult(null)

    const stressNum = Number.parseFloat(stress)
    const strainNum = Number.parseFloat(strain)

    if (isNaN(stressNum) || stressNum <= 0) {
      setError("Please enter a valid stress value greater than 0")
      return
    }

    if (isNaN(strainNum) || strainNum <= 0) {
      setError("Please enter a valid strain value greater than 0")
      return
    }

    // Convert strain from percentage to decimal if needed
    const strainDecimal = strainMode === "percentage" ? strainNum / 100 : strainNum

    if (strainDecimal <= 0) {
      setError("Strain must be greater than 0")
      return
    }

    // Convert stress to Pa
    const stressPa = stressNum * stressToPA[stressUnit]

    // Calculate Young's modulus: E = σ / ε
    const modulusPa = stressPa / strainDecimal

    // Convert to output unit
    const modulusDisplay = modulusPa / stressToPA[outputUnit]

    // Categorize the material stiffness
    const modulusGPa = modulusPa / 1e9
    let category: string
    let color: string
    let bgColor: string

    if (modulusGPa < 1) {
      category = "Very Flexible (Elastomers)"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (modulusGPa < 10) {
      category = "Flexible (Polymers)"
      color = "text-cyan-600"
      bgColor = "bg-cyan-50 border-cyan-200"
    } else if (modulusGPa < 50) {
      category = "Moderate (Wood, Concrete)"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (modulusGPa < 150) {
      category = "Stiff (Non-ferrous Metals)"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (modulusGPa < 300) {
      category = "Very Stiff (Steel, Iron)"
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else {
      category = "Extremely Stiff (Ceramics)"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    }

    setResult({
      modulusPa,
      modulusDisplay,
      displayUnit: stressUnitLabels[outputUnit],
      category,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setStress("")
    setStrain("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Young's Modulus: ${result.modulusDisplay.toExponential(3)} ${result.displayUnit} (${result.category})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Young's Modulus Result",
          text: `Young's Modulus: ${result.modulusDisplay.toExponential(3)} ${result.displayUnit} - Calculated using CalcHub`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (num >= 1e6 || num < 0.001) {
      return num.toExponential(3)
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 4 })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Young's Modulus Calculator</CardTitle>
                    <CardDescription>Calculate elastic modulus from stress and strain</CardDescription>
                  </div>
                </div>

                {/* Strain Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Strain Input</span>
                  <button
                    onClick={() => {
                      setStrainMode((prev) => (prev === "decimal" ? "percentage" : "decimal"))
                      setStrain("")
                      setResult(null)
                    }}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        strainMode === "percentage" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        strainMode === "decimal" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Decimal
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        strainMode === "percentage" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Percentage
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Stress Input */}
                <div className="space-y-2">
                  <Label htmlFor="stress">Stress (σ)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="stress"
                      type="number"
                      placeholder="Enter stress value"
                      value={stress}
                      onChange={(e) => setStress(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={stressUnit} onValueChange={(v) => setStressUnit(v as StressUnit)}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pa">Pa</SelectItem>
                        <SelectItem value="kpa">kPa</SelectItem>
                        <SelectItem value="mpa">MPa</SelectItem>
                        <SelectItem value="gpa">GPa</SelectItem>
                        <SelectItem value="psi">psi</SelectItem>
                        <SelectItem value="ksi">ksi</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Strain Input */}
                <div className="space-y-2">
                  <Label htmlFor="strain">Strain (ε) {strainMode === "percentage" ? "(%)" : "(decimal)"}</Label>
                  <Input
                    id="strain"
                    type="number"
                    placeholder={strainMode === "percentage" ? "e.g., 0.5 for 0.5%" : "e.g., 0.005"}
                    value={strain}
                    onChange={(e) => setStrain(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Output Unit */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <Select value={outputUnit} onValueChange={(v) => setOutputUnit(v as StressUnit)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pa">Pa</SelectItem>
                      <SelectItem value="kpa">kPa</SelectItem>
                      <SelectItem value="mpa">MPa</SelectItem>
                      <SelectItem value="gpa">GPa</SelectItem>
                      <SelectItem value="psi">psi</SelectItem>
                      <SelectItem value="ksi">ksi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateYoungsModulus} className="w-full" size="lg">
                  Calculate Young's Modulus
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Young's Modulus (E)</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>{formatNumber(result.modulusDisplay)}</p>
                      <p className="text-lg text-muted-foreground mb-2">{result.displayUnit}</p>
                      <p className={`text-sm font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Step-by-step toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? "Hide" : "Show"} calculation steps
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white/50 rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Formula:</strong> E = σ / ε
                        </p>
                        <p>
                          <strong>Stress (σ):</strong> {stress} {stressUnitLabels[stressUnit]}
                        </p>
                        <p>
                          <strong>Strain (ε):</strong> {strain}
                          {strainMode === "percentage" ? "%" : ""} ={" "}
                          {strainMode === "percentage" ? (Number(strain) / 100).toFixed(6) : strain}
                        </p>
                        <p>
                          <strong>Calculation:</strong> E = {stress} {stressUnitLabels[stressUnit]} /{" "}
                          {strainMode === "percentage" ? (Number(strain) / 100).toFixed(6) : strain}
                        </p>
                        <p>
                          <strong>Result:</strong> {formatNumber(result.modulusDisplay)} {result.displayUnit}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Material Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {commonMaterials.map((material) => (
                      <div key={material.name} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                        <span className="font-medium text-sm">{material.name}</span>
                        <span className="text-sm text-muted-foreground">{material.modulus}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Young's Modulus Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-lg">E = σ / ε</p>
                  </div>
                  <p>Where:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>
                      <strong>E</strong> = Young's modulus (elastic modulus)
                    </li>
                    <li>
                      <strong>σ</strong> = Stress (force per unit area)
                    </li>
                    <li>
                      <strong>ε</strong> = Strain (dimensionless, ΔL/L₀)
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Young's Modulus?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Young's modulus, also known as the elastic modulus or modulus of elasticity, is a mechanical property
                  that measures the stiffness of a solid material. It defines the relationship between stress (force per
                  unit area) and strain (proportional deformation) in a material in the linear elastic region of
                  uniaxial deformation. Named after British scientist Thomas Young, it is one of the most important
                  properties used in engineering to predict how materials will behave under load.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A higher Young's modulus indicates a stiffer material that requires more force to achieve the same
                  amount of deformation. For example, steel has a Young's modulus of about 200 GPa, while rubber has a
                  value around 0.01-0.1 GPa, explaining why steel is much harder to stretch than rubber. This property
                  is crucial in structural engineering, materials science, and mechanical design.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Young's Modulus</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Young's modulus is essential in numerous engineering applications. In structural engineering, it helps
                  predict how beams, columns, and frames will deflect under load. In mechanical engineering, it's used
                  to design springs, machine components, and pressure vessels. Materials scientists use it to
                  characterize and compare different materials, while biomedical engineers apply it to understand tissue
                  mechanics and design implants.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The modulus also helps engineers select appropriate materials for specific applications. For instance,
                  a bridge requires high-stiffness materials like steel or concrete, while a flexible seal might use
                  low-modulus elastomers. Understanding Young's modulus enables optimal material selection that balances
                  performance, weight, and cost requirements.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Young's modulus calculations are based on ideal elastic behavior within the linear elastic region.
                  Actual material properties may vary due to imperfections, temperature effects, strain rate,
                  anisotropy, and loading conditions. Consult material datasheets and conduct proper testing for precise
                  values in engineering applications. This calculator is for educational purposes only.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
