"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, FlaskConical, Info, AlertTriangle, Zap, Plus, Minus } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface AtomData {
  id: number
  symbol: string
  count: string
  oxidationNumber: string
  isKnown: boolean
}

interface OxidationResult {
  atoms: { symbol: string; oxidationNumber: number; count: number }[]
  totalCharge: number
  unknownAtom: { symbol: string; oxidationNumber: number } | null
}

export function OxidationNumberCalculator() {
  const [atoms, setAtoms] = useState<AtomData[]>([
    { id: 1, symbol: "", count: "1", oxidationNumber: "", isKnown: true }
  ])
  const [compoundCharge, setCompoundCharge] = useState("0")
  const [result, setResult] = useState<OxidationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const commonOxidationNumbers: { [key: string]: number } = {
    "H": 1,
    "O": -2,
    "F": -1,
    "Li": 1, "Na": 1, "K": 1, "Rb": 1, "Cs": 1,
    "Be": 2, "Mg": 2, "Ca": 2, "Sr": 2, "Ba": 2,
    "Al": 3,
    "Cl": -1, "Br": -1, "I": -1
  }

  const addAtom = () => {
    const newId = atoms.length > 0 ? Math.max(...atoms.map(a => a.id)) + 1 : 1
    setAtoms([...atoms, { id: newId, symbol: "", count: "1", oxidationNumber: "", isKnown: true }])
  }

  const removeAtom = (id: number) => {
    if (atoms.length > 1) {
      setAtoms(atoms.filter(a => a.id !== id))
    }
  }

  const updateAtom = (id: number, field: keyof AtomData, value: string | boolean) => {
    setAtoms(atoms.map(a => a.id === id ? { ...a, [field]: value } : a))
  }

  const autoFillOxidationNumber = (id: number, symbol: string) => {
    const upperSymbol = symbol.charAt(0).toUpperCase() + symbol.slice(1).toLowerCase()
    if (commonOxidationNumbers[upperSymbol] !== undefined) {
      setAtoms(atoms.map(a => a.id === id ? { ...a, symbol, oxidationNumber: commonOxidationNumbers[upperSymbol].toString() } : a))
    } else {
      setAtoms(atoms.map(a => a.id === id ? { ...a, symbol } : a))
    }
  }

  const calculateOxidationNumbers = () => {
    setError("")
    setResult(null)

    const charge = Number.parseInt(compoundCharge) || 0
    const results: { symbol: string; oxidationNumber: number; count: number }[] = []
    let knownSum = 0
    let unknownAtom: AtomData | null = null
    let unknownCount = 0

    for (const atom of atoms) {
      if (!atom.symbol.trim()) {
        setError("Please enter an atom symbol for all atoms")
        return
      }

      const count = Number.parseInt(atom.count) || 1
      if (count <= 0) {
        setError(`Please enter a valid count for ${atom.symbol}`)
        return
      }

      if (atom.isKnown && atom.oxidationNumber !== "") {
        const oxNum = Number.parseInt(atom.oxidationNumber)
        if (isNaN(oxNum)) {
          setError(`Please enter a valid oxidation number for ${atom.symbol}`)
          return
        }
        knownSum += oxNum * count
        results.push({ symbol: atom.symbol, oxidationNumber: oxNum, count })
      } else if (!atom.isKnown || atom.oxidationNumber === "") {
        if (unknownAtom !== null) {
          setError("Only one unknown oxidation number can be solved at a time")
          return
        }
        unknownAtom = atom
        unknownCount = count
      }
    }

    if (unknownAtom) {
      // Sum of oxidation numbers = compound charge
      // knownSum + (unknown × unknownCount) = charge
      // unknown = (charge - knownSum) / unknownCount
      const unknownOxNum = (charge - knownSum) / unknownCount
      if (!Number.isInteger(unknownOxNum)) {
        setError(`Calculated oxidation number for ${unknownAtom.symbol} is not an integer (${unknownOxNum.toFixed(2)}). Check your inputs.`)
        return
      }
      results.push({ symbol: unknownAtom.symbol, oxidationNumber: unknownOxNum, count: unknownCount })
      setResult({ atoms: results, totalCharge: charge, unknownAtom: { symbol: unknownAtom.symbol, oxidationNumber: unknownOxNum } })
    } else {
      // Verify total equals charge
      if (knownSum !== charge) {
        setError(`Sum of oxidation numbers (${knownSum}) does not equal compound charge (${charge})`)
        return
      }
      setResult({ atoms: results, totalCharge: charge, unknownAtom: null })
    }
  }

  const handleReset = () => {
    setAtoms([{ id: 1, symbol: "", count: "1", oxidationNumber: "", isKnown: true }])
    setCompoundCharge("0")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = result.atoms.map(a => `${a.symbol}: ${a.oxidationNumber > 0 ? "+" : ""}${a.oxidationNumber}`).join(", ")
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text = result.atoms.map(a => `${a.symbol}: ${a.oxidationNumber > 0 ? "+" : ""}${a.oxidationNumber}`).join(", ")
        await navigator.share({
          title: "Oxidation Number Calculation",
          text: `Oxidation Numbers: ${text}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const getOxidationColor = (oxNum: number) => {
    if (oxNum > 0) return "text-red-600 bg-red-50 border-red-200"
    if (oxNum < 0) return "text-blue-600 bg-blue-50 border-blue-200"
    return "text-green-600 bg-green-50 border-green-200"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Oxidation Number Calculator</CardTitle>
                    <CardDescription>Determine oxidation states of atoms in a compound</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Compound Charge */}
                <div className="space-y-2">
                  <Label htmlFor="charge">Compound/Ion Charge</Label>
                  <Input
                    id="charge"
                    type="number"
                    placeholder="0 for neutral, or ion charge"
                    value={compoundCharge}
                    onChange={(e) => setCompoundCharge(e.target.value)}
                  />
                </div>

                {/* Atoms List */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Atoms in Compound</Label>
                    <Button variant="outline" size="sm" onClick={addAtom}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Atom
                    </Button>
                  </div>

                  {atoms.map((atom, index) => (
                    <div key={atom.id} className="p-4 border rounded-lg space-y-3 bg-muted/30">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Atom {index + 1}</span>
                        {atoms.length > 1 && (
                          <Button variant="ghost" size="sm" onClick={() => removeAtom(atom.id)}>
                            <Minus className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-3 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs">Symbol</Label>
                          <Input
                            placeholder="e.g., Fe"
                            value={atom.symbol}
                            onChange={(e) => autoFillOxidationNumber(atom.id, e.target.value)}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Count</Label>
                          <Input
                            type="number"
                            placeholder="1"
                            value={atom.count}
                            onChange={(e) => updateAtom(atom.id, "count", e.target.value)}
                            min="1"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Ox. Number</Label>
                          <Input
                            type="number"
                            placeholder="?"
                            value={atom.oxidationNumber}
                            onChange={(e) => updateAtom(atom.id, "oxidationNumber", e.target.value)}
                          />
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Leave oxidation number empty to solve for it
                      </p>
                    </div>
                  ))}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateOxidationNumbers} className="w-full" size="lg">
                  Calculate Oxidation Numbers
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 border-purple-200 bg-purple-50 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-3">Oxidation Numbers</p>
                      <div className="flex flex-wrap gap-2 justify-center mb-4">
                        {result.atoms.map((atom, index) => (
                          <div
                            key={index}
                            className={`px-4 py-2 rounded-lg border ${getOxidationColor(atom.oxidationNumber)} ${result.unknownAtom?.symbol === atom.symbol ? "ring-2 ring-purple-500" : ""}`}
                          >
                            <span className="font-bold text-lg">{atom.symbol}</span>
                            {atom.count > 1 && <sub className="text-xs">{atom.count}</sub>}
                            <span className="ml-2 text-sm font-semibold">
                              {atom.oxidationNumber > 0 ? "+" : ""}{atom.oxidationNumber}
                            </span>
                          </div>
                        ))}
                      </div>
                      {result.unknownAtom && (
                        <p className="text-sm text-purple-700 font-medium">
                          Solved: {result.unknownAtom.symbol} has oxidation number {result.unknownAtom.oxidationNumber > 0 ? "+" : ""}{result.unknownAtom.oxidationNumber}
                        </p>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Oxidation Number Rules</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Sum Rule</p>
                    <p>Sum of oxidation numbers = charge of compound/ion</p>
                  </div>
                  <ul className="space-y-2 list-disc list-inside">
                    <li>Free elements have oxidation number <strong>0</strong></li>
                    <li>Hydrogen is usually <strong>+1</strong> (except in metal hydrides: -1)</li>
                    <li>Oxygen is usually <strong>-2</strong> (except in peroxides: -1)</li>
                    <li>Fluorine is always <strong>-1</strong></li>
                    <li>Alkali metals (Group 1) are <strong>+1</strong></li>
                    <li>Alkaline earth metals (Group 2) are <strong>+2</strong></li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Oxidation States</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Fe (Iron)</span>
                      <span className="font-mono">+2, +3</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Cu (Copper)</span>
                      <span className="font-mono">+1, +2</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Mn (Manganese)</span>
                      <span className="font-mono">+2, +4, +7</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>S (Sulfur)</span>
                      <span className="font-mono">-2, +4, +6</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>N (Nitrogen)</span>
                      <span className="font-mono">-3 to +5</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Cr (Chromium)</span>
                      <span className="font-mono">+3, +6</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Oxidation Number */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an Oxidation Number?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An oxidation number (also called oxidation state) is a measure of the degree of oxidation of an atom 
                  in a chemical compound. It represents the hypothetical charge an atom would have if all bonds to atoms 
                  of different elements were completely ionic. Oxidation numbers are essential for understanding redox 
                  reactions, balancing equations, and predicting chemical behavior.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  While formal charges assume equal sharing of electrons, oxidation numbers assign all shared electrons 
                  to the more electronegative atom. This makes oxidation numbers particularly useful for tracking electron 
                  transfer in redox (reduction-oxidation) reactions, where one species loses electrons (oxidation) while 
                  another gains electrons (reduction).
                </p>
              </CardContent>
            </Card>

            {/* Redox Reactions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Oxidation Numbers in Redox Reactions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Redox reactions involve the transfer of electrons between species, which can be tracked by changes in 
                  oxidation numbers. When an atom's oxidation number increases, it has lost electrons and been oxidized. 
                  When an atom's oxidation number decreases, it has gained electrons and been reduced. The mnemonic 
                  "OIL RIG" (Oxidation Is Loss, Reduction Is Gain) helps remember this concept.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, in the reaction 2Mg + O₂ → 2MgO, magnesium's oxidation number changes from 0 to +2 
                  (oxidation), while oxygen changes from 0 to -2 (reduction). Identifying these changes is crucial for 
                  balancing redox equations using the half-reaction method and understanding the chemistry of batteries, 
                  corrosion, combustion, and biological processes like cellular respiration.
                </p>
              </CardContent>
            </Card>

            {/* Determining Oxidation Numbers */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>How to Determine Oxidation Numbers</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Determining oxidation numbers follows a systematic approach using established rules. Start by assigning 
                  known oxidation numbers: free elements are 0, oxygen is usually -2, hydrogen is usually +1, and halogens 
                  in binary compounds are -1. For monatomic ions, the oxidation number equals the ionic charge. The sum of 
                  all oxidation numbers must equal the total charge of the species.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For unknown oxidation numbers, use algebra with the constraint that oxidation numbers must sum to the 
                  compound's charge. For example, in H₂SO₄: two H at +1 gives +2, four O at -2 gives -8, so S must be 
                  +6 to make the total 0. This calculator automates this process, allowing you to enter known values and 
                  solve for unknowns.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Limitations and Special Cases</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Oxidation number rules have exceptions that must be considered. Oxygen is -1 in peroxides (H₂O₂) and 
                  -1/2 in superoxides (KO₂). Hydrogen is -1 in metal hydrides (NaH). In compounds containing oxygen-oxygen 
                  or nitrogen-nitrogen bonds, careful analysis is needed. Transition metals often exhibit multiple 
                  oxidation states depending on the compound.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Oxidation numbers are formal assignments and don't represent actual charges on atoms in covalent 
                  compounds. They're most meaningful for ionic compounds and serve as bookkeeping tools for electron 
                  transfer. For complex molecules with unusual structures or resonance, computational chemistry methods 
                  may provide more accurate descriptions of electron distribution than simple oxidation number assignments.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
