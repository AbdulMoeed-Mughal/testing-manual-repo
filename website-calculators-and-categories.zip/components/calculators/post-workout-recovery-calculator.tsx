"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Timer,
  Info,
  ChevronDown,
  ChevronUp,
  Activity,
  Dumbbell,
  Heart,
  Moon,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type IntensityLevel = "low" | "moderate" | "high" | "very-high"
type ActivityType = "cardio" | "strength" | "hiit" | "mixed"
type FitnessLevel = "beginner" | "intermediate" | "advanced"
type SleepQuality = "poor" | "fair" | "good" | "excellent"

interface RecoveryResult {
  recoveryHours: number
  recoveryDays: number
  category: string
  color: string
  bgColor: string
  recommendations: string[]
}

export function PostWorkoutRecoveryCalculator() {
  const [duration, setDuration] = useState("")
  const [intensity, setIntensity] = useState<IntensityLevel>("moderate")
  const [activityType, setActivityType] = useState<ActivityType>("mixed")
  const [age, setAge] = useState("")
  const [fitnessLevel, setFitnessLevel] = useState<FitnessLevel>("intermediate")
  const [includeHeartRate, setIncludeHeartRate] = useState(false)
  const [heartRate, setHeartRate] = useState("")
  const [includeSleepQuality, setIncludeSleepQuality] = useState(false)
  const [sleepQuality, setSleepQuality] = useState<SleepQuality>("good")
  const [result, setResult] = useState<RecoveryResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const intensityMultipliers: Record<IntensityLevel, number> = {
    low: 0.5,
    moderate: 1.0,
    high: 1.5,
    "very-high": 2.0,
  }

  const activityMultipliers: Record<ActivityType, number> = {
    cardio: 0.8,
    strength: 1.2,
    hiit: 1.4,
    mixed: 1.0,
  }

  const fitnessAdjustments: Record<FitnessLevel, number> = {
    beginner: 1.2,
    intermediate: 1.0,
    advanced: 0.9,
  }

  const sleepAdjustments: Record<SleepQuality, number> = {
    poor: 1.3,
    fair: 1.15,
    good: 1.0,
    excellent: 0.9,
  }

  const calculateRecovery = () => {
    setError("")
    setResult(null)

    const durationNum = Number.parseFloat(duration)
    if (isNaN(durationNum) || durationNum <= 0) {
      setError("Please enter a valid workout duration greater than 0")
      return
    }

    const ageNum = Number.parseFloat(age)
    if (isNaN(ageNum) || ageNum < 10 || ageNum > 100) {
      setError("Please enter a valid age between 10 and 100")
      return
    }

    if (includeHeartRate) {
      const hrNum = Number.parseFloat(heartRate)
      if (isNaN(hrNum) || hrNum < 40 || hrNum > 220) {
        setError("Please enter a valid heart rate between 40 and 220 bpm")
        return
      }
    }

    // Base recovery time calculation
    let baseRecoveryMinutes = durationNum * intensityMultipliers[intensity]

    // Apply activity type multiplier
    baseRecoveryMinutes *= activityMultipliers[activityType]

    // Apply fitness level adjustment
    baseRecoveryMinutes *= fitnessAdjustments[fitnessLevel]

    // Age adjustment (older = more recovery needed)
    if (ageNum > 40) {
      baseRecoveryMinutes *= 1 + (ageNum - 40) * 0.01
    } else if (ageNum < 25) {
      baseRecoveryMinutes *= 0.95
    }

    // Heart rate adjustment (higher post-exercise HR = more recovery needed)
    if (includeHeartRate) {
      const hrNum = Number.parseFloat(heartRate)
      if (hrNum > 150) {
        baseRecoveryMinutes *= 1.2
      } else if (hrNum > 120) {
        baseRecoveryMinutes *= 1.1
      } else if (hrNum < 100) {
        baseRecoveryMinutes *= 0.9
      }
    }

    // Sleep quality adjustment
    if (includeSleepQuality) {
      baseRecoveryMinutes *= sleepAdjustments[sleepQuality]
    }

    // Convert to hours
    const recoveryHours = Math.round((baseRecoveryMinutes / 60) * 10) / 10
    const recoveryDays = Math.round((recoveryHours / 24) * 10) / 10

    // Determine category and recommendations
    let category: string
    let color: string
    let bgColor: string
    let recommendations: string[] = []

    if (recoveryHours < 6) {
      category = "Quick Recovery"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
      recommendations = [
        "Light stretching or yoga can enhance recovery",
        "Stay hydrated with water or electrolyte drinks",
        "A short nap or rest period is beneficial",
        "You can resume light activity tomorrow",
      ]
    } else if (recoveryHours < 24) {
      category = "Moderate Recovery"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
      recommendations = [
        "Focus on quality sleep tonight",
        "Consider foam rolling or massage",
        "Eat protein-rich foods to support muscle repair",
        "Light walking or active recovery is recommended",
      ]
    } else if (recoveryHours < 48) {
      category = "Extended Recovery"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
      recommendations = [
        "Prioritize rest and sleep for the next 24-48 hours",
        "Consume adequate protein (1.6-2.2g/kg body weight)",
        "Consider contrast showers (hot/cold) for recovery",
        "Avoid intense training until fully recovered",
      ]
    } else {
      category = "Full Rest Required"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
      recommendations = [
        "Take complete rest from intense training",
        "Focus on nutrition and hydration",
        "Consider sports massage or physiotherapy",
        "Monitor for signs of overtraining syndrome",
      ]
    }

    setResult({
      recoveryHours,
      recoveryDays,
      category,
      color,
      bgColor,
      recommendations,
    })
  }

  const handleReset = () => {
    setDuration("")
    setIntensity("moderate")
    setActivityType("mixed")
    setAge("")
    setFitnessLevel("intermediate")
    setIncludeHeartRate(false)
    setHeartRate("")
    setIncludeSleepQuality(false)
    setSleepQuality("good")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Post-Workout Recovery Time: ${result.recoveryHours} hours (${result.category})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Recovery Time",
          text: `I calculated my post-workout recovery time using CalcHub! Recovery needed: ${result.recoveryHours} hours (${result.category})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatRecoveryTime = (hours: number): string => {
    if (hours < 1) {
      return `${Math.round(hours * 60)} minutes`
    } else if (hours < 24) {
      return `${hours} hours`
    } else {
      const days = Math.floor(hours / 24)
      const remainingHours = Math.round(hours % 24)
      if (remainingHours === 0) {
        return `${days} day${days > 1 ? "s" : ""}`
      }
      return `${days} day${days > 1 ? "s" : ""} ${remainingHours} hour${remainingHours > 1 ? "s" : ""}`
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <Timer className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Post-Workout Recovery Calculator</CardTitle>
                    <CardDescription>Estimate optimal recovery time</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Workout Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Workout Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Enter workout duration"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Workout Intensity */}
                <div className="space-y-2">
                  <Label>Workout Intensity</Label>
                  <Select value={intensity} onValueChange={(v) => setIntensity(v as IntensityLevel)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low - Light effort, can talk easily</SelectItem>
                      <SelectItem value="moderate">Moderate - Somewhat hard, can hold conversation</SelectItem>
                      <SelectItem value="high">High - Hard effort, difficult to talk</SelectItem>
                      <SelectItem value="very-high">Very High - Maximum effort, can't talk</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Activity Type */}
                <div className="space-y-2">
                  <Label>Activity Type</Label>
                  <Select value={activityType} onValueChange={(v) => setActivityType(v as ActivityType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cardio">Cardio (Running, Cycling, Swimming)</SelectItem>
                      <SelectItem value="strength">Strength Training (Weights, Resistance)</SelectItem>
                      <SelectItem value="hiit">HIIT (High-Intensity Interval Training)</SelectItem>
                      <SelectItem value="mixed">Mixed (Combination workout)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Age */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="10"
                    max="100"
                  />
                </div>

                {/* Fitness Level */}
                <div className="space-y-2">
                  <Label>Fitness Level</Label>
                  <Select value={fitnessLevel} onValueChange={(v) => setFitnessLevel(v as FitnessLevel)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner (0-6 months training)</SelectItem>
                      <SelectItem value="intermediate">Intermediate (6 months - 2 years)</SelectItem>
                      <SelectItem value="advanced">Advanced (2+ years consistent training)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Optional: Heart Rate */}
                <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="include-hr" className="text-sm font-medium flex items-center gap-2">
                      <Heart className="h-4 w-4" />
                      Include Post-Exercise Heart Rate
                    </Label>
                    <Switch id="include-hr" checked={includeHeartRate} onCheckedChange={setIncludeHeartRate} />
                  </div>
                  {includeHeartRate && (
                    <Input
                      type="number"
                      placeholder="Heart rate after exercise (bpm)"
                      value={heartRate}
                      onChange={(e) => setHeartRate(e.target.value)}
                      min="40"
                      max="220"
                    />
                  )}
                </div>

                {/* Optional: Sleep Quality */}
                <div className="space-y-3 p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="include-sleep" className="text-sm font-medium flex items-center gap-2">
                      <Moon className="h-4 w-4" />
                      Include Sleep Quality
                    </Label>
                    <Switch id="include-sleep" checked={includeSleepQuality} onCheckedChange={setIncludeSleepQuality} />
                  </div>
                  {includeSleepQuality && (
                    <Select value={sleepQuality} onValueChange={(v) => setSleepQuality(v as SleepQuality)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="poor">Poor (less than 5 hours, interrupted)</SelectItem>
                        <SelectItem value="fair">Fair (5-6 hours, some interruptions)</SelectItem>
                        <SelectItem value="good">Good (7-8 hours, minimal interruptions)</SelectItem>
                        <SelectItem value="excellent">Excellent (8+ hours, uninterrupted)</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRecovery} className="w-full" size="lg">
                  Calculate Recovery Time
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Recovery Time</p>
                      <p className={`text-4xl font-bold ${result.color} mb-2`}>
                        {formatRecoveryTime(result.recoveryHours)}
                      </p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.category}</p>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          Hide Recommendations <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Recommendations <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-2">
                        <p className="font-medium text-sm mb-2">Recovery Recommendations:</p>
                        <ul className="space-y-2">
                          {result.recommendations.map((rec, index) => (
                            <li key={index} className="flex items-start gap-2 text-sm">
                              <Check className="h-4 w-4 mt-0.5 flex-shrink-0" />
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Intensity Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Low Intensity</span>
                      <span className="text-sm text-green-600">0.5× duration</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Moderate</span>
                      <span className="text-sm text-blue-600">1× duration</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">High Intensity</span>
                      <span className="text-sm text-yellow-600">1.5× duration</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Very High</span>
                      <span className="text-sm text-red-600">2× duration</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recovery Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      Recovery = Duration × Intensity × Activity × Fitness
                    </p>
                  </div>
                  <p>
                    Additional adjustments are made for age, post-exercise heart rate, and sleep quality when provided.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Activity Type Adjustments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Cardio</span>
                      <span className="font-medium">0.8× (faster recovery)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Mixed</span>
                      <span className="font-medium">1.0× (baseline)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Strength</span>
                      <span className="font-medium">1.2× (muscle repair)</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>HIIT</span>
                      <span className="font-medium">1.4× (high stress)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Workout Recovery</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Post-workout recovery is the process during which your body repairs and strengthens itself after
                  exercise. During workouts, you create microscopic tears in muscle fibers and deplete energy stores.
                  Recovery allows your body to repair these tissues, replenish energy, and adapt to become stronger.
                  Without adequate recovery, you risk overtraining, injury, and diminished performance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The recovery time needed varies significantly based on workout intensity, duration, type of exercise,
                  your fitness level, age, nutrition, sleep quality, and overall stress levels. Understanding your
                  personal recovery needs helps optimize training schedules and maximize fitness gains while minimizing
                  injury risk.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Recovery Time</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Dumbbell className="h-4 w-4" /> Exercise Factors
                    </h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Workout duration and intensity</li>
                      <li>• Type of exercise (cardio vs strength)</li>
                      <li>• Volume and load lifted</li>
                      <li>• Eccentric vs concentric movements</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Heart className="h-4 w-4" /> Individual Factors
                    </h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Age and fitness level</li>
                      <li>• Sleep quality and duration</li>
                      <li>• Nutrition and hydration</li>
                      <li>• Overall stress levels</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Timer className="h-5 w-5 text-primary" />
                  <CardTitle>Recovery Strategies</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Active Recovery</h4>
                    <p className="text-green-700 text-sm">
                      Light activities like walking, swimming, or yoga can enhance blood flow and speed recovery without
                      adding training stress. Aim for 20-30 minutes at low intensity on rest days.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Sleep & Rest</h4>
                    <p className="text-blue-700 text-sm">
                      Quality sleep is when most recovery occurs. Aim for 7-9 hours per night, and consider naps after
                      intense training. Growth hormone release peaks during deep sleep phases.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Nutrition & Hydration</h4>
                    <p className="text-purple-700 text-sm">
                      Consume protein within 2 hours post-workout (20-40g), stay well-hydrated, and ensure adequate
                      carbohydrate intake to replenish glycogen stores. Consider anti-inflammatory foods.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Important Disclaimer</p>
                    <p>
                      Recovery time estimates are general guidelines and may vary based on individual physiology,
                      nutrition, and rest. Listen to your body and consult a fitness professional or healthcare provider
                      for personalized advice. Signs of overtraining include persistent fatigue, decreased performance,
                      mood changes, and increased injury frequency.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
