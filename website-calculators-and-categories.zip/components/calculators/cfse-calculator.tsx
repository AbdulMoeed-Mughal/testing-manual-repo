"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Atom, Info, AlertTriangle, Zap } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Geometry = "octahedral" | "tetrahedral" | "square-planar"
type SpinState = "high-spin" | "low-spin"
type EnergyUnit = "kJ/mol" | "eV"

interface CFSEResult {
  cfse: number
  dElectrons: number
  t2gCount: number
  egCount: number
  spinState: SpinState
  geometry: Geometry
  unit: EnergyUnit
}

export function CFSECalculator() {
  const [geometry, setGeometry] = useState<Geometry>("octahedral")
  const [spinState, setSpinState] = useState<SpinState>("high-spin")
  const [energyUnit, setEnergyUnit] = useState<EnergyUnit>("kJ/mol")
  const [dElectrons, setDElectrons] = useState("")
  const [deltaValue, setDeltaValue] = useState("")
  const [pairingEnergy, setPairingEnergy] = useState("")
  const [result, setResult] = useState<CFSEResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCFSE = () => {
    setError("")
    setResult(null)

    const dElectronsNum = Number.parseInt(dElectrons)
    if (isNaN(dElectronsNum) || dElectronsNum < 0 || dElectronsNum > 10) {
      setError("Please enter a valid number of d-electrons (0-10)")
      return
    }

    const delta = Number.parseFloat(deltaValue)
    if (isNaN(delta) || delta <= 0) {
      setError("Please enter a valid crystal field splitting parameter (Δ > 0)")
      return
    }

    let t2gCount = 0
    let egCount = 0
    let cfse = 0

    if (geometry === "octahedral") {
      // Octahedral geometry
      if (spinState === "high-spin") {
        // High-spin: fill all orbitals singly first, then pair
        if (dElectronsNum <= 3) {
          t2gCount = dElectronsNum
          egCount = 0
        } else if (dElectronsNum <= 5) {
          t2gCount = 3
          egCount = dElectronsNum - 3
        } else if (dElectronsNum <= 8) {
          t2gCount = 3 + (dElectronsNum - 5)
          egCount = 2
        } else {
          t2gCount = 6
          egCount = dElectronsNum - 6
        }
      } else {
        // Low-spin: fill t2g completely before eg
        if (dElectronsNum <= 6) {
          t2gCount = dElectronsNum
          egCount = 0
        } else {
          t2gCount = 6
          egCount = dElectronsNum - 6
        }
      }
      // CFSE = (n_t2g × -0.4Δ₀) + (n_eg × 0.6Δ₀)
      cfse = (t2gCount * -0.4 * delta) + (egCount * 0.6 * delta)
    } else if (geometry === "tetrahedral") {
      // Tetrahedral geometry (always high-spin)
      // In tetrahedral, e orbitals are lower, t2 are higher
      if (dElectronsNum <= 4) {
        // e orbitals (lower)
        const eCount = Math.min(dElectronsNum, 4)
        const t2Count = Math.max(0, dElectronsNum - 4)
        t2gCount = t2Count // Using t2gCount for display
        egCount = eCount
        // CFSE = (n_e × -0.6Δ_t) + (n_t2 × 0.4Δ_t)
        cfse = (eCount * -0.6 * delta) + (t2Count * 0.4 * delta)
      } else {
        const eCount = 4
        const t2Count = dElectronsNum - 4
        t2gCount = t2Count
        egCount = eCount
        cfse = (eCount * -0.6 * delta) + (t2Count * 0.4 * delta)
      }
    } else {
      // Square planar geometry
      // Energy levels from lowest to highest: dxy, dxz/dyz, dz2, dx2-y2
      // Simplified calculation for square planar
      if (dElectronsNum === 8) {
        // Common for d8 metals (Ni2+, Pd2+, Pt2+, Au3+)
        cfse = -1.456 * delta // Strong stabilization
        t2gCount = 6
        egCount = 2
      } else {
        // General approximation
        cfse = dElectronsNum <= 4 
          ? dElectronsNum * -0.514 * delta 
          : (4 * -0.514 * delta) + ((dElectronsNum - 4) * 0.4 * delta)
        t2gCount = Math.min(dElectronsNum, 6)
        egCount = Math.max(0, dElectronsNum - 6)
      }
    }

    // Include pairing energy if provided
    const pairingEnergyNum = Number.parseFloat(pairingEnergy)
    if (!isNaN(pairingEnergyNum) && pairingEnergyNum > 0) {
      // Count electron pairs
      let pairs = 0
      if (geometry === "octahedral" && spinState === "low-spin") {
        pairs = Math.max(0, dElectronsNum - 3)
      } else if (geometry === "octahedral" && spinState === "high-spin") {
        pairs = Math.max(0, dElectronsNum - 5)
      } else {
        pairs = Math.max(0, dElectronsNum - 5)
      }
      cfse += pairs * pairingEnergyNum
    }

    // Round to 2 decimal places
    cfse = Math.round(cfse * 100) / 100

    setResult({
      cfse,
      dElectrons: dElectronsNum,
      t2gCount,
      egCount,
      spinState,
      geometry,
      unit: energyUnit,
    })
  }

  const handleReset = () => {
    setDElectrons("")
    setDeltaValue("")
    setPairingEnergy("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `CFSE: ${result.cfse} ${result.unit} for d${result.dElectrons} ${result.geometry} complex (${result.spinState})`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "CFSE Calculation Result",
          text: `I calculated CFSE using CalcHub! CFSE: ${result.cfse} ${result.unit} for d${result.dElectrons} ${result.geometry} complex`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleEnergyUnit = () => {
    setEnergyUnit((prev) => (prev === "kJ/mol" ? "eV" : "kJ/mol"))
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Atom className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">CFSE Calculator</CardTitle>
                    <CardDescription>Crystal Field Stabilization Energy</CardDescription>
                  </div>
                </div>

                {/* Energy Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Energy Unit</span>
                  <button
                    onClick={toggleEnergyUnit}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        energyUnit === "eV" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        energyUnit === "kJ/mol" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      kJ/mol
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        energyUnit === "eV" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      eV
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Geometry Selection */}
                <div className="space-y-2">
                  <Label>Geometry</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["octahedral", "tetrahedral", "square-planar"] as Geometry[]).map((geo) => (
                      <button
                        key={geo}
                        onClick={() => setGeometry(geo)}
                        className={`p-2 rounded-lg text-sm font-medium border transition-colors ${
                          geometry === geo
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-muted text-muted-foreground border-border hover:bg-muted/80"
                        }`}
                      >
                        {geo.charAt(0).toUpperCase() + geo.slice(1).replace("-", " ")}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Spin State Selection (only for octahedral) */}
                {geometry === "octahedral" && (
                  <div className="space-y-2">
                    <Label>Spin State</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {(["high-spin", "low-spin"] as SpinState[]).map((spin) => (
                        <button
                          key={spin}
                          onClick={() => setSpinState(spin)}
                          className={`p-2 rounded-lg text-sm font-medium border transition-colors ${
                            spinState === spin
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-muted text-muted-foreground border-border hover:bg-muted/80"
                          }`}
                        >
                          {spin.charAt(0).toUpperCase() + spin.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* d-Electron Count */}
                <div className="space-y-2">
                  <Label htmlFor="dElectrons">Number of d-Electrons (0-10)</Label>
                  <Input
                    id="dElectrons"
                    type="number"
                    placeholder="Enter number of d-electrons"
                    value={dElectrons}
                    onChange={(e) => setDElectrons(e.target.value)}
                    min="0"
                    max="10"
                  />
                </div>

                {/* Crystal Field Splitting Parameter */}
                <div className="space-y-2">
                  <Label htmlFor="delta">Crystal Field Splitting (Δ) ({energyUnit})</Label>
                  <Input
                    id="delta"
                    type="number"
                    placeholder={`Enter Δ value in ${energyUnit}`}
                    value={deltaValue}
                    onChange={(e) => setDeltaValue(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Optional Pairing Energy */}
                <div className="space-y-2">
                  <Label htmlFor="pairingEnergy">Pairing Energy (optional) ({energyUnit})</Label>
                  <Input
                    id="pairingEnergy"
                    type="number"
                    placeholder="Enter pairing energy (optional)"
                    value={pairingEnergy}
                    onChange={(e) => setPairingEnergy(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCFSE} className="w-full" size="lg">
                  Calculate CFSE
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.cfse < 0 ? "bg-green-50 border-green-200" : "bg-yellow-50 border-yellow-200"} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Crystal Field Stabilization Energy</p>
                      <p className={`text-5xl font-bold ${result.cfse < 0 ? "text-green-600" : "text-yellow-600"} mb-2`}>
                        {result.cfse}
                      </p>
                      <p className={`text-lg font-semibold ${result.cfse < 0 ? "text-green-600" : "text-yellow-600"}`}>
                        {result.unit}
                      </p>
                    </div>

                    {/* Electron Configuration */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg text-center">
                      <p className="text-sm text-muted-foreground">
                        d<sup>{result.dElectrons}</sup> {result.geometry} ({result.spinState})
                      </p>
                      <p className="text-sm font-medium mt-1">
                        {result.geometry === "tetrahedral" 
                          ? `e: ${result.egCount}, t₂: ${result.t2gCount}`
                          : `t₂g: ${result.t2gCount}, eg: ${result.egCount}`
                        }
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">CFSE Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground">Octahedral:</p>
                    <p>CFSE = (n<sub>t2g</sub> x -0.4Δ₀) + (n<sub>eg</sub> x 0.6Δ₀)</p>
                    <p className="font-semibold text-foreground mt-3">Tetrahedral:</p>
                    <p>CFSE = (n<sub>e</sub> x -0.6Δ<sub>t</sub>) + (n<sub>t2</sub> x 0.4Δ<sub>t</sub>)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Electron Configuration</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">High CFSE (negative)</span>
                      <span className="text-sm text-green-600">More stable</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Low CFSE (near zero)</span>
                      <span className="text-sm text-yellow-600">Less stable</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Δ<sub>oct</sub> vs Δ<sub>tet</sub></span>
                      <span className="text-sm text-purple-600">Δ<sub>t</sub> ≈ 4/9 Δ<sub>o</sub></span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Content Cards */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Crystal Field Stabilization Energy?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Crystal Field Stabilization Energy (CFSE) is a measure of the energy stabilization of a metal complex 
                  due to the splitting of d-orbitals in a ligand field. When ligands approach a metal ion, they create an 
                  electrostatic field that causes the five degenerate d-orbitals to split into different energy levels. 
                  The electrons preferentially occupy the lower-energy orbitals, resulting in an overall energy stabilization.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The CFSE concept is fundamental in crystal field theory, which helps explain the colors, magnetic properties, 
                  and stability of transition metal complexes. A negative CFSE indicates that the complex is more stable than 
                  the theoretical spherical field case, while a larger magnitude of negative CFSE suggests greater thermodynamic stability.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding d-Orbital Splitting</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In an octahedral field, the five d-orbitals split into two groups: the lower-energy t<sub>2g</sub> set 
                  (d<sub>xy</sub>, d<sub>xz</sub>, d<sub>yz</sub>) and the higher-energy e<sub>g</sub> set 
                  (d<sub>z²</sub>, d<sub>x²-y²</sub>). The t<sub>2g</sub> orbitals are stabilized by 0.4Δ₀ below the 
                  barycenter, while the e<sub>g</sub> orbitals are destabilized by 0.6Δ₀.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For tetrahedral complexes, the splitting pattern is inverted and smaller in magnitude (Δ<sub>t</sub> ≈ 4/9 Δ<sub>o</sub>). 
                  The e orbitals become lower in energy, and the t<sub>2</sub> orbitals are higher. Because tetrahedral 
                  splitting is always smaller than octahedral splitting for the same metal and ligands, tetrahedral 
                  complexes are almost always high-spin.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Atom className="h-5 w-5 text-primary" />
                  <CardTitle>High-Spin vs Low-Spin Complexes</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The competition between the crystal field splitting energy (Δ) and the pairing energy (P) determines 
                  whether a complex adopts a high-spin or low-spin configuration. When Δ is greater than P, electrons 
                  preferentially pair in the lower orbitals (low-spin). When P is greater than Δ, electrons fill all 
                  orbitals singly before pairing (high-spin).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Strong-field ligands (like CN⁻, CO) produce large Δ values, favoring low-spin configurations. 
                  Weak-field ligands (like I⁻, Br⁻) produce small Δ values, favoring high-spin configurations. 
                  This has significant implications for the magnetic and spectroscopic properties of the complexes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Crystal field theory provides a simplified electrostatic model that does not account for covalent 
                  bonding between metal and ligands. The actual CFSE values may differ from calculated values due to 
                  nephelauxetic effects (electron cloud expansion), Jahn-Teller distortions, and spin-orbit coupling.
                </p>
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800 text-sm">
                    <strong>Disclaimer:</strong> CFSE calculations assume ideal crystal field theory. Actual stabilization 
                    may vary due to covalency, lattice effects, or ligand field deviations. For more accurate results, 
                    consider using ligand field theory or molecular orbital theory approaches.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
