"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Info, AlertTriangle, Waves } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface FrictionResult {
  pressureLoss: number
  headLoss: number
  frictionFactor: number
  reynoldsNumber: number
  flowRegime: string
  color: string
  bgColor: string
}

export function PipeFrictionLossCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [pipeLength, setPipeLength] = useState("")
  const [pipeDiameter, setPipeDiameter] = useState("")
  const [velocity, setVelocity] = useState("")
  const [density, setDensity] = useState("")
  const [viscosity, setViscosity] = useState("")
  const [roughness, setRoughness] = useState("")
  const [result, setResult] = useState<FrictionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Common pipe materials roughness values (in mm)
  const pipePresets = [
    { name: "Smooth (PVC/Plastic)", roughness: 0.0015 },
    { name: "Drawn Copper", roughness: 0.0015 },
    { name: "Commercial Steel", roughness: 0.045 },
    { name: "Galvanized Steel", roughness: 0.15 },
    { name: "Cast Iron", roughness: 0.26 },
    { name: "Concrete", roughness: 1.0 },
  ]

  // Fluid presets
  const fluidPresets = [
    { name: "Water (20°C)", density: 998, viscosity: 0.001002 },
    { name: "Sea Water", density: 1025, viscosity: 0.00108 },
    { name: "Oil (SAE 30)", density: 880, viscosity: 0.3 },
    { name: "Air (20°C)", density: 1.204, viscosity: 0.0000182 },
  ]

  const calculateFrictionLoss = () => {
    setError("")
    setResult(null)

    const L = Number.parseFloat(pipeLength)
    const D = Number.parseFloat(pipeDiameter)
    const v = Number.parseFloat(velocity)
    const rho = Number.parseFloat(density)
    const mu = Number.parseFloat(viscosity)
    const eps = Number.parseFloat(roughness)

    if (isNaN(L) || L <= 0) {
      setError("Please enter a valid pipe length greater than 0")
      return
    }
    if (isNaN(D) || D <= 0) {
      setError("Please enter a valid pipe diameter greater than 0")
      return
    }
    if (isNaN(v) || v <= 0) {
      setError("Please enter a valid velocity greater than 0")
      return
    }
    if (isNaN(rho) || rho <= 0) {
      setError("Please enter a valid density greater than 0")
      return
    }
    if (isNaN(mu) || mu <= 0) {
      setError("Please enter a valid viscosity greater than 0")
      return
    }
    if (isNaN(eps) || eps < 0) {
      setError("Please enter a valid roughness (0 or greater)")
      return
    }

    // Convert to SI units if imperial
    let L_m = L
    let D_m = D
    let v_ms = v
    let rho_kgm3 = rho
    let mu_pas = mu
    let eps_m = eps

    if (unitSystem === "imperial") {
      L_m = L * 0.3048 // ft to m
      D_m = D * 0.0254 // inches to m
      v_ms = v * 0.3048 // ft/s to m/s
      rho_kgm3 = rho * 16.0185 // lb/ft³ to kg/m³
      mu_pas = mu * 47.8803 // lb/ft·s to Pa·s
      eps_m = eps * 0.3048 // ft to m
    } else {
      // Metric: diameter in cm, roughness in mm
      D_m = D / 100 // cm to m
      eps_m = eps / 1000 // mm to m
    }

    // Calculate Reynolds number
    const Re = (rho_kgm3 * v_ms * D_m) / mu_pas

    // Determine flow regime
    let flowRegime: string
    let color: string
    let bgColor: string

    if (Re < 2300) {
      flowRegime = "Laminar"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else if (Re < 4000) {
      flowRegime = "Transitional"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else {
      flowRegime = "Turbulent"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    }

    // Calculate friction factor
    let f: number

    if (Re < 2300) {
      // Laminar flow: f = 64/Re
      f = 64 / Re
    } else {
      // Turbulent flow: Colebrook-White equation (using Swamee-Jain approximation)
      const relRoughness = eps_m / D_m
      f = 0.25 / Math.pow(Math.log10(relRoughness / 3.7 + 5.74 / Math.pow(Re, 0.9)), 2)
    }

    // Calculate pressure loss using Darcy-Weisbach equation
    // ΔP = f × (L/D) × 0.5 × ρ × v²
    const pressureLoss_Pa = f * (L_m / D_m) * 0.5 * rho_kgm3 * v_ms * v_ms

    // Calculate head loss
    // h = ΔP / (ρ × g)
    const g = 9.81
    const headLoss_m = pressureLoss_Pa / (rho_kgm3 * g)

    // Convert results based on unit system
    let pressureLoss = pressureLoss_Pa
    let headLoss = headLoss_m

    if (unitSystem === "imperial") {
      pressureLoss = pressureLoss_Pa * 0.000145038 // Pa to psi
      headLoss = headLoss_m * 3.28084 // m to ft
    } else {
      pressureLoss = pressureLoss_Pa / 1000 // Pa to kPa
    }

    setResult({
      pressureLoss: Math.round(pressureLoss * 1000) / 1000,
      headLoss: Math.round(headLoss * 1000) / 1000,
      frictionFactor: Math.round(f * 10000) / 10000,
      reynoldsNumber: Math.round(Re),
      flowRegime,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setPipeLength("")
    setPipeDiameter("")
    setVelocity("")
    setDensity("")
    setViscosity("")
    setRoughness("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Pipe Friction Loss: ${result.pressureLoss} ${unitSystem === "metric" ? "kPa" : "psi"}, Head Loss: ${result.headLoss} ${unitSystem === "metric" ? "m" : "ft"}, Friction Factor: ${result.frictionFactor}, Re: ${result.reynoldsNumber} (${result.flowRegime})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    handleReset()
  }

  const applyPipePreset = (roughnessValue: number) => {
    if (unitSystem === "metric") {
      setRoughness(roughnessValue.toString())
    } else {
      setRoughness((roughnessValue / 304.8).toFixed(6))
    }
  }

  const applyFluidPreset = (preset: { density: number; viscosity: number }) => {
    if (unitSystem === "metric") {
      setDensity(preset.density.toString())
      setViscosity(preset.viscosity.toString())
    } else {
      setDensity((preset.density / 16.0185).toFixed(3))
      setViscosity((preset.viscosity / 47.8803).toFixed(6))
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Waves className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Pipe Friction Loss Calculator</CardTitle>
                    <CardDescription>Calculate pressure loss due to friction in pipes</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Pipe Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="pipeLength">Pipe Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="pipeLength"
                    type="number"
                    placeholder={`Enter pipe length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={pipeLength}
                    onChange={(e) => setPipeLength(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Pipe Diameter Input */}
                <div className="space-y-2">
                  <Label htmlFor="pipeDiameter">Pipe Diameter ({unitSystem === "metric" ? "cm" : "inches"})</Label>
                  <Input
                    id="pipeDiameter"
                    type="number"
                    placeholder={`Enter pipe diameter in ${unitSystem === "metric" ? "centimeters" : "inches"}`}
                    value={pipeDiameter}
                    onChange={(e) => setPipeDiameter(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Velocity Input */}
                <div className="space-y-2">
                  <Label htmlFor="velocity">Fluid Velocity ({unitSystem === "metric" ? "m/s" : "ft/s"})</Label>
                  <Input
                    id="velocity"
                    type="number"
                    placeholder={`Enter velocity in ${unitSystem === "metric" ? "m/s" : "ft/s"}`}
                    value={velocity}
                    onChange={(e) => setVelocity(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Fluid Properties */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Quick Fluid Selection</Label>
                  <div className="flex flex-wrap gap-2">
                    {fluidPresets.map((preset) => (
                      <Button
                        key={preset.name}
                        variant="outline"
                        size="sm"
                        onClick={() => applyFluidPreset(preset)}
                        className="text-xs"
                      >
                        {preset.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Density Input */}
                <div className="space-y-2">
                  <Label htmlFor="density">Fluid Density ({unitSystem === "metric" ? "kg/m³" : "lb/ft³"})</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder={`Enter density in ${unitSystem === "metric" ? "kg/m³" : "lb/ft³"}`}
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Viscosity Input */}
                <div className="space-y-2">
                  <Label htmlFor="viscosity">Dynamic Viscosity ({unitSystem === "metric" ? "Pa·s" : "lb/ft·s"})</Label>
                  <Input
                    id="viscosity"
                    type="number"
                    placeholder={`Enter viscosity in ${unitSystem === "metric" ? "Pa·s" : "lb/ft·s"}`}
                    value={viscosity}
                    onChange={(e) => setViscosity(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Pipe Roughness */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Quick Pipe Material Selection</Label>
                  <div className="flex flex-wrap gap-2">
                    {pipePresets.map((preset) => (
                      <Button
                        key={preset.name}
                        variant="outline"
                        size="sm"
                        onClick={() => applyPipePreset(preset.roughness)}
                        className="text-xs"
                      >
                        {preset.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Roughness Input */}
                <div className="space-y-2">
                  <Label htmlFor="roughness">Pipe Roughness ({unitSystem === "metric" ? "mm" : "ft"})</Label>
                  <Input
                    id="roughness"
                    type="number"
                    placeholder={`Enter roughness in ${unitSystem === "metric" ? "mm" : "ft"}`}
                    value={roughness}
                    onChange={(e) => setRoughness(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFrictionLoss} className="w-full" size="lg">
                  Calculate Friction Loss
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Pressure Loss</p>
                      <p className={`text-4xl font-bold ${result.color} mb-1`}>
                        {result.pressureLoss} <span className="text-lg">{unitSystem === "metric" ? "kPa" : "psi"}</span>
                      </p>
                      <p className="text-sm text-muted-foreground mt-2">Head Loss</p>
                      <p className={`text-2xl font-semibold ${result.color}`}>
                        {result.headLoss} {unitSystem === "metric" ? "m" : "ft"}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Friction Factor</p>
                        <p className="font-semibold">{result.frictionFactor}</p>
                      </div>
                      <div className="p-2 bg-white/50 rounded-lg text-center">
                        <p className="text-muted-foreground">Reynolds Number</p>
                        <p className="font-semibold">{result.reynoldsNumber.toLocaleString()}</p>
                      </div>
                    </div>

                    <div className="mt-3 p-2 bg-white/50 rounded-lg text-center">
                      <p className="text-muted-foreground text-sm">Flow Regime</p>
                      <p className={`font-semibold ${result.color}`}>{result.flowRegime}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setShowSteps(!showSteps)}>
                        {showSteps ? "Hide Steps" : "Show Steps"}
                      </Button>
                    </div>

                    {/* Step-by-step breakdown */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white/70 rounded-lg text-sm space-y-2">
                        <p className="font-semibold">Step-by-Step Calculation:</p>
                        <p>1. Reynolds Number: Re = (ρ × v × D) / μ = {result.reynoldsNumber.toLocaleString()}</p>
                        <p>
                          2. Flow Regime: {result.flowRegime} (Re{" "}
                          {result.reynoldsNumber < 2300
                            ? "< 2300"
                            : result.reynoldsNumber < 4000
                              ? "2300-4000"
                              : "> 4000"}
                          )
                        </p>
                        <p>
                          3. Friction Factor: f = {result.frictionFactor} (
                          {result.reynoldsNumber < 2300 ? "64/Re for laminar" : "Swamee-Jain approximation"})
                        </p>
                        <p>4. Darcy-Weisbach: ΔP = f × (L/D) × 0.5 × ρ × v²</p>
                        <p>5. Head Loss: h = ΔP / (ρ × g)</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Darcy-Weisbach Equation</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">ΔP = f × (L/D) × ½ρv²</p>
                  </div>
                  <p>Where:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>
                      <strong>ΔP</strong> = Pressure loss
                    </li>
                    <li>
                      <strong>f</strong> = Darcy friction factor
                    </li>
                    <li>
                      <strong>L</strong> = Pipe length
                    </li>
                    <li>
                      <strong>D</strong> = Pipe diameter
                    </li>
                    <li>
                      <strong>ρ</strong> = Fluid density
                    </li>
                    <li>
                      <strong>v</strong> = Flow velocity
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Pipe Roughness Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {pipePresets.map((preset) => (
                      <div key={preset.name} className="flex justify-between p-2 bg-muted/50 rounded">
                        <span>{preset.name}</span>
                        <span className="font-mono">{preset.roughness} mm</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Flow Regimes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Laminar</span>
                      <span className="text-sm text-green-600">Re {"<"} 2,300</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Transitional</span>
                      <span className="text-sm text-yellow-600">2,300 – 4,000</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Turbulent</span>
                      <span className="text-sm text-blue-600">Re {">"} 4,000</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Pipe Friction Loss */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Pipe Friction Loss?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pipe friction loss, also known as head loss or pressure drop, is the loss of pressure or energy that
                  occurs when a fluid flows through a pipe. This loss is primarily caused by the friction between the
                  fluid and the pipe walls, as well as internal fluid friction. Understanding friction loss is crucial
                  for designing efficient piping systems, selecting appropriate pumps, and ensuring adequate flow rates
                  in industrial, commercial, and residential applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Darcy-Weisbach equation is the most widely used formula for calculating friction loss in pipes. It
                  accounts for pipe geometry (length and diameter), fluid properties (density and viscosity), flow
                  velocity, and pipe roughness. The friction factor used in this equation depends on the flow regime
                  (laminar or turbulent) and is determined by the Reynolds number and relative pipe roughness.
                </p>
              </CardContent>
            </Card>

            {/* Applications */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Waves className="h-5 w-5 text-primary" />
                  <CardTitle>Engineering Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pipe friction loss calculations are essential in many engineering applications including HVAC system
                  design, water distribution networks, oil and gas pipelines, chemical processing plants, and fire
                  protection systems. Engineers use these calculations to properly size pipes, select pumps with
                  adequate head capacity, and optimize system efficiency to minimize energy consumption and operating
                  costs.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Pipe friction loss calculations are estimates based on standard formulas assuming steady, fully
                  developed flow in straight pipes. Actual losses may vary due to fittings, valves, bends, turbulence,
                  temperature effects, pipe aging, and deposits. For critical applications, consult fluid mechanics
                  references, manufacturer data, and professional engineering guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
